<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_menus.php 2823 2022-10-03 02:24:54Z robert0609 $
 */

/**
 * Description of API client test menus
 * for CLI ops
 * @author robert0609
 */

require_once 'api_dialogs.php';
require_once 'api_client.php';

class Capi_menus extends Capi_dialogs {

	protected static $etc_dir = false;
	protected static $api_dialogs_file = false;
	protected static $api_dialogs = false;
	protected static $api_client = false;

	protected static $meths2mod = array('get','post','put','delete');

	const API_DIALOGS_INI = 'API_dialogs.ini';
	const DEF_BOX_TITLE = 'API Dialogs';

	function __construct() {
		parent::__construct();
		self::$etc_dir = ETC_API_DIR;
		if(!is_dir(self::$etc_dir)) mkdir(self::$etc_dir,0777,true);
		self::$api_dialogs_file = self::$etc_dir . self::API_DIALOGS_INI;
		self::$api_dialogs = Capi_client::load_json(self::$api_dialogs_file);
		if(empty(self::$api_dialogs)) {
			self::$api_dialogs = array(
				'dest_url' => false,
				'summary' => false,
				'recent_calls' => array(),
				);
			} // if
		} // __construct()

	function __destruct() {
		parent::__destruct();
		if(!empty(self::$api_dialogs)) {
			Capi_client::save_json(self::$api_dialogs_file, self::$api_dialogs);
			} // if
		} // __destruct()

// static methods
	public static function help() {
		echo 'Help for Menus API Client.' . PHP_EOL;
		echo '	CLI options;' . PHP_EOL;
		echo '	[-h|--help]' . PHP_EOL;
		echo '	[-u|--url dest_rul]' . PHP_EOL;
		echo '	[-t|--token token]' . PHP_EOL;
		echo '	[-j|--jwt JWT]' . PHP_EOL;
		echo '	[--timeout seconds]' . PHP_EOL;
		echo '' . PHP_EOL;
		} // help()

// dynamic methods

	public function run_API_call($dest_url = false,$path = false,$init_vals = false, $use_init_vals = false) {
		global $argc, $argv;

		$port = false;
		$timeout_mS = 0;
		$token =false;
		if(!empty($argv[1])) {
			$opts = $argv;
			for($i = 1; $i < count($opts);$i++) {
				switch($opts[$i]) {
				case '-u':
				case '--url':
					if(!empty($opts[++$i])) $dest_url = $opts[$i];
					break;
				case '-t':
				case '--token':
					if(!empty($opts[++$i])) $token = $opts[$i];
					break;
				case '-j':
				case '--jwt':
					if(!empty($opts[++$i])) $JWT = $opts[$i];
					break;
				case '--timeout':	// seconds
					if(!empty($opts[++$i])) $timeout_mS = $opts[$i] * 1000;	// as mS
					break;
				default:
				case '-h':
				case '--help':
					self::help();
					exit(0);
					break;
					} // switch
				} // for
			} // if

		$box_backtitle = self::DEF_BOX_TITLE;
		if(empty($dest_url)) {
			if(($use_init_vals) && (!empty(self::$api_dialogs['dest_url']))) {
				$dest_url = self::$api_dialogs['dest_url'];
				} // if
			else {
				$dest_url = self::box_input(
					'Destination URL',		// title
					$box_backtitle,	// backtitle
					'Enter API destination URL.',	// query
					80,	// width
					0,	// height
					self::$api_dialogs['dest_url']	// init value
					);
				} // else
			// echo PHP_EOL . 'DEST URL: ' . print_r($dest_url,true) . PHP_EOL;	// test
			} // if
		if(empty($dest_url)) {
			Capi_client::log_msg('API destination URL empty.','err');
			return false;
			} // if

		self::$api_client = new Capi_client($dest_url,$port,$timeout_mS,$token);
		if((empty(self::$api_dialogs['summary']['paths'])) || (self::$api_dialogs['dest_url'] != $dest_url)) {
			self::$api_dialogs['summary'] = self::$api_client->get_summary();
			self::$api_dialogs['dest_url'] = $dest_url;	// save it
			} // if
		if(empty(self::$api_dialogs['summary']['paths'])) {
			Capi_client::log_msg('API did not return a useable summary.','err');
			Capi_client::log_msg(print_r(self::$api_dialogs,true),'info');
			return false;
			} // if
		// get function to call
		$menu = array(
			'title' => 'API Ops',
			'items' => array(),	// (meth . path) => description
			);
		if(($use_init_vals) && (!empty($init_vals['meth_path']))) {
			$meth_path = $init_vals['meth_path'];
			} // if
		else {
			foreach(self::$api_dialogs['summary']['paths'] as $path => &$cntl) {
				foreach($cntl as $meth => &$m_cntrl) {
					if(!in_array($meth,self::$meths2mod)) continue;
					$menu['items'][(strtoupper($meth) . ':' . $path)] = $m_cntrl['description'];
					} // foreach
				} // foreach
			$meth_path = self::box_menu('API Paths (function calls)', $box_backtitle, $menu);
			} // else
		// $meth_path = 'GET:/session/open';	// test
		// $meth_path = 'GET:/cms/logCMS';	// test
		// echo PHP_EOL . 'METH:PATH: ' . print_r($meth_path,true) . PHP_EOL;	// test
		if(empty($meth_path)) {
			return false;
			} // if

		// get function parameters
		list($meth,$path) = explode(':',$meth_path);
		$meth = strtolower($meth);
		if(empty(self::$api_dialogs['summary']['paths'][$path][$meth])) {
			Capi_client::log_msg('API method ' . $meth . ' and ' .$path . ' path not available.','err');
			return false;
			} // if
		$m_cntrl = self::$api_dialogs['summary']['paths'][$path][$meth];
		$param_vals = array();
		$required = array();

		if(!empty($m_cntrl['parameters'])) {	// get parameter values
			// do query
			$form = array(
				'title' => 'Enter API parameters.',	// the form title
				'height' => 15,
				'width' => 64,
				'formheight' => 0,	// typically 0 to default to 'height'
				'elements' => array(),
				);
			foreach($m_cntrl['parameters'] as &$param) {
				$name = $param['name'];
				switch($name) {	// inital by name
				case 'JWT':
					$init_vals[$name] = self::$api_client->get_jwt();	// from session
					break;
				default:
					break;
					} // switch
				if($use_init_vals) {
					if(!empty($init_vals[$name])) {
						$param_vals[$name] = $init_vals[$name];
						continue;
						} // if
					else if(empty($param['required'])) continue;
					} // if
				switch($param['in']) {
				default:
					// fall thru
				case 'query':
				case 'path':
					if(empty($param['enum'])) {
						$prm_cntl = array(
							'label' => $name,
							'flen' => 24,
							);
						if(!empty($init_vals[$name]))
							$prm_cntl['value'] = $init_vals[$name];
						$form['elements'][] = $prm_cntl;
						} // if
					else {	// selector (one at a time (??)
						$lst = array('items' => array());
						foreach($param['enum'] as $item) $lst['items'][$item] = ucwords($name) .  ': ' . $item;
						$param_vals[$name] = self::box_menu(
							'Select: ' . (!empty($param['description']) ? $param['description']:$name . ' value.'),
							$box_backtitle, $lst);
						} // else
					break;
				case 'app':
				case 'body':
				case 'formData':
				case 'post':
					if(!empty($init_vals[$name])) {
						if(@file_exists($init_vals[$name])) $param_vals[$name]['__filenames'] = $init_vals[$name];
						else $param_vals[$name] = $init_vals[$name];	// it is the parameter data
						} // if
					else {	// use files for large/json/text data  to send to server
						$param_vals[$name]['__filenames'] = self::box_file_select('Select file for "' . $name . '" parameter.', $box_backtitle,VAR_RESULTS_DIR,60);
						} // else
					break;
					} // switch
				if(!empty($param['required'])) $required[] = $name;
				} // foreach
			if(!empty($form['elements']))
				$param_vals = array_merge($param_vals,self::box_simple_form('Enter "' . $meth_path . '" parameters.', $box_backtitle,$form));
			// $param_vals = array('username' => 'tester','password' => 'tester');	// test
			// $param_vals = array('tail' => '10');	// test
			// echo PHP_EOL . 'PARAMS: ' . print_r($param_vals,true) . PHP_EOL;	// test

			if(empty($param_vals)) {
				Capi_client::log_msg('No API params entered.','warn');
				return false;
				} // if
			$ok = true;
			foreach($required as $name) {
				if(empty($param_vals[$name])) {
					Capi_client::log_msg('Need value for ' . $name .'.','err');
					$ok = false;
					} // if
				} // foreach
			if(!$ok) return false;
			} // if
		$results = self::$api_client->call_api_function($path,$meth,$m_cntrl,$param_vals);
		$results_file = self::$api_client->save_results($results);
		if($results_file)
			self::$api_client->log_msg('Results saved in: "' . $results_file . '".','info');
		// echo PHP_EOL . 'RESULTS: ' . print_r($results,true) . PHP_EOL;	// test
		return $results;
		} // run_API_call()

} // Capi_menus
