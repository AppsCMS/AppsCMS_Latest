#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: example_apps_cron.sh 2786 2022-08-31 05:40:44Z robert0609 $

# example apps common CRON engagement script
# run as apps/cli/apps_cron.sh from web root directory
# wraps apps/cli/apps_cron.php to access the AppsCMS and PHP code

FVERSION="Vx.yz"

BASE_DIR="$(dirname $0 | sed 's/apps\/cli//g' )"
pushd "$BASE_DIR" > /dev/null
/usr/bin/php "apps/cli/apps_cron.php" "$1" "$2"
popd > /dev/null

# EOF

