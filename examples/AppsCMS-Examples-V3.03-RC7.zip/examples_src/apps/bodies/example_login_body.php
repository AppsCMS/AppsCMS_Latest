<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_login_body.php 2786 2022-08-31 05:40:44Z robert0609 $
 */
?>

		<div class="login_extra">
			<h1>Login</h1>
<?php
		// require(CMS_FS_OPS_DIR . 'cms_login_local_form.php');
		Ccms::get_app_action(false);
		$text = Ccms_auth::get_signin_signout('',false);
		echo $text;
?>
		</div>

