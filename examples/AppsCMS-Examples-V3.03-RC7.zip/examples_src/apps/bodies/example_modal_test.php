<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_modal_test.php 2786 2022-08-31 05:40:44Z robert0609 $
 */
Ccms::page_start_comment(__FILE__);
?>
<style>
	/* override modal background */
	#id_CU_id_dlg__modal {
		background-color: lightblue;	/* should be covered !! */
		border-radius: 7px;
		border: 2px solid black;
		}

	/* give h1 a boost */
	#id_CU_id_dlg__body h1 {
		text-align: center;
		color: purple;
		}
	div.h1__mt {
		text-align: center;
		}

	.id_dlg_contactus div {
		background-color: lightgrey;
		border-radius: 5px;
		border: 2px solid pink;
		}

	/* override the panels */
	.__panel_contacts_mt div,
	.__panel_feedback_mt div {
		background-color: lightgreen;
		margin: 10px;
		padding: 5px;
		border: 2px solid darkgreen;
		border-radius: 5px;
		color: black;
		}

	/* override the error msg */
	span.cms_msg_required {
		background-color: orange;
		color: blue;
		}

</style>

Add page body code or text here.

<br>

	<div>
		<?= Ccms::getMsgs() ?>
	</div>
<br>
	<button type="button" name="contact_us" id="id_contact_us" onclick="show_contactus_modal();">
		Show Contact Us Modal
	</button>

<?php
	$form_id = '';
	$suffix = '_mt';
	$class = '';	// usually 'page_body'
	$geo_flg = true;	// if available
	$msg_drop_box = false;

	$body_text = Ccms_contactus_plugin::generate($form_id,$suffix,$class,$geo_flg,$msg_drop_box);
	// this could be done by calling panels separately

	$name = 'CU';
	$id = 'id_dlg_';
	$class_name = 'id_dlg_contactus';
	$h1 = '';
	$header = '';
	$footer = '';

	$cModal = new Ccms_modal();
	echo $cModal->get_modal($id, $body_text, $class_name, $h1, $header, $footer, $name);

?>
<script type="text/javascript">
	function show_contactus_modal() {
		<?= $cModal->get_name() ?>_open_modal();
		} // show_contactus_modal()

<?php
if ((Ccms_contactus_plugin::get_msg_cnt_contactus() > 0) ||
	(Ccms_contactus_plugin::has_email_been_sent())) {
?>

	show_contactus_modal();	// keep dialog open is message/s

<?php
	} // if
?>
</script>

<?= Ccms::page_end_comment(__FILE__) ?>
