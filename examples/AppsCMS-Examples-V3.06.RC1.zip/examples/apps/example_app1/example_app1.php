<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_app1.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

?>

<p>
	<?= Cexample_app1_app::where_am_I(); // static method (no new/dymanic allocation ?>
</p>

<?php

$cCEX = new Cexample_app1_app();

?>

<p>
	<?php $cCEX->who_am_I(); // dynamic method, can be multiple ?>
</p>

