<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_app.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of Cexample_app_plugin
 *
 * Provides an example local app plugin
 *
 * @author robert0609
 */

class Cexample_app_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'example_app';
	const APP_NAME = 'exmple_app';

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		return self::is_plugin_enabled(self::PLUGIN);
		} // is_enabled()

	private static function apps_ext_init() {	// just for uniformity
		// setup app extension data
		// nothing todo, just return
		} // apps_ext_init()

	protected static function read_app_settings_ini() {
		// the return value is mainly used for config searchs
		self::apps_ext_init();
		return array(	// must be in the same order as the idx= param
			self::$config_ext,
			self::$config_ext2,
			);
		} // read_app_settings_ini()

	protected static function read_app_comments_ini() {
		// the return value is mainly used for config searchs
		self::apps_ext_init();
		return array(	// must be in the same order as the idx= param
			self::$config_ext_control,
			self::$config_ext2_control,
			);
		} // read_app_comments_ini()

	public static function get_admin_uris() {	// refer to index.php?cms_action=cms_manual#AppsExtendPlugin
		$admin_uris = array(
			'app_name' => self::APP_NAME,
			'app_dir' => $app_dir,
			'app_uri' => false,
			);
		$admin_uris[] = array(
				'text' => 'Apps Presets',
				'func' => 'Cexample_plugin::get_apps_extend_settings()',
				'title' => 'Setup application presets on example.',
				'app_name' => self::APP_NAME,
			);
		return $admin_uris;
		} // get_admin_uris()

	public static function get_apps_extend_settings() {
		// typically uses the Ccms_edit class
		return true;
		} // get_apps_extend_settings()

	public static function get_title() {	// get the plugin title
		return 'Example Local App Plugin.';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The Example plugin (' . self::PLUGIN . ') description. An example of a standard app local plugin.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "EXAMPLE_APP_PLUGIN",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Use Example App Local Plugin.",
				'cms_config_description' => "True = use plugin. False = not used.",
				),	// row data
			 array(
			 	'cms_config_key' => "example_CONTROL",	// gets prefixed with the PL_PluginName_ in uppercase
			 	'cms_config_value' => "true",
			 	'cms_config_allowed_values' => "true:false",
			 	'cms_config_name' => "Use example Control.",
			 	'cms_config_description' => "True = use example control plugin. False = turn off control.",
			 	),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Cexample_app_plugin
