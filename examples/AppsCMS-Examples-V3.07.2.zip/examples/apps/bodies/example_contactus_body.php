<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_contactus_body.php 2808 2022-09-16 11:22:11Z robert0609 $
 */

?>
<!--
Example contactus page.
-->
<style>
	table.contactus {
		background-color: inherit;
		border: 2px solid grey;
		min-width: 320px;
		}
	tr.contactus,th.contactus,td.contactus {
		padding-top: 5px;
		vertical-align: top;
		}
	th.contactus,td.contactus {
		margin: 5px;
		text-align: left;
		}
</style>
<?= Ccms_contactus_plugin::generate('','_mt','page_body contactus') ?>
