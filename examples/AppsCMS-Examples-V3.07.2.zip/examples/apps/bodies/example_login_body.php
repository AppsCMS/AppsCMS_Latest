<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_login_body.php 3100 2023-02-06 02:08:30Z robert0609 $
 */
?>

		<div class="login_extra">
			<h1>Login to: <?= CMS_C_CO_NAME ?></h1>
<?php
		Ccms::get_app_action(false);
		$text = Ccms_auth::get_signin_signout('',false);
		echo $text;
?>
		</div>

