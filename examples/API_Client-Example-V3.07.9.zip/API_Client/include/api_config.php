<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_config.php 3458 2024-05-12 04:53:29Z robert0609 $
 */

// configuration for API Client

define('API_VERSION',	    'V3.07.9');
define('API_NAME',	    	'API Client for AppsCMS');
define('API_SHORT_NAME',	'APIclient');
define('API_CHAR_SET',      'utf8');

// directories
// where is everything
define('BASE_DIR',	str_replace('\\','/',dirname(dirname(__FILE__))) . '/');	 // here I am
if(!empty($_SERVER['HOME'])) define('HOME', $_SERVER['HOME'] . '/temp/' . API_SHORT_NAME . '/'); // dont include in squash and zip files
else define('HOME',         'BASE_DIR');	// ?? BAD
define('ETC_API_DIR',       HOME . 'etc/API/');
define('VAR_API_DIR',		HOME . 'var/API/');
define("VAR_LOGS_DIR",		VAR_API_DIR . "logs/");
define("VAR_RESULTS_DIR",	VAR_API_DIR . "results/");

// the files
define('SESSION_FILE',		'API_session.json');
define('API_SUMMARY_FILE',	'API_summary.json');
define("LOG_FILE",			'APIclient-' . date('Ymd') . '.log');
define("ERROR_LOG_FILE",	'APIclient_error_php-' . date('Ymd') . '.log');

// globel defines
date_default_timezone_set('Australia/Sydney');
ini_set('log_errors',		'On');
ini_set('error_log',		VAR_LOGS_DIR . ERROR_LOG_FILE);	// separate errors from global log
ini_set('display_errors',	'On');
ini_set('display_startup_errors','On');
ini_set('html_errors',		'Off');


// eof
