<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_session.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of API client session
 *
 * @author robert0609
 */

require_once 'api_logs.php';

class Capi_session extends Capi_logs {

	protected $request_header = false;
	protected $response_info = false;
	protected $response_header = false;
	protected $result = false;

	protected static $etc_dir = false;
	protected static $client_session_file = false;
	protected static $api_summary_file = false;

	protected static $client_session = false;
	protected static $api_summary = false;

	const API_TOK_KEY = 'API_key';	// index to token in headers
	const API_JWT_KEY = 'JWT';	// index to JWT where used

	function __construct() {
		parent::__construct();
		self::init_session();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		self::save_session();
		} // __destruct()

	// static methods
	protected static function init_session() {
		self::$etc_dir = ETC_API_DIR;
		if(!is_dir(self::$etc_dir)) mkdir(self::$etc_dir,0777,true);

		self::$client_session_file = self::$etc_dir . SESSION_FILE;
		self::$client_session = self::load_json(self::$client_session_file);
		if(empty(self::$client_session)) {
			self::$client_session = array(
				self::API_TOK_KEY => false,
				'token_name' => false,
				'token_expires' => false,
				);
			} // if

		self::$api_summary_file = self::$etc_dir . API_SUMMARY_FILE;
		self::$api_summary = self::load_json(self::$api_summary_file);
		if(empty(self::$api_summary)) {
			self::$api_summary = array();
			} // if
		// print_r(self::$api_summary); exit(10);	// test
		return true;
		} // init_session()

	protected static function save_session() {
		if((!empty(self::$client_session)) &&
			(!self::save_json(self::$client_session_file, self::$client_session))) {
			self::log_msg('Failed to save: "' . self::$client_session_file . '" session.', 'err');
			} // if
		if((!empty(self::$api_summary)) &&
			(!self::save_json(self::$api_summary_file, self::$api_summary))) {
			self::log_msg('Failed to save: "' . self::$api_summary_file . '" summary.', 'err');
			} // if
		return true;
		} // save_session()

	public static function load_json($sorc, $do_incs = false) {
		// read a keyed csv
		if ((!empty($sorc)) &&
			(file_exists($sorc)) &&
			(($json = @file_get_contents($sorc)) !== false)) {
			$data_ary = json_decode($json, true);
			if (is_null($data_ary)) {
				$err = json_last_error();
				$err_msg = json_last_error_msg();
				self::log_msg('Error in "' . $sorc . '" JSON: "' . $err_msg . '"','err');
				return false;
				} // if
			return $data_ary;
			} // if
		return false;
		} // load_json()

	public static function save_json($dest, &$data_ary_obj) {
		if (empty($dest))
			return false;
		if(is_object($data_ary_obj)) $data_ary = get_object_vars($data_ary_obj);	// loose ref
		else $data_ary = $data_ary_obj;
		if ((!is_writable($dest)) && (!is_writable(dirname($dest)))) {
			self::log_msg('JSON destination "' . $dest . '" not writeable.','err');
			return false;
			} // if
		if (!is_array($data_ary)) {
			self::log_msg('Data not an array: "' . print_r($data_ary) . '".','err');
			return false;
			} // if
		foreach($data_ary as $k => &$v) {	// filter sys keys
			if(preg_match('/^_/',$k)) unset($data_ary[$k]);
			} // foreach
		$data_ary['_ModTime'] = date('Ymd-His');
		$json = json_encode($data_ary, (JSON_PRETTY_PRINT));
		if (file_put_contents($dest, $json) === false) {
			self::log_msg('Failed to save JSON "' . $dest . '".','err');
			return false;
			} // if
		// else ok
		return true;
		} // save_json()

	// dynamic methods

} // Capi_session

// eof

