<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_client.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of API client
 *
 * @author robert0609
 */

require_once 'api_funcs.php';

class Capi_client extends Capi_funcs {

	protected $use_curl = true;
	protected $timeout_mS = false;
	protected $new_url = false;
	protected $dest_url = false;
	protected $port = false;

	protected static $results_dir = false;

	const API_CALL_TIMEOUT_MS = (5 * 1000);

	function __construct($dest_url,$port = false, $timeout_mS = 0, $token = false) {
		global $argc, $argv;
		parent::__construct();
		if(!self::do_warnings()) return;
		$this->dest_url = $dest_url;
		$this->port = $port;
		if(empty($timeout_mS)) $timeout_mS = self::API_CALL_TIMEOUT_MS;
		$this->timeout_mS = $timeout_mS;
		if($token) self::$client_session[self::API_TOK_KEY] = $token;
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods

	// dynamic methods
	public function get_token() {
		return (!empty(self::$client_session[self::API_TOK_KEY]) ? self::$client_session[self::API_TOK_KEY]:false);
		} // get_token()

	public function get_jwt() {
		return (!empty(self::$client_session[self::API_JWT_KEY]) ? self::$client_session[self::API_JWT_KEY]:false);
		} // get_jwt()

	protected function decode_response_header($res_header = false) {
		if((empty($res_header)) && (!empty($http_response_header)))
			$res_header = $http_response_header;

		$this->response_header = array();	// getallheaders() will only work on apache
		if(!empty($res_header)) {
			$res_lines = explode(PHP_EOL,$res_header);
			foreach($res_lines as $l) {
				$h = @explode(':',$l);
				if(empty($h[1])) continue;
				$this->response_header[(trim($h[0]))] = trim($h[1]);
				} // foreach
			$sid = false; $sid_name = false; $sid_expires = false;
			if(!empty($this->response_header[self::API_JWT_KEY])) {	// get the JWT
				$sid = $this->response_header[self::API_JWT_KEY];
				$sid_name = self::API_JWT_KEY;
				$payload = $this->get_jwt_payload($sid);
				if(!empty($payload['exp'])) {
					$sid_expires = date(DateTime::ISO8601,$payload['exp']);
					} // if
				else $sid_expires = false;		// ??
				} // if
			else if(!empty($this->response_header['Set-Cookie'])) {	// get the SID, etc from session cookie
				// e.g. [Set-Cookie] => AppsCMSid_=kq2iq1890aa32orlqnctvaq35e; expires=Tue, 24-Aug-2021 14
				$cky = $this->response_header['Set-Cookie'];
				$sid = preg_replace('/^.*=([0-9a-zA-Z]{20,});.*$/','$1',$cky);
				$sid_name = preg_replace('/^([0-9a-zA-Z_]+)=.*$/','$1',$cky);
				$sid_expires = preg_replace('/^.*expires=[a-z]{3}, (.*)$/i','$1',$cky);
				} // if
			else {
				if(!empty($this->response_header[self::API_TOK_KEY]))	// get the SID, etc
					$sid = $this->response_header[self::API_TOK_KEY];
				if(!empty($this->response_header['Expires']))
					$sid_expires = $this->response_header['Expires'];
				$sid_name = 'APIclient_';
				} // else
			if(!empty($sid)) self::$client_session[self::API_TOK_KEY] = $sid;
			if(!empty($sid_name)) self::$client_session['token_name'] = $sid_name;
			if(!empty($sid_expires)) {
				if(!is_numeric($sid_expires))
					$sid_expires = @strtotime($sid_expires);
				self::$client_session['token_expires'] = $sid_expires;
				} // if
			} // if
		return $this->response_header;
		} // decode_response_header()

	protected function decode_result_data(&$enc_result) {
		// echo 'ENC_RESULT: ' . print_r($enc_result, true) . PHP_EOL;	// test
		if(empty($enc_result)) return false;
		$result = array();
		if(!empty($this->response_header['Content-Type'])) {
			list($typ,) = explode(';',$this->response_header['Content-Type']);	// may have charset, etc.
			switch(strtolower($typ)) {
			case 'application/json':
				$result = json_decode($enc_result,true);
				break;
			case 'application/xml':
				$result = xmlrpc_decode($enc_result, CMS_S_CHAR_SET);
				break;
			case 'application/x-www-form-urlencoded':
				$result = urldecode($enc_result);
				break;
			case 'text/plain':
				$result = $enc_result;	// just text
				break;
			case 'text/html':
				$result = rawurldecode($enc_result);	// maybe
				break;
			default:
				$result = $enc_result;	// don't decode
				break;
				} // switch
			} // if
		else $result = $enc_result; // ??
		if(!empty($result[self::API_JWT_KEY])) {	// get the JWT
			$jwt = $result[self::API_JWT_KEY];
			$payload = $this->get_jwt_payload($jwt);
			if(!empty($payload['exp'])) {
				$expires = date(DateTime::ISO8601,$payload['exp']);
				} // if
			else $expires = false;		// ??
			self::$client_session[self::API_JWT_KEY] = $jwt;
			self::$client_session[self::API_JWT_KEY . '_payload'] = $payload;
			self::$client_session[self::API_JWT_KEY . '_expires'] = $expires;
			unset($result[self::API_JWT_KEY]);	// saved
			} // if
		// echo 'RESULT: ' . print_r($result, true) . PHP_EOL;	// test
		return $result;
		} // decode_result_data()

	public function send_curl($method, $request_uri, $data = false){
		$ch = curl_init();
		if(preg_match('/^http:\/\/.+/i', $this->dest_url)) {
			curl_setopt($ch, CURLPROTO_HTTP, true);
			} // if
		else if(preg_match('/^https:\/\/.+/i',$this->dest_url)) {
			curl_setopt($ch, CURLPROTO_HTTPS, true);
			} // else if
		else {
			curl_close($ch);	// don't run out of memory with orphans
			self::log_msg('URL: "' . $this->dest_url . '" unknown protocol.','error');
			return false;	// what ???
			} // else

		// add request uri
		$url = self::clean_path($this->dest_url .
			($this->use_rewrite ? self::API_BASE_URI:self::API_CODE_URI) . $request_uri);

		switch (strtoupper($method)){
		case "POST":
			curl_setopt($ch, CURLOPT_POST, 1);
			if ((!empty($data)) && (is_array($data))) {
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
				} // if
			else {
				curl_close($ch);	// don't run out of memory with orphans
				self::log_msg('POST: No data to post.','err');
				return false;
				} // else
			break;
		case "PUT":
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
			if ((!empty($data)) && (is_array($data))) {
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
				} // if
			else {
				curl_close($ch);	// don't run out of memory with orphans
				self::log_msg('PUT: No data to put.','err');
				return false;
				} // else
			break;
		case "GET":
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
			break;
		default:	// DELETE, etc.
			curl_close($ch);	// don't run out of memory with orphans
			return false;
			break;
			} // switch
		// OPTIONS:
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //false will prevent curl from verifying the SSL certificate

		$request_header = array('Content-Type: application/json',);
		if(!empty(self::$client_session[self::API_JWT_KEY])) {
			$request_header[] = self::API_JWT_KEY . ': ' . self::$client_session[self::API_JWT_KEY];
			} // if
		else if(!empty(self::$client_session[self::API_TOK_KEY])) {
			$request_header[] = self::API_TOK_KEY . ': ' . self::$client_session[self::API_TOK_KEY];
			if(!empty(self::$client_session['token_name'])) {
				$request_header[] = 'Cookie' . ': ' . self::$client_session['token_name'] . '=' . self::$client_session[self::API_TOK_KEY];
				} // if
			} // if
		curl_setopt($ch, CURLOPT_HTTPHEADER, $request_header);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLINFO_HEADER_OUT, 1);	//enable request headers
		curl_setopt($ch, CURLOPT_HEADER, 1);		//enable response headers
		if($this->timeout_mS) {
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_mS);
			curl_setopt($ch, CURLOPT_TIMEOUT_MS, ($this->timeout_mS));
			} // if
		if((int) $this->port > 10) curl_setopt ($ch, CURLOPT_PORT, (int) $this->port);

		// EXECUTE:
		$res_header_result = curl_exec($ch);	// response header and result
		if(curl_errno($ch)) {
			self::log_msg('Curl: "' . curl_error($ch) . '".','err');
			} // if
		$res_header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$req_header = curl_getinfo($ch, CURLINFO_HEADER_OUT ); // request headers
		$this->response_info = curl_getinfo($ch);
		curl_close($ch);

		$this->request_header = $req_header; // used request headers

		$enc_result = substr($res_header_result, $res_header_size);
		$res_header = substr($res_header_result, 0, $res_header_size);
		$this->decode_response_header($res_header);

		$this->result = $this->decode_result_data($enc_result);

		// work on it (a test than normal to test code)
		// self::log_msg($this->result);
		if($this->result === false) {
			self::log_msg('URL: "' . $url . '" failed to respond.');
			return false;
			} // if
		if(!empty($this->response_info['http_code'])) {
			$this->response_header['http_code'] = $this->response_info['http_code'];
			$this->new_url = $this->response_info['url'];
			if(200 == $this->response_info['http_code']) {	// ok
				self::log_msg('URL: "' . $url . '" ok response.','success');
				} // if
			else if(301 == $this->response_info['http_code']) {	// ok
				self::log_msg('URL: "' . $url . '" redirect response "' . $this->response_info['http_code'] . '" to "' . $this->new_url . '".','warning');
				} // else if
			else if(302 == $this->response_info['http_code']) {	// ok
				self::log_msg('URL: "' . $url . '" redirect response "' . $this->response_info['http_code'] . '" to "' . $this->new_url . '".','warning');
				} // else if
			else {	// ??
				self::log_msg('URL: "' . $url . '" response "' . $this->response_info['http_code'] . '".','info');
				} // else
			} // if
		return $this->result;
		} // send_curl()

	public function send_request($method,$request_uri,$data = false) {
		if($this->use_curl) return $this->send_curl($method,$request_uri,$data);
		$con_opts = array(
			'ssl'=> array(
				'verify_peer' => true,
				'allow_self_signed' => true,
				),
			);
		if(($data) && (is_array($data))) {
			$con_opts['http'] = array(
				'method'  => 'POST',
				'header'  => 'Content-Type: application/x-www-form-urlencoded',
				'content' => http_build_query($data),
				);
			} // if
		$url = $this->dest_url . ($this->use_rewrite ? self::API_BASE_URI:self::API_CODE_URI) . $request_uri;
		self::log_msg('URI: "' . $url . '".','info');
		$streamContext = stream_context_create($con_opts);
		$res = @file_get_contents($url,false,$streamContext);
		$this->decode_response_header();
		// $this->result = json_decode($res,true);
		$this->result = $this->decode_result_data($res);
		// self::log_msg($this->result);
		return $this->result;
		} // send_request()

	public function save_results($results) {
		self::$results_dir = VAR_RESULTS_DIR;
		if(!is_dir(self::$results_dir)) mkdir(self::$results_dir,0777,true);

		$results_file = self::$results_dir . 'Results-' . date('Ymd-His');
		if(is_array($results)) {
			$results_file .= '.json';
			if(!self::save_json($results_file, $results)) return false;
			} // if
		else if(!empty($results)) {
			$results_file .= '.txt';
			if(!file_put_contents($results_file,$results)) {
				self::log_msg('Failed to save results "' . $results_file . '".','err');
				return false;
				} // if
			} // else if
		else {
			self::log_msg('Failed to retrieve results.','err');
			return false;
			} // else
		return $results_file;
		} // save_results()

	public function get_info($all = false) {
		$text = '';
		if($all) {
			$text .= PHP_EOL . "Request Header: " . print_r($this->request_header,true) . PHP_EOL;
			$text .= PHP_EOL . 'Response Info: : ' . print_r($this->response_info,true) . PHP_EOL;
			} // if
		$text .= PHP_EOL . "Response Header: " . print_r($this->response_header,true) . PHP_EOL;
		$text .= PHP_EOL . 'Result: ' . print_r($this->result,true) . PHP_EOL;
		$text .= PHP_EOL;
		return $text;
		} // get_info()

} // Capi_client

// eof

