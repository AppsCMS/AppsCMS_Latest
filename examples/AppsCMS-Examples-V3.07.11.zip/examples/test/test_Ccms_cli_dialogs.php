<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: test_Ccms_cli_dialogs.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/*
 * script file is provided for testing code and it is intended be copied and changed as required.
 */
error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$box_backtitle = 'Top of screen text.';	// show at the top of the screen

$msg = "This is a message\nSecond line\nThird line.";

Ccms_cli_dialogs_plugin::box_msg('Help', $box_backtitle, $msg, 64);

$dir = './';	//$_SERVER['HOME'];	// CLI on Linux
$vals = Ccms_cli_dialogs_plugin::box_file_select('Select a file (space bar to select)',$box_backtitle,$dir, 64);
print_r($vals); // test
echo PHP_EOL;

exit(0);	// test

$menu = array(
	'title' => 'Test Menu',
	'items' => array(
		'A' => 'A is for Apple',
		'Z' => 'Is for Zulu',
		'T' => 'For Timezone',
		'1' => 'Select one.',
		),
	);

$selected = Ccms_cli_dialogs_plugin::box_menu('A Menu', $box_backtitle, $menu);
print_r($selected); // test
 // exit(0);	// test

$vals = Ccms_cli_dialogs_plugin::box_simple_form('Enter details', $box_backtitle,
	array(
		'title' => 'My Simple Form',	// the form title
		'height' => 9,
		'width' => 30,
		'formheight' => 0,	// typically 0 to default to 'height'
		'elements' => array(
			array(
				'label' => 'Who',	// the label of the input
				'value_x' => 10,	// optional
				'flen' => 15,	// the input field length, optional if the field is the display length
				),
			array(
				'label' => 'Age',	// the label of the input
				'value_x' => 8,	// optional
				'flen' => 15,	// the input field length, optional if the field is the display length
				),
			array(
				'label' => 'Dance',
				'value_x' => 8,	// optional
				'flen' => 15,	// the input field length, optional if the field is the display length
				),
			),
		)
	);
print_r($vals); // test
//exit(0);	// test

$vals = Ccms_cli_dialogs_plugin::box_username_password('Login for something', $box_backtitle,true);
print_r($vals); // test

$vals = Ccms_cli_dialogs_plugin::box_calendar('Calendar', $box_backtitle,'Enter yesterday.');
print_r($vals); // test

$vals = Ccms_cli_dialogs_plugin::box_time('Time', $box_backtitle,'Enter time of ...');
print_r($vals); // test






exit(0);

