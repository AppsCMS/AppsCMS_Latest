#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: test_find_replace_static_code.sh 2786 2022-08-31 05:40:44Z robert0609 $

# set -x

OUTD="tmp"
if [ ! -d "OUTD" }; then mkdir -p "$OUTD"; fi
F="${OUTD}/test_str.txt"	# test code
LOG="${OUTD}/test_str.txt.log"
REPLACE=1

TEST_STR="
test strings for test.sh

if(self::\$is_debug)
if (self::\$is_debug)
self::\$is_debug=false;
self::\$is_debug = true;

class::\$is_debug = true;
class::\$is_debug

last bit

// comment

"

function find_replace_static_code() { # $1=file $2=find $3=replacement
	local F="$1"
	local FND="$2"
	local REP="$3"
	local PRE='::'	# only for class::FND or self::FND
	local DT="$(date '+%Y%m%d-%H%M%S')"
	local PAT="${PRE}\$${FND}"
	# echo "PAT=$PAT"	# test
	local FOUND="$(grep -nH "$PAT" "$F" 2> /dev/null)"
	if [ -z "$FOUND" ]; then
		echo "\"${PRE}\$${FND}\" not found in \"$F\" ($DT)." | tee -a "$LOG"
		return 1
	fi

	if [ $REPLACE -eq 0 ]; then
		echo "Found \"${PRE}\$$FND\" to be replaced with \"${PRE}${REP}()\" in \"$F\"." | tee -a "$LOG"
		return 0
	fi

	echo "Starting Code Update from \"${PRE}\$$FND\" to \"${PRE}${REP}()\" in \"$F\" ($DT)." | tee -a "$LOG"

	# replace base
	local SED="s/${PRE}\\\$${FND}/${PRE}${REP}()/mg"
	echo "SED=$SED"	# test
	echo -e "Replace: \"${PRE}\$${FND}\" with \"${PRE}${REP}()\"." | tee -a "$LOG"

	sed -i -E "$SED" "$F"	# do it
	grep -nH "${PRE}${REP}" "$F" | tee -a "$LOG"	# show it
	# cat "$F"	# test

	# move variable
	local SEDV="s/${PRE}${REP}[\(\)]+\s*=\s*(.*);/${PRE}${REP}(\\1);/mg"
	echo "SEDV=$SEDV"	# test
	echo -e "Move variables: \"${PRE}${REP}() = var;\" to \"${PRE}${REP}(var);\"." | tee -a "$LOG"
	sed -i -E "$SEDV" "$F"	# do it
	grep -nH "${PRE}${REP}" "$F" | tee -a "$LOG"	# show it
	# cat "$F"	# test

	DT="$(date '+%Y%m%d-%H%M%S')"
	echo "Finished Code Update from \"${PRE}\$$FND\" to \"${PRE}${REP}([var])\" in \"$F\" ($DT)." | tee -a "$LOG"
	echo "" | tee -a "$LOG"	# new line

	return 0
} # find_replace_static_code()

FND="is_debug"	# find
REP="is_debug"	#_new"	# replacement
echo "F=$F"

echo "$TEST_STR" > "$F"	# output start file
find_replace_static_code "$F" "$FND" "$REP"

echo "F=$F"
cat "$F"

echo "LOG=$LOG"
cat "$LOG"

# EOF
