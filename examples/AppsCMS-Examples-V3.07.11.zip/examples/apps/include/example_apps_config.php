<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_apps_config.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

// example of /apps/include/apps_config.php
// Refer to manual for more information.

define('APP1_VERSION', 'V1.0');
define('APP2_VERSION', 'V1.0');

// example applications locations
define('APP1_BASEDIR', APPS_FS_DIR . 'example_app1/');	// filesystem local of example_aap1
define('APP2_BASEDIR', APPS_FS_DIR . 'example_app2/');	// filesystem local of example_aap2



