<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_jwt.php 3394 2023-07-25 00:25:01Z robert0609 $
 */

/**
 * Description of Capi_jwt
 *
 * Use decode payload of JWT, etc
 *
 * @author robert0609
 */

require_once 'api_session.php';

class Capi_jwt extends Capi_session {	// JWT class

	protected static $jwt_decoded = false;
	protected $jwt_payload = false;

	const JWT_LOG_PRE = 'JWT: ';

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_use_jwt_ok() {	// check if JWT ok
		return true;
		} // is_use_jwt_ok()

	protected static function addKWTmsg($msg, $type = 'error') {
		// $log = self::JWT_LOG_PRE . $msg;
		self::log_msg($msg, $type);
		} // addKWTmsg()

	protected static function safe_b64_decode($b64) {
		$remainder = strlen($b64) % 4;
		if ($remainder) {
			$padlen = 4 - $remainder;
			$b64 .= str_repeat('=', $padlen);
			} // if
		return base64_decode(strtr($b64, '-_', '+/'));
		} // safe_b64_decode()

	protected static function extract_sections(&$jwt) {
		if(!empty(self::$jwt_decoded)) return true;	// do once
		$tks = explode('.', $jwt);
		if (count($tks) != 3) {
			self::addKWTmsg('Wrong number of segments');
			return false;
			} // if
		$jwtd = &self::$jwt_decoded;	// a ref
		$jwtd = array();
		list($jwtd['headb64'], $jwtd['payload64'], $jwtd['cryptob64']) = $tks;
		if(null === ($jwtd['header'] = json_decode(self::safe_b64_decode($jwtd['headb64']),true))) {
			self::addKWTmsg('Invalid header encoding');
			return false;
			} //if
		if(null === ($jwtd['payload'] = json_decode(self::safe_b64_decode($jwtd['payload64']),true))) {
			self::addKWTmsg('Invalid payload encoding');
			return false;
			} //if
		if (false === ($jwtd['sig'] = self::safe_b64_decode($jwtd['cryptob64']))) {
			self::addKWTmsg('Invalid signature encoding');
			return false;
			} //if
		return true;
		} // extract_sections()

	// dynamic methods
	public function &get_jwt_payload(&$jwt) {	//
		if(!self::is_use_jwt_ok()) return false;
		if(!self::extract_sections($jwt)) return false;
		if(self::$jwt_decoded)
			return false;

		$jwtd = &self::$jwt_decoded;	// a ref
		$payload = &$jwtd['payload'];

		// assume payload clean
		$timestamp = time();
		if (isset($payload['nbf']) && $payload['nbf'] > $timestamp) {
			self::addKWTmsg('Cannot handle token prior to ' . date(DateTime::ISO8601, $payload['nbf']));
			} // if
		if (isset($payload['iat']) && $payload['iat'] > $timestamp) {
			self::addKWTmsg('Cannot handle token prior to ' . date(DateTime::ISO8601, $payload['iat']));
			} // if
		if (isset($payload['exp']) && $timestamp >= $payload['exp']) {
			self::addKWTmsg('Expired token');
			} // if
		$this->jwt_payload = (array) $payload;	// force it to associative array
		return $this->jwt_payload;
		} // get_jwt_payload()

} // Capi_jwt

