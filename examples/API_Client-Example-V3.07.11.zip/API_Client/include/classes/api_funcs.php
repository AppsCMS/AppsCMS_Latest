<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_funcs.php 3394 2023-07-25 00:25:01Z robert0609 $
 */

/**
 * Description of API client functions
 *
 * @author robert0609
 */

require_once 'api_general.php';

class Capi_funcs extends Capi_general {

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods

	// dynamic methods

	public function get_summary() {
		$request_uri = '/summary';	// basic uri
		$result = $this->send_request('GET',$request_uri);
		if((!empty($result)) && (is_array($result))) self::$api_summary = $result;
		else self::$api_summary = false;
		return self::$api_summary;
		} // get_summary()

	protected function make_API_param_type(&$c_param,&$param) {
		$val = $param;	// because its a ref
		if(!isset($c_param['type'])) return $val;
		switch(strtolower($c_param['type'])) {
		case 'integer':	// workaround for swagger bug
		case 'int':
		case 'int32':	// ??
		case 'int64':	// swagger compatibility
			$val = sprintf('%d',(int)$param);	// a string representation (with rounding)
			break;
		case 'float':
			$val = sprintf('%f',$param);	// a string representation (e.g. 1.25e-2)
			break;
		case 'number':	// usually returns as text
			if(!is_numeric($param)) $val = 0;
			else $val = sprintf('%s',$param);	// int or float (best guess)
			break;
		case 'string':
			$val = sprintf('%s',$param);	// string
			break;
		default:
			$val = $param;
			break;
			} // switch
		return $val;
		} // make_API_param_type()

	public function call_api_function($path,$meth,$cntl,$param_vals) {	// ,$post_data is in the parameters to there 'in' setting
		if($path == '/summary') return $this->get_summary();	// special case
		$form_data = array();
		$request_uri = $path;
		if((!empty($param_vals)) && (!empty($cntl['parameters'])) && (count($cntl['parameters']) > 0)) {
			$query = '';
			$p_idx = 0;
			foreach($cntl['parameters'] as $c_param) {
				if(!empty($param_vals[($c_param['name'])])) {
					$param = $param_vals[($c_param['name'])];
					$p_idx++;
					} // if
				else if(!empty($param_vals[$p_idx]))
					$param = $param_vals[$p_idx++];
				else {
					if(!empty($c_param['required'])) {
						$this->log_msg('Missing parameter ' . $c_param['name'] . ' for path: ' . $path);
						} // if
					$p_idx++;	// sync
					continue;
					} // else
				$param = $this->make_API_param_type($c_param, $param);
				if((!empty($c_param['in'])) && ($c_param['in'] == 'path') &&
					(preg_match('/\{' . $c_param['name'] . '\}/',$request_uri))) {
					$request_uri = preg_replace('/\{' . $c_param['name'] . '\}/',$param,$request_uri);
					continue;
					} // if
				else if((empty($c_param['in'])) || ($c_param['in'] == 'query')) {
					// assume it's a URL query
					if(empty($query)) $query .= '?';
					else $query .= '&';
					if(isset($c_param['name'])) $query .= $c_param['name'] . '=';
					$query .= urlencode($param);
					} // if
				else if($c_param['in'] == 'body') {
					if(isset($c_param['name']))
						$form_data[($c_param['name'])] = $param;
					else $this->log_msg('Missing formData name for: ' . $path);
					} // else
				else if($c_param['in'] == 'formData') {
					if(isset($c_param['name']))
						$form_data[($c_param['name'])] = $param;
					else $this->log_msg('Missing formData name for: ' . $path);
					} // else
				else if($c_param['in'] == 'path') {
					$request_uri .= '/' . urlencode($param);
					} // else
				} // foreach
			$request_uri .= $query;
			} // if
		// echo PHP_EOL . 'REQ URI: ' . print_r($request_uri,true) . PHP_EOL;	// test
		return $this->send_request($meth,$request_uri,$form_data);
		} // call_api_function()

} // Capi_funcs

// eof

