<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_english2chinese.php 2947 2022-11-04 03:27:27Z robert0609 $
 */


error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure

// $cd = preg_replace('/\\/','/',__DIR__);
// $cms_docroot = preg_replace('/\/(examples\/apps|apps|cms).*$/','',$cd);	// test
$cms_docroot = dirname(dirname(__DIR__));		// windows compatibility
require_once ( $cms_docroot . '/cms/cms_init.php' );

echo 'Translate English to Chinese on ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.' . PHP_EOL;

if(!empty($argv[1])) $english =  array_slice($argv,1);
else $english = array(	// some sample text
	'Hello world, this is the translator example for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.',
	'This is a test of English to Chinese translation.',
	'The shy tabby cat hides from the moon at sunrise.',
	"It's ok to be me.",
	);

if(!Ccms_language::init('Chinese')) {
	echo 'ERROR: failed to initialise translation.' . PHP_EOL;
	exit(1);
	} // if
$chinese = Ccms_language::translate_text($english);
if(empty($chinese)) {
	echo 'ERROR: falied to translate.';
	exit(2);
	} //if
echo PHP_EOL;
echo 'English:' . PHP_EOL . implode(PHP_EOL,$english) . PHP_EOL . PHP_EOL;
echo 'Chinese:' . PHP_EOL . implode(PHP_EOL,$chinese) . PHP_EOL . PHP_EOL;

exit(0);

// eof
