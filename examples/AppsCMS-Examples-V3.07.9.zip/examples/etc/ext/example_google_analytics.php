<?php // $Id: example_google_analytics.php 2865 2022-10-15 01:36:45Z robert0609 $ 
	// typical Google analytics include file
	// the Google analytics site provides "google_tracker_id" for this web site from its Google analytics account
	$google_measurement_id = 'measurement-id';	// from the google analytics account
?>
        <!--start from Google Analytics for <?= CMS_C_CO_NAME . '(' . CMS_C_TITLE . ')' ?> -->
		<!-- Google tag (gtag.js) -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=<?= $google_measurement_id ?>"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', '<?= $google_measurement_id ?>');
		</script>
		<!--end from Google Analytics for <?= CMS_C_CO_NAME . '(' . CMS_C_TITLE . ')' ?> -->
