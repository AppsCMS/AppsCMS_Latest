<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: example_app1.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of Cexample_app1
 *
 * the auto class loader finds me in apps/include/classes/ directory
 *
 * @author robert0609
 */

class Cexample_app1 extends Ccms_app_base {

	protected static $my_ini_ctls = array();
	protected static $my_api_summary = array();
	protected static $my_head = array();

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// AppsCMS optional methods, see "index.php?cms_action=cms_manual#AppClass"
	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		return '';	// default empty return
		} // get_ajax_text()

	public static function get_ws_text($wsid,$op) {	// required function, Executes the applications WebSockets code.
		return '';	// default emtpy return
		} // get_ws_text()

	public static function do_app_warnings($bld = false) {
		return true;	// return ok
		} // do_app_warnings()

	public static function is_app_setup_key_funcs_used($key) {
		return false;	// default return (not used)
		} // is_app_setup_key_funcs_used()

	public static function show_app_setup_value($sect,$key,$name,$value) {
		return false;	// default return (not used)
		} // show_app_setup_value()

	public static function input_app_setup_form_text($sect,$key,$name,$value) {
		return false;	// default return (not used)
		} // input_app_setup_form_text()

	public static function get_app_setup_form_value($sect,$key,$name,$value) {
		return null;	// default return (not used)
		} // get_app_setup_form_value()

	public static function &get_ini_app_input_ctl() {
		return self::$my_ini_ctls;	// default return (empty)
		} // get_ini_app_input_ctl()

	public static function &get_api_map_summary() {
		return self::$my_api_summary;	// default return (empty)
		} // get_api_map_summary()

	public static function &get_head_text() {
		return self::$my_head;	// default return (empty)
		} // get_head_text()

// static methods

	public static function where_am_I() {
		return 'In Cexample_app1 class.';
		} // where_am_I()

// dynamic methods
	public function who_am_I() {
		echo 'I am the Cexample_app1 class.';
		} // who_am_I()

} // Cexample_app1


