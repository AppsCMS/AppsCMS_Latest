Applications Management System Library for PHP (AppsCMS) - Example README_apps_libs.
=======================================================================
see Licence in cms/LICENCE.txt
<!-- _SVN_build: $Id: example_README_apps_libs.md 2786 2022-08-31 05:40:44Z robert0609 $ -->

3rd Party Libraries used by Applications.
-----------------------------------------

"apps/lib/" is a convienient directory to place the 3rd party libraries used by the applications.


.EOF.
