<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_client.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

require_once 'include/api_config.php';	// do the configs
require_once 'include/classes/api_client.php';
require_once 'include/classes/api_menus.php';

echo PHP_EOL . 'Run API Call: start,' . PHP_EOL;
$menus = new Capi_menus();
$dest_url = false;
$path = false;
$init_vals = array(	// initial reuse/save time values
	'username' => 'tester',
	'password' => 'tester',
	'table' => 'lm_sections',
	'format' => 'csv',
	'meth_path' => 'GET:/cmsDB/export/{table}/{format}'
	);
$use_init_vals = false;	// else put up dialog
$result = $menus->run_API_call($dest_url,$path,$init_vals,$use_init_vals);
// print_r($result);	// test
echo PHP_EOL . 'Run API Call: end.' . PHP_EOL;
echo PHP_EOL;

exit(0);

// eof

