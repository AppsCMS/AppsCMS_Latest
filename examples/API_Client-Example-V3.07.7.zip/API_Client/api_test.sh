#!/bin/bash
# see Licence in cms/LICENCE.txt
# _SVN_build: $Id: api_test.sh 3052 2022-12-16 09:01:07Z robert0609 $
# AppsCMS API Client
API_CLIENT="$(dirname "$0")/api_client.php"

# export XDEBUG_CONFIG="idekey=netbeans-xdebug"

if [ -f "cms/examples/API_Client/${API_CLIENT}" ]; then
	php "cms/examples/API_Client/${API_CLIENT}" "$@"
elif [ -f "$API_CLIENT" ]; then
	php "$API_CLIENT" "$@"
else
	echo -e "ERROR: cannot find \"$API_CLIENT\"."
	exit 1;
fi

exit 0

# EOF
