<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_logs.php 3321 2023-04-11 23:58:24Z robert0609 $
 */

/**
 * Description of API client logs
 *
 * @author robert0609
 */

class Capi_logs {

	const CLI_SH_BOLD = "\033[1m";
	const CLI_SH_NORM = "\033[0m";

	const CLI_SH_RED = "\033[1;31m";
	const CLI_SH_GREEN = "\033[1;32m";
	const CLI_SH_YELLOW = "\033[1;33m";
	const CLI_SH_PURPLE = "\033[1;35m";
	const CLI_SH_BLUE = "\033[1;34m";	// now light blue
	const CLI_SH_WHITE = "\033[1;39m";
	const CLI_SH_DEFCOL = "\033[0m";

	protected static $log_dir = false;
	protected static $token = false;

	function __construct() {
		self::init();
		} // __construct()

	function __destruct() {
		} // __destruct()

	// static methods
	private static function init() {
		self::$log_dir = VAR_LOGS_DIR;
		if(!is_dir(self::$log_dir)) mkdir(self::$log_dir,0777,true);
		} // init()

	public static function is_cli() {	// for compatibility
		return true;
		} // is_cli()

	public static function log2file($log_msg) {
		self::init();
		$prefix = date('c: ');
		error_log($prefix . $log_msg,3,self::$log_dir . LOG_FILE);
		} // log2file()

	public static function log_msg($result,$status = 'err') {	// slow on big data
		if(empty($result)) return false;
		$msg = false;
		if(is_array($result)) {
			if(!empty($result['result']['message'])) $msg = $result['result']['message'];
			if(!empty($result['result']['status'])) $status = $result['result']['status'];
			} // if
		else $msg = $result;
		// echo "Status :" . $status . ", Msg: " . $msg . PHP_EOL;

		$cli_pre = '';
		$cli_suf = '';
		$pre = strtoupper($status) . ':';
		$ok = false;

		switch(strtolower($status)) {
		case 'required':
		case 'require':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_PURPLE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'REQUIRED:';
			break;
		case 'warning':
		case 'warn':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_PURPLE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'WARNING:';
			break;
		case 'ok':
		case 'tick':
		case 'success':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_GREEN;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'SUCCESS:';
			if(!empty($result['result'][Capi_client::API_JWT_KEY])) self::$token = $result['result'][Capi_client::API_JWT_KEY];
			if(!empty($result['result'][Capi_client::API_TOK_KEY])) self::$token = $result['result'][Capi_client::API_TOK_KEY];
			$ok = true;
			break;
		case 'info':
		case 'information':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_BLUE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'INFO:';
			break;
		case 'working':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_WHITE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			break;
		case 'debug':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_PURPLE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			break;
		case 'wrong':
		case 'cross':
		case 'error':
		case 'err':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_RED;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'ERROR:';
			break;
		default:
			break;
			} // switch

		echo $cli_pre . $pre . $cli_suf . ' ' . $msg . PHP_EOL;
		self::log2file($pre . ' ' . $msg . PHP_EOL);
		return $ok;
		} // log_msg()

	// dynamic methods

} // Capi_logs

// eof

