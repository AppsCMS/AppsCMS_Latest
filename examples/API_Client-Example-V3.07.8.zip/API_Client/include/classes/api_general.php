<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: api_general.php 3394 2023-07-25 00:25:01Z robert0609 $
 */

/**
 * Description of API client functions
 *
 * @author robert0609
 */

require_once 'api_jwt.php';

class Capi_general extends Capi_jwt {

	protected $use_rewrite = true;	// e.g. "/api/summary" calls (similiar to swagger)
	protected static $methods_used = array('get','put','post');	// match methods in summary

	// API URI signals.
	const API_BASE_URI = 'api/';	// the virtual folders version
	const API_CODE_URI = 'api.php/';	// the code version

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods
	public static function clean_path($path) { // the file path
		$text = preg_replace('/([^:])[\/]{2,}/', '$1/', $path);
		return $text;
		} // clean_path()

	public static function do_warnings() {
		$ok = true;

		$func_class_chk_list = array(
			array(
				'func' => 'mb_strlen',
				'needs' => 'php-mbstring',
				),
			array(
				'func' =>'json_decode',
				'needs' => 'php-json',
				),
//			array(
//				'func' =>'posix_getgrgid',
//				'needs' => 'php-posix or php-process',
//				'type' => 'warn',	// default is 'error', are the same as log_msg() uses
//				),
			array(
				'func' => 'curl_init',
				'needs' => 'php curl',
				// 'type' => 'warn',	// default is 'error', are the same as log_msg() uses
				),
			array(
				'cli' => 'dialog',	// complete test command (empty = fail)
				'needs' => 'System package: dialog. Not installed, required for CLI diaplog boxes.',
				// 'type' => 'warn',	// default is 'error', are the same as log_msg() uses
				),
//			array(
//				'func' => 'ncurses_init',	// not reliable
//				'needs' => 'PECL nurses or System pkg php-pecl-ncurse',	// not reliable
//				),
			);
		$ok &= self::do_install_warnings_func_chks($func_class_chk_list);

		$ok &= Ccms_language::is_ok();

		if($ok) self::log_msg('No install issues detected.','info');
		return $ok;
		} // do_warnings()

	public static function do_install_warnings_func_chks($func_class_chk_list) {
		$ok = true;
		foreach($func_class_chk_list as $f) {
			$type = 'error';
			if((!empty($f['type']))) $type = $f['type'];
			if($type != 'error') $install_msg = ' install recommended.';
			else $install_msg = ' to be installed.';
			if((isset($f['func'])) &&
				(!function_exists($f['func']))) {
				if(empty($f['msg']))
					self::log_msg('System Function: ' . $f['func'] . '() not installed. Needs ' . $f['needs'] . $install_msg,$type);
				else self::log_msg('System Function: ' . $f['func'] . '() not installed. ' . $f['msg'] . '',$type);
				if($type == 'error') $ok = false;
				} // if
			else if((isset($f['class'])) &&
				(!class_exists($f['class'],false))) {
				if(empty($f['msg']))
					self::log_msg('System Class: ' . $f['class'] . ' not installed. Needs ' . $f['needs'] . $install_msg,$type);
				else self::log_msg('System Class: ' . $f['class'] . '() not installed. ' . $f['msg'] . '',$type);
				if($type == 'error') $ok = false;
				} // if
			else if(isset($f['cli'])) {
				if(preg_match('/^windows .*/i', php_uname())) continue;	// no not on windows
				$result = '';
				$output = '';
				exec('which ' . $f['cli'], $output, $result);
				if($result) {
					if(empty($f['msg']))
						self::log_msg('System command not installed: Needs ' . $f['needs'] . '.',$type);
					else self::log_msg('System command not installed: ' . $f['needs'] . '. ' . $f['msg'] . '',$type);
					if($type == 'error') $ok = false;
					} // if
				} // if
			} // foreach
		return $ok;
    } // do_install_warnings_func_chks()

	// dynamic methods
	public function send_request($method,$request_uri,$form_data = false) { return false; }	// virtual


} // Capi_general

// eof

