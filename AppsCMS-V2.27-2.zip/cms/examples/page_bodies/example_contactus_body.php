<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_contactus_body.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>
<!--
Example contactus page.
-->
<style>
	table.contactus {
		background-color: inherit;
		border: 2px solid grey;
		width: 320px;
		}
	tr.contactus,th.contactus,td.contactus {
		padding-top: 5px;
		vertical-align: top;
		}
	th.contactus,td.contactus {
		margin: 5px;
		text-align: left;
		}
</style>
<?php echo Ccms_contactus_plugin::generate('','_mt','page_body contactus'); ?>
