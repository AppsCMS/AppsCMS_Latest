<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_body.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>

<h1>Hello, I am an example body page.</h1>

<?php

// and include some local apps
include APPS_FS_DIR . 'example_app1/' . 'example_app1.php';

include APPS_FS_DIR . 'example_app2/' . 'example_app2.php';
// NOTE: the APPS_FS_DIR . 'example_app1/' and APPS_FS_DIR . 'example_app2/' could have defined apps_config.php
// per the example_apps_config.php file

// plugin examples
// contactus, will show warnings if the email addresses to send to are not setup.
echo Ccms_contactus_plugin::generate();	// basic contactus

// Google maps
// After setting up echo '<p><iframe src="' . CMS_WS_DIR . 'cms_ajax.php?ajax=loadMapFrm&plugin=cms_maplatlong" frameborder="0" scrolling="no" width="350" height="350"></iframe></p>' . PHP_EOL;

// social meda
// After setting up echo '<p style="float: right;"><iframe src="' . CMS_WS_DIR . 'cms_ajax.php?ajax=socialMedia&plugin=cms_socialmedia" frameborder="0" scrolling="no"></iframe></p>' . PHP_EOL;

// NOTE: plugs may need configuring to use.

?>

<?php Ccms::get_JS_calendar_resource(); ?>
<form>
	<p>
		Calendar input example:
		<input type="text" id="id_calendar" name="calendar" value="" title="A tip for the calendar.">
	</p>
	<p>
		HTML5 Calendar input example:
		<input type="date" id="id_calendar2" name="calendar2" value="" title="A tip for the calendar 2.">
	</p>
	<p>
		Try enabling the Geo Location.
	</p>
		<?php Ccms::add_JS_geolcation_to_form(); ?>
</form>
<script type="text/javascript">
	<?php Ccms::set_JS_calendar_init("'id_calendar'","'y-m-d'"); ?>
</script>


