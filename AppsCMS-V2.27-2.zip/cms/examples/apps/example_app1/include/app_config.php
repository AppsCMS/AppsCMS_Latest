<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: app_config.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

define('EXAMPLE_APP1_VERSION' , 'V0.02');

