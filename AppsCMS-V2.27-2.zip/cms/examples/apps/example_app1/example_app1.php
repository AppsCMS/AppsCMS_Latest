<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_app1.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>

<p>
	<?php echo Cexample_app1_app::where_am_I(); // static method (no new/dymanic allocation ?>
</p>

<?php

$cCEX = new Cexample_app1_app();

?>

<p>
	<?php $cCEX->who_am_I(); // dynamic method, can be multiple ?>
</p>

