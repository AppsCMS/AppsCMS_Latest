<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_app1.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Cexample_app1
 *
 * the auto class loader finds me in apps/include/classes/ directory
 *
 * @author robert0609
 */

class Cexample_app1 extends Ccms_app_base {

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()


// static methods
	public static function where_am_I() {
		return 'In Cexample_app1 class.';
		} // where_am_I()

// dynamic methods
	public function who_am_I() {
		echo 'I am the Cexample_app1 class.';
		} // who_am_I()

} // Cexample_app1


