<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_tools_menu.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

$tools = Ccms::get_tools();
if(count($tools) > 0) {
	Ccms::page_start_comment(__FILE__);
	$tools_menu = array(
		'th' => array(
			'text' => Ccms_html::get_menu_icon_text('Tools'),
			'title' => "Tools for users. Tools are hard coded.",
			),
		'td' => array(),
		);
	// add 'td's in display order
	foreach($tools as $tool) {
		$tools_menu['td'][] = array(
			'url' => $tool['url'],
			'new' => $tool['new'],
			'title' => (!empty($tool['title']) ? strip_tags($tool['title']):''),
			'text' => $tool['name'],
			);
		} // foreach

	new Ccms_generate_Vmenu('tmenu','tools_pdb_container',$tools_menu);
	Ccms::$tools_menu_output = true;
	Ccms::page_end_comment(__FILE__);
	} // if

