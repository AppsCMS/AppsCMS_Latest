<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_bottom.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

	Ccms::get_code_errors();
	Ccms::saveMsgs();
	// save last url for variable recovery
	$current_url = (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI']:'');
	if(!preg_match('/ajax=|ajax\.php/',$current_url)) {	// no ajax url
		$_SESSION['last_url'] = $current_url;
		$_SESSION['last_time'] = time();
		} // if
	else {
		$_SESSION['last_ajax'] = $current_url;
		} // else
	$_SESSION['client_ip'] = Ccms_auth::get_client_ip_address();
	// session closed by server

