<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_page_right_column.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>
<?php	if(Ccms::show_right_column()) { ?>
<?php Ccms::page_start_comment(__FILE__); ?>
	<div id="cms_right_column">
		<table class="right_container"><tr class="right_container"><td class="right_container">
			<table class="right_container">
<?php
		$smtxt = Ccms::get_social_media('right_column_top');
		if(!empty($smtxt)) echo '<tr class="right_container"><td class="right_container">' . $smtxt . '</td></tr>' . PHP_EOL;
?>
<?php		if((!Ccms::$tools_menu_output) &&
				(Ccms::get_tool_cnt() > 0)) { ?>
				<tr class="right_container">
					<td class="right_container">
						<?php include CMS_FS_INCLUDES_DIR . "cms_tools_menu.php"; ?>
					</td>
				</tr>
<?php			} //if ?>
<?php		if((!Ccms::$admin_menu_output) &&
				(Ccms_auth::is_group_manager())) { ?>
				<tr class="right_container">
					<td class="right_container">
<?php				include CMS_FS_INCLUDES_DIR . "cms_config_menu.php"; ?>
					</td>
				</tr>
<?php			} // if ?>
<?php
		$smtxt = Ccms::get_social_media('right_column_bottom');
		if(!empty($smtxt)) echo '<tr class="right_container"><td class="right_container">' . $smtxt . '</td></tr>' . PHP_EOL;
?>
			</table>
		</td></tr></table>
	</div>
<?php Ccms::page_end_comment(__FILE__); ?>
<?php	} // if ?>
