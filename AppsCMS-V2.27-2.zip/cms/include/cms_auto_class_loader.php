<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_auto_class_loader.php 2070 2021-04-29 03:57:55Z robert0609 $
 */

/*
 *
 * class autoloader implementation
 *
 * the autoloader removed many circular includes and requires from the code
 * with the overall result that it runs faster and uses a lot less memory (typically half)
 *
 */

// function __autoload($class) {
//     include 'classes/' . $class . '.class.php';
// }

// the always defined classes
require_once(CMS_FS_CLASSES_DIR . 'cms_base.php');

class Ccms_autoloader extends Ccms_base {

	protected static $ops_dirs_list = false;

	function __construct($log = '', $record_time_times = true) {
		parent::__construct($log, $record_time_times);
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function &get_ops_dirs_list($reload = false) {
		if($reload) self::$ops_dirs_list = false;
		if(!self::$ops_dirs_list)
			self::init_ops_dirs_list ();
		return self::$ops_dirs_list;
		} // get_ops_dirs_list()

	protected static function init_ops_dirs_list() {
		if(self::$ops_dirs_list) return;

		// do the fast ones first
		// classes and plugins with relative paths for autoload
		self::$ops_dirs_list['classes'][] = CMS_FS_CLASSES_DIR;
		self::$ops_dirs_list['classes'][] = APPS_FS_CLASSES_DIR;
		self::$ops_dirs_list['plugins'][] = CMS_FS_PLUGINS_DIR;
		self::$ops_dirs_list['plugins'][] = APPS_FS_PLUGINS_DIR;

		// images and images with docroot relative paths for image selects
		// self::$ops_dirs_list['images'][] = CMS_WS_IMAGES_DIR;	// cms only
		self::$ops_dirs_list['images'][] = ETC_WS_IMAGES_DIR;
		self::$ops_dirs_list['images'][] = APPS_WS_IMAGES_DIR;
		self::$ops_dirs_list['images'][] = LOCAL_WS_TOOLS_IMAGES_DIR;

		// self::$ops_dirs_list['icons'][] = CMS_WS_ICONS_DIR;	// cms only
		self::$ops_dirs_list['icons'][] = ETC_WS_ICONS_DIR;
		self::$ops_dirs_list['icons'][] = LOCAL_WS_TOOLS_ICONS_DIR;

		self::$ops_dirs_list['backgrounds'][] = ETC_WS_BACKGROUNDS_DIR;

		if(is_dir(APPS_FS_DIR)) {	// find app class and plugins
			$dirs = scandir(APPS_FS_DIR);
			$sub_dirs = array('classes','plugins','images','icons','backgrounds');
			foreach($dirs as $d) {
				if(!is_dir(APPS_FS_DIR . $d)) continue;
				if(!self::is_dir_usable($d)) continue;
				if(preg_match('/^\.|include|javascript|lib|stylesheets/', $d)) continue;
				foreach($sub_dirs as $s) {
					switch($s) {
					case 'classes':
					case 'plugins':
						$bd = APPS_FS_DIR;
						break;
					default:
						$bd = APPS_WS_DIR;
						break;
						} // switch
					if(is_dir($bd . $d . '/' . $s))
						self::$ops_dirs_list[$s][] = $bd . $d . '/' . $s . '/';
					} // foreach
				} // foreach
			} // if
		} // init_ops_dirs_list

	public static function find_class($class, $filter = false) {
		$class_file = preg_replace('/^C/','', $class) . '.php';

		foreach(self::$ops_dirs_list['classes'] as $d) {
			if(($filter) && (strpos($d,$filter) === false))
				continue;
			if(file_exists($d . $class_file)) {	// standard cms classes
				return $d . $class_file;
				} // if
			} // foreach
		return false;
		} // find_class()

	public static function find_plugin($class, $dir_filter = false) {

		$class_file = preg_replace('/^C/','', $class) . '.php';

		if(preg_match('/_plugin$/', $class)) { // cms plugin classes
			$plugin_file = preg_replace('/_plugin/', '', $class_file);
			foreach(self::$ops_dirs_list['plugins'] as $d) {
				if(($dir_filter) && (strpos($d,$dir_filter) === false))
					continue;
				if(file_exists($d . $plugin_file)) {
					return $d . $plugin_file;
					} // if
				} // foreach
			} // if
		return false;
		} // find_plugin()

	public static function load_class($class) {

		self::init_ops_dirs_list();
		if(preg_match('/[ !?@]+/',$class)) {	// not legal
			Ccms::addMsg('Bad class name "' . $class . '".');
			return;
			} // if

		if($plugin_file = self::find_plugin($class)) { // cms plugin classes
			include_once $plugin_file;
			return;
			} // if

		if($class_file = self::find_class($class)) {	// standard cms classes
			include_once $class_file;
			return;
			} // if

		// special clases
		// @TODO rename the files of these classes
		switch($class) {
		case 'ZipArchive':
			return;
		default:
			// for class_exists(), dont make unnecessary logs/alerts
			$bk_trc = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
			$bk_tr_str = serialize($bk_trc);
			// typically: "... s:8:"function";s:12:"class_exists"; ... "
			if(strpos($bk_tr_str,'s:8:"function";s:12:"class_exists";') !== false)
				return;
			break;
			} // switch

		$msg = 'Unknown autoloader class: ' . $class . '';
		if((!defined('INI_DEBUG_BOOL')) ||
			(INI_DEBUG_BOOL)) echo $msg . PHP_EOL;

		if((!is_null(self::$is_debug)) && (self::$is_debug)) self::addMsg ($msg);
		else self::log_msg($msg);
		return;

		} // load_class()

} // Ccms_autoloader

// hook in global autoloader
function cms_auto_class_loader($class) {
	if(class_exists($class,false)) return;
	return Ccms_autoloader::load_class($class);
	} // cms_auto_class_loader()
spl_autoload_register('cms_auto_class_loader');

// set global classes
$cCMS = new Ccms();

