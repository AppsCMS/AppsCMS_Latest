<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_body.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php
$body_cnt = Ccms::get_body_cnt();
$filename = '';
$body = '';
if($body_cnt > 0) {
	if(!$body = Ccms::get_body()) {	// should not happen
		Ccms::log_msg('ERROR: Could not find a page body.');
		return;
		} // if
	} // if
if(Ccms::$body_full_view) {
	Ccms::output_body_core($body);
	return;
	} // if
?>

<table class="page_body">
	<?php if($body_cnt > 0) echo '<caption>' . $body['cms_body_name'] . ' body</caption>' . PHP_EOL ?>
	<?php if((Ccms::$body_default_msgs) && (Ccms::getMsgsCount())) { ?>

	<tr class="page_body_msgs">
		<td class="page_body_msgs">
			<?php echo Ccms::getMsgsTable(); ?>
		</td>
	</tr>
	<?php } //if ?>
<?php
if($body_cnt > 0) {
?>

	<tr class="page_body">
		<td class="page_body">
<?php
		Ccms::output_body_core($body);
?>
		</td>
	</tr>
<?php	} // if ?>
<?php if((Ccms::$body_default_msgs) && (Ccms::getMsgsCount())) { ?>
	<tr class="page_body_msgs">
		<td class="page_body_msgs">
			<?php echo Ccms::getMsgsTable(); ?>
		</td>
	</tr>
<?php } //if ?>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>
