<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_edit_apps.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

$cms_app_id = 0;
$cms_app_op = '';
$comments = Ccms_apps::read_apps_ini_comments();

if(Ccms::$cms_action == 'cms_edit_apps') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('edit_options_ary'))) {
		Ccms_xml_sitemap::reset_xml_sitemap();
		$conf = Ccms_apps::read_apps_ini_settings();
		$install = Ccms_edit::get_posted_data('edit_options_ary',$comments,$conf);
		if($install) {
			Ccms_apps::convert_ini_apps_form_input($install);
			Ccms_apps::save_apps_ini_settings($install);
			} // if
		Ccms::unset_get_or_post('save');
		Ccms::unset_get_or_post('edit_options_ary');
		} // if
	else if((Ccms::is_get_or_post('reloadINI')) && (Ccms::get_or_post('reloadINI') == 'reloadINI')) {
		Ccms_xml_sitemap::reset_xml_sitemap();
		$settings_default = Ccms_apps::read_apps_ini_defaults();
		// $settings = Ccms_apps::read_apps_ini_settings();
		$settings = $settings_default;
		if(Ccms_apps::save_apps_ini_settings($settings)) {
			Ccms::addMsg("Set install to default apps settings.",'info');
			} // if
		$cms_theme_op = '';
		$cms_theme_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_app_op = 'cancel';
		$cms_app_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('name')) {
		$cms_app_op = 'scroll';
		$cms_app_id = Ccms::get_or_post('name');
		} // else if
	} // if
?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php
	$h1 = 'Application (Apps) Configurations';
	$conf = Ccms_apps::read_apps_ini_settings();		// read again for changes
	$opts_ary = array(
		'dest_file' => ETC_FS_APPS_CONFIG,
		'prefix' => 'APP_',
	//	'ary_name' => 'pm_options_ary',
	//	'class' => 'page_config appsthm',
	//	'readonly' => true,
	//	'show_code_links' => false,
	//	'show_scroll2top' => false,
	//	'show_found_name' => false,
		);
	new Ccms_edit('cms_edit_apps', $h1, $conf, $comments,$opts_ary);
?>

<?php Ccms::page_end_comment(__FILE__); ?>
