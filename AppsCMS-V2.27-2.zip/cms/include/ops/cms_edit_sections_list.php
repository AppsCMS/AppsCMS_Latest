<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_edit_sections_list.php 2004 2021-02-28 08:53:00Z robert0609 $
 */

$edit_section_qk_filter = Ccms::get_or_post_keyed_session_var('edit_section_qk_filter');
$edit_section_qk_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_section_qk_enabled');

if((!Ccms::is_get_or_post('section_edit_id')) &&
	(Ccms::get_or_post('lm_section_qk_anchor') != 'null')) {	// return anchor
	$edit_section_qk_anchor = Ccms::get_or_post_keyed_session_var('lm_section_qk_anchor');
	} // if
else $edit_section_qk_anchor = false;	// edit the link

?>

<?php Ccms::page_start_comment(__FILE__); ?>

			<script type="text/javascript">
				var lm_select_sect_opts = <?php echo json_encode((object)Ccms_html::gen_section_selection_options(0,false,true,false), JSON_PRETTY_PRINT); ?>;
				function lm_select_fill_options(event,sel_obj) {
					if(event.type == 'change') {
						sel_obj.form.submit();
						return true;
						} // if
					else if((event.type == 'click') &&
						(sel_obj.options.length < 5)) {	// 5 ?!?!
						// fill select options
						sel_obj.onclick = null;	// stop further click events
						var seld_option = false;
						try {
							seld_option = sel_obj.options[sel_obj.selectedIndex];	// get currect selected
							}
						catch(e) {
							seld_option = false;
							}
						// fill select options
						sel_obj.options.length = 0;	// clear it
						for(var i in lm_select_sect_opts) {
							var s_opt = lm_select_sect_opts[i];
							var seld = false;
							if(seld_option.value == s_opt.value) seld = true
							var n_opt = document.createElement("option");
							n_opt.value = s_opt.value;
							n_opt.text = s_opt.text;
							n_opt.selected = seld;
							// n_opt.style = s_opt.style;
							sel_obj.appendChild(n_opt);
							} // for
						return true;
						} // if
					return false;
					} // lm_select_fill_options()

			var last_edit_section_qk_filter_call = null;
			function chk_section_filter(event,obj) {
				if(event.keyCode == 13) {
					obj.form.submit();
					return true;
					} // if
				if((event.type == 'click') &&
					(obj.type == 'checkbox')) {
					obj.form.submit();
					return true;
					} // if
				// don't submit on every char event, wait
				if(last_edit_section_qk_filter_call != null) {	// clear it
					window.clearTimeout(last_edit_section_qk_filter_call);
					last_edit_section_qk_filter_call = null;
					} // if
				// restart if
				last_edit_section_qk_filter_call = window.setTimeout(
					function (event,obj) {
						var keywords = obj.value;
						if((keywords.length > 2) ||
							(keywords.length == 0)) {
							obj.form.submit();
							return true;
							} // if
						return false;
						},
					1200, event, obj);
				} // chk_section_filter()

			function submit_edit_section_qk_input(event,obj,id,anchor) {
				if(obj.tagName != 'INPUT')
					return false;
				var name = obj.name;
				var form = document.createElement("FORM");

				form.method = "POST";
				form.action = "<?php echo $_SERVER['PHP_SELF']; ?>";

				var element1 = document.createElement("input");
				element1.value = "cms_edit_sections";
				element1.name = "cms_action";
				form.appendChild(element1);

				var element2 = document.createElement("input");
				element2.name = "lm_section_qk_op";
				element2.value = "edit_section_input";
				form.appendChild(element2);

				var element3 = document.createElement("input");
				element3.value = id;
				element3.name = "lm_section_qk_id";
				form.appendChild(element3);

				var element4 = document.createElement("input");
				element4.value = obj.type;
				element4.name = 'lm_section_qk_type';
				form.appendChild(element4);

				var element5 = document.createElement("input");
				element5.name = "lm_section_qk_name";
				element5.value = name;
				form.appendChild(element5);

				var element6 = document.createElement("input");
				if(obj.type == 'checkbox') {
					var chkd = obj.checked;
					element6.value = (chkd ? 'on':'off');
					} // if
				else element6.value = obj.value;
				element6.name = 'lm_section_qk_value';
				form.appendChild(element6);

				var element7 = document.createElement("input");
				element7.name = "lm_section_qk_anchor";
				element7.value = (anchor ? anchor:'');
				form.appendChild(element7);

				document.body.appendChild(form);
				form.submit();

				} // submit_edit_section_qk_section_input()

			</script>
			<style>
				#summary_id select {
					font-size: 0.9em;
					max-width: 300px;
					min-width: 240px;
					}
			</style>

<table class="page_config">
	<tr class="page_config">
		<td class="page_config">
			<h3 class="page_config" class="page_config">Summary</h3>
			&nbsp;
			<form name="link_section_edit_filter" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_sections"/>
				<input type="hidden" name="lm_section_qk_op" value="edit_section_qk_filter"/>
				<label style="text-decoration: none; font-weight: normal;">
					<input type="text" name="edit_section_qk_filter"
						value="<?php echo $edit_section_qk_filter; ?>"
						oninput="chk_link_section_filter(event,this);"
						title="Enter filter keywords to find sections separated by spaces."
						/>
					<input type="checkbox" name="edit_section_qk_enabled"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only enabled sections."
						<?php echo ($edit_section_qk_enabled ? ' CHECKED':''); ?>/>
					section filters.
				</label>
			</form>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
	<?php
		$ret_anch = '';
		$where_filter = '';
		if(!empty($edit_section_qk_filter)) {
			$bowes = 0;
			$where_filter .= PHP_EOL . 'WHERE ( ';
			$filters = preg_split('/[\s,;:\/\'\"]+/',$edit_section_qk_filter);
			foreach($filters as $bow) {
				if($bowes > 0) $where_filter .= ' AND ';
				$where_filter .= 'lm_section_name LIKE \'%' . $bow . '%\'' . PHP_EOL;
				$bowes++;
				} // foreach
			$where_filter .= ' ) ' . PHP_EOL;
			} // if
		if($edit_section_qk_enabled) {
			if(empty($where_filter)) $where_filter = ' WHERE ';
			else $where_filter .= ' AND ';
			$where_filter .= ' lm_section_enabled > 0 ';
			}
		$sect_chk = array();
		$sql_query = "SELECT  lm_section_id,lm_section_name,lm_section_columns,lm_section_group_ids" .
			",lm_section_title,lm_section_description, lm_section_order, lm_section_enabled" .
			", lm_section_parent_id, lm_section_image_url, lm_section_icon_url,lm_section_comments" .
			PHP_EOL . " FROM  lm_sections" .
			$where_filter .
			PHP_EOL . " ORDER BY lm_section_parent_id,lm_section_order,lm_section_name";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
?>
			<table class="page_config">
				<tr class="page_config" style="position: sticky; top: 0px; background-color: ivory;">
					<th width ="150px" class="page_config" title="Section parent name">Section Parent</th>
					<th width ="150px" class="page_config" title="Section name">Section</th>
					<th class="page_config">Groups</th>
					<th class="page_config" style="text-align: center" title="Section image">Image</th>
					<th class="page_config" style="text-align: center" title="Section icon">Icon</th>
					<th width ="70px" class="page_config" title="Display order">Order</th>
					<th width ="70px" class="page_config">Enabled</th>
					<th width ="70px" class="page_config">Columns</th>
					<th class="page_config">Description</th>
					<th class="page_config">Comments</th>
				</tr>
<?php
			$row = 0;
			$sel_params = ' onclick="lm_select_fill_options(event,this);"' .
				' onchange="lm_select_fill_options(event,this)" size="1"';
			while($section = Ccms::$cDBcms->fetch_array($result)) {
				$ret_anch = 'anch_sect_' . $section['lm_section_id'];
				echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">' . PHP_EOL;

				$sect_links_cnt = Ccms::$cDBcms->get_row_count_in_table('lm_links','lm_link_section_id = ' . (int)$section['lm_section_id']);

				echo '<td class="page_config" style="text-align: left">';
//				if(!empty($section['lm_section_parent_id'])) {
//					$section_parent_name = Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_name',"lm_section_id = " . (int)$section['lm_section_parent_id'] . "");
//					$section_parent_enabled = Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_enabled',"lm_section_id = " . (int)$section['lm_section_parent_id'] . "");
//					echo '' .
//						($section_parent_name ? '<a href="index.php?cms_action=cms_edit_sections&section_edit_id=' . $section['lm_section_parent_id'] . '">' .
//						$section_parent_name . '</a>':Ccms::make_message_brief_text('(Orphan)','warn'));
//					if((int)$section_parent_enabled <= 0) echo Ccms::make_message_brief_text('(Disabled)','warn');
//					} // if
//				else echo '(Base Section)';

				echo '	<form name="link_qk_section_edit" action="' . $_SERVER['PHP_SELF'] . '" method="get">' . PHP_EOL;
				// public static function gen_section_selection_list($name, $lm_section_id = 0, $params = '', $exc_ids = false, $bare = false, $onchange_submit = true) {
				echo  Ccms::gen_parent_section_js_selection_list('lm_section_qk_parent_id', $section['lm_section_id'],$sel_params, false, true, false) . PHP_EOL;
				echo '		<input type="hidden" name="cms_action" value="cms_edit_sections"/>' . PHP_EOL;
				echo '		<input type="hidden" name="lm_section_qk_id" value="' . $section['lm_section_id'] . '"/>' . PHP_EOL;
				echo '		<input type="hidden" name="lm_section_qk_op" value="edit_section_qk"/>' . PHP_EOL;
				echo '		<input type="hidden" name="edit_section_qk_filter" value="' . $edit_section_qk_filter . '"/>' . PHP_EOL;
				echo '		<input type="hidden" name="lm_section_qk_anchor" value="' . $ret_anch . '"/>' . PHP_EOL;
				echo '	</form>' . PHP_EOL;

				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left">';
				echo '<a name="' . $ret_anch . '" style="scroll-margin: 25px;"></a>';
				if(Ccms::is_debug()) echo 'ID: ' . $section['lm_section_id'] . ', ';
				echo '	<a href="index.php?cms_action=cms_edit_sections&section_edit_id=' . $section['lm_section_id'] .
					'" title="' . strip_tags($section['lm_section_title']) . ' (' . $sect_links_cnt . ' links.)"' .
					'>' . $section['lm_section_name'] . '</a>' .
					(!$section['lm_section_enabled'] ? '<br>(disabled)':'');
				if(isset($sect_chk[($section['lm_section_id'])])) {
					if((int)$sect_chk[($section['lm_section_id'])] != (int)$section['lm_section_parent_id']) {
						echo Ccms::make_message_text('(Duplicate parents)','warn');
						} // if
					} // if
				else $sect_chk[($section['lm_section_id'])] = $section['lm_section_parent_id'];

				echo '</td>' . PHP_EOL;

				echo '<td class="page_config">' . Ccms::get_group_ids_text($section['lm_section_group_ids'],false) . '</td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: center">';
				echo $cCMS_C->show_image($section['lm_section_image_url'],ETC_WS_IMAGES_DIR,'page_config');
				echo '</td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: center">';
				echo $cCMS_C->show_image($section['lm_section_icon_url'],ETC_WS_ICONS_DIR,'page_config');
				echo '</td>';
				// echo '<td class="page_config" style="text-align: left">' . $section['lm_section_order'] . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left">' .
						'<input type="number" name="lm_section_order" size="5"' .
							' value="' . $section['lm_section_order'] . '"' .
							' style="width: 40px;"' .
							' onchange="submit_edit_section_qk_input(event,this,\'' . $section['lm_section_id'] . '\',\'' . $ret_anch . '\');"' .
							' autocapitalize="off"/>' .
					 '</td>'. PHP_EOL;
				// echo '<td class="page_config" style="text-align: left">' . ($section['lm_section_enabled'] ? 'yes':'no') . ' </td>';
				echo '<td class="page_config" style="text-align: left">' .
						' <input type="checkbox" name="lm_section_enabled"' .
							' onchange="submit_edit_section_qk_input(event,this,\'' . $section['lm_section_id'] . '\',\'' . $ret_anch . '\');"' .
							($section['lm_section_enabled'] == 1 ? ' CHECKED':'') . '/>' .
					 '</td>'. PHP_EOL;
				// echo '<td class="page_config" style="text-align: left">' . $section['lm_section_columns'] . ' </td>';
				echo '<td class="page_config" style="text-align: left">' .
						'<input type="number" name="lm_section_columns" size="5"' .
							' value="' . $section['lm_section_columns'] . '"' .
							' style="width: 40px;"' .
							' onchange="submit_edit_section_qk_input(event,this,\'' . $section['lm_section_id'] . '\',\'' . $ret_anch . '\');"' .
							' autocapitalize="off"/>' .
					 '</td>'. PHP_EOL;
				//echo '<td class="page_config" style="text-align: left">' . $section['lm_section_description'] . '</td>';
				echo '<td class="page_config" style="text-align: left">' .
						'<input type="text" name="lm_section_description"' .
							' value="' . $section['lm_section_description'] . '"' .
							' onchange="submit_edit_section_qk_input(event,this,\'' . $section['lm_section_id'] . '\',\'' . $ret_anch . '\');"' .
							' autocapitalize="off"/>' .
					 '</td>'. PHP_EOL;
				//echo '<td class="page_config" style="text-align: left">' . $section['lm_section_comments'] . '</td>';
				echo '<td class="page_config" style="text-align: left">' .
						'<input type="text" name="lm_section_comments"' .
							' value="' . $section['lm_section_comments'] . '"' .
							' onchange="submit_edit_section_qk_input(event,this,\'' . $section['lm_section_id'] . '\',\'' . $ret_anch . '\');"' .
							' autocapitalize="off"/>' .
					 '</td>'. PHP_EOL;
				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			echo '			</table>' . PHP_EOL;
			} // if
		else {
			if(!empty($edit_section_qk_filter))
				$msg = '(No sections found)';
			else $msg = '(No sections setup)';
			echo '<span class="cms_msg_warning">' . $msg . '</span>' . PHP_EOL;
			} // else
		?>
		</td>
	</tr>
</table>

<script type="text/javascript">
	var last_edit_section_qk_filter_call = null;
	function chk_link_section_filter(event,obj) {
		if(event.keyCode == 13) {
			obj.form.submit();
			return true;
			} // if
		if((event.type == 'click') &&
			(obj.type == 'checkbox')) {
			obj.form.submit();
			return true;
			} // if
		// don't submit on every char event, wait
		if(last_edit_section_qk_filter_call != null) {	// clear it
			window.clearTimeout(last_edit_section_qk_filter_call);
			last_edit_section_qk_filter_call = null;
			} // if
		// restart if
		last_edit_section_qk_filter_call = window.setTimeout(
			function (event,obj) {
				var keywords = obj.value;
				if((keywords.length > 2) ||
					(keywords.length == 0)) {
					obj.form.submit();
					return true;
					} // if
				return false;
				},
			1200, event, obj);
		} // chk_link_section_filter()

</script>

<?php if (!empty($edit_section_qk_anchor)) { ?>

<script>

	cms_scroll2Name('<?php echo $edit_section_qk_anchor; ?>',-50);	// scroll anchor

</script>

<?php	} // if ?>

<?php Ccms::page_end_comment(__FILE__); ?>
