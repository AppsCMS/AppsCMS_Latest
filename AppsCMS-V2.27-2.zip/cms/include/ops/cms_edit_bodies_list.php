<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_edit_bodies_list.php 2070 2021-04-29 03:57:55Z robert0609 $
 */

// the body list table for cms_edit_bodies.php

function get_cms_edit_bodies_more_DB($body) {

	$cms_body_title = (empty($body['cms_body_title']) ? '(empty)':$body['cms_body_title']);
	$cms_body_meta_description = (empty($body['cms_body_meta_description']) ? '(empty)':str_replace(',',', ',$body['cms_body_meta_description']));
	$cms_body_meta_keywords = (empty($body['cms_body_meta_keywords']) ? '(empty)':str_replace(',',', ',$body['cms_body_meta_keywords']));

	$cms_body_description = Ccms::get_body_description($body['cms_body_id'],$body['cms_body_name'],$body['cms_body_description'],false);
	$cms_body_H1 = Ccms::get_body_description($body['cms_body_id'],$body['cms_body_name'],$body['cms_body_H1'],false);
	$cms_body_H1_title = Ccms::get_body_description($body['cms_body_id'],$body['cms_body_name'],$body['cms_body_H1_title'],false);
	$cms_body_purpose = Ccms::get_body_description($body['cms_body_id'],$body['cms_body_name'],$body['cms_body_purpose'],false);
	$cms_body_info1 = Ccms::get_body_description($body['cms_body_id'],$body['cms_body_name'],$body['cms_body_info1'],false);
	$cms_body_info2 = Ccms::get_body_description($body['cms_body_id'],$body['cms_body_name'],$body['cms_body_info2'],false);
	$cms_body_comments = $body['cms_body_comments'];
	$cms_body_package_excludes = $body['cms_body_package_excludes'];

	$cron_title = (can_cron($body['cms_body_type']) ? 'Allow CRON job.' . (!empty($body['cms_body_crontab_job']) ? '\nCron script: ' . $body['cms_body_crontab_job']:' (No script set)'):'');
	$cron_text = (can_cron($body['cms_body_type']) ? ($body['cms_body_crontab_enable'] ? 'yes':'no'):'na');

	$text = <<< EOTTOP

		<style>
			table.page_config th {
				width: 120px;
				}
		</style>
		<div class="page_config_dropdown">
			<span style="cursor: pointer;"> ... more</span>
			<div class="page_config_dropdown_content" style="width: 480px;">
				<table class="page_config page_config_edit">
					<tr class="page_config_odd" title="Window / Tab title.">
						<th class="page_config">Page Title</th>
						<td class="page_config">{$cms_body_title}</td>
					</tr>
					<tr class="page_config_even" title="Page header meta description.">
						<th class="page_config">Meta Description</th>
						<td class="page_config">{$cms_body_meta_description}</td>
					</tr>
					<tr class="page_config_odd" title="Page header search keywords (SEO).">
						<th class="page_config">Meta Keywords</th>
						<td class="page_config">{$cms_body_meta_keywords}</td>
					</tr>
					<tr class="page_config_even" title="Application description.">
						<th class="page_config">Description</th>
						<td class="page_config">{$cms_body_description}</td>
					</tr>
					<tr class="page_config_odd" title="Application H1 heading.">
						<th class="page_config">H1</th>
						<td class="page_config">{$cms_body_H1}</td>
					</tr>
					<tr class="page_config_odd" title="Application H1 title/tooltip.">
						<th class="page_config">H1 Title</th>
						<td class="page_config">{$cms_body_H1_title}</td>
					</tr>
					<tr class="page_config_odd" title="Application purpose.">
						<th class="page_config">Purpose</th>
						<td class="page_config">{$cms_body_purpose}</td>
					</tr>
					<tr class="page_config_even" title="Application general info 1, free text for applications.">
						<th class="page_config">Info 1</th>
						<td class="page_config">{$cms_body_info1}</td>
					</tr>
					<tr class="page_config_odd">
						<th class="page_config" title="Application general info 2, free text for applications.">Info 2</th>
						<td class="page_config">{$cms_body_info2}</td>
					</tr>
					<tr class="page_config_odd">
						<th class="page_config" title="{$cron_title}">Cron</th>
						<td class="page_config">{$cron_text}</td>
					</tr>
					<tr class="page_config_odd">
						<th class="page_config" title="Application admin comments, free text for applications.">Comments</th>
						<td class="page_config">{$cms_body_comments}</td>
					</tr>
				</table>
			</div>
		</div>

EOTTOP;

	return $text;
	} // get_cms_edit_bodies_more_DB()

Ccms::page_start_comment(__FILE__);

?>

			<table class="page_config">
				<tr class="page_config" style="position: sticky; top: 0px; background-color: ivory;">
					<th class="page_config" style="width: unset;" title="App name and options.">Name</th>
					<th class="page_config"></th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;"></th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;">File</th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;"
						title="Nav bar and menu and application icon.\nUsed on small devices instead of text labels.\nStored in the <?php echo ETC_WS_ICONS_DIR; ?> directory or in <?php echo APPS_WS_DIR; ?>(APP_DIR)/icons/">
						Icon
					</th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;"
						title="Application purpose image.\nStored in the <?php echo ETC_WS_IMAGES_DIR; ?> directory or in <?php echo APPS_WS_DIR; ?>(APP_DIR)/images/">
						Image
					</th>

					<th class="page_config" style="width: unset; border-right: 1px solid grey;"
						title="Application readme.\nNOTE: Is a file reference in <?php echo APPS_WS_DIR; ?>(APP_DIR)/">
						Readme
					</th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;"
						title="Application release notes.\nNOTE: Is a file reference in <?php echo APPS_WS_DIR; ?>(APP_DIR)/">
						Release Notes
					</th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;"
						title="Application terms and conditions.\nNOTE: Is a file reference in <?php echo APPS_WS_DIR; ?>(APP_DIR)/">
						Terms
					</th>
					<th class="page_config" style="width: unset; border-right: 1px solid grey;"
						title="Application Acknowledgments.\nNOTE: Is a file reference in <?php echo APPS_WS_DIR; ?>(APP_DIR)/">
						Ack&rsquo;
					</th>
					<th class="page_config" style="width: unset;"
						title="Application Licence.\nNOTE: Is a file reference in <?php echo APPS_WS_DIR; ?>(APP_DIR)/">
						Licence
					</th>

				</tr>
	<?php
		$sql_query = "SELECT cms_body_id,cms_body_version,cms_body_installed,cms_body_name,cms_body_dir,cms_body_type,cms_body_ssl,cms_body_file,cms_body_group_ids, cms_body_debug_only,cms_body_default_msgs" .
			", cms_body_title,cms_body_meta_description,cms_body_meta_keywords, cms_body_order, cms_body_default, cms_body_login_page, cms_body_login_required" .
			", cms_body_enabled, cms_body_cached, cms_body_full_view, cms_body_description" .
			", cms_body_H1, cms_body_H1_title, cms_body_purpose, cms_body_info1, cms_body_info2" .
			", cms_body_icon_url,cms_body_image_url,cms_body_terms_url,cms_body_terms_upfirst,cms_body_release_notes_url,cms_body_readme_url,cms_body_acknowledgment_url,cms_body_licence_url" .
			", cms_body_crontab_enable,cms_body_crontab_time,cms_body_crontab_job,cms_body_comments,cms_body_package_excludes" .
			", DATETIME(cms_body_added, 'LocalTime') as  cms_body_added" .
			", DATETIME(cms_body_updated, 'LocalTime') as  cms_body_updated" .
			" FROM  cms_bodies ORDER BY cms_body_default DESC,cms_body_order ASC,cms_body_id ASC";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			while($body = Ccms::$cDBcms->fetch_array($result)) {
				if(!Ccms_auth::is_group_manager($body['cms_body_group_ids'])) continue;
				$body_filepath = PAGE_BODIES_FS_DIR . $body['cms_body_file'];
				$body_stats = '';
				if($body['cms_body_type'] == Ccms_DB_checks::APP_TYPE_REVPROXY_FRAME) {
					if(!Ccms::host_check($body['cms_body_file'])) {
						$body_stats .= '<span class="cms_msg_error">URL: Not found</span>';;
						} // if
					else $body_stats .= '<span class="cms_msg_info">URL: Ok</span>';;
					} // if
				else if((file_exists($body_filepath)) && (is_readable($body_filepath))) {
					$body_stats .= '<span class="cms_msg_info title="Added:&nbsp;' . $body['cms_body_added'] . ',' . PHP_EOL . 'Updated:&nbsp;' . $body['cms_body_updated'] . '">';
					$body_stats .= filesize($body_filepath) . ' bytes';
					if(!is_writable($body_filepath)) $body_stats .= ', read only';
					$body_stats .= '</span>';
					} // if
				else $body_stats .= '<span class="cms_msg_error">Not found</span>';
				echo '			';
				echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">';

				$app_type = &$apps_types[((int)$body['cms_body_type'] % count($apps_types))];

				echo '<td class="page_config" style="text-align: left;  white-space: nowrap;">';
				if(Ccms::is_debug()) echo 'ID: ' . $body['cms_body_id'] . ', ';
				echo '<a class="multi" href="index.php?cms_action=cms_edit_bodies&body_edit_id=' . $body['cms_body_id'] . '" title="' . strip_tags($body['cms_body_title']) . ($body['cms_body_installed'] ? '\nInstalled application.':'') . '"><b>' . $body['cms_body_name'] . '</b></a>';
				echo '<br><span class="multi">Enabled: ' . ($body['cms_body_enabled'] ? 'yes':'no') . ' </span>';
				echo '<br><span class="multi" title="' . $app_type['title'] . ', refer to tech manual.">Type: ' . $app_type['name'] . '</span>';
				echo '<br><span class="multi" title="Application directory in ' . APPS_WS_DIR . '">Dir:  ' . (empty($body['cms_body_dir']) ? '(not set)':$body['cms_body_dir']) . '</span>';
				echo '<br><span class="wrap">' . Ccms::get_group_ids_text($body['cms_body_group_ids'],false) . '</span>';
				echo '<br><span class="multi" title="' . ($body['cms_body_installed'] ? 'Installed application package, limited changes allowed.':'') . '">Can Change: ' . (!$body['cms_body_installed'] ? 'yes':'no') . '</span>';
				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left">';
				echo '<span class="multi" title="Application version (optional, app version tracking).">Version: ' . (empty($body['cms_body_version']) ? '(empty)':$body['cms_body_version']) . '</span>';
				echo '<br><span class="multi" title="Checked: default home page (only one allowed).">Default: ' . ($body['cms_body_default'] ? 'yes':'no') . ' </span>';
				echo '<br><span class="multi" title="Use this page for login form else use standard login page.">Login: '. ($body['cms_body_login_page'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="Login required to use this page.">Required: '. ($body['cms_body_login_required'] ? 'yes':'no') . '</span>';

				echo '<br><span class="multi" title="Only used in debug mode.">Debug: ' . ($body['cms_body_debug_only'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="Default message operation.">Msgs: ' . ($body['cms_body_default_msgs'] ? 'yes':'no') . '</span>';
				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">';
				echo '<span class="multi" title="The body code conatins the entire page body (i.e. AppsCMS does not ouput header, nav bar, left column or footer.).">Full: ' . ($body['cms_body_full_view'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="Checked: if SSL encryption required.">SSL: ' . ($body['cms_body_ssl'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="Allow the content to cached (not suitable for dynamic content).">Cached: ' . ($body['cms_body_cached'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="Display order.">Order: ' . $body['cms_body_order'] . '</span>';
				echo '<br><span class="multi" title="' . ($body['cms_body_installed'] ? 'Application is installed, changes are not allowed (can be updated).':'Application is not locked (can be packaged).') . '">Installed : ' . ($body['cms_body_installed'] ? 'yes':'no') . '</span>';
				echo get_cms_edit_bodies_more_DB($body);
				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">';
				echo '<span class="multi" title="File in page_bodies/">' . $body['cms_body_file'] . ' </span>';
				echo '<br><span class="multi">' . $body_stats . ' </span>';
				if(Ccms::is_debug()) {
					echo '<br><span class="multi"' .
						' title="Numeric base URIs to the body page.\nSuffixed with the page body actions, etc.\ne.g. &quot;index.php?body=1&action=something_to_do&quot;.">' .
						'URIs: ' . Ccms::get_body_uri($body['cms_body_id']) .
						'</span>';
					echo '<br><span class="multi">or</span>';
					echo '<br><span class="multi"' .
						' title="Long base URIs to the body page.\nThe long version is preferred by GoogleBot so the name matches the contents.">' .
						Ccms::get_body_uri($body) . '</span>';
					} // if
				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_body_icon_uri($body,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_body_image_uri($body,'(empty)','page_config') . ' </td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_body_readme_uri($body,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_body_release_notes_uri($body,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' .
						Ccms::get_body_terms_uri($body,'(empty)') .
						($body['cms_body_terms_upfirst'] ? '<br>(Show on first use)':'') .
						' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_body_acknowledgment_uri($body,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left;">' . Ccms::get_body_licence_uri($body,'(empty)') . ' </td>' . PHP_EOL;

				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			} // if
		else echo '<tr class="page_config"><td class="page_config" style="text-align: left"><span class="cms_msg_warning">(No page bodies setup)</span></td></tr>' . PHP_EOL;
		?>
			</table>

<?php Ccms::page_end_comment(__FILE__); ?>
