<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_about.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<table class="page_body" style="color: black; background-color: white;">
	<caption>About <?php echo strip_tags(CMS_PROJECT_SHORTNAME); ?> page</caption>
	<tr class="page_body">
		<th class="page_body">
			<img height="150px" src="<?php echo CMS_IMAGE_LOGO; ?>" alt="<?php echo CMS_PROJECT_SHORTNAME; ?> Logo">
			<h1 class="page_config" style="white-space: normal;">About</h1>
			<br>
			<h2 class="page_config" style="white-space: normal;"><?php Ccms::prn_AppsCMS_title(); ?></h2>
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> came from the need to have an easy to install, use and maintain web management system for workshops, store rooms and laboratories.
				The <?php echo CMS_PROJECT_SHORTNAME; ?> can operate on an isolated intranet network, making it ideal for internal private web sites.
				As well as for public access web sites.
			</p>
			<p class="page_body">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> is a PHP developers web multiple Applications Management System Library.
				Not wanting to wrangle with abstract concepts (both software and design) in mainstream
				content management systems and deal of problematic installations,
				I wrote the <?php echo CMS_PROJECT_SHORTNAME; ?> for this role.
			</p>
			<p class="page_body">
				The installation comes as a self installing bash script (2,2MB) for LINUX and a ZIP (1.6M) file for general installations.
				Available on the &quot;https://github.com/AppsCMS/AppsCMS_Latest/blob/master/AppsCMS-Installer-latest.sh&quot; repository and
				on &quot;http://<?php echo CMS_PROJECT_DOMAIN; ?>/&quot; web site.
			</p>
			<p class="page_body">
				Access to web pages is controlled by user and group permissions.
				Individual users or groups can have administation privileges, to a page or to the whole web site.
				Users with privileges are required to have a username and password.
				Access by public (guest) users is controlled by permissions.
			</p>
			<p class="page_body">
				<?php echo CMS_PROJECT_SHORTNAME; ?> provides settings and configuration pages to write, edit and maintain the contents.
			</p>
			<p class="page_body">
				A further consideration is to have a common method to link to locally installed tools
				(e.g. WebSVN, Database tools, Regex testers, etc).
			</p>
			<p class="page_body">
				<?php echo CMS_PROJECT_SHORTNAME; ?> also provides a methods for displaying only the necessary content for each user or group.
				A user can log into <?php echo CMS_PROJECT_SHORTNAME; ?>.
				Each user can be a member of a number of groups
				and so allows content set for group/s to display the appropriate pages.
				A user also be an administrator or a group manager.
			</p>
			<p class="page_body">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has many built in aids including programming aids, log viewing, debugging, examples and setup searches.
				Making the <?php echo CMS_PROJECT_SHORTNAME; ?> easy to learn and implement.
			</p>
			<p class="page_body">
				The <a href="index.php?cms_action=cms_manual">Users Manual</a> has more details on the <?php echo CMS_PROJECT_SHORTNAME; ?>.
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			Licence
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				As <?php echo CMS_PROJECT_SHORTNAME; ?> has been useful, <?php echo CMS_PROJECT_SHORTNAME; ?> has been released
				under the <a href="https://opensource.org/licences/BSD-3-Clause">The 3-Clause BSD Licence</a>.
			</p>
			<p class="page_body">
<!--				Refer to <a href="<?php echo CMS_WS_DIR; ?>LICENCE.txt">LICENCE.txt</a>.-->
				Refer to <?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'LICENCE.txt','LICENCE'); ?>.
			</p>
			<p class="page_body">
				Refer to the <a href="index.php?cms_action=cms_manual#Licence">Technical Manual Licence</a> for more licence information.
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="MoreInfo"></a>
			User Manual, Release Information and Feedback
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				<A HREF="index.php?cms_action=cms_manual">Technical Manual</A>.
			</p>
			<p class="page_body">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'README.md','README'); ?>
			</p>
			<p class="page_body">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes'); ?>
			</p>
			<p class="page_body">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes'); ?>
			</p>
			<p class="page_body">
				Hints, corrections and suggestions are always welcome.
				<A HREF="mailto:feedback@<?php echo CMS_PROJECT_DOMAIN; ?>?Subject=<?php echo rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION); ?>">Email Feedback</A>.
			</p>
		</td>
	</tr>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>
