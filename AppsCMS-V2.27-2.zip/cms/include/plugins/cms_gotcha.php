<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_gotcha.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Gotcha plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */


class Ccms_gotcha_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_gotcha';

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		return self::is_plugin_enabled(self::PLUGIN);
		} // is_enabled()

	public static function is_this_ajax_plugin($ajax) {	// required function, check for ownership of ajax op by this plugin
		if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		if ($ajax == 'reloadGotchaCode') return true;
		return false;
		} // is_this_ajax_plugin()

	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		// return '';	// default return
		if ($ajax == 'reloadGotchaCode') {
			$suffix = self::get_or_post('suffix');
			require_once CMS_FS_PLUGINS_DIR . self::PLUGIN . '/gotcha_code.php';	// include extra code
			$img = new Cgotcha_code($suffix);
			return $img->output_ajax();
			} // if
		return '';
		} // get_ajax_text()

	public static function generate($id,$suffix = '',$required = '',$class = false, $placeholder = false) {
		if(!self::is_plugin_enabled(self::PLUGIN)) return '';
		require_once CMS_FS_PLUGINS_DIR . self::PLUGIN . '/gotcha_code.php';	// include extra code
		$img = new Cgotcha_code($suffix);
		return $img->output_html($id,false,$required,$class,$placeholder);
		} // generate()

	public static function validate($code,$suffix = '') {
		if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		require_once CMS_FS_PLUGINS_DIR . self::PLUGIN . '/gotcha_code.php';	// include extra code
		$img = new Cgotcha_code($suffix);
		$res = $img->check($code);
		return $res;
		} // validate()

	public static function reset_cache($cli = false) {
		if(!$cli) {
			// later !!
			} // if

		if((!defined('VAR_FS_CACHE_GOTCHA_DIR')) ||
			(!is_dir(VAR_FS_CACHE_GOTCHA_DIR)))
			return 0;

		$files = scandir(VAR_FS_CACHE_GOTCHA_DIR);
		$cnt = 0;
		foreach($files as $f) {
			$fp = VAR_FS_CACHE_GOTCHA_DIR . $f;
			if((is_file($fp)) &&
				(self::is_file_usable($fp))) {
				@unlink($fp);
				$cnt++;
				} // if
			} // if
		self::addDebugMsg('Reset ' . $cnt . ' gotcha cache files.','info');
		return $cnt;
		} // reset_cache()

	public static function get_title() {	// get the plugin title
		return 'Gotcha';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The Gotcha plugin (' . self::PLUGIN . ') is an assistive plugin used by other plugins.'
			. ' The Gotcha plugin is a bot filtering plugin intended to stop erroroneous emails being sent.'
				. ' Sometimes called a captcha filter.'
				. ' It\'s not normal for this plugin to be called directly.'
			. '<br>NOTE: content using the gotcha plugin are not suitable for content caching.';
		} // get_description()

} // Ccms_gotcha_plugin