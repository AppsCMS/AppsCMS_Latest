<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_contactus.php 2067 2021-04-13 06:11:26Z robert0609 $
 */

/**
 * Description of Mailto plugin, emails messages to CMS_C_EMAIL_ADDRESS
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */

class Ccms_contactus_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_contactus';
	protected static $text_form = false;
	protected static $text_contacts = false;

	protected static $fail_msg_lev = 'warning';
	protected static $err_msgs_cnt = 0;	// error messages count to appear with input
	protected static $err_msgs = array(	// error messages to appear with input
//		// possible types
//		'SUBJECT' => array(),
//		'NAME' => array(),
//		'PHONE' => array(),
//		'EMAIL' => array(),
//		'MESSAGE' => array(),
//		'GOTCHA' => array(),
		);

	public static $msg_drop_box = true;

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(!self::is_plugin_enabled(self::PLUGIN)) {
			return false;
			} // if
		if(!defined('PL_CMS_CONTACTUS_EMAIL_ADDRESS')) define('PL_CMS_CONTACTUS_EMAIL_ADDRESS', '');	// @TODO why ??
		if(strlen(PL_CMS_CONTACTUS_EMAIL_ADDRESS) < 4) {
			if(strlen(CMS_C_EMAIL_ADDRESS) < 4) {
				if(Ccms_auth::is_admin_user()) {
					self::addMsg(self::get_cms_config_name('PL_CMS_CONTACTUS_EMAIL_ADDRESS') . ' and ' . self::get_cms_config_name('CMS_C_EMAIL_ADDRESS') . ' Not set up.','warning');
					} // if
				return false;
				} // if
			if(Ccms_auth::is_admin_user()) {
				self::log_msg(self::get_cms_config_name('PL_CMS_CONTACTUS_EMAIL_ADDRESS') . ' Not set up. Using ' . self::get_cms_config_name('CMS_C_EMAIL_ADDRESS') . '.','info');
				} // if
			} // if
		if(!Ccms_email_plugin::is_enabled()) {	// dependancy
			if(Ccms_auth::is_admin_user()) self::addMsg(self::PLUGIN . ' plugin needs the email plugin.','warning');
			return false;
			} // if
		if(!self::is_plugin_enabled(self::PLUGIN)) {
			if(Ccms_auth::is_admin_user()) self::addMsg(self::PLUGIN . ' plugin is disable.','warning');
			return false;
			} // if
		return true;
		} // is_enabled()

	public static function is_this_ajax_plugin($ajax) {	// required function, check for ownership of ajax op by this plugin
		if(!self::is_enabled()) return false;	// default return
		return false;	// no ajax on this plug
		} // is_this_plugin()

	protected static function add_err_msg($type,$msg) {
		if(!isset(self::$err_msgs[$type])) self::$err_msgs[$type] = array();
		self::$err_msgs[$type][] = $msg;
		self::$err_msgs_cnt++;
		self::log_msg($msg, self::$fail_msg_lev);
		} // add_err_msg()

	public static function get_msg_cnt_contactus() {
		$types = array(
			'SUBJECT',
			'NAME',
			'PHONE',
			'EMAIL',
			'MESSAGE',
			'GOTCHA',
			);
		$cnt = 0;
		foreach($types as $t) {
			$cnt += self::get_msg_cnt($t);
			} // foreach
		return $cnt;
		} // get_msg_cnt_contactus()

	protected static function get_msg_cnt($type) {
		if((!isset(self::$err_msgs[$type])) ||
			(count(self::$err_msgs[$type]) < 1))
			return false;	// no msg
		return count(self::$err_msgs[$type]);
		} // get_msg_cnt()

	protected static function get_msg($type,&$suffix) {
		if((!isset(self::$err_msgs[$type])) ||
			(count(self::$err_msgs[$type]) < 1)) {
			return '';	// no msg
			} // if

		$msg = ''; $msgs = '';
		foreach(self::$err_msgs[$type] as $m) {
			// if(!empty($msg)) $msg .= '<br>';	// @TODO for the moment
			$msg .= '<p class="__panel' . $suffix . '">';
			$msg .= self::make_message_text($m, 'required');
			$msg .= '</p>' . PHP_EOL;
			} // foreach
		if(self::$msg_drop_box) {
			$img = Ccms_msgs::get_msg_small_icon_text('required.gif','CMS_C_MSG_REQUIRED_ICON');
			$msgs .= '<span class="__cms_contactus_err_outer">' . PHP_EOL .
					'	' . $img . PHP_EOL .
					'	<span class="__cms_contactus_err_inner">' . PHP_EOL .
					'		' . $msg . PHP_EOL .
					'	</span>' . PHP_EOL .
					'</span>' . PHP_EOL;
			} // if
		else $msgs .= PHP_EOL . $msg . PHP_EOL;
		return $msgs;
		} // get_msg()

	protected static function &get_contact_defines() {
		static $contact_keys = array(
			0 => array(	// primary
				'prefix' => '',	// primary
				'title' => "OUR_CONTACT_TITLE",
				'name' => "OUR_CONTACT_NAME",
				'phone' => "OUR_PHONE_NUMBER",
				'fax' => "OUR_FAX_NUMBER",
				'email' => "OUR_EMAIL_ADDRESS",
				'web' => "OUR_WEB_URL",
				'postal' => "OUR_POSTAL_ADDRESS",
				'street' => "OUR_STREET_ADDRESS",
				),
			1 => array(	// second
				'prefix' => 'Second',	// primary
				'title' => "OUR_CONTACT_TITLE_2ND",
				'name' => "OUR_CONTACT_NAME_2ND",
				'phone' => "OUR_PHONE_NUMBER_2ND",
				'fax' => "OUR_FAX_NUMBER_2ND",
				'email' => "OUR_EMAIL_ADDRESS_2ND",
				'web' => "OUR_WEB_URL_2ND",
				'postal' => "OUR_POSTAL_ADDRESS_2ND",
				'street' => "OUR_STREET_ADDRESS_2ND",
				),
			2 => array(	// third
				'prefix' => 'Third',	// primary
				'title' => "OUR_CONTACT_TITLE_3RD",
				'name' => "OUR_CONTACT_NAME_3RD",
				'phone' => "OUR_PHONE_NUMBER_3RD",
				'fax' => "OUR_FAX_NUMBER_3RD",
				'email' => "OUR_EMAIL_ADDRESS_3RD",
				'web' => "OUR_WEB_URL_3RD",
				'postal' => "OUR_POSTAL_ADDRESS_3RD",
				'street' => "OUR_STREET_ADDRESS_3RD",
				),
			3 => array(	// fourth
				'prefix' => 'Fourth',	// primary
				'title' => "OUR_CONTACT_TITLE_4TH",
				'name' => "OUR_CONTACT_NAME_4TH",
				'phone' => "OUR_PHONE_NUMBER_4TH",
				'fax' => "OUR_FAX_NUMBER_4TH",
				'email' => "OUR_EMAIL_ADDRESS_4TH",
				'web' => "OUR_WEB_URL_4TH",
				'postal' => "OUR_POSTAL_ADDRESS_4TH",
				'street' => "OUR_STREET_ADDRESS_4TH",
				),
			);
		return $contact_keys;
		} // get_contact_defines()

	public static function get_contact_values() {	// public to allow other code to access
		$contact_keys = self::get_contact_defines();
		$prekey = 'PL_CMS_CONTACTUS_';
		$valkeys = array('title','name','phone','email','postal','street');
		$draw_flg=false;
		$text = '';
		for($i = 0; $i < count($contact_keys); $i++) {	// does this contain anything ??
			$ct = &$contact_keys[$i];
			foreach($valkeys as $k) {
				$v = constant($prekey . $ct[$k]);
				if(($k == 'name') && (empty($v))) break;	// no name
				if(($k == 'name') || ($k == 'title')) continue;	// need more than name and title
				if(!empty($v)) {
					$draw_flg = true;
					break;
					} // if
				} //foreach
			if($draw_flg) break;
			} // for
		if(!$draw_flg) return false;

		$contact_values = array();

		for($i = 0; $i < count($contact_keys); $i++) {
			$ct = &$contact_keys[$i];
			$contact_values[] = array(
				'prefix' => $ct['prefix'],
				'title' => constant($prekey . $ct['title']),
				'name' => constant($prekey . $ct['name']),
				'phone' => constant($prekey . $ct['phone']),
				'fax' => constant($prekey . $ct['fax']),
				'email' => constant($prekey . $ct['email']),
				'web' => constant($prekey . $ct['web']),
				'postal' => constant($prekey . $ct['postal']),
				'street' => constant($prekey . $ct['street']),
				);
			} // for
		return $contact_values;
		} // get_contact_values()

	protected static function generate_styles(&$text,&$suffix,&$class) {	// most positioning
		$text .= Ccms::page_start_comment(__FILE__ . '-' . __METHOD__,false);
		$text .= '<style>' . PHP_EOL;
		$text .= '	div.__panel' . $suffix . ' {' .
			//	'		align-content: center;' .
			//	'		margin: 0 auto;' .
			//	'		border:		2px solid #808080;' .
			//	'		padding: 0px;' .
			//	'		margin: auto;' .
			//	'		flex-wrap: wrap;' .
			//	'		flex-basis: auto;' .
			//	'		justify-content: center;' .
			//	'		flex-basis: 0 | auto;' .
				'		justify-content: center;' .
				'		flex-flow: row;' .
				'		display: flex;' .
				'		}' . PHP_EOL;

		$text .= '	p.__panel' . $suffix . ' {' .
				'		margin: 20x auto;' .
				'		padding: 0px;' .
				'		}' . PHP_EOL;
		$text .= '.contact_frm_inp' . $suffix . ' {' .
				'		width: calc(100% - 30px);' .
				'		}' . PHP_EOL;

		if(!empty(self::$text_contacts)) {
			$text .= '	div.__panel_contacts' . $suffix . ' {' .
					//'		width: 380px;' .
					//'		width: min-content;' .
					//'		border:		2px solid #808080;' .
					'		padding: 0px;' .
					'		margin: 5px;' .
			(!empty(self::$text_form) ? '		float: left;':'margin: 0 auto;') .
					'		}' . PHP_EOL;
			$text .= '	th.__panel_contact, td.__panel_contact {'.
				//	'		vertical-align: top;' .
					'		padding: 0px;' .
					'		margin: 0px;' .
					'		}' . PHP_EOL;

			$text .= '	div.__panel_contact' . $suffix . ' {' .
				//	'		width: min-content;' .
				//	'		vertical-align: top;' .
				//	'		border:		2px solid #808080;' .
					'		padding: 0px;' .
					'		margin: 0 auto;' .
				//	'		float: left;' .
					'		}' . PHP_EOL;
			} // if

		if(!empty(self::$text_form)) {
			$text .= '	div.__panel_feedback' . $suffix . ' {' .
					//'		width: 380px;' .
				//	'		margin: 0 auto;' .
					'		text-align: left;' .
					'		vertical-align: middle;' .
				//	'		border:		2px solid #808080;' .
					'		padding: 0px;' .
					'		margin: 5px;' .
			(!empty(self::$text_contacts) ? '		float: left;':'margin: 0 auto') .
					'		}' . PHP_EOL;
			} // if

		if((self::$msg_drop_box) &&
			(self::get_msg_cnt_contactus() > 0)) {// the error styles
			$text .= '	span.__cms_contactus_err_outer span {' . PHP_EOL;
			$text .= '		display: none;' . PHP_EOL;
//			$text .= '		background-color: inherit;' . PHP_EOL;
//			$text .= '		color:		inherit;' . PHP_EOL;
			$text .= '		font-family: inherit;' . PHP_EOL;
			$text .= '		font-size: inherit;' . PHP_EOL;
			$text .= '		font-weight: inherit;' . PHP_EOL;
			$text .= '		cursor: inherit;' . PHP_EOL;
			$text .= '		text-decoration: inherit;' . PHP_EOL;
			$text .= '		position: absolute;' . PHP_EOL;
//			$text .= '		position: relative;' . PHP_EOL;
//			$text .= '		right: unset;'	. PHP_EOL;
//			$text .= '		padding: unset;'	. PHP_EOL;
//			$text .= '		margin-left: unset;'	. PHP_EOL;
//			$text .= '		white-space: unset;'	. PHP_EOL;
			$text .= '		}' . PHP_EOL;

			$text .= '	.__cms_contactus_err_inner span {' . PHP_EOL;
			$text .= '		display: block;' . PHP_EOL;
//			$text .= '		background-color: inherit;' . PHP_EOL;
//			$text .= '		height: auto;' . PHP_EOL;
			$text .= '		border-radius: 0.5em;' . PHP_EOL;
			$text .= '		position: relative;' . PHP_EOL;
//			$text .= '		position: absolute;' . PHP_EOL;
//			$text .= '		right: unset;' . PHP_EOL;
			$text .= '		padding: 3px;' . PHP_EOL;
//			$text .= '		color: inherit;' . PHP_EOL;
//			$text .= '		font-family: inherit;' . PHP_EOL;
//			$text .= '		font-size: inherit;' . PHP_EOL;
//			$text .= '		font-weight: normal;' . PHP_EOL;
			$text .= '		outline: none;' . PHP_EOL;
//			$text .= '		cursor: inherit;' . PHP_EOL;
			$text .= '		z-index: 830;' . PHP_EOL;
//			$text .= '		text-decoration: none;' . PHP_EOL;
//			$text .= '		float: left;' . PHP_EOL;
			$text .= '		white-space: nowrap;' . PHP_EOL;
			$text .= '		top: -20px;' . PHP_EOL;
			$text .= '		left: 0px;' . PHP_EOL;
			$text .= '		}' . PHP_EOL;

			$text .= '	.__cms_contactus_err_outer:hover span {' . PHP_EOL;
			$text .= '		display: block;' . PHP_EOL;	// show inner
			$text .= '		}' . PHP_EOL;

			// Ccms_drop_box::init('__cms_contactus_err_outer', '__cms_contactus_err_inner');	// replace the classes
			} // if

			$text .= '	#id_gotcha_img' . $suffix . ' img {' . PHP_EOL;
			$text .= '		width: 210px;' . PHP_EOL;	/* original 280px wide */
			$text .= '		height: 75px;' . PHP_EOL;	/* original 100px high */
			$text .= '		}' . PHP_EOL;

		$text .= '</style>' . PHP_EOL;
		$text .= Ccms::page_end_comment(__FILE__ . '-' . __METHOD__,false);
		} // generate_styles()

	protected static function generate_contacts(&$suffix,&$class) {
		$contact_values = self::get_contact_values();
		if(empty($contact_values)) return false;

		$text = Ccms::page_start_comment(__FILE__ . '-' . __METHOD__,false);
		$text .= '<h2>Our contact details:</h2>' . PHP_EOL;

		for($i = 0; $i < count($contact_values); $i++) {
			$ct = &$contact_values[$i];
			$prefix = $ct['prefix'];
			$title = $ct['title'];
			$name = $ct['name'];
			$phone = $ct['phone'];
			$fax = $ct['fax'];
			$email = $ct['email'];
			$web = $ct['web'];
			$postal = $ct['postal'];
			$street = $ct['street'];
			if(empty($name)) continue;	// must have a name
			$tmp = ($phone . $email . $postal . $street);
			if(empty($tmp)) continue;	// must have something to talk to

			$text .= '<div class="__panel_contact' . $suffix . '_inner">' .
				'	<table class="' . $class . '">' . PHP_EOL;

//			$text .= '	<tr class="' . $class . '"><th class="' . $class . '">' . $prefix . '</th>' .
//					'<td class="' . $class . '">&nbsp;</td></tr>' . PHP_EOL;

			if(!empty($name))
				$text .= '	<tr class="' . $class . '">' .
				'<th class="' . $class . '">' . self::sanitiseText4Html($name) . '</th>' .
				'<td class="' . $class . '">' . (!empty($title) ? self::sanitiseText4Html($title):'&nbsp;') . '</td></tr>' . PHP_EOL;

			if(!empty($phone))
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '">Phone:</th>' .
					'<td class="' . $class . '"><a href="tel:' . preg_replace('/[^0-9+]+/','',$phone) . '">' . self::sanitiseText4Html ($phone) . '</a></td></tr>' . PHP_EOL;

			if(!empty($fax))
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '">Phone:</th>' .
					'<td class="' . $class . '">' . $fax . '</td></tr>' . PHP_EOL;

			if(!empty($email))
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '">Email:</th>' .
					'<td class="' . $class . '"><a href="mailto:' . $email . '">' . $email . '</a></td></tr>' . PHP_EOL;

			if(!empty($web))
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '">Web:</th>' .
					'<td class="' . $class . '"><a href="' . $web . '" target="_blank">' . $web . '</a></td></tr>' . PHP_EOL;

			if(!empty($postal))
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '">Postal Address:</th>' .
					'<td class="' . $class . '">' . self::nl2br ($postal) . '</td></tr>' . PHP_EOL;

			if(!empty($street))
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '">Street Address:</th>' .
					'<td class="' . $class . '">' . self::nl2br ($street) . '</td></tr>' . PHP_EOL;

			$text .= '</table></div>' . PHP_EOL;
			} // for

		$text .= Ccms::page_end_comment(__FILE__ . '-' . __METHOD__,false);
		return $text;
		} // generate_contacts()

	protected static function get_user_name() {
		if((Ccms_auth::is_user_logged_in()) &&
			(PL_CMS_CONTACTUS_COPY_EMAIL_TO_USER) &&
			(isset($_SESSION['user']['name'])) &&
			(!empty($_SESSION['user']['name']))) {
			return $_SESSION['user']['name'];
			} // if
		return false;
		} // get_user_name()

	protected static function get_user_phone() {
		if((Ccms_auth::is_user_logged_in()) &&
			(PL_CMS_CONTACTUS_COPY_EMAIL_TO_USER) &&
			(isset($_SESSION['user']['phone'])) &&
			(!empty($_SESSION['user']['phone']))) {
			return $_SESSION['user']['phone'];
			} // if
		return false;
		} // get_user_phone()

	protected static function get_user_email() {
		if((Ccms_auth::is_user_logged_in()) &&
			(PL_CMS_CONTACTUS_COPY_EMAIL_TO_USER) &&
			(isset($_SESSION['user']['email'])) &&
			(!empty($_SESSION['user']['email']))) {
			return $_SESSION['user']['email'];
			} // if
		return false;
		} // get_user_email()

	protected static function generate_feedback_form($form_id,&$suffix,&$class,$geo_flg,$msg_drop_box = true) {
		if(empty($form_id)) $form_id = 'plugin_' . self::PLUGIN;

		self::$msg_drop_box = $msg_drop_box;
		$f_url = self::get_current_body_uri();
		$f_url .= '&plugin=cms_contactus';
//		if(!empty(Ccms::$action)) $f_url .= '?action=' . urlencode(Ccms::$action) . '&plugin=cms_contactus';
//		else if(empty(Ccms::$body_name)) $f_url .= '?body=' . urlencode(Ccms::$body_name) . '&plugin=cms_contactus';
//		else $f_url .= '?plugin=contactus';

		$required = '<span class="cms_msg_warning" title="Required input.">&nbsp;***&nbsp;</span>';
		$optional = '<span class="cms_msg_info" title="Require telephone number or email address or both.">&nbsp;<small>optional</small>&nbsp;</span>';
		$email_done = false;
		$email_failed = false;
		if(PL_CMS_CONTACTUS_STAY_ON_PAGE) {
			if(self::has_email_been_sent()) $email_done = true;
			else if(self::has_email_send_failed()) $email_failed = true;
			} // if
		unset($_SESSION['contactus_emailed']);	// only once

		$text = Ccms::page_start_comment(__FILE__ . '-' . __METHOD__,false);
		$text .= '<h2>Send Us an Email:</h2>' . PHP_EOL;
		$text .= '<form name="' . $form_id . '" action="' . $f_url . '" method="post">' . PHP_EOL;
		if($email_done) $text .= '	<fieldset disabled>' . PHP_EOL;
		$text .= '<div class="__panel_feedback' . $suffix . '_inner">' .
				'	<table class="' . $class . '">' . PHP_EOL;	// extra style

		if(!$email_done) {
			if(strlen(PL_CMS_CONTACTUS_SUB_TITLE) > 0)
				$text .= '	<tr class="' . $class . '"><th class="' . $class . '"><h3>' . PL_CMS_CONTACTUS_SUB_TITLE . '</h3></th></tr>' . PHP_EOL;
			else
				$text .= '		<tr class="' . $class . '"><th class="' . $class . '"><h3>Send us an email. Please provide the following information:</h3></th></tr>' . PHP_EOL;
			} // if
		else $text .= '		<tr class="' . $class . '"><th class="' . $class . '"><h3>' . self::make_message_text('Email Sent', 'success') . '</h3></th></tr>' . PHP_EOL;

		if(strlen(PL_CMS_CONTACTUS_EMAIL_SUBJECT) > 4) {	// have a subject/s
			$subs = PL_CMS_CONTACTUS_EMAIL_SUBJECT;
			$text .= '		<tr class="' . $class . '"><th class="' . $class . '">Subject:</th></tr>' . PHP_EOL;
			$pre_subject = self::get_or_post('subject');
			$sub_flg = false; // select only one subjct
			$subjects = self::unserialize_string2arry($subs,':');
			if(count($subjects) > 1) {
				// make a dropdrop
				$db = '<select class="contact_frm_inp' . $suffix . '" name="' . self::PLUGIN . '_subject" title="Select email subject from list." required="on">';
				$db .= '<option value="" disabled selected hidden>  -- Select Subject -- </option>';
				foreach($subjects as $s) {
					if(is_array($s)) $v = $s[0];
					else $v = $s;
					$selected = '';
					if(!$sub_flg) { // select only one subjct
						if(self::get_or_post(self::PLUGIN . '_subject') == $v) $selected = 'SELECTED';
						else if((!empty($pre_subject)) && ($pre_subject == $v)) $selected = 'SELECTED';
						if(!empty($selected)) $sub_flg = true;
						} // if
					$db .= '<option value="' . htmlentities($v) . '"' . $selected . '>' .
							htmlentities($v) .
						'</option>';
					} // foreach
				$db .= '</select>';
				$text .= '		<tr class="' . $class . '"><td class="' . $class . '">' . $db . $required . '</td></tr>' . PHP_EOL;
				} // if
			else {
				if(is_array($subjects[0])) $v = $subjects[0][0];
				else $v = $subjects[0];
				$text .= '		<tr class="' . $class . '"><td class="' . $class . '">' . $v  . '</td></tr>' . PHP_EOL;
				} // else
			$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
			$text .= '			' . self::get_msg('SUBJECT',$suffix);
			$text .= '</td></tr>' . PHP_EOL;
			};

		$user_name = self::get_user_name();
		if(!$user_name) $user_name = '';
		$user_phone = self::get_user_phone();
		if(!$user_phone) $user_phone = '';
		$user_email = self::get_user_email();
		if(!$user_email) $user_email = '';

		$text .= '		<tr class="' . $class . '"><th class="' . $class . '">Your Name:</th></tr>' . PHP_EOL .
				'		<tr class="' . $class . '"><td class="' . $class . '"><input class="contact_frm_inp' . $suffix . '"  type="text" name="' . self::PLUGIN . '_name" size="30" value="' . (isset($_POST[self::PLUGIN . '_name']) ? $_POST[self::PLUGIN . '_name']:$user_name) . '" title="Minimum of 2 characters." autocapitalize="on" required="on">' . $required . '</td></tr>' . PHP_EOL;

		$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
		$text .= '			' . self::get_msg('NAME',$suffix);
		$text .= '</td></tr>' . PHP_EOL;

		if(PL_CMS_CONTACTUS_CUSTOMER_PHONE_NUMBER) {
			$text .= '		<tr class="' . $class . '"><th class="' . $class . '">Your Phone Number:</th></tr>' . PHP_EOL .
				'		<tr class="' . $class . '"><td class="' . $class . '"><input class="contact_frm_inp' . $suffix . '"  type="text" name="' . self::PLUGIN . '_phone" size="30" value="' . (isset($_POST[self::PLUGIN . '_phone']) ? $_POST[self::PLUGIN . '_phone']:$user_phone) . '" title="" autocapitalize="off"/>' . $optional . '</td></tr>' . PHP_EOL;

			$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
			$text .= '			' . self::get_msg('PHONE',$suffix);
			$text .= '</td></tr>' . PHP_EOL;
			} // if
		$text .= '		<tr class="' . $class . '"><th class="' . $class . '">Your Email Address:</th></tr>' . PHP_EOL .
				'		<tr class="' . $class . '"><td class="' . $class . '"><input class="contact_frm_inp' . $suffix . '"  type="text" name="' . self::PLUGIN . '_email" size="30" value="' . (isset($_POST[self::PLUGIN . '_email']) ? $_POST[self::PLUGIN . '_email']:$user_email) . '" title="" autocapitalize="off"/>' . (PL_CMS_CONTACTUS_CUSTOMER_PHONE_NUMBER ? $optional:$required) . '</td></tr>' . PHP_EOL;

		$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
		$text .= '			' . self::get_msg('EMAIL',$suffix);
		$text .= '</td></tr>' . PHP_EOL;

		$text .= '		<tr class="' . $class . '"><th class="' . $class . '" title="Message is emailed to ' . CMS_C_CO_NAME . '">Your Message:</th></tr>' . PHP_EOL .
				'		<tr class="' . $class . '"><td class="' . $class . '"><textarea class="contact_frm_inp' . $suffix . '"  name="' . self::PLUGIN . '_message" cols="40" rows="6" required="on">' . (isset($_POST[self::PLUGIN . '_message']) ? $_POST[self::PLUGIN . '_message']:'') . '</textarea>' . $required . '</td></tr>' . PHP_EOL;

		$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
		$text .= '			' . self::get_msg('MESSAGE',$suffix) . '</td></tr>' . PHP_EOL;

		if(strlen(PL_CMS_CONTACTUS_TERMS_MSG) > 8) {
			$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
			$text .= '			<input type="checkbox" name="' . self::PLUGIN . '_terms"' .
				(self::get_or_post_checkbox(self::PLUGIN . '_terms') ? ' CHECKED':'') .
				' REQUIRED>' .
				'&nbsp;' . PL_CMS_CONTACTUS_TERMS_MSG . ' ' . $required . '</td></tr>' . PHP_EOL;
			} // if

		if((!$email_done) && (Ccms_gotcha_plugin::is_enabled())) {
			$text .= '		<tr class="' . $class . '"><td class="' . $class . '">' . Ccms_gotcha_plugin::generate('gotcha_id',$suffix, $required) . '</td></tr>' . PHP_EOL;
			$text .= '		<tr class="' . $class . '"><td class="' . $class . '">';
			$text .= '			' . self::get_msg('GOTCHA',$suffix);
			$text .= '</td></tr>' . PHP_EOL;
			} // if
		if($email_done) {
			$sb = '';
			} // if
		else {
			$sb = '<button name="send" value="send" type="submit" title="Send email to ' . trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME)) . '">Send</button>' .
				'<button name="cancel" value="cancel" type="button"  onclick="location.href=\'index.php\';" title="Cancel sending email" formnovalidate>Cancel</button>';
			} // else

		$text .= '		<tr class="' . $class . '"><td class="' . $class . '" style="text-align: left;">' .
			(((Ccms_auth::is_user_logged_in()) && (PL_CMS_CONTACTUS_COPY_EMAIL_TO_SENDER)) ? '<input type="checkbox" name="copy2address"' . (self::get_or_post_checkbox('copy2address') ? ' CHECKED':'') . '>Copy to Address &nbsp;':'') .
			((!empty($user_email)) ? '<input type="checkbox" name="copy2user"' . (self::get_or_post_checkbox('copy2user') ? ' CHECKED':'') . '>Copy to User &nbsp;':'') .
			'&nbsp;' .
			$sb .
			'<input type="hidden" name="suffix" value="' . $suffix . '"/>' .
			'<input type="hidden" name="msg_drop_box" value="' . (self::$msg_drop_box ? 1:0) . '"/>' .
			'</td><tr>' . PHP_EOL;
		if($email_failed) $text .= '		<tr class="' . $class . '"><th class="' . $class . '">' . self::make_message_text('Email Failed', 'warning') . '</th></tr>' . PHP_EOL;
		$text .= '	</table></div>' . PHP_EOL;
		if((!$email_done) && ($geo_flg))
			$text .= Ccms::add_JS_geolcation_to_form(false,true);
		if($email_done) $text .= '	</fieldset>' . PHP_EOL;
		$text .= '</form>' . PHP_EOL;
		if($email_done) {
			$text .= '<div style="text-align: center;"><button name="close" value="close" type="button"  onclick="location.href=\'index.php\';" title="Close dialog">Close</button></div>';
			} // if

		// Ccms_drop_box::init();	// restore std classes
		$text .= Ccms::page_end_comment(__FILE__ . '-' . __METHOD__,false);
		return $text;;
		} // generate_feedback_form()

	public static function generate($form_id = '',$suffix = '_mt',$class = 'page_body',$geo_flg = true,$msg_drop_box = true) {
		if(!self::is_enabled()) return '';

		$text = Ccms::page_start_comment(__FILE__ . '-' . __METHOD__,false);
		self::generate_styles($text, $suffix, $class);
		$text .= '<div class="h1_' . $suffix . '"><h1>Contact Us</h1></div>' . PHP_EOL;
		self::$text_form = self::generate_feedback_form($form_id,$suffix,$class,$geo_flg,$msg_drop_box);
		self::$text_contacts = self::generate_contacts($suffix,$class);

//		$text .= '<table><tr><td>&nbsp;</td><td style="text-align: center;">' . PHP_EOL;
		$text .= '<div class="__panel' . $suffix . '">' . PHP_EOL;

		if(!empty(self::$text_contacts)) {
			$text .= '	<div class="__panel_contacts' . $suffix . '">' . PHP_EOL;
			$text .= self::$text_contacts;
			$text .= '	</div>' . PHP_EOL;
			} // if

		if(!empty(self::$text_form)) {
			$text .= '<div class="__panel_feedback' . $suffix . '">' . PHP_EOL;
			$text .= self::$text_form;
			$text .= '</div>' . PHP_EOL;
			} // if

		$text .= '</div>' . PHP_EOL;

		if((PL_CMS_CONTACTUS_SHOW_MSGS) && (self::getMsgsCount())) {
			$text .= '<div>' . Ccms::getMsgs() . '</div>';
			} // if
//		$text .= '</td><td>&nbsp;</td></tr></table>' . PHP_EOL;
		$text .= Ccms::page_end_comment(__FILE__ . '-' . __METHOD__,false);
		return $text;
		} // generate()

	public static function validate($code,$suffix = 'mt') {
		if(!self::is_enabled()) return false;
		if(Ccms_gotcha_plugin::is_enabled()) {
			return Ccms_gotcha_plugin::validate($code,$suffix);
			} // if
		return false;
		} // validate()

	protected static function send_contactus_mail(	// send customer contact email to owner (often overriden)
			$from_name,
			$from_address,
			$email_text,
			$fail_msg_lev = 'warning') {
		if(empty($email_text)) self::addMsg('No text message in contact email.',$fail_msg_lev);
		if(empty($from_name)) self::addMsg('No from contact name in email.',$fail_msg_lev);
		if(empty($from_address)) self::addMsg('No from contact email address.',$fail_msg_lev);

		if(isset($_POST[self::PLUGIN . '_subject'])) {
			$email_subject = $_POST[self::PLUGIN . '_subject'];
			if($email_subject == '-1') {
				$email_subject = 'No subject selected.';
				} // if
			} // if
		else $email_subject = ((strlen(PL_CMS_CONTACTUS_EMAIL_SUBJECT) > 4) ? PL_CMS_CONTACTUS_EMAIL_SUBJECT:'Contact Us') . ' from ' . $from_name;

		$to_name = trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME));
		$to_address = ((strlen(PL_CMS_CONTACTUS_EMAIL_ADDRESS) > 4) ? PL_CMS_CONTACTUS_EMAIL_ADDRESS:CMS_C_EMAIL_ADDRESS);
		if(Ccms::getMsgsCount('error')) return false;

		if(Ccms_auth::is_user_logged_in()) {
			if((self::get_or_post('copy2address')) && (PL_CMS_CONTACTUS_COPY_EMAIL_TO_SENDER)) {	// copy to address on form
				if(!Ccms_email_plugin::send_out_mail(
						$to_name,
						$from_address,
						$email_text,
						$email_subject . ' Copy of email sent to ' . CMS_C_CO_NAME,
						$from_name,
						$from_address))
					self::addMsg('Failed to send email copy to "' . $from_address . '".',$fail_msg_lev);
				} // if

			if((self::get_or_post_checkbox('copy2user')) &&
				($copy2user = self::get_user_email())) {	// copy to user
				if(!Ccms_email_plugin::send_out_mail(
						$to_name,
						$copy2user,
						$email_text,
						$email_subject . ' Copy of email to ' . CMS_C_CO_NAME,
						$from_name,
						$from_address))
					self::addMsg('Failed to send email copy to "' . $copy2user . '".',$fail_msg_lev);
				} // if
			} // if

		return Ccms_email_plugin::send_out_mail(
				$to_name,
				$to_address,
				$email_text,
				$email_subject,
				$from_name,
				$from_address);
		} // send_contactus_mail()

	public static function has_email_been_sent() {
		if(!isset($_SESSION['contactus_emailed'])) return false;
		return $_SESSION['contactus_emailed'];
		} // has_email_been_sent()

	public static function has_email_send_failed() {
		if(!isset($_SESSION['contactus_emailed'])) return false;
		return ($_SESSION['contactus_emailed'] ? false:true);
		} // has_email_send_failed()

	public static function execute_form($form_id = '', $fail_msg_lev = false, $exclude = '') {	// check form data and email stuff
		// get the data posts
		$name = self::get_or_post(self::PLUGIN . '_name');
		$email = self::get_or_post(self::PLUGIN . '_email');
		$message = self::get_or_post(self::PLUGIN . '_message');
		$suffix = self::get_or_post('suffix');
		$email_subject = self::get_or_post(self::PLUGIN . '_subject');
		$terms = self::get_or_post_checkbox(self::PLUGIN . '_terms');
		if(strlen(PL_CMS_CONTACTUS_TERMS_MSG) > 8) {
			if(!$terms) {
				self::log_msg ('TERMS','You need to agree to the terms.');
				} // if
			} // if
		self::$msg_drop_box = (self::get_or_post('msg_drop_box') ? true:false);

		unset($_SESSION['contactus_emailed']);
		if(($name === false) || ($email === false) || ($message === false) || ($suffix === false)) return false;	// not me
		if(Ccms_gotcha_plugin::is_enabled()) {
			$gotcha_text = self::get_or_post('gotcha_text' . $suffix);
			if($gotcha_text === false) return false;	// not me
			} // if

		if($fail_msg_lev) self::$fail_msg_lev = $fail_msg_lev;
		if(empty($form_id)) $form_id = 'plugin_' . self::PLUGIN;
		if(self::get_or_post('cancel') == 'cancel') return true;	// done
		if((self::get_or_post('send') == 'send')) {
			// process form
			$message = html_entity_decode($message);

			if($email_subject) {
				if($email_subject == '-1') self::add_err_msg('SUBJECT','Please select subject.');
				} // if
			else $email_subject = ((strlen(PL_CMS_CONTACTUS_EMAIL_SUBJECT) > 4) ? PL_CMS_CONTACTUS_EMAIL_SUBJECT:'Contact Us') . ' from ' . $name;

			if(strlen($name) < 2) {
				self::add_err_msg('NAME','Please enter your name. Minimum of 2 characters.');
				}
			if(strlen($message) < 2) {
				self::add_err_msg('MESSAGE','Please enter your message. Minimum of 2 characters.');
				}
			if(Ccms_gotcha_plugin::is_enabled()) {	// check gotcha
				if(!self::validate($gotcha_text,$suffix)) {
					self::add_err_msg('GOTCHA','Incorrect check code');	// bad gotcha
					} // if
				} // if
			$phone_text = '';
			if(PL_CMS_CONTACTUS_CUSTOMER_PHONE_NUMBER) {
				$chkr = new Ccms_config();	// use the phone number checker in the config class
				$phone = $chkr->get_phone_number(self::PLUGIN . '_phone', '', //
					array('func' => __CLASS__ . '::add_err_msg','param' => 'PHONE','type' => 'required'));	// chkr has reported problems
				if(!empty($phone)) {
					$phone_text = 'Customer telephone number for ' . $name . ': ' . $phone . PHP_EOL . PHP_EOL;
					} // if
				else self::log_msg ('PHONE','Phone number is invalid.');
				if(!empty($email)) {
					if(strlen($email) < 8) {
						self::log_msg('EMAIL','Please enter your email address. Minimum of 8 characters.');
						} // if
					else {
						$email = $chkr->get_email(self::PLUGIN . '_email', $email,	// callback
							array('func' => __CLASS__ . '::add_err_msg','param' => 'EMAIL','type' => 'required'));	// chkr has reported problems
						} // else
					} // if
				if((empty($phone)) && (empty($email))) {
					self::add_err_msg('EMAIL','Please enter your email address or your telephone number or both.');
					} // if
				else if (empty($email)) {	// no email address, but has a telephone number
					$email = ((strlen(PL_CMS_CONTACTUS_EMAIL_ADDRESS) > 4) ? PL_CMS_CONTACTUS_EMAIL_ADDRESS:CMS_C_EMAIL_ADDRESS);
					$email = preg_replace('/^.*@/', 'no_reply@', $email); // replace user
					$name = 'No Reply Email Address';
					} // else if
				} // if
			else {
				if(strlen($email) < 8) {
					self::add_err_msg('EMAIL','Please enter your email address. Minimum of 8 characters.');
					}
				else {
					$chkr = new Ccms_config();	// use the email address checker in the config class
					$email = $chkr->get_email(self::PLUGIN . '_email', $email,	// callback
						array('func' => __CLASS__ . '::add_err_msg','param' => 'EMAIL','type' => 'required'));	// chkr has reported problems
					} // else
				} // else
			if(self::$err_msgs_cnt) return false;	// input problems
			if(Ccms::getMsgsCount(self::$fail_msg_lev)) return false;	// bad

			// ok we can user message to CMS_C_EMAIL_ADDRESS
			// static instead of self so that we can override this in derived classes
			if(static::send_contactus_mail($name, $email, $phone_text . $message, self::$fail_msg_lev)) {
				$_SESSION['contactus_emailed'] = true;
				self::addMsg('Email sent.','success');
				if(PL_CMS_CONTACTUS_STAY_ON_PAGE) return false;	// dont goto home page
				return true;	// goto home page
				} // if
			} // if
		$_SESSION['contactus_emailed'] = false;
		return false;	// not me, but ???
		} // execute_form()

	public static function get_engage_uri() {	// default uri to engage plugin
		return htmlentities('<?php echo Ccms_contactus_plugin::generate(); // only in .php files ?>');
		} // get_engage_uri()

	public static function get_title() {	// get the plugin title
		return 'Contact Us';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The Contact Us plugin (' . self::PLUGIN . ') is used to generate a contact us email form.'
		. ' The email form is used to send emails from web site users.'
		. ' The Contact Us plugin requires the Email plugin to work.'
		. ' Optionally, the Contact Us can use the Gotcha plugin to stop bots form'
		. ' sending erroneous emails.'
		. ' To use the Contact Us plugin, enter "' . htmlentities('<?php echo Ccms_contactus_plugin::generate(); ?>') . '"'
		. ' into a .php file.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "SUB_TITLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Sub Title.",
				'cms_config_description' => "Sub title on page. If empty, no sub heading is used.",
				),	// row data
			array(
				'cms_config_key' => "EMAIL_SUBJECT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "Subject Choices",
				'cms_config_name' => "Email Subject.",
				'cms_config_description' => "Email subject to send on contactus emails.<br>" .
											"If empty, will use Contact Us.",
				'cms_config_show_func' => 'show_grid',
				'cms_config_input_func' => 'input_grid',
				'cms_config_save_func' => 'save_grid',
				),	// row data
			array(
				'cms_config_key' => "EMAIL_ADDRESS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Email Address.",
				'cms_config_description' => "Email address to send contact us emails to here. If empty will use the company / entity email address.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data

			array(
				'cms_config_key' => "OUR_CONTACT_TITLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Contact Title.",
				'cms_config_description' => "Title or purpose of person to contact us. If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_CONTACT_NAME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Contact Name.",
				'cms_config_description' => "Name of person to contact us. If empty, first contact details not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_PHONE_NUMBER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Phone Number.",
				'cms_config_description' => "Phone number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_FAX_NUMBER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Fax Number.",
				'cms_config_description' => "Fax number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_EMAIL_ADDRESS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Email Address.",
				'cms_config_description' => "Email address displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_WEB_URL",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Web Site URL.",
				'cms_config_description' => "Web site URL address on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_url",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_POSTAL_ADDRESS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Postal Address.",
				'cms_config_description' => "Postal address for mail contact us form for customers to contact us (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_STREET_ADDRESS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Our Street Address.",
				'cms_config_description' => "Street address or location customers (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data

			array(
				'cms_config_key' => "OUR_CONTACT_TITLE_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Contact Title.",
				'cms_config_description' => "Second title or purpose of person to contact us. If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_CONTACT_NAME_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Contact Name.",
				'cms_config_description' => "Second name of person to contact us. If empty, second contact details not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_PHONE_NUMBER_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Phone Number.",
				'cms_config_description' => "Second phone number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_FAX_NUMBER_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Fax Number.",
				'cms_config_description' => "Second fax number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_EMAIL_ADDRESS_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Email Address.",
				'cms_config_description' => "Second email address displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_WEB_URL_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Web Site URL.",
				'cms_config_description' => "Second web site URL address on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_url",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_POSTAL_ADDRESS_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Postal Address.",
				'cms_config_description' => "Second postal address for mail contact us form for customers to contact us (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_STREET_ADDRESS_2ND",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Second Street Address.",
				'cms_config_description' => "Second street address or location customers (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data

			array(
				'cms_config_key' => "OUR_CONTACT_TITLE_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Contact Title.",
				'cms_config_description' => "Third title or purpose of person to contact us. If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_CONTACT_NAME_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Contact Name.",
				'cms_config_description' => "Third name of person to contact us. If empty, third contact details not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_PHONE_NUMBER_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Phone Number.",
				'cms_config_description' => "Third phone number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_FAX_NUMBER_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Fax Number.",
				'cms_config_description' => "Third fax number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_EMAIL_ADDRESS_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Email Address.",
				'cms_config_description' => "Third email address displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_WEB_URL_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Web Site URL.",
				'cms_config_description' => "Third web site URL address on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_url",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_POSTAL_ADDRESS_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Postal Address.",
				'cms_config_description' => "Third postal address for mail contact us form for customers to contact us (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_STREET_ADDRESS_3RD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Third Street Address.",
				'cms_config_description' => "Third street address or location customers (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data

			array(
				'cms_config_key' => "OUR_CONTACT_TITLE_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Contact Title.",
				'cms_config_description' => "Fourth title or purpose of person to contact us. If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_CONTACT_NAME_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Contact Name.",
				'cms_config_description' => "Fourth name of person to contact us. If empty, fourth contact details not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_PHONE_NUMBER_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Phone Number.",
				'cms_config_description' => "Fourth phone number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_FAX_NUMBER_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Fax Number.",
				'cms_config_description' => "Fourth fax number displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_phone_number",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_EMAIL_ADDRESS_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Email Address.",
				'cms_config_description' => "Fourth email address displayed on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_WEB_URL_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Web Site URL.",
				'cms_config_description' => "Fourth web site URL address on contact us form for customers to contact us. If empty, not shown.",
				"cms_config_save_func" => "get_url",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_POSTAL_ADDRESS_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Postal Address.",
				'cms_config_description' => "Fourth postal address for mail contact us form for customers to contact us (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "OUR_STREET_ADDRESS_4TH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if not shown
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Fourth Street Address.",
				'cms_config_description' => "Fourth street address or location customers (Note: backslash n inserts a new line). If empty, not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data

			array(
				'cms_config_key' => "CUSTOMER_PHONE_NUMBER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",	// leave empty if no cc emails
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Request Customer Phone Number.",
				'cms_config_description' => "true = request customer phone number, false = customer phone number input not shown.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data

			array(
				'cms_config_key' => "STAY_ON_PAGE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",	// leave empty if no cc emails
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Stay on Page with Contact Us Form.",
				'cms_config_description' => "true = stay on the the page with the contact us form, false = go to home page after sending email.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "COPY_EMAIL_TO_SENDER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "false",	// leave empty if no cc emails
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Copy Email to Sender.",
				'cms_config_description' => "true = for logged in users copy email to address on form, false = no copy send.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "COPY_EMAIL_TO_USER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",	// leave empty if no cc emails
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Copy Email to Logged In User.",
				'cms_config_description' => "true = for logged in users copy email to address on form, false = no copy send.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SHOW_MSGS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",	// leave empty if no cc emails
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Show Messages in Contact Form.",
				'cms_config_description' => "true = show messages at the bottom of the contact us form, false = normal message processing.",
				"cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "TERMS_MSG",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_name' => "Terms of Use.",
				'cms_config_description' => "The terms of use of the ContactForm.<br>"
				. "If not empty, puts a checkbox at the beginning of the terms of use wording."
				. "The checkbox ticked is required, if present.",
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_contactus_plugin

