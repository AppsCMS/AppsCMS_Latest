<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_search.php 2070 2021-04-29 03:57:55Z robert0609 $
 */

/**
 *  * Description of cms_search
 *	* static class to provide theme, install and configuration option for display
 *	* an admin help class
 *
 * @author robert0609
 */
class Ccms_search extends Ccms_general {

	private static $allowed_page_tags = '<a><img>'; // to look inside these tags for values
	private static $exact_match = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function get_form_search_input_keywords_str() {
		if(self::is_get_or_post('keywords_inp')) // for ajax
			return trim(strtolower (Ccms::get_or_post('keywords_inp')));
		else if(self::is_get_or_post('keywords'))
			return trim(strtolower (Ccms::get_or_post('keywords')));
		else if(Ccms::is_get_or_post('search'))
			return trim(strtolower(Ccms::get_or_post ('search')));
		return false;
		} // get_form_search_input_keywords_str()

	public static function get_form_search_input_keywords_ary() {
		if(self::is_get_or_post('keywords_inp')) // for ajax
			$st = trim(Ccms::get_or_post('keywords_inp'));
		else if(self::is_get_or_post('keywords'))
			$st = trim(Ccms::get_or_post('keywords'));
		else if(Ccms::is_get_or_post('search'))
			$st = trim(Ccms::get_or_post ('search'));
		else false;
		if(empty($st)) return false;
		return explode(' ',$st);
		} // get_form_search_input_keywords_ary()

	public static function get_form_search_hidden_inputs() {
		if(self::is_get_or_post('keywords'))
			return '<input type="hidden" name="search" value="' . self::get_or_post('keywords') . '"/>';
		else if(self::is_get_or_post('search'))
			return '<input type="hidden" name="search" value="' . self::get_or_post('search') . '"/>';
		return '';
		} // get_form_search_hidden_inputs()

	public static function get_form_search_inputs($inc_form_vals = true) {
		if(!CMS_C_RETURN2SEARCH) return '';
		$h_vals = '';
		if(Ccms::is_get_or_post('search')) {
			if($inc_form_vals) $h_vals = '<input type="hidden" name="search" value="' . Ccms::get_or_post ('search') .'">';
			return $h_vals . '&nbsp;&nbsp;<span class="cms_msg_success"><a href="index.php?cms_action=cms_edit_search&search=' . urldecode(self::get_or_post('search')) . '" title="Search for: ' . urldecode(self::get_or_post('search')) . '" onclick="Ccms_cursor.setWait();">Return to search.</a></span>';
			} // if
		else if(Ccms::is_get_or_post('keywords')) {
			if($inc_form_vals) $h_vals = '<input type="hidden" name="keywords" value="' . Ccms::get_or_post ('keywords') .'">';
			return $h_vals . '&nbsp;&nbsp;<span class="cms_msg_success"><a href="index.php?cms_action=cms_edit_search&search=' . urldecode(self::get_or_post('keywords')) . '" title="Search for: ' . urldecode(self::get_or_post('keywords')) . '" onclick="Ccms_cursor.setWait();">Return to search.</a></span>';
			} // if
		return '';
		} // get_form_search_inputs()

	public static function chk_search_redirect($get_or_post_chks = false) {	// check if return to search
		$url = false;
		if($search = self::get_or_post('search')) {
			$url = 'index.php?cms_action=cms_edit_search&search=' . urlencode($search);
			} // if
		else if($keywords= self::get_or_post('keywords')) {
			$url = 'index.php?cms_action=cms_edit_search&search=' . urlencode($keywords);
			} // else if
		else return false;

		if(!empty($get_or_post_chks)) {
			$fnd = false;
			foreach($get_or_post_chks as $name) {
				if(self::get_or_post($name)) {
					$fnd = true;
					break;
					} // if
				} // foreach
			if(!$fnd) return false;
			} // if
		if(empty($url)) return false;
		header('Location: ' . $url);
		exit();
		} // chk_search_redirect()

	public static function make_meta_search_text($meta_ary) {
		if(!is_array($meta_ary)) return '';
		if(!CMS_C_SHOW_SEARCH_METADATA) return '';
		if((CMS_C_SHOW_SEARCH_METADATA === 'debug') && (!self::is_debug())) return '';
		$meta = '';
		$meta .= '&nbsp;(';
		$meta .= (((isset($meta_ary['exact'])) && ($meta_ary['exact'])) ? 'Exact, ':'');
		if(CMS_C_USE_LEVENSHTEIN_SEARCH) {;
			$meta .= (((isset($meta_ary['lev'])) && ($meta_ary['lev'])) ? 'Levenshtein, ':'');
			} // if
		if(CMS_C_USE_METAPHONE_SEARCH) {
			$meta .= (((isset($meta_ary['pho'])) && ($meta_ary['pho'])) ? 'Phonetic, ':'');
			} // if
		if(CMS_C_USE_SIMILAR_SEARCH) {
			$meta .= (((isset($meta_ary['sim'])) && ($meta_ary['sim'])) ? 'Similar, ':'');
			} // if
		$meta = substr($meta,0,-2);
		$meta .= ')';
		return self::make_message_brief_text($meta,'info','','Search match');
		} // make_meta_search_text()

	protected static function exact_search_cmp($keywords,$data) {	// return true if all keywords are matched (exactly) in data
		$exact = true;
		if(!is_array($keywords)) $keywords = explode(' ',$keywords);
		foreach($keywords as $w) {
			if(substr($w,0,1) == '!') {
				$ww = substr($w,1);
				if(stripos($data, $ww) !== false) {
					$exact = false;
					break;
					} // if
				} // if
			else if(stripos($data, $w) === false) {
				$exact = false;
				break;
				} // if
			} // foreach
		return $exact;
		} // exact_search_cmp()

	protected static function metaphone_search_cmp($a,$b) {	// return true alike, false too different
		// see "https://www.php.net/manual/en/function.metaphone.php"
		if(!CMS_C_USE_METAPHONE_SEARCH) return false;
		$phonemes = min(strlen($a),strlen($b));
		$a_metaphone = metaphone($a,$phonemes);
		$b_metaphone = metaphone($b,$phonemes);
		if($a_metaphone == $b_metaphone) return true;	// phonetically same
		$percent = 0.0;
		$likeness = similar_text($a_metaphone, $b_metaphone, $percent);
		if((int)$percent <= 60) return false;	// different
		return true; // alike
		} // metaphone_search_cmp()

	protected static function levenshtein_search_cmp($a,$b) {	// return true alike, false too different
		// see "https://www.php.net/manual/en/function.levenshtein.php"
		if(!CMS_C_USE_LEVENSHTEIN_SEARCH) return false;
		$threshold = min(strlen($a),strlen($b));
		$cost_ins = 4; $cost_rep = 1; $cost_del = 4;
		$lev = @levenshtein($a, $b, $cost_ins, $cost_rep, $cost_del);
		if($lev == -1) // string too long
			return false;	// no match
		if($lev == 0) return true;	// exact match
		if($lev > $threshold) return false;	// different
		return true;	// small difference, alike
		} // levenshtein_search_cmp()

	protected static function similarity_search_cmp($a,$b) {	// return true alike, false too different
		// see "https://www.php.net/manual/en/function.similar-text.php"
		if(!CMS_C_USE_SIMILAR_SEARCH) return false;
		$percent = 0.0;
		$likeness = similar_text($a, $b, $percent);
		if((int)$percent <= 60) return false;	// different
		return true; // alike
		} // similarity_search_cmp()

	public static function search_cmp($keywords,$data, $exact_match = false) {	// return true meta array() if found else false
		$exact = false; $lev = false; $pho = false; $sim = false;
		if(is_array($keywords)) $keywords_str = implode(' ',$keywords);
		else $keywords_str = $keywords;
		$found = true;
		if(($exact_match) || (self::$exact_match)) {
			if(!$exact = self::exact_search_cmp($keywords,$data))
				$found = false;
			} // if
		else if((!$exact = self::exact_search_cmp($keywords,$data)) &&
			(!$lev = self::levenshtein_search_cmp($keywords_str, $data)) &&
			(!$pho = self::metaphone_search_cmp($keywords_str, $data)) &&
			(!$sim = self::similarity_search_cmp($keywords_str, $data))) {
			$found = false;
			} // if
		if(!$found) return false;
		$meta = array( 'exact' => $exact, 'lev' => $lev, 'pho' => $pho, 'sim' => $sim,);
		return $meta;
		} // search_cmp()

	private static function get_allowed_tags_text() {
		return ((!empty(self::$allowed_page_tags)) ? 'or ' . htmlentities(self::$allowed_page_tags) . ' tags ':'');
		} // get_allowed_tags_text()

	private static function search_array($keywords_str,$data,$uri_prefix) {
		$result = array();
		if(isset($data['comment'])) unset($data['comment']);
		$keywords = preg_split('/ /', $keywords_str);
		foreach($data as $n => $v) {
			$found = true;
			$d = strtolower(($n . ' ' . $v));	// join the name and value
			if(!$meta = self::search_cmp($keywords, $d)) {
				$found = false;
				} // if
			if($found) {	// make result text
				$result[] = array(
					'url' => $uri_prefix . '&name=' . urlencode($n) . '&keywords=' . urlencode(implode(' ',$keywords)),
					'text' => '<strong>' . Ccms::make_nice_name($n) . '</strong>' . ' = "' . preg_replace('/( - -|")/', '', (!empty($v) ? $v:'<b>(empty)</b>')) . '"',
					'meta' => $meta,
					);
				} // if
			} // foreach
		return $result;
		} // search_array()

	private static function join_arrays($search_ore,$prefix = false) {
		$data = array();
		for($i = 0; $i < count($search_ore); $i++) {
			$ore = &$search_ore[$i];
			if($ore) {
				if(is_array($ore)) {
					foreach($ore as $n => $v) {
						if(is_array($v))
							$val = implode(' ',self::flatten_array ($v));
						else $val = $v;
						$idx = ($prefix ? $prefix . '_' . $n : $n);
						if(!isset($data[$idx])) $data[$idx] = '"' . $val . '"';	// should be the value first
						else  $data[$idx] .= ' - ' . $val;
						} // foreach
					} // if
				else {
					// what error !!!
					} // else
				} // if
			} // for
		ksort($data);
		return $data;
		} // join_arrays()

	private static function join_comments_settings_sections(&$comments,&$settings,$extras = false) {
		// up the sections
		$search_ore = array();
		foreach($comments as $sect => &$c_vals) {
			if($c_vals == 'comment') continue;
			if(!is_array($c_vals)) continue;
			foreach($c_vals as $key => $cmt) {
				if($key == 'comment') continue;
				$name = $sect . '_' . $key;
				$value = '';
				if(isset($settings[$sect][$key])) {
					$val = $settings[$sect][$key]; // value first
					if(!empty($val)) $value .= $val;
					else $value .= '(empty)';
					$value .= ' - ';
					} // if
				$value .= (is_array($cmt) ? implode(' ',$cmt):$cmt);	// ?? array ??
				$search_ore[][$name] = $value;
				} // foreach
			} // foreach
		if($extras) $search_ore[] = $extras;
		return self::join_arrays($search_ore);
		} // join_comments_settings_sections()

	protected static function search_ext_apps($keywords) {
		if(/*(!self::is_apps_extend_static_func('get_admin_uris')) ||*/
			(!self::is_apps_extend_static_func('read_apps_extend_settings_ini')) ||
			(!self::is_apps_extend_static_func('read_apps_extend_comments_ini'))) {
			return false;
			} // if
//		$app_admin_uris = self::get_admin_uris();
//		if(is_null($app_admin_uris)) return false;
//		for($i = 0; $i < count($app_admin_uris); $i++) {
//			$uri = &$app_admin_uris[$i];
//			} // for
		$ext_settings = self::read_apps_extend_settings_ini();
		$ext_comments = self::read_apps_extend_comments_ini();
		if((empty($ext_settings)) || (empty($ext_comments))) return false;

		$result = array();
		$exts = count($ext_comments);
		for($i = 0; $i < $exts; $i++) {
			$settings = &$ext_settings[$i];
			$comments = &$ext_comments[$i];
			$extras = array();
			$scrs = $extras;	//array($extras);
			foreach($settings as $k => $v) {
				$scrs = array_merge (
					$scrs,
					self::join_arrays(array($settings[$k]),$k)
					);
				} // foreach
			$data = self::join_arrays(array($scrs));
			$result = array_merge($result,self::search_array($keywords, $data, 'index.php?cms_action=apps_extend&idx=' . ($i + 1)));
			} // for
		$result['title'] = 'Found in ' . $exts . ' App Extend Settings.';
		return $result;
		} // search_ext_apps()

	protected static function search_apps($keywords) {
		$settings = Ccms_apps::read_apps_ini_settings();
		$comments = Ccms_apps::read_apps_ini_comments();
		if((empty($settings)) || (empty($comments))) return false;
		$data = self::join_comments_settings_sections($comments,$settings);
		$result = self::search_array($keywords, $data, 'index.php?cms_action=cms_edit_apps');
		$result['title'] = 'Found in App Local Settings.';
		return $result;
		} // search_apps()

	protected static function search_install($keywords) {
		$settings = self::read_cms_ini_settings(false,self::get_theme_ini_sections());
		$comments = self::read_cms_ini_comments(false,self::get_theme_ini_sections());	// get control file
		$extras = array( 'DEFAULT_INSTALL_BUTTON' => 'Set all install values to default.',);
		$data = self::join_comments_settings_sections($comments,$settings,$extras);
		$result = self::search_array($keywords, $data, 'index.php?cms_action=cms_edit_install');
		$result['title'] = 'Found in Install Settings.';
		return $result;
		} // search_install()

	protected static function search_theme($keywords) {
		$settings = self::read_cms_ini_settings(false,self::get_install_ini_sections());
		$comments = self::read_cms_ini_comments(false,self::get_install_ini_sections());	// get control file
		$extras = array( 'DEFAULT_THEME_BUTTON' => 'Set all theme values to default theme.',);
		$data = self::join_comments_settings_sections($comments,$settings,$extras);
		$result = self::search_array($keywords, $data, 'index.php?cms_action=cms_edit_theme');
		$result['title'] = 'Found in Theme Settings.';
		return $result;
		} // search_theme()

	private static function search_body_text($keywords,$id) {
		$cms_body_file = self::$cDBcms->get_data_in_table('cms_bodies','cms_body_file','cms_body_id = ' . (int)$id);
		if(!$cms_body_file) return false;
		$filename = PAGE_BODIES_FS_DIR . $cms_body_file;
		if((!file_exists($filename)) || (!is_readable($filename))) return false;
		$page_text = strtolower(strip_tags(file_get_contents($filename),self::$allowed_page_tags));
		$found = true;
		foreach($keywords as $w) {
			if(strpos($page_text, strtolower($w)) === false) {
				$found = false;
				break;
				} // if
			} // foreach
		return $found;
		} // search_body_text()

	private static function search_custom_header($keywords_str) {
		$result = array();
		$filename = PAGE_HEADER_FS_INC;
		if((!CMS_C_CUSTOM_HEADER) ||
			(!file_exists($filename)) ||
			(!is_readable($filename)))
			return $result;
		$page_text = strtolower(strip_tags(file_get_contents($filename),self::$allowed_page_tags));
		$found = true;
		$keywords = preg_split('/ /', $keywords_str);
		if(!$meta = self::search_cmp($keywords, $page_text)) {
			$found = false;
			} // if
		if($found) {
			$result[] = array(
				'url' => 'index.php?cms_action=cms_edit_header_footer&edit=custom_header' . '&name=custom&keywords=' . urlencode(implode(' ',$keywords)),
				'text' => '<strong>' . 'Custom Header' . ':</strong>' . ' has text ' . self::get_allowed_tags_text() . 'that matches the keywords.',
				'meta' => array( 'exact' => $meta['exact'], 'lev' => $meta['lev'], 'pho' => $meta['pho'], 'sim' => $meta['sim'],),
				);
			} // if
		$result['title'] = 'Found in Custom Header.';
		return $result;
		} // search_custom_header()

	private static function search_custom_footer($keywords_str) {
		$result = array();
		$filename = PAGE_FOOTER_FS_INC;
		if((!CMS_C_CUSTOM_FOOTER) ||
			(!file_exists($filename)) ||
			(!is_readable($filename)))
			return $result;
		$page_text = strtolower(strip_tags(file_get_contents($filename),self::$allowed_page_tags));
		$found = true;
		$keywords = preg_split('/ /', $keywords_str);
		if(!$meta = self::search_cmp($keywords, $page_text)) {
			$found = false;
			} // if
		if($found) {
			$result[] = array(
				'url' => 'index.php?cms_action=cms_edit_header_footer&edit=custom_footer' . '&name=custom&keywords=' . urlencode(implode(' ',$keywords)),
				'text' => '<strong>' . 'Custom Footer' . ':</strong>' . ' has text ' . self::get_allowed_tags_text() . 'that matches the keywords.',
				'meta' => $meta,
				);
			} // if
		$result['title'] = 'Found in Custom Footer.';
		return $result;
		} // search_custom_footer()

	private static function search_DB_extras($table,&$row,&$result) {
		if($table == 'cms_configs') {
			switch($row['cms_config_key']) {
				case 'CMS_C_ENABLED_PLUGINS':	// show all available plugins
					$cCNF = new Ccms_config();
					$plugins = $cCNF->get_plugins('');
					$pls = array();
					foreach($plugins as $pl => &$v) $pls[] = $pl;
					$row['cms_config_value'] = implode(' ',$pls);
					$row['cms_config_key'] = 'Plugins';
					break;
				default:
					break;
				} // switch
			} // if
		} // search_DB_extras()

	private static function search_DB($keywords_str,$table,$cols,$uri_prefix,$search_body_text = false) {
		$result = array();
		$sql_query = "SELECT " . implode(',',$cols) .
			" FROM " . $table;
		$keywords = preg_split('/ /', $keywords_str);
		if(($sql_result = self::$cDBcms->query($sql_query)) &&
			(self::$cDBcms->num_rows($sql_result) > 0)) {
			while($row = self::$cDBcms->fetch_array($sql_result)) {
				self::search_DB_extras($table, $row, $result);
				$subject = '';
				for($i = 0; $i < count($cols); $i++) {
					if(!empty($row[($cols[$i])])) {
						if(!empty($subject)) $subject .= ' - ';	// joiner/delim
						$sub = $row[($cols[$i])];
						if(($i == 2) &&	// value
							($vg = @unserialize($sub,array()))) { // check if serialized
							$sub = self::serialize_array2string($vg);
							} // if
						$subject .= $sub;
						} // if
					} // for
				$id = $row[$cols[0]];	// [0] has id
				unset($row[$cols[0]]);
				$n = $row[$cols[1]];	// [1] is the key or name
				unset($row[$cols[1]]);
				$v = $row[$cols[2]];	// [2] is the value
				unset($row[$cols[2]]);
				if($vg = @unserialize($v,array())) { // check if serialized
					$v = self::serialize_array2string($vg);
					} // if
				$rest = (!empty($row) ? ' - ' . implode(' - ',$row):'');
				$found = true;
				$d = strtolower($subject);
				if(!$meta = self::search_cmp($keywords_str, $d)) {
					$found = false;
					} // if
				if($found) {	// make result text
					$result[] = array(
						'url' => $uri_prefix . $id . '&name=' . urlencode($n) . '&keywords=' . urlencode(implode(' ',$keywords)),
						'text' => '<strong>' . Ccms::make_nice_name($n) . '</strong>' . ' = "' . preg_replace('/ - -/', '', (!empty($v) ? $v:'(empty)')) . '"' .$rest,
						'meta' => $meta,
						);
					} // if
				if(($search_body_text) && (self::search_body_text($keywords,$id))) {
					$result[] = array(
						'url' => $uri_prefix . $id . '&name=' . urlencode($n) . '&keywords=' . urlencode(implode(' ',$keywords)),
						'text' => '<strong>' . Ccms::make_nice_name($n) . ':</strong>' . ' has page body text ' . self::get_allowed_tags_text() . 'that matches the keywords.',
						);
					} // if
				} // while
			} // if
		return $result;
		} // search_DB()

	protected static function search_users($keywords) {
		$result = array();
		$cols = array('cms_user_id', 'cms_user_name','cms_user_email','cms_user_mobile','cms_user_comments');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'cms_users', $cols, 'index.php?cms_action=cms_edit_users&user_edit_id=');
		$result['title'] = 'Found in Users.';
		return $result;
		} // search_users()

	protected static function search_groups($keywords) {
		$result = array();
		$cols = array('cms_group_id', 'cms_group_name','cms_group_description','cms_group_comments');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'cms_groups', $cols, 'index.php?cms_action=cms_edit_groups&group_edit_id=');
		$result['title'] = 'Found in Groups.';
		return $result;
		} // search_groups()

	protected static function search_sections($keywords) {
		$result = array();
		$cols = array('lm_section_id', 'lm_section_name', 'lm_section_description', 'lm_section_title','lm_section_comments');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'lm_sections', $cols, 'index.php?cms_action=cms_edit_sections&section_edit_id=');
		$result['title'] = 'Found in Sections.';
		return $result;
		} // search_sections()

	protected static function search_links($keywords) {
		$result = array();
		$cols = array('lm_link_id', 'lm_link_name', 'lm_link_description', 'lm_link_title', 'lm_link_url','lm_link_comments');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'lm_links', $cols, 'index.php?cms_action=cms_edit_links&link_edit_id=');
		$result['title'] = 'Found in Links.';
		return $result;
		} // search_links()

	protected static function search_body_pages($keywords) {
		$result = array();
		$cols = array('cms_body_id', 'cms_body_name', 'cms_body_file', 'cms_body_title', 'cms_body_meta_description','cms_body_meta_description','cms_body_meta_keywords','cms_body_icon_url','cms_body_image_url','cms_body_terms_url','cms_body_acknowledgment_url','cms_body_release_notes_url','cms_body_readme_url','cms_body_licence_url','cms_body_comments','cms_body_package_excludes');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'cms_bodies', $cols, 'index.php?cms_action=cms_edit_bodies&body_edit_id=',true);
		$result['title'] = 'Found in Page Bodies / Apps Control.';
		return $result;
		} // search_body_pages()

	protected static function search_tools($keywords) {
		$result = array();
		$cols = array('cms_tool_id', 'cms_tool_name', 'cms_tool_url', 'cms_tool_title', 'cms_tool_description','cms_tool_icon_url','cms_tool_image_url','cms_tool_terms_url','cms_tool_acknowledgment_url','cms_tool_licence_url,cms_tool_readme_url,cms_tool_release_notes_url','cms_tool_comments','cms_tool_package_excludes');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'cms_tools', $cols, 'index.php?cms_action=tool&tool_id=');
		$result['title'] = 'Found in Tools.';
		return $result;
		} // search_tools()

	protected static function search_config($keywords) {
		$result = array();
		$cols = array('cms_config_id', 'cms_config_key','cms_config_value', 'cms_config_name','cms_config_description','cms_config_comments');	// [0] is the id, [1] is the key
		$result = self::search_DB($keywords, 'cms_configs', $cols, 'index.php?cms_action=cms_edit_config&config_edit_id=');
		$result['title'] = 'Found in Config Settings.';
		return $result;
		} // search_config()

	public static function search($keywords = false,$exact_match = false) {
		if(!$keywords) $keywords = self::get_form_search_input_keywords_str();
		if(empty($keywords)) {
			return array();
			} // if
		if($exact_match === false) {
			$exact_match = self::get_or_post_checkbox('exact');
			} // if
		self::$exact_match = $exact_match;
		$results = array('keywords' => $keywords,'exact' => $exact_match);
		$results['users'] = self::search_users($keywords);
		$results['groups'] = self::search_groups($keywords);
		$results['links'] = self::search_links($keywords);
		$results['sections'] = self::search_sections($keywords);
		$results['header'] = self::search_custom_header($keywords);
		$results['bodies'] = self::search_body_pages($keywords);
		$results['footer'] = self::search_custom_footer($keywords);
		$results['tools'] = self::search_tools($keywords);
		$results['config'] = self::search_config($keywords);
		$results['apps'] = self::search_apps($keywords);
		$results['apps_ext'] = self::search_ext_apps($keywords);
		$results['install'] = self::search_install($keywords);
		$results['theme'] = self::search_theme($keywords);
		return $results;
		} // search()

	public static function help() {
		$text = "Enter filter/search keywords, separated by spaces, to search Users, Groups, Pages, Links, Tools, Config, Install and Theme.";
		return $text;
		} // help()

} // Ccms_search
