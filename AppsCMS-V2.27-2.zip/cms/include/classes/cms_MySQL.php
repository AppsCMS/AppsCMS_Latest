<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_MySQL.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description
 * cms_mysql functions wrapper and easy access class
 *
 * @author robert0609
 */

class Ccms_MySQL extends Ccms_database_mysql {

	function __construct($create = false,$admin_user = '',$admin_passwd = '') {

		// use AppsCMS INI settimgs
		$db_inuse = ((Ccms::get_cms_ini_value('DB_MYSQL_USE_BOOL','DataBaseAccess') != 'true') ? false:true);
		if((!$db_inuse) && (!$create)) return;	// not used
		$db_user = Ccms::get_cms_ini_value('DB_MYSQL_USERNAME','DataBaseAccess');
		$db_passwd = Ccms::get_cms_ini_value('DB_MYSQL_PASSWORD','DataBaseAccess');
		$db_name = Ccms::get_cms_ini_value('DB_MYSQL_DATABASE','DataBaseAccess') . (self::is_debug() ? '_TEST':'');
		$db_host = Ccms::get_cms_ini_value('DB_MYSQL_HOST_URL','DataBaseAccess');
		$db_port = Ccms::get_cms_ini_value('DB_MYSQL_HOST_PORT','DataBaseAccess');
		if((empty($db_user)) && (empty($db_passwd)) && (empty($db_name))) return;	// doing a separate open

		if($create) {
			if((empty($admin_user)) || (empty($admin_passwd))) {
				self::addMsg('Missing ' . CMS_PROJECT_SHORTNAME . ' admin user or admin password for "' . $db_host . '".');
				return;
				} // if
			if(!Ccms_database_mysql::install_user_privileges_database($admin_user,$admin_passwd,
					$db_user,$db_passwd,$db_host,$db_name)) {
				self::addMsg('Failed to create ' . CMS_PROJECT_SHORTNAME . ' MySQL database and user on "' . $db_host . '".');
				return;
				} // if
			} // if
		if(!$db_inuse) return;

		$db_timeout = 10000;
		parent::__construct($db_user, $db_passwd, $db_name, $db_host, $db_port, $db_timeout);
		if($create) {
			$this->m_bNew = true;
			$this->init(true);
			} // if
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// methods
	public function init($install_tables) {
		if(!$this->is_ok()) return false;
		if(($this->m_bNew) || ($install_tables === true)) {
			if(!self::is_debug()) {
				die('ERROR: Failed to open MySQL DB.');
				return false;
				} // if
			else if(!$this->installDataBase()) {
				die('ERROR: Failed to install MySQL DB tables.');
				return false;
				} // if
			} // if
		$this->m_bNew = false;
		return true;
		} // init()

	public function installDatabase($table = '', $verbose = false, $drop = false) {
		$cCMSi = new Ccms_DB_install();
		$install_scripts = $cCMSi->get_installDBscriptsMySQL();

		$res = $this->install_db_tables($table,$install_scripts,true,$drop);
		if(($res) &&
			(($table == 'cms_configs') || (empty($table)))) {
			$plugins = Ccms::get_cms_config_value('CMS_C_ENABLED_PLUGINS');
			Ccms::do_plugin_installs($plugins);
			} // if
		return $res;
		} // installDatabase()


} // Ccms_MySQL
