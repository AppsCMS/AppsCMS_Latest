<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_general.php 2067 2021-04-13 06:11:26Z robert0609 $
 */

/**
 * Description of cms_general
 * general base class for cms functions
 *
 * @author robert0609
 */

class Ccms_general extends Ccms_base {

	public static $cAL = false;

	protected static $ssl_context = false;

	private static $install_settings_done = false;

	const PRE_DEF_APPs_WS_DIR = "APPs_WS_";
	const PRE_DEF_APPs_FS_DIR = "APPs_FS_";

	const INLINE_IMG_MIN_SIZE = 100;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// dynamic methods

	private function get_cms_page_title($cms_action, $delimiter = ' - ') { // set page title, a bit of basic SEO
		$title = CMS_C_TITLE;
		switch($cms_action) {
		case 'home':
			// $title .= $delimiter . 'Home';
			break;
		case 'tool':
			if((($tool_id = (int)self::$tool_id) > 0) &&
				($name = self::$cDBcms->get_data_in_table('cms_tools','cms_tool_name','cms_tool_id = ' . $tool_id)) &&
				(!empty($name))) {
				$title .= $delimiter . $name;
				} // if
			break;
		case 'cms_login':
			$title .= $delimiter . 'Login';
			break;
		case 'get_password':
			$title .= $delimiter . 'Change Password';
			break;
		case 'cms_edit_tools':
			$title .= $delimiter . 'Edit Tools';
			break;
		case 'cms_edit_bodies':
			$title .= $delimiter . 'Edit Page Bodies / Apps Control';
			break;
		case 'cms_edit_sections':
			$title .= $delimiter . 'Edit Sections';
			break;
		case 'cms_edit_links':
			$title .= $delimiter . 'Edit Links';
			break;
		case 'cms_edit_groups':
			$title .= $delimiter . 'Edit Groups';
			break;
		case 'cms_edit_users':
			$title .= $delimiter . 'Edit Users';
			break;
		case 'cms_edit_search':
			$title .= $delimiter . 'Admin Search';
			break;
		case 'cms_edit_install':
			$title .= $delimiter . 'Edit Installation';
			break;
		case 'cms_edit_theme':
			$title .= $delimiter . 'Edit Theme';
			break;
		case 'cms_edit_config':
			$title .= $delimiter . 'Edit Config';
			break;
		case 'cms_about':
			$title .= $delimiter . 'About ' . CMS_PROJECT_SHORTNAME;
			break;
		case 'cms_manual':
			$title .= $delimiter . CMS_PROJECT_SHORTNAME . ' Technical Manual';
			break;
		case 'cms_debug':
			$title .= $delimiter . CMS_PROJECT_SHORTNAME . ' Debug';
			break;
		case 'cms_doxy':
			$title .= $delimiter . CMS_PROJECT_SHORTNAME . ' Doxygen Source Code Documents';
			break;
		default:
			break;
		} // switch
		return $title;
		} // get_cms_page_title()

	private function get_page_title($action,$body_id, $delimiter = ' - ') { // set page title, a bit of basic SEO
		$title = CMS_C_TITLE;
		switch($action) {
		case 'home':
			// $title .= $delimiter . 'Home';
			break;
		case 'body':
		default:
			if(!empty($body_id)) $title .= $delimiter . self::$body_name;
			break;
		} // switch
		return $title;
		} // get_page_title()

	private function is_api_call() {
		// used to detect API calls to apps code
		if((isset($_SERVER['PHP_SELF'])) &&
			(preg_match('/\/api.php|\/api\/.+/',$_SERVER['PHP_SELF']))) return true;
		return false;
		} // is_api_call()

	private function is_ssl_available($domain = false, $check_dom = false) {	// check if $domain has SSL certificate

		$connection_context_option = array(
			'ssl' => array(
				'capture_peer_cert' => true,
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true,
				),
			);
		$stream = stream_context_create($connection_context_option);

		if(!$domain) $domain = CMS_DOMAIN;	// it's me !!!!
		$url = 'ssl://' . $domain . ':443';
		$socket = @stream_socket_client($url, $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $stream );

		if($socket) {
			if(!$check_dom) {	// quick and dirty for redirect
				fclose($socket);
				return true;
				} // if
			// check here if the certificate domain same name.
			$cont = stream_context_get_params( $socket );
			$cert_ressource = $cont['options']['ssl']['peer_certificate'];
			$cert = openssl_x509_parse( $cert_ressource );
			fclose($socket);

			// @TDOD (maybe) check further.

			if($cert['subject']['CN'] == $domain) {
				return true;
				} // if
			self::log_msg('SSL cert is for "' . $cert['subject']['CN'] . '" and does not match "' . $domain . '".');
			} // if
		return false;
		} // is_ssl_available()

	private function is_ssl_required() {
		if(self::is_cli())
			self::$ssl_required = false;
		else if(!empty(self::$ajax)) {	// match the original web site for ajax
			if((isset($_SERVER['HTTPS'])) &&
				($_SERVER['HTTPS'] == 'on'))
				self::$ssl_required = true;
			else self::$ssl_required = false;
			} // if
		else if(INI_ALLOW_NON_SSL_LOGIN_BOOL)
			self::$ssl_required = false;
		else if(INI_ALWAYS_USE_SSL_BOOL)
			self::$ssl_required = true;
		else if((INI_API_USE_SSL_BOOL) && ($this->is_api_call()))
			// if the api caller is not on
			self::$ssl_required = true;
		else if(Ccms_auth::is_user_logged_in())
			self::$ssl_required = true;
		else if((isset($_SERVER['PHP_SELF'])) &&
			(preg_match('/login|logout/i',$_SERVER['REQUEST_URI'])) &&
			(Ccms_auth::is_login_allowed()))
			self::$ssl_required = true;
		else if(!empty(self::$action)) {
			if((preg_match('/login|logout|edit.*|apps.*/',(!empty(self::$cms_action) ? self::$cms_action:self::$action))) &&
				(Ccms_auth::is_login_allowed()))
				self::$ssl_required = true;
			else {
				switch((!empty(self::$cms_action) ? self::$cms_action:self::$action)) {
				case 'tool':
					if(self::$cDBcms->get_data_in_table('cms_tools','cms_tool_ssl','cms_tool_id = ' . (int)self::$tool_id))
						self::$ssl_required = true;
					break;
				default:
					break;
					} // switch
				} // else
			} // if
		else {
			if((isset(self::$page_info['body']['cms_body_ssl'])) &&
				(self::$page_info['body']['cms_body_ssl'] > 0))
				self::$ssl_required = true;
			} // else
		if((self::$ssl_required) &&
			(INI_ALLOW_SELF_SIGNED_SSL_BOOL)) {
			self::$ssl_context = stream_context_set_default(
				array(
					'ssl' => array(
						'verify_peer' => false,
						'verify_peer_name' => false,
						),
					)
				);
			} // if
		return self::$ssl_required;
		} // is_ssl_required()

	private function get_base_ref() {
		$base_ref = '';
		self::$has_ssl_available = $this->is_ssl_available();
		if((isset($_SERVER['HTTPS'])) &&
			($_SERVER['HTTPS'] == 'on')) {
			self::$ssl_in_use = true;	// running on SSL
			if($this->is_ssl_required()) {	// ok
				$base_ref = CMS_SSL_URL;
				} // if
			else { // redirect to non SSL
				$url = CMS_WWW_URL;
				if((INI_ALLOW_NON_SSL_LOGIN_BOOL) ||
					(preg_match('/login|logout/',self::$action)) ||
					(preg_match('/login|logout/',self::$cms_action))) {
					if(!empty(self::$cms_action)) $url .= 'index.php?cms_action=' .self::$cms_action;
					else if(!empty(self::$action)) $url .= 'index.php?action=' .self::$action;
					else {
						// Use the URI the browser asked for so that we don't
						// expose the inner workings of any rewrite rules
						$url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
						} // else
					} // else
				unset($_SESSION['action']);
				unset($_SESSION['cms_action']);
				header('Location: ' . $url);
				exit(0);
				} // else
			} // if
		else {
			self::$ssl_in_use = false;	// running on an open port
			if($this->is_ssl_required()) {	// change to SSL
				$url = CMS_SSL_URL;
				if(!self::$has_ssl_available)
					self::log_msg ('No SSL certificate found.','warning');
				if((INI_ALLOW_NON_SSL_LOGIN_BOOL) ||
					(!preg_match('/login|logout/',self::$action)) ||
					(!preg_match('/login|logout/',self::$cms_action))) {
					if(!empty(self::$cms_action)) $url .= 'index.php?cms_action=' .self::$cms_action;
					else if(!empty(self::$action)) $url .= 'index.php?action=' .self::$action;
					else {
						// Use the URI the browser asked for so that we don't
						// expose the inner workings of any rewrite rules
						$url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
						} // else
					} // if
				unset($_SESSION['action']);
				unset($_SESSION['cms_action']);
				header('Location: ' . $url);
				exit(0);
				} // if
			else { // ok
				$base_ref = CMS_WWW_URL;
				if((INI_ALLOW_NON_SSL_LOGIN_BOOL) &&
					(!Ccms_auth::is_user_logged_in()) &&
					((preg_match('/logout/',self::$cms_action)) ||
						(preg_match('/logout/',self::$action)))) {
					$url .= $base_ref;
					unset($_SESSION['action']);
					unset($_SESSION['cms_action']);
					header('Location: ' . $url);
					exit(0);
					} // if
				} // else
			} // else
		return $base_ref;
		} // get_base_ref()

	protected function lookup_default_body() {
		if(!empty(self::$cms_action)) return 0;
		$sql_body_query = "SELECT * " .
			" FROM  cms_bodies" .
			" WHERE  cms_body_enabled > 0 AND cms_body_default > 0" .
			" ORDER BY  cms_body_default DESC, cms_body_order ASC,cms_body_id ASC;";
		$body = '';
		$body_cnt = 0;
		if($result_body = self::$cDBcms->query($sql_body_query)) {
			if(!$body = self::$cDBcms->fetch_array($result_body)) {
				// self::addMsg('No default page or app available.');
				return 0;
				} // if
			else {
				if($body['cms_body_type'] == Ccms_DB_checks::APP_TYPE_REVPROXY_FRAME) {
					if(!Ccms::host_check($body['cms_body_file'])) {
						self::addMsg('URL: "' . $body['cms_body_file'] . '" not available.');
						return 0;
						} // if
					$body['proxy_url'] = $body['cms_body_file'];
					} // if
				else {
					$incfile = PAGE_BODIES_WS_DIR . $body['cms_body_file'];
					$filepath = PAGE_BODIES_FS_DIR . $body['cms_body_file'];
					if((!file_exists($filepath)) || (!is_readable($filepath))) {
						self::addMsg('File "' . $filepath . '" not available.');
						return 0;
						} // if
					$body_cnt++;
					$body['filepath'] = $filepath;
					// $body['incfile'] = $incfile;	// for cache
					} // else
				} // else
			self::$cDBcms->free_result($result_body);
			} // if
		self::$page_info['body'] = $body;
		self::$page_info['body_cnt'] = $body_cnt;
		unset($_SESSION['body']);	// clear last body
		unset($_SESSION['last_url']);	// clear last url
		return $body_cnt;
		} // lookup_default_body()

	private function lookup_current_body($body_id) {
		if(!empty(self::$cms_action)) return 0;
		if(empty($body_id)) return 0;
		$sql_body_query = "SELECT * " .
			" FROM  cms_bodies" .
			" WHERE  cms_body_enabled > 0" .
			" AND cms_body_id = " . (int)$body_id .
			" ORDER BY  cms_body_default DESC, cms_body_order ASC,cms_body_id ASC;";
		$body_cnt = 0;
		$filepath = '';
		$body = '';
		if($result_body = self::$cDBcms->query($sql_body_query)) {
			while($body = self::$cDBcms->fetch_array($result_body)) {
				if(!Ccms_auth::check_user_group_ids($body['cms_body_group_ids'])) continue;
				if($body['cms_body_type'] == Ccms_DB_checks::APP_TYPE_REVPROXY_FRAME) {
					if(!Ccms::host_check($body['cms_body_file'])) {
						self::addMsg('URL: "' . $body['cms_body_file'] . '" not available.');
						continue;	// next file
						} // if
					$body['proxy_url'] = $body['cms_body_file'];
					} // if
				else {
					$incfile = PAGE_BODIES_WS_DIR . $body['cms_body_file'];
					$filepath = DOCROOT_FS_BASE_DIR . $incfile;
					if((!file_exists($filepath)) || (!is_readable($filepath))) {
						self::addMsg('File "' . $filepath . '" not available.');
						continue;	// next file
						} // if
					$body['filepath'] = $filepath;
					//$body['incfile'] = $incfile;	// for cache
					} // if
				$body_cnt++;
				break; // just the first available page
				} // while
			self::$cDBcms->free_result($result_body);
			} // if
		if((empty(self::$cms_action)) && (!$body_cnt)) {
			if((!empty(self::$page_info['body_name'])) ||
				(empty(self::$page_info['action'])) ||
				(self::$page_info['action'] == 'home')) {
				// usually arrive here on login time
				Ccms_content_cache::reset_caches(false);
				self::$page_info['body_name'] = false;
				self::$page_info['action'] = 'home';
				self::$action = 'home';
				} // if
			} // if
		self::$page_info['body'] = $body;
		self::$page_info['body_cnt'] = $body_cnt;
		unset($_SESSION['body']);	// clear last body
		return $body_cnt;
		} // lookup_current_body()

	protected function get_user_agent() {
		if((isset($_SERVER['HTTP_USER_AGENT'])) &&
			(isset($_SERVER['HTTP_USER_AGENT']))) {
			return $_SERVER['HTTP_USER_AGENT'];
			} // if
		return 'agent_unknown';
		} // get_user_agent()

	protected function get_next_body_file() {
		if(!isset($_SESSION['next_body_filename'])) return false;
		$next_body_filename = $_SESSION['next_body_filename'];
		unset($_SESSION['next_body_filename']);	// only once
		if(empty($next_body_filename)) return false;
		if(!file_exists($next_body_filename)) return false;
		return $next_body_filename;
		} // set_next_body_file()

	protected function make_head_values() {
		if((!empty(self::$page_info)) || (self::$page_info !== false)) return true;	// already done
		self::$page_info = array(
			'action' => self::$action,
			'cms_action' => self::$cms_action,
			'body_id' => self::$body_id,
			'body_name' => self::$body_name,
			'tool_id' => self::$tool_id,
			'tool_name' => self::$tool_name,
			);
		if(self::is_cli()) return true;

		self::$page_info['closed'] = $this->is_web_site_closed(self::$action);
		self::$page_info['redirect_url'] = $this->is_web_site_redirected(self::$action);
		self::$page_info['title'] = (!empty(self::$cms_action) ? $this->get_cms_page_title(self::$cms_action):$this->get_page_title(self::$action,self::$body_id));
		self::$page_info['meta_keywords'] = CMS_C_META_KEYWORDS;
		self::$page_info['meta_description'] = CMS_C_META_DESCRIPTION;
		self::$page_info['header_title'] = CMS_C_TITLE . ((strlen(CMS_C_SITE_STATUS) > 0) ? ' ' . CMS_C_SITE_STATUS:'') . (INI_WEBSITE_CLOSED_BOOL ? ' (Closed)':'');

//		switch(self::$action) {
//		case 'home':
//		default:
//			break;
//		} // switch

		if(($this->lookup_current_body(self::$body_id) > 0) && (!empty(self::$body_name))) {
			// substitute head values
			self::$page_info = array_merge(self::$page_info,self::$page_info['body']);
			} // if
		else if((!LMC_USE_LM_AS_HOME) &&
			(((empty(self::$action)) && (empty(self::$cms_action))) ||
				(self::$action == 'home') || (self::$cms_action == 'home')) && 	// @TODO this maybe an edge case
				($this->lookup_default_body() > 0)) {
			self::$body_id = self::$page_info['body']['cms_body_id'];
			self::$body_name = self::$page_info['body']['cms_body_name'];
			self::$page_info = array_merge(self::$page_info,self::$page_info['body']);
			} // else if
		else if((empty(self::$action)) && (empty(self::$cms_action)) && (preg_match('/index/i',$_SERVER['PHP_SELF']))) {
			if((LMC_USE_LM_AS_HOME) &&
				(self::is_links_manager_inuse())) {
				self::$action = "lm_show_links";
				self::$page_info['action'] = self::$action;
				} // if
			else if(INI_DEFAULT_ABOUT_PAGE_BOOL) {
				self::$cms_action = "cms_about";
				self::$page_info['cms_action'] = self::$cms_action;
				self::addMsg('No default page or application available. Using About page.','info');
				} // if
			else if($this->lookup_default_body() > 0) {
				self::$body_id = self::$page_info['body']['cms_body_id'];
				self::$body_name = self::$page_info['body']['cms_body_name'];
				self::$page_info = array_merge(self::$page_info,self::$page_info['body']);
				self::log_msg('No links available but default app available. Consider turning off USE_LM_AS_HOME.','info');
				} // else if
			else self::addMsg('No default page or application available.','warning');
			} // else

		self::$page_info['html_wysiwyg_allow'] = false;	// off until needed
		self::$page_info['base_ref'] = $this->get_base_ref();

		return true;
		} // make_head_values()

	protected function show_cms_title_tooltips() {
		if(!CMS_C_USE_TITLE_TOOLTIPS) return false;
		if(!self::is_hover_boxes_ok()) return false;
		if((self::$chrome_flg) && (self::$block_html)) return false;
		if(self::$tiny_flg) return false;
		return true;
		} // show_cms_title_tooltips()

	protected function is_web_site_closed($action) {
		if(self::is_cli()) return false;
		if(!defined('INI_WEBSITE_CLOSED_BOOL')) return false;
		if(!INI_WEBSITE_CLOSED_BOOL) return false;
		if(Ccms_auth::is_admin_user()) return false;

		// if the admin is trying to login, allow it
		if(!Ccms_auth::is_login_allowed()) return true;	// login not allowed, so its closed
		if(preg_match('/login|logout/i',$_SERVER['PHP_SELF'])) return false;	// open for login, etc
		if(preg_match('/login|logout|cms_edit_install/',$action)) return false;	// open for login, etc
		return true;	// closed
		} // is_web_site_closed()

	protected function is_web_site_redirected($action) {
		if(self::is_cli()) return '';
		if((empty($_SESSION)) || (!is_array($_SESSION)) || (count($_SESSION) <= 0)) return '';
		if(!defined('INI_REDIRECT_WEBSITE_BOOL')) return '';
		if(!INI_REDIRECT_WEBSITE_BOOL) return '';
		if(Ccms_auth::is_admin_user()) return '';
		$url = INI_REDIRECT_WEBSITE_URL;
		if(!self::has_dns_record($url)) return '';

		// if the admin is trying to login, allow it
		if(!Ccms_auth::is_login_allowed()) return $url;	// login not allowed, so its closed
		if((preg_match('/login/i',$_SERVER['PHP_SELF'])) ||	// open for login, etc
			(preg_match('/login/',$action))) {	// open for login, etc
			$_SESSION['logging_in_flg'] = true;
			return '';
			} // if
		else if((isset($_SESSION['logging_in_flg'])) &&
			($_SESSION['logging_in_flg'])) return '';
		else if((preg_match('/logout/i',$_SERVER['PHP_SELF'])) ||	// open for login, etc
			(preg_match('/logout|cms_edit_install/',$action)) ||	// open for login, etc
			(preg_match('/logout|cms_edit_install/',$cms_action))) {	// open for login, etc
			return '';
			} // if
		return $url;	// redirected
		} // is_web_site_redirected()

	protected function get_visitor_count() {
		// visitor number to site
		if(self::$visitor_cnt) return self::$visitor_cnt;

		$cntrDat = 0;
		if (is_readable(VAR_ACCESS_CNTR)) {
			$dat = file_get_contents(VAR_ACCESS_CNTR);
			$cntrDat = (int)$dat;
			} // if
		else self::$cDBcms->logEvent('INFO: Created new "' . basename(VAR_ACCESS_CNTR) . '"');

		$cntrDat += 1;
		$_SESSION['visitorNum'] = $cntrDat;

		// In our example we're opening VAR_ACCESS_CNTR in append mode.
		// The file pointer is at the bottom of the file hence
		// that's where $cntrDat will go when we fwrite() it.
		if (!self::file_safe_write(VAR_ACCESS_CNTR, $cntrDat)) {
			self::$cDBcms->logEvent("ERROR: Cannot save vist counter (" . VAR_ACCESS_CNTR . ")");
			} // if
		self::$visitor_cnt = $cntrDat;
		return self::$visitor_cnt;
		} // get_visitor_count()

// static methods
	public static function define_install_settings($redefine = false) {

		if($redefine) self::$cms_ini = false;
		else if((self::$install_settings_done) &&
			(self::$cms_ini !== false)) return self::$cms_ini;
		self::$install_settings_done = true;

		$settings = (self::$cms_ini ? self::$cms_ini : self::read_cms_ini_settings());

		// define installed settingss
		foreach($settings as $sect_name => $sect) {
			foreach($sect as $key => $val) {
				if(defined('INI_' . $key)) continue;
				if($sect_name == 'ThemeSettings') {
//					$cont = false;
					switch($key) {
					case 'FOOTER_BOOL':
					case 'FOOTER_HEIGHT':
					case 'HEADER_BOOL':
					case 'HEADER_HEIGHT':
					case 'LEFT_COLUMN_BOOL':
					case 'LEFT_WIDTH':
					case 'MODAL_HEIGHT':
					case 'MODAL_WIDTH':
					case 'NAV_BAR_BOOL':
					case 'NAV_BAR_HEIGHT':
					case 'NAV_BAR_LINKS_POSITION':
					case 'NAV_BAR_SHOW_ICONS_BOOL':
					case 'NAV_BAR_RIGHT_BOOL':
					case 'PAGE_DB_MENU_BOOL':
					case 'PAGE_STYLE_BLOCK_BOOL':
					case 'RIGHT_COLUMN_BOOL';
					case 'RIGHT_WIDTH':
						break;	// needed
					default:
						// PHP Warning:  "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"?
						// see PHP 7.3 bug "https://www.mantisbt.org/bugs/view.php?id=25033"
						continue 2;	// dont define these 'ThemeSettings' not used at runtime
//						$cont = true;
//						break;
						} // switch
//					if($cont) continue;
					} // if
				$val = self::get_macro_lookup($sect_name,$sect, $key, $val);
				switch(strtolower($val)) {
				case 'comment': break;	// only to help edit settings web page
				case '0':	// that what false becomes
				case 'false':
				//case 'inline':
					define('INI_' . $key,false);
					break;
				case '1':	// thats what true becomes
				case 'true':
				//case 'block':
					define('INI_' . $key,true);
					break;
				default:
					define('INI_' . $key,$val);
					break;
					} // switch
				} // foreach
			} // foreach
		return $settings;
		} // define_install_settings()

	public static function has_dns_record($url, $types = array('A','AAAA','CNAME')) {
		$url_chk = parse_url($url);
		if(empty($url_chk['host'])) return false;
		if(strlen($url_chk['host']) < 6) return false;
		if(is_array($types)) {
			foreach($types as $t) {
				if(checkdnsrr($url_chk['host'],$t)) return true;
				} // foreach
			} // if
		else if(checkdnsrr($url_chk['host'],$types)) return true;
		if(preg_match('/^(::1|127.0.0.1|localhost)$/i',$url_chk['host'])) return true;
		return false;
		} // has_dns_record()

	// static methods
	public static function get_header_bar_title($delimiter = ' - ') { // set page title, a bit of basic SEO
		$title = self::$page_info['header_title'];
		switch(self::$cms_action) {
		case 'tool':
			if(((int)Ccms::$tool_id > 0) &&
				($name = self::$cDBcms->get_data_in_table('cms_tools','cms_tool_title','cms_tool_id = ' . (int)Ccms::$tool_id)) &&
				(!empty($name))) {
				$title .= $delimiter . $name;
				} // if
			break;
		case 'cms_login':
		case 'cms_edit_tools':
		case 'cms_edit_bodies':
		case 'cms_edit_groups':
		case 'cms_edit_users':
		case 'cms_edit_search':
		case 'cms_edit_install':
		case 'cms_edit_config':
		case 'cms_about':
		case 'home':
		default:
			break;
		} // switch
		return $title;
		} // get_header_bar_title()

	public static function is_wysiwyg_allowed() {
		return self::$page_info['html_wysiwyg_allow'];
		} // is_wysiwyg_allowed()

	public static function output_apps_css($prn = true) {
		static $sent = false;
		if(!$sent) {
			$sent = true;
			if(file_exists(ETC_WS_CSS_DIR . 'apps.css')) {
				$text = '<link rel="stylesheet" type="text/css" href="' . Ccms_minify_plugin::minify_css(ETC_WS_CSS_DIR . 'apps.css') . '">' . PHP_EOL;
				if($prn) echo $text;
				return $text;
				} // if
			} // if
		return '';
		} // output_apps_css()

	protected static function is_cms_action() {
		if(!empty(self::$cms_action)) return true;
		return false;
		} // is_cms_action()

	public static function is_admin_action($action = false) {
		if(!$action) $action = self::$cms_action;
		if(preg_match('/^cms_[_a-z]+$|^app[s]?_extend$/',$action)) return true;
//		switch($action) {	// too slow
//		case 'app_extend':
//		case 'apps_extend':
//		// case 'apps_manual':
//		case 'cms_about':
//		case 'cms_browse_sessions':
//		case 'cms_users_stats':
//		case 'cms_debug':
//		case 'cms_doxy':
//		case 'cms_edit_apps':
//		case 'cms_edit_bodies':
//		case 'cms_edit_config':
//		case 'cms_edit_groups':
//		case 'cms_edit_header_footer':
//		case 'cms_edit_install':
//		case 'cms_edit_links':
//		case 'cms_edit_search':
//		case 'cms_edit_sections':
//		case 'cms_edit_theme':
//		case 'cms_edit_tools':
//		case 'cms_edit_users':
//		case 'cms_log_view':
//		case 'cms_manual':
//		case 'cms_rebuild_setup':
//		case 'update_sitemap':
//			return true;
////		case 'cookies':
////		case 'terms':
////		case 'licence':
////		case 'acknowledgement':
////		case 'release_notes':
////		case 'readme':
////		case 'link':
////		case 'tool':
////		case: 'get_password':
//		default:
//			break;
//			} // switch
		return false;
		} // is_admin_action()

	public static function is_drag_drop_used() {
		if(INI_DRAG_DROP_PRELOAD_BOOL) return true;
		if(self::is_admin_action()) return true;
		if(empty(self::$body_id)) return true;	// links page
		return false;
		} // is_drag_drop_used()

	protected static function get_head_JS_url($js_file, $async = true) {
		$minnd = Ccms_minify_plugin::minify_js($js_file);
		$text = '		<script type="text/javascript"';
		$text .= ' src="' . $minnd .'"';
		if($async) $text .= ' async';
		$text .= ' ></script>' . PHP_EOL;
		return $text;
		} // get_head_JS_url()

	protected static function get_head_CSS_url($css_file, $async = true) {
		// see "https://developer.mozilla.org/en-US/docs/Web/HTML/Preloading_content"
		$text = '';
		$minnd = Ccms_minify_plugin::minify_css($css_file);
		if($async) {
			$text = '		<link rel="preload"';
			$text .= ' href="' . $minnd . '"';
			$text .= ' as="style">' . PHP_EOL;
			} // if
		$text .= '		<link rel="stylesheet"';
		$text .= ' href="' . $minnd . '">' . PHP_EOL;
		return $text;
		} // get_head_CSS_url()

	public static function output_page_headers() {
		if(headers_sent()) return;
		echo '<!DOCTYPE html>' . PHP_EOL;
		header('X-Frame-Options: DENY');
		if(!INI_ENABLE_BROWSER_CACHING_BOOL) {
			header("Expires: " . date('r',time() - (7 * 24 * 60 * 60)));	// last week
			header("Cache-Control: no-cache");
			header("Pragma: no-cache");
			} // if
		} // output_page_headers()

	public static function output_head($newTitle = '', $prn_flg = true) {
		if(self::$head_output_flg) return false;	// donot output twice
		$text = '	<head>' . PHP_EOL;
		if(INI_ANALYTICS_EXT_INHEAD_BOOL) {
			ob_start();
			Ccms::do_analytics_include();
			$text .= ob_get_clean();
			} // if
		$text .= '		<meta charset="' . INI_CHAR_SET . '">' . PHP_EOL .
			'		<title>' . strip_tags(empty($newTitle) ? self::$page_info['title'] : $newTitle) . '</title>' . PHP_EOL;

		if(strlen(CMS_C_META_DEFAULT_EXTRAS) > 4) {
			$grid_all = unserialize(CMS_C_META_DEFAULT_EXTRAS,array());
			foreach ($grid_all as &$g) { // check body enabled
				$text .= '		<meta name="' . $g[0] . '" content="' . $g[1] . '">' . PHP_EOL;
				} // foreach
			} // if

		$text .= '		<base id="cms_base_ref" href="' . self::$page_info['base_ref'] . '">' . PHP_EOL .
			'		<META NAME="GENERATOR" CONTENT="'. CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '">' . PHP_EOL;

		if(strlen(CMS_C_META_COPYRIGHT) > 4)
			$text .= '		<meta name="owner" content="' . CMS_C_META_COPYRIGHT . '">' . PHP_EOL;
		if(strlen(CMS_C_META_COPYRIGHT) > 4)
			$text .= '		<meta name="copyright" content="' . CMS_C_META_COPYRIGHT . '">' . PHP_EOL;
		if(strlen(CMS_C_META_AUTHOR) > 4)
			$text .= '		<meta name="author" content="' . CMS_C_META_AUTHOR . '">' . PHP_EOL;
		if(strlen(CMS_C_META_CONTACT) > 4)
			$text .= '		<meta name="contact" content="' . CMS_C_META_CONTACT . '">' . PHP_EOL;

		if(!empty(self::$page_info['meta_keywords']))
			$text .= '		<meta name="keywords" content="' . self::$page_info['meta_keywords'] . '">' . PHP_EOL;

		if(!empty(self::$page_info['meta_description']))
			$text .= '		<meta name="description" content="' . self::$page_info['meta_description'] . '">' . PHP_EOL;
		if(!INI_ALLOW_ROBOTS_BOOL)
			$text .= '		<meta name="robots" content="nofollow">' . PHP_EOL;

		if((self::$tiny_flg) || (self::$tablet_flg)) {
			// $text .= '		<meta name="viewport" content="initial-scale = 1.0, user-scalable = no">' . PHP_EOL;
			$text .= '		<meta name="viewport" content="initial-scale = 1.0">' . PHP_EOL;
			$text .= '		<meta name="apple-mobile-web-app-capable" content="yes">' . PHP_EOL;
			} // if

//		if(!INI_ENABLE_BROWSER_CACHING_BOOL) {
//			$text .= '		<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">' . PHP_EOL;
//			$text .= '		<meta HTTP-EQUIV="Expires" CONTENT="-1">' . PHP_EOL;
//			} // if

		if(is_readable(DOCROOT_FS_BASE_DIR . '/favicon.ico')) {
			$text .= '		<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>' . PHP_EOL;
			$text .= '		<link rel="icon" href="favicon.ico" type="image/x-icon"/>' . PHP_EOL;
			} // if
		else if(is_readable(DOCROOT_FS_BASE_DIR . '/favicon.png')) {
			$text .= '		<link rel="shortcut icon" type="image/png" href="favicon.png"/>' . PHP_EOL;
			$text .= '		<link rel="icon" href="favicon.png" type="image/png"/>' . PHP_EOL;
			} // if

		$text .= self::get_head_CSS_url(ETC_WS_CSS_DIR . 'cms_main_styles.css',false);
		$text .= self::get_head_CSS_url(ETC_WS_CSS_DIR . (self::$block_html ? 'cms_block_styles.css':'cms_inline_styles.css'),false);

		if(strlen(INI_CUSTOM_CSS_URI) > 4)  {	// custom CSS setting.
			$text .= self::get_head_CSS_url(INI_CUSTOM_CSS_URI);
			} // if

		$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_funcs.js',false);
		if(self::is_drag_drop_used()) {
			$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_drag_drop.js',false);
			} // if

		if(strlen(INI_CUSTOM_JS_URI) > 4) {	// custom CSS setting.
			$text .= self::get_head_JS_url(INI_CUSTOM_JS_URI);
			} // if

		if(INI_INC_APPS_CSS_IN_HEAD_BOOL) {
			$text .= '		' . self::output_apps_css(false);
			} // if

		switch(self::$cms_action) {
		case 'cms_edit_bodies':
			if((Ccms::is_get_or_post('add')) ||
				(Ccms::is_get_or_post('edit')) ||
				(Ccms::is_get_or_post('body_edit_id'))) {
				$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_body_funcs.js',false);

				if(Ccms::is_get_or_post('body_edit_id')) {
					if((int)Ccms::get_or_post('body_edit_id') > 0) {
						$file = self::$cDBcms->get_data_in_table('cms_bodies','cms_body_file','cms_body_id = ' . (int)Ccms::get_or_post('body_edit_id'));
						self::$page_info['html_wysiwyg_allow'] = (preg_match('/\.htm$|\.html$/i', $file) ? true:false);
						} // if
					else self::$page_info['html_wysiwyg_allow'] = true;	// just allow, @TODO use js select editor type later for new body file
					} // if
				} // if
			break;
		case 'cms_edit_header_footer':
			if(Ccms::is_get_or_post('edit')) {
				$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_body_funcs.js',false);
				self::$page_info['html_wysiwyg_allow'] = true;
				} // if
			break;

		// the ajaxed results for cms pages
		case 'app_extend':	// output app js and css files
			$idx = Ccms::get_or_post('idx');
			$app_name = Ccms::get_or_post('app_name');
			if((!empty($app_name)) && ($idx !== false) && (is_numeric($idx))) {
				// get app directory
				$body_defines = self::$body_defines;
				$app_def = array_filter($body_defines, function($v) use ($app_name) {
					if(empty($v['cms_body_dir'])) return false;
					if((empty($v['app_name'])) || ($v['app_name'] != $app_name)) return false;
					return true; // me
					});
				if((!empty($app_def)) &&
					($k = key($app_def)) &&
					(!empty($app_def[$k]['cms_body_dir']))) {
					$body_define = &$app_def[$k];
					if(isset($body_define['app_css'])) {
						$text .= self::get_head_CSS_url($body_define['app_css']);
						} // if
					if(isset($body_define['app_js'])) {
						$text .= self::get_head_JS_url($body_define['app_js']);
						} // if
					} // if
				} // if
			$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_body_funcs.js',false);
			break;
		case 'apps_extend':
		case 'cms_edit_search':
		case 'cms_debug':
		// case 'cms_doxy':
		case 'cms_log_view':
		case 'cms_browse_sessions':
		case 'cms_users_stats':
		case 'lm_show_links':
			$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_body_funcs.js',false);
			break;
		default:
			$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_body_funcs.js',false);
			if((int)self::$body_id > 0) {	//include the app css and js if present
				$body_defines = &self::$body_defines;
				if(isset($body_defines[self::$body_id])) {
					$body_define = &$body_defines[self::$body_id];
					if(isset($body_define['app_css'])) {
						$text .= self::get_head_CSS_url($body_define['app_css']);
						} // if
					if(isset($body_define['app_js'])) {
						$text .= self::get_head_JS_url($body_define['app_js']);
						} // if
					} // if
				} // if
			break;
			} // switch
		if(Ccms_auth::is_group_manager()) {
			$text .= self::get_head_CSS_url(CMS_WS_DIR . 'cms_admin.css',false);
			$text .= self::get_head_CSS_url(CMS_WS_DIR . 'cms_admin_pdb.css',false);
			} // if
//		else if((INI_NAV_BAR_BOOL) && (Ccms_auth::is_group_manager())) {
//			$text .= self::get_head_CSS_url(CMS_WS_DIR . 'cms_admin_pdb.css',false);
//			} // else if

		if(self::$tooltips_flg) {
			$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_title_tooltips.js',false);
			} // if

		$text .= Ccms_html::get_clientMeta_sender();
		if(strlen(CMS_C_LOGO_IMAGE) > 4) {
			if(is_readable(CMS_C_LOGO_IMAGE)) $img = CMS_C_LOGO_IMAGE;
			else $img = ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE;
			$text .= '		<link rel="preload" as="image" href="' . $img . '">' . PHP_EOL;
			} // if

		$text .= '	</head>' . PHP_EOL;

		self::$head_output_flg = true;
		if($prn_flg) echo $text;
		return $text;
		} // output_head()

	public static function chk_bld_crit_dirs($bld = true) {
		if(!$bld) $bld = self::is_rebuild();
		$crit_dirs_check_list = array(	// critical read/write paths

			VAR_FS_DIR,	// worrying
			VAR_FS_APPS_DIR,
			VAR_FS_LOGS_DIR,
			VAR_FS_BACKUP_DIR,
			VAR_FS_CACHE_DIR,
			VAR_FS_CACHE_APPS_DIR,
			VAR_FS_CACHE_CONTENTS_DIR,
			VAR_FS_CACHE_GOTCHA_DIR,
			VAR_FS_CACHE_MINIFY_DIR,
			VAR_FS_EXPORT_DIR,
			VAR_FS_SESSION_DIR,
			VAR_FS_TEMP_DIR,
			VAR_FS_TRASH_DIR,
			VAR_FS_VARIABLES_DIR,
			VAR_FS_USERS_DIR,
			VAR_FS_PROXY_DIR,

			ETC_FS_DIR,	// very worrying
			ETC_FS_EXT_INCLUDES_DIR,
			ETC_FS_IMAGES_DIR,
			ETC_FS_BACKGROUNDS_DIR,
			ETC_FS_IMAGES_DIR,
			ETC_FS_ICONS_DIR,
			ETC_FS_INI_DIR,
			ETC_FS_CSS_DIR,
			ETC_FS_SQLITE_DIR,	// for INI_DB_SQLITE_DATABASE,

			LOCAL_FS_TOOLS_DIR,

			PAGE_BODIES_FS_DIR,

			APPS_FS_DIR,
			APPS_FS_INCLUDE_DIR,
			APPS_FS_PLUGINS_DIR,
			APPS_FS_CLASSES_DIR,
			APPS_FS_INI_DIR,

			);
		$ok = true;
		foreach($crit_dirs_check_list as $vd) {
			if(!self::chkdir($vd,$bld)) {
				$ok = false;
				self::addMsg('Cannot create "' . substr($vd,strlen(DOCROOT_FS_BASE_DIR)) . '" directory.');
				} // if
			// else ok
			} // foreach
		return $ok;
		} // chk_bld_crit_dirs()

	private static function chk_bld_crit_files($touch = true) {

		$files_r_check_list = array(	// read files
			CMS_FS_CMS_CONFIG_MSGS,
			CMS_FS_CMS_CONFIG_DEFAULT,
			);

		$files_rw_check_list = array(	// read/write file
			ETC_FS_SQLITE_DIR . INI_DB_SQLITE_DATABASE => array(),
			ETC_WS_CSS_DIR . 'cms_main_styles.css' => array( 'func' => 'Ccms::reload_ini_default_settings'),
			ETC_WS_CSS_DIR . 'cms_block_styles.css' => array( 'func' => 'Ccms::reload_ini_default_settings'),
			ETC_WS_CSS_DIR . 'cms_inline_styles.css' => array( 'func' => 'Ccms::reload_ini_default_settings'),
// can use default in install			ETC_FS_CMS_CONFIG => array(),
//			VAR_LOG_FILE => array(),
//			VAR_ERROR_LOG_FILE => array(),
			);

		$ok = true;

		foreach($files_r_check_list as $f) {
			if(!file_exists($f)) {
				self::addMsg('Readonly file . "' . $f . '" does not exist.');
				$ok = false;
				} // if
			else if(!is_readable($f)) {
				self::addMsg($f . ' is not readable.');
				$ok = false;
				} // if
			// else ok
			} // foreach

		foreach($files_rw_check_list as $f => &$op) {
			if(!file_exists($f)) {
				if(isset($op['func'])) {
					$func = $op['func'];
					if($func()) continue;
					} // if
				self::addMsg('RW File . "' . $f . '" does not exist.',($touch ? 'warning':''));
				$ok = false;
				} // if
			else if(!is_writable($f)) {
				if(!self::chmod_chown($f)) {
					self::addMsg('File "' . $f . '" is not writeable.');
					$ok = false;
					} // if
				} // if
			// else ok
			} // foreach
		return $ok;
		} // chk_bld_crit_files()

	private static function chk_dir_defines() {
		$defines = get_defined_constants(true);
		if(!isset($defines['user'])) return true;

		// find all the var/ directory settings and check they exist
		$user_d = &$defines['user'];
		$ok = true;
		$dir_bases = array(
			APPS_DIR,
			VAR_DIR,
			);
		foreach($dir_bases as $bd) {
			$prefix = DOCROOT_FS_BASE_DIR . $bd;
			$prefix_len = strlen($prefix);
			reset($user_d);
			foreach($user_d as $k => &$v) {
				if((substr($v,-1) == '/') && (substr($v,0,$prefix_len) == $prefix)) {	// use preg_match instead ???
					if(!self::chkdir($v,true)) {
						self::log_msg('Failed to create "' . $v . '" (1).');
						$ok = false;
						} // if
					// too much else self::log_msg('"' . $v . '" ok (1).','info');
					} // if
				else if((substr($v,-1) == '/') && (substr($v,0,strlen($bd)) == $bd)) {	// use preg_match instead ???
					$dir = DOCROOT_FS_BASE_DIR . $v;
					if(!self::chkdir($dir,true)) {
						self::log_msg('Failed to create "' . $v . '" (2).');
						$ok = false;
						} // if
					// too much else self::log_msg('"' . $v . '" ok (2).','info');
					} // if
				} // foreach
			} // foreach
		return $ok;
		} // chk_dir_defines()

	public static function do_install_warnings_func_chks($func_class_chk_list) {
		$ok = true;
		foreach($func_class_chk_list as $f) {
			$type = 'error';
			if((!empty($f['type']))) $type = $f['type'];
			if($type != 'error') $install_msg = ' install recommended.';
			else $install_msg = ' to be installed.';
			if((isset($f['func'])) &&
				(!function_exists($f['func']))) {
				if(empty($f['msg']))
					self::addMsg('System Function: ' . $f['func'] . '() not installed. Needs ' . $f['needs'] . $install_msg,$type);
				else self::addMsg('System Function: ' . $f['func'] . '() not installed. ' . $f['msg'] . '',$type);
				if($type == 'error') $ok = false;
				} // if
			if((isset($f['class'])) &&
				(!class_exists($f['class'],false))) {
				if(empty($f['msg']))
					self::addMsg('System Class: ' . $f['class'] . ' not installed. Needs ' . $f['needs'] . $install_msg,$type);
				else self::addMsg('System Class: ' . $f['class'] . '() not installed. ' . $f['msg'] . '',$type);
				if($type == 'error') $ok = false;
				} // if
			if(isset($f['cli'])) {
				$result = '';
				$output = '';
				exec('which ' . $f['cli'], $output, $result);
				if($result) {
					if(empty($f['msg']))
						self::addMsg('System command not installed: Needs ' . $f['needs'] . '.',$type);
					else self::addMsg('System command not installed: ' . $f['needs'] . '. ' . $f['msg'] . '',$type);
					if($type == 'error') $ok = false;
					} // if
				} // if
			} // foreach
		return $ok;
		} // do_install_warnings_func_chks()

	public static function do_cms_cli_warnings($chk_flg = false) {
		if(!self::is_cli()) return true;
		$ok = true;
		if($chk_flg) {
			$func_class_chk_list = array(
				array(
					'cli' => 'dialog',	// complete test command (empty = faile)
					'needs' => 'System package: dialog. Not installed, required for CLI diaplog boxes.',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
				array(
					'cli' => 'fusermount',	// complete test command (empty = faile)
					'needs' => 'System package: fuse. Not installed, fusemount required for AppsCMS read only operation.',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
				array(
					'cli' => 'squashfuse',	// complete test command (empty = faile)
					'needs' => 'System package: squashfuse. Not installed, fusemount required for AppsCMS read only operation.',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
//				array(
//					'func' => 'ncurses_init',	// not reliable
//					'needs' => 'PECL nurses or System pkg php-pecl-ncurse',	// not reliable
//					),
				);
			$ok &= self::do_install_warnings_func_chks($func_class_chk_list);
			} // if
		return $ok;
		} // do_cms_cli_warnings()

//	protected static function chk_htaccess() {
//		if(self::is_cli()) return true;	// not docroot
//		$rw_base = self::clean_path('/' . DOCROOT_WS_BASE_DIR . '/');
//		$ht = DOCROOT_FS_BASE_DIR . '.htaccess';
//		if(is_readable($ht)) {
//			$pat = 'RewriteBase\s+' . preg_quote($rw_base,'/');
//			if(preg_match('/' . $pat . '/im',file_get_contents($ht))) return true;	// ok
//			} // if
//		// else no good
//
//		$ht_text_inc = <<< EOT
//
//####################################
//<IfModule mod_rewrite.c>
//	RewriteEngine On
//	# RewriteBase is usually / or the alias to the diretory e.g. /alias/
//	RewriteBase {$rw_base}
//	RewriteCond %{REQUEST_FILENAME} !-f
//	RewriteCond %{REQUEST_FILENAME} !-d
//</IfModule>
//####################################
//
//EOT;
//
//	self::addMsg('Need this text added near the top of "' . $ht . '"' . $ht_text_inc,'warn');
//	return false;
//	} // chk_htaccess

	public static function do_cms_warnings($chk_flg = false) {
		if(self::is_rebuild()) {
			$chk_flg = true;
			self::build_css_stylesheets();
			} // if
		if((!$chk_flg) && (!INI_INSTALLATION_WARNINGS_BOOL)) return true;
		$ok = true;
//		$ok = self::chk_htaccess();

		if($chk_flg) {
			self::log_msg((Ccms_auth::is_admin_user () ? 'Admin ':'') . 'Installation Check.','info');
			} // if
		$ok &= self::chk_bld_crit_files();
		if(!self::chk_dir_defines()) $ok = false;

		if($chk_flg) {
			$func_class_chk_list = array(
				array(
					'func' => 'mb_strlen',
					'needs' => 'php-mbstring',
					),
				array(
					'func' => 'geoip_country_name_by_name',
					'needs' => 'PECL geoip >= 1.0 or System pkg php-pecl-geoip',
					'msg' => ' Needed for geolocation.',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
				array(
					'func' =>'json_decode',
					'needs' => 'php-json',
					),
				array(
					'func' =>'posix_getgrgid',
					'needs' => 'php-posix or php-process',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
//				array(
//					'func' => 'posix_getpwuid',
//					'needs' => 'php-posix or php-process',
//					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
//					),
				array(
					'func' => 'curl_init',
					'needs' => 'php curl',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
				array(
					'func' => 'ldap_connect',
					'needs' => 'php-ldap',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					'msg' => 'Requires php-ldap for LDAP login.',
					),
				array(
					'func' => 'imagecreate',
					'needs' => 'php-gd',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					'msg' => 'Requires php-gd for image manipulation.',
					),
				array(
					'func' => 'locale_accept_from_http',
					'needs' => 'php-intl',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
				array(
					'class' => 'SQLite3',
					'needs' => 'SQLite 3',
					),
				array(
					'class' => 'ZipArchive',
					'needs' => 'php-pecl-zip',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					),
				array(
					'class' => 'tidy',
					'needs' => 'php-tidy',
					'type' => 'warn',	// default is 'error', are the same as addMsg() uses
					'msg' => 'Recommended for WYSIWYG editing.',
					),
				);
			$ok &= self::do_install_warnings_func_chks($func_class_chk_list);
			} // if

		if((!self::is_cli()) &&
			(defined('CMS_C_WYSIWYG_EDITOR')) &&	// can be defined later
			(!Ccms_wysiwyg::is_wysiwyg_available())) {
			self::log_msg('No WYSIWYG configured.','warning');
			// $ok = false;
			} // if

		if((!$chk_flg) && ($ok)) self::getMsgs();	// no error clear it
		if($chk_flg) {
//			if(is_writable(CMS_FS_INCLUDES_DIR . 'cms_configure.php')) {
//				self::addMsg(CMS_FS_INCLUDES_DIR . 'cms_configure.php is writeable.','warning');
//				// $ok = false;
//				}
			if($ok) self::log_msg('No install issues detected.','info');
			} // if
		return $ok;
	} // do_cms_warnings()

	public static function clean_orphaned_settings($clean_old_apps_sections = false) {
		if(!self::is_rebuild()) return false;	// only when rebuilding

		// do AppsCMS first
		$cms_settings = self::read_cms_ini_settings();	// will also put in missing values
		$cms_comments = self::read_cms_ini_comments();
		$orphan_cnt= 0;
		$clean_settings = array();
		foreach($cms_settings as $sect_name => $sect) {
			if(!isset($cms_comments[$sect_name])) {
				self::addMsg('Removed orphaned cms settings section "' . $sect_name . '".','info');
				$orphan_cnt++;
				continue;
				} // if
			foreach($sect as $k => $v) {
				if(!isset($cms_comments[$sect_name][$k])) {
					self::addMsg('Removed orphaned cms settings section "' . $sect_name . '", key "' . $k . '".','info');
					$orphan_cnt++;
					continue;
					} // if
				$clean_settings[$sect_name][$k] = $v;
				} // foreach
			} // foreach
		self::save_cms_ini_settings($clean_settings,true);
		self::addMsg('Removed ' . $orphan_cnt . ' cms orphaned settings.','info');

		// clean apps settings orphans
		$apps_settings = Ccms_apps::read_apps_ini_settings();
		$apps_comments = Ccms_apps::read_apps_ini_comments();
		if(!$apps_settings) return false;
		$orphan_cnt= 0;
		$clean_settings = array();
		foreach($apps_settings as $sect_name => $sect) {
			if(($clean_old_apps_sections) && (!isset($apps_comments[$sect_name]))) {
				self::addMsg('Removed orphaned apps settings section "' . $sect_name . '".','info');
				$orphan_cnt++;
				continue;
				} // if
			// else it maybe an old app settings
			foreach($sect as $k => $v) {
				if(!isset($apps_comments[$sect_name][$k])) {
					self::addMsg('Removed orphaned apps settings section "' . $sect_name . '", key "' . $k . '".','info');
					$orphan_cnt++;
					continue;
					} // if
				$clean_settings[$sect_name][$k] = $v;
				} // foreach
			} // foreach
		Ccms_apps::save_apps_ini_settings($clean_settings,true);
		self::addMsg('Removed ' . $orphan_cnt . ' apps orphaned settings.','info');

		return true;
	} // clean_orphaned_settings()

	public static function make_nice_name($ini_key, $delim = '_', $substitutes = null) {	// turns "MAGE_IMPORT_CHANGED_ONLY_BOOL_BOOL" into "Mage Continue Import"
		if(is_array($substitutes)) $subs = $substitutes;
		else {
			$subs = array(
				'DB' => 'DB',	// keep same
				'WS' => 'WS',	// keep same
				'BOOL' => '',	// remove type at end of $ini_key
				'TZ' => '', // remove type at end of $ini_key
				);
			} // else
		if(preg_match('/^[a-z]+[A-Z]+[a-z]*$/',$ini_key)) return $ini_key;	// careful with these sort of words
		if(preg_match('/^[A-Z]+$/',$ini_key)) return $ini_key;	// careful with these sort of words

		$name = '';
		// deliniate camel case with underscore
		$ini_key = preg_replace('/([a-z])([A-Z][a-z])/','$1' . $delim . '$2',$ini_key);
		$words = explode($delim,$ini_key);
		if((!is_array($words)) || (count($words) < 2)) return trim($ini_key);
		self::array_trim($words);
		foreach($words as $word) {
			if(!empty($name)) $name .= ' ';
			if(isset($subs[$word])) $name .= $subs[$word];
			else if(preg_match('/^[a-z]+[A-Z]+[a-z]*$/',$word)) $name .= $word;	// careful with these sort of words
			else $name .= ucwords(strtolower($word));	// make proper noun
			} // foreach
		return trim($name);
	} // make_nice_name()

	public static function unmake_hungarion_fmt($str) {
		// @TODO left over from older sibling ????
		return self::make_nice_name($str);
//		$text = '';
//		$idx = 0; $spFlg = true; $c_l = '';
//		while($idx < strlen($str)) {
//			$c = substr($str,$idx++,1);
//			if(strlen($text) > 0) {
//				if($c == '_' || $c == '-') {
//					if(!$spFlg || $c_l != ' ') {	// only one space
//						$text .= ' ';
//						$spFlg = true;
//						} // if
//					$c_l = ' ';
//					continue; // dont add $c
//					} // if
//				else if($c >= 'A' && $c <= 'Z' && ($c_l < 'A' || $c_l > 'Z')) {
//					if(!$spFlg) {	// only one space
//						$text .= ' ';
//						$spFlg = true;
//						} // if
//					// add $c
//					} // if
//				else $spFlg = false;
//				} // if
//			$c_l = $c;
//			$text .= $c;
//			} // while
//		return $text;
	} // unmake_hungarion_fmt()

	public static function get_body_description($body_id, $name, $description, $expand = true) {
		if(!$expand) {
			if(empty($description)) return '(empty)';
			else if(file_exists(DOCROOT_FS_BASE_DIR . $description)) {
				// return self::make_message_text('Filename: &quot;' . $description . '&quot; OK.','info');
				return 'Filename mode: &quot;' . $description . '&quot; OK.';
				} // else if
			else if(preg_match('/^[a-z_]+::[a-z_]+/i',$description)) {
				if($func = self::get_inc_method_callback($description)) {
					try {
						$text = @$func($body_id,$name);
						// return self::make_message_text('Callback Method: &quot;' . $description . '&quot; OK.','info');
						return 'Callback mode: &quot;' . $description . '&quot; OK.';
					} catch (Exception $ex) {
						return self::make_message_text('Callback Method failed: &quot;' . $func . '&quot;.','warn');
						}
					} // if
				else {
					return self::make_message_text('Callback Method not found: &quot;' . $description . '&quot;.', 'warn');
					} // else
				} // else if
			// return self::make_message_text('Default Text:<br>&quot;' . nl2br($description) . '&quot;.','info');
			return 'Text mode: &quot;' . nl2br($description) . '&quot;';
			} // if

		if(empty($description)) return '';	// nothing
		else if(file_exists(DOCROOT_FS_BASE_DIR . $description)) {
			ob_start();
			include($description);
			$text = ob_get_clean();
			return $text;
			} // else if
		else if($func = self::get_inc_method_callback($description)) {
			try {
				$text = @$func($body_id,$name);
				return $text;
			} catch (Exception $ex) {
				self::addMsg('Failed to call "' . $func . '(id,name)".');
				return '';
				}
			} // else if
		return '<p>' . preg_replace('/\n/','</p><p>',$description) . '</p>';
		} // get_body_description()

	public static function is_browser_html5() {
		return self::$browser_html5;
		} // is_browser_html5()

	public static function get_time_zones() {
		$timezones = timezone_identifiers_list();

		// include the aliases from "https://en.wikipedia.org/wiki/List_of_tz_database_time_zones"
		$aliases = array(
			'Africa/Addis_Ababa',
			'Africa/Asmara',
			'Africa/Bamako',
			'Africa/Bangui',
			'Africa/Banjul',
			'Africa/Blantyre',
			'Africa/Brazzaville',
			'Africa/Bujumbura',
			'Africa/Conakry',
			'Africa/Dakar',
			'Africa/Dar_es_Salaam',
			'Africa/Djibouti',
			'Africa/Douala',
			'Africa/Freetown',
			'Africa/Gaborone',
			'Africa/Harare',
			'Africa/Kampala',
			'Africa/Kigali',
			'Africa/Kinshasa',
			'Africa/Libreville',
			'Africa/Lome',
			'Africa/Luanda',
			'Africa/Lubumbashi',
			'Africa/Lusaka',
			'Africa/Malabo',
			'Africa/Maseru',
			'Africa/Mbabane',
			'Africa/Mogadishu',
			'Africa/Niamey',
			'Africa/Nouakchott',
			'Africa/Ouagadougou',
			'Africa/Porto-Novo',
			'Africa/Sao_Tome',
			'Africa/Timbuktu',
			'America/Anguilla',
			'America/Antigua',
			'America/Argentina/ComodRivadavia',
			'America/Aruba',
			'America/Atka',
			'America/Buenos_Aires',
			'America/Catamarca',
			'America/Cayman',
			'America/Coral_Harbour',
			'America/Cordoba',
			'America/Dominica',
			'America/Ensenada',
			'America/Fort_Wayne',
			'America/Grenada',
			'America/Guadeloupe',
			'America/Indianapolis',
			'America/Jujuy',
			'America/Knox_IN',
			'America/Kralendijk',
			'America/Louisville',
			'America/Lower_Princes',
			'America/Marigot',
			'America/Mendoza',
			'America/Montreal',
			'America/Montserrat',
			'America/Porto_Acre',
			'America/Rosario',
			'America/Santa_Isabel',
			'America/Shiprock',
			'America/St_Barthelemy',
			'America/St_Kitts',
			'America/St_Lucia',
			'America/St_Thomas',
			'America/St_Vincent',
			'America/Tortola',
			'America/Virgin',
			'Antarctica/McMurdo',
			'Antarctica/South_Pole',
			'Arctic/Longyearbyen',
			'Asia/Aden',
			'Asia/Ashkhabad',
			'Asia/Bahrain',
			'Asia/Calcutta',
			'Asia/Chongqing',
			'Asia/Chungking',
			'Asia/Dacca',
			'Asia/Harbin',
			'Asia/Istanbul',
			'Asia/Kashgar',
			'Asia/Katmandu',
			'Asia/Kuwait',
			'Asia/Macao',
			'Asia/Muscat',
			'Asia/Phnom_Penh',
			'Asia/Rangoon',
			'Asia/Saigon',
			'Asia/Tel_Aviv',
			'Asia/Thimbu',
			'Asia/Ujung_Pandang',
			'Asia/Ulan_Bator',
			'Asia/Vientiane',
			'Atlantic/Faeroe',
			'Atlantic/Jan_Mayen',
			'Atlantic/St_Helena',
			'Australia/Canberra',
			'Australia/Yancowinna',
			);
		reset($timezones);
		foreach($aliases as $tz) {
			if(!in_array($tz, $timezones)) {
				$timezones[] = $tz;
				} // foreach
			} // if
		sort($timezones);
		return $timezones;
		} // get_time_zones()

	public static function get_language_codes() {
		$languages = array(
			// engish snippet from "https://gist.github.com/JamieMason/3748498"  html-languages.txt
			// CULTURE   SPEC.CULTURE  ENGLISH NAME
			'en',	// en-US       English
			'en-029',	//       en-029      English (Caribbean)
			'en-AU',	//        en-AU       English (Australia)
			'en-BZ',	//        en-BZ       English (Belize)
			'en-CA',	//        en-CA       English (Canada)
			'en-GB',	//        en-GB       English (United Kingdom)
			'en-IE',	//        en-IE       English (Ireland)
			'en-JM',	//        en-JM       English (Jamaica)
			'en-NZ',	//        en-NZ       English (New Zealand)
			'en-PH',	//        en-PH       English (Republic of the Philippines)
			'en-TT',	//        en-TT       English (Trinidad and Tobago)
			'en-US',	//        en-US       English (United States)
			'en-ZA',	//        en-ZA       English (South Africa)
			'en-ZW',	//        en-ZW       English (Zimbabwe)
			);
		return $languages;
		} // get_language_codes()

	public static function get_charsets() {
		$charsets = array(	// html5 only
		//	'ASCII',
		//	'ANSI',
			'ISO-8859-1',	// must be in <head> as '<meta charset="ISO-8859-1">'
			'UTF-8',
			'UTF-16',
			);
		return $charsets;
		} // get_charsets()

	public static function get_group_ids_text($cms_group_ids,$only_enabled = true) {
		$ids = explode(':',$cms_group_ids);
		$text = '';
		foreach($ids as $id) {
			if(!empty($text)) $text .= ', ';
			if((int)$id == 0) $text .= 'All Groups';
			else {
				$name = self::$cDBcms->get_data_in_table('cms_groups','cms_group_name','cms_group_id = ' . $id . ($only_enabled ? ' cms_group_enabled > 0':''));
				if((!$only_enabled) && (Ccms_auth::is_admin_user())) {
					$text .= '<a href="index.php?cms_action=cms_edit_groups&group_edit_id=' . $id . '">' . $name . '</a>';
					} // if
				else $text .= $name;
				if((!$only_enabled) &&
					(!self::$cDBcms->get_data_in_table('cms_groups','cms_group_enabled','cms_group_id = ' . $id))) {
					$text .= ' (disabled)';
					} // if
				} // else
			} // foreach
		return $text;
		} // get_group_ids_text()

	public static function get_group_user_ids_text($cms_group_user_ids,$only_enabled = true) {
		$ids = explode(':',$cms_group_user_ids);
		$text = '';
		foreach($ids as $id) {
			if(!empty($text)) $text .= ', ';
			if((int)$id == 0) $text .= 'All users';
			else {
				$name = self::$cDBcms->get_data_in_table('cms_users','cms_user_name','cms_user_id = ' . $id . ($only_enabled ? ' cms_user_enabled > 0':''));
				if(!$only_enabled) {
					$text .= '<a href="index.php?cms_action=edit_user&user_edit_id=' . $id . '">' . $name . '</a>';
					} // if
				else $text .= $name;
				if((!$only_enabled) &&
					(!self::$cDBcms->get_data_in_table('cms_users','cms_user_enabled','cms_user_id = ' . $id))) {
					$text .= ' (disabled)';
					} // if
				} // else
			} // foreach
		return $text;
		} // get_group_user_ids_text()

	public static function get_group_manager_ids_text($cms_group_admin_ids,$only_enabled = true) {
		$ids = explode(':',$cms_group_admin_ids);
		$text = '';
		foreach($ids as $id) {
			if(!empty($text)) $text .= ', ';
			if((int)$id == 0) $text .= 'No group managers';
			else {
				$name = self::$cDBcms->get_data_in_table('cms_users','cms_user_name','cms_user_id = ' . $id . ($only_enabled ? ' cms_user_enabled > 0':''));
				if(!$only_enabled) {
					$text .= '<a href="index.php?cms_action=edit_user&user_edit_id=' . $id . '">' . $name . '</a>';
					} // if
				else $text .= $name;
				if((!$only_enabled) &&
					(!self::$cDBcms->get_data_in_table('cms_users','cms_user_enabled','cms_user_id = ' . $id))) {
					$text .= ' (disabled)';
					} // if
				} // else
			} // foreach
		return $text;
		} // get_group_manager_ids_text()

	public static function do_plugin_installs($plugins = '', $verbose = false) {
		if((empty($plugins)) && (defined('CMS_C_ENABLED_PLUGINS'))) $plugins = CMS_C_ENABLED_PLUGINS;
		$ctl = new Ccms_config();
		$avail_plugins = $ctl->get_plugins($plugins);

		// if(empty($plugins)) return true;
		$nl = (self::is_cli() ? PHP_EOL:'<br>');
		if($verbose) echo $nl . "Installing/Updating plugins." . $nl;
		$plugins = explode(':',$plugins);
		foreach($avail_plugins as $plugin) {
			if(empty($plugin)) continue;	// blank in the config
			$class = 'C' . $plugin['name'] . '_plugin';
			if(in_array($plugin['name'],$plugins)) {	// install
				$class::install();
				if($verbose) echo "Installed plugin: " . $class . $nl;
				} // if
			else {
				$class::uninstall();
				if($verbose) echo "Uninstalled plugin: " . $class . $nl;
				} // else
			} // foreach
		self::addMsg('Installed plugin configs for ' . implode(', ',$plugins) . '.', 'info');
		return true;
		} // do_plugin_installs()

//	public static function cnt_digits($digits_str) {
//		$idx = 0; $cnt = 0;
//		while($idx < strlen($digits_str)) {
//			if(is_numeric(substr($digits_str,$idx,1))) $cnt++;
//			$idx++;
//			} // while
//		return $cnt;
//		} // cnt_digits()

	public static function validate_phone_number(&$phone) {	// au for the moment @TODO others
		if(preg_match('/[a-zA-Z]+/',$phone)) return false;
		$num = preg_replace('/[^0-9]+/','',$phone);
		$sep = (preg_match('/ /',$phone) ? ' ':'-');	// what's the preference
		$digits = strlen($num);	// self::cnt_digits($num);
		if(($digits < 6) || ($digits > 16)) {
			return false;
			} // if

		// format phone number
		if((preg_match('/^1[38]00/', $num)) && (strlen($num) >= 10)) { // 1300 or 1800 number
			$frt = substr($num,0,4);
			$mid = substr(substr($num,-6),0,3);
			$bck = substr($num,-3);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // if
		else if((substr($num,0,2) == '04') && (strlen($num) == 10)) { // mobile number
			$frt = substr($num,0,4);
			$mid = substr(substr($num,-6),0,3);
			$bck = substr($num,-3);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,2) == '13') && (strlen($num) == 6)) { // 13 number
			$frt = substr($num,0,2);
			$mid = substr(substr($num,-4),0,2);
			$bck = substr($num,-2);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,2) == '61') && (strlen($num) == 11)) {	// international
			$frt = substr($num,0,2);
			$std = substr($num,2,1);
			$mid = substr(substr($num,-8),0,4);
			$bck = substr($num,-4);
			$phone = '+' . $frt . $sep . $std . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,3) == '610') && (strlen($num) == 12)) {	// international
			$frt = substr($num,0,2);
			$std = substr($num,3,1);
			$mid = substr(substr($num,-8),0,4);
			$bck = substr($num,-4);
			$phone = '+' . $frt . $sep . $std . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,1) == '0') && (strlen($num) == 10)) { // std number
			$frt = substr($num,0,2);
			$mid = substr(substr($num,-8),0,4);
			$bck = substr($num,-4);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // else if
		else if(strlen($num) == 8) {	// local number
			$frt = substr($num,0,4);
			$bck = substr($num,-4);
			$phone = $frt . $sep . $bck;
			} // else
		else return false;

		return true;
	} // validate_phone_number()

	public static function get_code_errors() {	// get errors that are not normally displyed in debug
		if(!self::is_debug()) return '';

		$text = '';
		if(($prerr = preg_last_error()) != PREG_NO_ERROR) {	// regex error
			static $errtext;
			if (!isset($errtxt)) {
				$errtext = array();
				$constants = get_defined_constants(true);
				foreach ($constants['pcre'] as $c => $n) if (preg_match('/_ERROR$/', $c)) $errtext[$n] = $c;
				} // if
			$text .= array_key_exists($errcode, $errtext)? $errtext[$errcode] : '';
			} // if
		if(!empty($text)) self::addMsg($text);
		return $text;
		} // get_code_errors()

	public static function is_hover_boxes_ok() {
		// if(self::$tablet_flg) return false;
		if(self::$moz_4_flg) return false;
		return true;
		} // is_hover_boxes_ok()

	public static function backup_settings_configs() {
		// @TODO the windows version
		$res = array(); $ret = array();
		exec(CMS_FS_CLI_DIR . 'cms_backup_settings.sh',$res,$ret);
		if(($ret == 0) && (!empty($res))) {	// ok
			self::addMsg('Backed up settings and configurations.','success');
			self::$cDBcms->logEvent('INFO: Backed up settings and configurations.');
			return true;
			} // if
		self::addMsg('Failed to back up settings and configurations.','warning');
		self::$cDBcms->logEvent('WARNING: Failed to back up settings and configurations.');
		return false;
		} // backup_settings_configs()

	public static function backupOnSave() {
		// virtual place holder
		if(!INI_DB_SQLITE_BACKUP_ON_SAVE_BOOL) return true;	// it's ok
		return self::$cDBcms->backupDatabase();
		} // backupOnSave()

	public static function is_links_manager_inuse() {
		if(!LMC_LINKS_MANAGER_ENABLE) return false;
		$sql_query = "SELECT lm_link_id,lm_link_enabled" .
		" FROM  lm_links as l, lm_sections as s" .
		" WHERE l.lm_link_id > 0 AND l.lm_link_enabled > 0" .
		" AND s.lm_section_id > 0 AND s.lm_section_enabled > 0" .
		" AND l.lm_link_section_id = s.lm_section_id";
		if(($result = self::$cDBcms->query($sql_query)) &&
			(self::$cDBcms->num_rows($result) > 0)) {
			$test = self::$cDBcms->fetch_array($result);	// test for debugger
			self::$cDBcms->free_result($result);
			return true;
			} // if
		self::$cDBcms->free_result($result);
		return false;
		} // is_links_manager_inuse()

	public static function locate_image_url4css($dest_dir,$img_path,$image) {
		// @TODO only simple for now, needs to check/optimise for path and css directories.
		if(empty($image)) return '';
		if(is_readable($image)) {	// directly readable
			$img_path = dirname($image) . '/';
			$image = basename($image);
			} // if
		else if(!is_readable($img_path . '/' . $image)) return '';

		// assumes that both parameters are referenced to the same location
		$cnt = substr_count($dest_dir, '/');
		$pre = str_repeat('../',$cnt);
		$dl = strlen($img_path);
		$chk = substr($image,0,$dl);
		if($chk == $img_path) {	// it from the from of the string
			$image = substr($image,$dl);
			$text = 'url("' . $pre . $img_path . $image . '")';
			} // if
		else $text = 'url("' . $pre . $img_path . $image . '")';
		return $text;
		} // locate_image_url4css()

	public static function get_password_chk_regex($strength = false,$minlen = false) {
		if(!$strength) $strength = INI_PASSWORD_REQUIRED_REGEX;
		if(!$minlen) $minlen = LMC_MIN_PASSWD_LEN;
		$strng_punc = '!@#$%^&*';
		// not needed inside []	$strng_punc = preg_quote($strng_punc);
		$password_regexs = array(
			'feeble' => array(
				'min' => (LMC_MIN_PASSWD_LEN + 0),
				'reg' => '.*',
				'title' => 'Feeble: any characters (min of $minlen characters)',
				),
			'weak' => array(
				'min' => (LMC_MIN_PASSWD_LEN + 0),
				'reg' => '(?=.*[0-9a-zA-Z])',
				'title' => 'Weak: numbers, upper and lower case (min of $minlen characters)',
				),
			'medium' => array(
				'min' => (LMC_MIN_PASSWD_LEN + 2),
				'reg' => '(?=.*\d)(?=.*[a-z])(?=.*[A-Z])',
				'title' => 'Medium: at least 1 number, 1 lowercase and 1 uppercase (min of $minlen characters)',
				),
			'strong' => array(
				'min' => (LMC_MIN_PASSWD_LEN + 4),
				'reg' => '(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[' . $strng_punc . '])',
				'title' => 'Strong: at least 1 number, 1 lowercase, 1 uppercase and 1 of ' . htmlentities($strng_punc) . ' (min of $minlen characters)',
				),
			);
		if(!isset($password_regexs[$strength])) $strength = 'medium';
		if($minlen < $password_regexs[$strength]['min'])
			$minlen = $password_regexs[$strength]['min'];
		$regex = '^' . $password_regexs[$strength]['reg'] . '.{' . $minlen . ',}$';
		$title = $password_regexs[$strength]['title'];
		eval("\$title = \"$title\";");
		return array(
			'pattern' => $regex,
			'title' => $title,
			);
		} // get_password_chk_regex()

	protected static function fmt2inline_alt_image($img_data, $alt = '') {
		if(!CMS_C_INLINE_ICONS_IMAGES_ALLOW) return false;
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE < self::INLINE_IMG_MIN_SIZE) return false;
		// typical $img_data = "data:image/png;base64,(some b64 string of image)"
		if(!preg_match('/data\:image\//i',$img_data)) {
			return false;	// for now
			} // if
		$alt2 = preg_replace('/^.?alt="(.+?)".*$/i','$1',$img_data);
		if(empty($alt)) $alt = $alt2;	// use old
		$src = preg_replace('/^.?src="(.+?)".*$/i','$1',$img_data);
		// else assume $img_data is 'data:image/' . $ext . ';base64,' . $b64 (see conv2inline_alt_image)
		$text = (!empty($alt) ? 'alt="' . $alt . '"':'') .' src="'. $src . '"';
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE > strlen($text)) return false;
		return $text;
		} // fmt2inline_alt_image()

	public static function conv2inline_alt_image($img_file, $alt) {
		if(!CMS_C_INLINE_ICONS_IMAGES_ALLOW) return false;
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE < self::INLINE_IMG_MIN_SIZE) return false;
		if (empty($alt)) return false;
		if (!is_file($img_file)) return false;
		$bin = file_get_contents($img_file);
		$b64 = base64_encode($bin);
		$ext = pathinfo($img_file, PATHINFO_EXTENSION);
		$text = 'alt="' . $alt . '" src="data:image/' . $ext . ';base64,' . $b64 .'"';
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE > strlen($text)) return false;
		return $text;
		} // conv2inline_alt_image()

	public static function get_users_stats() {
		$users_path = VAR_FS_USERS_DIR;
		$users = array();
		$expiry = time() - self::$session_timeout;
		if($dh = opendir($users_path)) { // check sessions location
			$stmp = session_encode();	// save current session
			while (($file = readdir($dh)) !== false) {
				if(!Ccms::is_dir_usable($file)) continue;
				if(is_dir($users_path . $file)) continue;
				if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $file)) continue;
				$filepath = $users_path . $file;
				if((is_readable($filepath)) &&
					(preg_match('/\.json$/i',$file))) {
					if((!self::get_or_post_checkbox('show_expired')) &&	// include expired
						(filemtime($filepath) < $expiry)) continue;	// expired
					$json = self::load_json($filepath);
					if((!empty($json)) && (!empty($json['username']))) {
						$usr = array(
							'file' => $file,
							'expired' => ((filemtime($filepath) < $expiry) ? true:false),
							'data' => $json,
							);
						$users[($json['username'])] = $usr;
						} // if
					} // if
				} // while
			} // if
		return $users;
		} // get_users_stats()

	public static function get_human_fmt_time_interval($secs, $longest_unit = '') {
		$bit = array(
			'years' => array ('secs' => 31556926, 'mod' => 12,),
			'weeks' => array ('secs' => 604800, 'mod' => 52,),
			'days' => array ('secs' => 86400, 'mod' => 7,),
			'hours' => array ('secs' => 3600, 'mod' => 24,),
			'minutes' => array ('secs' => 60, 'mod' => 60,),
			'seconds' => array ('secs' => 1, 'mod' => 60),
			 );
		$flg = false; $ret = array();
		foreach($bit as $k => &$sm) {
			if((!$flg) && (!empty($longest_unit))) {
				if(strcasecmp($k,$longest_unit)) continue;
				$flg = true;
				$v = $secs / $sm['secs'];
				$ret[] = $v . $k;
				continue;
				} // if
			$v = $secs / $sm['secs'] % $sm['mod'];
			if($v > 0) {
				$ret[] = $v . $k;
				} // if
			} // foreach
		if((!$flg) && (!empty($longest_unit))) return "(Interval FMT error.)";
		return join(' ', $ret);
		} // get_human_fmt_time_interval()

} // Ccms_general
