<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_proxy.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of cms_proxy
 * proxy class to access files on local file systems and network shares
 * the proxy operation needs to be as fast as possible (not using the AppsCMS code or defines)
 *
 * @author robert0609
 */

include_once 'cms_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_proxy extends Ccms_base {

	const SLASH_KEY = '_##_';
	private static $signat_file = false;	// time saver

	function __construct() {
		parent::__construct();
		self::output_proxy_file();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function clear_signats($cli = false) {
		if(!$cli) {
			// later !!
			} // if

		if((!defined('VAR_FS_PROXY_DIR')) ||
			(!self::chkdir(VAR_FS_PROXY_DIR)))
			return 0;

		$files = scandir(VAR_FS_PROXY_DIR);
		$cnt = 0;
		foreach($files as $f) {
			$fp = VAR_FS_PROXY_DIR . $f;
			if((is_file($fp)) &&
				(self::is_file_usable($fp))) {
				@unlink($fp);
				$cnt++;
				} // if
			} // if
		self::addDebugMsg('Reset ' . $cnt . ' proxy signat files.','info');
		return $cnt;
		} // clear_signats()

	private static function get_signat_filename() {
		if(!self::$signat_file) {
			self::$signat_file = true;	// do once

			if(version_compare(PHP_VERSION, '5.4.0') >= 0) {
				if (session_status() == PHP_SESSION_NONE) {
					// @TODO check on other browsers
					@session_name(CMS_SESSION_NAME);
					@session_start();
					} // if
				} // if
			else {	// < 5.4
				if((session_id() == '') ||
					(!isset($_SESSION)) ||
					(empty($_SESSION))) {
					// @TODO check on other browsers
					@session_name(CMS_SESSION_NAME);
					@session_start();
					} // if
				} // else
			$sess_id = session_id();
			self::$signat_file = VAR_FS_PROXY_DIR . 'proxy_' . $sess_id . '.lst';
			} // if
		return self::$signat_file;
		} // get_signat_filename()

	protected static function save_proxy_signat($slash_keyed) {	// save a check signature for url for security reasons
		if(!$signat_file = self::get_signat_filename()) return false;
		if(file_exists($signat_file)) {	// check if already saved
			if(strpos(file_get_contents($signat_file),$slash_keyed) !== false) return true;	// already saved
			} // if
		if(!($fp = self::file_safe_wopen($signat_file, 'a'))) {
			self::addMsg('Failed to open proxy signature file "' . $signat_file . '".');
			return false;
			} // if
		if(fwrite($fp,$slash_keyed . PHP_EOL) === false) {
			self::addMsg('Failed to save proxy signature file "' . $signat_file . '".');
			self::file_safe_wclose($fp,$signat_file);
			return false;
			} // if
		self::file_safe_wclose($fp,$signat_file);
		return true;
		} // save_proxy_signat()

	protected static function check_proxy_signat($slash_keyed) {	// save a check signature for url for security reasons
		if(!$signat_file = self::get_signat_filename()) return false;
		if(file_exists($signat_file)) {	// check if already saved
			if($fh = @fopen($signat_file,'r')) {
				while(($line = fgets($fh)) !== false) { // read line from file, $line string has newline character at the end of string
//                  $line = preg_replace('/\r\n$|\n$/','',$line); // remove newline character at the end
					$line = str_replace(PHP_EOL,'',$line); // remove newline character at the end
//                  $chk = substr($slash_keyed,0,strlen($line)); // take first n characters where n = $line string length
					$chk = substr($slash_keyed,0,strlen($line)); // take first n characters where n = $line string length

					if($chk == $line) { // compare
						fclose($fh);
						return true;
						} // if
					} // while
				fclose($fh);
				} // if
			} // if
		self::log_msg('INFO: Failed to find proxy signature for "' . $slash_keyed . '".');
		return false;
		} // check_proxy_signat()

	public static function get_proxy_url($src) {		// returns the url to use in the web code, called from web code
		if((!file_exists($src)) || (!is_readable($src))) return false;

		// @TODO the $src needs to obvascated better
		// if(self::is_debug()) {
			$slash_keyed = str_replace('/',self::SLASH_KEY, self::clean_path($src));
		//	} // if
		// else {	// @TODO need to add security, $slash_keyed needs $src in signat file
		//	$slash_keyed = md5(str_replace('/',self::SLASH_KEY, self::clean_path($src)));
		//	} // else
		if(!self::save_proxy_signat($slash_keyed)) return false;
		$url = 'cms/cms_proxy.php?proxy=' . rawurlencode($slash_keyed);
		return $url;
		} // get_proxy_url()

	public static function clear_file_proxy() { // clear user session proxy list
		if(!$signat_file = self::get_signat_filename()) return false;
		if(!file_exists($signat_file)) return true;
		if(@unlink($signat_file) !== false) return true;	// cleared
		self::log_msg('ERROR: Failed to clear proxy signature file "' . $signat_file . '".');
		return false;
		} // clear_file_proxy()

	public static function output_proxy_file() {	// outputs the file given by get_proxy_url(), called from cms/cms_proxy.php
		if(self::is_get_or_post('proxy')) {
			$url = self::get_or_post('proxy');
			$slash_keyed = rawurldecode($url);
// 			echo $slash_keyed;
			if(!self::check_proxy_signat($slash_keyed)) return '';
			$src = str_replace(self::SLASH_KEY,'/',$slash_keyed);
			if((file_exists($src)) && (is_readable($src))) {
				header('Content-Type: ' . mime_content_type($src));
			    header('Content-Length: '.filesize($src)."\r\n");
				readfile($src);	// outputs the file
				return true;
				} // if
			else {	// add docroot
				$dr_src = '../' . $src;
				if((file_exists($dr_src)) && (is_readable($dr_src))) {
					header('Content-Type: ' . mime_content_type($dr_src));
				    header('Content-Length: '.filesize($dr_src)."\r\n");
					readfile($dr_src);	// outputs the file
					return true;
					} // if
				} // else
			} // if
		echo '';
		return false;
		} // output_proxy_file()

	} // Ccms_proxy
