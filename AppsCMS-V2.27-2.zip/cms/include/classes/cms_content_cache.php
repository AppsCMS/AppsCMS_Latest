<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_content_cache.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of cms_cache
 * controls and caches static output
 * mostly from include files
 * to provide faster operation of AppsCMS functionality
 * e.g. menu bars, nav bars, drop boxes, selectors, etc.
 *
 * @author robert0609
 */

class Ccms_content_cache extends Ccms_base {

	protected static $cached_content_files = false;

	const CONTENTS_CACHE_EXTENSION = 'contents_cache';	// filename extension used contents cache in the CMS_WS_CONTENT_CACHE_DIR directory

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	private static function init() {
		if(self::$cached_content_files) return;
		self::$cached_content_files = array(
			// list of content generating files that can be cached
			CMS_FS_INCLUDES_DIR . "cms_page_header.php",
			CMS_FS_INCLUDES_DIR . "cms_page_left_column.php",
			CMS_FS_INCLUDES_DIR . "cms_page_right_column.php",
			CMS_FS_INCLUDES_DIR . "cms_bodies_menu.php",
			CMS_FS_INCLUDES_DIR . "cms_config_menu.php",
			CMS_FS_INCLUDES_DIR . "tools.php",
			CMS_FS_OPS_DIR . "cms_about.php",
			CMS_FS_OPS_DIR . "cms_manual.php",
			CMS_FS_OPS_DIR . "cms_disclaimer.tmpl.php",
			CMS_FS_OPS_DIR . "cms_no_cookie.php",
			// user cached files added here
			);
		} // init()

	protected static function is_content_cache_used() {
		if(!defined('INI_CONTENT_CACHE_ENABLE_BOOL')) return false;	// here during rebuilds and upgrades
		if(!INI_CONTENT_CACHE_ENABLE_BOOL) return false;
		if(!self::chkdir(VAR_FS_CACHE_CONTENTS_DIR)) return false;
		self::init();
		return true;
		} // is_content_cache_used()

	protected static function get_cache_dir() {
		if(!self::is_content_cache_used()) return false;
		$user = Ccms_auth::get_logged_in_username();
		if(!empty($user)) {
			$cpath = self::clean_path(VAR_FS_CACHE_CONTENTS_DIR . '/' . $user . '/');
			if(self::chkdir($cpath)) return $cpath;
			return false;
			} // if
		return self::chkdir(VAR_FS_CACHE_CONTENTS_DIR);
		} // get_cache_dir()

	public static function reset_caches($show_res = true) {
		if(!$cpath = self::get_cache_dir()) return false;
		$df = scandir($cpath);
		$cnt = 0;
		$deleted = 0;
		$ok = true;
		foreach($df as $f) {
			if(!self::is_dir_usable($f)) continue;
			if(preg_match('/\.' . self::CONTENTS_CACHE_EXTENSION . '$/', $f)) {
				if(@unlink($cpath . $f) !== false) {
					$deleted++;
					} // if
				else $ok = false;
				$cnt++;
				} // if
			} // foreach
		if(!$ok) self::addMsg ('Failed to delete all cached files, deleted ' . $deleted . '/' . $cnt . '.');
		else if($show_res) self::addMsg ('Delete all ' . $deleted . ' cached files.','info');
		return true;
		} // reset_caches()

	protected static function is_cached_path($inc_file) {
		if(!self::is_content_cache_used()) return false;
		if(!in_array($inc_file, self::$cached_content_files)) return false;
		return true;
		} // is_cached_path()

	protected static function get_cache_path($inc_file, $is_cms_content, $cache_it) {
		if(!$cache_it) return false;
		if(($is_cms_content) && (!self::is_cached_path($inc_file))) return false;
		else if(!self::is_content_cache_used()) return false;
		if(!$cpath = self::get_cache_dir()) return false;
		if(self::is_debug()) $cache_path = $cpath . preg_replace('/[\/\.]/', '_', $inc_file) . '.' . self::CONTENTS_CACHE_EXTENSION;
		else $cache_path = $cpath . md5($inc_file) . '.' . self::CONTENTS_CACHE_EXTENSION;
		return $cache_path;
		} // get_cache_path()

	public static function cache_content($inc_file, $is_cms_content = true, $cache_it = false) {
		if(!is_readable($inc_file)) {	// source file not found.
			self::addMsg('Content cache failure. Cannot read "' . $inc_file . '".');
			return false;
			} // if
		$cache_path = self::get_cache_path($inc_file,$is_cms_content, $cache_it);
		if(($cache_path === false) || (empty($cache_path))) {
			include($inc_file);
			return false;
			} // if
		// else cache it
		$now = time();
		$ctime = false;	// cache time
		if((!is_readable($cache_path)) ||
			(!$ctime = filemtime($cache_path)) ||
			(((int)$now - (int)$ctime) > (int)INI_CONTENT_CACHE_TTL)) {	// time diff is less then TTL
			// make cache file
			ob_start();
			include($inc_file);
			$text = ob_get_clean();
			if(self::file_safe_write($cache_path, $text) === false) {
				$errors = error_get_last();
				self::addMsg('Failed cache contents "' . basename($inc_file) . '". ' . $errors['message']);
				include($inc_file);
				return false;
				} // if
			} // if
		// else already cached
		readfile($cache_path);	// ok to use
		return true;
		} // cache_content()

	public static function add_incfile2cache($inc_file) { // for apps include files
		if(!self::is_content_cache_used()) return false;
		if(in_array($inc_file, self::$cached_content_files)) return true;	// already there
		if(!is_readable($inc_file)) {	// source file not found.
			self::addMsg('Cannot add content file "' . $inc_file . '" to cache system.');
			return false;
			} // if
		self::$cached_content_files[] = $inc_file;
		return true;
		} // add_incfile2cache()

// dynamic methods

} // Ccms_content_cache

