<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_apps.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of cms_apps
 * general base class for local applications functions
 *
 * @author robert0609
 */

class Ccms_apps extends Ccms_general {

	protected static $app_flg = false;
	protected static $app_ini_flg = false;
	protected static $apps_config_done = false;
	protected static $apps_ini = false;
	protected static $apps_ini_flat = false;
	protected static $apps_ini_ctls = false;

	function __construct() {
		parent::__construct();
		if(!self::is_apps()) return;
		self::$app_flg = true;
		$this->init();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods
	public static function is_ini_congurable() {
		if(!Ccms_auth::is_admin_user()) return false;
		if(!self::is_apps()) return false;
		// if(is_readable(ETC_FS_APPS_CONFIG)) return true;
		if(!self::read_apps_ini_comments()) return false;
		if(!self::read_apps_ini_defaults()) return false;
		return true;
		} // is_ini_congurable()

	public static function &read_apps_ini_settings($rebuild = false) {
		if(self::$apps_ini) return self::$apps_ini;
		if(!file_exists(ETC_FS_APPS_CONFIG)) return self::$apps_ini;	// false
		$settings = parse_ini_file(ETC_FS_APPS_CONFIG,true);	// the data
		if($settings === false) {
			self::addMsg('Read of "' . basename(ETC_FS_APPS_CONFIG) . '" format error.');
			return self::$apps_ini;	// false
			} // if
		if((self::is_debug()) || ($rebuild)) {// check for missing sections and keys (and values)
			$settings_default = self::read_apps_ini_defaults();
			$defaults = 0;
			foreach ($settings_default as $sect_name => &$sect) {
				if(empty($settings[$sect_name])) {	// new/missing section
					$settings[$sect_name] = $sect;	// put the default values in
					self::log_msg('Missing APPS INI section: ' . $sect_name . ', using default.', 'warn');
					$defaults += count($sect);
					continue;
					} // if
				foreach ($sect as $key => $val) {
					if(!isset($settings[$sect_name][$key])) {	// new/missing section
						$settings[$sect_name][$key] = $val;	// put the default values in
						self::log_msg('Missing APPS INI section: ' . $sect_name . ', key: ' . $key . ', using default.', 'warn');
						$defaults += 1;
						continue;
						} // if
					} // foreach
				} // foreach
			if($defaults) {
				self::addDebugMsg("Using " . $defaults . " default values from Aggregated Applications INI Defaults.", 'warning');
				} // if
			if(($defaults) && (self::is_rebuild())) {
				self::write_ini_settings(ETC_FS_APPS_CONFIG,$settings,
					ETC_FS_APPS_CONFIG_JSON,
					"; rebuild to insert defaults.");
				}  // if
			} // if
		self::$apps_ini = $settings;
		return self::$apps_ini;
		} // read_apps_ini_settings()

	private static function merge_apps_ini_comments($ini,$parent_ini,$cntl) {
		$body_defines = Ccms_sm::get_bodies_defines();
		foreach($body_defines as $body_id => &$body) {
			if(empty($body['app_key'])) continue;
			if(empty($body['app_dir'])) continue;
			$fi = APPS_WS_DIR . $body['app_dir'] . '/ini/' . $ini;
			$app_key = $body['app_key'];
			$class = self::get_app_primary_class($body);
			if(file_exists(DOCROOT_FS_BASE_DIR . $fi)) {
				if(!$app_comments = parse_ini_file(DOCROOT_FS_BASE_DIR . $fi,true)) {
					self::addDebugMsg('Read of "' . $fi . '" format error.');
					continue;
					} // if
				// join it together
				foreach($app_comments as $sect_name => &$sect) {
					foreach($sect as $key => &$val) {
						if($key == 'comment')
							$parent_ini[$app_key . $sect_name][$key] = $val;
						else {
							if(($cntl) && ($class) &&
								(method_exists($class,'is_app_setup_key_funcs_used')) &&
								($class::is_app_setup_key_funcs_used($key))) {	// check for app special funcs used for this app setup key
								$ctl = array(
									'text' => $val,
									'app_key' => $app_key,
									'_show_func' => (method_exists($class,'show_app_setup_value') ? $class . '::show_app_setup_value':false),
									'_form_input_func' => (method_exists($class,'input_app_setup_form_text') ? $class . '::input_app_setup_form_text':false),
									'_form_get_func' => (method_exists($class,'get_app_setup_form_value') ? $class . '::get_app_setup_form_value':false),
									);
								$parent_ini[$app_key . $sect_name][$app_key . $key] = $ctl;
								} // if
							else $parent_ini[$app_key . $sect_name][$app_key . $key] = $val;
							} // else
						} // foreach
					} // foreach
				} // if
			} // foreach
		return $parent_ini;
		} // merge_apps_ini_comments()

	public static function read_apps_ini_comments() {
		if(file_exists(APPS_FS_CONFIG_MSGS)) {
			$comments = parse_ini_file(APPS_FS_CONFIG_MSGS,true);	// the control keynames
			if($comments === false) {
				self::addMsg('Read of "' . basename(APPS_FS_CONFIG_MSGS) . '" format error.');
				return false;
				} // if
			} // if
		else $comments = array();	// empty primary/global settings
		return self::merge_apps_ini_comments('app.comments.ini', $comments,true);	// include apps comments
		} // read_apps_ini_comments()

	public static function read_apps_ini_defaults() {
		if(file_exists(APPS_FS_APPS_CONFIG_DEFAULT)) {
			$defaults = parse_ini_file(APPS_FS_APPS_CONFIG_DEFAULT,true);	// the contral keynames
			} // if
		else $defaults = array();
		return self::merge_apps_ini_comments('app.defaults.ini', $defaults,false);	// include apps defaults
		} // read_apps_ini_defaults()

 	protected static function get_apps_configs() {
		if(self::$apps_config_done) return true;
		self::$apps_config_done = true;	// only need once
		$apps_config = APPS_FS_INCLUDE_DIR . 'apps_config.php';
		if(file_exists($apps_config)) {
			include_once $apps_config;
			} // if
		return true;
		} // get_apps_configs()

	public static function get_settings($redefine = false) {
		// if(self::is_rebuild()) return false;
		if((!$redefine) && (self::$app_ini_flg)) return true;
		self::$app_ini_flg = true;

		self::get_apps_configs();

		if(!$settings = self::read_apps_ini_settings()) return false;

		// define apps settingss
		foreach($settings as $sect_name => $sect) {
			foreach($sect as $key => $val) {
				if(defined('APP_' . $key)) continue;
				switch(strtolower($val)) {
				case 'comment': break;	// only to help edit settings web page
				case '0':	// that what false becomes
				case 'false':
				//case 'inline':
					define('APP_' . $key,false);
					break;
				case '1':	// thats what true becomes
				case 'true':
				//case 'block':
					define('APP_' . $key,true);
					break;
				default:
					$val = self::get_macro_lookup($sect_name,$sect, $key, $val);
					define('APP_' . $key,$val);
					break;
					} // switch
				} // foreach
			} // foreach
		return true;
		} // get_settings()

	public static function get_apps_ini_value($key,$sect_name = false) { // get from the ini file directly
		$apps_settings = self::read_apps_ini_settings(); // cache
		if ((empty($sect_name)) || ($sect_name == '*')) { // flat lookup required (uniqueness required per manual)
			// slow way
			if (self::$apps_ini_flat === false) {
				self::$apps_ini_flat = array(); // cache
				foreach ($apps_settings as $sect_nam => &$sect) {
					foreach ($sect as $k => &$v) {
						self::$apps_ini_flat[$k] = $v;
				} // foreach
			} // foreach
		} // if
			if (!isset(self::$apps_ini_flat[$key]))
				return null;
			$value = self::$apps_ini_flat[$key];
		} // if
		else { // normal lookup
			if (!isset($apps_settings[$sect_name][$key]))
				return null;
			$value = $apps_settings[$sect_name][$key];
		} // else

		if (is_numeric($value))
			return $value;

		switch (strtolower($value)) {
			case 'false': $value = false;
			case 'true': $value = true;
			default:
				$value = self::get_macro_lookup($sect_name, $apps_settings[$sect_name], $key, $value);
				break;
		} // switch
		return $value;
		} // get_apps_ini_value()

	protected static function gen_app_css() {
		$body_defines = Ccms_sm::get_bodies_defines();
		$settings = self::read_apps_ini_settings();
		$ok = true;
		foreach($body_defines as $body_id => &$body) {
			if(empty($body['app_key'])) continue;
			if(empty($body['app_dir'])) continue;
			$app_key = $body['app_key'];
			$theme_key = $app_key . 'ThemeSettings';

			// make theme combo
			if(empty($body['app_dir'])) continue;
			$fi = APPS_WS_DIR . $body['app_dir'] . '/include/app_css.php';
			if(!file_exists(DOCROOT_FS_BASE_DIR . $fi)) continue;

			// do all three for compatibiblity
			$theme = array();
			if(isset($settings[$theme_key])) {
				foreach($settings[$theme_key] as $k => $v) {
					// make it look like the original INI file
					$kk = preg_replace('/^' . $app_key . '/','',$k);
					$theme['ThemeSettings'][$kk] = $v;

					$theme[$kk] = $v;	// the easy ones
					$theme[$k] = $v;	// the easy ones
					$theme[$theme_key][$k] = $v;	// compatibility version
					} // foreach
				} // if
			// $fo = APPS_WS_DIR . $body['cms_body_dir'] . '/stylesheets/app.css';
			$fo = APPS_WS_DIR . $body['app_dir'] . '/stylesheets/app.css';
			$gen_note = '"' . $body['cms_body_name'] . '" App CSS file generated on ' . self::get_gm_datetime() . PHP_EOL;
			ob_start();
			include(DOCROOT_FS_BASE_DIR . $fi);
			$text = ob_get_clean();
			if((!empty($text)) &&
				($fh = self::file_safe_wopen(DOCROOT_FS_BASE_DIR . $fo, 'w'))) {
				fwrite($fh, $text);
				self::file_safe_wclose($fh,$text);
				self::chmod_chown(DOCROOT_FS_BASE_DIR . $fo);
				self::addMsg('Updated "' . $body['cms_body_name'] . '" "app.css".','success');
				} // if
			else {
				$ok = false;
				self::addMsg('Failed to update "' . $body['cms_body_name'] . '" "app.css".');
				} // else
			} // foreach
		return $ok;
		} // gen_app_css()

	public static function save_apps_ini_settings(&$new_settings,$always_save = true) {
		Ccms_content_cache::reset_caches(false);
		Ccms_minify_plugin::expire_cache();
		if(!self::is_rebuild()) {	// hot fix bug fix for orphan removal
			if($old_settings = self::read_apps_ini_settings()) {
				foreach($old_settings as $sect_name => $section) {
					// put in missings sections
					if(!isset($new_settings[$sect_name])) {
						$new_settings[$sect_name] = $section;
						} // if
					} // foreach
				} // if
			} // if
		self::insert_macros($new_settings);

		$ini_cntl = self::read_apps_ini_comments();	// get control file
		$settings_default = self::read_apps_ini_defaults();
		if($settings_default === false) {
			self::addMsg('Read of "' . basename(APPS_FS_APPS_CONFIG_DEFAULT) . '" format error.');
			return false;
			} // if
		$save_settings = array();
		foreach($ini_cntl as $sect_name => $section) {
			foreach($section as $key => $value_comment) {
				if($key == 'comment') continue;
				if(!isset($new_settings[$sect_name][$key])) $new_value = '';
				else {
					$new_value = $new_settings[$sect_name][$key];
					if(is_array($new_value)) {
						if(in_array('',$new_value)) $new_value = '';	// use default
						else $new_value = implode(' ',$new_value);
						} // if
					} // else

				if((empty($new_value)) && (!is_numeric($new_value)) &&
					(!empty($settings_default[$sect_name][$key]))) {
					$new_value = $settings_default[$sect_name][$key];
					$new_settings[$sect_name][$key] = $new_value;
					self::addMsg('Restore apps default; ' . Ccms::unmake_hungarion_fmt($sect_name) . ', ' . Ccms::make_nice_name($key) .' = "' . $new_value . '".','info');
					} // if

				if((!preg_match('/theme/i',$sect_name)) &&
					(!isset($ini_cntl[$sect_name][$key]['app_key']))) {
					if($new_value == '0') $new_value = 'false';
					if($new_value == '1') $new_value = 'true';
					} // if

				if((self::is_macro_lookup($sect_name, $new_value)) &&
					(self::get_macro_lookup($sect_name, $key, $new_value)) &&
					(!empty($settings_default[$sect_name][$key]))) {
					$macro = $new_value;
					$new_value = $settings_default[$sect_name][$key];
					$save_settings[$sect_name][$key] = $new_value;
					self::addMsg('Bad app macro expansion, using default; ' . Ccms::unmake_hungarion_fmt($sect_name) . ', ' . Ccms::make_nice_name($key) .' = "' . $new_value . '" (was "' . $macro . '").','info');
					} // if

				$save_settings[$sect_name][$key] = $new_value;
				} // foreach
			} // foreach
		if((empty($save_settings)) || (!is_array($save_settings))) {
			self::addMsg('No apps settings.','info');
			} // if

		if((!$always_save) && (!self::is_rebuild())) {
			$cmp = self::cmp_arrays($save_settings,$old_settings);
			if($cmp == 0) {
				self::addMsg('Unchanged APPS INI file.','info');
				return true;
				} // if
			} // if

		$hc =	'; Copyright ' . 	CMS_C_CO_NAME . ' ' . date('Y') . PHP_EOL .
				'; Contains common applications stylesheet settings.' . PHP_EOL .
				'; NOTE: backslashes are evaluated when read in by PHP (e.g. \e should be written as \\e).' . PHP_EOL;
		if(!self::write_ini_settings(ETC_FS_APPS_CONFIG,$save_settings,ETC_FS_APPS_CONFIG_JSON,$hc)) return false;

		if(file_exists(APPS_FS_INCLUDE_DIR . 'apps_css.php')) {
			// build the apps.css changes

			// import global theme settings for apps
			if((!isset($theme)) ||
				(empty($theme)) ||
				(!isset($theme['ThemeSettings'])) ||
				(!is_array($theme['ThemeSettings']))) {
				$theme = Ccms::read_cms_ini_settings(false,self::get_install_ini_sections());
				} // if

			$gen_note = 'Apps CSS file generated on ' . self::get_gm_datetime() . PHP_EOL;
			$odd_even_ratio = Ccms::get_cms_ini_value('ODD_EVEN_ROW_CHG','ThemeSettings');	// typ '0.10'; // table row ratio for contrast
			$out = ETC_FS_CSS_DIR .'apps.css';
			ob_start();
			include(APPS_FS_INCLUDE_DIR . 'apps_css.php');
			$text = ob_get_clean();
			if((!empty($text)) &&
				($fh = self::file_safe_wopen($out, 'w'))) {
				fwrite($fh, $text);
				self::file_safe_wclose($fh,$out);
				self::chmod_chown($out);
				self::addMsg('Updated general "apps.css".','success');
				} // if
			else {
				$ok = false;
				self::addMsg('Failed to update general "apps.css".');
				} // else
			} // if

		Ccms_content_cache::reset_caches();
		Ccms_gotcha_plugin::reset_cache();
		Ccms_proxy::clear_signats();
		Ccms_minify_plugin::reset_cache();

		if(!self::do_std_app_ini_saved()) return false;
		if(!self::gen_app_css()) return false;
		return true;
	} // save_apps_ini_settings()

	public static function is_apps() {
		if(!is_dir(APPS_FS_DIR)) return false;	// not present
		if(!is_readable(APPS_FS_DIR)) return false;	// not present
		return true;
		} // is_apps()

	public static function get_dyn_cntl_plugin_names() {
		$paths = Ccms_autoloader::get_ops_dirs_list();
		foreach($paths['plugins'] as $dir) {
			$files = scandir($dir);
			$dyn_pls = array();
			foreach($files as $f) {
				if(!self::is_dir_usable($f)) continue;
				if((!self::is_debug()) && (preg_match('/^example/',$f))) continue;
				$pi = pathinfo($f);
				if(!isset($pi['extension'])) continue;
				if(strtolower($pi['extension']) != 'php') continue;
				$class = 'C' . $pi['filename'] . '_plugin';
				if((Ccms_autoloader::find_plugin($class)) &&
					(method_exists($class, 'is_dynamic_controller')) &&
					($class::is_dynamic_controller() === true)) {
					$dyn_pls[] = $class;
					} // if
				} // foreach
			} // foreach
		return $dyn_pls;
		} // get_dyn_cntl_plugin_names()

	protected static function get_app_primary_class(&$body) {
		if(empty($body['app_name'])) return false;
		if(empty($body['app_key'])) return false;
		if(empty($body['app_dir'])) return false;
		$app_name = $body['app_name'];
		$app_key = $body['app_key'];
		$app_dir = $body['app_dir'];
		$class = 'C' . $app_name . '_app';
		if(!class_exists($class)) return false;
		return $class;
		} // get_app_primary_class()

	public static function do_std_app_warnings() {
		$body_defines = self::$body_defines;
		foreach($body_defines as $body_id => &$body) {
			$class = self::get_app_primary_class($body);
			if(!$class) continue;
			if(method_exists($class,'do_app_warnings')) {
				$class::do_app_warnings();
				} // if
			} // foreach
		return true;
		} // do_std_app_warnings()

	public static function do_std_app_ini_saved() {
		$body_defines = self::$body_defines;
		foreach($body_defines as $body_id => &$body) {
			$class = self::get_app_primary_class($body);
			if(!$class) continue;
			if(method_exists($class,'do_app_ini_saved')) {
				$class::do_app_ini_saved();
				} // if
			} // foreach
		return true;
		} // do_std_app_ini_saved()

	public static function get_ini_apps_input_ctl($ini_key) {
		if(!self::$apps_ini_ctls) {
			self::$apps_ini_ctls = array();
			$body_defines = self::$body_defines;
			foreach($body_defines as $body_id => &$body) {
				$class = self::get_app_primary_class($body);
				if(!$class) continue;
				if(method_exists($class,'get_ini_app_input_ctl')) {
					$ini_ctl = $class::get_ini_app_input_ctl();
					if(!empty($ini_ctl)) {
						$app_key = &$body['app_key'];
						foreach($ini_ctl as $k => &$v)
							$v['class'] = $class;
							self::$apps_ini_ctls[$app_key . $k] = $v;
						} // if
					} // if
				} // foreach
			} // if
		if(empty($ini_key)) return self::$apps_ini_ctls;
		if(isset(self::$apps_ini_ctls[$ini_key]))
			return self::$apps_ini_ctls[$ini_key];
		return false;	// not found
		} // get_ini_apps_input_ctl()

	public static function convert_ini_apps_form_input(&$ini_ary) {
		foreach($ini_ary as $sect_name => &$s2c) {
			foreach($s2c as $k => &$v) {
				$val = $v;
				if($c = self::get_ini_apps_input_ctl($k)) {
					switch($c['type']) {
					case 'multi_select':
						$v = Ccms_options::multi_row_get_form_elems($k,$v,'',$c['val_sep']);
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					case 'multi_input':
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					default:
						break;
						} // switch
					} // if
				else if(is_array($v)) {
					if(in_array('',$v)) $val = '';	// use default
					else $val = implode(' ',$v);
					} // if
				$s2c[$k] = $val;	// ?? stripslashes($val);
				} // foreach
			} // foreach
		return $ini_ary;
		} // convert_ini_apps_form_input()

	public static function get_app_extend_menus(&$config_menu) {		// build a submenu for each app from
		// each app extend plugin
		$body_defines = &self::$body_defines;
		$all_paths = Ccms_autoloader::get_ops_dirs_list();
		$paths = &$all_paths['plugins'];
		$cnt = 0;
		$inline = false;
		// if((Ccms::is_menu_in_header()) || (INI_NAV_BAR_BOOL)) $inline = true;
		if(INI_NAV_BAR_BOOL) $inline = true;
		// if(!$inline) Ccms_drop_box::init('cms_sub_hover_block_outer','cms_sub_hover_block_inner');
		$app_sub_menus = array();
		foreach($body_defines as $id => &$body) {
			if(!isset($body['app_name'])) continue;
			$app_name = $body['app_name'];
			$class = 'C' . $app_name . '_app_extend_plugin';
			if(!$pl_a_e = Ccms_autoloader::find_plugin($class)) continue;
			if(!method_exists($class,'get_admin_uris')) continue;
			$aC = new $class();
			$uris = $class::get_admin_uris();
			unset($aC);	// clean up
			if(empty($uris)) continue;
			$app_menu = array(
				'th' => array(
					'text' => $body['cms_body_name'],
					'title' => 'App ' . $body['cms_body_name'] . ' Configs',
					),
				'td' => array(),
				);
			for($i = 0; $i < count($uris); $i++) {
				$uri = &$uris[$i];
				$td = array(
					'text' => $uri['text'],
					'title' => ($inline ? $body['cms_body_name'] . ' - ':'') . $uri['title'],
					'url' => 'index.php?cms_action=app_extend&app_name=' . $app_name . '&idx=' . ($i + 1),
					);
				if($inline) $config_menu['td'][] = $td; // put in direct
				else $app_menu['td'][] = $td;	// else put up a sub menu
				} // for
			if(!$inline) {
				$inner_style = '';
				if(self::$menu_in_header) $inner_style = ' style="left: 30px;"';
				else if(self::$right_column) $inner_style = ' style="right: 30px;"';
				else if(self::$left_column) $inner_style = ' style="left: 30px;"';

				ob_start();
				new Ccms_generate_Vmenu('apmenu_' . $app_name,'admin_pdb_container',$app_menu,true,true,20);
				$atext = ob_get_clean();
				$params = array(	// make $text_inner variable array
					'text_inner' => &$atext,
					'outer_class' => (!$inline ? 'cms_sub_hover_block_outer':'cms_hover_block_outer'),	// 'admin_pdb_container'),
					'inner_class' => (!$inline ? 'cms_sub_hover_block_inner':'cms_hover_block_inner'),
					//'outer_params' => '',
					'inner_params' => $inner_style,
					//'table_class' => '',
					);
				$text = Ccms_drop_box::hover_block($body['cms_body_name'],$params);
				$config_menu['td'][] = array(
					'text' => $text,	//$body['cms_body_name'],
					'title' => '',
					'url' => '',
					);
				} // if
			$cnt++;
			} // foreach
		return $cnt;
		} // get_app_extend_menus()

	// dynamic methods
	protected function init() {
		// if(self::is_rebuild()) return;
		Ccms_sm::get_bodies_defines();
		self::get_settings();
		} // init()

} // Ccms_apps
