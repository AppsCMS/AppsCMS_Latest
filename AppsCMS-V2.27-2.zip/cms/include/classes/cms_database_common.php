<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_database_common.php 2085 2021-07-06 16:24:36Z robert0609 $
 */

/**
 * Description of database
 *
 * @author robert0609
 */

class Ccms_database_common extends Ccms_base {

	protected $m_sDatabase = '';		// the database name used
	protected $m_bOpen = false;		// true when db link open
	private $username = '';
	private $password = '';

	public static $m_bSaveDBtransactions = false;
	public $m_bDB_checked = false;	// true indactes DB checked, dont check again
	public $m_sVersion = '';

	protected $db_chgd = false;

	public $m_bNew = false;	// true if db created

	function __construct($log = '') {
		parent::__construct($log);
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// methods
	public static function get_db_datetime($time = false) {	// returns date time string in DB compatible format, useful as it returns the SI DT string
		// @TODO why is this duplicated, and where has the base class gone !!!!
		if($time) return date('Y-m-d H:i:s',$time);
		return date('Y-m-d H:i:s');
		} // get_db_datetime()

	protected function out_import_stat_msg($msg) {	// output an iterative on a single line using line refresh
		self::flush_out_msg($msg);
		} // out_import_stat_msg()

	public function dt2sql_dt($dt) {
		$time = strtotime($dt);
		if($time === false) return false;
		$sql_dt = self::get_db_datetime($time);
		return $sql_dt;
		} // dt2sql_dt()

//	public function checkdate($date) {	// check the date is mysql std fmt 'yyyy-mm-dd'
//		// for sake of convienience this function is repeatly statically in Ccms_app_base.php
//		if(preg_match('/[0-9]{4,4}-[0-9]{2,2}-[0-9]{2,2}/', $date)) return true;
//		return false;
//		} // checkdate()

	protected function onError($error) {
		$this->logEvent('DB_ERROR ' . $this->m_sDatabase . ' - ' . $error);
		self::addMsg('DB_ERROR ' . $this->m_sDatabase . ' - ' . $error);
		if((!defined('INI_DB_DIE_ON_ERRORS_BOOL')) || (INI_DB_DIE_ON_ERRORS_BOOL != true)) return false;	// for short cut back
		echo self::getMsgs();
		die();
		} // onError()

	protected function log_result($result) {
		switch(gettype($result)) {
		case "boolean":
			$this->logEvent('DB_RESULT: ' . ($result ? 'true':'false'));
			break;
		case "integer":
		case "double":
		case "float":
		case "string":
			$this->logEvent('DB_RESULT: "' . $result . '"');
			break;
		case "object":
			$this->logEvent('DB_RESULT: ' . serialize($result));
			break;
		case "array":
			$this->logEvent('DB_RESULT: ' . json_encode($result));
			break;
		case "NULL":
			$this->logEvent('DB_RESULT: ' . 'null');
			break;
		case "resource":
		case "resource (closed)":
		case "unknown type":
		default:
			break;
			} // switch
		} // log_result()

	public static function array_trimCallback(&$str,$key) { $str = trim($str); } // array_trimCallback()
	public static function array_trim(&$array) { return array_walk_recursive($array,'self::array_trimCallback'); } // array_trim()

	// dynamic methods
	public function get_name() { return $this->m_sDatabase; } // get_name()
	public function get_host() { return ''; } // get_host() virtual
	public function save_reconstruct_DB_data() { return false; } // save_reconstruct_DB_data() virtual

	public function convertSyntaxSQLite2MySQL($def) {	// $def is the column definition
		$ignored_prefixes = array(
			'PRAGMA',
			'BEGIN TRANSACTION;',
			'COMMIT;',
			'SELECT * FROM sqlite_master;',
			'DELETE FROM sqlite_sequence;',
			'INSERT INTO "sqlite_sequence"',
			);

		foreach($ignored_prefixes as $chk) {
			if(preg_match('/' . $chk . '/i',$def)) return false;
			} // foreach

		$replacements = array(
			"INTEGER PRIMARY KEY" =>  "INTEGER AUTO_INCREMENT PRIMARY KEY",
			"AUTOINCREMENT" =>  "AUTO_INCREMENT",
			"DATETIME('NOW','UTC')" => "CURRENT_TIMESTAMP",	// "UTC_TIMESTAMP()",
			"DATETIME('NOW')" => "CURRENT_TIMESTAMP",	// "NOW()",
			"DATETIME" => "TIMESTAMP",
			"DEFAULT 't'" =>  "DEFAULT '1'",
			"DEFAULT 'f'" =>  "DEFAULT '0'",
			"ON CONFLICT FAIL" => "",
			",'t'" =>  ",'1'",
			",'f'" =>  ",'0'",
			);

		foreach($replacements as $chk => $rep) {
//			$def = preg_replace('/' . $chk . '/i',$rep,$def);
			$def = str_replace($chk,$rep,$def);
			$def = str_replace(strtolower($chk),$rep,$def);
			} // foreach
		return $def;
		} // convertSyntaxSQLite2MySQL()

	public function convertSyntaxMySQL2SQLite($def) {	// $def is the column definition
		$def = preg_replace('/\'/',"'",$def);	// Use '' instead of \'
		$def = preg_replace('/\"/','"',$def);	// Use " instead of \"
		$def = preg_replace('/\\r\\n/','\r\n',$def);	// Convert escaped \r\n to literal
		$def = preg_replace('/\\\\/','\\',$def);	// Convert escaped \ to literal
		$def = preg_replace('/ auto_increment/i','',$def);	// Remove auto_increment
		$def = preg_replace('/^[UN]*?LOCK TABLES.*/i','',$def);	// Remove locking statements
		return $def;
		} // convertSyntaxMySQL2SQLite()

	public function output($string) {
		$string = html_entity_decode($string,ENT_COMPAT,INI_CHAR_SET);
		return htmlspecialchars($string,ENT_COMPAT,INI_CHAR_SET);
		} // output()

	public function input($string) {
		return $string;
		} // input()

	protected function sanitize_string($string) {
		$string = ereg_replace(' +', ' ', trim($string));
		return preg_replace("/[<>]/", '_', $string);
		} // sanitize_string()

	public function prepare_input($string) {
		if (is_string($string)) {
			return trim($this->sanitize_string(stripslashes($string)));
		} // if
		elseif (is_array($string)) {
			reset($string);
			foreach($string as $key => &$value) {
				$string[$key] = prepare_input($value);
			} // foreach
			return $string;
		} // elseif
		else {
			return $string;
		} // else
	} // prepare_input()

	public function prepare_search_keyword($keyword) { // added by BF
		$keyword = prepare_input($keyword);
		if (empty($keyword))
			return $keyword;

		// ambiguous prefixes and suffixes that may hinder search
		$prefixes = array('[', ']', '{', '}', '\\', '/', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '|', '~', '?', '<', '>', '"', "'", '-', ';', ':', '.', ','); // single letter at this stage
		$suffixes = array('[', ']', '{', '}', '\\', '/', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '|', '~', '?', '<', '>', '"', "'", '-', ';', ':', '.', ',', 's', 'S'); // single letter at this stage

		if (is_array($keyword)) {
			reset($keyword);
			foreach ($keyword as $key => &$value) {
				$keyword[$key] = prepare_search_keyword($value);
			} // foreach
		} // if
		else {
			foreach ($prefixes as $p) {
				if (strlen($keyword) < 1)
					break;
				if (substr($keyword, 0, 1) == $p)
					$keyword = substr($keyword, 1);
			} // foreach
			foreach ($suffixes as $s) {
				if (strlen($keyword) < 1)
					break;
				if (substr($keyword, -1, 1) == $s)
					$keyword = substr($keyword, 0, -1);
			} // foreach
		} // else
		return $keyword;
	} // prepare_search_keyword()

	public function is_data_in_table($table,$colname,$data) {
		if(!$this->is_ok()) return false;
		if(!$this->is_table_present($table)) return false;	// no table
		$test_sql = "select ". $colname . " from " . $table .
			" where " . $colname . " = " . (is_numeric($data) ? $data:"'" . $this->input($data) . "'");
		if($test_result = $this->query($test_sql)) {
			if($test = $this->fetch_array($test_result)) {
				return true;	//$test[$colname];	// its there
				} // if
			} // if
		return false; // no data match
		} // is_data_in_table()

	public function get_row_count_in_table($table,$where = '') {	// virtual
		return false; // no data, error
		} // get_row_count_in_table()

	public function get_row_cnt($results = false) {	// virtual
		return -1;
		} // get_row_cnt()

	public function get_data_in_table($table,$colname,$where, $params = false) {
		if(!$this->is_ok()) return false;
		if((!$this->m_bDB_checked) &&
			(!$this->is_table_column_present($table,$colname))) return false;	// no table or no column
		$cols = (is_array($colname) ? $colname:explode(',',$colname));
		$test_sql = "select ". implode(', ',$cols) . " from " . $table .
			(!empty($where) ? " where " . $where:'') .
			(!empty($params) ? " " . $params:'');
		if($test_result = $this->query($test_sql)) {
			if($test = $this->fetch_array($test_result)) {
				// cols in ary, return ary
				return (is_array($colname) ? $test:$this->output($test[$colname]));
				} // if
			} // if
		return false; // no data match
		} // get_data_in_table()

	protected function checkAddDBcolumn($table, $column, $type) {	// virtual
		return false;
		} // checkAddDBcolumn()

	public function checkDropDBcolumn($table, $column) {	// virtual
		return false;
		} // checkDropDBcolumn()

	protected function checkAddDBtable($table) {
		if(!$this->is_ok()) return false;
		if($this->is_table_present($table)) return true;
		if ($this->query('CREATE TABLE ' . $table . ';')) return true;
		return false;
		} // checkAddDBtable()

	protected function set_time_limit($limit) {
		// dummy function
		} // set_time_limit()

	protected function chk_table_row_sanity(&$table,&$row) {	// very likely this will have overrides
		$upd = false;
		switch($table) {
		case 'cms_configs':
			if(isset($row['cms_config_key'])) {
				switch($row['cms_config_key']) {
				case "'CMS_C_VERSION'":
					if(self::is_rebuild()) {
						$row['cms_config_value'] = CMS_PROJECT_VERSION;	// don't overwrite new version
						$upd = true;
						} // if
					break;
				default:
					break;
					} // switch
				} // if
			break;
		case 'cms_users':
			if(isset($row['cms_user_inline_html'])) {
				unset($row['cms_user_inline_html']);	// remove old column
				$upd = true;
				} // if
			break;
		default:
			break;
			} // switch
		return $upd;
		} // chk_table_row_sanity()

	function backupDatabase($backupFolder = false, $cms_msg_info = false) {
		if(!$this->is_ok()) return false;
		// dummy virtual function
		return true;
		} // backupDatabase()

	function restoreDatabase($backupfile) {
		if(!$this->is_ok()) return false;
		// dummy virtual function
		return true;
		} // restoreDatabase()

	protected function installTable($table,$params,$drop = false, $verbose = false) {
		if(!$this->is_ok()) return false;
		// dummy function
		return true;
		} // installTable()

	protected function install_db_tables($only_table, $install_scripts, $verbose = false, $drop = false) {
		if(!$this->is_ok()) return false;
		// dummy function
		return true;
		} // install_db_tables()

} // Ccms_database_common

