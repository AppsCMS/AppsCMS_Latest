<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_sm.php 2081 2021-07-04 10:29:50Z robert0609 $
 */

/**
 * Description of _sm
 * The top class for cms_sm state machine
 *
 * @author robert0609
 */

/* @TODO
 * State Machine Truth Table
 * ======================================================================================================================================================
 * |                           |                                        Detected Enviroment Flags                                                       |
 * | Settings (bools)          | $tablet_flg | $tiny_flg | $block_html | $moz_4_flg | $fox_flg | $chrome_flg | $safari_flg | $edge_flg | $browser_html5 |
 * |===========================|=============|===========|=============|============|==========|=============|=============|===========|================|
 * | INI_DEBUG_BOOL            |             |           |             |            |          |             |             |           |                |
 * | INI_PAGE_STYLE_BLOCK_BOOL |             |           |             |            |          |             |             |           |                |
 * | INI_HEADER_BOOL           |             |           |             |            |          |             |             |           |                |
 * | INI_FOOTER_BOOL           |             |           |             |            |          |             |             |           |                |
 * | INI_NAV_BAR_BOOL          |             |           |             |            |          |             |             |           |                |
 * | INI_LEFT_COLUMN_BOOL      |             |           |             |            |          |             |             |           |                |
 * | INI_RIGHT_COLUMN_BOOL     |             |           |             |            |          |             |             |           |                |
 * | INI_PAGE_DB_MENU_BOOL     |             |           |             |            |          |             |             |           |                |
 * | self::$bodies_cnt         |             |           |             |            |          |             |             |           |                |
 * | self::$tools_cnt          |             |           |             |            |          |             |             |           |                |
 * | self::$navbar_cnt         |             |           |             |            |          |             |             |           |                |
 * | CMS_C_CUSTOM_HEADER       |             |           |             |            |          |             |             |           |                |
 * | CMS_C_CUSTOM_FOOTER       |             |           |             |            |          |             |             |           |                |
 * ======================================================================================================================================================
 * @TODO complete SM layout
 *
 */
class Ccms_sm extends Ccms_html {

	function __construct() {

		self::$docroot = DOCROOT_FS_BASE_DIR;
		$this->do_globals();

		if(!self::is_cli()) {

			// some versions of PHP and Apache don't use the same version info path
			$ver = false;
			if(function_exists('apache_get_version')) $ver = apache_get_version();
			if((empty($ver)) && (!empty($_SERVER['SERVER_SOFTWARE']))) $ver = $_SERVER['SERVER_SOFTWARE'];
			if(!empty($ver))
				self::$httpd_version = preg_replace('/^apache\/([0-9\.]+) .*$/i','\1',$ver);
			else self::$httpd_version = '2.4.0';

			if(INI_PHP_GBL_VAL_USE_BOOL) {
				self::set_chk_php_value('max_execution_time',INI_PHP_GBL_VAL_EXEC_TIME);	// PHP_INI_ALL
				self::set_chk_php_value('memory_limit',INI_PHP_GBL_VAL_MEMORY);	// PHP_INI_ALL
				self::set_chk_php_value('post_max_size',INI_PHP_GBL_VAL_POST_SIZE);	// PHP_INI_PERDIR (per dir)
				self::set_chk_php_value('max_file_uploads',INI_PHP_GBL_VAL_UPLOAD_FILES, true);	// PHP_INI_SYSTEM (in php.ini only)
				self::set_chk_php_value('upload_max_filesize',INI_PHP_GBL_VAL_UPLOAD_SIZE);	// PHP_INI_PERDIR (per dir)
				} // if
			} // if

		// debug definitions
		if (self::is_cli()) {
			self::set_chk_php_value('output_buffering', 'Off');
			self::set_chk_php_value('display_errors', 'On');
			self::set_chk_php_value('display_startup_errors', 'On');
			self::set_chk_php_value('html_errors', 'Off');
			} // if
		else if (self::is_debug()) {
			self::set_chk_php_value('output_buffering', 'Off');
			self::set_chk_php_value('display_errors', 'On');
			self::set_chk_php_value('display_startup_errors', 'On');
			self::set_chk_php_value('html_errors', 'On');
			} // else if
		else {
			self::set_chk_php_value('output_buffering', 'On');
			self::set_chk_php_value('display_errors', 'Off');
			self::set_chk_php_value('display_startup_errors', 'Off');
			self::set_chk_php_value('html_errors', 'Off');
			} // else
		parent::__construct();

		new Ccms_detector();	// detect client device and browser

		if(!empty(self::$ajax)) return;

		if(!$this->make_head_values()) {
			self::addMsg('Failed to make head values.');
			} // if

		self::$block_html = INI_PAGE_STYLE_BLOCK_BOOL;
		if ((self::$body_full_view) || (!INI_HEADER_BOOL) || (!INI_FOOTER_BOOL))
			self::$block_html = false;
		else if ((CMS_C_CUSTOM_HEADER) || (CMS_C_CUSTOM_FOOTER))
			self::$block_html = false;

		if ((self::$tablet_flg) && (self::$ssl_required))
			self::$block_html = false;
		if (self::$tiny_flg)
			self::$block_html = false;

		self::$tooltips_flg = $this->show_cms_title_tooltips();

		// do time savers
		self::is_menu_in_header();
		self::show_left_column();
		self::show_right_column();

		self::initMsgs();
		Ccms_auth::log_user_access();
		} // __construct()

	function __destruct() {
		Ccms_auth::log_user2apache();
		parent::__destruct();
		} // __destruct()

// dynamic functions
	private function do_globals() {

		// first get actions
		self::$cms_action = self::get_or_post('cms_action');
		if(!empty(self::$cms_action)) {
			$_SESSION['cms_action'] = self::$cms_action;
			} // if
		else {
			self::$action = strtolower(self::get_or_post('action'));
			if (!empty(self::$action)) {
				$_SESSION['action'] = self::$action;
				} // if
			else if (!empty($_SESSION['action'])) {
				self::$action = $_SESSION['action'];
				unset($_SESSION['cms_action']);
				} // else if
			else if (!empty($_SESSION['cms_action'])) {
				self::$cms_action = $_SESSION['cms_action'];
				unset($_SESSION['cms_action']);
				} // else if
			else {

				} // else
			} // else

		self::$ajax = Ccms::get_or_post('ajax');
		if((!self::$ajax) && (isset($_SESSION['callbacks']))) unset($_SESSION['callbacks']);	// make non persistent

		self::$app = Ccms::get_or_post('app');

		if(self::is_cms_action()) {	//
			self::$tool_name = self::get_or_post('tool_id');
			if(!empty(self::$tool_name)) {
				if((is_numeric(self::$tool_name)) && (($id = (int)self::$tool_name) > 0)) {
					// get the correct name, assume self::$body_name is the id
					self::$tool_id = $id;
					self::$tool_name = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_name', "cms_tool_id = " . $id );
					} // if
				else {
					self::$tool_id = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_id', "cms_tool_name = '" . self::$tool_name . "'");
					} //else
				if((int)self::$tool_id > 0) {
					self::$tool_version = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', "cms_tool_id = " . self::$tool_id);
					} // if
				} // if
			self::$link_name = self::get_or_post('link_id');
			if(!empty(self::$link_name)) {
				if((is_numeric(self::$link_name)) && (($id = (int)self::$link_name) > 0)) {
					// get the correct name, assume self::$body_name is the id
					self::$link_id = $id;
					self::$link_name = self::$cDBcms->get_data_in_table('cms_links', 'cms_link_name', "cms_link_id = " . $id );
					} // if
				else {
					self::$link_id = self::$cDBcms->get_data_in_table('cms_links', 'cms_link_id', "cms_link_name = '" . self::$link_name . "'");
					} //else
				if((int)self::$link_id > 0) {
					self::$link_version = self::$cDBcms->get_data_in_table('cms_links', 'cms_link_version', "cms_link_id = " . self::$link_id);
					} // if
				} // if
			} // if
		else {
			self::$body_name = self::get_or_post('body');
			if(!empty(self::$body_name)) {
				if((is_numeric(self::$body_name)) && (($id = (int)self::$body_name) > 0)) {
					// get the correct name, assume self::$body_name is the id
					self::$body_id = $id;
					self::$body_name = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_name', "cms_body_id = " . $id );
					if(empty(self::$body_name)) self::$body_id = false;
					} // if
				else {
					self::$body_id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_name = '" . self::$body_name . "'");
					if(empty(self::$body_id)) self::$body_name = false;
					} //else
				if((int)self::$body_id > 0) {
					self::$body_version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', "cms_body_id = " . self::$body_id);
					} // if
				} // if

			if(!empty(self::$body_id))
				$_SESSION['body'] = self::$body_id;
			else if (isset($_SESSION['body'])) {
				self::$body_id = $_SESSION['body'];
				unset($_SESSION['body']);	// only use once
				} // else if
			} // else

		self::$plugin = self::get_or_post('plugin');
		if (!empty(self::$plugin)) { // execute plugin
			$class = 'C' . self::$plugin . '_plugin';
			if ((Ccms_autoloader::find_plugin($class)) &&
				(method_exists($class, 'is_enabled')) &&
				($class::is_enabled(self::$plugin))) {

				if ($class::execute_form()) {
					$url = $class::executed_url(); // get return point
					Ccms::saveMsgs();
					header('Location: ' . $url);
					exit(0);
				} // if
			} // if
		} // if
	} // do_globals()

// static functions

	public static function is_menu_in_header() {
		// self::$menu_in_header = true;	// test
		if(!is_null(self::$menu_in_header)) return self::$menu_in_header;
		if((self::$action == 'get_eula') ||	// not on EULA page
			(self::$cms_action == 'get_eula') ||	// not on EULA page
			(INI_HEADER_BOOL) &&
			(!INI_NAV_BAR_BOOL) &&
			(self::$tiny_flg))
			self::$menu_in_header = true;
		else if((!INI_HEADER_BOOL) ||
			(CMS_C_CUSTOM_HEADER) ||
			(INI_LEFT_COLUMN_BOOL) ||
			(!INI_PAGE_DB_MENU_BOOL) ||
			(INI_NAV_BAR_BOOL) ||
			(self::$moz_4_flg) ||
			(!self::$browser_html5))
			self::$menu_in_header = false;
		else self::$menu_in_header = true;
		return self::$menu_in_header;
		} // is_menu_in_header()

	private static function is_admin_tools() {
		if (self::is_cli())
			return false;
		if ((self::get_or_post('action') == 'login') ||
			(self::get_or_post('action') == 'cms_login'))
			return false;
		if (Ccms_auth::is_admin_user())
			return true;
		else if (Ccms::get_tool_cnt() > 0)
			return true;
		return false;
	} // is_admin_tools()

	public static function show_left_column() {
		if(!is_null(self::$left_column)) return self::$left_column;
		if((self::$action == 'get_eula') ||	// not on EULA page
			(self::$cms_action == 'get_eula') ||	// not on EULA page
			(!INI_LEFT_COLUMN_BOOL) ||
			(INI_NAV_BAR_BOOL) || // shown in nav bar
			// (self::$tablet_flg) ||
			(self::$tiny_flg))
			self::$left_column = false;
		else {
			// this part closely mimics the cms_page_left_column.php file
			self::$left_column = false;	// assume off to start
			if(Ccms::get_body_cnt() > 0) self::$left_column = true;
			else if(!self::show_right_column ()) {
				if((!self::$tools_menu_output) &&
					(Ccms::get_tool_cnt() > 0))
					self::$left_column = true;
				else if((!self::$admin_menu_output) &&
					(Ccms_auth::is_group_manager()))
					self::$left_column = true;
				else if(self::is_admin_tools())
					self::$left_column = true;
				} // if
			} // else
		return self::$left_column;
		} // show_left_column()

	public static function show_right_column() {
		if(!is_null(self::$right_column)) return self::$right_column;
		if((self::$action == 'get_eula') ||	// not on EULA page
			(self::$cms_action == 'get_eula') ||	// not on EULA page
			(!INI_LEFT_COLUMN_BOOL) ||
			(!INI_RIGHT_COLUMN_BOOL) ||
			(INI_NAV_BAR_BOOL) ||	// shown in nav bar
			(self::$tiny_flg) ||
			(self::is_menu_in_header()))
			self::$right_column = false;
		else {
			// this part closely mimics the cms_page_right_column.php file
			self::$right_column = false;	// assume off
			if((INI_RIGHT_COLUMN_BOOL) && (Ccms::get_body_cnt() > 0)) {
				if((!self::$tools_menu_output) &&
					(Ccms::get_tool_cnt() > 0))
					self::$right_column = true;
				else if((!self::$admin_menu_output) &&
					(Ccms_auth::is_group_manager()))
					self::$right_column = true;
				else if(self::is_admin_tools())
					self::$right_column = true;
				} // if
			} // else
		return self::$right_column;
	} // show_right_column()

	public static function get_tools($redo = false) {
		if(($redo) || (self::$tools === false)) { // not set yet
			self::$tools = array();
			if((INI_TOOLS_LOGIN_REQD_BOOL) && (!Ccms_auth::is_user_logged_in())) return self::$tools;

			$sql_query = "SELECT  cms_tool_id,cms_tool_name,cms_tool_version,cms_tool_url,cms_tool_title, cms_tool_debug_only" .
				", cms_tool_new_page, cms_tool_enabled, cms_tool_ssl, cms_tool_login_required, cms_tool_group_ids, cms_tool_add_name2url" .
				" FROM  cms_tools" .
				" WHERE  cms_tool_enabled > 0" .
				(Ccms_auth::is_user_logged_in() ? "":" AND cms_tool_login_required = 0") .
				(self::is_debug() ? "":" AND cms_tool_debug_only = 0") .
				" ORDER BY  cms_tool_order,cms_tool_name,cms_tool_id";
			if (($result = self::$cDBcms->query($sql_query)) &&
				(self::$cDBcms->num_rows($result) > 0)) {
				$row = 0;
				while ($tool = self::$cDBcms->fetch_array($result)) {
					if(empty($tool['cms_tool_url'])) continue;
					if(!file_exists(LOCAL_FS_TOOLS_DIR . $tool['cms_tool_url'])) continue;
					if (!Ccms_auth::check_user_group_ids($tool['cms_tool_group_ids']))
						continue;

					$url = '';
					if ($tool['cms_tool_ssl'])
						$url .= (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL);

					if (!$tool['cms_tool_new_page']) {
						$url .= 'index.php?cms_action=tool&tool_id=' . (int) $tool['cms_tool_id'] . '&name=' . urlencode($tool['cms_tool_name']);
					} // if
					else {
						$url .= LOCAL_WS_TOOLS_DIR . $tool['cms_tool_url'] . ((int) $tool['cms_tool_add_name2url'] ? '?name=' . urlencode($tool['cms_tool_name']) : '');
					} // else

					self::$tools[] = array(
						'id' => 'cms_tool_id',
						'name' => $tool['cms_tool_name'],
						'version' => $tool['cms_tool_version'],
						'url' => $url,
						'new' => (($tool['cms_tool_new_page']) ? '" target="_blank' : ''),
						'title' => (!empty($tool['cms_tool_title']) ? strip_tags($tool['cms_tool_title']) : LOCAL_WS_TOOLS_DIR . $tool['cms_tool_url']) . (($tool['cms_tool_new_page'] && CMS_C_SHOWINNEWTAB) ? PHP_EOL . '(in a new tab)' : ''),
					);
				} // while
			} //if
			self::$cDBcms->free_result($result);
		} // if
		return self::$tools;
	} // get_tools()

	private static function is_on_navbar(&$nav_bav_grid,&$url) {
		if(!INI_NAV_BAR_BOOL) return false;
		foreach($nav_bav_grid as $g) {
			if ($g[0] == $url) return true;
			} // foreach
		return false;
		} // is_on_navbar()

	public static function get_bodies($init = false) {
		if (self::$bodies === false) { // not set yet
			if(!Ccms::$ajax) $nav_bav_grid = self::get_navbar_grid();
			self::$bodies = array();

			$sql_query = "SELECT  cms_body_id,cms_body_version,cms_body_installed,cms_body_name,cms_body_title, cms_body_cached,cms_body_full_view" .
				", cms_body_enabled, cms_body_file, cms_body_group_ids,cms_body_default, cms_body_debug_only,"
				. " cms_body_default_msgs, cms_body_login_page, cms_body_login_required, cms_body_description, cms_body_type, cms_body_dir" .
				" FROM  cms_bodies" .
				" WHERE  cms_body_enabled > 0" .
				(!Ccms_auth::is_user_logged_in() ? "":" AND cms_body_login_page = 0") .
				(Ccms_auth::is_user_logged_in() ? "":" AND cms_body_login_required = 0") .
				(self::is_debug() ? "":" AND cms_body_debug_only = 0") .
				" ORDER BY  cms_body_order,cms_body_name,cms_body_id";
			if (($result = self::$cDBcms->query($sql_query)) &&
				(self::$cDBcms->num_rows($result) > 0)) {
				$row = 0;
				while ($body = self::$cDBcms->fetch_array($result)) {
					if (!Ccms_auth::check_user_group_ids($body['cms_body_group_ids'])) continue;
					if(!Ccms_auth::is_page_allowed($body['cms_body_name'])) continue;
					if(Ccms::$ajax) continue;

					$url = '';
					$proxy_url = '';
					if($body['cms_body_type'] == Ccms_DB_checks::APP_TYPE_REVPROXY_FRAME) {
						if(!Ccms::host_check($body['cms_body_file'])) continue;
						$proxy_url .= $body['cms_body_file'];
						} // if
					else {
						if(!is_readable(PAGE_BODIES_FS_DIR . $body['cms_body_file'])) continue;
						} // else
					$url .= Ccms::get_body_uri($body);

					if((!$init) && (self::is_on_navbar($nav_bav_grid, $url))) continue;

					self::$bodies[] = array(
						'id' => $body['cms_body_id'],
						'name' => Ccms_html::get_navbar_icon_text($body['cms_body_id'],$body['cms_body_name']),
						'version' =>  $body['cms_body_version'],
						'cached' => $body['cms_body_cached'],
						'default_page' =>  $body['cms_body_default'],
						'login_page' => $body['cms_body_login_page'],
						'login_required' => $body['cms_body_login_required'],
						'file' =>  $body['cms_body_file'],
						'full_view' =>  $body['cms_body_full_view'],
						'url' => $url,
						'proxy_url' => $proxy_url,
						'type' => $body['cms_body_type'],
						'title' => (!empty($body['cms_body_title']) ? strip_tags($body['cms_body_title']) : ''),
						'debug_only' => $body['cms_body_debug_only'],
						'app_dir' => (empty($body['cms_body_dir']) ? '':$body['cms_body_dir']),
						'app_key' => self::get_app_key($body),
						'app_name' => self::get_app_name($body),
						);
					if(((int)self::$body_id > 0) && (self::$body_id == $body['cms_body_id'])) {
						self::$app_dir = (empty($body['cms_body_dir']) ? '':$body['cms_body_dir']);
						self::$app_key = self::get_app_key($body);
						self::$app_name = self::get_app_name($body);
						self::$app_type = $body['cms_body_type'];
						} // if
				} // while
			} //if
		self::$cDBcms->free_result($result);
		} // if
		return self::$bodies;
	} // get_bodies()

	public static function get_body_cnt() {
		if (self::$bodies_cnt === false) { // not set yet
			self::$bodies_cnt = count(self::get_bodies(true));
		} // if
		return self::$bodies_cnt;
	} // get_body_cnt()

	public static function get_body() {
		global $cCMS;
		if(isset(self::$page_info['body'])) return self::$page_info['body'];
		if(!self::get_body_cnt()) return false;
		$cCMS->lookup_default_body();
		if(isset(self::$page_info['body'])) {
			return self::$page_info['body'];
			} // if
		return false;
	} // get_body()

		private static function get_app_key(&$body) {
		if(empty($body['cms_body_dir'])) return false;
		$app_key = preg_replace('/[^0-9a-zA-Z]+/','_',$body['cms_body_dir']) . '_';
		$app_key = strtoupper($app_key);
		return $app_key;
		} // get_app_key()

	private static function get_app_name(&$body) {
		if(!empty($body['cms_body_name'])) {
			$app_name = preg_replace('/[^0-9a-zA-Z]+/','_',$body['cms_body_name']);
			return $app_name;
			} // if
		if(!empty($body['cms_body_dir'])) {;
			$app_name = preg_replace('/[^0-9a-zA-Z]+/','_',$body['cms_body_dir']);
			return $app_name;
			} // if
		return false;
		} // get_app_name()

	private static function define_body_const(&$body,$fs_dir_const,$fs_dir,$ws_dir_const,$ws_dir) {
		if(!is_dir($fs_dir)) return false;	// dir not there
		if(!defined($fs_dir_const)) {
			$body[$fs_dir_const] = $fs_dir;
			define($fs_dir_const, $fs_dir);
			} // if
		if(!defined($ws_dir_const)) {
			$body[$ws_dir_const] = $ws_dir;
			define($ws_dir_const, $ws_dir);
			} // if
		return true;
		} // define_body_const()

	private static function define_app_body_constants(&$body) {
		// define the standard FS and WS constants for the apps
		$apps_types = Ccms_DB_checks::get_apps_types_configs();
		$body['app_name'] = self::get_app_name($body);

		if(!isset($body['cms_body_type'])) return false;	// not yet
		$app_type = &$apps_types[((int)$body['cms_body_type'] % count($apps_types))];
		if(!isset($app_type['app_dirs'])) return false;
		if(empty($body['cms_body_dir'])) return false;

		$app_fs_dir = APPS_FS_DIR . $body['cms_body_dir'] . '/';
		$app_fs_dir_const = self::PRE_DEF_APPs_FS_DIR .  strtoupper($body['cms_body_dir']) . '_DIR';

		$app_ws_dir = APPS_WS_DIR . $body['cms_body_dir'] . '/';
		$app_ws_dir_const = self::PRE_DEF_APPs_WS_DIR .  strtoupper($body['cms_body_dir']) . '_DIR';

		self::define_body_const($body,$app_fs_dir_const,$app_fs_dir,$app_ws_dir_const,$app_ws_dir);

		foreach($app_type['app_dirs'] as $d) {	// do defines

			$app_fs_dir = APPS_FS_DIR . $body['cms_body_dir'] . '/' . $d . '/';
			$app_fs_dir_const = self::PRE_DEF_APPs_FS_DIR .  strtoupper($body['cms_body_dir'] . '_' . $d) . '_DIR';

			$app_ws_dir = APPS_WS_DIR . $body['cms_body_dir'] . '/' . $d . '/';
			$app_ws_dir_const = self::PRE_DEF_APPs_WS_DIR .  strtoupper($body['cms_body_dir'] . '_' . $d) . '_DIR';

			self::define_body_const($body,$app_fs_dir_const,$app_fs_dir,$app_ws_dir_const,$app_ws_dir);

			} // foreach

		$app_config = APPS_FS_DIR . $body['cms_body_dir'] . '/include/' . 'app_config.php';
		if(file_exists($app_config)) {
			$body['app_config'] = $app_config;
			include_once $app_config;
			} // if

		$app_css = APPS_FS_DIR . $body['cms_body_dir'] . '/stylesheets/' . 'app.css';
		if(file_exists($app_css)) {
			// save web location
			$body['app_css'] = APPS_WS_DIR . $body['cms_body_dir'] . '/stylesheets/' . 'app.css';
			} // if

		$app_js = APPS_FS_DIR . $body['cms_body_dir'] . '/javascript/' . 'app.js';
		if(file_exists($app_js)) {
			// save web location
			$body['app_js'] = APPS_WS_DIR . $body['cms_body_dir'] . '/javascript/' . 'app.js';
			} // if

		$body['app_dir'] = (empty($body['cms_body_dir']) ? '':$body['cms_body_dir']);
		$body['app_key'] = self::get_app_key($body);

		return true;
		} // define_app_body_constants()

	public static function get_bodies_defines() {	// to define APPs_
		if (self::$body_defines === false) { // not set yet
			self::$body_defines = array();

			$sql_query = "SELECT  " . (self::is_rebuild() ? '*':'cms_body_id,cms_body_name,cms_body_type,cms_body_dir') .
				" FROM  cms_bodies" .
				" ORDER BY  cms_body_order,cms_body_name,cms_body_id";
			if (($result = self::$cDBcms->query($sql_query)) &&
				(self::$cDBcms->num_rows($result) > 0)) {
				$row = 0;
				while ($body = self::$cDBcms->fetch_array($result)) {
					self::define_app_body_constants($body);
					self::$body_defines[($body['cms_body_id'])] = $body;
				} // while
			} //if
		self::$cDBcms->free_result($result);
		} // if
		return self::$body_defines;
	} // get_bodies_defines()

public static function get_tool_cnt($redo = false) {
		if (($redo) || (self::$tools_cnt === false)) { // not set yet
			self::$tools_cnt = count(Ccms::get_tools($redo));
		} // if
		return self::$tools_cnt;
	} // get_tool_cnt()

	public static function get_body_version($body = false) {
		if((empty($body)) || (!is_array($body))) return self::$body_version;
		$version = self::getDottedKeys2Var($body,'*.cms_body_version');
		if(!empty($version)) return $version;
		$id = self::getDottedKeys2Var($body,'*.cms_body_id');
		if((!empty($id)) &&
			($version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', "cms_body_id = " . $id)))
			return $version;
		return self::$body_version;
		} // get_body_version()

	public static function get_tool_version($tool = false) {
		if((empty($tool)) || (!is_array($tool))) return self::$tool_version;
		$version = self::getDottedKeys2Var($body,'*.cms_tool_version');
		if(!empty($version)) return $version;
		$id = self::getDottedKeys2Var($body,'*.cms_tool_id');
		if((!empty($id)) &&
			($version = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', "cms_tool_id = " . $id)))
			return $version;
		return self::$tool_version;
		} // get_tool_version()

	public static function get_navbar_grid_sanitised(&$navbar_grid, $privileged = true) {
		$navbar_grid = array();	// clean it
		$navbar_cnt = 0;
		if (strlen(CMS_C_NAVBAR_LINKS) > 8) { // 6 is the minimum size for of serialized array
			// test echo CMS_C_NAVBAR_LINKS;
			$grid_all = unserialize(CMS_C_NAVBAR_LINKS);	// hot fix for PHP5 on V2.19-2
			foreach ($grid_all as $g) { // check body enabled
				$where = false;	// stop it repeating
				$u = false;
				if((preg_match('/login.php|action=.*login/i',$g[0])) &&
					((Ccms_auth::is_user_logged_in()) ||
					(preg_match('/cms_login/',self::$cms_action)) ||
					(preg_match('/login/',self::$action)))) {
					continue;
					} // if
				if((preg_match('/logout.php|action=.*logout/i',$g[0])) &&
					((!Ccms_auth::is_user_logged_in()) ||
					(preg_match('/cms_logout/',self::$cms_action)) ||
					(preg_match('/logout/',self::$action)))) {
					continue;
					} // if
				if (preg_match('/^.*body=[0-9]+&name=/i', $g[0])) {	// new style nav link
					$u = preg_replace('/^.*body=([0-9]+)&name=.*$/i', '$1', $g[0]);
					// $u = urldecode($u);
					if (!empty($u)) {
						$where = "cms_body_id = '" . (int)$u . "'" .
							((self::is_debug() && !$privileged) ? "":" AND cms_body_debug_only = 0");
						if((!self::$cDBcms->is_data_in_table('cms_bodies', 'cms_body_id', $u)) ||
							(!($body_file = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_file', $where))))
							continue;
						} // if
					} // if
				else if (preg_match('/.*body=/i', $g[0])) {	// old style nav link
					$u = preg_replace('/.*body=/i', '', $g[0]);
					$u = urldecode($u);
					if (!empty($u)) {
						$where = "cms_body_name = '" . self::$cDBcms->input($u) . "'" . (self::is_debug() ? "":" AND cms_body_debug_only = 0");
						if((!self::$cDBcms->is_data_in_table('cms_bodies', 'cms_body_name', $u)) ||
							(!($body_file = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_file', $where))))
							continue;
						} // if
					} // if
				else $g['bid'] = 0;

				if((!empty($u)) && (!empty($where))) {
					if(!is_readable(PAGE_BODIES_FS_DIR . $body_file)) continue;
					if(!self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_enabled', $where)) continue;

					$g['group'] = Ccms_auth::check_user_group_ids(self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_group_ids', $where));
					$g['allowed'] = Ccms_auth::is_navbar_element_allowed($g[1]);

					if($privileged) {
						if(!$g['group']) continue;
						if(!$g['allowed']) continue;
						} // if

					// add keyed values to decode the Ccms_options::grid_input_form_elems() method
					$g['name'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_name', $where);
					$g['bid'] = (int)self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', $where);
					$g['uri'] = $g[0];
					$g['text'] = $g[1];
					$g['title'] = $g[2];
					$icon = Ccms_html::get_navbar_icon_text($g['bid'],$g[1]);
					if(!empty($icon)) $g['nb_icon'] = $icon;
					else $g['nb_icon'] = $g[1];
					$g['mn_icon'] = Ccms_html::get_menu_icon_text($g['bid'],$g[1]);
					$g['icon'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_icon_url', $where);
					$g['image'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_image_url', $where);
					$g['debug_only'] = (self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_debug_only', $where) ? true:false);
					$g['production'] = !$g['debug_only'];

					// get text for the application, menus, etc.
					$g['description'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_description', $where);
					$g['purpose'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_purpose', $where);
					$g['info1'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_info1', $where);
					$g['info2'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_info2', $where);
					$g['version'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', $where);
					} // if
				$navbar_grid[] = $g;
				$navbar_cnt++;
				} // foreach
			} // if

		// add bodies to nav bar grid for other purposes
		$body_cnt = self::get_body_cnt();
		$bodies = self::get_bodies();
		$navbar_grid['apps'] = array();
		$navbar_apps = &$navbar_grid['apps'];
		foreach($bodies as &$body) {
			$navbar_apps[($body['name'])] = $body;
			} // foreach

		return $navbar_cnt;
		} // get_navbar_grid_sanitised()

	public static function get_navbar_grid($menu_only = false) {
		if ((self::$navbar_grid === false) || ($menu_only)) { // not set yet
			self::$navbar_grid = array();
			self::$navbar_cnt = 0;
			if (INI_NAV_BAR_BOOL) {
				self::$navbar_cnt = self::get_navbar_grid_sanitised(self::$navbar_grid);

//				if (($tool_cnt = self::get_tool_cnt(true)) > 0) {
//					self::$tools_on_navbar = true;
//					$tools = self::get_tools();
//					foreach ($tools as $tool) {
//						if(!Ccms_auth::is_navbar_element_allowed($tool['name'])) continue;
//						self::$navbar_grid[] = array(
//							0 => $tool['url'] . $tool['new'],
//							1 => $tool['name'],
//							2 => $tool['title'],
//							'tid' => $tool['id'],
//							'uri' => $tool['url'] . $tool['new'],
//							'title' => $tool['title'],
//							'nb_icon' => $tool['name'],
//							'mn_icon' => $tool['name'],
//							'version' => self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', 'cms_tool_id = ' . $tool['id']),
//							);
//
//						self::$navbar_cnt++;
//						} // foreach
//					self::$tools_cnt = 0;
//					self::$tools = array();
//				} // if

				if(!$menu_only) {
					// nothing for now
					} // if
			} // if
		} // if
		return self::$navbar_grid;
	} // get_navbar_grid()

	public static function get_navbar_cnt() {
		if (self::$navbar_cnt === false) { // not set yet
			self::get_navbar_grid();
		} // if
		return self::$navbar_cnt;
	} // get_navbar_cnt()

	public static function set_form_cms_return_action() {	// set return action required
		if(!self::is_get_or_post('cms_return_action')) return;
		$cms_return_action = rawurldecode(Ccms::get_or_post('cms_return_action'));
		echo '<input type="hidden" name="cms_return_action" value="' . rawurlencode($cms_return_action) . '"/>' . PHP_EOL;
	} // set_form_cms_return_action()

	public static function do_cms_return_action() {	// does not return action required
		if(!empty($_SESSION['cms_return_action'])) $cms_return_action = $_SESSION['cms_return_action'];
		else {
			if(!self::is_get_or_post('cms_return_action')) return;
			$cms_return_action = rawurldecode(Ccms::get_or_post('cms_return_action'));
			} // else
		if(!headers_sent()) {
			unset($_SESSION['cms_return_action']);
			$url = 'index.php?cms_action=' . $cms_return_action;
			header('Location: ' . $url);
			exit(0);
			} // if
		$_SESSION['cms_return_action'] = $cms_return_action;
		exit(0);
	} // do_cms_return_action()

	private static function log_error_handler_context($errcontext = false) {
		return;

//		if(empty($errcontext)) return;
//		echo PHP_EOL . 'CODE CONTEXT:' . PHP_EOL;
//		print_r($errcontext);
//		echo PHP_EOL;
//		return;

//		if(is_array($errcontext)) {
//			foreach($errcontext as $k => $v) {
//				self::addDebugMsg("CODE CONTEXT: [$k] => " . ((is_array($v) || (is_object($v))) ? print_r($v,true):$v),'warn');
//				} // foreach
//			} // if
//		else self::addDebugMsg("CODE CONTEXT: $errcontext",'warn');
		} // log_error_handler_context()

	public static function global_error_handler($errno, $errstr, $errfile, $errline, $errcontext) {
		// see "https://www.php.net/manual/en/function.set-error-handler.php"
		// this is especially helpful in catching and hilighting intermittent code disrupting warnings and errors.
		if (!(error_reporting() & $errno)) {
			// This error code is not included in error_reporting, so let it fall
			// through to the standard PHP error handler
			// the @ error ignore comes thru here too
			return false;
			} // if
		if(empty($errcontext)) $errcontext = false;	// context not always present
		switch ($errno) {
		case E_USER_ERROR:	// user generated with trigger_error()
			self::addDebugMsg("USER ERROR: [$errno] $errstr\n" .
				"  Fatal error on line $errline in file $errfile" .
				", PHP " . PHP_VERSION . " (" . PHP_OS . ")\n" .
				"Aborting.");
			exit(1);
			break;

		case E_USER_WARNING:	// user generated with trigger_error()
			self::addDebugMsg("USER WARNING: [$errno] $errstr in \"$errfile\" at line $errline",'warn');
			break;

		case E_USER_NOTICE:	// user generated with trigger_error()
			self::addDebugMsg("USER INFO: [$errno] $errstr in \"$errfile\" at line $errline",'info');
			break;

		case E_ERROR:	// std error number
			self::addMsg("CODE ERROR: [$errno] $errstr in \"$errfile\" at line $errline",'info');
			self::log_error_handler_context($errcontext);
			echo self::getMsgs();
			exit(101);	// don't lock up

		case E_WARNING:	// std error number
			if((self::is_debug()) || (!self::is_production())) {
				if(preg_match('/undefined/i',$errstr)) {
					self::addDebugMsg("CODE UNDEFINED (debug): [$errno] $errstr in \"$errfile\" at line $errline",'warn');
					} // if
				else {
					self::addDebugMsg("CODE WARNING (debug): [$errno] $errstr in \"$errfile\" at line $errline",'warn');
					} // else
				self::log_error_handler_context($errcontext);
				echo self::getMsgs();
				// if(preg_match('/constraint.+fail/i',$errstr)) return false;	// use the internal error handler
				exit(100);	// don't lock up
				} // if
			self::addDebugMsg("CODE WARNING: [$errno] $errstr in \"$errfile\" at line $errline",'warn');
			self::log_error_handler_context($errcontext);
			return true;

		default:
			self::addDebugMsg("CODE ERROR: Type: [$errno] $errstr in \"$errfile\" at line $errline");
			return false;	// use the internal error handler
			} // switch

		/* Don't execute PHP internal error handler */
		return true;
		} // global_error_handler()

	public static function chk_domain_to_host() {
		if(!INI_HOSTS_URLS_CHECKED_BOOL) return true;	// ok
		if(self::is_cli()) return true;	// ok, on CLI
		$doms = explode(':',INI_HOSTS_URLS_ALLOWED);
		if(empty($doms)) return true;	// nothing to check
		if((in_array($_SERVER['HTTP_HOST'],$doms))) return true;	// ok

		// else it's not me
		self::addMsg('Domain error, requested domain "' . $_SERVER['HTTP_HOST'] . '".');
		$url = INI_HOSTS_URLS_ERROR_URL;
		if(!empty($url)) {	// have redirect
			$proto = "";
			if(!preg_match('/^http:\/\/|^https:\/\//i',$url)) $proto = "http://";
			header('Location: ' . $proto . $url);
			exit (0);
			} // if
		return false;
		} // chk_domain_to_host()


} // Ccms_sm
