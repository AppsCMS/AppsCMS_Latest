<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_app_install.php 2070 2021-04-29 03:57:55Z robert0609 $
 */

/**
 * Description of cms_app_install
 *
 * Class to package, install and update applications
 *
 * @author robert0609
 */

// @TODO package dependencies (scan other apps for cross over)

class Ccms_app_install extends Ccms_general {

	protected $op = false;
	protected $package_id = 0;
	protected $package = false;
	protected $package_file = false;
	protected $package_file_tree = false;
	protected $cZIP = false;
	protected $apps_types = false;
	protected $priv_objs = false;

	const PKG_INFO_JSON = 'package_info.json';
	const PRIVATE_OBJS_CHKS = 'nbproject,private,.settings,.project,.vscode';	// keep IDE settings out of package


	function __construct($op = 'install',$package_id = 0, $package = false) {
		if(!self::is_app_pkg_ops_ok()) return;
		parent::__construct();
		$this->package_id = $package_id;
		$this->op = $op;
		$this->package = $package;
		$this->apps_types = Ccms_DB_checks::get_apps_types_configs();

		switch($this->op) {
		case 'build_package':
			$this->package_application($this->package_id);
			break;
		case 'package':
			$this->get_package_form($this->package_id);
			break;
		case 'install_package':
			$this->install_application($this->package);
			break;
		case 'install':
			$this->get_install_form($this->package);
			break;
		default:
			self::get_error_return_text('Unknown install packager operation');
			return;
			} // switch
		} // __construct()

	function __destruct() {
		parent::__destruct();
		if(($this->cZIP) && ($this->cZIP->status))
			$this->cZIP->close();
		} // __destruct()

	// static methods
	public static function is_app_pkg_ops_ok() {
		if(!@class_exists('ZipArchive')) return false;
		return true;
		} // is_app_pkg_ops_ok()

	protected static function get_error_return_text($msg,$type = false) {
		self::addMsg($msg,$type);
		if($type) return;	// only errors
		// put up a return link
		echo '<p>' . $msg . '</p>' . PHP_EOL;
		echo '<a href="index.php?cms_action=cms_edit_bodies">Close</a>' . PHP_EOL;
		} // get_error_return_text()

	public static function get_package_upload_file() {
		$destpath = VAR_FS_TEMP_DIR;
		if((isset($_FILES['packageToUpload']['name'])) &&
			(!empty($_FILES['packageToUpload']['name']))) { // check image location
			$filename = self::clean_path($destpath . '/' . $_FILES['packageToUpload']['name']);
			$tmp_name = $_FILES['packageToUpload']['tmp_name'];
			if(move_uploaded_file($tmp_name, $filename)) {
				self::chmod_chown($filename);
				return $filename;
				} // if
			} // if
		return false;
		} // get_package_upload_file()

	protected static function get_plugin_configs($body_dir) {
		$plugins = array();
		if(!is_dir($body_dir . '/plugins'))
			return $plugins;

		$plugins_dir = self::clean_path($body_dir . '/plugins');
		$files = scandir($plugins_dir);
		foreach($files as $file) {
			if(!preg_Match('/\.php$/',$file)) continue;
			include_once($plugins_dir . '/' . $file);
			$pl = 'C' . substr($file,0,-4) . '_plugin';
			if(!class_exists($pl)) {
				self::addMsg('Plugin ' . $pl . ' does not exist.');
				continue;
				} // if
			if(!method_exists($pl,'get_PL_config_keys_values')) {
				self::addMsg('Plugin ' . $pl . ' method get_PL_config_keys_values() does not exist.');
				continue;
				} // if
			//$pl_obj = new $pl();
			$method = $pl . '::get_PL_config_keys_values';
			if(!$configs = $method($pl)) {
				self::addMsg('Plugin ' . $pl . ' has no configuration.','warn');
				continue;	// no configs
				} // if
			$plugins[] = $configs;
			} // foreach
		return $plugins;
		} // get_plugin_configs()

	// dynamic methods
	protected function add_package_json_to_zip() {
		$json = json_encode($this->package);
		$json = self::json_text_pretty($json);
	    if(!$this->cZIP->addFromString(self::PKG_INFO_JSON,$json)) {
			$error = $this->cZIP->getStatusString();
			return false;
			} // if
		return true;
		} // add_package_json_to_zip()

	private function is_sorc_ok($dir_file) {
		if((is_dir($dir_file)) & (!self::is_dir_usable($dir_file))) return false;
		else if(!self::is_file_usable($dir_file)) return false;
		if(!$this->priv_objs) $this->priv_objs = explode(',',self::PRIVATE_OBJS_CHKS);
		foreach($this->priv_objs as $o) {
			$pat = '/' . preg_quote($o,'. \ + * ? [ ^ ] $ ( ) { } = ! < > | : - #') . '/i';
			if(preg_match($pat,$dir_file))
				return false;
			} // foreach
		return true;
		} // is_sorc_ok()

	protected function add_file_to_zip($dir,$file) {
		$path = (empty($dir) ? $file:self::clean_path($dir . '/' . $file)); // dont make absolute
		if(in_array($path,$this->package_file_tree)) return true;	// already there
		$this->package_file_tree[] = $path;
		if((!empty($dir)) && (!in_array($dir,$this->package_file_tree))) {
			$this->package_file_tree[] = $dir;
			$this->cZIP->addEmptyDir($dir);
			} // if
		if(!$this->cZIP->addFile(
			self::clean_path(DOCROOT_FS_BASE_DIR . $path),
			self::clean_path($path))) {
			$error = $this->cZIP->getStatusString();
			return false;
			} // if
		return true;
		} // add_file_to_zip()

	protected function add_dir_to_zip($dir,$exclude = array()) {
		if(empty($dir)) return false;
		if(!is_dir(DOCROOT_FS_BASE_DIR . $dir)) return false;
		if(in_array($dir,$this->package_file_tree)) return true;	// already there
		$this->package_file_tree[] = $dir;
		$this->cZIP->addEmptyDir($dir);
		if(in_array(preg_replace('/^.*\//','',$dir),$exclude)) return true;	// dir saved
		$files = opendir(DOCROOT_FS_BASE_DIR . $dir);
		while($file = readdir($files)) {
			if(!self::is_dir_usable($file)) continue;
			$path = self::clean_path($dir . '/' . $file);
			if(is_link(DOCROOT_FS_BASE_DIR . $path)) continue;
			else if(is_dir(DOCROOT_FS_BASE_DIR . $path)) {
				if(!$this->is_sorc_ok($file)) continue;
				$this->add_dir_to_zip($path,$exclude = array());
				} // if
			else if(is_file(DOCROOT_FS_BASE_DIR . $path)) {
				if(!$this->is_sorc_ok($file)) continue;
				if(in_array($file,$exclude)) continue;
				$this->add_file_to_zip($dir, $file);
				} // if
	 		} // while
		return true;
		} // add_dir_to_zip()

	private function get_nav_bar_body_link($cms_body_id,$cms_body_name) {
		if (strlen(CMS_C_NAVBAR_LINKS) < 8) return false;
		$grid_all = unserialize(CMS_C_NAVBAR_LINKS,array());
		$link = false;
		foreach ($grid_all as $g) { // check body enabled
			if(preg_match('/body=' . $cms_body_id . '/',$g[0])) {
				// remember $cms_body_id is transient between installs
				$link = array('text' => $g[1], 'title' => $g[2]);
				break;
				} // if
			} // foreach
		return $link;
		} // get_nav_bar_body_link()

	private function add_associated_files($body) {
		// used to collect images, icons, etc. in directories outside the apps dir.
		$body_files2chk = array(
			"cms_body_icon_url",
			"cms_body_image_url",
			"cms_body_terms_url",
			"cms_body_acknowledgment_url",
			"cms_body_licence_url",
			"cms_body_release_notes_url",
			"cms_body_readme_url",
			);
		if((!isset($this->package['assoc'])) ||
			(!is_array($this->package['assoc'])))
			$this->package['assoc'] = array();
		$app_dir = $body['cms_body_dir'];
		foreach($body_files2chk as $fc) {
			$file = $body[$fc];
			if(empty($file)) continue;
			if(preg_match('/^-1$|^0$/',$file)) continue;	// mostly the select option default
			if((!empty($app_dir)) && (strstr($file,$app_dir) !== false)) continue;	// in the app dir
			if(in_array($file, $this->package['assoc'])) continue;
			if(file_exists(DOCROOT_FS_BASE_DIR . $file)) {
				$this->package['assoc'][] = $file;
				$this->add_file_to_zip('',$file);
				} // if
			else if(!file_exists(DOCROOT_FS_BASE_DIR . '/' . $app_dir . '/' . $file)) {
				self::addDebugMsg('Unknown file / url: "' . $file . '" in "' . $body['cms_body_name'] . '".','warn');
				} // else
			} // foreach
		return $this->package['assoc'];
		} // add_associated_files()

	protected function add_plugin_configs($body_name,$body_dir) {
		if(!is_dir($body_dir . '/plugins')) {
			return true; // no plugins but OK
			} // if
		$this->package['bodies'][$body_name]['plugins'] = self::get_plugin_configs($body_dir);
		return true;	// got em
		} // add_plugin_configs()

	private static function get_app_ini($cms_body_id) {	// get ini configs
		$body_defines = self::$body_defines;
		$settings = Ccms_apps::read_apps_ini_settings();
		$ini = array();
		foreach($body_defines as $body_id => &$body) {
			if((int)$body['cms_body_id'] != (int)$cms_body_id) continue;
			$pre = preg_replace('/[^0-9a-zA-Z]+/','_',$body['cms_body_dir']) . '_';
			$pre = strtoupper($pre);
			foreach($settings as $sect_name => &$sect) {
				if(!preg_match('/' . $pre . '/',$sect_name)) continue;
				foreach($sect as $key => &$val) {
					if($key == 'comment') $ini[$sect_name][$key] = $val;
					else $ini[$sect_name][$key] = $val;
					} // foreach
				} // foreach
			} // foreach
		return $ini;
		} // get_app_ini()

	protected function package_application($package_id) {
		$package_name = self::get_or_post('package_name');
		$inc_dt_suffix = self::get_or_post_checkbox('add_dt_suffix');
		if($inc_dt_suffix) $dt_suffix = '-' . self::get_gm_datetime(false,true);
		else $dt_suffix = '';
		$packages = self::get_or_post('packages');
		if(empty($package_id)) $package_id = self::get_or_post ('packge_id');
		if((empty($package_name)) || (empty($package_id)) || (empty($packages)) || (count($packages) <= 0)) {
			self::get_error_return_text('Cannot find required package information, not packaged.','warn');
			return false;
			} // if
		$this->package_file_tree = array();
		$this->package = array(
			'bodies' => array(),
			'plugins' => array(),
			'nav_bar' => array(),
			'dirs' => array(),
			'files' => array(),
			'ini' => array(),
			);
		$sql_query = "SELECT * FROM cms_bodies WHERE cms_body_id = " . (int)$package_id;
		if(($result = self::$cDBcms->query($sql_query)) &&
			($body = self::$cDBcms->fetch_array($result))) {
			foreach($body as $k => $v) $$k = $v;
			$excludes = explode(',',$cms_tool_package_excludes);
			$body_filepath = PAGE_BODIES_FS_DIR . $cms_body_file;
			if((file_exists($body_filepath)) && (is_readable($body_filepath))) {
				$package_name = preg_replace('/[ ]/','_',strip_tags($package_name));
				$package_name = preg_replace('/&#?[a-z0-9]{2,8};/i','',$package_name);
				$this->package_file = $package_name . $dt_suffix . '.zip';
				$this->cZIP = new ZipArchive();
				if($this->cZIP->open(VAR_FS_EXPORT_DIR . $this->package_file,(ZipArchive::CREATE | ZipArchive::OVERWRITE)) !== true) {
					self::get_error_return_text('Cannot create "' . $this->package_file . '".');
					return false;
					} // if
				$this->add_file_to_zip(PAGE_BODIES_WS_DIR, $cms_body_file);
				$this->package['bodies'][$cms_body_name] = $body;
				if(!empty($cms_body_dir)) {
					$this->add_dir_to_zip(APPS_WS_DIR . $cms_body_dir,$excludes);
					if(!$this->add_plugin_configs($cms_body_name,APPS_WS_DIR . $cms_body_dir)) return false;
					} // if
				$this->package['nav_bar'][$cms_body_name] = $this->get_nav_bar_body_link($cms_body_id, $cms_body_name);
				$this->add_associated_files($body);

				// check for other bodies at the same location
				$sql_sub_query = "SELECT * FROM cms_bodies WHERE cms_body_id != " . $package_id;
				if($result = self::$cDBcms->query($sql_sub_query)) {
					while($sub_body = self::$cDBcms->fetch_array($result)) {
						if(!array_key_exists($sub_body['cms_body_id'],$packages)) continue;
						$sub_body_filepath = PAGE_BODIES_FS_DIR . $sub_body['cms_body_file'];
						if((file_exists($sub_body_filepath)) && (is_readable($sub_body_filepath))) {
							$this->package['bodies'][($sub_body['cms_body_name'])] = $sub_body;
							$this->package['nav_bar'][$cms_body_name] = $this->get_nav_bar_body_link($sub_body['cms_body_id'], $sub_body['cms_body_name']);
							$this->add_file_to_zip(PAGE_BODIES_WS_DIR, $sub_body['cms_body_file']);
							} // if
						if(!empty($sub_body['cms_body_dir'])) {
							$this->add_dir_to_zip(APPS_WS_DIR . $sub_body['cms_body_dir'],$excludes);
							if(!$this->add_plugin_configs($sub_body['cms_body_name'],APPS_WS_DIR . $sub_body['cms_body_dir'])) return false;
							} // if
						$this->add_associated_files($sub_body);
						} // while
					} // if

				$base_pattern = '/^' . preg_quote(DOCROOT_FS_BASE_DIR,'/') . '/';
				$consts = self::get_or_post('consts');
				if(!empty($consts)) {
					foreach($consts as $const => $st) {
						$def = constant($const);
						$def = preg_replace($base_pattern,'',$def);
						$this->package['dirs'][] = $def;
						$this->add_dir_to_zip($def,$excludes);
						} // foreach
					} // if
				$files = self::get_or_post('files');
				if(!empty($files)) {
					foreach($files as $file => $st) {
						$file = rawurldecode($file);
						$file = preg_replace($base_pattern,'',$file);
						$this->package['files'][] = $file;
						$this->add_file_to_zip('', $file);
						} // foreach
					} // if

				$this->package['name'] = $package_name;
				$this->package['type'] = 'application';
				$this->package['packager'] = CMS_PROJECT_SHORTNAME;
				$this->package['packager_version'] = CMS_PROJECT_VERSION;
				$this->package['_JSON_ModTime'] = self::get_gm_datetime();
				$this->package['_JSON_ModUser'] = Ccms_auth::get_logged_in_username();
				$this->package['ini'] = self::get_app_ini($cms_body_id);

				if($this->add_package_json_to_zip()) {
					$this->cZIP->close();
					self::get_error_return_text('Packaged application "' . $cms_body_name . '".','success');
					$_SESSION['download_dir'] = VAR_FS_EXPORT_DIR;
					$_SESSION['download_file'] = $this->package_file;
					// $url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?download_file=' . $this->package_file;
					// return $url;
					$url = $_SERVER['HTTP_REFERER'] . '&build=done';
					echo <<< EOTLD

	<script type="text/javascript">

		window.location.href = '{$url}';

	</script>

EOTLD;
//					header('Location: ' . $url);
//					exit(0);
					return true;
					} // if
				} // if
			} // if
		$this->cZIP->close();
		self::get_error_return_text('Failed to find page id ' . $package_id);
		return false;
		} // package_application()

	protected function get_dir_file_table($dir,$tree,$exclude) {
		$text = '';
		$text .= '<div class="page_config_dropdown_content" style="width: 500px;">' . PHP_EOL;
		$text .= '<table class="page_config page_config_edit">' . PHP_EOL;
		$text .= '	<tr class="page_body">';
		$text .= '		<th class="page_config">Common Application Files in ' . $dir . '</th>';
		$text .= '		<th class="page_config">Include in package.</th>';
		$text .= '	</tr>' . PHP_EOL;
		$base_pattern = '/^' . preg_quote(DOCROOT_FS_BASE_DIR . $dir,'/') . '/';
		$file_pattern = '/^' . preg_quote(DOCROOT_FS_BASE_DIR,'/') . '/';
		$row = 0;
		foreach($tree as $f) {
			if(!is_file($f)) continue;
			if(!preg_match($base_pattern,$f)) continue;	// not me
			if(dirname($f) != dirname(DOCROOT_FS_BASE_DIR . $dir . '/a')) continue;
			$use = true;
			foreach($exclude as $e) {
				$g = substr($f,0,strlen($e));
				if($g == $e) {
					$use = false;
					break;
					} // if
				} // foreach
			if(!$use) continue;

			$text .= '	<tr class="' . (($row++ & 1) ? 'page_config_odd':'page_config_even') . '">';
			$text .= '		<td class="page_config">';
			$text .= '			' . preg_replace($file_pattern,'',$f);
			$text .= '		</td>';
			$text .= '		<td class="page_config">';
			$text .= '			<label>Select: <input type="checkbox" name="files[' . rawurlencode($f) . ']"' .
								' title="Check to include this file in package." {$checked}/></label>';
			$text .= '		</td>';
			$text .= '	</tr>' . PHP_EOL;
			} // foreach
		$text .= '</table>' . PHP_EOL;
		$text .= '</div>' . PHP_EOL;
		if(!$row) return '';
		return $text;
		} // get_dir_file_table()

	public function get_package_form($package_id) {
		// get dependant packages and put up selection table
		$sql_query = "SELECT * FROM cms_bodies WHERE cms_body_id = " . (int)$package_id;
		if(($result = self::$cDBcms->query($sql_query)) &&
			($prim_body = self::$cDBcms->fetch_array($result))) {
			foreach($prim_body as $k => $v) $$k = $v;
			$body_filepath = PAGE_BODIES_FS_DIR . $cms_body_file;
			if((file_exists($body_filepath)) && (is_readable($body_filepath))) {
				$package_name = preg_replace('/[ ]/','_',strip_tags(CMS_C_CO_NAME . '_Application_' . $cms_body_name . (!empty($cms_body_version) ? '_' . $cms_body_version:'')));
				$package_name = preg_replace('/&#?[a-z0-9]{2,8};/i','',$package_name);
				$row = 0;
				$exclude = array();
				$app_places = 'Primary application body file in &quot;' . PAGE_BODIES_WS_DIR . $cms_body_name . '&quot;';
				if(!empty($cms_body_dir)) {
					$exclude[] = APPS_FS_DIR . $cms_body_dir;
					$app_places .= ' and application files in &quot;' . APPS_WS_DIR . $cms_body_dir . '&quot; directory';
					} // if
				$tr_class = (($row++ & 1) ? 'page_config_odd':'page_config_even');
				echo <<< EOTTOP

			<table class="page_config page_config_edit">
				<tr class="page_body">
					<th class="page_config">Application Name</th>
					<th class="page_config">Include in package.</th>
					<th class="page_config">Comments</th>
				</tr>
				<tr class="{$tr_class}">
					<th class="page_config">{$cms_body_name}</th>
					<td class="page_config">
						<input type="hidden" name="package_id" value="{$package_id}">
						<label>Select: <input type="checkbox" name="packages[{$package_id}]"
							title="Main application" CHECKED READONLY/></label>
					</td>
					<td class="page_config">
						 {$app_places}.
					</td>
				</tr>
EOTTOP;
				// check for other bodies at the same location
				$sql_sub_query = "SELECT * FROM cms_bodies WHERE cms_body_id != " . (int)$package_id;
				if($result = self::$cDBcms->query($sql_sub_query)) {
					while($sub_body = self::$cDBcms->fetch_array($result)) {
						foreach($sub_body as $k => $v) { $sub = 'sub_' . $k; $$sub = $v; }
						$sub_body_filepath = PAGE_BODIES_FS_DIR . $sub_cms_body_file;
						if((!file_exists($sub_body_filepath)) ||
							(!is_readable($sub_body_filepath)))
							continue;

						$tr_class = (($row++ & 1) ? 'page_config_odd':'page_config_even');
						if($cms_body_dir == $sub_cms_body_dir) $checked = ' CHECKED';
						else $checked = '';
						$disabled = ($sub_cms_body_enabled ? '':' (disabled)');

						$app_places = 'Sub application body file in &quot;' . PAGE_BODIES_WS_DIR . $sub_cms_body_name . '&quot;';
						if(!empty($sub_cms_body_dir)) {
							$exclude[] = APPS_FS_DIR . $sub_cms_body_dir;
							$app_places .= ' and in &quot;' . APPS_WS_DIR . $sub_cms_body_dir . '&quot; directory';
							} // if

						echo <<< EOTROW

				<tr class="{$tr_class}">
					<th class="page_config">{$sub_cms_body_name}<small>{$disabled}</small></th>
					<td class="page_config">
						<label>Select: <input type="checkbox" name="packages[{$sub_cms_body_id}]"
							title="Check to include {$sub_cms_body_name} as a sub application in package." {$checked}/></label>
					</td>
					<td class="page_config">
						 {$app_places}.
					</td>
				</tr>

EOTROW;

						} // while
					} // if

				echo <<< EOTMID

			</table>
			<br>
			<table class="page_config page_config_edit">
				<tr class="page_body">
					<th class="page_config">Common Applications Base Directories</th>
					<th class="page_config">Include in package.</th>
					<th class="page_config">Number of files.</th>
				</tr>

EOTMID;
				// look for common app defines
				$all_consts = get_defined_constants(true);
				$consts = &$all_consts['user'];
				asort($consts);
				$base_pattern = '/^' . preg_quote(DOCROOT_FS_BASE_DIR,'/') . '/';
				foreach($consts as $const => &$v) {
					if(!preg_match('/^APPS_FS_/',$const)) continue;	// leave only common apps dirs
					if(!is_dir($v)) continue;
					$tree = false;
					$cnt = self::recursiveScan($v, $tree);
					if($cnt <= 0) continue;	// nothing there

					$app_dir = preg_replace($base_pattern,'',$v);
					$tr_class = (($row++ & 1) ? 'page_config_odd':'page_config_even');
					$checked = '';
					$sub_dir_select = $this->get_dir_file_table($app_dir, $tree, $exclude);
					echo <<< EOTCONST

				<tr class="{$tr_class}">
					<td class="page_config">
						<div class="page_config_dropdown">
							<span>{$app_dir}</span>
							{$sub_dir_select}
						</div>
					</td>
					<td class="page_config">
						<label>Select: <input type="checkbox" name="consts[{$const}]"
							title="Check to include this sub-directory and all files in package." {$checked}/></label>
					</td>
					<td class="page_config">{$cnt}</td>
				</tr>

EOTCONST;
					} // foreach

				echo <<< EOTBOT

			</table>
			<br>
			<table class="page_config page_config_edit">
				<tr class="page_config">
					<td class="page_config">
						<br>
						<label>Package Name: <input type="text" name="package_name" value="{$package_name}"
							size="80" style="width: unset; max-width: unset;"
							title="Package name, punctuation and spaces are converted to underscores.">
						</label>
						&nbsp;
						<label><input type="checkbox" name="add_dt_suffix"
							title="Check to add date time suffix (e.g. YYYMMDD-HHMMSS) to package file name."
							CHECKED>
						</label>
						&nbsp;
						<label>
							<button type="submit" name="build_package" value="package" title="Build package.">
								Build
							</button>
						</label>
						&nbsp;
						<label>
							<button type="submit" name="cancel" value="cancel" title="Return to page / apps config.">
								Close
							</button>
						</label>
					</td>
				</tr>
			</table>

EOTBOT;
				return true;
				} // if
			} // if
		self::get_error_return_text('Failed to find page id ' . $package_id);
		return false;
		} // get_package_form()


/////////////////////////////////////// Install section \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

	private static function put_app_ini($ini,$cms_body_dir) {	// get ini configs
		$settings = Ccms_apps::read_apps_ini_settings();
		$pre = preg_replace('/[^0-9a-zA-Z]+/','_',$cms_body_dir) . '_';
		$pre = strtoupper($pre);
		foreach($ini as $sect_name => &$sect) {
			if(!preg_match('/' . $pre . '/',$sect_name)) continue;
			foreach($sect as $key => &$val) {
				if($key == 'comment') $settings[$sect_name][$key] = $val;
				else $settings[$sect_name][$key] = $val;
				} // foreach
			} // foreach
		return Ccms_apps::save_apps_ini_settings($settings,true);
		} // put_app_ini()

	public function install_application($package_file) {
		if((empty($package_file)) || (!file_exists($package_file))) {
			$pack_filename = self::get_or_post('pack_filename');
			if(empty($pack_filename)) {
				self::get_error_return_text('Cannot get package filename.');
				return false;
				} // if
			$package_file = VAR_FS_TEMP_DIR . rawurldecode($pack_filename);
			if(!file_exists($package_file)) {
				self::get_error_return_text('Cannot get package "' . $package_file . '".');
				return false;
				} // if
			} // if
		$this->package_file = $package_file;
		if(!$this->get_unzip_package_tree()) {
			// hmm
			return false;
			} // if
		$bodies = self::get_or_post('bodies');
		$files = self::get_or_post('files');
		$assoc = self::get_or_post('assoc');
		$nav_bar = self::get_or_post('nav_bar');
		$cZIP = new ZipArchive();
		if($cZIP->open($this->package_file) !== true) {	// open in read mode
			self::get_error_return_text('Cannot open "' . $package_file . '".');
			return false;
			} // if
		if(is_array($assoc)) $files = array_merge($files,$assoc);
		$seld_files = array();
		if((!empty($files)) && (is_array($files))) {
			foreach($files as $file => $ck) {
				// $ck = 'on'
				$seld_files[] = urldecode($file);
				} // foreach
			} // if
		$seld_bodies = array();
		$seld_app_dirs = array();
		foreach($bodies as $body => $ck) {
			// $ck = on
			$seld_body = urldecode($body);
			$body_conf = $this->package['bodies'][$seld_body];
			$seld_files[] = PAGE_BODIES_WS_DIR . $body_conf['cms_body_file'];
			$seld_app_dirs[] = APPS_WS_DIR . $body_conf['cms_body_dir'];
			$seld_bodies[$seld_body] = $body_conf;
			} // foreach
		$seld_nav_bar_links = array();
		foreach($nav_bar as $link => $ck) {
			// $ck = on
			$seld_link = urldecode($link);
			$link_conf = $this->package['nav_bar'][$seld_link];
			$seld_nav_bar_links[$seld_link] = $link_conf;
			} // foreach

		for ($i = 0; $i < $cZIP->numFiles; $i++) {
			$file = $cZIP->getNameIndex($i);
			if($file == self::PKG_INFO_JSON) continue;
			foreach($seld_app_dirs as $dir) {
				if(substr($file,0,strlen($dir)) == $dir) {
					if(!@$cZIP->extractTo(DOCROOT_FS_BASE_DIR,$file)) {	// save it;
						self::get_error_return_text('Cannot save "' . $file . '".');
						$cZIP->close();
						return false;
						} // if
					self::chmod_chown(DOCROOT_FS_BASE_DIR . $file);
					break;
					} // if
				} // foreach
			if(!in_array($file, $seld_files)) continue; // not unused
			if(!@$cZIP->extractTo(DOCROOT_FS_BASE_DIR,$file)) {	// save it;
				self::get_error_return_text('Cannot save file "' . $file . '".');
				$cZIP->close();
				return false;
				} // if
			self::chmod_chown(DOCROOT_FS_BASE_DIR . $file);
			} // for
		$cZIP->close();

		// now add / update DB
		$enabled_plugins = explode(':',CMS_C_ENABLED_PLUGINS);
		$pl_chgd = false;
		foreach($seld_bodies as $name => &$conf) {
			$fields = $conf;
			unset($fields['enabled']); unset($fields['plugins']);	// only for plugins
			unset($fields['cms_body_added']); unset($fields['cms_body_updated']);	// only for audits
			unset($fields['cms_body_id']);
			$fields['cms_body_installed'] = (self::get_or_post_checkbox('allow_changes') ? 0:1);
			$id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_name = '" . $conf['cms_body_name'] . "'");
			if((int)$id > 0) {	// update
				if(self::$cDBcms->perform('cms_bodies',$fields,'update','cms_body_id = ' . $id )){
					self::get_error_return_text('Updated "' . $conf['cms_body_name'] . '".','success');
					} // if
				else {
					self::get_error_return_text('Failed to update "' . $conf['cms_body_name'] . '".');
					return false;
					} // else
				} // if
			else { // insert
				if(self::$cDBcms->perform('cms_bodies',$fields)){
					self::get_error_return_text('Added "' . $conf['cms_body_name'] . '".','success');
					} // if
				else {
					self::get_error_return_text('Failed to add "' . $conf['cms_body_name'] . '".');
					return false;
					} // else
				} // else
			if(isset($this->package['bodies'][$name]['plugins'])) { // body plugins
				$plugins_confs = $this->package['bodies'][$name]['plugins'];
				// do the plugins
				foreach($plugins_confs as $pl_conf) {
					$pl_info = $pl_conf['info'];
					$pl_key = $pl_info['key'];
					$pl_class = $pl_info['class'];
					$plugin = $pl_info['plugin'];
					if(isset($pl_info['enabled'])) {
						if($pl_info['enabled']) {	// plugin enabled
							if(!in_array($plugin,$enabled_plugins)) {
								$enabled_plugins[] = $pl_key;
								$pl_chgd = true;
								} // if
							} // if
						else { // disabled
							if(($i = array_search($plugin,$enabled_plugins)) !== false) {
								unset($enabled_plugins[$i]);
								$pl_chgd = true;
								} // if
							} // else
						} // if

					// install configs basics
					if(!class_exists($pl_class)) {
						Ccms_autoloader::get_ops_dirs_list(true);	// so autoloader finds it
						if(!class_exists($pl_class)) {
							addmsg('Could include : ' . $pl_class );
							continue;
							} // if
						} // if
					$method = $pl_class . '::install';
					$ok = $method();
					if($ok) {
						// check key = value
						unset($pl_conf['info']);
						foreach($pl_conf as $k => $v) {
							self::$cDBcms->query('UPDATE cms_configs SET cms_config_value = \'' . $v . '\' WHERE cms_config_key = \'' . $k . '\';');
							} // foreach
						self::addMsg("Installed plugin: " . $pl_class,'success');
						} // if
					else {
						self::addMsg('Failed to install plugin: ' . $pl_class);
						return false;
						} // else
					} // foreach
				} // if
			} // foreach
		$enabled_plugins = implode(':',$enabled_plugins);
		if($pl_chgd) {
			$pl_sql = 'UPDATE cms_configs SET cms_config_value = \'' . $enabled_plugins . '\' WHERE cms_config_key = \'' . CMS_C_ENABLED_PLUGINS . '\';';
			if(!$pl_result = self::$cDBcms->query($pl_sql)) {
				self::addMsg('Failed to update enabled plugins for ' . $name . '.');
				return false;
				} // if
			// Ccms::do_plugin_installs($enabled_plugins);
			} // if
		// Ccms::do_plugin_installs($enabled_plugins);

		// now add / update nav bar links
		$grid_all = unserialize(CMS_C_NAVBAR_LINKS,array());
		$chgd = false;
		foreach($seld_nav_bar_links as $name => &$v) {
			// each body /app ony gets one mention on the nav bar
			if(empty($v)) continue;
			$id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_name = '" . $name . "'");
			if((int)$id <= 0) continue;
			$url = 'index.php?body=' . $id . '&name=' . urlencode($name);
			// search match
			$found = false;
			foreach($grid_all as &$g) {
				if($g[0] == $url) {
					$g[1] = $v['text'];
					$g[2] = $v['title'];
					$found = true;
					$chgd = true;
					break;
					} // if
				} // foreach
			if(!$found) {
				$grid_all[] = array(
					0 => $url,
					1 => $v['text'],
					2 => $v['title'],
					);
				$chgd = true;
				} // if
			} // foreach
		if($chgd) {
			$cms_c_navbar_links = serialize($grid_all);
			self::$cDBcms->query('UPDATE cms_configs SET cms_config_value = \'' . $cms_c_navbar_links . '\' WHERE cms_config_key = \'CMS_C_NAVBAR_LINKS\';');
			} // if

		if((self::get_or_post_checkbox('ini')) &&
			(isset($this->package['ini'])) &&
			(!self::put_app_ini($this->package['ini'],$body_conf['cms_body_dir']))) {
	 		self::addMsg('Failed to install INI settings for application package "' . $this->package['name'] . '".');
			return false;
			} // if

 		self::get_error_return_text('Installed application package "' . $this->package['name'] . '".','success');
		return true;
		} // install_application()

	protected function get_unzip_package_tree() {
		$cZIP = new ZipArchive();
		if($cZIP->open($this->package_file) !== true) {	// open in read mode
			self::get_error_return_text('Cannot open "' . $package_file . '".');
			return false;
			} // if
		$this->package_file_tree = array();
		$j = 0;
		for ($i = 0; $i < $cZIP->numFiles; $i++) {
			$name = $cZIP->getNameIndex($i);	// get name
			if($name == self::PKG_INFO_JSON) {
				$json = $cZIP->getFromIndex($i);
				$this->package = json_decode($json, true);
				continue;
				} // if
			$this->package_file_tree[$j++] = $name;	// tree it;
			} // for

		$cZIP->close();
		return true;
		} // get_unzip_package_tree()

	public function get_install_form($package_file) {
		$this->package_file = $package_file;
		if(!$this->get_unzip_package_tree()) {
			// hmm
			return false;
			} // if
		$ok = true;
		// present the options to admin
		$package = &$this->package;
		if($package['type'] != 'application') {
			self::get_error_return_text('Package is not an application (type is: ' . $package['type'] . ').');
			return false;
			} // if
		$pack_filename = basename($this->package_file);

		$package_name = $package['name'];
		$packager = $package['packager'];
		$packager_version = $package['packager_version'];
		$package_build_dt = $package['_JSON_ModTime'];
		$package_build_user = $package['_JSON_ModUser'];

		$bodies = &$package['bodies'];
		$files = &$this->package_file_tree;
		$nav_bar = &$package['nav_bar'];

		echo '<input type="hidden" name="pack_filename" value="' . rawurlencode($pack_filename) . '">';

		echo <<< EOTTOP

			<table class="page_config page_config_edit">
				<tr class="page_config">
					<th class="page_config">
						<h2>{$package_name}</h2>
					</th>
				</tr>
				<tr class="page_config">
					<td class="page_config">
						Package file: {$pack_filename}
						<br>
						Packager: {$packager}, Packager version: {$packager_version}.
						<br>
						Build date: {$package_build_dt}, Built by user name: {$package_build_user}.
					</td>
				</tr>
				<tr class="page_config"><td class="page_config">&nbsp;</td></tr>

EOTTOP;
		$row = 0;
		if((!empty($bodies)) && (count($bodies) > 0)) {
			echo '<tr class="page_config"><th class="page_config">Application Bodies.</th></tr>';
			foreach($bodies as $name => &$body) {
				$update = self::$cDBcms->is_data_in_table('cms_bodies', 'cms_body_name',  $body['cms_body_name']);
				echo '				<tr class="' . (($row++ & 1) ? 'page_config_odd':'page_config_even') . '"><td class="page_config">';
				echo '<label title="Description: ' . Ccms::get_body_description(0,$body['cms_body_name'],$body['cms_body_description'],false) . '">';
				echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $body['cms_body_name'] . '&nbsp;';
				echo '<input type="checkbox" name="bodies[' . urlencode($body['cms_body_name']) . ']" CHECKED>';
				echo '</label>';
				if((isset($nav_bar[($body['cms_body_name'])])) && (!empty($nav_bar[($body['cms_body_name'])]))) {
					echo '<br>';
					echo '<label>';
					echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $body['cms_body_name'] . ' nav bar link' . '&nbsp;';
					echo '<input type="checkbox" name="nav_bar[' . urlencode($body['cms_body_name']) . ']" CHECKED>';
					echo '</label>';
					if(!empty($package['ini'])) {
						echo '<br>';
						echo '<label>';
						echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $body['cms_body_name'] . ' INI settings' . '&nbsp;';
						echo '<input type="checkbox" name="ini" CHECKED>';
						echo '</label>';
						} // if
					} // if
				echo '</td></tr>' .PHP_EOL;
				} // foreach
			echo '<tr class="page_config"><td class="page_config">&nbsp;</td></tr>';
			} // if
		else {
			echo '<tr class="page_config"><td class="page_config">Package has no bodies.</td></tr>';
			} // else

		if((!empty($files)) && (count($files) > 0)) {
			echo '<tr class="page_config"><th class="page_config">Application Files.</th></tr>';
			foreach($files as $fa) {
				if($update = file_exists(DOCROOT_FS_BASE_DIR . $fa)) {
					if(is_dir(DOCROOT_FS_BASE_DIR . $fa)) continue;
					} // if
				echo '				<tr class="' . (($row++ & 1) ? 'page_config_odd':'page_config_even') . '"><td class="page_config">';
				echo '<label>';
				if(is_dir(DOCROOT_FS_BASE_DIR . $fa)) {
						echo 'Directory: ' . $fa . ' already installed.';
						} // if
				else {
					echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $fa . '&nbsp;';
					echo '<input type="checkbox" name="files[' . urlencode($fa) . ']" CHECKED>';
					} // else
				echo '</label>';
				echo '</td></tr>' .PHP_EOL;
				} // foreach
			echo '<tr class="page_config"><td class="page_config">&nbsp;</td></tr>';
			} // if
		else {
			echo '<tr class="page_config"><td class="page_config">No common application files.</td></tr>';
			} // else

		echo '<tr class="page_config"><td class="page_config"><label>Allow change: <input type="checkbox" name="allow_changes" title="Allow the application to be changed."></label></td></tr>';

		echo <<< EOTBOT

				<tr class="page_config">
					<td class="page_config">
						<br>
						<label><button type="submit" name="install_package" value="package" title="Install package.">Install</button>
						&nbsp;
						<label><button type="submit" name="cancel" value="cancel" title="Return to page / apps config." formnovalidate>Cancel</button>
					</td>
				</tr>
			</table>

EOTBOT;

		return $ok;
		} // get_install_form()

	public static function uninstall_application($cms_body_id,$body_file_only) {
		$sql_query = "SELECT * FROM  cms_bodies WHERE  cms_body_id = '" . (int)$cms_body_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($body = Ccms::$cDBcms->fetch_array($result))) {
			foreach($body as $k => &$v) $$k = $v;
			if((!$body_file_only) &&
				(!empty($cms_body_dir)) &&
				(is_dir(APPS_FS_DIR . $cms_body_dir))) {
				$configs = self::get_plugin_configs(APPS_FS_DIR . $cms_body_dir);
				if(!empty($configs)) { // remove plugin configurations
					foreach($configs as $plc) {
						foreach($plc as $k => $v) {
							if($k == 'info') {
								// @TODO remove from enabled plugins
								continue;	// for the moment
								} // if
							$sql_query = "DELETE FROM  cms_configs WHERE  cms_config_key = '" . $k . "'";
							Ccms::$cDBcms->query($sql_query);
							} // if
						} // foreach
					} // if
				self::trash_path(APPS_FS_DIR . $cms_body_dir);
				} // if
			if((!empty($cms_body_file)) &&
				((is_dir(PAGE_BODIES_FS_DIR . $cms_body_file)) || (file_exists(PAGE_BODIES_FS_DIR . $cms_body_file)))) {
				self::trash_path(PAGE_BODIES_FS_DIR . $cms_body_file);
				} // if
			// delete from cms_bodies table
			$sql_query = "DELETE FROM  cms_bodies WHERE  cms_body_id = " . (int)$cms_body_id . "";
			return Ccms::$cDBcms->query($sql_query);
			} // if
		return false;
		} // uninstall_application()

} // Ccms_app_install
