<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_base_sm.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of cms_base_sm state machine base class
 * Used to hold variable from Ccmc_sm (state machine) class
 *
 * @author robert0609
 */

require_once 'cms_base_file.php';	// speed up for proxy (no autoloader needed)

class Ccms_base_sm extends Ccms_base_file {

	protected static $client_ip = false;
	protected static $session_cookie_ok = false;
	protected static $have_session = false;
	protected static $session_id = false;
	protected static $visitor_cnt = false;
	protected static $client_headers = false;

	public static $tablet_flg = false;
	public static $tiny_flg = false;
	public static $tooltips_flg = true;
	public static $block_html = false;

	public static $moz_4_flg = false;
	public static $fox_flg = false;
	public static $chrome_flg = false;
	public static $safari_flg = false;
	public static $edge_flg = false;

	public static $browser_html5 = true;

	public static $browsercap_result = null;

	protected static $access_logged = false;	// only do once
	protected static $browsercap_done = false;	// only do once

	public static $action = false;
	public static $cms_action = false;

	protected static $head_output_flg = false;
	protected static $tools_on_navbar = false;

	protected static $tools = false;
	protected static $tools_cnt = false;
	public static $tool_id = false;
	public static $tool_name = false;
	public static $tool_version = false;

	public static $link_id = false;
	public static $link_name = false;
	public static $link_version = false;

	protected static $navbar_grid = false;
	protected static $navbar_cnt = false;

	public static $page_info = false;
	protected static $bodies = false;
	protected static $bodies_cnt = false;
	public static $body_id = false;
	public static $body_name = false;
	public static $body_version = false;
	public static $body_full_view = false;
	public static $body_default_msgs = true;
	public static $body_defines = false;

	public static $plugin = false;
	public static $ajax = false;
	public static $app = false;

	// see tech manual
	public static $docroot = false;
	public static $app_dir = false;
	public static $app_name = 'base';
	public static $app_key = false;
	public static $app_type = false;
	public static $httpd_version = false;	// from apache_get_version(); e.g.Apache/1.3.29 (Unix) PHP/4.3.4


	protected static $session_timeout = false;
	protected static $session_no_write = false;	// used to stop foreign session decodes being re/saved

	public static $geo_location_latitude = false;	// decimal degrees
	public static $geo_location_longitude = false;	// decimal degrees
	public static $geo_location_accuracy = false;	// metres
	public static $geo_location_loc_time = false;	// seconds since epoch

	protected static $page_start_time = 0;
	protected static $page_end_time = 0;

	protected static $refd_false = false;	// DO NOT CHANGE, used as reference return &false

	protected static $header_admin_sent = false;
	protected static $header_tools_sent = false;
	protected static $header_menu_sent = false;

	public static $has_ssl_available = false;
	public static $ssl_required = false;
	public static $ssl_in_use = false;

	protected static $left_column = null;	// time saver
	protected static $right_column = null;	// time saver
	protected static $menu_in_header = null;	// time saver

	protected static $password_resource_done = false;	// stop multiple generates.

//	protected static $prevErrorHandler = false;

	function __construct() {
		parent::__construct();
		if((!self::$client_headers) && (!self::is_cli()) &&
			($client_headers = @apache_request_headers())) {
			self::$client_headers = array();
			foreach($client_headers as $k => &$v) {
				$t = explode(';',$v);
				self::$client_headers[$k] = array(
					'type' => trim($t[0]),
					'params' => (empty($t[1]) ? null:trim($t[1])),
					);
				} // foreach
			} // if
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function is_tiny_device() { return self::$tiny_flg; }

	public static function is_tablet_device() { return self::$tablet_flg; }

	public static function is_computer_device() { return (!self::$tiny_flg && !self::$tablet_flg); }

	public static function have_session() {
		return self::$have_session;
		} // have_session()

	public static function session_cookie_ok() {
		return self::$session_cookie_ok;
		} // session_cookie_ok()

	public static function get_session_timeout() {
		return self::$session_timeout;
		} // get_session_timeout()

	public static function lookup_body($app_name, $dis_assoc = false) {
		$body = array_filter(self::$body_defines,
			function($a) use ($app_name) {
				// find this app
				if($a['app_name'] == $app_name) return true;
				return false;
				}
			);
		if(empty($body)) return false;
		return $body;
		} // lookup_body()

	public static function lookup_body_url($app_name_or_body) {
		if(!is_array($app_name_or_body))
			$body = self::lookup_body($app_name_or_body);
		else {
			if(isset($app_name_or_body['cms_body_id'])) {
				$url = 'index.php?body=' . (int)$app_name_or_body['cms_body_id'];
				return $url;
				} // if
			$body = $app_name_or_body;
			} // else

		$url = Ccms_sm::get_body_uri($body);
		return $url;
		} // lookup_body_url()

	public static function lookup_body_dir($app_name_or_body) {
		if(!is_array($app_name_or_body))
			$body = self::lookup_body($app_name_or_body);
		else {
			if(isset($app_name_or_body['app_dir'])) {
				$dir = $app_name_or_body['app_dir'];
				return $dir;
				} // if
			else if(isset($app_name_or_body['cms_body_dir'])) {
				$dir = $app_name_or_body['cms_body_dir'];
				return $dir;
				} // else if
			$body = $app_name_or_body;
			} // else
		$dir = Ccms_sm::get_body_dir($body);
		return $dir;
		} // lookup_body_dir()

} // Ccms_base
