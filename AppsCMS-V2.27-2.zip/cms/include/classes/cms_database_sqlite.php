<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_database_sqlite.php 2085 2021-07-06 16:24:36Z robert0609 $
 */

/**
 * Description of database
 *
 * @author robert0609
 */

// echo Ccms_database_sqlite::sqlite_libversion();

class Ccms_database_sqlite extends Ccms_database_common {

	private $m_hSQL = null;			// the sqlite database resource handle

	const DB_SIG_PRE = 'signatSQL_';


	function __construct($database_file,$chk_table = false,$log = '') {
		parent::__construct($log);
		// set up
		$this->connect($database_file,$chk_table);
	} // __construct()

	public function __destruct() {
		// clean before I go home
		$this->close();
		parent::__destruct();
	} // __destruct()

	public function get_DB_signat() {
		if(!self::is_debug())
			return self::DB_SIG_PRE . md5($this->m_sDatabase);
		return self::DB_SIG_PRE . preg_replace('/[ .]+/i','_', ($this->m_sDatabase));
		} // get_DB_signat()

	public function is_ok() {
		if(!$this->m_hSQL) return false;
		if(!$this->m_bOpen) return false;
		return true;
		} // is_ok()

	public function is_table_present($table) {
		if(!$this->is_ok()) return false;
		if($mr_result = $this->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%';")) {
			while($mr = $this->fetch_array($mr_result,false)) {
				if($mr['name'] == $table) return true;
				} // while
			} // if
		return false;
		} // is_table_present()

	public function is_table_column_present($table,$column) {
		if(!$this->is_ok()) return false;
		if($this->is_table_present($table)) {
			$cols = $this->get_columns_list($table);
			if(in_array($column,$cols)) return true;
			} // if
		return false;
		} // is_table_column_present()

	public function get_columns_list($table, $default_values = false, $inc_type = false) {	// return column names array
		if(!$this->is_ok()) return false;
		if($mr_result = $this->query('SELECT * FROM sqlite_master;')) {
			while($mr = $this->fetch_array($mr_result,false)) {
				if(($mr['type'] == 'table') &&
					($mr['tbl_name'] == $table)) {
					$list = array();
					$a = preg_split('/' . $table . ' ?\(/', $mr['sql']);
					$b = preg_split('/\)$/', (isset($a[1]) ? $a[1]:$a[0]));
					$cols = explode(',',$b[0]);
					foreach($cols as $col) {
						if(preg_match('/(create|select|drop)\s/i',$col)) continue;
						// bad $col = trim(strtolower($col));
						$col = trim($col);
						$c = preg_split('/\s+/s',$col);
						// self::array_trim($c);
						// self::array_trim calls array_walk_recursive, which is very expensive
						// and unnecessary since we know $c is a flat array.
						// Using preg_split on all whitespace removes any need to trim at all;
						// so I've removed the array_trim call and all calls to trim() on elements
						// of $c.
						$k = trim($c[0]," \'\"\t\n\r\0\x0B");
						if(!$default_values) $list[] = $k;	// makes a column name list
						else {	// extract default values
							$j = 1;
							$t = $c[$j];
							$j++;
							if((isset($c[$j])) && ($c[$j] == 'integer')) {
								$t .= ' ' . $c[$j];
								$j++;
								} // if
							$v = '';
							if((isset($c[$j])) &&
								($c[$j] == 'default') &&
								(isset($c[($j + 1)]))) {
								$j++;
								$d = '';
								for($i = $j, $n = count($c); $i < $n; $i++) {
									if(!empty($d)) $d .= ' ';
									$d .= $c[$i];
									} // for
								if(!preg_match('/not null/i', $d)) {
									switch($t) {
									case 'int':
									case 'bigint':
									case 'short integer':
									case 'unsigned integer':
									case 'short':
									case 'unsigned':
									case 'integer':
									case 'boolean':
										$v = (int)$d;
										break;
									case 'float':
										$v = (float)$d;
										break;
									case 'double':
										$v = (double)$d;
										break;
									default:
										if(preg_match('/varchar|character|text/', $t)) {
											$v = preg_replace('/^[\'\"](.*)[\'\"]$/', '$1', $d);
											} // if
										else if(preg_match('/numeric/', $t)) {
											$v = (double)$d;
											} // if
										else $v = '';
										break;
										} // switch
									} // if
								} // if
							if(!$inc_type) $list[$c[0]] = $v;	// a list of default values
							else {
								$list[$c[0]] = trim(str_replace($c[0], '', $col));
								} // else
							} // else
						} // foreach
					return $list;
					} // if
				} // while
			} // if
		return false;
		} // get_columns_list()

	public function get_columns_type($table) {	// returns column names with type array
		if(!$this->is_ok()) return false;
		$types = sqlite_fetch_column_types($table,$this->m_hSQL);	// @TODO implement

		if($mr_result = $this->query('SELECT * FROM sqlite_master;')) {
			while($mr = $this->fetch_array($mr_result,false)) {
				if(($mr['type'] == 'table') &&
					($mr['tbl_name'] == $table)) {;
					$types = array();
					$a = preg_split('/' . $table . ' ?\(/', $mr['sql']);
					$b = preg_split('/\)$/', $a[1]);
					$cols = explode(',',$b[0]);
					foreach($cols as $col) {
						$c = explode(' ',trim($col));
						$k = $c[0];
						$v = '';
						for($i = 1, $n = count($c); $i < $n; $i++) $v .= $c[$i] . ' ';
						$types[$k] = trim($v);
						} // foreach
					return $types;
					} // if
				} // while
			} // if
		return false;
		} // get_columns_type()

	public function get_row_count_in_table($table,$where = '') {
		if(!$this->is_ok()) return false;
		if(!$this->is_table_present($table)) return false;	// no table
		$test_sql = "select count(*) as total from " . $table .
			(!empty($where) ? ' where ' . $where:'');
		if($test_result = $this->query($test_sql)) {
			if($test = $this->fetch_array($test_result)) {
				return $this->output($test['total']);
				} // if
			} // if
		return false; // no data, error
		} // get_row_count_in_table()

	public function get_row_cnt($results = false) {
		if(!$results) $results = $this->results;
		if(empty($this->results)) return 0;
		return sqlite_num_rows($results);
		} // get_row_cnt()

	protected function checkAddDBcolumn($table, $column, $type) {
		if(!$this->is_ok()) return false;
		$bFound = false;
		if (($test_result = $this->query("PRAGMA table_info('" . $table . "');"))) {
			while ($test = $this->fetch_array($test_result,false)) {
				if ($test['name'] == $column) {
					$bFound = true;
					break;
					} // while
			} // while
			if ($bFound == false) {
				if(!$this->query('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . $type . ';')) { // add
					return false;
					} // if
				} // if
			$this->db_chgd = true;
			return true;
			} // if
		return false;
		} // checkAddDBcolumn()

	public function checkDropDBcolumn($table, $column) {	// override base
		if(!$this->is_ok()) return false;
//		// not working SQLite3::query(): Unable to prepare statement: 1, near "COLUMN": syntax error in ...
//		$bFound = false;
//		if ($this->is_table_column_present($table,$column)) {
//			if(!$this->query("ALTER TABLE " . $table . " RENAME COLUMN " . $column . " TO " . $column . "_deleted;")) {
//				return false;
//				} // if
//			} // if
		return true;
		} // checkDropDBcolumn()

	public function connect($database_file,$chk_table = false) {
		if($this->m_bOpen)	$this->close ();

		if(!class_exists("SQLite3")) {
			$this->onError("ERROR: PHP Sqlite not installed or not functioning");
			die("ERROR: PHP Sqlite not installed or not functioning");
			exit(100);
			} // if

		$this->m_sVersion = Ccms_database_sqlite::sqlite_libversion();

		if((!file_exists($database_file)) ||
			(!is_readable($database_file))) {
			self::addMsg('Creating new database "' . basename($database_file) . '".','warning');
			$this->m_bNew = true;
			} // if
		else if(!is_writable($database_file)) {
			self::chmod_chown($database_file);	// try to fix it
			if(!is_writable($database_file)) {
				return $this->onError('Unable to write to "' . basename($database_file) . '" (permissions).');
				} // if
			} // if

		// copy details for error checks
		$this->m_sDatabase = $database_file;

		$timeout_ms = 10000;
		$this->m_hSQL = new SQLite3($this->m_sDatabase);
		if (!$this->m_hSQL) {
			return $this->onError('Could not open "' . $this->m_sDatabase . '": ' . $error_msg);
			} // if
		if($this->m_bNew) {
			self::chmod_chown($this->m_sDatabase);
			} // if
		$this->m_bOpen = true;
		if($timeout_ms > 1000)
			$this->m_hSQL->busyTimeout($timeout_ms);
		if(self::is_rebuild()) {	// go faster
			// Source "https://www.sqlite.org/pragma.html#pragma_journal_mode"
			// use default (delete)	$this->m_hSQL->exec('PRAGMA journal_mode = off;');
			// NOTE: cannot use ROLLBACKs with journal off
			} // if
		else {	// wal is slow but has a write ahead log
			// WAL mode has better control over concurrency.
			// Source: https://www.sqlite.org/wal.html
			$this->m_hSQL->exec('PRAGMA journal_mode = wal;');
			} // else
		$this->m_hSQL->exec('PRAGMA encoding="UTF-8";');
		if(($chk_table) &&
			(!@$this->is_table_present($chk_table))) {	// could be encrypted by newer versions
			// have a DB file (??) but it is not ok.
			$this->close();
			self::trash_path($this->m_sDatabase);	// remove it
			self::addMsg("Failed to verify DB: " . basename($this->m_sDatabase) . '.');
			// open a neew file
			$this->m_hSQL = new SQLite3($this->m_sDatabase);
			if (!$this->m_hSQL) {
				return $this->onError('Could not open "' . $this->m_sDatabase . '": ' . $error_msg);
				} // if
			self::chmod_chown($this->m_sDatabase);
			if($timeout_ms > 1000)
				$this->m_hSQL->busyTimeout($timeout_ms);
			// WAL mode has better control over concurrency.
			// Source: https://www.sqlite.org/wal.html
			$this->m_hSQL->exec('PRAGMA journal_mode = wal;');
			$this->m_hSQL->exec('PRAGMA encoding="UTF-8";');
			$this->m_bOpen = true;
			$this->m_bNew = true;
			} // else if
		return $this->is_ok();
		} // connect()

	public function close() {
		if ($this->m_hSQL) {
			@$this->m_hSQL->close();
			$this->m_hSQL = null;
		} // if
		$this->m_bOpen = false;
		} // close()

	public function error($query) {
		if(!$this->is_ok()) return false;
		$errno = $this->m_hSQL->lastErrorCode();
		$error = $this->m_hSQL->lastErrorMsg();	//($errno);
		$this->logEvent('DB_ERROR ' . $this->m_sDatabase . ' - ' . $errno . ' - ' . $error . ' - ' . $query);
		return $this->onError($this->m_sDatabase . ' - ' . $errno . ' - ' . $error . CMS_NL . $query . CMS_NL . '[DB STOP]');
		} // error()

	public function perform($table, $data, $action = 'insert', $where_params = '',$unchecked_cols = null) {
		if(!$this->is_ok()) return false;
		$this->chk_table_row_sanity($table,$data);
		reset($data);
		if ($action == 'insert') {
			$query = 'INSERT INTO ' . $table . ' (';
			foreach ($data as $column => $value) {
				$query .= $column . ', ';
			} // while
			$query = substr($query, 0, -2) . ') VALUES (';
			reset($data);
			foreach ($data as $key => $value) {
				$value = preg_replace("/^'|'$/",'',$value);
				switch ((string) $value) {
					case 'now()':
						$query .= "DATETIME('NOW'), ";
						break;
					case 'null':
						$query .= 'null, ';
						break;
					default:
						if(is_bool($value)) $query .= ($value ? 1:0) . ', ';
						else if(is_numeric($value)) $query .= $value . ', ';
						else $query .= '\'' . $this->input($value) . '\', ';
						break;
				} // switch
			} // while
			$query = substr($query, 0, -2) . ')';
		} // if
		elseif ($action == 'update') {
			if(!empty($unchecked_cols) && is_array($unchecked_cols)) {

				} // if
			$query = 'UPDATE ' . $table . ' SET ';
			foreach ($data as $column => $value) {
				$value = preg_replace("/^'|'$/",'',$value);
				switch ((string) $value) {
					case 'now()':
						$query .= $column . "DATETIME('NOW'), ";
						break;
					case 'null':
						$query .= $column . ' = null, ';
						break;
					default:
						if(is_bool($value)) $query .= $column . ' = ' . ($value ? 1:0) . ', ';
						else if(is_numeric($value)) $query .= $column . ' = ' . $value . ', ';
						else $query .= $column . ' = \'' . $this->input($value) . '\', ';
						break;
				} // switch
			} // while
		$query = substr($query, 0, -2) . ' WHERE ' . $where_params;
		} // elseif
		else return false;
		$this->db_chgd = true;
		return $this->query($query);
	} // perform()

	public function query($query) {
		if(!$this->is_ok()) return false;
		if (self::$m_bSaveDBtransactions === true) {
			$this->logEvent('DB_QUERY: ' . $query);
			} // if

		$result = $this->m_hSQL->query($query);
		if ($result === false)
			return $this->error($query);

		if(self::$m_bSaveDBtransactions === true) $this->log_result ($result);

		return $result;
	} // query()

	public function fetch_array($query_result,$unescape_flg = true) {
		if(!$this->is_ok()) return false;
		if(!$query_result) return false;
		$result = $query_result->fetchArray(SQLITE3_ASSOC);
		if($unescape_flg) $result = $this->output($result);
		if(self::$m_bSaveDBtransactions === true) $this->log_result ($result);
		return $result;
	} // fetch_array()

	public function num_rows($query_result) {
		if(!$this->is_ok()) return false;
		if(!$query_result) return false;
		$cnt = 0;
		while($query_result->fetchArray()) $cnt++;
		$query_result->reset();
		return $cnt;
	} // num_rows()

	public function query_unbuffered($query) {	// a compatibility func
		if(!$this->is_ok()) return false;
		if (self::$m_bSaveDBtransactions === true) {
			$this->logEvent('DB_QUERY ' . $query);;
			} // if

		$result = $this->m_hSQL->query($query);
		if ($result === false) return $this->error($query);

		if(self::$m_bSaveDBtransactions === true) $this->log_result ($result);

		return $result;
	} // query_unbuffered()

	public function fetch_array_unbuffered($query_result,$next = true) {
		if(!$this->is_ok()) return false;
		if(!$query_result) return false;
		$result = $query_result->fetchArray(SQLITE3_ASSOC);
		if(($next) && ($result)) { /* dummy */ }
		if(self::$m_bSaveDBtransactions === true) $this->log_result ($result);
		return $result;
	} // fetch_array_unbuffered()

	public function data_seek($query_result, $row_number) {
		if(!$this->is_ok()) return false;
		if(!$query_result) return false;
		$query_result->reset();
		$row = 0;
		while($row++ < $row_number) if(!$query_result->fetchArray()) return false;
		return true;
	} // data_seek()

	public function insert_id() {
		if(!$this->is_ok()) return false;
		return $this->m_hSQL->lastInsertRowID();
	} // insert_id()

	public function free_result($query_result) {
		if(!$this->is_ok()) return false;
		if(!$query_result) return false;
		return true;	// not available	SQLite_free_result($query_result);
	} // free_result()

//	public function fetch_fields($query_result) {
//		if(!$this->is_ok()) return false;
//		return SQLite_fetch_field($query_result);
//	} // fetch_fields()

	public function input($string) {
		if(!$this->is_ok()) return false;
//		if(is_array($string)) {
//			$str_a = array();
//			foreach($string as $k => $v) {
//				$str_a[$k] = $this->input($v);	// recurse thru array
//				} // foreach
//			return $str_a;
//			} // if
		if(function_exists('sqlite_escape_string')) {	// V5
			$string = sqlite_escape_string($string);
			return $string;
			} // if
		else if('SQLite3::escapeString') {
			$string = SQLite3::escapeString($string);
			return $string;
			} // else if
		$string = preg_replace('/[\']+/','\\\'',$string);
		$string = preg_replace('/[\"]+/','\\"',$string);
		return $string;
	} // input()

	public function output($string) {	// opposite of input
		if(!$this->is_ok()) return false;
//		if(!function_exists('sqlite_escape_string')) return $string;
//		if(is_array($string)) {
//			$str_a = array();
//			foreach($string as $k => $v) {
//				$str_a[$k] = $this->output($v);	// recurse thru array
//				} // foreach
//			return $str_a;
//			} // if
//		$string = str_replace("''","'",$string);
//		$string = str_replace('\"','"',$string);
		return $string;
	} // output()

	protected function update_row_data($table,$columns,$row,$updateable_columns,$key_column) {
		if(empty($updateable_columns)) return true;	// nothing can be changed
		$upd_cols = explode(',',$updateable_columns);
		if(count($upd_cols) < 1) return true;	// nothing to do

		$colnames = array_keys($columns);
		$key_idx = 0;	// assume it's the id col
		if(!empty($key_column)) {
			$key_idx = array_search($key_column, $colnames);
			if($key_idx === false) return false;
			} // if
		if(count($colnames) != count($row)) {
			self::addMsg('Columns and data do not match in table: ' . $table .
					', ' . $colname[0] . ' = ' . $row[0] . '.');
			} // if

		$idx = 0;
		$fields = array_combine($colnames,$row);
		$this->chk_table_row_sanity($table,$fields);
		// $vals = array_values($fields);
		// $cols = array_keys($fields);
		if((int)$this->get_row_count_in_table($table,$key_column . ' = ' . $row[$key_idx]) > 0) {
			$action = 'update';
			} // if
		else $action = 'insert';
		foreach($columns as $col => $type) {
			if($idx < 3) unset($fields[$col]);	// let autoincrement and datatime do its thing
			else { // normal data
				if(($action != 'insert') &&
					(!in_array($col, $upd_cols))) {
					unset($fields[$col]); // not updated
					} // if
				} // else
			$idx++;
			} // foreach

		if($action == 'update') {
			if(!$this->perform($table,$fields,$action,$key_column . ' = ' . $row[$key_idx])) return false;
			} // if
		else if($action == 'insert') {
			if(!$this->perform($table,$fields,$action)) return false;
			} // else
		$this->db_chgd = true;
		return true;
		} // update_row_data()

	protected function installTable($table,$params, $drop = false, $verbose = false) {
		if(!$this->is_ok()) return false;
		if((empty($table)) || (!is_array($params))) return false;

		// $params
		// 'drop' => 'false' or 'true'
		// 'columns' => array( 'col_name' => 'type/def' )
		// 'data' => array() of column data in columns order

		if($verbose) $this->out_import_stat_msg('Table: ' . $table . ' checks for ' . CMS_PROJECT_VERSION . '.' . PHP_EOL);
		$ok = true;
		$table_present = $this->is_table_present($table);
		if(($table_present) &&
			(isset($params['drop'])) &&
			(($params['drop'] == 'true') || ($params['drop'] === true) || ($drop))) {
			$this->query("DROP TABLE " . $table . ";");
			$table_present = false;
			} // if

		// $this->query("SET @saved_cs_client     = @@character_set_client;");	// save language
		// $this->query("SET character_set_client = utf8;");	// set language

		if((is_array($params['columns'])) && (count($params['columns']) > 0)) {
			$columns = $params['columns'];

			if(!$table_present) {
				$sql_query = 'CREATE TABLE IF NOT EXISTS ' . $table;
				$sql_query .= ' (';
				$cnt = 0;
				foreach ($columns as $name => $type) {
					if($cnt > 0) $sql_query .= ', ';
					$sql_query .= "" . $name . " " . $type;
					$cnt++;
					} // foreach
				$sql_query .= ');';
				if(!$this->query($sql_query)) {
					$ok = false;
					} // if
				} // if
			else {	// check all columns are there
				if(isset($params['delete_columns'])) {	// delete unused columns
					foreach($params['delete_columns'] as $dcol) {
						// SQLite has no easy way to delete columns
						} // foreach
					} // if

				foreach ($columns as $name => $type) {
					if(!$this->checkAddDBcolumn($table, $name, $type)) $ok = false;
					if($verbose) $this->out_import_stat_msg('Table: ' . $table . ', column: ' . $name . '.');
					} // foreach
				if($verbose) $this->out_import_stat_msg('Table: ' . $table . ', column: ' . $name . '.' . PHP_EOL);
				} // else

			if(($ok) && (isset($params['functions']))) {	// create triggers, filters and functions
				foreach($params['functions'] as $k => $v) {
					// check if function ($k) is already there first
					if($test_query = $this->query("SELECT * FROM sqlite_master WHERE tbl_name = '" . $table . "' AND TYPE = 'trigger';")) {
						$found = false;
						while($test = $this->fetch_array($test_query,false)) {
							if($test['name'] == $k) {
								$found = true;
								break;
								} // if
							} // while
						if($found) continue;
						} // if
					$sql_query = $v;
					if(!$this->query($sql_query)) {
						$ok = false;
						break;
						} // if
					} // foreach
				} // if

			if(($ok) && (isset($params['data'])) && (is_array($params['data'])) && (count($params['data']) > 0)) {
				$data = $params['data'];	// in the same order as the columns
				$row_cnt = 0;
				if(!$table_present) {	// empty table
					foreach($data as $row) {
						$sql_query = "INSERT INTO " . $table . " VALUES (" . implode(',',$row) . ");";
						if(!$this->query($sql_query)) $ok = false;
						if(($verbose) && ((++$row_cnt % 10) == 0))	// speed up
							$this->out_import_stat_msg('Table: ' . $table . ', row: ' . $row_cnt . '.');
						} // foreach
					} // if
				else {	// add / update columns
					$columns = $params['columns']; // assumes columns[0] is the id name and row[0] is the value
					$colnames = array_keys($columns);
					if((isset($params['updateable_columns'])) && (!empty($params['updateable_columns'])) &&
						((isset($params['key_column'])) && (!empty($params['key_column'])))) {
						foreach($data as $row) {
							if(!$this->update_row_data($table,$columns,$row,$params['updateable_columns'],$params['key_column'])) $ok = false;
							if(($verbose) && ((++$row_cnt % 10) == 0))	// speed up
								$this->out_import_stat_msg('Table: ' . $table . ', row: ' . $row_cnt . '.');
							} // foreach
						} // if
					else if((!isset($params['key_column'])) || (empty($params['key_column']))) {
						foreach($data as $row) {
							if(((int)$row[0] > 0) &&	// ??? what for
							(!$test_query = $this->query('SELECT * FROM ' . $table . ' WHERE ' . $colnames[0] . ' = ' . $row[0] . '')) ||
							($this->num_rows($test_query) < 1)) {
								$fields = array_combine($colnames,$row);
								$this->chk_table_row_sanity($table,$fields);
								$vals = array_values($fields);
								$cols = array_keys($fields);
								$sql_query = 'INSERT INTO ' . $table . ' (' . implode(',',$cols) . ') VALUES (' . implode(',',$vals) . ');';
								if(!$this->query($sql_query)) $ok = false;
								} // if
							if(($verbose) && ((++$row_cnt % 10) == 0))	// speed up
								$this->out_import_stat_msg('Table: ' . $table . ', row: ' . $row_cnt . '.');
							} // foreach
						} // if
					} // else
				if($verbose) $this->out_import_stat_msg('Table: ' . $table . ', row: ' . $row_cnt . '.' . PHP_EOL);
				} // if
			} // if
		else $ok = false;
		if($ok) $this->db_chgd = true;
		if($verbose) $this->out_import_stat_msg(PHP_EOL);
		return $ok;
		} // installTable()

	protected function install_db_tables($only_table, $install_scripts, $verbose = false, $drop = false) {
		if(!$this->is_ok()) return false;
		$ok = true;
		foreach($install_scripts as $table => $params) {
			if((strlen($only_table) > 0) &&
				($table != $only_table)) continue;

			if($verbose) self::addMsg(($drop ? 'Installing table ':'Checking table ') . ' ' . $table,'info');
			if(!$this->installTable($table,$params,$drop,$verbose)) {
				if($verbose) self::addMsg('Failed to ' . ($drop ? "install":"check") . ' ' . $table . ' in ' . $this->get_name(), 'error');
				$this->logEvent('Failed to ' . ($drop ? "install":"check") . ' ' . $table . ' in ' . $this->get_name());
				$ok = false;
				} // if
			} // foreach
		if($verbose) {
			if($ok) self::addMsg(($drop ? "Installed":"Checked") . " " . basename($this->get_name()) . " tables - success", 'success');
			else self::addMsg("Failed to " . ($drop ? "install":"check") . " " . basename($this->get_name()) . " tables - failed");
			} // if
		return $ok;
		} // install_db_tables()

	public function backupDatabase($backupFolder = false,$cms_msg_info = false) {
		// virtual override
		if(!$this->is_ok()) return false;
		if(!is_dir($backupFolder)) $backupFolder = VAR_FS_BACKUP_DIR;

		// save directly to file
		$filepath = $backupFolder . '/' . CMS_PROJECT_SHORTNAME . '-Backup-' . basename($this->m_sDatabase) . '-' . date('Ymd-His') . '.gz';
		$err = '';
		exec('sqlite3 ' . $this->m_sDatabase . ' .dump | gzip > ' . $filepath , $err);
		Ccms::chmod_chown($filepath);

//		// save to file
//		$filepath = $backupFolder . '/' . basename($this->m_sDatabase) . '-' . date('Ymd-His') . '.bak';
//		if($gzipFlg) {
//			$filepath .= '.gz';
//			if(($gz = gzopen($filepath,'w9') === false) ||
//				(gzwrite($gz, $output) <= 0)) {
//					if($gz) gzclose($gz);
//					self::addMsg('Failed to save "' . $filepath . '".');
//					return false;
//					} // if
//				gzclose($gz);
//			} // if
//		else {
//			if(!self::file_safe_write($filepath, $output) === false) {
//				self::addMsg('Failed to save "' . $filepath . '".');
//				return false;
//				} // if
//			} // else

		if($cms_msg_info) self::addMsg('Saved DB to "' . basename($filepath) . '".','success');
		return true;
	} // backupDatabase()

	public function restoreDatabase($backupfile) {	// needs to be preceeded with "Are you sure"
		// virtual override
		if(!$this->is_ok()) return false;
//		if((!is_readable($backupfile)) ||
//			($zd = gzopen($filename, "r") === false)) {
//			self::addMsg('Failed to open "' . $backupfile . '".');
//			return false;
//			} // if
//		$contents = gzread($zd, 100000);
//		gzclose($zd);

		$err = '';
		exec('zcat "' . $backupfile . '" | sqlite3 ' . $this->m_sDatabase,$err);

		return true;
		} // restoreDatabase()

	protected function export_db2json(&$install_scripts,$json_file) {	// exports data and remove orphans as it goes
		if(!$this->is_ok()) return false;
		$json = array();
		foreach($install_scripts as $table => &$v) {
			$sql = 'SELECT * FROM ' . $table . (!empty($v['asc']) ? ' ORDER BY ' . $v['asc']:'');
			if($res = $this->query($sql)) {
				while($data = $this->fetch_array($res,false)) {
					$jd = array();
					foreach($v['columns'] as $c => &$t) {
						if(isset($data[$c])) $jd[$c] = $data[$c];	// filter it (remove empty and orphaned)
						} // if
					$json[$table][] = $jd;
					} // while
				} // if
			} // foreach
		if(self::save_json($json_file, $json, false)) {
			self::addMsg('Saved reconstruct data for ' . CMS_PROJECT_SHORTNAME . ' DB.','success');
			return true;
			}
		self::addMsg('Failed to save data for ' . CMS_PROJECT_SHORTNAME . ' DB.');
		return false;
		} // export_db2json()

	protected function import_json2db(&$install_scripts,$json_file,$verbose = false) {	// imports data into cms.sqlite (probably some corruption by encryption between sqlite versions)
		if(!$this->is_ok()) return false;
		if((!file_exists($json_file)) ||
			(!is_readable($json_file)) ||
			(!$json = self::load_json($json_file))) {
			self::addMsg('No reconstruct data for ' . CMS_PROJECT_SHORTNAME . ' DB.','warn');
			return false;
			} // if
		if(self::is_cli()) self::addMsg ('Recontructing ' . CMS_PROJECT_SHORTNAME . ' DB.','info');
		else if($verbose) $this->out_import_stat_msg('Recontructing ' . CMS_PROJECT_SHORTNAME . ' DB.' . PHP_EOL);
		foreach($json as $table => &$data) {
			if(preg_match('/^[^a-z]+/',$table)) continue;	// sys value, not table
			if(empty($install_scripts[$table])) continue;	// no table
			if((self::is_cli()) || ($verbose)) self::addMsg ('Recontructing: ' . $table,'info');
			$this->query("DELETE FROM " . $table . ";");	// clean it
			for($i = 0; $n = count($data), $i < $n; $i++) {
				$row = &$data[$i];
				$this->chk_table_row_sanity($table,$row);
				$sql_query = "INSERT INTO " . $table . " (" .
					implode(',',array_keys($row)) .
					") VALUES (" .
					implode(',',array_map(function($v) {
						if(is_numeric($v)) return $v;
						return "'" . $v . "'";
						}, array_values($row))) .
					");";
				if(!$this->query($sql_query)) {
					self::addMsg('Failed to reconstruct ' . CMS_PROJECT_SHORTNAME . ' DB.');
					return false;
					} // if
				if(($verbose) && (($i % 10) == 0))	// speed up
					$this->out_import_stat_msg('Table: ' . $table . ', row: ' . $i . '.');
				} // for
			if($verbose) $this->out_import_stat_msg('Table: ' . $table . ', row: ' . $i . '.' . PHP_EOL);
			} // foreach
		self::addMsg('Reconstructed ' . CMS_PROJECT_SHORTNAME . ' DB.','success');
		if($verbose)$this->out_import_stat_msg('Reconstructed ' . CMS_PROJECT_SHORTNAME . ' DB.' . PHP_EOL);
		return true;
		} // import_json2db()

	public static function sqlite_libversion() {
		if(!class_exists('SQLite3',false)) return false;
		$n = rand(1,1000); // dont overwrite other users
		$tmp = VAR_FS_TEMP_DIR . $n . '__tmp__.sqlite';
		$h = new SQLite3($tmp);	// is part of php-sqlite3
		$v = $h->version();
		$h->close();
		if(file_exists($tmp)) @unlink($tmp);
		return $v['versionString'];
		} // sqlite_libversion()

} // Ccms_database_sqlite

