<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_ajax.php 2004 2021-02-28 08:53:00Z robert0609 $
 */

require_once 'include/cms_top.php';

if(!empty(Ccms::$ajax)) {	// works with the javascript Ccms_ajaxOps class
	Ccms::log_ajax_request();
	$text = false;
	$content_type = 'text/html';
	if(!empty(Ccms::$plugin)) {	// do plugins
		$class = 'C' . Ccms::$plugin . '_plugin';
		if(Ccms_autoloader::find_plugin($class)) {
			if((method_exists($class,'is_enabled')) &&
				(method_exists($class,'is_this_ajax_plugin')) &&
				(method_exists($class,'get_ajax_text')) &&
				($class::is_enabled(Ccms::$plugin)) &&
				($class::is_this_ajax_plugin(Ccms::$ajax))) {
				$text = $class::get_ajax_text(Ccms::$ajax);
				if (method_exists($class, 'ajax_content_type')) {
					$content_type = $class::ajax_content_type();
					}
//				$tidy = tidy_parse_string($text);
//				// $tidy->cleanRepair();
//				$text = preg_replace('/<html>(.*|\n)<body>(.*|\n)<\/body>(.*|\n)<\/html>/i','$2',tidy_get_output($tidy));
//				// $text = tidy_get_output($tidy);
				} // if
			else {
				$text = 'Ajax Plugin Error. Check ' . Ccms::$plugin . ' config.';
				} // else
			} // if
		else {
			$text = 'Ajax Error.';
			} // else
		if(!empty($text)) {
			Ccms::log_ajax_response($text);
			// output a response header
			if(preg_match('/^UTF/i',INI_CHAR_SET))
				header("Content-type: $content_type; charset=" . INI_CHAR_SET . '');
			header('Cache-Control: no-cache');
			header('Cache-Control: no-store' , false);     // false => this header
			echo $text;
			} // if
		} // if
	else if(!empty(Ccms::$app)) {	// do apps
		if(Ccms_autoloader::find_class(($class = 'C' . Ccms::$app . '_app'))) {	// uses autoloader to test
			$text = $class::get_ajax_text(Ccms::$ajax);
			if(is_bool($text)) {	// no point sending
				exit(1000);	// just an indicator
				} // if
			if (method_exists($class, 'ajax_content_type')) {
				$content_type = $class::ajax_content_type();
				}
			} // if
		else if(is_readable(($fphp = APPS_FS_DIR . Ccms::$app . '.php'))) {
			ob_start();
			include $fphp;
			$text = ob_get_clean();
			} // else if
		else $text = 'Apps ' . Ccms::$app . ' Error.';
		if(!empty($text)) {
			Ccms::log_ajax_response($text);
			// output a response header
			if(preg_match('/^UTF/i',INI_CHAR_SET))
				header("Content-type: $content_type; charset=" . INI_CHAR_SET . '');
			header('Cache-Control: no-cache');
			header('Cache-Control: no-store' , false);     // false => this header
			echo $text;
			} // if
		} // if
	else {
		switch(Ccms::$ajax) {
		case 'cms_edit_ws_image_upload':
			if((isset($_FILES['file']['name'])) &&
				(!empty($_FILES['file']['name']))) { // check image location
				$tmp_name = $_FILES['file']['tmp_name'];
				$filename = ETC_FS_IMAGES_DIR . $_FILES['file']['name'];
				if(move_uploaded_file($tmp_name, $filename)) {
					Ccms::chmod_chown($filename);
					Ccms::log_ajax_response($text);

					// output a response header
					if(preg_match('/^UTF/i',INI_CHAR_SET))
						header("Content-type: $content_type; charset=" . INI_CHAR_SET . '');
					header('Cache-Control: no-cache');
					header('Cache-Control: no-store' , false);     // false => this header
					$text = Ccms::get_ws_image_uri_selection();
					echo $text;
					} // if
				} // if
			break;
		case 'cms_edit_search':
			if(Ccms_auth::is_admin_user()) {
				Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_search.php");
				break;
				} // if
		case 'cms_debug':
			if(Ccms_auth::is_admin_user()) {
				Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_debug.php");
				break;
				} // if
		case 'cms_log_view':
			if(Ccms_auth::is_admin_user()) {
				Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_log_view.php");
				break;
				} // if
		case 'cms_browse_sessions':
			if(Ccms_auth::is_admin_user()) {
				Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_session_browser.php");
				break;
				} // if
		case 'cms_users_stats':
			if(Ccms_auth::is_admin_user()) {
				Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_users_stats.php");
				break;
				} // if
		case 'cms_get_filtered_links_page':
			if(Ccms::is_get_or_post('keywords')) { // get filtered output
				// output a response header
				if(preg_match('/^UTF/i',INI_CHAR_SET))
					header('Content-type: text/html; charset=' . INI_CHAR_SET . '');
				header('Cache-Control: no-cache');
				header('Cache-Control: no-store' , false);     // false => this header
//				if(INI_DEBUG_BOOL) {
//					$text = "AJAX DEBUG - " . Ccms::get_or_post('filter');
//					echo $text;
//					} // if
				include(CMS_FS_INCLUDES_DIR . "cms_filtered_links.php");
				} // if
			break;
		case 'lm_save_filtered_sections_state':
			if(Ccms::is_get_or_post('lm_section_states')) { // get lm section states
				$states = Ccms::get_or_post('lm_section_states');
				foreach($states as $id => $val) {
					$_SESSION['lm_section_states'][$id] = $val;
					} // foreach
				} // if
			break;
		case 'cms_livesearch':	// default callback for get_live_search_input()
			$name = Ccms::get_or_post('name');
			if(!name) {
				Ccms::log_msg('Failed to get name for "cms_livesearch".','warn);');
				echo 'Failed "cms_livesearch" name.';
				break;
				} // if
			if(isset($_SESSION['callbacks']['cms_livesearch'][$name]['func'])) {
				$func = $_SESSION['callbacks']['cms_livesearch'][$name]['func'];
				$text = @call_user_func($func,$name);
				if(is_null($text) || empty($text)) {
					Ccms::log_msg('Failed "cms_livesearch.' . $name . '" to get results..','warn);');
					echo 'Failed "cms_livesearch.' . $name . '" to get results.';
					echo '';
					} // if
				else echo $text;
				}
			else {
				Ccms::log_msg('Failed "cms_livesearch.' . $name . '": callback not found.','warn);');
				echo 'Failed "cms_livesearch" name.';
				} // else
			break;
		case 'cms_cookie_banner_closed':	// default callback for cms_cookie_banner_closed()
			Ccms_auth::cms_cookie_banner_closed();
			Ccms::log_msg('Cookie banner closed.','info');
			echo 'Ok';
			break;
		case 'cms_client_metadata':
			$meta = Ccms::get_or_post('clientMeta');
			$_SESSION['clientMetadata'] = $meta;
//			if(Ccms::is_debug()) {
//				Ccms::save_json(VAR_FS_TEMP_DIR . 'client_meta.json',$meta);
//				} // if
			break;
		default:
			// else what, nothing
			break;
			} // switch
		} // else
	} // if

require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';
