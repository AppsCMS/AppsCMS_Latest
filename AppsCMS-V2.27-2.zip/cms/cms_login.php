<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_login.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

	require_once 'include/cms_top.php';

	Ccms_auth::logout_user();
	session_destroy();

	if(INI_ALWAYS_LOGIN_BOOL) {
		if(!Ccms_auth::is_login_allowed()) {
			echo "Login not allowed.";
			Ccms::$cDBcms->logEvent('WARNING: Possible conflict with login and login not allowed.');
			exit(1);
			} // if
		} // if

	if(!Ccms_auth::is_login_allowed()) {
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if

	$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?cms_action=cms_login';
	if((Ccms::is_get_or_post('user')) && (!empty(Ccms::get_or_post('user')))) $url .= '&user=' . Ccms::get_or_post('user');
	header('Location: ' . $url);
	exit (0);
