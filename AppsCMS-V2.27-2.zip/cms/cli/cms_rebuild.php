<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_rebuild.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('REBUILD_MODE',	true);	// tell configure i am rebuilding (same as rebuild from web)
if(isset($argv[1]) && ($argv[1] == '--use-json'))
	define('USE_JSON_REBUILD', true);

// $docroot = preg_replace('/\/(apps|cms)\/.*$/','',__DIR__);	// test
require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

// CLI test
// Ccms::addMsg('Bad');	// test
// Ccms::addMsg('Good','warn');	// test
// Ccms::addMsg('Good','success');	// test
// exit(0);	// test

echo 'Starting -> rebuilding setup for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.' . PHP_EOL;
Ccms::$cDBcms->logEvent('Starting -> rebuilding setup for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.');

Ccms_sm::get_bodies_defines();
if(!Ccms::$cDBcms->checkDBversion(true)) {
	Ccms::addMsg('Failed configuration database checks.');
	exit(1);
	} // if

if(!Ccms_DB_install::rebuild_from_settings()) {
	echo "Setting errors found (2). Exiting.";
	} // if
else if(!Ccms::chk_bld_crit_dirs()) { // if there is critical errors should never get here, Ccms::__construct() should exit
	echo "Critical errors found (2). Exiting.";
	} // if
else  if((Ccms::do_cms_warnings(true)) &&
	(Ccms::do_cms_cli_warnings(true))) {
	Ccms::clean_orphaned_settings(true);		//	exit(1);	// test
	} // if
else {
	Ccms::addMsg('Failed installation checks.');
	} // else

Ccms_content_cache::reset_caches(true);
Ccms_gotcha_plugin::reset_cache(true);
Ccms_proxy::clear_signats(true);
Ccms_minify_plugin::reset_cache(true);

echo 'Finished -> rebuilding setup for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.' . PHP_EOL;
Ccms::$cDBcms->logEvent('Finished -> rebuilding setup for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.');

exit(0);

// eof
