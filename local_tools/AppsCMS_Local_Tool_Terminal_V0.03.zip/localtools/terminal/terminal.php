<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * A simple shell terminal tool
 * Copyright (C) 2020 Robert Fulton
 * SVN Build: $Id$
 */

define('TERMINAL_VERSION', 'V0.03');

class terminal {

	private $allowed_commands = array(
		"ls", "cp", "mv", "cal", "mkdir", "cd",
		"touch", "man", "ps", "mysql", "df",
		"cat", "grep", "sed", "free",
		"sqlite3", "pwd", "file", "dir", "year",
		"time", "date", "bc", "clear", "tree");
	// no work: , "cd"

	private $max_txt_lines = 2000;
	private $cmd_prefix = '';	// /bin/bash -c ';

	protected $screen_text = '';
	protected $ret_status = 0;
	protected $output = '';
	protected $cmd = '';
	protected $doc_root = '';

	public $trm_recent_cmds = array('ls', 'free', 'df', 'ls -l',);	// preload sum history !!
	public $trm_recent_cmd_idx = false;
	public $error = '';
	public $cwd = '';
	public $textArea = false;	// the output
	public $textArea_truncated = false;

	const COOKIE_NAME = 'term_prefs';

	function __construct() {
		$this->trm_recent_cmd_idx = count($this->trm_recent_cmds);
		$this->cwd = $this->doc_root = $this->get_doc_root();
		$this->chk_cwd();	// am I allowed
		$this->cmdString();
		$this->runShell();
		$this->trm_recent_cmd_idx = count($this->trm_recent_cmds);
		$this->composeSrnText();
		} // __construct()

	function __destruct() {

		} // __destruct()

	public function get_doc_root() {
		// pick off the server alias not the virtual server base doc root folder
		$script = $_SERVER['SCRIPT_NAME'];
		$filename = $_SERVER['SCRIPT_FILENAME'];
		// remove the $script part from $filename to get root folder taking into account aliases
		// step backwards thru the both strings looking a match,
		// when not matched to RHS at that point is the web URI and
		// the LHS is the directory root
		$script_dirs = explode('/',dirname($script));
		$filename_dirs = explode('/',dirname($filename));
		$script_end = count($script_dirs) - 1;
		$filename_end = count($filename_dirs) - 1;
		$found = true;
		while($script_dirs[$script_end] == $filename_dirs[$filename_end]) {
			unset($script_dirs[$script_end]);
			unset($filename_dirs[$filename_end]);
			$script_end--;
			$filename_end--;
			if(($script_end < 0) || ($filename_end < 0)) {
				$found = false;
				break;
				} // if
			} // while
		if($found) {
			$f_root = implode('/',$filename_dirs);
			return $f_root;
			} // if

		// try the old way
		// slow runtime but quick to code
		$script_len = strlen($script);
		$filename_len = strlen($filename);
		$end = 0;
		do {
			$end --;
			} while (substr($script,$end) == substr($filename,$end));
		$f_root = substr($filename,0,($filename_len + $end + 1));
		return $f_root;
		} // get_doc_root()

	protected function get_or_post($name,$def = null) {	// quell not there errors
		$val = $def;
		if(!empty($_POST[$name]))
			$val = $_POST[$name];
		else if(!empty($_GET[$name]))
			$val = $_GET[$name];
		return $val;
		} // get_or_post()

	protected function chk_cwd() {
		$this->cwd = rawurldecode($this->get_or_post('cwd',''));
		if((empty($this->cwd)) || ($this->cwd == '.') ||	// bad
			(strpos($this->cwd,$this->doc_root) === false)) {	// out side the park
			$this->cwd = $this->doc_root;
			$this->error .= "Returned to in scope directory.";
			} // else if
		} // chk_cwd()

	protected function cmdString() {
		$this->screen_text = rtrim($this->get_or_post('term_screen',''));
		$cmds_list = explode(']#',$this->screen_text);
		if(!is_array($cmds_list)) { $this->cmd = ''; return; }
		$cln_cmd = trim($cmds_list[(count($cmds_list) - 1)]);
		$descompose = preg_split('/[ ]+/', $cln_cmd);
		if (empty($descompose))
			return;
		switch($descompose[0]) {	// local aliases
		case 'cd':
			if(!empty($descompose[1])) {
				if($descompose[1] == '..') {
					// so !!
					} // if
				}// if
			break;
		case 'll':
			array_unshift($descompose,'ls','-l');	// prepend cmd and option
			unset($descompose[2]);	// remove old ll
			$cln_cmd = implode(' ',$descompose);	// new cmd
			break;
		case 'lla':
			array_unshift($descompose,'ls','-al');	// prepend cmd and option
			unset($descompose[2]);	// remove oold ll
			$cln_cmd = implode(' ',$descompose);	// new cmd
			break;
		case 'la':
			array_unshift($descompose,'ls','-a');	// prepend cmd and option
			unset($descompose[2]);	// remove oold ll
			$cln_cmd = implode(' ',$descompose);	// new cmd
			break;
		case 'alias':
			$this->output = <<< EOTALI
alias ll ='ls -l'
alias la ='ls -a'
alias lla='ls -la'
EOTALI;
			return;
		default:
			break;
			} // switch
		if (in_array($descompose[0], $this->allowed_commands)) {
			$this->cmd = escapeshellcmd($cln_cmd);
			// do history
			$idx = $this->get_or_post('cur_hist');
//		if($idx) {
//			$this->trm_recent_cmd_idx = $idx;
//			$this->trm_recent_cmds[$idx] = $this->cmd;
//			} // if
//		else
			$this->trm_recent_cmds[] = $this->cmd;
			} // if
		else if(!empty($cln_cmd)) {
			sort($this->allowed_commands);
			$this->error .= '<p>Command: &quot;<span style="color: red;">' . $cln_cmd . '</span>&quot; not allowed.';
			$this->screen_text = preg_replace('/^(.*)\]#[ ]*.*$/s','$1]# ',$this->screen_text);
			} // else
		} // cmdString()

	private function chdir($dir) {
		if(!@chdir($dir)) {
			$this->error .= "Failed to chdir {$dir}";
			return false;
			} // if
		return true;
		} // chdir()

	protected function shell_exec($cmd, &$stdout=null, &$stderr=null) {
		$locd_cmd = 'cd "' . $this->cwd . '"; ' . $cmd . '; echo -e "\n$(pwd)\n"';
		$proc = proc_open($locd_cmd,[
			1 => ['pipe','w'],
			2 => ['pipe','w'],
		],$pipes);
		$stdout = stream_get_contents($pipes[1]);
		fclose($pipes[1]);
		$stderr = stream_get_contents($pipes[2]);
		fclose($pipes[2]);
		$res = proc_close($proc);
		$cwd = preg_replace('/^.*[\n](.+)[\n]+$/s','$1',$stdout);
		$this->cwd = preg_replace('/[\n]*$/s','',$cwd);
		$stdout = preg_replace('/[\n].*[\n]+$/','',$stdout);
		return $res;
		} // shell_exec()

	protected function runShell() {
		if (empty($this->cmd)) return;
		switch($this->cmd) {
		case 'clear':
			$this->screen_text = '';
			$this->cwd = '.';
			return;
		case 'cd':	// no options
			$this->cwd = $this->doc_root;
			$this->output = PHP_EOL;
			return;
		case 'alias':
			$this->output = PHP_EOL;
			return;
		default:
			break;
			} // switch
		if(empty($this->cwd)) $this->cwd = $this->doc_root;
//		$cd_save = getcwd();
//		$this->chdir($this->cwd);
		$cmd2run = trim($this->cmd_prefix . ' ' . $this->cmd);	// changes the shell

//		// very disobedient bunny
//		$env = getenv();	// checker
//		$tmp = array(); exec('export SHELL=/bin/bash; echo $SHELL',$tmp);	// get "/sbin/nologin" (apache shell)

//		$output = array();
//		exec($cmd2run . ' 2>&1', $output, $this->ret_status);
//		$this->output = implode(PHP_EOL,$output);

		// need stderr too
		$stdout = '';
		$stderr = '';
		$this->ret_status = $this->shell_exec($cmd2run,$stdout,$stderr);
		$this->chk_cwd();	// keep it in the park
		$this->output = $stdout;
		if(!empty($stderr)) $this->output .= PHP_EOL . $stderr;

//		if($this->ret_status == 0) // no error
//			$this->cwd = getcwd();
//		if(!empty($cd_save)) $this->chdir($cd_save);
		} // runShell()

	protected function composeSrnText() {
		$prompt = '[' . basename($this->cwd) . ']#';
		$this->textArea = $this->screen_text;
		// if(!empty($this->error)) $this->textArea .= ' (cmd error)' . PHP_EOL . $prompt;
		// $this->textArea .= $prompt;
		if((!empty($this->output)) || (!empty($this->cmd))) {
			// $this->textArea .= $this->cmd;
			if(!empty($this->output)) $this->textArea .= PHP_EOL . $this->output;
			if(($this->ret_status != 0)  && (empty($this->output))) // cmd has taken care of it
				$this->textArea .= ' (error code: ' . $this->ret_status . ')' . PHP_EOL . $prompt;
			$this->textArea .= PHP_EOL . $prompt;
			} // if
		if(empty($this->textArea)) $this->textArea = $prompt;
		else {
			$line_cnt = substr_count($this->textArea,"\n");
			if($line_cnt > $this->max_txt_lines) {	// remove leaving line
				$lines = explode("\n",$this->textArea);
				$start = $line_cnt - $this->max_txt_lines;
				$new_lines = array_slice($lines,$start);	// don't need ,($this->max_txt_lines + 1),true);
				$this->textArea = implode("\n",$new_lines);
				$this->textArea_truncated = true;
				$this->error .= '<p style="color: orangered;">Screen truncated to ' . $this->max_txt_lines . ' lines.</p>';
				} // if
			} // else
		$this->textArea = trim($this->textArea) . ' ';
		} // composeSrnText()

	public function getAvailableCmds() {
		return implode(', ', $this->allowed_commands);
		} // getAvailableCmds()

	} // terminal

ini_set('output_buffering', 'Off');
ini_set('display_errors', 'On');
ini_set('display_startup_errors', 'On');
ini_set('html_errors', 'On');

$terminal = new Terminal();
?>
<!DOCTYPE html>
<html dir="ltr" lang="en-AU">
	<head>
		<meta charset="UTF-8">
		<title>Terminal</title>
		<style>
			body {
				padding: 0;
				margin: 0 5px;
				}
			p {
				margin: 0;
				}
			div.top_line {
				}
			.child_line {
				display: inline-block;
				}
			h1 {
				display: inline-block;
				font-size: 1.5em;
				white-space: nowrap;
				}
			input.exe {
				display: inline-block;
				margin: 0;
				padding: 0;
				}
			.fb_screen {
				background-color: #000;
				font-size: 1.25em;
				min-height: 512px;
				width: calc(100vw - 30px);
				height: calc(100vh - 130px);
				padding: 5px;
				color: white;
				border: 5px inset #ccc;
				cursor: text;
				}
		</style>
		<script type="text/javascript">
			var trm_last_svr_len = <?php echo strlen($terminal->textArea); ?>;
			var trm_cur_pos_ta_len = <?php echo strlen($terminal->textArea); ?>;
			var trm_recent_cmds = <?php echo json_encode($terminal->trm_recent_cmds,(JSON_PRETTY_PRINT)); ?>;
			var trm_recent_cmd_idx = <?php echo $terminal->trm_recent_cmd_idx; ?>;

			function moveToEnd(obj,offset) {
				if(!offset) offset = 0;
				if (typeof obj.selectionStart == "number") {
					obj.selectionStart = obj.selectionEnd = obj.value.length - offset;
					} // if
				else if (typeof obj.createTextRange != "undefined") {
					obj.focus();
					var range = obj.createTextRange();
					range.collapse(false);
					range.select();
					} // else if
				} // moveToEnd()

			function keycode_mon(event) {
				var txt_inp = document.getElementById("id_fb_screen");
				var offset = 0;
				if(event.keyCode) {
					if (event.keyCode === 13) {	// return (submit)
						event.preventDefault();
						var form = txt_inp.form;
						form.submit();
						} // if
					else if (event.keyCode === 38) {	// up arrow (next previous cmd)
						event.preventDefault();
						var recents = trm_recent_cmds.length;
						if(((trm_recent_cmd_idx - 1) < recents) &&
							(trm_recent_cmd_idx > 0)) {
							trm_recent_cmd_idx--;
							var cur_txt = txt_inp.value;
							var old_scr = cur_txt.substring(0,trm_last_svr_len);	// clean off any existing
							// console.log('OLD:',old_scr);
							var hist_cmd = trm_recent_cmds[trm_recent_cmd_idx]
							var new_scr = old_scr + hist_cmd;
							// console.log('NEW:',new_scr);
							txt_inp.value = new_scr;
							document.getElementById('id_cur_hist').value = '\'' + trm_recent_cmd_idx + '\'';
							} // if
						} // if
					else if (event.keyCode === 40) {	// down arrow (next last cmd)
						event.preventDefault();
						var recents = trm_recent_cmds.length;
						if(((trm_recent_cmd_idx + 1) < recents) &&
							(trm_recent_cmd_idx > -1)) {
							trm_recent_cmd_idx++;
							var cur_txt = txt_inp.value;
							var old_scr = cur_txt.substring(0,trm_last_svr_len);	// clean off any existing
							// console.log('OLD:',old_scr);
							var hist_cmd = trm_recent_cmds[trm_recent_cmd_idx]
							var new_scr = old_scr + hist_cmd;
							// console.log('NEW:',new_scr);
							txt_inp.value = new_scr;
							document.getElementById('id_cur_hist').value =  '\'' + trm_recent_cmd_idx + '\'';
							} // if
						} // if
					else if (event.keyCode === 35) {	// end
						event.preventDefault();
						trm_cur_pos_ta_len = txt_inp.value.length;
						} // if
					else if (event.keyCode === 36) {	// home
						event.preventDefault();
						trm_cur_pos_ta_len = trm_last_svr_len;
						} // if
					else if (event.keyCode === 37) {	// left arrow
						event.preventDefault();
						if(trm_cur_pos_ta_len > trm_last_svr_len) trm_cur_pos_ta_len--;
						} // if
					else if (event.keyCode === 39) {	// right arrow
						event.preventDefault();
						if(trm_cur_pos_ta_len < txt_inp.value.length) trm_cur_pos_ta_len++;
						} // if
					else if (event.keyCode === 8) {	// backspace (just the current cmd not the history)
						event.preventDefault();
						var txt = txt_inp.value;
						console.log('TXT: ', txt);
						var vlen = txt.length;
						console.log('TXT Len: ', vlen);
						if(vlen > trm_last_svr_len) {	// ok
							vlen --;
							var new_scr = txt.substring(0,vlen);	// clean off 1 char
							txt_inp.value = new_scr;
							trm_cur_pos_ta_len --;
							} // if
						} // if
					else if (event.keyCode === 46) {	// delete
						event.preventDefault();
						var txt = txt_inp.value;
						console.log('TXT: ', txt);
						var vlen = txt.length;
						console.log('TXT Len: ', vlen);
						if(vlen > trm_cur_pos_ta_len) {	// ok
							// remove char at trm_cur_pos_ta_len
							var new_scr = txt.substring(0,trm_cur_pos_ta_len) + txt.substring((trm_cur_pos_ta_len + 1));	// clean off 1 char
							txt_inp.value = new_scr;
							// no change trm_cur_pos_ta_len --;
							} // if
						} // if
					else {
						trm_cur_pos_ta_len++;
						} // else
					offset = txt_inp.value.length - trm_cur_pos_ta_len;
					} // if
				moveToEnd(txt_inp,offset);
				} // keycode_mon()

			function init_keycode_mon() {
				var txt_inp = document.getElementById("id_fb_screen");
				trm_last_svr_len = txt_inp.value.length;	// because FF does something strAnGe with text length
				moveToEnd(txt_inp);
				txt_inp.focus();
				txt_inp.addEventListener('keydown',keycode_mon);
				} // init_keycode_mon()

		</script>
	</head>
	<body onload="init_keycode_mon();">
		<form name="terminal" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
			<div class="top_line">
				<h1 class="child_line" title="Enter command and click &quot;Execute&quot;.">
					Simple Shell Terminal
				</h1>
				<div class="child_line"> <?php echo TERMINAL_VERSION; ?>.</div>
				<input class="exe child_line" id="id_fb_clk" type="submit" name="system" value="Execute">
				<div class="child_line"><?php echo $terminal->error;?></div>
			</div>
			<p>Available commands: <?php echo $terminal->getAvailableCmds(); ?></p>
			<textarea
				id="id_fb_screen"
				class="fb_screen"
				name="term_screen"
				spellcheck="false"
				autofocus="true"
				><?php echo $terminal->textArea; ?></textarea>
			<input type="hidden" id="id_cur" name="cwd" value="<?php echo rawurlencode($terminal->cwd); ?>">
			<input type="hidden" id="id_cur_hist" name="cur_hist" value="<?php echo count($terminal->trm_recent_cmds); ?>">
		</form>
	</body>
</html>

