<?php
// debugged May 2020 by Robert Fulton robert0609@braeworks.com
// from PHPclasses TorFileManager (Latest commit 1ca8f76 on Nov 29, 2017)
/*
 * V2.0 debugged version TorFileManager from PHPclasses
 * V2.1 added multi file uploads
 *
 */
namespace TorFileManager;

define("VERSION", "V2.1");

class Config {

	static public $folder_img = 'img/security_folder_black.png'; // 'http://findicons.com/files/icons/552/aqua_candy_revolution/16/security_folder_black.png';
	static public $file_img = 'img/registry_file.png'; //'http://findicons.com/files/icons/743/rumax_ip/16/registry_file.png';
	static public $download_img = 'img/download.png'; // 'http://findicons.com/files/icons/141/toolbar_icons_6_by_ruby_softwar/16/download.png';
	static public $zip_img = 'img/folder_zipper.png'; // 'http://findicons.com/files/icons/1156/fugue/16/folder_zipper.png';
	static public $unzip_img = 'img/comprimidos_zip.png'; // 'http://findicons.com/files/icons/1016/aerovista/16/comprimidos_zip.png';
	static public $delete_img = 'img/delete.png'; // 'http://findicons.com/files/icons/139/toolbar_icons_2_by_ruby_softwar/16/delete.png';
	static public $date_format = 'd M y H:i:s';
	static public $ds = DIRECTORY_SEPARATOR;
	static public $zip_extract_folder = 'zip_extract';
	static public $zip_folder = 'zip_files';

}

class Processing {

	public static function replaceSeparators($address = '') {
		return str_replace(['//', '\\'], ['/', '/'], str_replace(Config::$ds, '/', $address));
	}

	public static function formatBytes($bytes, $precision = 2) {
		if (!$bytes)
			return '0 b';
		$base = log($bytes, 1024);
		$suffixes = ['b', 'Kb', 'Mb', 'Gb', 'Tb'];
		return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
	}

	public static function sortArrayWithObjects($array, $property = 'name') {
		usort($array, function ($a, $b) use ($property) {
			if ($a->$property == $b->$property) {
				return 0;
			}
			return ($a->$property < $b->$property) ? -1 : 1;
		});
		return $array;
	}

}

class FileManager {

	private static $errors = [];
	private static $messages = [];
	private static $zip_files_added = 0;
	private static $zip_folders_added = 0;
	public static $msgs = array();

	public static function getRootFolder() {
		// wrong return Processing::replaceSeparators($_SERVER['DOCUMENT_ROOT']);
		// pick off the server alias not the virtual server base doc root folder
		$script = $_SERVER['SCRIPT_NAME'];
		$script_len = strlen($script);
		$filename = $_SERVER['SCRIPT_FILENAME'];
		$filename_len = strlen($filename);
		// remove the $script part from $filename to get root folder taking into account aliases
		// step backwards thru the both strings looking a match,
		// when not matched to RHS at that point is the web URI and
		// the LHS is the directory root
		// slow runtime but quick to code
		$end = 0;
		do {
			$end --;
			} while (substr($script,$end) == substr($filename,$end));
		$f_root = substr($filename,0,($filename_len + $end + 1));
		return Processing::replaceSeparators($f_root);
	}

	private static function get_username($uid) {
		$info = posix_getpwuid($uid);
		if (!empty($info['name']))
			return $info['name'];
		return $uid;
	}

// get_username()

	private static function get_groupname($gid) {
		$info = posix_getgrgid($gid);
		if (!empty($info['name']))
			return $info['name'];
		return $gid;
	}

// get_username()

	public static function getFolders($path = '') {
		$folders = [];
		try {	// catch that hidden Trash folder
			foreach (new \DirectoryIterator($path) as $folder) {
				try {
					if (!$folder->isDot() && $folder->isDir()) {
						$folder_info = new \stdClass();
						$folder_info->name = $folder->getFilename();
						$folder_info->size = $folder->getSize();
						$folder_info->type = $folder->getType();
						$folder_info->owner = self::get_username($folder->getOwner());
						$folder_info->group = self::get_groupname($folder->getGroup());
						$folder_info->perms = substr(sprintf('%o', $folder->getPerms()), -4);
						$folder_info->ctime = date(Config::$date_format, $folder->getCTime());
						$folder_info->atime = date(Config::$date_format, $folder->getATime());
						$folder_info->mtime = date(Config::$date_format, $folder->getMTime());
						$folder_info->fileinfo = $folder->getFileInfo();
						$folder_info->isr = $folder->isReadable();
						$folder_info->isw = $folder->isWritable();
						$folder_info->ise = $folder->isExecutable();
						$folders[] = $folder_info;
					}
				} catch (\RuntimeException $e) {
					self::$errors[] = 'Error access to: ' . $folder->getFilename();
				}
			} // foreach
		} catch (\RuntimeException $e) {
			self::$errors[] = 'Error accessing to: ' . $path;
		}
		return $folders;
	}

	public static function getFiles($path = '') {
		$files = [];
		try {	// catch that hidden Trash folder
			foreach (new \DirectoryIterator($path) as $file) {
				try {
					if (!$file->isDot() && $file->isFile()) {
						$file_info = new \stdClass();
						$file_info->name = $file->getFilename();
						$file_info->size = $file->getSize();
						$file_info->type = $file->getType();
						$file_info->owner = self::get_username($file->getOwner());
						$file_info->group = self::get_groupname($file->getGroup());
						$file_info->perms = substr(sprintf('%o', $file->getPerms()), -4);
						$file_info->ctime = date(Config::$date_format, $file->getCTime());
						$file_info->atime = date(Config::$date_format, $file->getATime());
						$file_info->mtime = date(Config::$date_format, $file->getMTime());
						$file_info->fileinfo = $file->getFileInfo();
						$file_info->isr = $file->isReadable();
						$file_info->isw = $file->isWritable();
						$file_info->ise = $file->isExecutable();
						$file_info->ext = $file->getExtension();
						$files[] = $file_info;
					}
				} catch (\RuntimeException $e) {
					//echo '<div class="alert alert-warning" role="alert">Error access to: '.$file->getFilename().'</div>';
				}
			} // foreach
		} catch (\RuntimeException $e) {
			self::$errors[] = 'Error accessing to: ' . $path;
		}
		return $files;
	}

	public static function downloadFile($file) {
		if (file_exists($file)) {
			if (ob_get_level()) {
				ob_end_clean();
			}
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename=' . basename($file));
			header('Content-Transfer-Encoding: binary');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			readfile($file);
			exit(0);
		} else {
			self::$errors[] = 'Download: Not found ' . $file;
			return false;
		}
	}

	public static function deleteFile($file) {
		if (file_exists($file)) {
			if (unlink($file)) {
				self::$messages[] = "File: " . $file . " successfully deleted.";
				return true;
			}
		} else {
			self::$errors[] = 'File not found: ' . $file;
			return false;
		}
	}

	public static function convertFolderToZip($folder_path = '', $zip_path = '') {
		if (!$zip_path) {
			$zip_path = self::getRootFolder() . Config::$ds . Config::$zip_folder;
			if (!file_exists($zip_path)) {
				if (!mkdir($zip_path, 0777)) {
					self::$errors[] = 'ZIP: I couldn\'t create zip files folder ' . $zip_path;
					return false;
				}
			}
		}
		//echo $folder_path.'<br/>';
		$zip = new \ZipArchive();
		$zip_name = substr($folder_path, (strrpos($folder_path, '/') + 1)) . '.zip';
		//echo $zip_name.'<br/>';
		if (file_exists($zip_path . '/' . $zip_name))
			unlink($zip_path . '/' . $zip_name);
		$ret = $zip->open($zip_path . '/' . $zip_name, \ZipArchive::OVERWRITE | \ZipArchive::CREATE | \ZipArchive::EXCL);
		if ($ret !== TRUE) {
			self::$errors[] = 'ZIP: Failed with code ' . $ret . ($zip->getStatusString());
		} else {
			self::$zip_folders_added = self::$zip_files_added = 0;
			$first_folders = self::getFolders($folder_path);
			if (sizeof($first_folders)) {
				foreach ($first_folders as $ff) {
					if ($zip->addEmptyDir($ff->name)) {
						self::$zip_folders_added++;
						$zip = self::addSubFolderContentToZip($folder_path, $ff->name, '', $zip);
					}
				}
			}
			$first_files = self::getFiles($folder_path);
			if (sizeof($first_files)) {
				foreach ($first_files as $ff) {
					if ($zip->addFile($folder_path . '/' . $ff->name, $ff->name)) {
						self::$zip_files_added++;
					}
				}
			}

			self::$messages[] = "ZIP: $folder_path transfer to $zip_path [Zipped " . self::$zip_folders_added . " folder(s) and " . self::$zip_files_added . " file(s)]";

			$zip->close();
		}
	}

	protected static function addSubFolderContentToZip($folder_path, $active_folder, $pre_path, $zip) {
		//echo 'Work with subfolder: ' . $folder_path . '/' . $active_folder . ' <br/>';
		$pre_path .= ($pre_path ? '/' : '') . $active_folder;
		$folders = self::getFolders($folder_path . '/' . $active_folder);
		if (sizeof($folders)) {
			foreach ($folders as $ff) {
				//echo 'Added : ' . $pre_path . '/' . $ff->name . ' <br/>';
				if ($zip->addEmptyDir($pre_path . '/' . $ff->name)) {
					self::$zip_folders_added++;
				}
				//echo 'Continue parsing to  : ' . $folder_path . '/' . $active_folder . '/' . $ff->name . ' <br/>';
				$zip = self::addSubFolderContentToZip($folder_path . '/' . $active_folder, $ff->name, $pre_path, $zip);
			}
		}
		$files = self::getFiles($folder_path . '/' . $active_folder);
		if (sizeof($files)) {
			foreach ($files as $ff) {
				if ($zip->addFile($folder_path . '/' . $active_folder . '/' . $ff->name, $pre_path . '/' . $ff->name)) {
					self::$zip_files_added++;
				}
			}
		}
		return $zip;
	}

	public static function extractZip($file_path = '', $extract_path = '') {
		if (!file_exists($file_path) || !is_file($file_path)) {
			self::$errors[] = 'ZIP: Not found in ' . $file_path;
			return false;
		}

		$zip_folder_name = str_replace('.zip', '', substr(strrchr($file_path, '/'), 1));
		if (!$zip_folder_name) {
			self::$errors[] = 'ZIP: Can\'t generate folder name. ' . $file_path;
			return false;
		}
		if (!$extract_path) {
			$extract_path = self::getRootFolder() . Config::$ds . Config::$zip_extract_folder . Config::$ds . $zip_folder_name;
			if (!file_exists($extract_path)) {
				if (!mkdir($extract_path, 0755)) {
					self::$errors[] = 'ZIP: I couldn\'t create extract folder ' . $extract_path;
					return false;
				}
			}
		}
		$zip = new \ZipArchive;
		$res = $zip->open($file_path);
		if ($res === TRUE) {
			$zip->extractTo($extract_path);
			$zip->close();
			self::$messages[] = "ZIP: $file_path extracted to $extract_path";
		} else {
			self::$errors[] = 'ZIP: I couldn\'t open' . $file_path;
			return false;
		}
	}

	public static function getErrorsString() {
		$error_string = '';
		if (sizeof(self::$errors))
			foreach (self::$errors as $error) {
				$error_string .= '<div class="alert alert-warning" role="alert">' . $error . '</div>';
			}
		return $error_string;
	}

	public static function getMessagesString() {
		$messages_string = '';
		if (sizeof(self::$messages))
			foreach (self::$messages as $message) {
				$messages_string .= '<div class="alert alert-success" role="success">' . $message . '</div>';
			}
		return $messages_string;
	}

	private static function upCodeToMessage($code) {
		switch ($code) {
			case 0:
				$message = 'Ok';
				break;
			case UPLOAD_ERR_INI_SIZE:
				$message = "The uploaded file exceeds the upload_max_filesize directive in php.ini";
				break;
			case UPLOAD_ERR_FORM_SIZE:
				$message = "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form";
				break;
			case UPLOAD_ERR_PARTIAL:
				$message = "The uploaded file was only partially uploaded";
				break;
			case UPLOAD_ERR_NO_FILE:
				$message = "No file was uploaded";
				break;
			case UPLOAD_ERR_NO_TMP_DIR:
				$message = "Missing a temporary folder";
				break;
			case UPLOAD_ERR_CANT_WRITE:
				$message = "Failed to write file to disk";
				break;
			case UPLOAD_ERR_EXTENSION:
				$message = "File upload stopped by extension";
				break;
			default:
				$message = "Unknown upload error";
				break;
		}
		return $message;
	}

	public static function processUpLoadedFiles($doc_root) {
		$upL_prefolders = explode(',',rawurldecode($_REQUEST['upL_prefolders']));
		$path = $doc_root . '/' . implode('/',$upL_prefolders);
		if ((isset($_FILES['uploadFiles']['name'])) &&
			(!empty($_FILES['uploadFiles']['name'])) &&
			(is_array($_FILES['uploadFiles']['name']))) { // check image location
			$fcnt = count($_FILES['uploadFiles']['name']);
			for ($i = 0; $i < $fcnt; $i++) {
				$name = $_FILES['uploadFiles']['name'][$i];
				$tmp_name = $_FILES['uploadFiles']['tmp_name'][$i];
				$code = $_FILES['uploadFiles']['error'][$i];
				if ($code > 0) {
					self::$errors[] = self::upCodeToMessage($code);
				} // if
				else { // ok so far
					$dest = $path . '/' . $name;
					if (!move_uploaded_file($tmp_name, $dest)) {
						self::$errors[] = 'ERROR: Failed to upload "' . $name . '". ';
					} // if
					else {
						self::$messages[] = 'SUCCESS: Uploaded "' . $name . '".';
					} // else
				} // else
			} // for
		} // if
	} // processUpLoadedFiles()

} // FileManager

$path = $action = '';
$path_file = $path_folder = '';
$up_url = '';
$pre_folders = [];
$home_url = $_SERVER['PHP_SELF'];	// this may have an alias in it and may crash after code changes
$doc_root = FileManager::getRootFolder();

//Initialise variables from REQUEST
if (isset($_REQUEST['action'])) {
	$action = $_REQUEST['action'];

	if (isset($_REQUEST['file'])) {
		$path_file = $_COOKIE['TOR_FM_PATH'] . '/' . rawurldecode($_REQUEST['file']);
		}
	}
else if (isset($_REQUEST['file'])) {
	$file = rawurldecode($_REQUEST['file']);
	$path_file = $_COOKIE['TOR_FM_PATH'] . '/' . $file;
	$mime = mime_content_type($path_file);
	header('Content-Type: ' . $mime);
	header('Content-Length: ' . filesize($path_file));
	readfile($path_file);
	exit;
	} // else

if (isset($_REQUEST['prefolders'])) {
	$pre_folders = explode(',', rawurldecode($_REQUEST['prefolders']));
}

if (isset($_REQUEST['folder'])) {
	$pre_folders[] = rawurldecode($_REQUEST['folder']);
}

if (isset($_REQUEST['folder'])) {
	$path_folder = rawurldecode($_REQUEST['folder']);
	$path = $doc_root . Config::$ds;
	if (sizeof($pre_folders)) {
		$path .= implode(Config::$ds, $pre_folders);
	} else {

		$path .= $path_folder;
	}

	if (!@file_exists($path)) {
		$path = $doc_root;
	}

	if (sizeof($pre_folders)) {
		$up_folders = $pre_folders;
		array_pop($up_folders);
		$up_folder = array_pop($up_folders);
		if ($up_folder) {
			$up_url = '?folder=' . rawurlencode($up_folder) . (count($up_folders) ? ('&prefolders=' . rawurlencode(implode(',', $up_folders))) : '');
		} else {
			$up_url = $home_url;
		}
	}
}
else
	$path = $doc_root . (!empty($pre_folders) ? '/' . implode('/', $pre_folders):'');

//Switch actions:
switch ($action) {
	case 'home':	// clean up and reset
		$path = $doc_root;
		$action = '';
		$path_file = $path_folder = '';
		$up_url = '';
		$pre_folders = [];
		setcookie("TOR_FM_PATH", $path);
		break;
	case 'download':
		FileManager::downloadFile($path_file);
		break;
	case 'delete':
		FileManager::deleteFile($path_file);
		$path = $_COOKIE['TOR_FM_PATH'];
		break;
	case 'to_zip':
		if (isset($_REQUEST['zipfolder'])) {
			$folder_path = $_COOKIE['TOR_FM_PATH'] . '/' . $_REQUEST['zipfolder'];
			FileManager::convertFolderToZip($folder_path);
			$path = $doc_root . Config::$ds . Config::$zip_folder;
		}
		break;
	case 'extract_zip':
		FileManager::extractZip($path_file);
		$path = $doc_root . Config::$ds . Config::$zip_extract_folder;
		break;
	case 'upload':
		FileManager::processUpLoadedFiles($doc_root);
		break;
	default:
		break;
}

$path = Processing::replaceSeparators($path);
setcookie("TOR_FM_PATH", $path);
$folders = Processing::sortArrayWithObjects(FileManager::getFolders($path), 'name');
$files = Processing::sortArrayWithObjects(FileManager::getFiles($path), 'name');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>File Manager</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<style type="text/css">
			body {
				padding: 5px 0px 0px 0px;
			}
			.jumbotron .table tr td a img {
				margin-right: 3px;
			}
		</style>
		<script src="js/jquery.min.1.11.3.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script>

		</script>
	</head>
	<body>
		<div class="container theme-showcase" role="main" style="width: 100%;">
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
								data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="<?= $home_url; ?>?action=home" title="<?= VERSION; ?>">TFM</a>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="<?= $home_url; ?>?action=home"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>
									Home<span class="sr-only">(current)</span></a>
							</li>
<?php if ($up_url) { ?>
								<li><a href="<?= $up_url; ?>"><span class="glyphicon glyphicon-circle-arrow-up" aria-hidden="true"></span>
										Up</a>
								</li>
<?php } ?>
							<li><a href="javascript:void(0)" onclick="location.reload();"><span
										class="glyphicon glyphicon-refresh" aria-hidden="true"></span> Refresh</a></li>
							<li>
								<div class="file-upload-wrapper" style="padding: 5px 5px 0px 5px; margin: 5px 5px; border: 1px solid #ddd; border-radius: 5px;">
									<form name="torFM" action="<?php echo $home_url . '?action=upload'; ?>" method="post" enctype="multipart/form-data">
										<input type="hidden" name="upL_prefolders" value="<?php echo rawurlencode(implode(',', $pre_folders)); ?>"/>
										<label style="display: inline-block;">
											<input class="btn btn-primary btn-sm file-upload-wrapper" type="file" id="input-file-now"
												   name="uploadFiles[]" data-max-file-size="8M"
												   onchange="document.getElementById('upload-file-now').disabled = false;"
												   title="Drop files here to upload or click browse to select files."
												   multiple/>
										</label>
										<label style="display: inline-block;">
											<button class="btn btn-success btn-sm glyphicon glyphicon-upload" id="upload-file-now"
													type="submit" name="submit" value="upload"
													title="Click to upload files to current path."
													DISABLED> Upload</button>
										</label>
									</form>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</nav>

			<div class="panel panel-info">
				<div class="panel-heading">Current path: <strong><?= $path ?></strong></div>
				<div class="panel-body">
					<span class="label label-default">Folders: <?= count($folders); ?></span>
					<span class="label label-info">Files: <?= count($files); ?></span>
				</div>
			</div>
			<?= FileManager::getErrorsString(); ?>
			<?= FileManager::getMessagesString(); ?>
			<div class="jumbotron">
				<table class="table table-hover">
					<tr>
						<th>Title</th>
						<th>Created</th>
						<th>Size</th>
						<th>Owner/Group/Permissions [Read|Write|Execute]</th>
						<th>Modified</th>
						<th>Download [Remove/Zip]</th>
					</tr>
<?php if ($up_url) { ?>
					<tr>
						<td colspan="6" title="Click to return to parent directory.">
							<a href="<?= $up_url;?>">
								<img src="<?= Config::$folder_img; ?>"
									 alt="parent"/>
								back ...
							</a>
						</td>
					</tr>
<?php } ?>
<?php
foreach ($folders as $folder) {
?>
					<tr>
						<td>
							<a href="?folder=<?= rawurlencode($folder->name); ?><?= count($pre_folders) ? ('&prefolders=' . rawurlencode(implode(',', $pre_folders))) : ''; ?>">
								<img src="<?= Config::$folder_img; ?>"
									 alt="<?= $folder->type . ': ' . $folder->name; ?>"/><?= $folder->name; ?>
							</a>
						</td>
						<td><?= '<span class="label label-default">' . $folder->ctime . '</span> ' ?></td>
						<td><?= '<span class="label label-success">' . Processing::formatBytes($folder->size) . '</span> ' ?></td>
						<td><?= '<span class="label label-primary">' . $folder->owner . '</span> <span class="label label-primary">' . $folder->group . '</span> <span class="label label-info">' . $folder->perms . '</span>'; ?>
								[ <?=
					($folder->isr ? '<span class="label label-success">R</span>' : '<span class="label label-default">UR</span>')
					. ' | ' .
					($folder->isw ? '<span class="label label-success">W</span>' : '<span class="label label-default">UW</span>')
?>
								]
						</td>
						<td><?= ' <span class="label label-default">' . $folder->mtime . '</span>' ?></td>
						<td>
							<a href="?action=to_zip&zipfolder=<?= rawurlencode($folder->name); ?>">
								<img src="<?= Config::$zip_img; ?>" alt="<?= $folder->type . ': ' . rawurlencode($folder->name); ?>"/>
							</a>
						</td>
					</tr>
<?php
}
foreach ($files as $file) {
	?>
						<tr>
							<td>
								<a href="?file=<?= rawurlencode($file->name); ?>">
									<img src="<?= Config::$file_img; ?>"
										 alt="<?= $file->type . ': ' . rawurlencode($file->name); ?>"/><?= $file->name; ?>
								</a>
							</td>
							<td><?= '<span class="label label-default">' . $file->ctime . '</span> ' ?></td>
							<td><?= '<span class="label label-success">' . Processing::formatBytes($file->size) . '</span> ' ?></td>
							<td><?= '<span class="label label-primary">' . $folder->owner . '</span> <span class="label label-primary">' . $file->group . '</span> <span class="label label-info">' . $file->perms . '</span>'; ?>
								[ <?=
					($file->isr ? '<span class="label label-success">R</span>' : '<span class="label label-default">UR</span>')
					. ' | ' .
					($file->isw ? '<span class="label label-success">W</span>' : '<span class="label label-warning">UW</span>')
					. ' | ' .
					($file->ise ? '<span class="label label-danger">E</span>' : '<span class="label label-default">UE</span>')
	?>
								]
							</td>
							<td><?= ' <span class="label label-default">' . $file->mtime . '</span>' ?></td>
							<td>
								<a href="?action=download&file=<?= rawurlencode($file->name); ?>">
									<img src="<?= Config::$download_img; ?>" alt="<?= $file->type . ': ' . rawurlencode($file->name); ?>"/></a>
								<a href="?action=delete&file=<?= rawurlencode($file->name); ?>"  onclick="return confirm('Are you sure you want to delete this file?');">
									<img src="<?= Config::$delete_img; ?>" alt="<?= $file->type . ': ' . $file->name; ?>"/></a>
	<?php if ($file->ext == 'zip') { ?>
									<a href="?action=extract_zip&file=<?= rawurlencode($file->name); ?>">
										<img src="<?= Config::$unzip_img; ?>" alt="<?= $folder->type . ': ' . rawurlencode($folder->name); ?>"/></a>
	<?php } ?>
							</td>
						</tr>
	<?php
} // foreach
if((empty($files)) && (empty($folders))) {
?>
					<tr>
						<td colspan="6">
							(No accessible folders or files found.)
						</td>
					</tr>
<?php	} // if ?>
				</table>
			</div>
		</div>
	</body>
</html>
