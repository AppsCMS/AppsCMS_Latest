<?php // Revision: $Id: rgbpicker.php 2867 2022-04-30 23:12:42Z robert0609 $ ?>
<?php
	//

	?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
	<title>Braeworks Online Tools: Colour Picker</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta name="GENERATOR" content="BRAEWORKS">
	<meta name="copyright" content="&copy; 2007 BRAEWORKS">
	<meta name="Author" content="Robert Fulton">
	<meta name="CREATED" CONTENT="20070217;12000000">
	<META name="keywords" content="RGB colour picker">
	<meta name="CHANGED" CONTENT="20070217;15300000">
	<meta name="CHANGEDBY" CONTENT="Robert Fulton">
	<link rel="stylesheet" type="text/css" href="rgbcp/rgbcp.css"/>
	<script language="javascript" src="rgbcp/rgbcp.js"></script>
</head>
<body>
	<h1>RGB Colour Picker</h1>
<!--	<script language="javascript">cp_create();</script>-->
<!--	<input id="field_id" onchange="cp_update_color_box(this.id);">-->
	<input id="example_1" type="text" name="field_name_1" size="6" maxlength="6">
	<script language="javascript">
		cp_create();
		cp_color_field('example_1', CP_FIELD_ICON);
		// cp_update_color_box(this.id);
	</script>
</body>
</html>
