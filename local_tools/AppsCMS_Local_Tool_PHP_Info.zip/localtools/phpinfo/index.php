<H1 align="center"><?php echo $_SERVER['SERVER_NAME']; ?> server PHP info</H1>
<?php
	phpinfo();
	?>
<br>
<p>Check Pear System class installed</p>
<?php
	if(file_exists('System.php')) require_once 'System.php';
	if(class_exists('System')) echo 'Pear System class installed.' . "\n";
	else echo 'PEAR System class does not exist.' ."\n";
?>
<br>
