<?php // Revision: $Id: ASCIItable.php 2867 2022-04-30 23:12:42Z robert0609 $ 

	// ASCII table array, added codes 128 to 255 14/09/2009
	$aASCIItab = array(	// 128 rows, 3 + 1 columns, remember it is for html display
			//	Decimal,	Octal,	Hex',	Char',	Comment
			array ( 0, "000", "00", "[NUL]", "^@, null, padding, ignore, terminator", ),
			array ( 1, "001", "01", "[SOH]", "^A, start of header", ),
			array ( 2, "002", "02", "[STX]", "^B, start of text", ),
			array ( 3, "003", "03", "[ETX]", "^C, end of text, break", ),
			array ( 4, "004", "04", "[EOT]", "^D, end of transmission", ),
			array ( 5, "005", "05", "[ENQ]", "^E, enquiry, transmission request (reception ready)", ),
			array ( 6, "006", "06", "[ACK]", "^F, acknowledge, OK", ),
			array ( 7, "007", "07", "[BEL]", "^G, bell, alarm", ),
			array ( 8, "010", "08", "[BS]", "^H, backspace (delete character to the left of cursor)", ),
			array ( 9, "011", "09", "[HT]", "^I, horizontal tab (\"whitespace\"), column seperator", ),
			array ( 10, "012", "0A", "[LF]", "^J, line feed", ),
			array ( 11, "013", "0B", "[VT]", "^K, vertical tab", ),
			array ( 12, "014", "0C", "[FF]", "^L, form feed", ),
			array ( 13, "015", "0D", "[CR]", "^M, carriage return, enter", ),
			array ( 14, "016", "0E", "[SO]", "^N, shift out", ),
			array ( 15, "017", "0F", "[SI]", "^O, shift in", ),
			array ( 16, "020", "10", "[DLE]", "^P, data link escape", ),
			array ( 17, "021", "11", "[DC1]", "^Q, data control 1, xon, resume", ),
			array ( 18, "022", "12", "[DC2]", "^R, data control 2", ),
			array ( 19, "023", "13", "[DC3]", "^S, data control 3, xoff, pause", ),
			array ( 20, "024", "14", "[DC4]", "^T, data control 4", ),
			array ( 21, "025", "15", "[NAK]", "^U, negative, error, not OK", ),
			array ( 22, "026", "16", "[SYN]", "^V, synchronous idle, keep alive", ),
			array ( 23, "027", "17", "[ETB]", "^W, end of transmission block", ),
			array ( 24, "030", "18", "[CAN]", "^X, cancel", ),
			array ( 25, "031", "19", "[EM]", "^Y, end of media or medium", ),
			array ( 26, "032", "1A", "[SUB]", "^Z, substitute, cls, end of file", ),
			array ( 27, "033", "1B", "[ESC]", "^[, escape, control sequence prefix", ),
			array ( 28, "034", "1C", "[FS]", "^\, file separator", ),
			array ( 29, "035", "1D", "[GS]", "^], group separator", ),
			array ( 30, "036", "1E", "[RS]", "^^, record separator", ),
			array ( 31, "037", "1F", "[US]", "^_, unit separator, home", ),
			array ( 32, "040", "20", "(spc)", "blank, space (\"whitespace\"), text delimiter, \"&amp;nbsp;\"", ),
			array ( 33, "041", "21", "!",  "exclamation mark, not (logical, relational)", ),
			array ( 34, "042", "22", "&quot",  "diaeresis, (double) quotation marks, (double) encapsulation marks, \"&amp;quot;\"", ),
			array ( 35, "043", "23", "#",  "number sign, hash, (\"name\" prefix)", ),
			array ( 36, "044", "24", "$",  "dollar, (\"variable\" or \"value name\" prefix)", ),
			array ( 37, "045", "25", "%",  "percent, modulus (arithmetic)", ),
			array ( 38, "046", "26", "&amp;",  "ampersand, and (&amp;&amp; logical, relational), (\"address of\" or \"reference to\" prefix), \"&amp;amp;\"", ),
			array ( 39, "047", "27", "&rsquo;",  "apostrophe, (single) quotation mark, (single) encapsulation mark", ),
			array ( 40, "050", "28", "(",  "open parenthesis, (\"higher precedence\" arithmetic, relational)", ),
			array ( 41, "051", "29", ")",  "close parenthesis, (\"lower precedence\" arithmetic, relational)", ),
			array ( 42, "052", "2A", "*",  "asterisk, star, multiply (arithmetic), (\"points to\" prefix)", ),
			array ( 43, "053", "2B", "+",  "plus sign, add (arithmetic), concatenate (logical)", ),
			array ( 44, "054", "2C", ",",  "comma, seperator, (\"delimiter\" logical)", ),
			array ( 45, "055", "2D", "-",  "minus sign, hyphen, dash, subtract (arithmetic)", ),
			array ( 46, "056", "2E", ".",  "full stop, period, dot, concatenate/join (logical)", ),
			array ( 47, "057", "2F", "/",  "forward slash, fraction bar, per, divide (arithmetic), \"&amp;frasl;\"", ),
			array ( 48, "060", "30", "0",  "(numeral), ZERO", ),
			array ( 49, "061", "31", "1",  "(numeral), ONE", ),
			array ( 50, "062", "32", "2",  "(numeral), TWO", ),
			array ( 51, "063", "33", "3",  "(numeral), THREE", ),
			array ( 52, "064", "34", "4",  "(numeral), FOUR", ),
			array ( 53, "065", "35", "5",  "(numeral), FIVE", ),
			array ( 54, "066", "36", "6",  "(numeral), SIX", ),
			array ( 55, "067", "37", "7",  "(numeral), SEVEN", ),
			array ( 56, "070", "38", "8",  "(numeral), EIGHT", ),
			array ( 57, "071", "39", "9",  "(numeral), NINE", ),
			array ( 58, "072", "3A", ":",  "colon, full colon", ),
			array ( 59, "073", "3B", ";",  "semicolon, (\"delimiter\" logical)", ),
			array ( 60, "074", "3C", "&lt;",  "left angle bracket, left chevron, less than (relational), \"&amp;lt;\"", ),
			array ( 61, "075", "3D", "=",  "equal sign, equals sign, equal (arithmetic, logical, relational)", ),
			array ( 62, "076", "3E", "&gt",  "right angle bracket, right chevron, greater than (relational), \"&amp;gt;\"", ),
			array ( 63, "077", "3F", "?",  "question mark, eroteme, interrogation point (relational)", ),
			array ( 64, "100", "40", "@",  "commercial at, at sign, at, (\"belongs to\" or \"associate\")", ),
			array ( 65, "101", "41", "A",  "(uppercase), ALPHA", ),
			array ( 66, "102", "42", "B",  "(uppercase), BRAVO", ),
			array ( 67, "103", "43", "C",  "(uppercase), CHARLIE, Roman one hundred", ),
			array ( 68, "104", "44", "D",  "(uppercase), DELTA, Roman five hundred", ),
			array ( 69, "105", "45", "E",  "(uppercase), ECHO", ),
			array ( 70, "106", "46", "F",  "(uppercase), FOXTROT", ),
			array ( 71, "107", "47", "G",  "(uppercase), GOLF, prefix giga", ),
			array ( 72, "110", "48", "H",  "(uppercase), HOTEL", ),
			array ( 73, "111", "49", "I",  "(uppercase), INDIA, Roman one", ),
			array ( 74, "112", "4A", "J",  "(uppercase), JULIET", ),
			array ( 75, "113", "4B", "K",  "(uppercase), KILO, prefix kilo", ),
			array ( 76, "114", "4C", "L",  "(uppercase), LIMA, Roman fifty", ),
			array ( 77, "115", "4D", "M",  "(uppercase), MIKE, prefix mega, Roman one thousand", ),
			array ( 78, "116", "4E", "N",  "(uppercase), NOVEMBER", ),
			array ( 79, "117", "4F", "O",  "(uppercase), OSCAR", ),
			array ( 80, "120", "50", "P",  "(uppercase), PAPA", ),
			array ( 81, "121", "51", "Q",  "(uppercase), QUEBEC", ),
			array ( 82, "122", "52", "R",  "(uppercase), ROMEO", ),
			array ( 83, "123", "53", "S",  "(uppercase), SERRIA", ),
			array ( 84, "124", "54", "T",  "(uppercase), TANGO, prefix terra", ),
			array ( 85, "125", "55", "U",  "(uppercase), UNIFORM", ),
			array ( 86, "126", "56", "V",  "(uppercase), VICTOR, Roman five", ),
			array ( 87, "127", "57", "W",  "(uppercase), WHISKY", ),
			array ( 88, "130", "58", "X",  "(uppercase), X-RAY, Roman ten", ),
			array ( 89, "131", "59", "Y",  "(uppercase), YANKEE", ),
			array ( 90, "132", "5A", "Z",  "(uppercase), ZULU", ),
			array ( 91, "133", "5B", "[",  "open/left square bracket", ),
			array ( 92, "134", "5C", "\\",  "back slash, reverse solidus, slosh, escape character prefix", ),
			array ( 93, "135", "5D", "]",  "close/right square bracket", ),
			array ( 94, "136", "5E", "^",  "caret (circumflex accent), to the power of (arithmetic), xor (logical)", ),
			array ( 95, "137", "5F", "_",  "underscore", ),
			array ( 96, "140", "60", "`",  "grave accent", ),
			array ( 97, "141", "61", "a",  "(lowercase)", ),
			array ( 98, "142", "62", "b",  "(lowercase)", ),
			array ( 99, "143", "63", "c",  "(lowercase), prefix centi", ),
			array ( 100, "144", "64", "d",  "(lowercase)", ),
			array ( 101, "145", "65", "e",  "(lowercase)", ),
			array ( 102, "146", "66", "f",  "(lowercase)", ),
			array ( 103, "147", "67", "g",  "(lowercase)", ),
			array ( 104, "150", "68", "h",  "(lowercase)", ),
			array ( 105, "151", "69", "i",  "(lowercase)", ),
			array ( 106, "152", "6A", "j",  "(lowercase)", ),
			array ( 107, "153", "6B", "k",  "(lowercase)", ),
			array ( 108, "154", "6C", "l",  "(lowercase)", ),
			array ( 109, "155", "6D", "m",  "(lowercase), prefix milli", ),
			array ( 110, "156", "6E", "n",  "(lowercase), prefix nano", ),
			array ( 111, "157", "6F", "o",  "(lowercase)", ),
			array ( 112, "160", "70", "p",  "(lowercase), prefix pico", ),
			array ( 113, "161", "71", "q",  "(lowercase)", ),
			array ( 114, "162", "72", "r",  "(lowercase)", ),
			array ( 115, "163", "73", "s",  "(lowercase)", ),
			array ( 116, "164", "74", "t",  "(lowercase)", ),
			array ( 117, "165", "75", "u",  "(lowercase), prefix micro", ),
			array ( 118, "166", "76", "v",  "(lowercase)", ),
			array ( 119, "167", "77", "w",  "(lowercase)", ),
			array ( 120, "170", "78", "x",  "(lowercase)", ),
			array ( 121, "171", "79", "y",  "(lowercase)", ),
			array ( 122, "172", "7A", "z",  "(lowercase)", ),
			array ( 123, "173", "7B", "{",  "left brace, left curly brace", ),
			array ( 124, "174", "7C", "|",  "vertical bar, pipe (\"send to\"), or (|| logical, relational)", ),
			array ( 125, "175", "7D", "}",  "right brace, right curly brace,", ),
			array ( 126, "176", "7E", "~",  "tilde (grapheme), negate (logical)", ),
			array ( 127, "177", "7F", "[del]",  "^?, delete (character under cursor), (often is a backspace)", ),

			// added 14/09/2009 BF

			// Extended ASCII added 14/09/2011
			array ( 128, "200", "80", "&euro;", "Euro", ),
			array ( 129, "201", "81", "", "� Unknown", ),
			array ( 130, "202", "82", "&sbquo;", "Single low-quote", ),
			array ( 131, "203", "83", "&fnof;", "Function symbol (lowercase f with hook)", ),
			array ( 132, "204", "84", "&bdquo;", "Double low-quote", ),
			array ( 133, "205", "85", "&hellip;", "Elipsis", ),
			array ( 134, "206", "86", "&dagger;", "Dagger", ),
			array ( 135, "207", "87", "&Dagger;", "Double dagger", ),
			array ( 136, "210", "88", "&circ;", "Hatchek", ),
			array ( 137, "211", "89", "&permil;", "Per mille symbol", ),
			array ( 138, "212", "8A", "&Scaron;", "Capital esh", ),
			array ( 139, "213", "8B", "&lsaquo;", "Left single angle quote", ),
			array ( 140, "214", "8C", "&OElig;", "OE ligature", ),
			array ( 141, "215", "8D", "", "� Unknown", ),
			array ( 142, "216", "8E", "&#142;", "Capital ž", ),
			array ( 143, "217", "8F", "", "� Unknown", ),
			array ( 144, "220", "90", "", "� Unknown", ),
			array ( 145, "221", "91", "&lsquo;", "Left single-quote", ),
			array ( 146, "222", "92", "&rsquo;", "Right single-quote", ),
			array ( 147, "223", "93", "&ldquo;", "Left double-quote", ),
			array ( 148, "224", "94", "&rdquo;", "Right double-quote", ),
			array ( 149, "225", "95", "&bull;", "Small bullet", ),
			array ( 150, "226", "96", "&ndash;", "En dash", ),
			array ( 151, "227", "97", "&mdash;", "Em dash", ),
			array ( 152, "230", "98", "&tilde;", "Tilde", ),
			array ( 153, "231", "99", "&trade;", "Trademark", ),
			array ( 154, "232", "9A", "&scaron;", "Lowercase esh", ),
			array ( 155, "233", "9B", "&rsaquo;", "Right single angle quote", ),
			array ( 156, "234", "9C", "&oelig;", "oe ligature", ),
			array ( 157, "235", "9D", "", "� Unknown", ),
			array ( 158, "236", "9E", "&#158;", "Lowercase ž", ),
			array ( 159, "237", "9F", "&Yuml;", "Uppercase y-umlaut", ),
			array ( 160, "240", "A0", "&nbsp;", "Non-breaking space", ),
			array ( 161, "241", "A1", "&iexcl;", "Inverted exclamation point", ),
			array ( 162, "242", "A2", "&cent;", "Cent", ),
			array ( 163, "243", "A3", "&pound;", "Pound currency sign", ),
			array ( 164, "244", "A4", "&curren;", "Currency sign", ),
			array ( 165, "245", "A5", "&yen;", "Yen currency sign", ),
			array ( 166, "246", "A6", "&brvbar;", "Broken vertical bar", ),
			array ( 167, "247", "A7", "&sect;", "Section symbol", ),
			array ( 168, "250", "A8", "&uml;", "Umlaut (Diaeresis)", ),
			array ( 169, "251", "A9", "&copy;", "Copyright", ),
			array ( 170, "252", "AA", "&ordf;", "Feminine ordinal indicator (superscript lowercase a)", ),
			array ( 171, "253", "AB", "&laquo;", "Left angle quote", ),
			array ( 172, "254", "AC", "&not;", "Not sign", ),
			array ( 173, "255", "AD", "&shy;", "Soft hyphen (non printing)", ),
			array ( 174, "256", "AE", "&reg;", "Registered sign", ),
			array ( 175, "257", "AF", "&macr;", "Macron", ),
			array ( 176, "260", "B0", "&deg;", "Degree sign", ),
			array ( 177, "261", "B1", "&plusmn;", "Plus/minus sign", ),
			array ( 178, "262", "B2", "&sup2;", "Superscript 2, squared", ),
			array ( 179, "263", "B3", "&sup3;", "Superscript 3, cubed", ),
			array ( 180, "264", "B4", "&acute;", "Acute accent", ),
			array ( 181, "265", "B5", "&micro;", "Micro sign", ),
			array ( 182, "266", "B6", "&para;", "Pilcrow sign (paragraph)", ),
			array ( 183, "267", "B7", "&middot;", "Middle dot", ),
			array ( 184, "270", "B8", "&cedil;", "Cedilla", ),
			array ( 185, "271", "B9", "&sup1;", "Superscript 1", ),
			array ( 186, "272", "BA", "&ordm;", "Masculine ordinal indicator (superscript o)", ),
			array ( 187, "273", "BB", "&raquo;", "Right angle quote", ),
			array ( 188, "274", "BC", "&frac14;", "One quarter fraction", ),
			array ( 189, "275", "BD", "&frac12;", "One half fraction", ),
			array ( 190, "276", "BE", "&frac34;", "Three quarters fraction", ),
			array ( 191, "277", "BF", "&iquest;", "Inverted question mark", ),
			array ( 192, "300", "C0", "&Agrave;", "A grave accent", ),
			array ( 193, "301", "C1", "&Aacute;", "A accute accent", ),
			array ( 194, "302", "C2", "&Acirc;", "A circumflex", ),
			array ( 195, "303", "C3", "&Atilde;", "A tilde", ),
			array ( 196, "304", "C4", "&Auml;", "A umlaut", ),
			array ( 197, "305", "C5", "&Aring;", "A ring", ),
			array ( 198, "306", "C6", "&AElig;", "AE ligature", ),
			array ( 199, "307", "C7", "&Ccedil;", "C cedilla", ),
			array ( 200, "310", "C8", "&Egrave;", "E grave", ),
			array ( 201, "311", "C9", "&Eacute;", "E acute", ),
			array ( 202, "312", "CA", "&Ecirc;", "E circumflex", ),
			array ( 203, "313", "CB", "&Euml;", "E umlaut", ),
			array ( 204, "314", "CC", "&Igrave;", "I grave", ),
			array ( 205, "315", "CD", "&Iacute;", "I acute", ),
			array ( 206, "316", "CE", "&Icirc;", "I circumflex", ),
			array ( 207, "317", "CF", "&Iuml;", "I umlaut", ),
			array ( 208, "320", "D0", "&ETH;", "Eth", ),
			array ( 209, "321", "D1", "&Ntilde;", "N tilde (enye)", ),
			array ( 210, "322", "D2", "&Ograve;", "O grave", ),
			array ( 211, "323", "D3", "&Oacute;", "O acute", ),
			array ( 212, "324", "D4", "&Ocirc;", "O circumflex", ),
			array ( 213, "325", "D5", "&Otilde;", "O tilde", ),
			array ( 214, "326", "D6", "&Ouml;", "O umlaut", ),
			array ( 215, "327", "D7", "&times;", "Multiplication sign", ),
			array ( 216, "330", "D8", "&Oslash;", "O slash", ),
			array ( 217, "331", "D9", "&Ugrave;", "U grave", ),
			array ( 218, "332", "DA", "&Uacute;", "U acute", ),
			array ( 219, "333", "DB", "&Ucirc;", "U circumflex", ),
			array ( 220, "334", "DC", "&Uuml;", "U umlaut", ),
			array ( 221, "335", "DD", "&Yacute;", "Y acute", ),
			array ( 222, "336", "DE", "&THORN;", "Thorn", ),
			array ( 223, "337", "DF", "&szlig;", "SZ ligature", ),
			array ( 224, "340", "E0", "&agrave;", "a grave", ),
			array ( 225, "341", "E1", "&aacute;", "a acute", ),
			array ( 226, "342", "E2", "&acirc;", "a circumflex", ),
			array ( 227, "343", "E3", "&atilde;", "a tilde", ),
			array ( 228, "344", "E4", "&auml;", "a umlaut", ),
			array ( 229, "345", "E5", "&aring;", "a ring", ),
			array ( 230, "346", "E6", "&aelig;", "ae ligature", ),
			array ( 231, "347", "E7", "&ccedil;", "c cedilla", ),
			array ( 232, "350", "E8", "&egrave;", "e grave", ),
			array ( 233, "351", "E9", "&eacute;", "e acute", ),
			array ( 234, "352", "EA", "&ecirc;", "e circumflex", ),
			array ( 235, "353", "EB", "&euml;", "e umlaut", ),
			array ( 236, "354", "EC", "&igrave;", "i grave", ),
			array ( 237, "355", "ED", "&iacute;", "i acute", ),
			array ( 238, "356", "EE", "&icirc;", "i circumflex", ),
			array ( 239, "357", "EF", "&iuml;", "i umlaut", ),
			array ( 240, "360", "F0", "&eth;", "eth", ),
			array ( 241, "361", "F1", "&ntilde;", "n tilde", ),
			array ( 242, "362", "F2", "&ograve;", "o grave", ),
			array ( 243, "363", "F3", "&oacute;", "o acute", ),
			array ( 244, "364", "F4", "&ocirc;", "o circumflex", ),
			array ( 245, "365", "F5", "&otilde;", "o tilde", ),
			array ( 246, "366", "F6", "&ouml;", "o umlaut", ),
			array ( 247, "367", "F7", "&divide;", "Division symbol", ),
			array ( 248, "371", "F8", "&oslash;", "o slash", ),
			array ( 249, "372", "F9", "&ugrave;", "u grave", ),
			array ( 250, "372", "FA", "&uacute;", "u acute", ),
			array ( 251, "373", "FB", "&ucirc;", "u circumflex", ),
			array ( 252, "374", "FC", "&uuml;", "u umlaut", ),
			array ( 253, "375", "FD", "&yacute;", "y acute", ),
			array ( 254, "376", "FE", "&thorn;", "thorn", ),
			array ( 255, "377", "FF", "&yuml;", "y umlaut", ),

		);

	function byte2binStr ( $iByte ) {
		$sStr = "";
		$iCnt = 8;
		while ( $iCnt-- ) {
			if($iCnt == 3) $sStr .= " ";
			if(($iByte & 0x80) > 0) $sStr .= "1";
			else $sStr .= "0";
			$iByte *= 2;
			} // while
		return $sStr;
		} // byte2binStr ()

define('AT_VERSION', 'V3.02');

$____in_iframe = false;
if( isset($_SERVER['HTTP_SEC_FETCH_DEST']) && $_SERVER['HTTP_SEC_FETCH_DEST'] == 'iframe' ) {
	$____in_iframe = true;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
	<title>AppsCMS Online Tools: ASCII Table</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta name="GENERATOR" content="BRAEWORKS">
	<meta name="Author" content="Robert Fulton">
	<meta name="CREATED" CONTENT="20050831;12150000">
	<META name="keywords" content="ASCII table, ASCII codes">
</head>
<body>
<?php	} // if ?>
	<h1>8 bit ASCII codes</h1>
	<table cellpadding="1" cellspacing="1" border="1">

		<tr>
			<td width="50" align="center">Deci&#39;</td>
			<td width="50" align="center">Oct&#39;</td>
			<td width="50" align="center">Hex&#39;</td>
			<td width="75" align="center">HTML Number</td>
			<td width="75" align="center">HTML Code</td>
			<td width="100" align="center">Binary</td>
			<td width="100" align="center">Character</td>
			<td width="200" align="left">Comments</td>
		</tr>
		<?php
			for($iAscii = 0; $iAscii < count($aASCIItab);$iAscii++) {
				echo "<tr>";
				for($iCol = 0; $iCol < 8; $iCol++) {
					echo "";
					switch($iCol) {
					case 0: echo "<td align=\"center\">",$aASCIItab[$iAscii][0], "</td>"; break;	// putup decimal
					case 1: echo "<td align=\"center\">0",$aASCIItab[$iAscii][1], "</td>"; break;	// putup octal
					case 2: echo "<td align=\"center\">0x",$aASCIItab[$iAscii][2], "</td>"; break;	// putup hexidecimal
					case 3: echo "<td align=\"center\">&amp;#" . $aASCIItab[$iAscii][0] .";</td>"; break;	// putup html
					case 4: echo "<td align=\"center\">" . (($iAscii >= 32 && strlen($aASCIItab[$iAscii][3]) > 1) ? htmlentities($aASCIItab[$iAscii][3]):$aASCIItab[$iAscii][3]) ."</td>"; break;	// putup html
					case 5: echo "<td align=\"center\">",byte2binStr($aASCIItab[$iAscii][0]), "</td>"; break;	// putup binary
					case 6: echo "<td align=\"center\">",$aASCIItab[$iAscii][3], "</td>"; break;	// putup character
					case 7: echo "<td align=\"left\">",$aASCIItab[$iAscii][4], "</td>"; break;	// putup comment/s
					default: break;
						} // switch
					} // for
				echo "</tr>";
				} // for
		?>
	</table>
	<h3>Comments</h3>
	<p>
		I have found a need to have a quick reference to the ASCII codes from time to time, consequently I have made this table available to internet users in the hope that others will find it useful. I have added information for characters commonly used for other uses in the comments column. The table is provided "as is" and no warrantees, guarantees or suitability for a purpose, are given, expressed or implied.
		<br>
		References: <br>
		<a href="http://en.wikipedia.org/ASCII" title="The free online encyclopedia.">Wikipedia</a><br>
		<a href="http://www.ascii-code.com/" title="The extended ASCII table.">ASCII Code</a>
	</p>
	<p>
		Tool for AppsCMS. <small>(<?php echo AT_VERSION; ?>)</small>
	</p>
<?php if($____in_iframe) {	?>
</body>
</html>
<?php	} // if ?>
