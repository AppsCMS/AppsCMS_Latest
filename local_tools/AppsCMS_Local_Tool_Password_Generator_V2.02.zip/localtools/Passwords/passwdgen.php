<?php
// Revision: $Id: passwdgen.php 2459 2019-06-13 11:37:50Z robert0609 $

define('PG_VERSION', 'V2.02');

$____in_iframe = false;
if( isset($_SERVER['HTTP_SEC_FETCH_DEST']) && $_SERVER['HTTP_SEC_FETCH_DEST'] == 'iframe' ) {
	$____in_iframe = true;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
	<title>AppsCMS Online Tools: Password and Hash Code Generator</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta name="GENERATOR" content="AppsCMS">
	<meta name="Author" content="Robert Fulton">
	<META name="keywords" content="password generator, hash code generator">
	<style>
		table { border: 1px double black; }
		tr { }
		td { border: 1px solid black; padding: 5px; }
	</style>
</head>
<body>
<?php	} // if ?>
<!--	<img alt="Password Lock" src="passwd_lock.png">-->
	<h1><img alt="Password Lock" src="passwd_lock_icon.png"> Password and Hash Code Generator</h1>
	<?php
		$iMaxPwdSize = 32;
		$iMinPwdSize = 4;
		$iMaxPwdQty = 50;
		// check source security
		if(empty($_SERVER['HTTPS'])) { // not a secure port
			echo '<h2 style="color: red;">WARNING: This page is being accessed on an insecure port.</h2>' . PHP_EOL;
			} // if

		// check generate posts
		if((isset($_POST['BWgenPW'])) && ($_POST['op'] == "gen")) {
			// do basic checks
			$iPWqty = $_POST['PWqty'];
			if($iPWqty < 1) { $iPWqty = 1; echo "Set count to ",$iPWqty,"<br>\n"; }
			if($iPWqty > $iMaxPwdQty) { $iPWqty = $iMaxPwdQty; echo "Set count to ",$iPWqty,"<br>\n"; }
			$iPWlen = $_POST['PWlen'];
			if($iPWlen < $iMinPwdSize) { $iPWlen = $iMinPwdSize; echo "Set length to ",$iPWlen,"<br>\n"; }
			if($iPWlen > $iMaxPwdSize) { $iPWlen = $iMaxPwdSize; echo "Set length to ",$iPWlen,"<br>\n"; }

			//echo "PWuseNumbers=",$_POST[PWuseNumbers],"<br>\n";

			if((isset($_POST['PWuseNumbers'])) && ($_POST['PWuseNumbers'] == "on")) $iUnums = 1;
			else $iUnums = 0;
			if((isset($_POST['PWuseUppers'])) && ($_POST['PWuseUppers'] == "on")) $iUuppers = 1;
			else $iUuppers = 0;
			if((isset($_POST['PWuseLowers'])) && ($_POST['PWuseLowers'] == "on")) $iUlowers = 1;
			else $iUlowers = 0;
			if($_POST['PWnonAlphNum'] == "on") $iUnoANs = 1;
			else $iUnoANs = 0;
			// $iUnoANs = 0;

			if(($iUnums < 1) && ($iUuppers < 1) && ($iUlowers < 1) && ($iUnoANs < 1)) {
				echo "No symbols set, setting numbers and lowercase to on.<br>\n";
				$iUnums = 1;
				$iUuppers = 1;
				$iUlowers = 1;
				$iUnoANs = 0;
				} // if

			// generate and display passwords
			echo <<< EOTXT1

Shortcuts;-
&nbsp;&nbsp;&nbsp;&nbsp;<a href="#SetPasswordParams">Set New Password Perameters</a>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="#GenHashCodes">Hash Codes Generator</a>

<h3>Generated Password/s</h3>

<table>
	<tr>
		<td>#</td>
		<td><b><u>Password</u></b></td>
		<td><u>MD5 hash code</u></td>
		<td><u>SHA256 hash code</u></td>
	</tr>

EOTXT1;

	$iIterations = 0;
	for ( $iCnt = 0; $iCnt < $iPWqty; $iCnt++ ) {
					$iLen = 0;
					$sPwdHash = "";
					$sPwd = "";
					while ( $iLen < $iPWlen ) {
						$iIterations++;
						$iChr = (int) rand(33,126);
						if(($iUnums < 1) && ($iChr >= 48) && ($iChr <= 57)) continue;
						if(($iUuppers < 1) && ($iChr >= 65) && ($iChr <= 90)) continue;
						if(($iUlowers < 1) && ($iChr >= 97) && ($iChr <= 122)) continue;
						if($iUnoANs < 1) {
							if($iChr < 48) continue;
							if(($iChr > 57) && ($iChr < 65)) continue;
							if(($iChr > 90) && ($iChr < 97)) continue;
							if($iChr > 122) continue;
							} // if
						else {	// just remove the obvious no goes
							if($iChr < 32) continue;
							if($iChr >= 128) continue;
							if(preg_match('/[\\\'\’\"]/',$iChr)) continue;
							} // else

						if(preg_match('/[' . preg_quote('(){}[]|`¬¦!"£$%^&*"<>:;#~_-+=,@') . '/',chr($iChr))) continue;
						$sPwd .= htmlentities( chr ( $iChr ));
						$sPwdHash .= chr ( $iChr );	// for hashing
						$iLen++;
						} // while
					// make one of each class
					if((($iUnums > 0) && (!preg_match('/[0-9]/',$sPwd))) ||
						(($iUuppers > 0) && (!preg_match('/[A-Z]/',$sPwd))) ||
						(($iUlowers > 0) && (!preg_match('/[a-z]/',$sPwd))) ||
						(($iUnoANs > 0) && (!preg_match('/[^0-9a-z]/i',$sPwd)))) {
						$iCnt--;
						continue;
						} // if

					echo "<tr><td>",($iCnt + 1),"</td><td><b>",$sPwd,"</b></td><td>",hash('md5',$sPwdHash),"</td><td>",hash('sha256',$sPwdHash),"</td></tr>\n";
					} // for

			echo "</table>";
			echo "<font size=1>Done in ",$iIterations," iterations.</font><br>\n";
			} // if
		else { // first run
			$iPWqty = 10;
			$iPWlen = 8;
			$iUnums = 1;
			$iUuppers = 1;
			$iUlowers = 1;
			$iUnoANs = 0;
			} // else

	?>

	<h2><a name="SetPasswordParams">Set Password Perameters</a></h2>
	<?php echo "<form action=\"",$_SERVER['PHP_SELF'], "\" method=\"POST\">"; ?><br>
		Symbols: <input type="checkbox" name="PWuseNumbers" value="on" <?php if($iUnums > 0) echo "checked=\"checked\""; ?> />numbers
		, <input type="checkbox" name="PWuseUppers" value="on" <?php if($iUuppers > 0) echo "checked=\"checked\""; ?> />uppercase
		, <input type="checkbox" name="PWuseLowers" value="on" <?php if($iUlowers > 0) echo "checked=\"checked\""; ?> />lowercase
		, <input type="checkbox" name="PWnonAlphNum" value="on" <?php if($iUnoANs > 0) echo "checked=\"checked\""; ?> />non-alphanumeric (punctuation)
		<br>
		Length of passwords <input type="text" name="PWlen" size="3" value="<?php echo $iPWlen; ?>" align=right> <?php echo "(min' ",$iMinPwdSize,", max' ",$iMaxPwdSize,")."; ?><br>
		Number of passwords <input type="text" name="PWqty" size="3" value="<?php echo $iPWqty; ?>" align=right> <?php echo "(max' ",$iMaxPwdQty,")."; ?><br>
		<br>
		<input type="hidden" name="op" value="gen">
		<input type="submit" name="BWgenPW" value="Generate Password/s">
	</form><br>

	<h2><a name="GenHashCodes">Hash Codes Generator</a></h2>
	<?php
		$iMaxCode2HashLen = 250;

		// check hash post
		$sHpwd = "";
		$scHpwd = "";
		if((isset($_POST['BWhashPW'])) && ($_POST['oph'] == "hash")) {
			$sHpwd = $_POST['PW2hash'];
			$scHpwd = $_POST['cPW2hash'];
			if((strlen($sHpwd)) && (strlen($scHpwd))) {
				if($sHpwd == $scHpwd) {
					echo "<p>Hash codes are;-</p>" . PHP_EOL;
					echo '<p style="text-indent: 50px;">MD5=' . hash('md5',$sHpwd) . '</p>' . PHP_EOL;
					echo '<p style="text-indent: 50px;">SHA1=' . hash('sha1',$sHpwd) . '</p>' . PHP_EOL;
					echo '<p style="text-indent: 50px;">SHA256=' . hash('sha256',$sHpwd) . '</p>' . PHP_EOL;
					echo '<p style="text-indent: 50px;">SHA384=' . hash('sha384',$sHpwd) . '</p>' . PHP_EOL;
					echo '<p style="text-indent: 50px;">SHA512=' . hash('sha512',$sHpwd) . '</p>' . PHP_EOL;
					} // if
				else echo "<p>Entries for hash codes were not the same !</p>";
				} // if
			else echo "<p>Missing entry for hash codes !</p>";
			} // if
	?>

	<script>
		function pwdToggle() {
			var p = document.getElementById("id_pwd");
			var c = document.getElementById("id_cfm");
			if (p.type === "password") {
				p.type = "text";
				c.type = "text";
				} // if
			else {
				p.type = "password";
				c.type = "password";
				} // else
			} // pwdToggle()
	</script>


	<?php echo "<form action=\"",$_SERVER['PHP_SELF'], "\" method=\"POST\">"; ?>
		Generate hash codes for
		<input id="id_pwd" type="password" name="PW2hash" size="20" maxlength="250" value="<?php echo $sHpwd; ?>" align=left>,
		confirm
		<input id="id_cfm" type="password" name="cPW2hash" size="20" maxlength="250" value="<?php echo $scHpwd; ?>" align=left>
		<input type="checkbox" onclick="pwdToggle();">Show Password
		<br>
		<input type="hidden" name="oph" value="hash">
		<input type="submit" name="BWhashPW" value="Show Hash Codes">
		<font size=1>Maximum <?php echo $iMaxCode2HashLen; ?> symbols.<br>
		<u>Note:</u> Hash codes provide an encrypted signature ('fingerprint') of an original text.<br>
		&nbsp;&nbsp;&nbsp;&nbsp;The original text cannot be read back from the hash code, but can be used to check text validity, without knowing or saving the orignal text.</font>
	</form>
	<br>

	<p>
		Tool for AppsCMS. <small>(<?php echo PG_VERSION; ?>)</small>
	</p>
<?php if($____in_iframe) {	?>
</body>
</html>
<?php	} // if ?>

