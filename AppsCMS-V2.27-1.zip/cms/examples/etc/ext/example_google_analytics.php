<?php // $Id: example_google_analytics.php 1914 2020-11-11 11:00:16Z robert0609 $ 
	// typical Google analytics include file
	// the Google analytics site provides "google_tracker_id" for this web site from its Google analytics account
?>
        <!--start from Google Analytics for <?php echo CMS_C_CO_NAME . '(' . CMS_C_TITLE . ')'; ?> -->
		<script type="text/javascript">
			var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
			document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
		</script>
		<script type="text/javascript">
			try {
				var pageTracker = _gat._getTracker("google_tracker_id");
				pageTracker._trackPageview();
				} catch(err) {}
		</script>
		<!--end from Google Analytics for <?php echo CMS_C_CO_NAME . '(' . CMS_C_TITLE . ')'; ?> -->
