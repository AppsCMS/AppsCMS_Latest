<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_apps_css.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/*
	Example of /apps/include/apps_css.php
	Works similar to <?php echo CMS_FS_INCLUDES_DIR; ?> cms_main_styles.css.php

	example of general local application stylesheet generation for apps theme settings
	to maintain commonality and theme presentation.
	Refer to manual for more information.

 	Document   : apps.css
    Description:
        Purpose of the stylesheet follows.
		Apps styles for apps.
		<?php echo $gen_note; // set the save function ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/
?>

/* for app2 */
	p.app2 {
		background-color: <?php echo APP_APP2_PARA_BKGD_COLOUR; ?>;
		color: <?php echo $theme['ThemeSettings']['FONT_COLOUR']; ?>;
		/* APP_APP2_PARA_BKGD_COLOUR is defined from 'APP_' by AppsCMS and 'APP2_PARA_BKGD_COLOUR' from apps.ini */
		}

/* login page */
	div.login_extra {
		background-color: <?php echo APP_LOGIN_BKGD_COLOUR; ?>;
		position: relative;
		width: 320px;
		margin: 0 auto;
		padding: 5px;
		}

