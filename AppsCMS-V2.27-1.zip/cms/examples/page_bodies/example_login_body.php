<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_login_body.php 1961 2021-01-25 10:09:54Z robert0609 $
 */
?>

		<div class="login_extra">
			<h1>Login</h1>
<?php
		// require(CMS_FS_OPS_DIR . 'cms_login_local_form.php');
		Ccms::$action = false;
		$text = Ccms_auth::get_signin_signout('',false);
		echo $text;
?>
		</div>

