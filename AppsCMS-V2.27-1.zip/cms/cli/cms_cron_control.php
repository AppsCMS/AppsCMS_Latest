<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_cron_control.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('CRON_MODE',		true);	// tell configure

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

require_once CMS_FS_INCLUDES_DIR . 'cms_auto_class_loader.php';
$cCRON = new Ccms_cron_control($argv,$argc);
exit(0);

// eof
