<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_DB_create.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

define('CLI_MODE',		true);	// tell
define('INI_DB_DIE_ON_ERRORS_BOOL', false);

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$admin_user = (isset($argv[0]) ? $argv[1]:'');
$admin_passwd = (isset($argv[2]) ? $argv[2]:'');
$db_host = Ccms::get_cms_ini_value('DB_MYSQL_HOST_URL','DataBaseAccess');
$db_name = Ccms::get_cms_ini_value('DB_MYSQL_DATABASE','DataBaseAccess');

$box_backtitle = 'Admin for AppsCMS DB host: "' . $db_host . '".';	// show at the top of the screen

echo "Checking/installing book keeper DB on host: " . $db_host . PHP_EOL;

if((empty($admin_user)) || (empty($admin_passwd))) {
	$vals = Ccms_cli_dialogs_plugin::box_username_password('Enter credentials', $box_backtitle);
	$admin_user = $vals['USERNAME'];
	$admin_passwd = $vals['PASSWORD'];
	} // if

$cDBcms = new Ccms_MySQL(true,$admin_user,$admin_passwd);

exit(0);	// done

// eof
