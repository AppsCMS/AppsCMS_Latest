<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * Engage system installed tinyMCE WYSIWYG
 * from example in "https://quilljs.com/docs/"
 * SVN Build: $Id: quill_init.php 2032 2021-04-05 08:12:00Z robert0609 $
 */
?>

<!-- highlight JS -->
<link rel="stylesheet" href="<?php echo CMS_WS_LIB_DIR; ?>quill/highlight-default.min.css">
<script src="<?php echo CMS_WS_LIB_DIR; ?>quill/highlight.min.js"></script>

<!-- Katex included JS -->
<script type="text/javascript" src="<?php echo CMS_WS_LIB_DIR; ?>quill/katex.min.js"></script>

<!-- Main Quill library -->
<script type="text/javascript" src="<?php echo CMS_WS_LIB_DIR; ?>quill/quill-1.3.6/quill.js"></script>
<!--<script type="text/javascript" src="<?php echo CMS_WS_LIB_DIR; ?>quill/quill-1.3.6/quill.min.js"></script>-->

<!-- Theme included stylesheets -->
<link href="<?php echo CMS_WS_LIB_DIR; ?>quill/quill-1.3.6/quill.snow.css" rel="stylesheet">
<link href="<?php echo CMS_WS_LIB_DIR; ?>quill/quill-1.3.6/quill.bubble.css" rel="stylesheet">

<!-- Core build with no theme, formatting, non-essential modules -->
<!--<link href="<?php echo CMS_WS_LIB_DIR; ?>quill/quill-1.3.6/quill.core.css" rel="stylesheet">-->
<!--<script type="text/javascript" src="<?php echo CMS_WS_LIB_DIR; ?>quill/quill-1.3.6/quill.core.js"></script>-->

