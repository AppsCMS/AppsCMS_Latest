<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_phpinfo.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

phpinfo();
?>
