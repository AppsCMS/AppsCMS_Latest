/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_DB_edit.js 1961 2021-01-25 10:09:54Z robert0609 $
 */

var cmsDBops = new function Ccms_DB_ops() {

	var self = this;

	// externally set
	var ext = {
		action_uri: false,
		ajax_uri: false,
		ajax_DB_column_uri: false,
		form_name: false,
		DB_table: false,
		};

	// internal
	var id_last_upd = false;
	var row_DB_id_upd = false;
	var last_send_DB_col_filters_call = null;	// speed limiter
	var last_send_DB_form_call = null;	// speed limiter
	var last_get_DB_select_options_call = null;	// speed limiter
	var table_id = 'id_table_id_db_table_heading_form';
	var deb_ms = 1000;	// debounce delay
	var id_search = '__NO_IDX__';

	this.set_ext_values = function (ext_opts) {
		ext = ext_opts;
		} // // set_ext_values()

	this.send_DB_col_filters = function (obj) {
		if(ext['action_uri'].length < 4) {	// bad
			if(obj.form)
				obj.form.submit();
			else
				console.log('Missing ext[action_uri].');
			return;
			} // if
		if(ext['DB_table'].length < 4) {	// bad
			if(obj.form)
				obj.form.submit();
			else
				console.log('Missing ext[DB_table].');
			return;
			} // if
		if(last_send_DB_col_filters_call != null) {	// clear it
			window.clearTimeout(last_send_DB_col_filters_call);
			last_send_DB_col_filters_call = null;
			} // if
		// restart if
		last_send_DB_col_filters_call = window.setTimeout(
			function (obj) {
				if(obj.form)
					obj.form.submit();
				// else no form, do it the hard way
				if(obj.tagName == 'INPUT') {
					var value = obj.value;
					if(value.length < 4) return;	// more please
					var name = obj.name;
					var table = ext['DB_table'];
					var action_uri = ext['action_uri'];
					var url = action_uri + '&table=' + table + '&' + name + '=' + escape(value);
					window.location.href = url;
					} // if
				}, deb_ms, obj);
		} // send_DB_col_filters()

//	this.upd_DB_ids = function (upd_row,last_upd_elem_val) {
//		var row2upd = upd_row.innerHTML;
//		var row_upd = row2upd.replace(/__NO_IDX__/g,last_upd_elem_val);
//		upd_row.innerHTML = row_upd;
//		// and the last bits
//		var row_id = upd_row.id;
//		if(row_id)
//			upd_row.id = row_id.replace(/__NO_IDX__/g,last_upd_elem_val);
//		console.log(upd_row);
//		} // upd_DB_ids()

	this.add_DB_table_tr_row = function () {
		location.href = ext['action_uri'];	// @TODO finish AJAX row/form insert
//		if(!row_DB_id_upd.includes('__NO_IDX__')) return;
//		// new
//		var last_upd_elem = document.getElementById(id_last_upd);
//		var last_upd_elem_val = last_upd_elem.innerHTML;	// a label element
//		var table = document.getElementById(table_id);
//
//		var upd_row = table.rows[1];
//		self.upd_DB_ids(upd_row,last_upd_elem_val);
//
//		if(typeof cms_DB_new_table_tr === 'undefined') return false;	// row template not present
//		if(!table) return false;
//		var tr_data = decodeURIComponent(cms_DB_new_table_tr);
//
//		var row = table.insertRow(1);
//		row.innerHTML = tr_data
//		// console.log(tr_data);
//		// eval(tr_data);
//		return true;
		} // add_DB_table_tr_row()

	this.send_DB_form = function(obj) {
		if(ext['ajax_uri'].length < 4) {	// bad ajax
			obj.form.submit();
			return;
			} // if
		if(last_send_DB_form_call != null) {	// clear it
			window.clearTimeout(last_send_DB_form_call);
			last_send_DB_form_call = null;
			} // if
		// restart if
		last_send_DB_form_call = window.setTimeout(self.send_DB_form_delayed, deb_ms, obj);
		} // send_DB_form()

	this.send_DB_form_delayed = function (obj) {
		var form_els = obj.form.elements;
		if(!form_els) return;	// ????
		var val = false;
		var valid = true;
		var columns= {};
		var filters = {};
		var data = {};
		row_DB_id_upd = '';
		for(var i = 0; i < form_els.length; i++) {
			var elem = form_els[i];
			var name = elem.name;
			if(name == 'row_id') {
				row_DB_id_upd = elem.value;
				id_last_upd = 'id_db_table_row_id_cell[' +  row_DB_id_upd + ']';
				} // if
			if(elem.tagName == 'SELECT') {
				var selected_opt = elem.selectedIndex;
				var selected_val = elem.options[selected_opt].value;
				if(selected_val == 'show_all') {
					var id = elem.id;
					return self.get_DB_select_options_delayed(id,name,elem);
					} // if
				} // if
			var required = elem.required;
			if(!elem.checkValidity()) {
				elem.style.borderColor = "red";
				elem.classList.add('blink_red_twice');
				valid = false;
				continue;
				} // if
			elem.style.borderColor = "white";
			switch(elem.type) {
			case 'checkbox':
			case 'radio':
				val = (elem.checked ? 'on':'off');
				break;
			default:
				val = elem.value;
				if(required) {
					if((!(!!val)) || (val.length <= 0)) {
						valid = false;
						elem.style.borderColor = "red";
						continue;
						} // if
					elem.style.borderColor = "white";
					} // if
				break;
				} // switch
			// sort out what goes
			if(name.search(/^columns\./) != -1) {
				columns[(name.replace('columns.',''))] = val;
				} // if
			else if(name.search(/^filter\./) != -1) {
				filters[(name.replace('filter.',''))] = val;
				} // if
			else data[name] = val;
			} // for
		data['columns'] = columns;
		data['filters'] = filters;
		if(!valid) return false;
		var post = ext['form_name'] + '=' + encodeURI(JSON.stringify(data));

		if(!cms_ajaxOps[(ext['form_name'])]) {
			// Ccms_ajaxOps(ajax_feedback_id, ajax_result_id, op_data, run_scripts, feedback_txt)
			cms_ajaxOps[(ext['form_name'])] = new Ccms_ajaxOps('','','',true,'');	// no returned data/text
			} // if

		// doAjaxRequest = function (ajax_url_op, op_data, do_result_id,do_func)
		return cms_ajaxOps[(ext['form_name'])].doAjaxRequest(ext['ajax_uri'],post,id_last_upd,cmsDBops.add_DB_table_tr_row);
		} // send_DB_form_delayed()

	this.save_DB_form = function(obj) {
		if(ext['ajax_uri'].length < 4) {	// bad ajax
			obj.form.submit();
			return;
			} // if
		if(last_send_DB_form_call != null) {	// clear it
			window.clearTimeout(last_send_DB_form_call);
			last_send_DB_form_call = null;
			} // if
		// restart if
		last_send_DB_form_call = window.setTimeout(self.save_DB_form_delayed, (deb_ms / 2), obj);
		} // save_DB_form()

	this.save_DB_form_delayed = function (obj) {	// save button clicked
		var form_els = obj.form.elements;
		if(!form_els) return;	// ????
		var val = false;
		var valid = true;
		var columns= {};
		var filters = {};
		var data = {};
		row_DB_id_upd = '';
		var submit_button = false;
		for(var i = 0; i < form_els.length; i++) {
			var elem = form_els[i];
			var name = elem.name;
			var type = elem.type;
			// check being edited, save and delete have same position
			if((name == 'submit') && (elem.value == 'save')) {
				elem.disabled = false;
				elem.style.display = 'block';
				submit_button = elem;
				} // if
			if(name == 'delete') {
				elem.disabled = true;
				elem.style.display = 'none';
				} // if
			if(name == 'row_id') {
				row_DB_id_upd = elem.value;
				id_last_upd = 'id_db_table_row_id_cell[' +  row_DB_id_upd + ']';
				} // if
			if(elem.tagName == 'SELECT') {
				var selected_opt = elem.selectedIndex;
				var selected_val = elem.options[selected_opt].value;
				if(selected_val == 'show_all') {
					var id = elem.id;
					return self.get_DB_select_options_delayed(id,name,elem);
					} // if
				} // if
			var required = elem.required;
			if(!elem.checkValidity()) {
				elem.style.borderColor = "red";
				elem.classList.add('blink_red_twice');
				valid = false;
				// continue;
				} // if
			elem.style.borderColor = "white";
			switch(elem.type) {
			case 'password':
				if(elem.value.length <= 0) {
					elem.required = false;	// do it better
					continue;	// if empty don't send
					} // if
				var pattern = elem.pattern;
				if((pattern) && (pattern.length > 0)) {
					elem.required = true;	// do it better
					var pat = new RegExp(pattern);
					if((!elem.checkValidity()) || (!pat.test(elem.value))) {
						elem.style.borderColor = "red";
						elem.classList.add('blink_red_twice');
						valid = false;
						} // if
					} // if
				break;
			case 'checkbox':
			case 'radio':
				val = (elem.checked ? 'on':'off');
				break;
			default:
				val = elem.value;
				if(required) {
					if((!(!!val)) || (val.length <= 0)) {
						valid = false;
						elem.style.borderColor = "red";
						continue;
						} // if
					elem.style.borderColor = "white";
					} // if
				break;
				} // switch
			} // for
		if(!valid) {
			if(submit_button) submit_button.disabled = true;
			return false;
			} // if
		if(submit_button) submit_button.disabled = false;
		return true;
		} // save_DB_form_delayed()

	this.delete_DB_row = function (row_id,table,obj) {
		if(!table) table = ext['DB_table'];
		if(!confirm('Delete row ' + row_id + ' from ' + table + ' ?')) return false;
		var url = ext['action_uri'] + '&table=' + table + '&delete_row=' + row_id;
		window.location.href = url;
		} // delete_DB_row()

	this.get_DB_select_options = function (id,table,column_name,obj) {
		if(last_get_DB_select_options_call != null) {	// clear it
			window.clearTimeout(last_get_DB_select_options_call);
			last_get_DB_select_options_call = null;
			} // if
		if((obj.value.length > 0) &&	// onchange maybe 0 length after previous filter
			(obj.value.length < 3)) return;
		// restart if
		last_get_DB_select_options_call = window.setTimeout(
			self.get_DB_select_options_delayed,deb_ms,id,table,column_name,obj);
		} // get_DB_select_options()

	this.get_DB_select_options_delayed = function (id,table,column_name,obj) {
		Ccms_cursor.setWait();
		var sel = document.getElementById(id);
		var selVal = sel.options[sel.selectedIndex].value;
		var keywords = obj.value;
		var uri = ext['ajax_DB_column_uri'] + '&select_DB_options=' + ext['DB_table'] + '&table=' + table + '&column_name=' + encodeURI(column_name);
		if(selVal) uri = uri + '&selected=' + selVal;
		else uri = uri + '&filters=' + encodeURI(keywords);
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", uri, true);
		xhttp.onreadystatechange = function() {
			if (xhttp.readyState != 4)
				return;
			if (xhttp.status == 200) {
				self.replace_DB_select_options(id,this.responseText);
				Ccms_cursor.restore();
				} // if
			};
		xhttp.send();
		return true;
		} // get_DB_select_options_delayed()

	this.replace_DB_select_options = function (id,responseText) {
		var sel = document.getElementById(id);
		var rows = false;
		try {
			rows = JSON.parse(responseText);
			}
		catch (e) {
			console.log("JSON.parse failed: ",responseText);
			return;
			}
		var selectedIndex = sel.selectedIndex;
		var last_id = ((selectedIndex && sel.options[selectedIndex]) ? sel.options[selectedIndex].value:'');

		// replace the options
		while(sel.options.length > 0)  sel.remove(0);

		// populate with new options
		for(var i = 0; i < rows.length; i++) {
			var vals = rows[i];
			var opt = new Option(vals['name'],vals['id']);
			sel.options.add(opt);
			if(vals['params']) {
				var params = vals['params'];
				if(params.includes('disabled')) opt.disabled = true;
				if(params.includes('selected')) opt.selected = true;
				} // if
			else if(last_id == vals['id']) opt.selected = true;
			} // for
		var event = new MouseEvent('click');
		sel.dispatchEvent(event);
		} // replace_DB_select_options()

	// tr_dbl_click() is a double click hook function engaged by a
	// double click on a data table row <tr>
	// to a customised engagement function supplied by app code
	// engage_DB_app_extend(table,row_id) is the app provided function
	// can be used to engage an editor dialog box, etc.
	this.tr_dbl_click = function (table,row_id,obj) {

		if(!/^\d+$/.test(row_id)) return null;
		if(typeof engage_DB_app_extend === 'function') {
			return engage_DB_app_extend(table,row_id,obj);
			} // if
		if(typeof ajax_load_cmsDBeditDlg === 'function') {	// the built in function
			return ajax_load_cmsDBeditDlg(table,row_id,obj);
			} // if
		return null;
		} // tr_dbl_click()

	this.new_edit_click = function (table,row_id,obj) {	// onclick

		if(!row_id) return null;
		if(typeof engage_DB_app_extend === 'function') {
			return engage_DB_app_extend(table,row_id,obj);
			} // if
		if(typeof ajax_load_cmsDBeditDlg === 'function') {	// the built in function
			return ajax_load_cmsDBeditDlg(table,row_id,obj);
			} // if
		return null;
		} // new_edit_click()

} // Ccms_DB_ops


// EOF

