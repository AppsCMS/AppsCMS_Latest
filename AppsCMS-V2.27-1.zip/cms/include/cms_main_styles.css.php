/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_main_styles.css.php 2007 2021-03-02 06:41:43Z robert0609 $
 */

/*
	Document   : main_styles
	Description:
		Purpose of the stylesheet follows.
		Main styles styles for common styles.
		<?php echo $gen_note; ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

@media print {
		#cms_left_column,
		#cms_right_column,
		#cms_navbar_nolc,
		#cms_navbar_wlc,
		#cms_navbar_wlrc,
		cms_msg_alert,
		cms_hover_block_outer,
		cms_hover_block_inner,
		cms_sub_hover_block_outer,
		cms_sub_hover_block_inner,
		cms_title_tooltip,
		cms_nav_bar,
		cms_nav_bar_on,
		cms_JS_dialog,
		social_media,
		option:not(:checked),
		no_print {
			display: none !important;
			visibility: hidden;
		}
	pointer-events: none;
	}

@media print {

<?php if(!INI_PRINT_HEADER_FOOTER_BOOL) { ?>

	#cms_header { display:none; }
	#cms_footer { display:none; }
	#cms_left_column { display:none; }
	#cms_right_column { display:none; }

<?php	} // if ?>

	#id_cms_goto_Top_box {
		visibility: hidden;
		display:none;
		}
	}


@media screen {

	}

<?php

	// adjust logo height so it fits header (? + nav bar)
	$hh = (int)preg_replace('/[a-z]*$/i', '',  $theme['ThemeSettings']['HEADER_HEIGHT']);
	$pad = 5;
	$mh = $hh + $pad;
	if($cms_nav_bar)
		$mh += (int)preg_replace('/[a-z]*$/i', '', $theme['ThemeSettings']['NAV_BAR_HEIGHT']);

//	if(($cms_nav_bar) && (($cms_nav_bar_beside_logo) || ($cms_nav_bar_right))) {
//		$hh += (int)preg_replace('/[a-z]*$/i', '', $theme['ThemeSettings']['NAV_BAR_HEIGHT']);
//		} // if
	$lh = (int)preg_replace('/[a-z]*$/i', '',  $theme['ThemeSettings']['LOGO_HEIGHT']);
	if((($hh - $pad - $pad) > 0) && ($lh > ($hh - $pad - $pad))) {
		$lh = $hh - $pad - $pad;
		Ccms::pushMsg('Logo height reduced to ' . $lh . 'px to fit into header.','warning');
		} // if
	else if(($hh - $pad - $pad) <= 0) {
		$lh = 0;
		Ccms::pushMsg('Logo height too large to fit into header.','error');
		} // else if
	// else ok

if(!function_exists('echo_body_copy_css')) {	// sometimes run twice if installing or errors found
	function echo_body_copy_css($theme,$allow = true) {
		if(($allow) && ($theme['ThemeSettings']['PAGE_BODY_COPY_BOOL'] == 'true')) {
echo <<<EOTA

		-webkit-user-select: text; /* Chrome, Opera, Safari */
		-moz-user-select: text; /* Firefox 2+ */
		-ms-user-select: text; /* IE 10+ */
		user-select: text; /* Standard syntax */

EOTA;
		} // if
	else {
	echo <<<EOTB

		-webkit-user-select: none; /* Chrome, Opera, Safari */
		-moz-user-select: none; /* Firefox 2+ */
		-ms-user-select: none; /* IE 10+ */
		user-select: none; /* Standard syntax */

EOTB;
		} // else
	} // echo_body_copy_css()
} // if

?>

/* preloaded background images */
#preloaded::after {
	content: <?php
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_IMAGES_DIR,CMS_C_LOGO_IMAGE);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['BODY_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['HEADER_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_HOVER_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['FOOTER_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['SM_BKGD_IMAGE']);
if(is_readable(DOCROOT_FS_BASE_DIR . '/favicon.ico')) {
	echo ' url("favicon.ico")';
	} // if
else if(is_readable(DOCROOT_FS_BASE_DIR . '/favicon.png')) {
	echo ' url("favicon.png")';
	} // if
if(is_readable(DOCROOT_FS_BASE_DIR . '/cms/images/icons/eye_open.png')) {
	echo ' url("cms/images/icons/eye_open.png")';
	} // if
if(is_readable(DOCROOT_FS_BASE_DIR . '/cms/images/icons/eye_closed.png')) {
	echo ' url("cms/images/icons/eye_closed.png")';
	} // if
?>;
	display: none;
	}

/* standard stuff */
@media print {
	.no-print {
		display: none !important;
		}
	}

[draggable=true] {
	cursor: move;
	}

.resizable {
	overflow: scroll;
	resize: both;
	max-width: 300px;
	max-height: 460px;
}

div.cms_sticky_left,
td.cms_sticky_left {
	position: -webkit-sticky;
	position: sticky;
	background-color: <?php echo $theme['ThemeSettings']['BODY_BKGD_COLOUR']; ?>;
	top: 5px;
/*	left: 20px; */
	width: auto;
/*	padding: 5px;*/
	margin: 5px 5px 0px 5px;
	float: left;
	}

div.cms_sticky_top {
	position: -webkit-sticky;
	position: sticky;
	background-color: <?php echo $theme['ThemeSettings']['BODY_BKGD_COLOUR']; ?>;
	top: 5px;
	width: auto;
	margin: 5px 5px 0px 5px;
/*	margin: 5px;*/
	text-align: center;
	}

div.cms_sticky_right {
	position: -webkit-sticky;
	position: sticky;
/*	background-color: <?php echo $theme['ThemeSettings']['BODY_BKGD_COLOUR']; ?>;*/
/*	top: 5px;*/
	right: 10px;
	width: auto;
/*	padding: 5px;*/
	margin: 5px 5px 0px 5px;
	float: right;
	}

div.cms_sticky_bottom {
	position: -webkit-sticky;
	position: sticky;
	background-color: <?php echo $theme['ThemeSettings']['BODY_BKGD_COLOUR']; ?>;
	bottom: 5px;
	width: auto;
	padding: 5px;
	margin: 5px 5px 0px 5px;
	text-align: center;
	}

table, tbody, tr, th, td {
	border-spacing: 0; /* new footer looks terrible without this */
	}

/* *** Stretch vertically if necessary in order to get footer at bottom of screen */
html, body {
	height: 100% !important;
	}

tr.cms_main_body {
	height: 100% !important;
	vertical-align: top;
	}
/* *** */

body {
<?php if(!empty($theme['ThemeSettings']['BODY_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['BODY_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-size: cover;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['BODY_BKGD_COLOUR']; ?>;
<?php } // else ?>
	font-family:	<?php echo $theme['ThemeSettings']['FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['FONT_WEIGHT']; ?>;
	color:			<?php echo $theme['ThemeSettings']['FONT_COLOUR']; ?>;
	margin:		0px;
	padding:	0px;
	}

body.cms_waiting * {
	cursor: wait;
	}

fieldset {
	border: 0;
	margin: 0;
	padding: 0;
	}

div {
	}

caption {	/* make captions invisible to seeing, but useful to sight impaired */
	height: 0px;
	width: 0px;
	visibility: hidden;
	}

iframe {
	}

iframe.tools {
	background-color:	<?php echo $theme['ThemeSettings']['TOOLS_FRM_BKGD_COLOUR']; ?>;
	color:			<?php echo $theme['ThemeSettings']['TOOLS_FRM_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['TOOLS_FRM_FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['TOOLS_FRM_FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['TOOLS_FRM_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['TOOLS_FRM_FONT_WEIGHT']; ?>;
	}

font {
	font-family:	<?php echo $theme['ThemeSettings']['FONT_FAMILY']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['FONT_SIZE']; ?>;
	color:			<?php echo $theme['ThemeSettings']['FONT_COLOUR']; ?>;
	}

form {
	display: inline;
	}

input[type='file'] {
	border:		<?php echo $theme['ThemeSettings']['PAGE_BODY_BORDER']; ?>;
	border-radius: 0.5em;
	padding: 5px 8px;
	outline: none;
	}

input.page_body, button.page_body, select.page_body, option.page_body, textarea.page_body {
	background-color: <?php echo $theme['ThemeSettings']['BODY_BKGD_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['FONT_FAMILY']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['FONT_STYLE']; ?>;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['FONT_SIZE']; ?>;
	color:			<?php echo $theme['ThemeSettings']['FONT_COLOUR']; ?>;
	padding:		0px;
	}

input, button, select, textarea {
	background-color: white;
	font-family:	Verdana, Geneva, sans-serif;
	font-style:		normal;
	font-weight:	normal;
	font-size:		12px;
	color:			black;
	}

input.std, button.std, select.std, textarea.std {
	padding: 1px 2px;
	display: inline-block;
	max-width: 98%;
	width: unset;
	}

button {
	box-shadow: 2px 2px grey;
	}

button:active {
	box-shadow: 0px 0px grey;
	}

input:disabled, button:disabled, select:disabled, textarea:disabled, option:disabled {
	background-color: lightgrey;
	color:			grey;
	}

<?php if($theme['ThemeSettings']['INPUT_NUMBER_SPINNERS_BOOL'] != 'true') { ?>

/* fix the ugly input number spinners */
/* Standard */
input[type=number] {
	appearance: textfield;
	}

/* Firefox */
input[type=number] {
	-moz-appearance: textfield;
	}

/* Chrome */
input::-webkit-inner-spin-button,
input::-webkit-outer-spin-button {
	-webkit-appearance: none;
	margin:0;
	}

<?php	} // if ?>

<?php if(($theme['ThemeSettings']['INPUT_NUMBER_SPINNERS_HOVER_BOOL'] == 'true') &&
	($theme['ThemeSettings']['INPUT_NUMBER_SPINNERS_BOOL'] != 'true')) { ?>

/* fix the ugly input number spinners */
/* Standard */
/* Show number picker on focus */
input[type=number]:focus,
input[type=number]:hover {
	appearance: number-input;
	}

/* Firefox */
/* Show number picker on focus */
input[type=number]:focus,
input[type=number]:hover {
	-moz-appearance: number-input;
	}

/* Chrome */
/* Show number picker on focus */
input[type=number]:focus::-webkit-inner-spin-button,
input[type=number]:focus::-webkit-outer-spin-button,
input[type=number]:hover::-webkit-inner-spin-button,
input[type=number]:hover::-webkit-outer-spin-button {
	-webkit-appearance: inner-spin-button;
	margin: 0 2px 0 0 ;
	}

<?php	} // if ?>

<?php if($theme['ThemeSettings']['INPUT_SELECT_ARROW_BOOL'] != 'true') { ?>

/* turn off select arrows */
/* Standard */
select {
	appearance: textfield;
	}

/* Firefox */
select {
	-moz-appearance: textfield;
	}

/* Chrome */
select {
	-webkit-appearance: none;
	margin:0;
	}

<?php	} // if ?>

select {
	text-align: center;
	}

option {
	text-align: left;
	}

a, a:active, a:link, a:visited {
	font-family:	inherit;
	font-size:		inherit;
	color:			inherit;
	text-decoration: none;
	}

a:hover, .href_linked:hover {
	font-family:	inherit;
	color:			<?php echo $theme['ThemeSettings']['ANCHOR_HOVER_COLOUR']; ?>;
	text-decoration: underline;
	cursor:			pointer;
	}

a.href_up {	/* href is on screen */
	font-style: italic;
	font-size: 110%;
/*	font-weight: bold;		*/
	}

p {
	font-family:	<?php echo $theme['ThemeSettings']['FONT_FAMILY']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['FONT_SIZE']; ?>;
	color:			inherit;
	text-align: left;
	text-decoration: none;
	padding-bottom: 8px;
	padding-top:	2px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

h1 {
	display:	inline-block;
	background-color:	<?php echo $theme['ThemeSettings']['H1_BKGD_COLOUR']; ?>;
	color: <?php echo $theme['ThemeSettings']['H1_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['H1_FONT_FAMILY']; ?>;
	font-size: <?php echo $theme['ThemeSettings']['H1_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['H1_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['H1_FONT_WEIGHT']; ?>;
	text-align: left;
	text-decoration: underline;
	padding-top: 10px;
	padding-bottom: 4px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

h2 {
	display:	inline-block;
	background-color:	<?php echo $theme['ThemeSettings']['H2_BKGD_COLOUR']; ?>;
	color: <?php echo $theme['ThemeSettings']['H2_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['H2_FONT_FAMILY']; ?>;
	font-size: <?php echo $theme['ThemeSettings']['H2_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['H2_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['H2_FONT_WEIGHT']; ?>;
	text-align: left;
	text-decoration: underline;
	padding-top: 7px;
	padding-bottom: 2px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

h3 {
	display:	inline-block;
	background-color:	<?php echo $theme['ThemeSettings']['H3_BKGD_COLOUR']; ?>;
	color: <?php echo $theme['ThemeSettings']['H3_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['H3_FONT_FAMILY']; ?>;
	font-size: <?php echo $theme['ThemeSettings']['H3_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['H3_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['H3_FONT_WEIGHT']; ?>;
	text-align: left;
	text-decoration: none;
	padding-top: 5px;
	padding-bottom: 0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

h4 {
	display:	inline-block;
	background-color:	<?php echo $theme['ThemeSettings']['H4_BKGD_COLOUR']; ?>;
	color: <?php echo $theme['ThemeSettings']['H4_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['H4_FONT_FAMILY']; ?>;
	font-size: <?php echo $theme['ThemeSettings']['H4_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['H4_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['H4_FONT_WEIGHT']; ?>;
	text-align: left;
	text-decoration: none;
	padding-top: 3px;
	padding-bottom: 0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

img {
	border-width: 0px;
	padding: 0px;
	margin: 0px;
	text-decoration: none;
	}

img.logo {
	height: <?php echo $lh . 'px'; ?>;
	vertical-align: middle;
	text-decoration: none;
<?php if ($theme['ThemeSettings']['NAV_BAR_BESIDE_LOGO_BOOL'] == 'true') { ?>
	position: absolute;
	top: <?php echo $pad ?>px;
	left: <?php echo 2 * $pad ?>px;
<?php } ?>
	}

img.menu_link_icon {
	border:	none;
	padding: 0px;
	margin: 0px 5px 0px 0px;
	height: <?php echo $theme['ThemeSettings']['MENU_ICON_HEIGHT']; ?>;
	}

img.msg_icon {
	border:	none;
	padding: 0px;
	margin: 0px 5px 0px 0px;
	height: <?php echo $theme['ThemeSettings']['MSG_ICON_HEIGHT']; ?>;
	}

img.msg_icon_small {
	border:	none;
	padding: 0px;
	margin: 0;
	height: 15px;
	}

img.msg_icon_small:hover,
img.msg_icon:hover {	/* stop config msg icon scaling */
	-ms-transform: unset; /* IE 9 */
	-webkit-transform: unset(1.0); /* Safari 3-8 */
	transform: unset;
	transform-origin: unset;
}

img.lm_cog {
	height: 5px;
	opacity: 0.3;
	}

img.lm_cog:hover {
	height: 10px;
	opacity: 1;
	}

lu {
	background-color: inherit;
	font-family:	<?php echo $theme['ThemeSettings']['FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['FONT_WEIGHT']; ?>;
	color:			<?php echo $theme['ThemeSettings']['FONT_COLOUR']; ?>;
	text-align: left;
	text-decoration: none;
	padding-bottom: 0px;
	padding-top:	0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

li {
	background-color: inherit;
	font-family:	<?php echo $theme['ThemeSettings']['FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['FONT_WEIGHT']; ?>;
	color:			<?php echo $theme['ThemeSettings']['FONT_COLOUR']; ?>;
	text-align: left;
	text-decoration: none;
	padding-bottom: 2px;
	padding-top:	0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			5px;
	list-style-type: disc;
	}

table {
	background-color: inherit;
	font-family:	inherit;
	font-style:		inherit;
	font-weight:	inherit;
	font-size:		inherit;
	color:		inherit;
	padding:	0px;
	border-width:		0px;
	margin:		0px;
	width:		100%;
	border-width:	0px;
	border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
<?php echo_body_copy_css($theme); ?>
	-webkit-border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
/*	-moz-border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>; */
	}

th {
	font-family:	<?php echo $theme['ThemeSettings']['TH_FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['TH_FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['TH_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['TH_FONT_WEIGHT']; ?>;
	background-color: inherit;
	color:			inherit;
	text-align:		left;
	vertical-align: top;
	padding-top:	7px;
	margin:			0px;
	border-width:	0px;
	}

tr, td {
	background-color: inherit;
	color:			inherit;	/* show the inherited, try red */
	font-family:	inherit;
	font-weight:	inherit;
	font-size:		inherit;
	padding:		0px;
	margin:			0px;
	border-width:			0px;
	}

table.page_top {
<?php if(!empty($theme['ThemeSettings']['HEADER_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['HEADER_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['HEADER_BKGD_COLOUR']; ?>;
<?php } // else ?>
	font-family:	<?php echo $theme['ThemeSettings']['HEADER_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['HEADER_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['HEADER_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['HEADER_FONT_SIZE']; ?>;
	color:		<?php echo $theme['ThemeSettings']['HEADER_FONT_COLOUR']; ?>;
	padding:	0px;
	border:		<?php echo $theme['ThemeSettings']['HEADER_BORDER']; ?>;
	margin:		0px;
	width:		100%;
	height:		100%;
	}

<?php if ($theme['ThemeSettings']['NAV_BAR_BESIDE_LOGO_BOOL'] == 'true') { ?>
#cms_header {
	height: 10px;
}
<?php } ?>

th.page_top {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	text-align:		left;
	}

tr.page_top, td.page_top, p.page_top {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	}

table.left_container {
	background-color: <?php echo $theme['ThemeSettings']['LEFT_BKGD_COLOUR']; ?>;
	color:		<?php echo $theme['ThemeSettings']['LEFT_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['LEFT_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['LEFT_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['LEFT_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['LEFT_FONT_SIZE']; ?>;
	border:		<?php echo $theme['ThemeSettings']['LEFT_BORDER']; ?>;
	padding:	0px 0px 0px 0px;
	margin:		0px;
	width:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	}

tr.left_container {
	background-color: inherit;
	}

td.left_container, p.left_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px;
	font-family:	inherit;
	}

td.left_container {
	text-align: left;
	vertical-align: top;
	padding: 1px 1px 1px 1px;
	}

table.right_container {
	background-color: <?php echo $theme['ThemeSettings']['RIGHT_BKGD_COLOUR']; ?>;
	color:		<?php echo $theme['ThemeSettings']['RIGHT_FONT_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['RIGHT_BORDER']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['RIGHT_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['RIGHT_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['RIGHT_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['RIGHT_FONT_SIZE']; ?>;
	padding:	0px 0px 0px 0px;
	margin:		0px;
	width:		<?php echo $theme['ThemeSettings']['RIGHT_WIDTH']; ?>;
	}

tr.right_container {
	background-color: inherit;
	}

td.right_container, p.right_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px;
	font-family:	inherit;
	}

td.right_container {
	text-align: left;
	vertical-align: top;
	padding: 1px 1px 1px 1px;
	}

span.cms_scroll2anchor_box {
	background-color: <?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_BKGD_COLOUR']; ?>;
	opacity: 0.6;
	color:		<?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_BORDER']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_SIZE']; ?>;
	position: fixed;
	left: 180px;
	top: 30%;
	margin: 5px;
	padding: 5px;
	border-radius: 0.5em;
<?php echo_body_copy_css($theme,false); ?>
	-webkit-border-radius: 0.5em;
/*	-moz-border-radius: 0.5em; */
	scroll-behavior: smooth;
	z-index: +1000;
	}

span.cms_scroll2anchor_box:hover {
	opacity: 1;
	animation: blinkerTop 0.3s linear infinite;
	color: <?php echo $theme['ThemeSettings']['NAV_BAR_HOVER_BKGD_COLOUR']; ?>;
	}
@keyframes blinkerTop {
	50% { opacity: 0; }
	}

.blink_red_twice {
	animation-name: blink_2red_bkgd;
	animation-duration: 0.8s;
	}
@keyframes blink_2red_bkgd {
	0%	{	background-color: red; }
	32%	{	background-color: red; }
	33%	{	background-color: inherit; }
	65%	{	background-color: inherit; }
	66%	{	background-color: red;	}
	99%	{	background-color: red;	   }
	100%{	background-color: inherit;  }
	}

table.tools_pdb_container {
	background-color: <?php echo $theme['ThemeSettings']['TOOLS_PDB_BKGD_COLOUR']; ?>;
	color:		<?php echo $theme['ThemeSettings']['TOOLS_PDB_FONT_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['TOOLS_PDB_BORDER']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['TOOLS_PDB_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['TOOLS_PDB_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['TOOLS_PDB_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['TOOLS_PDB_FONT_SIZE']; ?>;
	padding:	0px;
	margin:		0px;
	}

tr.tools_pdb_container {
	background-color: inherit;
	}

tr.tools_pdb_container_odd {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['TOOLS_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.tools_pdb_container_even {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['TOOLS_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.tools_pdb_container_odd:hover,
tr.tools_pdb_container_even:hover {
	background-color: <?php echo $theme['ThemeSettings']['TOOLS_PDB_HOVER_BKGD_COLOUR']; ?>;
	}

th.tools_pdb_container {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	padding:		0px 5px;
	text-align:		left;
	white-space:	<?php echo (($theme['ThemeSettings']['TOOLS_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal'); ?>;
	}

td.tools_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	text-align:		right;
	white-space:	<?php echo (($theme['ThemeSettings']['TOOLS_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal'); ?>;
	}

td.tools_pdb_container_selected {
	font-weight:	bold;
	}

td.tools_pdb_container input {
	width: 80%;
	font-size: 		<?php echo $theme['ThemeSettings']['TOOLS_PDB_FONT_SIZE']; ?>;
	}

p.tools_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	}

table.bodies_pdb_container {
	background-color: <?php echo $theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR']; ?>;
	color:		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['BODIES_PDB_BORDER']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_SIZE']; ?>;
	padding:	1px;
	margin:		0px;
	}

tr.bodies_pdb_container {
	background-color: inherit;
	}

tr.bodies_pdb_container_odd {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.bodies_pdb_container_even {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.bodies_pdb_container_odd:hover,
tr.bodies_pdb_container_even:hover {
	background-color: <?php echo $theme['ThemeSettings']['BODIES_PDB_HOVER_BKGD_COLOUR']; ?>;
	}

th.bodies_pdb_container {
	background-color: inherit;
	font-family:	inherit;
	padding:		0px 5px;
	font-weight:	bold;
	text-align:		left;
	white-space:	<?php echo (($theme['ThemeSettings']['BODIES_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal'); ?>;
	}

td.bodies_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	text-align:		right;
	white-space:	<?php echo (($theme['ThemeSettings']['BODIES_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal'); ?>;
	}

td.bodies_pdb_container_selected {
	font-weight:	bold;
	}

td.bodies_pdb_container input {
	width: 80%;
	font-size: 		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_SIZE']; ?>;
	}

p.bodies_pdb_container,
li.bodies_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	}

div.page_container {
	background-color: inherit;
	color:		inherit;
	border-width:		0px;
	font-family:	inherit;
	padding:	0px;
	margin:		0px;
	width:		100%;
/*	height:		100%; */
	}

table.page_body {
<?php if(!empty($theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR']; ?>;
<?php } // else ?>
	border:		<?php echo $theme['ThemeSettings']['PAGE_BODY_BORDER']; ?>;
	color:		<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_FAMILY']; ?>;
	font-size:	<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_WEIGHT']; ?>;
	padding:	0px;
	margin:		0px;
	width:		100%;
	}

tr.page_body {
	background-color: inherit;
	}

tr.page_body_odd {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.page_body_even {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

th.page_body {
	font-family:	<?php echo $theme['ThemeSettings']['TH_FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['TH_FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['TH_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['TH_FONT_WEIGHT']; ?>;
	background-color: inherit;
	text-align:		left;
	padding-top:	7px;
	}

.page_body {	/* used by online html editor */
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE']; ?>;
	padding:		<?php echo $theme['ThemeSettings']['PAGE_BODY_PADDING']; ?>;
<?php echo_body_copy_css($theme); ?>
	}

.page_body_msgs {
	background-color: inherit;
	padding:	0px;
	margin:		0px;
/*	float:		left; */
	}

td.page_body_msgs {
	padding:	5px;
	margin:		3px;
	}

td.page_body, p.page_body, li.page_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE']; ?>;
	padding:		5px;
	}

span.page_body,
a.page_body, a.page_body:active, a.page_body:link, a.page_body:visited {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE']; ?>;
	padding:		5px;
	}

pre {
	font-family: monospace, Courier, "Courier New";
	font-size: 10px;
	font-style: italic;
	overflow-x: hidden;
	}

.page_body_pre,
pre.page_body {
/*	width: 95%;*/
/*	overflow-x: auto;*/
/*	scroll-behavior: auto;*/
/*	display: block;*/
	}

.row_inline,
div.row_inline {
	white-space: nowrap;
	vertical-align: top;
	text-align: left;
	}
td.row_inline {
	/*white-space: nowrap;*/
	vertical-align: top;
	text-align: left;
	}

.row_inline div,
.row_inline span,
.row_inline label,
.row_inline select,
.row_inline div,
div.row_inline div,
div.row_inline span,
div.row_inline label,
div.row_inline select,
div.row_inline div,
td.row_inline div,
td.row_inline span,
td.row_inline label,
td.row_inline select,
td.row_inline div {
	display: inline-block;
	}

table.page_database {
	background-color: <?php echo $theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['PAGE_DB_BORDER']; ?>;
	color:		<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_FAMILY']; ?>;
	font-size:	<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['PAGE_DB_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_WEIGHT']; ?>;
	padding:	0px;
	margin:		0px;
	width:		100%;
	}

tr.page_database {
	background-color: inherit;
	}

tr.page_database_odd {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.page_database_even {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.page_database_odd:hover,
tr.page_database_even:hover {
	background-color: <?php echo $theme['ThemeSettings']['PAGE_DB_HOVER_BKGD_COLOUR']; ?>;
	}

th.page_database {
	font-family:	<?php echo $theme['ThemeSettings']['TH_FONT_FAMILY']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['TH_FONT_SIZE']; ?>;
	font-style:		<?php echo $theme['ThemeSettings']['TH_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['TH_FONT_WEIGHT']; ?>;
	background-color: inherit;
	text-align:		center;
	padding-top:	7px;
	}

.page_database {	/* used by online html editor */
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_SIZE']; ?>;
	padding:		<?php echo $theme['ThemeSettings']['PAGE_DB_PADDING']; ?>;
<?php echo_body_copy_css($theme); ?>
	}

.page_database_msgs {
	background-color: inherit;
	padding:	0px;
	margin:		0px;
/*	float:		left; */
	}

td.page_database_msgs {
	background-color: inherit;
	border-radius: 0.5em;
	border:		2px solid grey;
	padding:	3px;
	margin:		3px;
	float:		left;
	}

td.page_database, td.page_database_number, p.page_database, li.page_database {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_SIZE']; ?>;
	padding:		5px;
	}

.page_database_text,
td.page_database_text {
	text-align: left;
	}

.page_database_number,
td.page_database_number {
	text-align: right;
	}

td.page_database {
	border:		<?php echo $theme['ThemeSettings']['PAGE_DB_CELL_BORDER']; ?>;
	}

th.page_database {
	border:		<?php echo $theme['ThemeSettings']['PAGE_DB_CELL_BORDER']; ?>;
	text-align: center;
	}

span.page_database,
a.page_database, a.page_database:active, a.page_database:link, a.page_database:visited {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['PAGE_DB_FONT_SIZE']; ?>;
	padding:		5px;
	}

.page_database_pre,
pre.page_database {
	font-family: monospace, Courier, "Courier New";
	font-size: <?php echo $theme['ThemeSettings']['PAGE_DB_FONT_SIZE']; ?>;
	font-style: italic;
	}

.page_database select,
.page_database input,
select.page_database,
input.page_database {
	text-align: left;
	}

div.col_DB_head {
	white-space: normal;
	}

div.col_DB_head div {
	display: inline-block;
	}

img.col_DB_head {
	height: 10px;
	padding: 0px;
	}

table.section_body {
	background-color: <?php echo $theme['ThemeSettings']['SECTION_BKGD_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['SECTION_BORDER']; ?>;
	color:		<?php echo $theme['ThemeSettings']['SECTION_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['SECTION_FONT_FAMILY']; ?>;
	font-size:	<?php echo $theme['ThemeSettings']['SECTION_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['SECTION_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['SECTION_FONT_WEIGHT']; ?>;
	padding:	0px;
	margin:		2px;
	width:		100%;
	}

tr.section_body {
	background-color: inherit;
	}

th.section_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	font-style:		normal;
	font-size:		inherit;
	text-align:		left;
	padding:		0px 5px;
	}

td.section_body, span.section_body,
a.section_body,  a.section_body:active, a.section_body:link, a.section_body:visited,
h1.section_body, h2.section_body, h3.section_body  {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['SECTION_FONT_SIZE']; ?>;
	padding:		0px 2px;
	}

td.section_body > span,
td.section_body > div {
/*	overflow-y: auto;*/
/*	-webkit-transition: all 0.25s ease-in-out;
	-moz-transition: all 0.25s ease-in-out;
	-ms-transition: all 0.25s ease-in-out;
	-o-transition: all 0.25s ease-in-out;
	transition: all 0.25s ease-in-out;*/
/*	max-height: 0;*/
	padding-bottom: 5px;
	}

table.link_body {
	background-color: <?php echo $theme['ThemeSettings']['LINK_BKGD_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['LINK_BORDER']; ?>;
	color:		<?php echo $theme['ThemeSettings']['LINK_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['LINK_FONT_FAMILY']; ?>;
	font-size:	<?php echo $theme['ThemeSettings']['LINK_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['LINK_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['LINK_FONT_WEIGHT']; ?>;
	padding:	0px;
	margin:		0px;
	width:		100%;
	}

tr.link_body {
	background-color: inherit;
	}

tr.link_body_odd {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['LINK_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

tr.link_body_even {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['LINK_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

th.link_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	font-style:		normal;
	font-size:		inherit;
	text-align:		left;
	padding:		0px 5px;
	}

td.link_body, span.link_body, div.link_body,
a.link_body, a.link_body:active, a.link_body:link, a.link_body:visited,
h1.link_body, h2.link_body, h3.link_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?php echo $theme['ThemeSettings']['LINK_FONT_SIZE']; ?>;
	padding:		2px 2px;
	}
td.link_body {
	text-align: justify;
	}
span.link_body,
div.link_body {
	display: inline-block;
	border: 1px solid <?php list($w,$s,$c) = explode(' ',$theme['ThemeSettings']['LINK_BORDER']); echo $c; // just colour ?>;
	border-radius: 3px;
	margin: 2px 1px;
	vertical-align: top;
	text-align: center;
	}
span.link_body_mt,
div.link_body_mt {
	display: inline-block;
	margin: 2px 1px;
	}
span.link_body_odd,
div.link_body_odd {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['LINK_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}
span.link_body_even,
div.link_body_even {
	background-color: <?php echo Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['LINK_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']); ?>;
	}

div.cms_select_filtered {
	display: inline-block;
	}

table.page_bottom {
<?php if(!empty($theme['ThemeSettings']['FOOTER_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['FOOTER_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['FOOTER_BKGD_COLOUR']; ?>;
<?php } // else ?>
	color:		<?php echo $theme['ThemeSettings']['FOOTER_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['FOOTER_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['FOOTER_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['FOOTER_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['FOOTER_FONT_SIZE']; ?>;
	padding:	0px;
	border:		<?php echo $theme['ThemeSettings']['FOOTER_BORDER']; ?>;
	margin:		0px;
	width:		100%;
	height:		100%;
	}

th.page_bottom {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	}

tr.page_bottom, td.page_bottom {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	inherit;
	}

.cms_page_sitemap {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	inherit;
	font-style:		italic;
	margin: 0px 0px 0px 25px;
	}

td.cms_hilite_selected {
	border: 3px solid greenyellow;
	padding: 5px;
	border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
<?php echo_body_copy_css($theme); ?>
	-webkit-border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
/*	-moz-border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>; */
	}

.cms_msg_brief {
	font-size:		0.8em;
	}

span.cms_msg_info, div.cms_msg_info, p.cms_msg_info,
span.cms_msg_debug, div.cms_msg_debug, p.cms_msg_debug,
span.cms_msg_required, div.cms_msg_required, p.cms_msg_required,
span.cms_msg_success, div.cms_msg_success,
span.cms_msg_warning, div.cms_msg_warning,
span.cms_msg_error, div.cms_msg_error {
	font-family:	inherit;
	font-style:		italic;
	font-size:		<?php echo $theme['ThemeSettings']['MSG_FONT_SIZE']; ?>;
	white-space:	normal;
	}

span.cms_msg_debug, div.cms_msg_debug, p.cms_msg_debug {
	background-color: darkgrey;
	font-weight:	normal;
	color:			white;
	}

span.cms_msg_info, div.cms_msg_info, p.cms_msg_info {
	background-color: white;
	font-weight:	normal;
	color:			black;
	}

span.cms_msg_required, p.cms_msg_required,
div.cms_msg_required {
	background-color: ghostwhite;
	font-weight:	normal;
	color:			black;
	}

span.cms_msg_success,
div.cms_msg_success {
	background-color: greenyellow;
	font-weight:	normal;
	color:			black;
	}

span.cms_msg_warning,
div.cms_msg_warning {
	background-color: yellow;
	font-weight:	bold;
	color:			black;
	}

span.cms_msg_error,
div.cms_msg_error {
	background-color: red;
	font-weight:	bold;
	color:			white;
	}

div.cms_msg_stack {
	display: block;
	visibility: visible;
	font-family:	inherit;
	font-style:		inherit;
	font-size:		<?php echo $theme['ThemeSettings']['MSG_FONT_SIZE']; ?>;
	min-width: 100px !important;
	max-width: 60%;
	white-space: nowrap !important;
	position: fixed;
	right: <?php echo (!Ccms::show_right_column() ? '0px':$theme['ThemeSettings']['RIGHT_WIDTH']); ?>;
	margin-right: 10px;
	margin-top: 10px;
	top:	<?php echo $mh . 'px'; ?>;   /* Height of the header + navbar + 5 */
	z-index: 10;
	background-color: <?php echo $theme['ThemeSettings']['MSG_BKGD_COLOUR']; ?>;
	color:		<?php echo $theme['ThemeSettings']['MSG_FONT_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['MSG_BORDER']; ?>;
	border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
<?php echo_body_copy_css($theme); ?>
	-webkit-border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
/*	-moz-border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>; */
	}

span.cms_msg_closebtn {
	display: inline-block;
	margin-left: 0px;
	color: black;
	font-weight: bold;
	/*float: right;*/
	font-size: 2.0em;
	line-height: 20px;
	cursor: pointer;
	transition: 0.3s;
	vertical-align: top;
	}

span.cms_msg_closebtn:hover {
	text-decoration: underline;
	}

div.cms_msg_table {
	display: inline-block;
/*	width: calc(100% - 30px);*/	}

div.cms_msg_alert {
	padding: 10px;
	}

.cms_panel_block_outer {
	background-color: inherit;
	color:		inherit;
	font-family: inherit;
	font-size: inherit;
	font-weight: inherit;
	cursor: inherit;
	text-decoration: inherit;
	position: relative;
	margin: 0px 5px;
	}

.cms_panel_block_inner:hover,
.cms_panel_block_inner {
	display: none;
	background-color: <?php echo $theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR']; ?>;
	color:		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['BODIES_PDB_BORDER']; ?>;
	border-radius: <?php echo $theme['ThemeSettings']['BORDER_RADIUS']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_STYLE']; ?>;
	font-weight:		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_WEIGHT']; ?>;
	font-size:		<?php echo $theme['ThemeSettings']['BODIES_PDB_FONT_SIZE']; ?>;
/*	min-width: 500px; */
	width: auto;
	height: auto;
	position: absolute;
	right: -15px;
/*	left: 0px;*/
	top: 20px;
	padding: 3px;
/*	margin-left: 0px;*/
	cursor: default;
/*	outline: none; */
	z-index: 830;
	text-decoration: none;
	float: left;
	}

.cms_hover_block_outer,
.cms_sub_hover_block_outer {
	background-color: inherit;
	color:		inherit;
	font-family: inherit;
	font-size: inherit;
	font-weight: inherit;
	cursor: inherit;
	text-decoration: inherit;
	position: relative;
	margin: 0px 5px;
}

.cms_hover_block_outer > span,
.cms_sub_hover_block_outer > span {
	display: none;
}

.cms_sub_hover_block_outer:hover > span,
.cms_hover_block_outer:hover > span {
	display: block;
}

.cms_hover_block_inner,
.cms_sub_hover_block_inner {
/* on tablet devices is assisted by onclick="return true" */
	min-width: <?php echo (($theme['ThemeSettings']['NAV_BAR_BOOL'] != 'true') ? '130px':'130px'); ?>;
	height: auto;
	border-radius: 0.5em;
	position: absolute;
	right: -15px;
/*	left: 0px;*/
	top: 10px;
	padding: 3px;
/*	margin-left: 0px;*/
/*	white-space: normal;*/
/*	position: absolute;*/
	cursor: default;
	color: <?php echo $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR']; ?>;
	font-family: inherit;
	font-size: inherit;
	font-weight: normal;
	outline: none;
	z-index: 830;
	text-decoration: none;
	float: left;
	white-space: normal;
}
.cms_sub_hover_block_inner {
	/*position: relative;*/
	<?php
		echo (($theme['ThemeSettings']['NAV_BAR_BOOL'] == 'true') ? 'right: 65px':
		(($theme['ThemeSettings']['RIGHT_COLUMN_BOOL'] == "true") ? 'right: 65px':'left: 65px')); ?>;
}

div.cms_title_tooltip {
	transition: opacity 0.3s;
	display:	block;
	background:	<?php echo $theme['ThemeSettings']['TOOLTIP_BKGD_COLOUR']; ?>;
	border:		<?php echo $theme['ThemeSettings']['TOOLTIP_BORDER']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['FOOTER_FONT_FAMILY']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['TOOLTIP_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['TOOLTIP_FONT_WEIGHT']; ?>;
	font-size:	<?php echo $theme['ThemeSettings']['TOOLTIP_FONT_SIZE']; ?>;
	color:		<?php echo $theme['ThemeSettings']['TOOLTIP_FONT_COLOUR']; ?>;
	border-radius: <?php echo $theme['ThemeSettings']['TOOLTIP_BORDER_RADIUS']; ?>;
<?php echo_body_copy_css($theme,false); ?>
	-webkit-border-radius: <?php echo $theme['ThemeSettings']['TOOLTIP_BORDER_RADIUS']; ?>;
/*	-moz-border-radius: <?php echo $theme['ThemeSettings']['TOOLTIP_BORDER_RADIUS']; ?>; */
	padding:	5px;
	margin:		0px;
	z-index:	840;
	position:	relative;
	}

span.cms_title_tooltip {
	}

/* navigation bar */
ul.cms_nav_bar {
	min-height:	<?php echo $theme['ThemeSettings']['NAV_BAR_HEIGHT']; ?>;
<?php if ($cms_nav_bar_beside_logo) { ?>
	margin: 0 0 0 200px;
	min-height: <?php echo $theme['ThemeSettings']['HEADER_HEIGHT'] ?>;
<?php } else { ?>
	width: 100%;
	margin: 0;
<?php } ?>
	list-style-type: none;
/*	list-style:	none; */
	padding: 5px 0 0 0;
	overflow: visible;
	flex-wrap: wrap;
	flex-direction: row;
/*	justify-content: flex-end;*/
	align-items: center;
	cursor: default;
	display: flex;
/*	display: inline-block;*/
}

@media only screen and (max-width: 600px) {
	ul.cms_nav_bar {
		margin: 70px 0 0 0;
	}
}

li.cms_nav_bar, li.cms_nav_bar_on  {
<?php if(!empty($theme['ThemeSettings']['NAV_BAR_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['NAV_BAR_BKGD_COLOUR']; ?>;
<?php } // else ?>
	list-style:	none;
	border:		<?php echo $theme['ThemeSettings']['NAV_BAR_BORDER']; ?>;
	border-radius: <?php echo $theme['ThemeSettings']['NAV_BAR_BORDER_RADIUS']; ?>;
<?php echo_body_copy_css($theme,false); ?>
	-webkit-border-radius: <?php echo $theme['ThemeSettings']['NAV_BAR_BORDER_RADIUS']; ?>;
/*	-moz-border-radius: <?php echo $theme['ThemeSettings']['NAV_BAR_BORDER_RADIUS']; ?>; */
	color:		<?php echo $theme['ThemeSettings']['NAV_BAR_FONT_COLOUR']; ?>;
	font-family:	<?php echo $theme['ThemeSettings']['NAV_BAR_FONT_FAMILY']; ?>;
	font-size:	<?php echo $theme['ThemeSettings']['NAV_BAR_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['NAV_BAR_FONT_STYLE']; ?>;
	font-weight:	<?php echo $theme['ThemeSettings']['NAV_BAR_FONT_WEIGHT']; ?>;
	text-align:		center;
/*	height:	<?php echo $theme['ThemeSettings']['NAV_BAR_HEIGHT']; ?>; */
	display: block;
	float: left;
	overflow: visible;
	padding-left: 7px;
	padding-right: 7px;
	padding-top: 2px;
	padding-bottom: 2px;
	display: inline;
	margin: 2px;
	/* padding: 0px; */
	overflow: visible;
	list-style-type: none;
	display: block;
	float: left;
	margin: 0 5px 5px 5px;
}

li.cms_nav_bar {
	text-decoration:	none;
}

li.cms_nav_bar_on {
	text-decoration:	underline;
}

li.cms_nav_bar:hover, li.cms_nav_bar_on:hover {
<?php if(!empty($theme['ThemeSettings']['NAV_BAR_HOVER_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_HOVER_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['NAV_BAR_HOVER_BKGD_COLOUR']; ?>;
<?php } // else ?>
	border:		<?php echo $theme['ThemeSettings']['NAV_BAR_HOVER_BORDER']; ?>;
	color:		<?php echo $theme['ThemeSettings']['NAV_BAR_HOVER_FONT_COLOUR']; ?>;
}

a.cms_nav_bar a.cms_nav_bar:active, a.cms_nav_bar:link, a.cms_nav_bar:visited {
	display: inline-block;
	font-family:	inherit;
	font-size:		inherit;
	color:			inherit;
	text-decoration: none;
}

a.cms_nav_bar:hover {
	font-family:	inherit;
	font-size:		inherit;
	color:			inherit;
	/* color:			<?php echo $theme['ThemeSettings']['ANCHOR_HOVER_COLOUR']; ?>; */
	text-decoration: underline;
	}

img.cms_nav_bar {
	border:	none;
	padding: 0px;
	margin: 0px 5px 0px 0px;
	height: <?php echo $theme['ThemeSettings']['NAV_BAR_ICON_HEIGHT']; ?>;
	vertical-align: bottom;
	}

/* social media */
span.social_media {
	background:		inherit;
	visibility: visible;
	}

span.social_media_left {
	background:		inherit;
	visibility: visible;
	float:		left;
	}

span.social_media_right {
	background:		inherit;
	visibility: visible;
	float:		right;
	}

span.social_media_center_left {
	background:		inherit;
	visibility: visible;
	opacity:	0.9;
	position:	fixed;
	left:		5px;
	top:		40%;
	}

span.social_media_center_right {
	background:		inherit;
	visibility: visible;
	opacity:	0.9;
	position:	fixed;
	right:		10px;
	top:		40%;
	}

table.social_media {
<?php if(!empty($theme['ThemeSettings']['SM_BKGD_IMAGE'])) { ?>
	background-image: <?php echo Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['SM_BKGD_IMAGE']); ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?php echo $theme['ThemeSettings']['SM_BKGD_COLOUR']; ?>;
<?php } // else ?>
	border:		<?php echo $theme['ThemeSettings']['SM_BORDER']; ?>;
	border-radius: <?php echo $theme['ThemeSettings']['SM_BORDER_RADIUS']; ?>;
	font-family:	inherit;
	font-style:		inherit;
	font-weight:	inherit;
	font-size:		inherit;
	color:			inherit;
	padding:		0px;
	margin:			0px;
/*	width:			100%;*/
<?php echo_body_copy_css($theme,false); ?>
	-webkit-border-radius: 1em;
/*	-moz-border-radius: 1em; */
	}

tr.social_media {
	background:		inherit;
	padding:		0px;
	margin:			0px;
	border-width:	0px;
	}

th.social_media, td.social_media {
	background:		inherit;
	color:			inherit;	/* show the inherited, try red */
	font-family:	inherit;
	font-weight:	inherit;
	font-size:		inherit;
	padding:		2px;
	margin:			0px;
	border-width:	0px;
	}

.cms_legal {
	background-color: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_BKGD_COLOUR']; ?>;
	border: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_BORDER']; ?>;
	color: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_FONT_COLOUR']; ?>;
	font-family: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_FONT_FAMILY']; ?>;
	font-size: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_FONT_SIZE']; ?>;
	font-style: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_FONT_STYLE']; ?>;
	font-weight: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_FONT_WEIGHT']; ?>;
	padding: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_PADDING']; ?>;
	border-radius: <?php echo $theme['ThemeSettings']['PAGE_LEGAL_BORDER_RADIUS']; ?>;
	margin: 5px;
	}

div.cms_ddwn_outer {
	position: relative;
	display: inline-block;
	}

div.cms_ddwn_inner {
	display: none;
	position: absolute;
	background-color: white;
	color: black;
	min-width: 160px;
	box-shadow: 0px 5px 8px 0px rgba(0,0,0,1);
	padding: 5px 7px;
	z-index: 4;
	}

div.cms_ddwn_outer:hover div.cms_ddwn_inner {
	display: block;
	}

img.cms_ddwn_img {
	height: 20px;
	}

img.eye_img {
	height: 15px;
	}

/* eof */

