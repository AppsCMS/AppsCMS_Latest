<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_manual.php 2054 2021-04-09 04:42:32Z robert0609 $
 */

define("APPS_MAN_INCLUDE_DIR",		APPS_WS_DIR . "include/");	// for manual
define("APPS_MAN_INI_DIR",			APPS_MAN_INCLUDE_DIR . "ini/");	// for manual
define("APPS_MAN_CLASSES_DIR",		APPS_MAN_INCLUDE_DIR . 'classes/');	// for manual
define("CMS_MAN_CLI_DIR",			CMS_WS_DIR . "cli/");	// for manual
define("CMS_MAN_INI_DIR",			CMS_WS_DIR . "include/ini/");	// for manual
define("ETC_MAN_INI_DIR",			ETC_DIR . "ini/");	// for manual
define("ETC_MAN_APPS_CONFIG",		ETC_DIR . 'ini/apps.ini');
define("ETC_MAN_EXT_INCLUDES_DIR",	ETC_DIR . 'ext/');	// for manual
define('ETC_MAN_SQLITE_DIR',		ETC_DIR . 'sqlite/');
define("CMS_MAN_EXAMPLE_BODIES_DIR",	CMS_WS_EXAMPLES_DIR . PAGE_BODIES_WS_DIR);	// for manual
define("VAR_WS_USERS_DIR",			VAR_DIR . "variables/users/");

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<table class="page_config">
	<caption>Manual for <?php echo strip_tags(CMS_PROJECT_SHORTNAME); ?> page</caption>
	<tr class="page_config">
		<th class="page_config">
			<img height="150px" src="<?php echo CMS_IMAGE_LOGO; ?>" alt="<?php echo CMS_PROJECT_SHORTNAME; ?> Logo">
			<h1 class="page_config" style="white-space: normal;">Technical Manual</h1>
			<br>
			<h2 class="page_config" style="white-space: normal;"><?php Ccms::prn_AppsCMS_title(); ?></h2>
		</th>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Features"></a>
			Features
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> is a multiple application management library written in PHP for web applications and web worker sites.
				It provides base line functionality to improve security and provide most of the web server side configuration and operation code.
				Although the <?php echo CMS_PROJECT_SHORTNAME; ?> is a PHP programmers tool (hence it is called a library), it is easy to
				learn and understand. Providing a good foundation library for web applications.
			</p>
			<p class="page_config">
				Being a code library and relatively small, it can easily be version controlled by Git or SVN as a whole.
			</p>
			<p class="page_config">
				<?php echo CMS_PROJECT_SHORTNAME; ?> provides theme / brand control of maintain basic theme appearance.
			</p>
			<p class="page_config">
				It is not intended to emulate or replace larger and more complex Content Management Systems (CMS).
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has a focus on web applications
				(e.g. data storage, processing and control, results compilation, machine interfacing, control/configuration interfacing,
				status display, etc).
			</p>
			<p class="page_config">
				A recommended way to see what the <?php echo CMS_PROJECT_SHORTNAME; ?> has is to login as an administrator to the
				<?php echo CMS_PROJECT_SHORTNAME; ?>, turn on debug (if not already on), goto to
				<a href="index.php?cms_action=cms_debug">&quot;<?php echo CMS_PROJECT_SHORTNAME; ?> Debug&quot;</a> and
				<a href="index.php?cms_action=cms_edit_search">&quot;Search&quot;</a> to check out whats there.
				A good PHP coding Integrated Development Enviroment (IDE) should allow more understanding of the <?php echo CMS_PROJECT_SHORTNAME; ?> library.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> library can function as an initial web site
				to allow setup and configuration.
				And get a feel for the library.
			</p>
			<p class="page_config">
				Also, if doxygen is installed, running &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_doxy_run.sh&quot; from the bash shell command line generate reasonable source documentation.
				Extra Admin entries will appear in debug mode to view the generated documentation.
			</p>
			<p class="page_config">
				There are a large number of configuration and coding features built in to the <?php echo CMS_PROJECT_SHORTNAME; ?> library.
				It is recommended to read this manual and explore the code library with a PHP IDE.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Contents"></a>
			Contents
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<ul class="page_config">
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Introduction">Introduction</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Terminology">Terminology</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Cookies">Cookies</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Licence">Licence</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#TechnicalInformation">Technical Information</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ServerSystemRequirement">Minimum Server System Requirements</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ServerSystemConfigs">Typical Server System Configurations</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Installation"> <?php echo CMS_PROJECT_SHORTNAME; ?> Installation and Update</a>
				</li>
				<li class="page_config">
						<a href="index.php?cms_action=cms_manual#GitSVNinstall">SVN and Git Applications Install and Update</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#WindowLayout">Browser Window Layout</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#SetupConfiguration">Static Setup and Configuration</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#RunTime">Applying Run Time Settings and Configurations</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#DynamicConfiguration">Dynamic Configuration</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Apps">Applications</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppTypes">Types of Applications</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppClass">Primary Application Class</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Plugins">Plug Ins</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppsAuth">Applications Authentication</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppsExtendPlugin">Applications Extension Plug In</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Localtools">Local Tools</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#WYSIWYGs">WYSIWYGs</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Sitemap">Sitemap</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#special_code">Special Code</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#coding_shortcuts">Coding Shortcuts and Builtin Features</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#cron_jobs">Chronological Timing (CRON Jobs)</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#TroubleShooting">Trouble Shooting</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#VersionControl">File Version Control</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#UtilityScripts">Utility Scripts</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ExampleCode">Code Examples</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#MoreInfo">More Information and Feedback</a>
				</li>
<?php if(file_exists("cms/doxy/html/index.html")) { ?>
				<li class="page_config">
					<a href="cms/doxy/html/index.html"><?php echo CMS_PROJECT_SHORTNAME; ?> Code Documentation</a>.
				</li>
<?php	} // if ?>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Introduction"></a>
			Introduction
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				This technical manual is to aid administrators, managers and web developers using the <?php echo CMS_PROJECT_SHORTNAME; ?>.<br>
				Supplementary to this manual is the <?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#Introduction'); ?>.
				The <?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes',false,'#Introduction'); ?> list the <?php echo CMS_PROJECT_SHORTNAME; ?> change history.
				General information is available in the <a href="index.php?cms_action=cms_about">About <?php echo CMS_PROJECT_SHORTNAME; ?></a> page.
			</p>
			<p class="page_config">
				The web site has a search function to aid finding configuration and setup values.
			</p>
			<p class="page_config">
				<strong>NOTE:</strong> The <?php echo CMS_PROJECT_SHORTNAME; ?> is not designed to operate inside a frame or iframe.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Terminology"></a>
			Terminology
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> and it&rsquo;s technical manual uses some terminology that is unique to the <?php echo CMS_PROJECT_SHORTNAME; ?>.
				This terminology is described as;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;(DOCROOT)&quot; - the location in the file system on the Apache server of the <?php echo CMS_PROJECT_SHORTNAME; ?> installation.
					For this installation it is the &quot;<?php echo DOCROOT_FS_BASE_DIR; ?>&quot; directory.
					The location of &quot;(DOCROOT)/&quot; is automatically found by the <?php echo CMS_PROJECT_SHORTNAME; ?>
					and defined in the &quot;DOCROOT_FS_BASE_DIR&quot; global constant,
					from which all file system location defines are derived.
					<br>NOTE: If in debug mode, the Admin -&gt; Debug page will show all the globally defined constants.
				</li>
				<li class="page_config">
					&quot;(APP_DIR)&quot; - is the application as described the Admin -&gt; Pages / Apps menu.
					The actual location of the application is in &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/&quot; directory.
					<br>NOTE: Applications which share an application directory in &quot;<?PHP echo APPS_WS_DIR;?>&quot;
					(allowed by Admin -&gt; Search -&gt; CMS_C_ALLOW_APPS_DIR_SHARE),
					also share the same (APP_DIR).
				</li>
				<li class="page_config">
					&quot;(APP_NAME)&quot; - is the application name used by the <?php echo CMS_PROJECT_SHORTNAME; ?>, for indexing.
					The (APP_NAME) is the the (APP_DIR) with non alphanumeric characters replaced by underscores.
					<br>For example: &quot;My App1&quot; directory would have an  (APP_NAME) of &quot;My_App1&quot;.
				</li>
				<li class="page_config">
					&quot;(APP_KEY)&quot; -  is the uppercase alphanumerical (other characters are set to underscore) representation
					of the application&rsquo;s directory in &quot;<?PHP echo APPS_WS_DIR;?>&quot;.
					For example: &quot;My App1&quot; directory would have an  (APP_NAME) of &quot;My_App1&quot;.
					The &quot;(APP_KEY)&quot; is used for prefixing application settings with the uppercase &quot;(APP_NAME)_&quot;,
					in the aggregated &quot;<?php echo ETC_MAN_APPS_CONFIG; ?>&quot; applications settings file.
					Amongst other requirements for a application key.
					<br>NOTE: Applications which share an application directory in &quot;<?PHP echo APPS_WS_DIR;?>&quot;
					(allowed by Admin -&gt; Search -&gt; CMS_C_ALLOW_APPS_DIR_SHARE),
					also share the same (APP_KEY).
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Cookies"></a>
			Cookies
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> uses session cookies (i.e. not third party cookies) to
				allow the browser to provide the user&rsquo;s session identity.
				The session identity is the unique key (generated by the user&rsquo;s browser) used to identify
				the user uniquely to that one web browser and is provided to the <?php echo CMS_PROJECT_SHORTNAME; ?> server via a session cookie.
				The identity connects only with that one browser on that particular user&rsquo;s machine.
				The session identity is stored in a cookie on the user&rsquo;s computer.
				Without the session cookie, the user would not be able to log in.
			</p>
			<p class="page_config">
				The non cookie method of having the session identity (or SID) in every URL (or some browser side script to do the same thing)
				is not used on the <?php echo CMS_PROJECT_SHORTNAME; ?>.
				The session identity is passed back to the server on every page load as a query parameter.
				The non session cookie method is very insecure as the browser URL shown in the address bar exposes the session identity
				and the URL can be easily copied to any another browser,
				the rights and privileges of the original user will also follow (because the server has no way to tell the difference).
				It is also not secure as the session identity will be stored in the browser history even when the browser is reopened at a later date
				(where a session cookie would be deleted when the user closed the browser).
				This non session cookie method is not recommended.
			</p>
			<p class="page_config">
				The recommended method for session identity is by the browser&rsquo;s session cookie.
				If no session cookie, no login should be allowed.
			</p>
			<p class="page_config">
				The browser session identity is used as a unique key to save and retrieve a user&rsquo;s state on the server.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> provides a client metadata cookie
				in &quot;_cms_clientMeta&quot; (as an encoded JSON).
				This cookie expires in 1 hour from last use.
				It provides metadata feedback for applications that need to know the dimensions (e.g. depth, width, height, timezone, language, etc.) of the
				client&rsquo;s browser window.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Licence"></a>
			Licence
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> is under &quot;BSD-3-Clause&quot; and has the
				<a href="https://opensource.org/licenses/BSD-3-Clause">&quot;https://opensource.org/licenses/BSD-3-Clause&quot;</a>.
			</p>
			<p class="page_config">
				The licence apply&rsquo;s as follows;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					With the exception of library files in the &quot;<?php echo CMS_WS_LIB_DIR; ?>&quot; directory,
					the <?php echo CMS_PROJECT_SHORTNAME; ?> licence applies to all other files in the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory.
				</li>
				<li class="page_config">
					And applies to &quot;index.php&quot;, &quot;ajax.php&quot;, &quot;login.php&quot; and  &quot;logout.php&quot; files (in the web &quot;(DOCROOT)/&quot; directory),
				</li>
			</ul>
			<p class="page_config">
				Which is the extent of <?php echo CMS_PROJECT_SHORTNAME; ?> files licenced.
			</p>
			<p class="page_config">
				File in the &quot;<?php echo CMS_WS_LIB_DIR; ?>&quot; directory are covered by there own respective licences.
				And are not licenced by the <?php echo CMS_PROJECT_SHORTNAME; ?>.
			</p>
			<p class="page_config">
				The applications and user web pages files are not licenced by the <?php echo CMS_PROJECT_SHORTNAME; ?> author.
				And belong to the licensing respective application authors.
				<b>The Licence for the Applications are the user&rsquo;s responsibility and are licenced separately.</b>
			</p>
			<p class="page_config">
				The author of <?php echo CMS_PROJECT_SHORTNAME; ?> is open to submissions from the user community for changes
				in the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory to be included in the next release.
				Submissions can be emailed to
				<a HREF="mailto:feedback@<?php echo CMS_PROJECT_DOMAIN; ?>?Subject=<?php echo rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ' Changes.'); ?>">
					<?php echo CMS_PROJECT_SHORTNAME; ?>
				</a>.
				A submission script is available at &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_wrap_submission.sh&quot; is available to produce a
				ZIP archive of the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory.
				<br>
				<b>Important Note on Submissions:</b> It is usual for submissions to be credited to the submission author.
				The submission author needs to provide permission for an acknowledgment (in the release notes) to be added.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="TechnicalInformation"></a>
			Technical Information
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?php echo CMS_PROJECT_SHORTNAME; ?> is based around standard technology.
				Some effort was made to make the code compatible for browsers with CSS3 and HTML5.
				PHP coding is used to generate html web pages.
				The PHP code is written in &quot;Object Oriented Programming&quot; (OOP).
				This aids the application programmer in writing applications that sit on top of <?php echo CMS_PROJECT_SHORTNAME; ?> objects (e.g. a class).
			</p>
			<p class="page_config">
				Installation setup is stored in INI files.
				Theme customization is also stored in INI files, and is used to generate CSS style sheets.
				Accompanying installation and theme setting pages are included to make changes.
				The default settings provide an operational <?php echo CMS_PROJECT_SHORTNAME; ?>.
			</p>
			<p class="page_config">
				The setup and configuration files are saved in the &quot;<?php echo ETC_DIR; ?>&quot; for setting JSON, INI and sqlite (e.g. cms.ini, <?php echo INI_DB_SQLITE_DATABASE; ?>, etc.) files.
				Setup control JSON and INI (e.g. cms.comment.ini, cms.default.ini, etc) files remain in &quot;<?php echo CMS_MAN_INI_DIR; ?>&quot; or &quot;<?php echo APPS_MAN_INI_DIR; ?>&quot; respectively as part of the code base.
				Execution data is saved the &quot;<?php echo VAR_DIR; ?>&quot; directory (counts, exports,logs, sessions, etc.).
				This is to make updating and developing &quot;<?php echo APPS_WS_DIR; ?>&quot; code easier,
				separating critical site only files from unwanted alteration.
				Refer to <?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes',false,'#TechnicalInformation'); ?>.
			</p>
			<p class="page_config">
				Data for users, administrators, managers, groups, page bodies, tools and configuration are stored in an SQLite3 database.
				SQLite was chosen due to its easy installation (no database setup required) and it is very suitable for small projects.
				Automatic database installation code is provided.
				The SQLite database is initialized when the first web page is generated after installation.
				Providing an empty initialized database with the default configuration settings.
			</p>
			<p class="page_config">
				A basic description of the configuration database tables used;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Configuration Table - stores company name, web titles, image control, etc.,
					used in the web pages.
				</li>

				<li class="page_config">
					Users Table - stores username, encrypted password, group memberships,
					sort order/priority, enable/disable and administrator enabling.
					<br>
					NOTE: That when the AD/LDAP authentication is used and no local password is supplied,
					a default local password of the date in YYYYMMDD format is used.
				</li>

				<li class="page_config">
					Groups Table - stores group, enable/disable, administrator and managers.
				</li>

				<li class="page_config">
					Page Bodies Table - stores the page body / application primary control values.
					The actual page content is stored in the &quot;<?php echo PAGE_BODIES_WS_DIR; ?>&quot; directory using the filename configured.
					The body file is often used as a connector or control file for local application
					and often includes files in the &quot;<?php echo APPS_WS_DIR; ?>&quot; directory.
					<br>
					<b>NOTE:</b> The applications may have further configuration settings in the applications.
				</li>

				<li class="page_config">
					Tools Table - stores the tools information.
					A special directory, &quot;<?php echo LOCAL_WS_TOOLS_DIR; ?>&quot;, has been set aside inside the <?php echo CMS_PROJECT_SHORTNAME; ?>
					file structure for handy tools, local "hacks" and try outs.
					Tools have sort order/priority, new page and enable/disable.
					Stores tool links , group memberships, sort order/priority and enable/disable.
					The tools appear in left column (or right column) in a drop down from the header or on the nav bar,
					and are displayed according to the group settings.
				</li>

				<li class="page_config">
					Links Table - stores the URL links information.
					This table contains values and controls are for the &quot;Links&quot; page (i.e. a type of bookmarks and documents index page.
					Bookmarks from Firefox and Chrome web browsers can be imported into the sections (folders) table and links (URLs) table.
				</li>

				<li class="page_config">
					Sections Table - controls the links page layout so that links are sectioned/grouped
					together for display and access control.
				</li>

			</ul>
			<p class="page_config">
				When the Admin-&gt;Config-&gt;Allow CSV Export and Import = True,
				the corresponding database table is exported to the exports/ directory on each save.
				The CSV can be downloaded from the relevant <?php echo CMS_PROJECT_SHORTNAME; ?> setup editor page.
				The CSV can be altered as the commentary included in the CSV file and uploaded back to the <?php echo CMS_PROJECT_SHORTNAME; ?> database.
				The CSV format uses the standard comma delimiter and double quotes for the enclosure (as required) to separate column data.
				<br>
				The <?php echo CMS_PROJECT_SHORTNAME; ?> setup editor page has a file browse button and an upload button
				to upload and import a CSV table file from your local computer.
				Before an uploaded file is imported, the <?php echo CMS_PROJECT_SHORTNAME; ?> backups up the database
				to the backups/ directory.
				<br>
				To restore a backup on LINUX, in the web root directory run:
				<br>
				&quot;zcat backups/AppsCMS-Backup-<?php echo INI_DB_SQLITE_DATABASE; ?>-YYYYMMDD-HHMMSS.gz | sqlite3 <?php echo ETC_FS_SQLITE_DIR . INI_DB_SQLITE_DATABASE; ?>&quot;
				<br>
				Substitute your filenames as needed.

			</p>
			<p class="page_config">
				Setup and operational features should be self evident.
				All install, setup and configuration settings have accompanying information builtin describing each particular setting.
				The idea was to keep it simple.
				Remove anything that wasn&rsquo;t useful or looked too complicated (i.e. make it easy to customize),
				by providing just the basics.
				The result has been to make use of CSS to remove as much code as possible.
				As a result the code has minimal javascript.
			</p>
			<p class="page_config">
				 <?php echo CMS_PROJECT_SHORTNAME; ?> theme settings are numerous and should be self evident.
				 <?php echo CMS_PROJECT_SHORTNAME; ?> is intended for general small web sites required for the generation of user/owner managed web sites.
				 <?php echo CMS_PROJECT_SHORTNAME; ?> can be set to be easily identifiable (due to page headers and footers) so that users know the web site entity.
			</p>
			<p class="page_config">
				The web site can authenticate user against a LDAP/AD server by setting a user&rsquo;s auth preferences to LDAP.
				The settings are part of the install settings.
			</p>
			<p class="page_config">
				The web site has an Admin -&gt; Search function to aid finding configuration, setup and page contents.
				Search (and filters) can be by exact match (of anded keywords), phonetic (sounds like) or levenshtein (similar match).
				The phonetic and levenshtein have enable/disable options.
				When the user is not sure of the exact words, these extra filters help find the required link,
				although they do produce more results.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> requires session cookies (also know as transient cookies) to be enabled to allow login.
				The session cookie locks your browser to the server session and provides additional security information about the identity of the session end to end.
				If the session cookie is disabled, a warning is shown on screen.
				Third party cookies are not used by the <?php echo CMS_PROJECT_SHORTNAME; ?>, so third party cookies can be disabled.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has a content cache functionality to speed up deliver of content that does not change
				between successive requests to the web server.
				The content cache provides a 80% to 95% time reduction in the background <?php echo CMS_PROJECT_SHORTNAME; ?> operation on
				sections like nav bar, header and menus that require a large amount of processing each time they are displayed but do not change.
				The page bodies, custom header and custom footer can also be cached selectively.
				The content cache is cleared at login, logout, saving settings and configuration rebuild.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has many defined constants, class objects, methods / functions and variables
				available to the web programmer. The use of an autocompleting IDE is recommended. The <?php echo CMS_PROJECT_SHORTNAME; ?> is
				in debug mode there is a debug selection in the Admin menu which will the global defines and various other other information.
			</p>
			<p class="page_config">
				A secondary data mine type database (i.e. filesystem based) in the &quot;<?php echo VAR_WS_USERS_DIR; ?>&quot; directory is used to hold transitory user data
				(e.g. login count, login timeout, etc.).
				This saves having to manage database changes in the sqlite database from transitory data when using Git or SVN document version control systems.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="ServerSystemRequirement"></a>
			Minimum Server System Requirements
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?php echo CMS_PROJECT_SHORTNAME; ?> requires the following server requirements to operate;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Apache 2.4.x installed on LINUX (tested on CentOS 8.3 and openSUSE 15.2).
				</li>

				<li class="page_config">
					PHP 7.2 (recommended, tested on 7.4)<br>
					Installed packages: php php-bcmath php-json php-pecl php-devel
					php-dba php-zlib php-sqlite php-curl php-zip php-dom php-opcache
					php-pear php-ctype php-tokenizer php-openssl php-mbstring,
					<br>Optionally packages: php-mysql php-pdo php-gd php-iconv php-posix/php-intl php-xdebug,
					<br>Plus the web server PHP engagement packages (e.g. apache2-mod_php).
				</li>

				<li class="page_config">
					<?php echo CMS_PROJECT_SHORTNAME; ?> can be setup as an adjunct to an existing web site,
					or as a new web site (If a new web site,
					the Apache web server configuration needs to be setup for the new web site.),
				</li>

				<li class="page_config">
					An SSL certificate, self signed or registered for SSL/https web site encryption,
				</li>

				<li class="page_config">
					http (port 80) for default home/links page and https (port 443) for login and user designated pages,
				</li>
			</ul>
			<p class="page_config">
				To use country checks, the PECL geoip (geoip >= 2.0) is required.
				For LDAP authentication the "php-ldap" module is required.
				For system process access the "php-process" module is required.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="ServerSystemConfigs"></a>
			Typical Server System Configurations
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<h3 class="page_config">Example Virtual Host Apache Configuration File:</h3>
			<?php include(CMS_FS_IMAGES_MANUAL_DIR . 'example_vhost_conf.html'); ?>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<h3 class="page_config">Example Aliased Apache Configuration File:</h3>
			<?php include(CMS_FS_IMAGES_MANUAL_DIR . 'example_alias_conf.html'); ?>
			<br>
			<b>Note:</b> The <?php echo CMS_PROJECT_SHORTNAME; ?> automatically includes the alias in URLs,
			by setting the page base href meta data to tell the browser the page locations.
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Installation"></a>
			Installation and Update
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<b>Note 1:</b> The server set up is beyond the scope of this manual. Some general server side setup information is given here. If help is required, contact your system administrator or tech support.<br>
				<b>Note 2:</b> The actual methods used on a particular server may vary from the steps shown here.<br>
				<b>Note 3:</b> The <?php echo CMS_PROJECT_SHORTNAME; ?> zip and installer files do not come with user set files that over writes user settings,
				if required &quot;(DOCROOT)&quot; files outside of &quot;<?php echo CMS_WS_DIR; ?>&quot; don&rsquo;t exist (e.g. .htaccess, index.php, ajax.php, login.php, logout.php,.etc.) the <?php echo CMS_PROJECT_SHORTNAME; ?> will generate default files.
				The &quot;ajax.php&quot; is not normally required nor used if the originating code is generated by the <?php echo CMS_PROJECT_SHORTNAME; ?> and calls &quot;cms/cms_ajax.php&quot; directly.
				For reference (and possible update), a copy of these distribution &quot;(DOCROOT)&quot; files is available in the &quot;cms/docroot_files/&quot;. If changes are made to the default &quot;(DOCROOT)&quot; files,
				the changes can be seen in the &quot;cms/docroot_files/&quot; directory.<br>
				<b>Note 4:</b> The <?php echo CMS_PROJECT_SHORTNAME; ?> installer script file defaults to installing <?php echo CMS_PROJECT_SHORTNAME; ?> library
				in a read only mode (approx 11MB). If a full read/write install is required use the zip (approx 19MB).<br>
				Refer to the <?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#Installation'); ?>.
				or to <?php echo Ccms_media_conv_plugin::get_file_href('cms_lib_sqsh.md','Installation Notes Extract',false,'#Installation'); ?>.
			</p>
			<p class="page_config">
				<b>Important Note:</b> The Apache web server will needed to be stopped and started after a read only install or update.
				The server will need to be totally disengaged (i.e. a full stop/start, e.g. service httpd stop &amp;&amp; service httpd start).
				And if in use, the php-fpm service  will need to be totally disengaged (i.e. a full stop/start, e.g. service php-fpm stop &amp;&amp; service php-fpm start).
				The normal restart only reloads the web server configuration files and will not release the previous squashfs mounts.
			</p>
			<p class="page_config">
				The installation comes as a self installing bash script (5.5MB) for LINUX and a ZIP (3.9M) file for general installations.
				Available on the &quot;https://github.com/AppsCMS/AppsCMS_Latest/blob/master/AppsCMS-Installer-latest.sh&quot;.
			</p>
			<p class="page_config">
				For full user and administration experience use a CSS3 and HTML5 compatible browser
				(e.g. Microsoft&reg; Edge, Mozilla Firefox, Google Chrome, etc.).
			</p>
			<p class="page_config">
			    The installation is in the &quot;(DOCROOT)/&quot; directory
				(the server file system directory, accessed/served by Apache, where the <?php echo CMS_PROJECT_SHORTNAME; ?> web apps are installed).
			</p>
			<p class="page_config">
				A guide to installing and updating <?php echo CMS_PROJECT_SHORTNAME; ?> follows;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Login to the web server as the user the web site is setup with (usually the user is the domain e.g. somedomain.com).
					<b>Do not log in as root, administrator or any other privileged user.</b>
				</li>
				<li class="page_config">
					<b>If updating, backup the web site.</b>
				</li>
				<li class="page_config">
					<a href="https://github.com/AppsCMS/AppsCMS_Latest/blob/master/AppsCMS-Installer-latest.sh" target="_blank">Download the <?php echo CMS_PROJECT_SHORTNAME; ?> installer file &quot;AppsCMS-Installer-latest.sh&quot;</a>
					to the web site&rsquo;s &quot;(DOCROOT)/&quot; directory on your web server.
					<br>
					Alternatively there is shell script &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_updateAppsCMS.sh&quot; to update the
					<?php echo CMS_PROJECT_SHORTNAME; ?> from the online repository using the &quot;AppsCMSupdater&quot; setup section.
				</li>
				<li class="page_config">
					On Linux, change the &quot;AppsCMS-Installer-latest.sh&quot; file attributes so it can be executed<br>
					e.g. chmod u+x &quot;AppsCMS-Installer-latest.sh&quot;
				</li>
				<li class="page_config">
					Then execute the &quot;AppsCMS-Installer-latest.sh&quot; in the &quot;(DOCROOT)/&quot; directory.<br>
					This will install or update the <?php echo CMS_PROJECT_SHORTNAME; ?> &quot;<?php echo CMS_WS_DIR; ?>&quot; directory and chek that manadatory file are present (replacing if necessary).
					And initialise the web site parameters.
				</li>
				<li class="page_config">
					For a new installation the output typically looks like this (with no errors and some warning for generating new files);-
					<?php include(CMS_FS_IMAGES_MANUAL_DIR . 'cli_installer_output.html'); ?>
					<br>
					<b>NOTE: That this installer run has indicated an error from a missing system package.</b>
				</li>
				<li class="page_config">
					For a <?php echo CMS_PROJECT_SHORTNAME; ?> read only update the output typically looks like this (with no errors and some warning for generating new files);-
					<?php include(CMS_FS_IMAGES_MANUAL_DIR . 'cli_updater_output.html'); ?>
					<br>
					<b>NOTE 1: That this update run has a few warnings but it can be used.</b>
					<br>
					<b>NOTE 2:</b> The &quot;.htaccess&quot;, &quot;index.php&quot;, &quot;login.php&quot; and &quot;logout.php&quot; files are not changed if they are already present.
					Because these files require customisation in some installation. If you need to to or reinstate the file,
					rename the old files to a new filename (e.g. &quot;index.php-bak&quot;) and re-run the installer.
					<br>
				</li>
				<li class="page_config">
					For a <?php echo CMS_PROJECT_SHORTNAME; ?> read/write install or update, uzip the <?php echo CMS_PROJECT_SHORTNAME; ?> zip file.
				</li>
				<ul class="page_config">
					<li class="page_config">
						Use &quot;<b>unzip <?php echo CMS_PROJECT_SHORTNAME; ?>-{VERSION}.zip cms/* -d (DOCROOT)</b>&quot; to update the <?php echo CMS_PROJECT_SHORTNAME; ?> cms library directory.
					</li>
					<li class="page_config">
						The &quot;.htaccess&quot;, &quot;index.php&quot;, &quot;login.php&quot; and &quot;logout.php&quot; files can be extracted as required."
						The read only control file &quot;cms_lib_sqsh.php&quot; should always be extracted.
						The other read only files &quot;cms_lib_sqsh.sqsh&quot;, &quot;cms_lib_sqsh.sh&quot; and &quot;cms_lib_sqsh.md&quot;
						are optional in a read/write installation.
						<br>
						The &quot;cms_rebuild.sh&quot; and &quot;cms_set_permissions.sh&quot; scripts in the (DOCROOT) are to make it easier for common command line rebuilds.

			</li>
					<li class="page_config">
						Use &quot;<b>unzip <?php echo CMS_PROJECT_SHORTNAME; ?>-{VERSION}.zip filename2unzip -d (DOCROOT)</b>&quot; to unzip the file.
					</li>
					<li class="page_config">
						<b>NOTE: The unzip utility command overwrites files by default. Do a backup first.</b>
					</li>
				</ul
				<li class="page_config">
					Pointer your browser at	&quot;http://your.web.site/site_alias/index.php&quot; (site_alias/ is part of your server setup, usually empty).
				</li>
				<li class="page_config">
					When the <?php echo CMS_PROJECT_SHORTNAME; ?> is first accessed, it will create an empty SQLite database and rebuild all the CSS stylesheets.<br>
					After approximately 20 to 60 seconds the rebuild will finish displaying status of the rebuild processes.
				</li>
				<li class="page_config">
					Click the &quot;User: Login&quot; link.
					When no users are setup, a default admin user is;-<br>
					Username: admin<br>
					Password: password<br>
					Strongly recommend the admin username be disabled after you have setup another, more secure, user (with admin rights).<br>
					Login to the web site.
					On a fresh install you should see the about page.
					For a update you should your home page.
				</li>
				<li class="page_config">
					<b>Important Note 1:</b> If upgrading from V2.07 or less,
					run "cms/cli/cms_update_appsV207.sh" to upgrade your applications.
				</li>
				<li class="page_config">
					<b>Important Note 2:</b> If upgrading from V2.15 or less,
					run "cms/cli/cms_update_appsV215.sh" to upgrade your applications.
				</li>
				<li class="page_config">
					Suggest going to the <a href="index.php?cms_action=cms_manual#SetupConfiguration">Setup and Configuration</a> section.
				</li>
			</ul>
			<p class="page_config">
				If failures and non functional issues occur, <a href="index.php?cms_action=cms_manual#TroubleShooting"> see Trouble shooting</a>
			</p>
			<p class="page_config">
				An advanced install can be done using the &quot;https://github.com/AppsCMS/AppsCMS_Latest/blob/master/AppsCMS-latest.zip&quot; zip file.
				From the command line run;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;sudo <?php echo CMS_WS_CLI_DIR; ?>cms/cli/cms_set_permissions.sh&quot; correct any permission problems.
					(If sudo access is not available, you will need to get the a sudoer or root to run it.)
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_WS_CLI_DIR; ?>cms/cli/cms_rebuild.sh&quot; check and update (and rebuild if necessary)
					<?php echo CMS_PROJECT_SHORTNAME; ?> will check and make the directory structure and add missing app directoruies,
					regenerate the stylesheets themes, etc.
				</li>
			</ul>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The settings in the INI files for the <?php echo CMS_PROJECT_SHORTNAME; ?>
				and for applications in the &quot;<?php echo ETC_MAN_INI_DIR; ?>cms.ini&quot; and
				the &quot;<?php echo ETC_MAN_INI_DIR; ?>apps.ini&quot; files are read after the configuration DB
				values, in the Ccms::__construct() method (i.e. in the same code block).
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="GitSVNinstall"></a>
			SVN and Git Applications Install and Update
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Supplementary to installing from a shell install script or update from a zip file or remote  <?php echo CMS_PROJECT_SHORTNAME; ?> repository,
				it is recommended for the  <?php echo CMS_PROJECT_SHORTNAME; ?> and application installations and updates
				from SVN and Git repositories to run the web applications, it is recommended to execute the following scripts;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					<b>First</b> run &quot;sudo bash -e <?php echo CMS_WS_CLI_DIR; ?>cms_set_permissions.sh&quot;.
					This will set permissions for shell and web server access.
				</li>
				<li class="page_config">
					<b>Second</b> run &quot;bash -e <?php echo CMS_WS_CLI_DIR; ?>cms_rebuild.sh&quot;.
					This will build the latest settings, configuration DB and directory structure for this <?php echo CMS_PROJECT_SHORTNAME; ?> version.
				</li>
			</ul>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="WindowLayout"></a>
			Browser Window Layout
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				There is an overall web site style settings (part of the Theme settings);
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;Block Style&quot; - uses absolute positioning in the browser&rsquo;s window. The page body scrolls between fixed positions of the header and the footer. The tool links, admin links and navigation bar also have fixed positions in the browser&rsquo;s window.
					The browser&rsquo;s window is more easily navigable.
				</li>
				<li class="page_config">
					&quot;Inline Style&quot; - uses inline/relative positioning in the browser&rsquo;s window. Scrolls the header, tool links, admin link, navigation bar, page body and footer as one entity. This can make the separate areas of the browser window difficult to navigate to.
					The <?php echo CMS_PROJECT_SHORTNAME; ?> detects the type of device being used to display the web pages,
					and is not designed to be administered from tablets or very small devices.
					Where the browser cannot be identified or compatibility issues are known, the <?php echo CMS_PROJECT_SHORTNAME; ?> will use inline style.
				</li>
			</ul>
			<p class="page_config">
				The general arrangement of the <?php echo CMS_PROJECT_SHORTNAME; ?> window layout sections is;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;Header&quot; - top section of the window.
					This can be the standard web page header from the <?php echo CMS_PROJECT_SHORTNAME; ?> which contains standard features.
					The standard features can be configured by the administer.
					Or the entire header can be replaced with a customer header.
					Or the header can be turned off.
					If the left column is turned off and the navigation bar is turned off, panel drop boxes are used to display tool and administration links.
					The header is identified by the HTML by &lt;div id=&quot;cms_header&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Left Column&quot; -  when enabled and displayed,
					occupies the left side of the window between the header and footer.
					The left column displays tool links and administration links.
					If no tools are setup and no user is logged in, the left column is not displayed.
					The left column can be turned off, then other means are used to display tool administration link, either in the header or in the navigation bar.
					The left column is identified by the HTML by &lt;div id=&quot;cms_left_column&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Right Column&quot; -  when enabled and displayed,
					occupies the right side of the window between the header and footer.
					The right column displays tool links and administration links.
					If no tools are setup and no user is logged in, the right column is not displayed.
					The right column can be turned off, then the tools and adminstration links are displayed in the left column.
					If the left column is turned off the right column is also turned off and other means are used to display tool administration link, either in the header or in the navigation bar.
					The right column is identified by the HTML by &lt;div id=&quot;cms_right_column&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Navigation Bar&quot; (Nav Bar) -  when enabled,
					is a narrow horizontal links bar that occupies the window to the right side of the left column, under the header and above the page body.
					The contents of the nav bar are configured in the Config settings.
					If there are tools enabled and if the nav bar size allows, all the tool links are placed in on the nav bar as single items.
					If the left column is turned off, the tool links and administration links are added to the nav bar.
					The navigation bar is identified by the HTML by &lt;div id=&quot;cms_navbar_wlc&quot;&gt;...&lt;/div&gt; with a left column or
					with a left column and a right column (three column mode, i.e. left column, page body, right column)
					the navigation bar is identified by the HTML by &lt;div id=&quot;cms_navbar_wlrc&quot;&gt;...&lt;/div&gt; or
					without a left column (by process no right column neither) has &lt;div id=&quot;cms_navbar_nolc&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Page Body&quot; -  occupies the remaining window area,
					written by the web site&rsquo;s author.
					This is the window area that displays the web site&rsquo;s content.
					Although the sections other than the page body have automatically generated default content,
					the page body section has number of extra html code features (including javascript support) to
					simplify code and enhance effects for overlays and ajax data presetation.
					The page body is identified by the HTML by &lt;div id=&quot;cms_page_body_wlc&quot;&gt;...&lt;/div&gt; with a left column or
					with a left column and a right column (three column mode, i.e. left column, page body, right column)
					the page body is identified by the HTML by &lt;div id=&quot;cms_page_body_wlrc&quot;&gt;...&lt;/div&gt; or
					without a left column (by process no right column neither) has &lt;div id=&quot;cms_page_body_nolc&quot;&gt;...&lt;/div&gt;
					Inside the page body &lt;div&gt; there are sub &quot;&lt;div&gt;s&quot; for HTML page body control and access.
				</li>
				<li class="page_config">
					&quot;Footer&quot; - bottom section of the window.
					This can be the standard web page footer from the <?php echo CMS_PROJECT_SHORTNAME; ?>
					which contains standard features.
					The standard features can be configured by the administer.
					Or the entire footer can be replaced with a customer header.
					Or the footer can be turned off.
					The footer is identified by the HTML by &lt;div id=&quot;cms_footer&quot;&gt;...&lt;/div&gt;
				</li>
			</ul>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config"><b>IMPORTANT NOTES:</b></p>
			<p class="page_config">If the navigation bar is enabled it takes priority over layout options.</p>
			<p class="page_config">
				If no navigation bar, left column or right column layouts are selected,
				the layout generator uses the <b>default layout</b> and
				places the &quot;Menu&quot;, &quot;Tools&quot; and &quot;Admin&quot;
				drop down panels in the header to provide user interaction.
				<br>
				<b>NOTE:</b> If a custom header is provided in this layout configuration,
				the programmer needs to provide for user interaction.
			</p>
			<p class="page_config">For &quot;tiny&quot; devices
				(e.g. small screen devices, mobile phones, etc.)
				the layout uses the <b>default layout</b>.
			</p>
			<p class="page_config">For &quot;tablet&quot; devices use the layout as configured.
				Except <?php echo CMS_PROJECT_SHORTNAME; ?> allows the tablet to treat the first touch on the drop down as an open click.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="SetupConfiguration"></a>
			Static Setup and Configuration
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">Use a recommended administration web browser.</p>
			<p class="page_config">
				After logging into the <?php echo CMS_PROJECT_SHORTNAME; ?>,
				an &quot;Admin&quot; menu in the left column (default),
				in the header (as a drop down) or
				on the Nav Bar (as a drop down),
				depending on any previous settings, will appear.
				The contents of the &quot;Admin&quot; menu are self explanatory, having tooltips (i.e. small pop up boxes with explanatory text) for each link.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> comes with an AD/LDAP authentication and search on login system.
				The authentication provides username and password login function, and optionally a AD/LDAP directory search function.
				The search function is mainly intended for local application and not directly used by the <?php echo CMS_PROJECT_SHORTNAME; ?>.
				There is optional AD/LDAP authentication search parameters available to interrogate the AD/LDAP server.
				The search results are placed in the &#36;_SESSION['ldap'] array for use by application code and is available across sessions.
				The contents of &#36;_SESSION['ldap'] are removed at logout.
				The AD/LDAP operation is controlled by installation settings in the &quot;Admin-&gt;Install&quot; in the &quot;Auth Settings&quot; section
				(more information available under &quot;Auth Settings&quot;-&gt;&quot;Comments/Help&quot;).
			</p>
			<p class="page_config">
				After installation or update, the following guide is useful;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Suggest checking out the &quot;Admin&quot; links to get a feel for the available settings.
				</li>
				<li class="page_config">
					If looking for a possible setting, try the &quot;Admin-&gt;Search&quot; link.
				</li>
			</ul>
			<p class="page_config">
				To further the general control and operation of the web site, the following maybe useful;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Web site administrators can redirect the web site to another URL.
					Administrator can still login (using the &quot;https://your.web.site/site_alias/login.php&quot; URI) and administrator the site.
				</li>
				<li class="page_config">
					Web site administrators can close the web site.
					Administrator can still login (using the &quot;https://your.web.site/site_alias/login.php&quot; URI) and administrator the site.
				</li>
			</ul>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> settings are stored &quot;<?php echo ETC_MAN_INI_DIR; ?>cms.ini&quot;.
				The applications settings are stored in &quot;<?php echo ETC_MAN_INI_DIR; ?>apps.ini&quot;.
				The INI files are editable text files that can be changed in case of problems (typically during application development).
				Usually these values are changed through the Admin -&gt; menus
				(which requires a <?php echo CMS_PROJECT_SHORTNAME; ?> system administrator to allow changes).
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> configuration is stored in a database (SQLite  by default or MySQL).
				These configuration values are permanent settings (e.g. support email, web site name, contact details, plug-in configs, etc.)
				and can be considered like hard coded values, and only changed through the Admin -&gt; menus
				(which requires a <?php echo CMS_PROJECT_SHORTNAME; ?> system administrator to allow changes).
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="RunTime"></a>
			Applying Run Time Settings and Configurations
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> provides the mechanisms for run time definition of constants;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					All settings and configuration values are defined when &quot;https://your.web.site/site_alias/index.php[?optional_parameters]&quot; is engaged.
					As all operations URLs generated by the <?php echo CMS_PROJECT_SHORTNAME; ?> contains the parameters for the required operation.
					And consequently the run time definitions are defined as part of the normal processing.
				</li>
				<li class="page_config">
					When calling AJAX operations through the &quot;https://your.web.site/site_alias/cms/cms_ajax.php?parameters&quot;
					the <?php echo CMS_PROJECT_SHORTNAME; ?> AJAX pre-processor defines the settings and configuration values.
				</li>
				<li class="page_config">
					However, in some cases the standard &quot;'index.php&quot; or &quot;cms_ajax.php&quot; URIs
					may not appropriate (typically CLI code), the best way to get the settings and
					configuration values defined is to;-<br>
					<pre class="page_config">require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );</pre>
					<br>at the top of the opening PHP file.
					This will provide the minimum run code for setting up definitions.
				</li>
			</ul>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> provides the five types of definitions identifiable by the prefixes in order of execution;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;INI_&quot; are the <?php echo CMS_PROJECT_SHORTNAME; ?> settings.
					The first definitions to get run time code.
					These are in &quot;<?php echo ETC_MAN_INI_DIR; ?>cms.ini&quot;.
				</li>
				<li class="page_config">
					&quot;CMS_C_&quot; are the <?php echo CMS_PROJECT_SHORTNAME; ?> configuration values.
					The second definitions to get run time code.
					These are in SQLite (&quot;<?php echo ETC_MAN_SQLITE_DIR . INI_DB_SQLITE_DATABASE; ?>&quot; or MySQL) <?php echo CMS_PROJECT_SHORTNAME; ?> database.
				</li>
				<li class="page_config">
					&quot;LMC_&quot; are the <?php echo CMS_PROJECT_SHORTNAME; ?> are used for the &quot;Links Manager&quot;.
					And are not used by applications.
					These are in SQLite (&quot;<?php echo ETC_MAN_SQLITE_DIR . INI_DB_SQLITE_DATABASE; ?>&quot; or MySQL) <?php echo CMS_PROJECT_SHORTNAME; ?> database.
				</li>
				<li class="page_config">
					&quot;APPs_(APP_NAME)_&quot; (i.e. lowercase &quot;s&quot;) are the statndard applications settings.
					from the <?php echo CMS_PROJECT_SHORTNAME; ?> database &quot;bodies&quot; table.
					<br>
					<b>NOTE:</b> Changing name and directory values in the Admin -&gt; Pages / Apps menu will require changing definition constants in the code.
				</li>
				<li class="page_config">
					&quot;APPS_&quot; (i.e. uppercase &quot;S&quot;) are the common applications settings.
					These are in &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>apps_config.php&quot;.
				</li>
				<li class="page_config">
					&quot;APP_&quot; are an individual application settings.
					The last definitions to get run time code.
					These are in &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/include/app_config.php&quot;.
				</li>
			</ul>
			<p class="page_config">
				<b>Notes on Recommended Mode Definitions</b>;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					For code running in command line (CLI) mode it is recommened that &quot;CLI_MODE&quot; is defined as &quot;true&quot;.
					This improves CLI operation and reduces the run time over head.
				</li>
			</ul>
			<p class="page_config">
				As a system administrator and with the debug mode enabled,
				the defined values at run time can found (and there definition)
				in the Admin -&gt; Debug page.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="DynamicConfiguration"></a>
			Dynamic Configuration
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Subsequently to the static setup configuration, the <?php echo CMS_PROJECT_SHORTNAME; ?> can use dynamic control configuration plugins for INI file values at the time of user engagement.
				The dynamic control plugins needs to be included in the included plugins configuration setting (&quot;CMS_C_ENABLED_PLUGINS&quot; setting).
			</p>
			<p class="page_config">
				Dynamic control uses a macro based on the &quot;<?php echo Ccms::MACRO_DELIM; ?>class::method<?php echo Ccms::MACRO_DELIM; ?>&quot; format, where the &quot;class&quot; is a user supplied plugin class name in
				&quot;<?php echo APPS_FS_PLUGINS_DIR; ?>&quot; directory.
				The &quot;method&quot; is the user supplied static method in the &quot;class&quot;.
				The dynamic control plugin also has a static method to identify it as a dynamic controller, &quot;is_dynamic_controller()&quot; which returns &quot;true&quot; if it is a dynamic control plugin.
				Otherwise it is not present or returns &quot;false&quot;.
				See <a href="index.php?cms_action=cms_manual#Plugins">Plugins</a> for more information on plugins.
			</p>
			<p class="page_config">
				The &quot;KeyName&quot; from the INI file are supplied to the &quot;class::method&quot; as formal function parameters.
				e.g. &quot;class_name::method_name(Keyname);&quot;.
			</p>
			<p class="page_config">This allows dynamic configuration to be implemented (e.g. by user name, by group, etc.) to set <?php echo CMS_PROJECT_SHORTNAME; ?> definitions to dynamic states at web page generation.</p>
			<p class="page_config">NOTE: Dynamic configuration is NOT intended for theme options as the theme is set when the save button is clicked.</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Apps"></a>
			Applications
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has a local applications directory at &quot;<?php echo APPS_WS_DIR; ?>&quot;, for the installation of applications and provide greater flexibility.
				The application directory provides somewhere to put local applications.
				This provides scope for larger and/or more free form code.
				The layout of the file structure under the &quot;<?php echo APPS_WS_DIR; ?>&quot; is under the local web programmer's control.
			</p>
			<p class="page_config">
				However, the <?php echo CMS_PROJECT_SHORTNAME; ?> requires some directory structure to allow code integration.
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;<?php echo PAGES_BODIES_DIR; ?>&quot; - the application control directory.
					This directory has the initial code files (referred as &quot;body files&quot;) or links for each application.
					For most applications, the code file may contain some configuration code and/or an include statement to code in the &quot;<?php echo APPS_WS_DIR; ?>&quot; directory.
				</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>&quot; - the application base directory.
					See <a href="index.php?cms_action=cms_manual#DirectoryStructure">Directory Structure</a> for directory information.
				</li>
				<li class="page_config">&quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>&quot; - the include directory.</li>
				<li class="page_config"> &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>apps_manual.php&quot; - a technical manual for applications.
						There is an example file, &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>example_apps_manual.php&quot;</li>
					<?php if((file_exists(APPS_FS_APPS_MANUAL)) && (is_readable(APPS_FS_APPS_MANUAL))) { ?>
						In <a href="index.php?action=apps_manual"><?php echo CMS_C_CO_NAME; ?> Applications Technical Manual</a>.
					<?php	} // if ?>
				<li class="page_config">&quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>apps_config.php&quot; - fixed configuration values for apps runtime (optional).
						There is an example file, &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>example_apps_config.php&quot;</li>
				<li class="page_config">&quot;<?php echo APPS_MAN_INI_DIR; ?>&quot; - the ini directory (the settings and install pages look in here).</li>
				<li class="page_config">&quot;<?php echo ETC_MAN_INI_DIR; ?>apps.ini&quot; - the combined applications settings (one file to spped normal access).</li>
				<li class="page_config">&quot;<?php echo APPS_MAN_INI_DIR; ?>apps.defaults.ini&quot; - the common default applications related settings.</li>
				<li class="page_config">&quot;<?php echo APPS_MAN_INI_DIR; ?>apps.comments.ini&quot; - the descriptions/help text of common applications related settings.</li>
				<li class="page_config">&quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>classes/&quot; - the general applications classes directory (the autoloader looks in here for general apps classes).</li>
				<li class="page_config">&quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>plugins/&quot; - the general applications plugins directory (the autoloader looks in here for general apps plugins).</li>
			</ul>
			<p class="page_config">
				Applications with an &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/&quot; directory have these individual application directories created for it.
				&quot;(APP_DIR)&quot; being the app directory name (or rename) given to the application.
				The &quot;(APP_DIR)&quot; directory provides modularity and separation to applications.
				And to allow automated application install and uninstall.
				<br>
				<b>NOTE:</b> Applications can be allowed to share the same application directory (Admin -&gt; Search -&gt; CMS_C_ALLOW_APPS_DIR_SHARE).
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/include/&quot; - application specific include directory.
				</li>
				<ul class="page_config">
					<li class="page_config">
						&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/include/app_config.php&quot; - application specific fixed configurations (the <?php echo CMS_PROJECT_SHORTNAME; ?> includes this file &quot;Admin -&gt Apps Config&quot; menu if present).
					</li>
					<li class="page_config">
						&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/include/app_css.php&quot; - application specific theme recipe file (the <?php echo CMS_PROJECT_SHORTNAME; ?> includes this file if present).
						The inputs to theme are taken the &quot;(APP_KEY)_ThemeSettings&quot; section of the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/ini/app.comments.ini&quot; values.
						This is used to generate the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/stylesheets/app.css&quot; file.
					</li>
				</ul>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/classes/&quot; - application specific classes directory
									(the autoloader looks in here for app specific classes).</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/plugins/&quot; - application specific plugins directory
									(the autoloader looks in here for app specific plugins).</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/ini/&quot; - application specific configuration.</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/ini/app.comments.ini&quot; - application menu control and help file (the <?php echo CMS_PROJECT_SHORTNAME; ?> places these configs in the &quot;Admin -&gt; App Config&quot; menu).</li>
					<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/ini/app.defaults.ini&quot; - application default values file (the <?php echo CMS_PROJECT_SHORTNAME; ?> uses these values as default config values in the &quot;Admin -&gt; App Config&quot; menu if present).</li>
					<li class="page_config">The &quot;app.comments.ini&quot; and &quot;app.defaults.ini&quot; are always used as a pair.
									The configured values are stored in the &quot;<?php echo ETC_MAN_INI_DIR; ?>apps.ini&quot;
									and are defined as global constants prefixed by &quot;APP_(APP_KEY)_&quot;.
									The comments and values appear in the results in the &quot;Admin -&gt; Search&quot;.
					</li>
					<li class="page_config">The &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/ini/&quot; may have an application specific control JSON file here. It is not assumed to be configured through the <?php echo CMS_PROJECT_SHORTNAME; ?> menus and would be accessed by the application.</li>
				</ul>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/cli/&quot; - application specific command line code.</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/lib/&quot; - application specific library code.</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/icons/&quot; - application specific icons (the icon selector will list icons in this directory).</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/images/&quot; - application specific images (the image selector will list images in this directory).</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/backgrounds/&quot; - application specific background images (the background icon selector will list images in this directory).</li>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/javascript/&quot; - application specific javascript code.</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/javascript/app.js&quot; - application specific javascript
									code, added by application author.
									When the the application is called the <?php echo CMS_PROJECT_SHORTNAME; ?> inserts a javascript link to the
									&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/javascript/app.js&quot; file in the &lthead&gt html,
									loading the javascript file automatically.
					</li>
				</ul>
				<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/stylesheets/&quot; - application specific stylesheets.</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/stylesheets/app.css&quot; - application specific stylesheet
									containing the CSS code produced by the <?php echo CMS_PROJECT_SHORTNAME; ?>
									running the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/include/app_css.php&quot; theme generator code
									against the &quot;[(APP_KEY)_ThemeSettings]&quot; section in the &quot;<?php echo ETC_MAN_INI_DIR; ?>apps.ini&quot; settings are saved.
									When the the application is called the <?php echo CMS_PROJECT_SHORTNAME; ?> inserts a stylesheet link to the
									&quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/stylesheets/app.css&quot; file in the &lthead&gt html,
									loading the stylesheet automatically.
					</li>
				</ul>
		</ul>
			<p class="page_config">
				The Admin -&gt; App Config -&gt; checks to see if a &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>apps_css.php&quot; is present.
				If so the save process generates a &quot;<?php echo ETC_WS_CSS_DIR; ?>apps.css&quot; from the &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>apps_css.php&quot; for use in application web pages.
				This can be used to set extra theme or branding settings into the applications style sheet.
				The &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>example_apps_css.php&quot; is provided to help.
			</p>
			<p class="page_config">The application installation check method &quot;public static function do_app_warnings()&quot;<br>
				Optional method in the application&rsquo;s top class (e.g. "<?php echo APPS_FS_DIR; ?>(APP_DIR)/classes/(APP_NAME)_app::do_app_warnings()").
				If present the do_app_warnings() method is called when an admin logs in.
				This can be used to check the application has all the system packages, etc. it needs to operate.
				<br>NOTE: The top (or primary) application class needs to conform to &quot;_app&quote; class name suffix.
			</p>
			<p class="page_config">The application post ini settings saved method &quot;public static function do_app_ini_saved()&quot;<br>
				Optional method in the application&rsquo;s top class (e.g. "<?php echo APPS_FS_DIR; ?>(APP_DIR)/classes/(APP_NAME)_app::do_app_ini_saved()").
				If present the do_app_ini_saved() method is called after an admin saves the application config page.
				This can be used to make changes to an applications runtime configuration (e.g. reset caches, generate API URLs, etc.).
				<br>NOTE: The top (or primary) application class needs to conform to &quot;_app&quote; class name suffix.
			</p>
			<p class="page_config">
				The &quot;<?php echo ETC_MAN_INI_DIR; ?>apps.ini&quot;, &quot;<?php echo APPS_MAN_INI_DIR; ?>apps.defaults.ini&quot;
				and &quot;<?php echo APPS_MAN_INI_DIR; ?>apps.comments.ini&quot; global (all applications) configuration files that are
				used together to a connection between help messages, default values and the config values.

				(Use the &quot;<?php echo ETC_MAN_INI_DIR; ?>cms.ini&quot;, &quot;<?php echo CMS_MAN_INI_DIR; ?>cms.defaults.ini&quot;
				and &quot;<?php echo CMS_MAN_INI_DIR; ?>cms.comments.ini&quot; files as an example.)

				When present, the settings are managed by &quot;Admin -&gt; App Config&quot; menu,
				are read in and values are defined with a prefix of &quot;APP_&quot; plus the ini file keyname for use in the code.
				There are example in &quot;<?php echo ETC_MAN_INI_DIR; ?>example.apps.ini&quot;, &quot;<?php echo APPS_MAN_INI_DIR; ?>example.apps.defaults.ini&quot;
				and &quot;<?php echo APPS_MAN_INI_DIR; ?>example.apps.comments.ini&quot; to help.
			</p>
			<p class="page_config">
				The access to the local applications is controlled by the <?php echo CMS_PROJECT_SHORTNAME; ?> authentication.
				A <?php echo CMS_PROJECT_SHORTNAME; ?> authenication plugin is provided in the <?php echo CMS_PROJECT_SHORTNAME; ?>.
			</p>
			<p class="page_config">
				By default, direct (authorised or not) access to files in &quot;.<?php echo APPS_WS_DIR; ?>&quot; directory is denied.
				Access should be provided from page body contents pages/code.
				This ensures root document jumps are not possible.
			</p>
			<p class="page_config">
				A note on apps classes; it is recommended that the base class on all apps classes should be Ccms_app_bass
				(e.g Cmy_class extends Ccms_app_base ).
				The Ccms_app_base class provides interface to the main <?php echo CMS_PROJECT_SHORTNAME; ?> and provides general functionality.
			</p>
			<p class="page_config">
				Examples of local applications are;- web page content provided by high level programming, specialized interface displays, just to name a few.
				Example files are given in the &quot;<?php echo CMS_WS_EXAMPLES_DIR; ?>&quot; directory to help show how to best these features of the <?php echo CMS_PROJECT_SHORTNAME; ?>.
			</p>
			<p class="page_config">
				Applications may require secure access to inbuilt APIs via SSL on the HTTPS protocol.
				To aid in providing secure access the <?php echo CMS_PROJECT_SHORTNAME; ?> monitors the called
				PHP code for &quot;api.php&quot; and can by configuration force SSL to be be used by redirection.
				If the API client cannot redirect, the client will be disconnected.
			</p>
<?php if((file_exists(APPS_FS_APPS_MANUAL)) &&
		(is_readable(APPS_FS_APPS_MANUAL))) { ?>
			<p class="page_config">
				See also <a href="index.php?action=apps_manual"><?php echo CMS_C_CO_NAME; ?> Applications Technical Manual</a>.
			</p>
<?php	} // if ?>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="AppTypes">
			Types of Applications
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Application types in <?php echo CMS_PROJECT_SHORTNAME; ?>;-
			</p>
			<?php echo Ccms_DB_checks::get_apps_types_descriptions(); ?>
			<p class="page_config">
				When the app / body is created or edited, the recommended sub-directories for the type of
				application are checked / created when saved. When an application directory is changed
				then the application directory is moved to the new directory.
			</p>
			<p class="page_config">
				When an application is used, the defined constants for the application directories
				are also generated, negating the need to manually create them (see Admin -&gt; <?php echo CMS_PROJECT_SHORTNAME; ?> Debug).
				These auto-generated body / app constants are prefixed with &quot;APPs_&quot; to distinguish them from the fixed/standard constants
				(standard constants/defines are prefixed with &quot;APPS_&quot; or &quot;APP_&quot;)
				(i.e. &quot;APPs_FS_*&quot; for filesystem access and &quot;APPs_WS_*&quot; for web access).
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="AppClass"></a>
			Primary Application Class
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				All applications can have a primary application class.
				For standard applications and close coupled applications the class is located in the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/classes/(APP_NAME)_app.php&quot; PHP source file.
				For other applications the class is located in the &quot;<?php echo APPS_MAN_CLASSES_DIR; ?>(APP_NAME)_app.php&quot;,
				the C(APP_NAME)_app PHP class source file code.
			</p>
			<p class="page_config">
				The C(APP_NAME)_app class, the primary application class provide hierarchical access to the following optional methods;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;public static function get_ajax_text($ajax)&quot;<br>
					Executes the applications AJAX code.
					<br>
					Optional method.
				</li>
				<li class="page_config">&quot;public static function do_app_warnings()quot;<br>
					Checks the application requirements when the user logs in.
				</li>
				<li class="page_config">&quot;public static function is_app_setup_key_funcs_used($key)&quot;<br>
					The Admin -&gt; Apps Config menu calls this method (function) for every KEY in the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns false;
					Else the method returns true.
					<br>
					<b>Required if</b> &quot;show_app_setup_value()&quot; or &quot;input_app_setup_form_text()&quot; or &quot;get_app_setup_form_value()&quot; is in use.
					Otherwise an optional method.
				</li>
				<li class="page_config">&quot;public static function show_app_setup_value($sect,$key,$name,$value)&quot;<br>
					The Admin -&gt; Apps Config menu calls this method (function) for every KEY=VALUE pair in the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns false;
					Else the method generates text to show the $value for $key.
					<br>
					Used as &quot;_show_func&quot; similar to JSON format. Optional method.
				</li>
				<li class="page_config">&quot;public static function input_app_setup_form_text($sect,$key,$name,$value)&quot;<br>
					The Admin -&gt; Apps Config menu calls this method (function) for every KEY=VALUE pair in the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns false.
					Else the method generates form input element text to input the $value for $key using $name for the input element.
					<br>
					Used as &quot;_form_input_func&quot; similar to JSON format. Optional method.
				</li>
				<li class="page_config">&quot;public static function get_app_setup_form_value($sect,$key,$name,$value)&quot;<br>
					The Admin -&gt; Apps Config menu calls this method (function) for every KEY=VALUE pair in the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns null (i.e. no input from form)
					Else the method gets the input element under $name from the posted form returns the value text to be saved.
					<br>
					Used as &quot;_form_get_func&quot; similar to JSON format. Optional method.
				</li>
				<li class="page_config">&quot;public static function &get_ini_app_input_ctl()&quot;<br>
					This method provides access to a HTML input generator for the applications INI settings to allow the application to.
					control (possibly generate if 'options_func' is provided) the form input elements.
					An example of the returned control array is;-<br>
					<pre class="page_config">
		static $my_ini_ctls = array(
			'MY_CUSTOM_COLOURS' => array(	// ini_key to match
				'type' => 'multi_input',	// input or multi_select
				'col_heads' => 'Name:Hex RGB Colour',	// e.g. "Name" is first column heading : "Hex RGB Colour" is second column heading, etc.
				'val_sep' => ':',	// separator used values
				'data_sep' => '=',	// separator between name and value (e.g. name=>value), optional
				'options_func' => 'get_my_custom_colours_options',	// method name to use in the primary application class, optional.
				),
			// etc,
		return $my_ini_ctls;	// it's a reference (i.e. static)
					</pre>
				</li>

			</ul>
<!--			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The &quot;$key&quot; variable will be prefixed by the (APP_KEY).
			</p>-->
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Plugins"></a>
			Plug Ins
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<b>NOTE:</b> Plug Ins (commonly referred to as Plugins) have an important difference to classes (although a plugin is a class),
				in that a plugin has its own set of configuration features.
				And can be enabled or disabled by configuration.
			</p>
			<p class="page_config">
				Users defined plugins can be placed in &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>plugins&quot; or in the &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/plugins/&quot;.
				The plugin class needs to be extended from the &quot;Ccms_plugin_base&quot; class (e.g. &quot;class Cmy_plugin_class_name extends Ccms_plugin_base&quot;, The &quot;C&quot; prefix is a convention adopted in the &quot;<?php echo CMS_PROJECT_SHORTNAME; ?>&quot; for classes and plugins.).
				And appear in the &quot;Admin -&gt; Config&quot; page prefixed with &quot;Plugin&quot;.
			</p>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The <?php echo CMS_PROJECT_SHORTNAME; ?> class autoloader finds classes and plugins by their PHP filename and the class name being the same (removing any &quot;C&quot; prefix).
				The class file may have hidden classes, not directly loaded by the autoloader, within the autoloaded class file which are included in the primary PHP class map upon reading the autoloaded class file.
			</p>
			<p class="page_config">
				<?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?> provides the following included plugins in the &quot;<?php echo CMS_FS_PLUGINS_DIR; ?>&quot; directory;
			</p>
			<ul class="page_config">
				<li class="page_config">
					Social Media - a plugin to interface a group of social media sub-plugins;
					<ul class="page_config">
						<li class="page_config">
							Facebook - a general Facebook &reg; sub-plugin.<br>
							NOTE: At this time, the &quot;center_right&quot; position, the Facebook generated fly out goes off the right side of the screen and cannot be viewed, it is disabled at this position.
						</li>
						<li class="page_config">
							Linkedin - a general Linkedin &reg; sub-plugin (not displayed on most tablet devices).
						</li>
					</ul>
					Social media links are not displayed on tiny devices (e.g. iPods, iPhones, etc).
				</li>
				<li class="page_config">
					Email - a general server side email plugin for use with other plugins.
				</li>
				<li class="page_config">
					Gotcha - a security plugin for use with the Email plugin, etc.
				</li>
				<li class="page_config">
					Contact Us - a standardized server side contact us web code/page generator plugin.
				</li>
				<li class="page_config">
					Map Latitude Longitude - a standardized server side map code/page generator plugin.
					A basic implementation intended to show location for &quot;contact us&quot; pages is included.
				</li>
				<li class="page_config">
					Authentication - a standardized external authentication that provides a method to authenticate from external sources.
					Takes a local application plugin_name and uses the plugin_name::auth(username,password) method to authenticate users.
				</li>
				<li class="page_config">
					Media Converter - a media converter plugin for converting files (e.g. Markdown .md and text .txt) to html format.
					And to encapsulate images (e.g. mp4, .png, .gif, etc.) for the user&rsquo;s web site.
					Engaged by using &quot;Ccms_media_conv_plugin::get_file_href(URI,NAME)&quot; to generate the link.
					The files are shown are in standard page for the user&rsquo;s web page (i.e. branded to the user&rsquo;s branding).
					The media plugin is primarily intended for documentation purposes.
					<br>
					<b>WARNING:</b> The plugin will not show external information (i.e. from outside this web site scope).
				</li>
			</ul>
			<p class="page_config">
				A &quot;<?php echo CMS_MAN_EXAMPLE_BODIES_DIR; ?>example_cms_body.php&quot; is available to help show how to use some plugins and local applications.
				The &quot;_body&quot; suffix in the filename is recommended to avoid filename clashes.
			</p>
			<p class="page_config">
				A &quot;<?php echo CMS_MAN_EXAMPLE_BODIES_DIR; ?>example_welcome_cms_body.php&quot; is available to help show how to use the a &quot;full view&quot; welcome or splash page using the <?php echo CMS_PROJECT_SHORTNAME; ?> facilities.
			</p>
			<p class="page_config">
				A &quot;<?php echo CMS_MAN_EXAMPLE_BODIES_DIR; ?>example_contactus_cms_body.php&quot; is available to help show how to use the Ccms_contactus plugin.
			</p>
			<p class="page_config">
				A &quot;<?php echo CMS_MAN_EXAMPLE_BODIES_DIR; ?>example_login_cms_body.php&quot; is available to help show a custom login page.
			</p>
			<p class="page_config">
				A &quot;<?php echo CMS_MAN_EXAMPLE_BODIES_DIR; ?>example_modal_test.php&quot; is available to help show how to use the Ccms_modal class with the Ccms_contactus plugin.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="AppsAuth"></a>
			Applications Authentication
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				In addition to the local applications the <?php echo CMS_PROJECT_SHORTNAME; ?> can use a user provided authentication.
				The &quot;Capps_auth&quot; class is the &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>classes/apps_auth.php&quot; class file.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> requires the &quot;Capps_auth&quot; to have following public static methods;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;public static function is_page_allowed($name)&quot;<br>
					Returns true if page is allowed.
					Used for fine control of pages.
				</li>
				<li class="page_config">&quot;public static function is_navbar_element_allowed($name)&quot;<br>
					Returns true if nav bar element is allowed.
					Used for fine control of nav bar elements.
				</li>
				<li class="page_config">&quot;public static function login($user, $password)&quot;<br>
					Authenticates the $user (per application requirements).
					If authenticated, executes any application login code
					and returns &quot;true&quot; else return &quot;false&quot; for login denied.
				</li>
				<li class="page_config">&quot;public static function init($user)&quot;<br>
					Called just after the web server session has started and the $_SESSION variables are available.
					The user value will be false if no user is logged in or the user name if logged in.
					This is for applications initialization.
					If &quot;init($user)&quot; is ok it returns &quot;true&quot;.
					Else returns &quot;false&quot; for denied
					(and will subsequently log the user out of the <?php echo CMS_PROJECT_SHORTNAME; ?>).
				</li>
				<li class="page_config">&quot;public static function is_login_current()&quot;<br>
					Used to check if apps user is still current with a remote second authenticator, possibly.
					Return null is not used or don't know, false = no, true = logged in still,
				</li>
				<li class="page_config">&quot;public static function logout()&quot;<br>
					Log out current user (per application requirements).
					If logged in it returns &quot;true&quot; else return &quot;false&quot; if not logged in.
				</li>
				<li class="page_config">&quot;public static function get_short_name()&quot;<br>
					Provides a short name (e.g. a well known acronym) that is suitable user selection text (i.e. in a drop down).
				</li>
				<li class="page_config">&quot;public static function get_title()&quot;<br>
					Provides a title for the authentication method (i.e. text for tooltip or bubble).
				</li>
				<li class="page_config">&quot;public static function get_JS()&quot;<br>
					Provides the APP AUTH login javascript, if used (called before get_html).
				</li>
				<li class="page_config">&quot;public static function get_html()&quot;<br>
					Provides the APP AUTH login html, if used.
				</li>
				<li class="page_config">&quot;public static function do_apps_warnings()&quot;<br>
					Optional method. If present the Capps_auth::do_apps_warnings() method is called when an admin logs in.
					The do_apps_warnings() can be used to check that the system requirements are met.
				</li>
			</ul>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The &quot;Capps_auth&quot; class provides authentication only for the <?php echo CMS_PROJECT_SHORTNAME; ?>.
				It does not provide the <?php echo CMS_PROJECT_SHORTNAME; ?> login execution code.
				Other application code is engaged by the user supplied code.
			</p>
			<p class="page_config">
				An example at &quot;<?php echo APPS_MAN_INCLUDE_DIR; ?>classes/example_apps_auth.php&quot; file is included.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="AppsExtendPlugin"></a>
			Applications Extension Plug In
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				An applications extension plugin can be used (configured by the &quot;CMS_C_APPS_EXTEND_PLUGIN&quot; config key) to add entry/s to the Admin menu.
				This applications configuration extension plugin is common to all applications.
				This plugin is detected by having the filename suffix of &quot;_apps_extend.php&quot; in the application plugin directory and
				The plugin is placed in the &quot;<?php echo APPS_FS_PLUGINS_DIR; ?>&quot; directory so the <?php echo CMS_PROJECT_SHORTNAME; ?> can find it.
			</p>
			<p class="page_config">
				For single application extension plugin, use the &quot;is_app_extend()&quot; method to indicate an application has admin extensions available.
				This plugin is detected by having the filename suffix of &quot;_app_extend.php&quot; in the application plugin directory and
				the plugin &quot;C(APP_NAME)_app_extend_plugin&quot; class name.
			</p>
			<p class="page_config">
				The plugin needs to have the following static methods to integrate into the <?php echo CMS_PROJECT_SHORTNAME; ?>;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;public static function is_app_extend()&quot;<br>
					If present, usually returns true to indicate that this plugin/class in a single application extension
					and the extensions are available.
					The method is only present when an application has a discrete set of configuration methods for itself.
				</li>
				<li class="page_config">&quot;public static function get_admin_uris()&quot;<br>
					to add the entry/s to the Admin menu.
					The returned values are an array. For example in JSON form;-
					<pre class="page_config">
	{
		"0":{
			"text": "Setup App A",
			"uri": "apps/AppName/config.php", (can be a URL or a class::method or function)
			"title": "Setup App A ..." (optional)
		},
		"1":{
			"text": "Setup App B",
			"uri": "CsomeClass::someMethod", (can be a URL or a class::method or function)
			"title": "Setup App B ...", (optional)
			"app_name": "(APP_NAME)", (optional, used by uri, as required)
			"app_dir": "(APP_DIR)", (optional, used by the <?php echo CMS_PROJECT_SHORTNAME; ?> to include the application CSS and JS files)
			"no_body" true	(optional, set false if the uri does not provide its own page body, else the extension provides it complete page.
					the <?php echo CMS_PROJECT_SHORTNAME; ?> will a themed header, body containing the output and footer).
		},
	}
					</pre>
					NOTE: Local URLs are with reference to &lt;base href meta data in the page header.
				</li>
				<li class="page_config">&quot;public static function read_apps_extend_comments_ini()&quot;<br>
					Is used retrieve an array of the extended applications control JSON.
					This allows the controls to be searched.
					It is associated with index 0 from the &quot;get_admin_uris()&quot; return;
				</li>
				<li class="page_config">&quot;public static function read_apps_extend_settings_ini()&quot;<br>
					Is used to retrieve an array of the extended applications settings JSON.
					This allows the setting to be searched.
					It is associated with index 0 from the &quot;get_admin_uris()&quot; return;
				</li>
				<li class="page_config">&quot;public static function get_apps_extend_settings()&quot;<br>
					Is used generate the setup page from the extended applications settings JSONs and
					read in and save the POSTed data from the browser.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Localtools"></a>
			Local Tools
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has a local tools directory at &quot;<?php echo LOCAL_WS_TOOLS_DIR; ?>&quot;, for the installation of web based tools and extras.
				The local tools directory provides somewhere to put web applications / pages (tools).
				Each tool should be given a unique directory to occupy.
				Examples of tools are;- conversion tables, code checkers, procedures, manuals, just to name a few.
			</p>
			<p class="page_config">
				If you have tools installed on the host that are not under the &quot;<?php echo LOCAL_WS_TOOLS_DIR; ?>&quot; directory,
				these tools can be accessed by using a symlink.
				This allows these non-local tools to be appear in the Local Tools setup.
				<br><br>
				<b><u>Synlinked Local Tools EXAMPLES:</u></b><br>
				<b>On LINUX</b>, to setup HTdig, make a symlink by going to the &quot;<?php echo LOCAL_WS_TOOLS_DIR; ?>&quot; directory,
				and execute &quot;ln -s /usr/share/htdig htdig&quot;,
				where &quot;/usr/share/htdig&quot; is the path to the HTdig web pages.
				This allows HTdig to be used as the Local Tool.
				<br>
				A similar tool setup can used for the Apache Manual.
				Execute &quot;ln -s /var/www/manual Apache Manual&quot; in the &quot;<?php echo LOCAL_WS_TOOLS_DIR; ?>&quot; directory,
				where &quot;/var/www/manual&quot; is the path to the Apache Manual web pages.
			</p>
			<p class="page_config">
				During tool setup, the &quot;<?php echo LOCAL_WS_TOOLS_DIR; ?>&quot; directory is searched for filename extensions of .htm .php .html and .txt
				The tool could be a complete sub-web site.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="WYSIWYGs"></a>
			WYSIWYGs
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> can use WYSIWYG HTML page editors.
				WYSIWYGs are configured by using the <?php echo CMS_PROJECT_SHORTNAME; ?> WYSIWYG configuration editor.
				Use Admin -&gt; Search -&gt; &quot;location&quot; to find WYSIWYG configuration.
				WYSIWYGs are installed in the &quot;<?php echo APPS_WS_LIB_DIR; ?>&quot; library directory as a third party library.
				There is a simple default configuration in the &quot;<?php echo ETC_FS_CMS_WYSIWYGS; ?>&quot; file.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> WYSIWYG configuration element are;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					<b>title</b> - Title for WYSIWYG (not the name).
				</li>
				<li class="page_config">
					<b>type</b> - Type of WYSIWYG, select from browser, system, library or custom.
				</li>
				<li class="page_config">
					<b>comment</b> - A general comment about the WYSIWYG.
				</li>
				<li class="page_config">
					<b>library_uri</b> - An initialisation URI (typically to javascript, php, etc.) to setup the WYSIWYG (provided by WYSIWYG,optional).
				</li>
				<li class="page_config">
					<b>engage_class</b> - WYSIWYG engagement class. Used to extend the <?php echo CMS_PROJECT_SHORTNAME; ?> base WYSIWYG &quot;Ccms_wysiwyg&quot; class for more customisation.
					Typically, the &quot;engage_class&quot; overrides the &quot;library_uri&quot; and
					&quot;engage_uri&quot;, and the &quot;library_uri&quot; and &quot;engage_uri&quot; are empty.
					However, if the &quot;library_uri&quot; and &quot;engage_uri&quot; have values,
					the <?php echo CMS_PROJECT_SHORTNAME; ?> base &quot;Ccms_wysiwyg&quot; class will still engage these values.
					<br>
					The &quot;engage_class&quot; is used to extend the <?php echo CMS_PROJECT_SHORTNAME; ?> &quot;Ccms_wysiwyg&quot; class.
					The WYSIWYG code execution then uses to &quot;engage_class&quot;.
					The &quot;engage_class&quot; is usually custom code written for the particular WYSIWYG.
					If no &quot;engage_class&quot; is available, the <?php echo CMS_PROJECT_SHORTNAME; ?> falls back
					to using the &quot;library_uri&quot; and &quot;engage_uri&quot; values.
					<br>
					<b>Note:</b> if not overridden by the &quot;engage_class&quot;,
					a &lt;textarea&gt; with a id and name of &quot;ws_text_area&quot; containing the html
					to be edited by the WYSIWYG editor is generated.
				</li>
				<li class="page_config">
					<b>engage_uri</b> - The URI (typically javascript, php, etc.) to engage the WYSIWYG (usually a custom script,optional).
				</li>
				<li class="page_config">
					<b>configurable</b> - Boolean true/false value to indicate the WYSIWYG in configurable.
				</li>
				<li class="page_config">
					<b>enabled</b> - Boolean true/false to indicate whether the WYSIWYG is enabled.
				</li>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Sitemap"></a>
			Sitemap
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has a search engine compatible XML sitemap generator and a HTML sitemap generator builtin.
				As changes are made to configuration and contents of the web site, the sitemap is automatically updated.
				To manually update the sitemap goto &quot;http://your.web.site/site_alias/index.php?cms_action=update_sitemap&quot;.
				<br>
				NOTE: If the sitemap filename is not setup, no sitemap file is generated.
			</p>
			<p class="page_config">
				The XML sitemap is available at &quot;http://your.web.site/site_alias/<?php echo CMS_SITEMAP_XML_FILE; ?>.xml&quot; (replace &quot;your.web.site/site_alias/&quot; with your domain name and alias, if any, for <?php echo CMS_PROJECT_SHORTNAME; ?> installation).
				<br>
				The HTML sitemap is available at &quot;http://your.web.site/site_alias/<?php echo CMS_SITEMAP_HTML_FILE; ?>.xml&quot; (replace &quot;your.web.site/site_alias/&quot; with your domain name and alias, if any, for <?php echo CMS_PROJECT_SHORTNAME; ?> installation).
				<br>
				NOTE: The name of the sitemap can be configured in the &quot;Admin-&gt;Install-&gt;Xml Sitemap File&quot; setting.
				The primary link URL in the sitemap is the same URL in &quot;Admin-&gt;Config-&gt;Main Web Site URL&quot; setting.
			</p>
			<p class="page_config">
				The sitemap can be generated from the command line.
		`	</p>
`			<ul class="page_config">
				<li class="page_config">On a LINUX server, in a console shell, goto the web site&rsquo;s &quot;<?php echo CMS_MAN_CLI_DIR; ?>&quot; directory and run &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_generate_sitemap.sh&quot;.</li>
			</ul>
				Successful sitemap generation looks like this;-

			<pre class="page_config">
				Starting -&gt; sitemap generator for <?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?>.
				INFO: Created sitemap &quot;/web-site-root-directory/sitemap.xml&quot; (Link=sitemap.xml)
				Finished -&gt; sitemap generator for <?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?>.
			</pre>
			<p class="page_config">
				Where sitemap name is set to &quot;sitemap&quot;.<br>
				If any errors or warnings occurred, these will be printed out.
		`	</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="special_code"></a>
			Special Code
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has a special code directory for PHP code
				(e.g. for Google analytics code and social media code)
				at  &quot;<?php echo ETC_FS_EXT_INCLUDES_DIR; ?>&quot;.
				Any analytics (e.g. from Google) code or special socal media code should be placed in this directory.
				The code (usually PHP, HTML, javascript, etc.) is included at the appropiate point by the <?php echo CMS_PROJECT_SHORTNAME; ?>.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="coding_shortcuts"></a>
			Coding Shortcuts and Builtin Features
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has many coding shortcuts and builtin features that are accessible to applications.
				These include:-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Global Definitions - The <?php echo CMS_PROJECT_SHORTNAME; ?> works out where it is and presets the coders/programmers definitions with all the &quot;(DOCROOT)/&quot; file structure defined.
					It is important to use these &quot;defined&quot; constants to maintain future proofing your code.
					Login as an administrator (and turn on the debug mode if necessary) and click on &quot;Admin -&gt; <?php echo CMS_PROJECT_SHORTNAME; ?> Debug&quot;.
					This displays a searchable list of all the <?php echo CMS_PROJECT_SHORTNAME; ?> definitions.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					Base Classes (Objects) for Apps - The Ccms_app_base() class in intended to link in many <?php echo CMS_PROJECT_SHORTNAME; ?> methods for use in applications.
					The Ccms_app_base() class is actual a methods library/stack to provide common useful methods and provide correct access into the <?php echo CMS_PROJECT_SHORTNAME; ?> code.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					POSIX Class (static methods) for Apps - The Ccms_posix() class contains POSIX and operating system informational functions.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					Applications Configuration INI Settings and CSS Style Sheets - a <?php echo CMS_PROJECT_SHORTNAME; ?> maintained setup and themed stylesheets.
					<br>
					The <?php echo CMS_PROJECT_SHORTNAME; ?> has code to produce annotated columns and headings for settings that contain multiple values or name=value pairs
					in the &quot;<?php echo ETC_FS_APPS_CONFIG; ?>&quot; settings file.

					<br>
					There are examples in the &quot;<?php echo CMS_WS_EXAMPLES_DIR; ?>&quot; sub-directories.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					Dynamic Configuration - Allows the configuration settings to modified dynamically via another process (local or remotely) by user supplied code.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					LDAP/AD Authentication - Just setting the LDAP settings and enabling users to use LDAP/AD, user authentication can be used.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					Remote Authentication and Data Control Retrieval - This feature allows &quot;glue&quot; logic and application specific code to be implemented.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					Proxies - Two types of proxy types are implemented;-
					<ul class="page_config">
						<li class="page_config">
							A pseudo proxy to access files directly accessible by <?php echo CMS_PROJECT_SHORTNAME; ?>
							but not directly accessible from the client side.
							And to keep private files away from indexing / multiview generated pages.
							These files are usually on storage systems that are not part of the <?php echo CMS_PROJECT_SHORTNAME; ?> server file system.
							<br>
							These are implemented by a URI, for example &quot;cms/cms_proxy?proxy={object_signature}&quot;.
							Where the &quot;{object_signature}&quot; is genrates by the <?php echo CMS_PROJECT_SHORTNAME; ?>
							and stored in a database against the proxied file, and the file delivered as required on call.
							See the &quot;Ccms_proxy&quot; PHP class for more details.
						</li>
						<li class="page_config">
							HTTP / HTTPS reverse proxy to allow access to web sites/apps behind the the firewall.
							This uses an inbuilt reverse proxy mechanism that not require Apache or Nginx configs to implement.
							The reverse proxy is based on an <?php echo CMS_PROJECT_SHORTNAME; ?> application.
							The application type is set to &quot;Reverse Proxy&quot; and instead on providing an application body filename,
							a proxy destination URL is entered instead.
						</li>
						<li class="page_config">
							<B>Note:</b> There is no websocket proxy in the <?php echo CMS_PROJECT_SHORTNAME; ?>.
							Websockets proxies are best implemented on the web server with application websocket initiators over the
							<?php echo CMS_PROJECT_SHORTNAME; ?> application code.
						</li>
					</ul>
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					Geo Location - Geo location can be added to any form by including Ccms::Ccms::add_JS_geolcation_to_form() function.
					The latitude, longitude, accuracy and time are captured by the <?php echo CMS_PROJECT_SHORTNAME; ?> and store in the base classes (and also in the session data).
					The <?php echo CMS_PROJECT_SHORTNAME; ?> Ccontactus plugin and the standard footer uses the Geo location code and can provide detailed application information.
					The Geo location can be enabled/disabled, and the time to live (TTL) of the location can be set.
					Use Admin -&gt; Search -&gt; &quot;location&quot; to find the settings.
				</li>
			</ul>
			<ul class="page_config">
				<li class="page_config">
					INI / JSON File Configurator - The Ccms_edit() code class is used by the <?php echo CMS_PROJECT_SHORTNAME; ?> to configure install, theme and apps settings engine.
					It uses a suffix detection to generate the appropriate input element.
					The configurator uses a three file system,
					one containing the settings in use (e.g. cms.ini, apps.ini),
					one being a default settings file  (e.g. cms.default.ini, apps.default.ini)
					and one file containing and explanation of every setting in the first ini file  (e.g. cms.comment.ini, apps.comment.ini).
					These three files can also be used for JSON file types (e.g. .JSON) because the Ccms_edit() code class is abstracted from reading the files (by the caller providing the arrays) and therefore can be used with remote files.
					At present the depth off the arrays is limited to standard INI format (i.e. [section][name] = value).
					There is html element creation code is in Ccms_edit() code class.
					This can also be used for JSON file type settings also, with some extra features for generating input elements.
					<ul class="page_config">
						<li class="page_config">
							INI files are usually used where it maybe necessary to edit settings manually.
							INI files are used by the <?php echo CMS_PROJECT_SHORTNAME; ?> for this reason.
							However they only have a simple [sect_name]key = &quot;value&quot; scope and cannot given value type nor possible selections.
							To help the Ccms_edit class has the Ccms_options class as a base to key name suffixes to allow a limited number of selections.
							Mainly suitable for theme settings and basic true/false (boolean) settings.
						</li>
						<li class="page_config">
							The JSON file format allows a much broader scope for settings allowing type and selections settings controlled from the comments.JSON (i.e the controlling JSON).
							The &quot;apps_comments.json&quot; is the controlling entity for the Ccms_edit class.
							<br>
							For example;-
							<pre class="page_config"><?php readfile(CMS_WS_IMAGES_MANUAL_DIR . 'example_controls.json'); ?></pre>
						</li>
						<li class="page_config">
							The values are in the settings values JSON.
						</li>
						<li class="page_config">
							Where settings values JSON has an array under the key name the value array is not shown.
							The values are maintained in the settings value JSON.
						</li>
					</ul>
				</li>
				<li class="page_config">
					System information. The default location for these files
					is the &quot;<?php echo ETC_WS_EXT_INCLUDES_DIR; ?>&quot; directory.
					<br>
					The <?php echo CMS_PROJECT_SHORTNAME; ?> has mechanisms for displaying the web site&rsquo;s
					information to the Admin Users;-
					<ul class="page_config">
						<li class="page_config">
							&quot;<?php echo ETC_WS_EXT_INCLUDES_DIR . 'README.md'; ?>&quot; or
							&quot;<?php echo ETC_WS_EXT_INCLUDES_DIR . 'README.txt'; ?>&quot;
							contains the main web site&rsquo;s &quot;README&quot; file for display.
						</li>
						<li class="page_config">
							&quot;<?php echo ETC_WS_EXT_INCLUDES_DIR . 'ReleaseNotes.md'; ?>&quot; or
							&quot;<?php echo ETC_WS_EXT_INCLUDES_DIR . 'ReleaseNotes.txt'; ?>&quot;
							contains the main web site&rsquo;s &quot;Release Notes&quot; file for display.
						</li>
					</ul>
				</li>
				<li class="page_config">
					Client browser metadata. The <?php echo CMS_PROJECT_SHORTNAME; ?> provides an automated client metadata ajax response
					(along the cookie discussed above) from the client browser and is saved in the $_SESSION['clientMetadata'].
					This feature can be disabled/enabled by the configuration.
					It provides metadata feedback for applications that need to know the dimensions (e.g. depth, width, height, timezone, language, etc.) of the client&rsquo;s browser window.
					This is typical metadata;-
					<pre class="page_config">
	$_SESSION['clientMetadata'] = {
			window_innerWidth,
			window_innerHeight,
			window_outerWidth,
			window_outerHeight,
			screen_width,
			screen_height,
			screen_colourDepth,
			screen_pixelDepth,
			screen_availWidth,
			screen_availHeight.
			user_lang,
			char_set,
			timezone_minutes,
			time_ms, (milliseconds from 00:00:00.000 on the 1st of January 1970)
			date, (formated as the ISO-8601 standard: YYYY-MM-DDTHH:mm:ss.sssZ)
			};
					</pre>
				</li>
				<li class="page_config">
					Legal requirements information.
					<br>
					The <?php echo CMS_PROJECT_SHORTNAME; ?> has provisions for controlling and
					displaying &quot;required&quot; information.
					The following provisions are available for standard applications and local tools;-
					<ul class="page_config">
						<li class="page_config">
							&quot;readme&quot; (only available to group managers and admins),
						</li>
						<li class="page_config">
							&quot;release_notes&quot; (only available to group managers and admins),
						</li>
						<li class="page_config">
							&quot;terms&quot;,
						</li>
						<li class="page_config">
							&quot;licence&quot;,
						</li>
						<li class="page_config">
							&quot;acknowledgement&quot;,
						</li>
						<li class="page_config">
							&quot;cookies&quot;,
						</li>
					</ul>
					Use Admin -&gt; Search -&gt; &quot;terms or licence, etc.&quot; to find the settings.
				</li>
				<li class="page_config">
					App SSL Files. The default location for SSL (e.g. cert, key, ca) files
					is the &quot;<?php echo ETC_WS_SSL_INCLUDES_DIR; ?>&quot; directory.
				</li>
<?php if(file_exists("cms/doxy/html/index.html")) { ?>
				<li class="page_config">
					See <a href="cms/doxy/html/index.html" target="_blank"><?php echo CMS_PROJECT_SHORTNAME; ?> Code Documentation</a>.for more information.
				</li>
<?php	} // if ?>
			</ul>
			<p class="page_config">
				The &lt;body&gt; element requires javascript events to manage drag and drop.
				The &quot;INI_DRAG_DROP_PRELOAD_BOOL&quot; setting controls whether the <?php echo CMS_PROJECT_SHORTNAME; ?> drag and drop javascript is included for application pages
				(the <?php echo CMS_PROJECT_SHORTNAME; ?> drag and drop javascript is always included for admin pages).
				In the &quot;<?php echo CMS_PROJECT_SHORTNAME; ?>&quot;  the body events are defined as;-
				<pre class="page_config">	&lt;body ondragover="javascript:cms_drag_over(event);" ondrop="javascript:cms_drop(event);"&gt;</pre>
				To allow applications to access these events,
				the JS initialize body event functions can now be overridden and replaced;-
			</p>
			<ol class="page_config">
				<li>cms_drag_start(event) looks for app_ov_drag_start(event) replacement function,</li>
				<li>cms_drop(event) looks for app_ov_drag(event) replacement function,</li>
				<li>cms_drag_over(event) looks for app_ov_drag_over(event) replacement function.</li>
			</ol>
			<p class="page_config">
				There are many inbuilt feature and useful classes and methods in the <?php echo CMS_PROJECT_SHORTNAME; ?> intended for end coders and
				code integrators to use. Beware changing the &quot;<?php echo CMS_PROJECT_SHORTNAME; ?>&quot; code in the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory.
				An update will overwrite any changes in the &quot;<?php echo CMS_WS_DIR; ?>&quot;.
			</p>
			<p class="page_config">
				Basic features and hints;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					The &quot;<?php echo CMS_WS_DIR; ?>&quot; is the &quot;<?php echo CMS_PROJECT_SHORTNAME; ?>&quot; code directory.
					This should regarded as a code library and a &quot;<?php echo CMS_PROJECT_SHORTNAME; ?>&quot; update will over write this directory.
				</li>
				<li class="page_config">
					The &quot;<?php echo APPS_WS_DIR; ?>&quot; is intended for free coding.
					Usual each application has its own sub-directory here.
					The installation will setup the basic directory for standard code locations (e.g. includes,classes,plugins,etc.).
					To help start coding there are examples applications and code in the &quot;<?php echo CMS_WS_EXAMPLES_DIR; ?>&quot;.
				</li>
				<li class="page_config">
					The &quot;<?php echo ETC_DIR; ?>&quot; is for settings, images, css (i.e. theme generated stylesheets), etc. that are required for operation.
					Basically the configuration directory (similar to /etc on LINUX).
				</li>
				<li class="page_config">
					The &quot;<?php echo VAR_DIR; ?>&quot; is for transient data (e.g. caches, backups, logs, session data, etc.) and
					would not normally be saved (similar to /var on LINUX).
				</li>
			</ul>
			<p class="page_config">
				There <?php echo CMS_PROJECT_SHORTNAME; ?> has been progressively hardened over time.
				Thanks to the feedback from users and community since V0.01 in 2013, the <?php echo CMS_PROJECT_SHORTNAME; ?> has beeb growing and it will continue to grow.
				Many things that can go wrong (e.g. missing &quot;<?php echo VAR_DIR; ?>&quot; directories, lost settings, etc) are checked and rebuilt on Admin login.
				When this happens the <?php echo CMS_PROJECT_SHORTNAME; ?> will tell you what it has done via the logs files (and on screen optionally).
				The &quot;<?php APPS_WS_DIR;?>&quot; is intended for end coders and code integrators to use.
				Beware changing the &quot;<?php echo CMS_PROJECT_SHORTNAME; ?>&quot; code in the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory.
				An update will overwrite any changes in the &quot;<?php echo CMS_WS_DIR; ?>&quot;.
				The &quot;<?php echo APPS_WS_DIR; ?>&quot; is intended for free coding, but does have example files that will be updated.
				The &quot;<?php echo ETC_DIR; ?>&quot; is for settings, images, etc that are required for operation.
				The &quot;<?php echo VAR_DIR; ?>&quot; is for transient data (e.g. caches, backups, logs, session data, etc.) and would not normally be saved.
				If a change is done to the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory, submit the code using &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_wrap_submission.sh&quot; script to make a ZIP archive
				and submit in a feedback email.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="cron_jobs"></a>
			Chronological Timing (CRON Jobs)
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has chronological timing interface to setup and run CRON jobs on Linux based operation systems.
				Each CRON job has a crontab entry under the web application home user account (not under the web server).
			</p>
			<p class="page_config">
				Crontab entries can be configured directly for standard and close coupled applications.
				Standard and Coupled applications have there own CRON job timing and initiator scripts (shell or PHP).
				They are configurated in the Admin -&gt; Pages / Apps configuration.
				Crontab entries are setup, engaged and deleted by the <?php echo CMS_PROJECT_SHORTNAME; ?> from entries in the page/apps configuration page,
				&quot;Admin -&gt; Pages / Apps&quot;.
				This operation needs to be run as the user who owns the web &quot;(DOCROOT)/&quot; directory
				(not Apache which runs as another user with no shell nor IO privileges).
				Depending on the system configuration,
				Apache may be able to change the effective user negating the need to manually log in to the &quot;(DOCROOT)/&quot;.
				<?php echo CMS_PROJECT_SHORTNAME; ?> will indicate results either way.
			</p>
			<p class="page_config">
				For other applications <?php echo CMS_PROJECT_SHORTNAME; ?> uses a common crontab timing configuration.
				If enabled the <?php echo CMS_PROJECT_SHORTNAME; ?> looks for and
				runs &quot;bash -e <?php echo APPS_WS_APPS_CRON_SCRIPT; ?>&quot;
				(or &quot;php <?php echo APPS_WS_APPS_CRON_PHP; ?>&quot;
				if &quot;<?php echo APPS_WS_APPS_CRON_SCRIPT; ?>&quot; is not available).
			</p>
			<p class="page_config">
				If CRON jobs are enabled (currently <?php echo (INI_ALLOW_APP_CRON_JOBS_BOOL ? 'enabled':'disabled'); ?>.) and
				after configuring the required settings in to CRON job configuration/s,
				<?php echo CMS_PROJECT_SHORTNAME; ?> will attempt to change local user&rsquo;s crontab.
				If the web server does have sufficient permissions, a warning to generated to indicate the failure.
				In this case, login in as the local user
				(i.e. the owner of the &quot;(DOCROOT)/&quot;,
				e.g. &quot;/home/(username)/public_html&quot;,
				which gives direct access to the web code).
				This gives you access to the user crontab entries.
				Goto the &quot;(DOCROOT)/&quot; directory and enter &quot;<?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.sh --start&quot;
				or enter &quot;php <?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.php --start&quot;.
				This will update the user&rsquo;s crontab and engage the crontab cronjobs listed in it.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> takes possession of the local user&rsquo;s crontab.
				Running the commands &quot;<?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.sh --start&quot;
				or &quot;php <?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.php --start&quot; as the home user
				will initialize user crontab.
				<br>
				<b>NOTE:</b> &quot;<?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.sh&quot; is a wrapper for &quot;php <?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.php&quot;.
			</p>
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> commands &quot;<?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.sh&quot;
				and &quot;php <?php echo CMS_WS_CLI_DIR; ?>cms_cron_control.php&quot; have options to --start, --stop, --run, etc.
				Running these scripts with the &quot;--help&quot; shows the available options.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="TroubleShooting"></a>
			Trouble Shooting
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?php echo CMS_PROJECT_SHORTNAME; ?> has installation and updating trouble shooting functions built-in.
				<br><b>NOTE:</b> This does not change existing settings, but will remove any code changes made outside of the release.
			</p>
			<p class="page_config">
				If the web site is basically functional,
				logging in as an administrator and
				going to the &quot;http://your.web.site/site_alias/index.php?cms_action=cms_rebuild_setup&quot; link will rebuild the web site settings.
				This can take a minute or so to complete.
			</p>
			<p class="page_config">
				If after an update or other problems, the web site is non functional, there is a recovery command available to help fix this.
			</p>
			<ul class="page_config">
				<li class="page_config">
					On a LINUX server, in a console shell, goto the web site&rsquo;s &quot;<?php echo CMS_MAN_CLI_DIR; ?>&quot; directory and run &quot;./cms_rebuild.sh&quot;.
				</li>
			</ul>
			<p class="page_config">
				Successful rebuild output looks similar to this;-
			</p>
			<pre class="page_config">
				Starting -&gt; rebuilding setup for <?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?>.
				INFO: Installation check.
				INFO: No install issues detected.
				INFO: Checking <?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?> database for updates.
				INFO: Checking table cms_users
				INFO: Checking table cms_bodies
				INFO: Checking table lm_sections
				INFO: Checking table lm_links
				INFO: Checking table cms_tools
				INFO: Checking table cms_configs
				SUCCESS: Checked <?php echo INI_DB_SQLITE_DATABASE; ?> tables - success
				INFO: Installed plugin configs for maplatlong, email, contactus.
				SUCCESS: Update cms_main_styles.css
				SUCCESS: Update cms_block_styles.css
				SUCCESS: Update cms_inline_styles.css
				INFO: DB updated to <?php echo CMS_PROJECT_VERSION; ?>.
				Finished -&gt; rebuilding setup for <?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?>.
			</pre>
			<p class="page_config">
				If any errors or warnings occurred, these will be printed out.
			</p>
			<p class="page_config">
				<b>CAUTION:</b> The update will use default settings for new features. <b>Take note of the messages (e.g.ERROR, WARNING, and INFO).</b>
				The default settings for new features may need to changed to more appropriate values.
			</p>
			<p class="page_config">
				A basic installation guide is available in the
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#TroubleShooting'); ?>.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="VersionControl"></a>
			File Version Control
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				When a manager or administrator are logged in, the <?php echo CMS_PROJECT_SHORTNAME; ?> can use &quot;Subversion&quot; (SVN) and Git,
				if available, to aid in administration and checking of the site.
				Hovering the mouse over the &quot;About <?php echo CMS_PROJECT_SHORTNAME; ?>&quot; or manual pages shows the current SVN and Git version status of the website.
				This reports the SVN revision number of the web site.
				The revision numbers can used to identify changes.
			</p>
			<p class="page_config">
				Current version details: <?php echo Ccms::$version_str; ?>
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="UtilityScripts"></a>
			Utility Scripts
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The &quot;<?php echo CMS_MAN_CLI_DIR; ?>&quot; directory contains utility scripts;
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_set_permissions.sh&quot; - Linux scripts to restore web server permissions (runs as &quot;sudo <?php echo CMS_MAN_CLI_DIR; ?>cms_set_permissions.sh&quot;).
					This script will check for &quot;<?php echo APPS_WS_CLI_DIR; ?>set_app_permissions.sh&quot; and run it if found.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_rebuild.sh&quot; - Linux version to rebuild configuration.
					NOTE: Running &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_rebuild.sh&quot; runs the &quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_backup_settings.sh&quot; before rebuilding.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_rebuild.php&quot; - is a PHP sub script for rebuild configuration and reset the cache. <br>
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_backup_settings.sh&quot; - backs up settings to a datetime named file in &quot;<?php echo VAR_DIR; ?>backup/&quot; (e.g. ;<?php echo VAR_DIR; ?>backups/<?php echo CMS_PROJECT_SHORTNAME; ?>-Backup-20170801-163930.zip).
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_generate_sitemap.sh&quot; - Linux version of CLI sitemap generator.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_generate_sitemap.php&quot; - is a PHP sub script of CLI sitemap generator.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_import_links_manager.sh&quot; - Linux version to import Links_Manager data. <br>
					<b>Important Note:</b> User and Group permissions need to be checked and/or reassigned after running this script.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_import_links_manager.php&quot; - is a PHP sub script to import DB data.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_wrap_submission.sh&quot; - Linux script used to help submit community feedback containing code with requested changes.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_cron_control.sh&quot;
					(executes &quot;php <?php echo CMS_MAN_CLI_DIR; ?>cms_cron_control.php&quot;)
					 - Linux script to control CRON jobs.
				</li>
				<li class="page_config">
					&quot;<?php echo CMS_MAN_CLI_DIR; ?>cms_updateAppsCMS.sh&quot;
					 - Linux script to update the <?php echo CMS_PROJECT_SHORTNAME; ?> from remote repositories.
					The online update process the setting in &quot;AppsCMSupdater&quot; to operate.
					<br>
					<b>Important Note:</b> This shell script will overwrite the &quot;<?php echo CMS_WS_DIR; ?>&quot; directory.
					This script will also run the rebuild script to install new data and features.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="ExampleCode"></a>
			Code Examples
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Code examples are available in the <?php echo CMS_WS_EXAMPLES_DIR; ?> directory.
				The &quot;<?php echo CMS_WS_EXAMPLES_DIR; ?>&quot; directory can be copied to the &quot;(DOCROOT)/&quot; directory
				to engage the examples.
				(e.g. at the &quot;(DOCROOT)/&quot; run &quot;cp -v -r <?php echo CMS_WS_EXAMPLES_DIR; ?> &quot;)
			</p>
			<p class="page_config">
				The examples show basic functionality.
				The explanations given here assume that the example code has been copy to the functional location.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="MoreInfo"></a>
			More Information and Feedback
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_IMAGES_DIR .CMS_PROJECT_SHORTNAME . '_logo.gif',CMS_PROJECT_SHORTNAME .' Logo',false,'#MoreInfo'); ?>.
			</p>
			<p class="page_config">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'README.md','README',false,'#MoreInfo'); ?>.
			</p>
			<p class="page_config">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes',false,'#MoreInfo'); ?>.
			</p>
			<p class="page_config">
				<?php echo Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#MoreInfo'); ?>.
			</p>
			<p class="page_config">
				<a name="DirectoryStructure"></a>
				<h3 class="page_config">Directory Structure;-</h3>
			<pre class="page_config">
\ (&quot;(DOCROOT)/&quot;/alias)		Web site base directory (maybe &quot;(DOCROOT)/&quot; or a directory / alias under &quot;(DOCROOT)/(alias)/&quot;).
│
├── <?php echo APPS_WS_DIR; ?>		Base directory for web applications (apps code supplied by user). Contains fixed code.
│   ├── cli                Apps common command line operations.
│   ├── include            Apps common include directory.
│   │   ├── classes        Apps common classes directory (autoload classes looks in here).
│   │   └── ini            Apps common fixed INI and JSON hard coded control files directory.
│   ├── javascript         Recomended Apps common javascript directory.
│   ├── lib                Recomended Apps commonlibraries directory.
│   ├── plugins            Apps commonplugin directory (autoload classes looks in here).
│   ├── stylesheets        Recomended Apps common stylesheet directory.
│   ├── (other)            Other Apps directories as required.
│   │                      Most applications will have a directory structure under <?php echo APPS_WS_DIR; ?>.
│   │                      e.g &quot;<?php echo APPS_WS_DIR; ?>(APP_DIR)/&quot; setup through the Admin -> Pages / Apps menu.
│   │
│   └── book_keep          Example of the &quot;Book Keeper&quot; standard app base installation directory structure.
│       ├── backgrounds    Apps background images, accessible to web browser.
│       ├── classes        Apps PHP code classes, not accessible to web browser.
│       ├── cli            Apps command line and cron job scripts, not accessible to web browser.
│       ├── icons          Apps background images, accessible to web browser.
│       ├── images         Apps background images, accessible to web browser.
│       ├── include        Apps PHP included code, not accessible to web browser.
│       ├── ini            Apps configuration control code, not accessible to web browser.
│       ├── javascript     Apps javascript files, accessible to web browser.
│       ├── lib            Apps third party code libraries, not accessible to web browser.
│       ├── plugins        Apps PHP code plugins, not accessible to web browser.
│       ├── stylesheets    Apps background images, accessible to web browser.
│       └────────────────  Apps base PHP code (and other) files, accessible to the web browser through the page body file/s.
│
├── <?php echo CMS_WS_DIR; ?>        Base AppsCMS library directory (this directory is overwritten by AppsCMS updates).
│   ├── cli                AppsCMS command line operations (e.g. rebuild, backup, etc.).
│   ├── dist               The AppsCMS installer creates this directory to save install/update files (e.g. AppsCMS-Vn.nn.zip).
│   │
│   ├── examples           Example code for user directories (copy this directory to document root to engage the examples).
│   │   ├── apps           Example apps/ directory layout.
│   │   │   │
│   │   │   ├── cli                                 Example apps command line operations.
│   │   │   │   ├── example_apps_cron.sh            Example apps common CRON engagement shell script called from crontab.
│   │   │   │   └── example_apps_cron.php           Example apps common CRON engagement PHP script (usually called by the shell script).
│   │   │   │
│   │   │   ├── example_app1                        Example app 1 directory (e.g. standard application)
│   │   │   │   ├── backgrounds                     Example app 1 application specific background images.
│   │   │   │   ├── classes                         Example app 1 application specific classes directory (autoload looks in here for app classes).
│   │   │   │   │   └── example_app1_app.php        Example app 1 class (NOTE: _app suffix).
│   │   │   │   ├── cli                             Example app 1 application specific command line code.
│   │   │   │   ├── icons                           Example app 1 application specific fixed icons.
│   │   │   │   ├── include                         Example app 1 application specific include directory.
│   │   │   │   │   └── app_css.php                 Example app 1 application specific theme style sheet theme recipe to generate app.css (optional).
│   │   │   │   │   └── app_config.php              Example app 1 application specific configuration (and definitions) file (optional).
│   │   │   │   ├── images                          Example app 1 application specific fixed images.
│   │   │   │   ├── ini                             Example app 1 application specific configuration control.
│   │   │   │   │   ├── app.comments.ini            Example app 1 application specific configuration comments (for app config control and help text) file (optional).
│   │   │   │   │   └── app.defaults.ini            Example app 1 application specific configuration defaults (for app config default values) file (optional).
│   │   │   │   ├── javascript                      Example app 1 application specific javascript directory.
│   │   │   │   │   └── app.js                      Example app 1 application specific javascript code file (automatically linked in to &lthead&gt html section when the application is engaged, optional).
│   │   │   │   ├── lib                             Example app 1 application specific library code.
│   │   │   │   ├── plugins                         Example app 1 plugins directory (autoload looks in here for app plugins).
│   │   │   │   ├── stylesheets                     Example app 1 application specific stylesheets directory.
│   │   │   │   │   └── app.css                     Example app 1 application specific stylesheet file (automatically linked in to &lthead&gt html section when the application is engaged, optional).
│   │   │   │   └── example_app1.php                An example app 1 code file.
│   │   │   │
│   │   │   ├── example_app2                        Example app 2 directory (simple application)
│   │   │   │   └── example_app2.php                An example app 2 code file.
│   │   │   │
│   │   │   ├── images                              Common app images
│   │   │   │
│   │   │   ├── include                             Common app include files.
│   │   │   │   ├── classes                         Common apps class files (autoload looks in here for common apps classes).
│   │   │   │   │   ├── example_apps_auth.php       Example apps authentication class.
│   │   │   │   │   └── example_dyn_cntl_base.php   Example dynamic control base class.
│   │   │   │   ├── example_apps_config.php         Example apps configuration file.
│   │   │   │   ├── example_apps_css.php            Example apps theme generator file.
│   │   │   │   ├── example_apps_manual.php         Example apps code / applications manual file.
│   │   │   │   ├── ini                             Example apps ini settings configuration directory.
│   │   │   │   │   ├── example.apps.comments.ini   Example apps configuration comment file.
│   │   │   │   │   └── example.apps.defaults.ini   Example apps default configuration file.
│   │   │   │   └── plugins                         Common apps plugins files (autoload looks in here for common apps plugins).
│   │   │   │       ├── example_app_extend.php      Example apps extended plugin class.
│   │   │   │       ├── example_app.php             Example apps plugin class.
│   │   │   │       └── example_dyn_cntl_app.php    Example apps dynamic control plugin class.
│   │   │   │
│   │   │   ├── javascript                          Apps common javascript directory.
│   │   │   │
│   │   │   ├── README-apps.txt                     Apps README file.
│   │   │   │
│   │   │   └── stylesheets                         Apps common style sheets directory.
│   │   │
│   │   ├── etc                                     Etc directory examples.
│   │   │   ├── ext                                 External code and extra code directory examples
│   │   │   │   ├── example_cookie_banner.html      Example cookie banner file.
│   │   │   │   ├── example_cookie_policy.html      Example cookie policy file.
│   │   │   │   └── example_google_analytics.php    Example Google analytics file.
│   │   │   └── ini                                 INI directory examples
│   │   │       └── example_cms_wysiwyg.json                Example WYSIWYG configuration file.
│   │   │
│   │   ├── page_bodies                             Page bodies (or apps links) directory (controlled by Admin -> Pages / Apps menu).
│   │   │   ├── example_cms_body.php                Example body file (may be an app or a standard web page).
│   │   │   ├── example_contactus_cms_body.php      Example use of the contactus plugin.
│   │   │   ├── example_login_cms_body.php          Example use of a login page.
│   │   │   └── example_welcome_cms_body.php        Example of a full view web page (header, body and footer all integrated).
│   │   │
│   │   └── Example application and tool installation packages.
│   │
│   ├── images             AppsCMS images directory (used by the AppsCMS).
│   │   └── manual         Images for the AppsCMS manual.
│   ├── includes           AppsCMS includes (not include like apps) directory.
│   │   ├── classes        AppsCMS classes directory (autoload classes looks in here).
│   │   ├── ini            AppsCMS fixed INI and JSON hard coded control files directory.
│   │   ├── ops            AppsCMS operations directory (e.g. login, login, edit config, etc.).
│   │   └── plugins        AppsCMS plugin directory (autoload classes looks in here).
│   └── lib                Local copy of AppsCMS 3rd party libraries, a directory for each library.
│       └── README_libs.md AppsCMS readme on 3rd party libraries.
│
├── <?php echo ETC_DIR; ?>		Config base directory (this directory contains the configuration files).
│   ├── ext                Directory for external code (e.g. Google Analytics, etc. code).
│   ├── images             Custom/uploaded web page images directory.
│   │── backgrounds        Custom/uploaded background images directory.
│   │── icons              Custom icons directory.
│   ├── ini                Edited configuration/options INI and JSON file directory.
│   ├── sqlite             The AppsCMS sqlite configuration database directory.
│   └── (other)            Other Apps config directories as required.
│
├── <?php echo LOCAL_WS_TOOLS_DIR; ?>		Local tools directory (supplied by user).
│
├── <?php echo PAGE_BODIES_WS_DIR; ?>		Web body/apps code directory (supplied by user).
│
└── <?php echo VAR_DIR; ?>		Temporary / transitory data directory (should not need to be backed up).
   ├── apps               Applications directory for Apps.
   ├── backups            Backups directory.
   ├── cache              Cache directory (each application has a sub-directory).
   ├── exports            Exports directory.
   ├── logs               Logs files.
   ├── sessions           PHP user session data directory (if used).
   ├── Trash              General directory for deleted files (local recycle bin).
   ├── variables          Variable storage directory (e.g. counts, stats, etc.).
   └── (other)            Other Apps variable directories as required.
	</pre>
			</p>
			<p class="page_config">
				Hints, corrections and suggestions are always welcome.
				Email <A HREF="mailto:feedback@<?php echo CMS_PROJECT_DOMAIN; ?>?Subject=<?php echo rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION); ?>">Feedback</A>.
			</p>
		</td>
	</tr>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>
