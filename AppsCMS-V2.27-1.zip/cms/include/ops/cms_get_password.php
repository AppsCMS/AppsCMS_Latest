<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_get_password.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

if(!Ccms_auth::is_user_logged_in()) {
	unset($_SESSION['action']);
	if(!Ccms_auth::is_login_allowed()) {
		$url = CMS_WWW_URL . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'login.php';
	header('Location: ' . $url);
	exit (0);
	} // if

if(isset($_SESSION['action'])) unset($_SESSION['action']);
$user_name = $_SESSION['user']['name'];
$user_id = $_SESSION['user']['id'];
$user_auth = $_SESSION['user']['type'];

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php Ccms::set_JS_password_resource(); ?>

<form name="set_user_password" action="<?php echo 'index.php?cms_action=set_password'; ?>" method="post" enctype="multipart/form-data" autocomplete="off">
<input type="hidden" name="user_id" value="<?php echo $user_id; ?>"/>
<input type="hidden" name="user_name" value="<?php echo htmlentities($user_name); ?>"/>
<input type="hidden" name="user_auth" value="<?php echo htmlentities($user_auth); ?>"/>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Change Local Password for: <?php echo $user_name; ?></h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<table class="page_config">
				<tr>
					<td width ="100px" class="page_config">Password:</td>
					<td class="page_config">
						<?php Ccms::set_JS_password_input('user_password', 'Enter new local password.','',true); ?>
					</td>
				</tr>
				<tr>
					<td width ="100px" class="page_config">Confirm:</td>
					<td class="page_config">
						<?php Ccms::set_JS_password_input('user_confirm', 'Confirm password.'); ?>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>
</table>
</form>

<?php Ccms::page_end_comment(__FILE__); ?>
