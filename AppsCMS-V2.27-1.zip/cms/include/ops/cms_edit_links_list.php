<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_edit_links_list.php 2004 2021-02-28 08:53:00Z robert0609 $
 */


if(Ccms::$cms_action == 'cms_edit_links') { // a bit of caution
	if(($lm_link_qk_op = Ccms::get_or_post('lm_link_qk_op')) &&
		($lm_link_qk_id = Ccms::get_or_post('lm_link_qk_id'))) {	// single value change
		switch($lm_link_qk_op) {
		case 'edit_link_qk_section':
			if($lm_link_qk_section_id = Ccms::get_or_post('lm_link_qk_section_id')) {
				$sql = "UPDATE lm_links SET lm_link_section_id = " . (int)$lm_link_qk_section_id . ' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
				if(!Ccms::$cDBcms->query($sql)) {
					Ccms::addMsg('Failed to update link section.');
					} // if
				} // if
			break;
		case 'edit_link_input':
			if(($lm_link_qk_type = Ccms::get_or_post('lm_link_qk_type')) &&
				($lm_link_qk_name = Ccms::get_or_post('lm_link_qk_name')) &&
				($lm_link_qk_value = Ccms::get_or_post('lm_link_qk_value'))) {
				switch($lm_link_qk_type) {
				case 'checkbox':
					$sql = "UPDATE lm_links SET " . $lm_link_qk_name . " = '" . (($lm_link_qk_value == 'on') ? 1:0) . "'" .
						' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
					break;
				case 'number':
					$sql = "UPDATE lm_links SET " . $lm_link_qk_name . " = " . (int)$lm_link_qk_value . "" .
						' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
					break;
				default:	// treat the rest as text
					$sql = "UPDATE lm_links SET " . $lm_link_qk_name . " = '" . $lm_link_qk_value . "'" .
						' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
					break;
					} // switch
				if(!Ccms::$cDBcms->query($sql)) {
					Ccms::addMsg('Failed to update link ID: ' . (int)$lm_link_qk_id . ', name: ' . $lm_link_qk_name . '.');
					} // if
				else Ccms::addDebugMsg('Updated link ID: ' . (int)$lm_link_qk_id . ', name: ' . $lm_link_qk_name . '.','success');
				} // if
			break;
		default:
			break;
			} // switch
		$lm_link_qk_id = 0;
		$lm_link_qk_op = '';
		} // if
	} // if
$edit_link_qk_section_filter = Ccms::get_or_post_keyed_session_var('edit_link_qk_section_filter');
$edit_link_qk_section_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_link_qk_section_enabled');

$edit_link_qk_link_filter = Ccms::get_or_post_keyed_session_var('edit_link_qk_link_filter');
$edit_link_qk_link_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_link_qk_link_enabled');

if((!Ccms::is_get_or_post('link_edit_id')) &&
	(Ccms::get_or_post('lm_link_qk_anchor') != 'null')) {	// return anchor
	$edit_link_qk_anchor = Ccms::get_or_post_keyed_session_var('lm_link_qk_anchor');
	} // if
else $edit_link_qk_anchor = false;	// edit the link

?>

<?php Ccms::page_start_comment(__FILE__); ?>

			<script type="text/javascript">
				var lm_select_sect_opts = <?php echo json_encode((object)Ccms_html::gen_section_selection_options(0,false,true,false), JSON_PRETTY_PRINT); ?>;
				function lm_select_fill_options(event,sel_obj) {
					if(event.type == 'change') {
						sel_obj.form.submit();
						return true;
						} // if
					else if((event.type == 'click') &&
						(sel_obj.options.length < 5)) {	// 5 ?!?!
						// fill select options
						sel_obj.onclick = null;	// stop further click events
						var seld_option = false;
						try {
							seld_option = sel_obj.options[sel_obj.selectedIndex];	// get currect selected
							}
						catch(e) {
							seld_option = false;
							}
						// fill select options
						sel_obj.options.length = 0;	// clear it
						for(var i in lm_select_sect_opts) {
							var s_opt = lm_select_sect_opts[i];
							var seld = false;
							if(seld_option.value == s_opt.value) seld = true
							var n_opt = document.createElement("option");
							n_opt.value = s_opt.value;
							n_opt.text = s_opt.text;
							n_opt.selected = seld;
							// n_opt.style = s_opt.style;
							sel_obj.appendChild(n_opt);
							} // for
						return true;
						} // if
					return false;
					} // lm_select_fill_options()

			var last_edit_link_qk_section_filter_call = null;
			function chk_link_section_filter(event,obj) {
				if(event.keyCode == 13) {
					obj.form.submit();
					return true;
					} // if
				if((event.type == 'click') &&
					(obj.type == 'checkbox')) {
					obj.form.submit();
					return true;
					} // if
				// don't submit on every char event, wait
				if(last_edit_link_qk_section_filter_call != null) {	// clear it
					window.clearTimeout(last_edit_link_qk_section_filter_call);
					last_edit_link_qk_section_filter_call = null;
					} // if
				// restart if
				last_edit_link_qk_section_filter_call = window.setTimeout(
					function (event,obj) {
						var keywords = obj.value;
						if((keywords.length > 2) ||
							(keywords.length == 0)) {
							obj.form.submit();
							return true;
							} // if
						return false;
						},
					1200, event, obj);
				} // chk_link_section_filter()

			function submit_edit_link_qk_section_input(event,obj,id,anchor) {
				if(obj.tagName != 'INPUT')
					return false;
				var name = obj.name;
				var form = document.createElement("FORM");

				form.method = "POST";
				form.action = "<?php echo $_SERVER['PHP_SELF']; ?>";

				var element1 = document.createElement("input");
				element1.value = "cms_edit_links";
				element1.name = "cms_action";
				form.appendChild(element1);

				var element2 = document.createElement("input");
				element2.name = "lm_link_qk_op";
				element2.value = "edit_link_input";
				form.appendChild(element2);

				var element3 = document.createElement("input");
				element3.value = id;
				element3.name = "lm_link_qk_id";
				form.appendChild(element3);

				var element4 = document.createElement("input");
				element4.value = obj.type;
				element4.name = 'lm_link_qk_type';
				form.appendChild(element4);

				var element5 = document.createElement("input");
				element5.name = "lm_link_qk_name";
				element5.value = name;
				form.appendChild(element5);

				var element6 = document.createElement("input");
				if(obj.type == 'checkbox') {
					var chkd = obj.checked;
					element6.value = (chkd ? 'on':'off');
					} // if
				else element6.value = obj.value;
				element6.name = 'lm_link_qk_value';
				form.appendChild(element6);

				var element7 = document.createElement("input");
				element7.name = "lm_link_qk_anchor";
				element7.value = (anchor ? anchor:'');
				form.appendChild(element7);

				document.body.appendChild(form);
				form.submit();

				} // submit_edit_link_qk_section_input()

			</script>
			<style>
				#summary_id select {
					font-size: 0.9em;
					max-width: 300px;
					min-width: 240px;
					}
			</style>
			<h3 class="page_config">Summary</h3>
			&nbsp;
			<form name="link_section_edit_filter" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_links"/>
				<!--<input type="hidden" name="edit_link_qk_section"/>-->
				<input type="hidden" name="lm_link_qk_op" value="edit_link_qk_section_filter"/>
				<label>
					<input type="text" name="edit_link_qk_section_filter"
						value="<?php echo $edit_link_qk_section_filter; ?>"
						oninput="chk_link_section_filter(event,this);"
						title="Enter filter keywords (separated by spaces) to find sections."
						/>
					<input type="checkbox" name="edit_link_qk_section_enabled"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only enabled sections."
						<?php echo ($edit_link_qk_section_enabled ? ' CHECKED':''); ?>/>
					sections filter.
					&nbsp;
					<input type="text" name="edit_link_qk_link_filter"
						value="<?php echo $edit_link_qk_link_filter; ?>"
						oninput="chk_link_section_filter(event,this);"
						title="Enter filter keywords (separated by spaces) to find links."
						/>
					<input type="checkbox" name="edit_link_qk_link_enabled"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only enabled links"
						<?php echo ($edit_link_qk_link_enabled ? ' CHECKED':''); ?>/>
					link filters.
				</label>
			</form>

			<span id="summary_id">
		<?php
			$where_filter = '';
			$ret_anch = '';
			if(!empty($edit_link_qk_section_filter)) {
				$bowes = 0;
				$where_filter .= PHP_EOL . ' AND ( ';
				$filters = preg_split('/[\s,;:\/\'\"]+/',$edit_link_qk_section_filter);
				foreach($filters as $bow) {
					if($bowes > 0) $where_filter .= ' AND ';
					$where_filter .= 'lm_section_name LIKE \'%' . $bow . '%\'' . PHP_EOL;
					$bowes++;
					} // foreach
				$where_filter .= ' ) ' . PHP_EOL;
				} // if
			if($edit_link_qk_section_enabled)
				$where_filter .= ' AND lm_section_enabled > 0 ' . PHP_EOL;
			if(!empty($edit_link_qk_link_filter)) {
				$bowes = 0;
				$where_filter .= PHP_EOL . ' AND ( ';
				$filters = preg_split('/[\s,;:\/\'\"]+/',$edit_link_qk_link_filter);
				foreach($filters as $bow) {
					if($bowes > 0) $where_filter .= ' AND ';
					$where_filter .= '(lm_link_name LIKE \'%' . $bow . '%\'' .
						' OR lm_link_url LIKE \'%' . $bow . '%\'' .
						' OR lm_link_title LIKE \'%' . $bow . '%\'' .
						' OR lm_link_description LIKE \'%' . $bow . '%\' ) ' . PHP_EOL;
					$bowes++;
					} // foreach
				$where_filter .= ' ) ' . PHP_EOL;
				} // if
			if($edit_link_qk_link_enabled) {
				$where_filter .= ' AND lm_link_enabled > 0 ';
				}
			$sql_query = "SELECT lm_link_id,lm_link_name,lm_link_url,lm_link_title,lm_link_description" .
				",lm_link_new_page, lm_link_image_url, lm_link_icon_url" .
				",lm_link_order,lm_link_enabled, lm_link_ssl, lm_link_comments" .
				",lm_link_add_name2url,lm_section_enabled,lm_section_id, lm_section_parent_id" .
				PHP_EOL .
				",lm_link_section_id,lm_section_name,lm_section_order,lm_section_title, lm_section_description" .
				PHP_EOL .
				" FROM  lm_links as l LEFT JOIN lm_sections as s ON l.lm_link_section_id = s.lm_section_id" .
				PHP_EOL .
				" WHERE lm_link_id > 0" .
				$where_filter .
				" AND (l.lm_link_section_id = s.lm_section_id OR l.lm_link_section_id = 0)" .
				PHP_EOL .
				" ORDER BY lm_section_name,lm_link_order";
			if(($result = Ccms::$cDBcms->query($sql_query)) &&
				(Ccms::$cDBcms->num_rows($result) > 0)) {
				$row = 0; $last_sect_id = false;
				$sel_params = ' onclick="lm_select_fill_options(event,this);"' .
					' onchange="lm_select_fill_options(event,this)" size="1"';
				while($link = Ccms::$cDBcms->fetch_array($result)) {
					if(($last_sect_id != $link['lm_section_id']) ||
						(empty($link['lm_section_id']))) {
						if($last_sect_id !== false) echo '</table>' . PHP_EOL;
						$last_sect_id = $link['lm_section_id'];
						$ret_anch = 'anch_sect_' . $link['lm_section_id'];
?>
				<a name="<?php echo $ret_anch; ?>"></a>
				<table class="page_config">
					<tr class="page_config" style="position: sticky; top: 0px; background-color: ivory;">
						<th width="150px" class="page_config" title="<?php echo strip_tags($link['lm_section_description']) . "\n" . $link['lm_section_title']; ?>">
							<a href="index.php?cms_action=cms_edit_sections&section_edit_id=<?php echo $link['lm_section_id']; ?>" title="Click to edit section.">Link in Section: <?php echo $link['lm_section_name']; ?></a>
						</th>
						<th width="150px" class="page_config" title="Link name">Link</th>
						<th class="page_config" style="text-align: center" title="Link image">Image</th>
						<th class="page_config" style="text-align: center" title="Link icon">Icon</th>
						<th width="70px" class="page_config" title="Display order">Order</th>
						<th width="70px" class="page_config">Enabled</th>
						<th width="40px" class="page_config" title="Use SSL encryption">SSL</th>
						<th width="40px" class="page_config" title="In a new tab/window">New</th>
						<th width="50px" class="page_config" title="Add name to URL">Add Name</th>
						<th class="page_config">Description</th>
						<th class="page_config">Comments</th>
					</tr>
<?php
						} // if
					echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">' . PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' . PHP_EOL;
					echo '	<form name="link_qk_section_edit" action="' . $_SERVER['PHP_SELF'] . '" method="get">' . PHP_EOL;
					// public static function gen_section_selection_list($name, $lm_section_id = 0, $params = '', $exc_ids = false, $bare = false, $onchange_submit = true) {
					echo  Ccms::gen_link_section_js_selection_list('lm_link_qk_section_id', $link['lm_section_id'],$sel_params, false, true, false) . PHP_EOL;
					echo '		<input type="hidden" name="cms_action" value="cms_edit_links"/>' . PHP_EOL;
					echo '		<input type="hidden" name="lm_link_qk_id" value="' . $link['lm_link_id'] . '"/>' . PHP_EOL;
					echo '		<input type="hidden" name="lm_link_qk_op" value="edit_link_qk_section"/>' . PHP_EOL;
					echo '		<input type="hidden" name="edit_link_qk_section_filter" value="' . $edit_link_qk_section_filter . '"/>' . PHP_EOL;
					echo '		<input type="hidden" name="lm_link_qk_anchor" value="' . $ret_anch . '"/>' . PHP_EOL;
					echo '	</form>' . PHP_EOL;
					echo '</td>' . PHP_EOL;

					echo '<td class="page_config" style="text-align: left">';
					$titex = (!empty($link['lm_link_url']) ? '\n(' . $link['lm_link_url'] . ')':'');
					echo '	<a href="index.php?cms_action=cms_edit_links&link_edit_id=' . $link['lm_link_id'] . '&lm_link_qk_anchor=null"' .
						' title="Click to edit link: ' . strip_tags($link['lm_link_title']) . (($link['lm_link_new_page'] && CMS_C_SHOWINNEWTAB) ? ' (in a new tab)':'') . $titex . '">' .
						(Ccms::is_debug() ? 'ID: ' . $link['lm_link_id'] . ', ':'') .
						$link['lm_link_name'] .
						'</a>' .
						(!$link['lm_link_enabled'] ? '<br>(disabled)':'');
					echo  '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: center">';
					echo $cCMS_C->show_image($link['lm_link_image_url'],ETC_WS_IMAGES_DIR,'page_config');
					echo  '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: center">';
					echo $cCMS_C->show_image($link['lm_link_icon_url'],ETC_WS_ICONS_DIR,'page_config');
					echo  '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="number" name="lm_link_order" size="5"' .
								' value="' . $link['lm_link_order'] . '"' .
								' style="width: 40px;"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								' autocapitalize="off"/>' .
						 '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="checkbox" name="lm_link_enabled"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								($link['lm_link_enabled'] == 1 ? ' CHECKED':'') . '/>' .
						 '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="checkbox" name="lm_link_ssl"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								($link['lm_link_ssl'] ? ' CHECKED':'') . '/>' .
						 '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="checkbox" name="lm_link_new_page"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								($link['lm_link_new_page'] ? ' CHECKED':'') . '/>' .
						 '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="checkbox" name="lm_link_add_name2url"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								($link['lm_link_add_name2url'] ? ' CHECKED':'') . '/>' .
						 '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="text" name="lm_link_description"' .
								' value="' . $link['lm_link_description'] . '"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								' autocapitalize="off"/>' .
						 '</td>'. PHP_EOL;
					echo '<td class="page_config" style="text-align: left">' .
							'<input type="text" name="lm_link_comments"' .
								' value="' . $link['lm_link_comments'] . '"' .
								' onchange="submit_edit_link_qk_section_input(event,this,\'' . $link['lm_link_id'] . '\',\'' . $ret_anch . '\');"' .
								' autocapitalize="off"/>' .
						 '</td>'. PHP_EOL;
					echo '</tr>' . PHP_EOL;
					$row++;
					} // while
				Ccms::$cDBcms->free_result($result);
				echo '</table>' . PHP_EOL;
				} // if
			else {
				if((!empty($edit_link_qk_section_filter)) ||
					(!empty($edit_link_qk_link_filter)))
					$msg = '(No links found)';
				else $msg = '(No links setup)';
				echo '<span class="cms_msg_warning">' . $msg . '</span>' . PHP_EOL;
				} // else
			?>
			</span>

<?php if (!empty($edit_link_qk_anchor)) { ?>

			<script>

				cms_scroll2Name('<?php echo $edit_link_qk_anchor; ?>');	// scroll anchor

			</script>

<?php	} // if ?>

<?php Ccms::page_end_comment(__FILE__); ?>
