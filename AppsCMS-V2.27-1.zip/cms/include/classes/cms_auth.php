<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_auth.php 1978 2021-02-24 01:40:22Z robert0609 $
 */

/**
 * Description of Ccms_auth
 *
 * @author robert0609
 */

class Ccms_ldap extends Ccms_base {	// LDAP class
	const LDAP_OPT_DIAGNOSTIC_MESSAGE = 0x0032;

	protected static $disabled = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_ldap_ok() {	// check if LDAP is setup
		if(self::$disabled) return false;
		if(strlen(INI_LDAP_SERVER_URI) < 6) {	// have no server
			self::$disabled = true;
			return false;
			} // if
		if(!function_exists('ldap_connect')) {
			self::$cDBcms->logEvent('INSTALL ERROR: No LDAP PHP functions installed.');
			self::$disabled = true;
			return false;	// the LDAP module not loaded
			} // if
		return true;
		} // is_ldap_ok()

	private static function get_ldap_search_result(&$ldapconn,$username) {

		if((strlen(INI_LDAP_SERVER_SEARCH_DOM) > 8) &&
			(strlen(INI_LDAP_SERVER_SEARCH_FILTER) > 4)) {	// want search with somewhere to put results

			$dom = INI_LDAP_SERVER_SEARCH_DOM;
			$filter = INI_LDAP_SERVER_SEARCH_FILTER;	// put in username, if there
			$filter = str_replace('$username',$username,$filter);
			$attributes = array("*");
			if(strlen(INI_LDAP_SERVER_SEARCH_KEYS) > 2)
				$attributes = explode(',',INI_LDAP_SERVER_SEARCH_KEYS);	// make keys

			if(($search_handle = ldap_search($ldapconn, $dom, $filter, $attributes)) === false) {
				$_SESSION['ldap'] = false; // bad search
				$err = ldap_error($ldapconn);
				self::addDebugMsg('LDAP Search Failed: ' . $err);
				} // if
			else {
				$_SESSION['ldap'] = ldap_get_entries($ldapconn, $search_handle);
				} // else
			} // if
		return true;
		} // get_ldap_search_result()

	private static function chk_ldap_connection_authed(&$ldapconn,&$username,&$password) {
		// Help talking to AD
		ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
		ldap_set_option($ldapconn, LDAP_OPT_REFERRALS, 0);

	    // binding to ldap server
		$user_dom = Ccms_auth::chk_add_default_user_domain($username);
		if(!$ldapbind = @ldap_bind($ldapconn, $user_dom, $password)) {
			$extended_error = false;
			$err = '';
			ldap_get_option($ldapconn, self::LDAP_OPT_DIAGNOSTIC_MESSAGE, $extended_error);
			if (!empty($extended_error)) {
				$err .= $extended_error;
			    $errno = explode(',', $extended_error[2]);
				// $errno = explode(' ', $errno[2]);
				if ((int)$errno[0] == 532) {
					$err .= ': Password expired.';
					} // if
				}
			self::$cDBcms->logEvent('WARNING: Failed to auth "' . $username . '"' . $err . '.');
			return false;	// ???
			} // if

		self::get_ldap_search_result($ldapconn, $username);

		@ldap_unbind($ldapbind);	// let em go on
		return true;
		} // chk_ldap_connection_authed()

	public static function is_user_ldap_authed($username,$password) { // using ldap bind
		if(!self::is_ldap_ok()) {	// have a server
			self::$cDBcms->logEvent('INFO: No LDAP server setup.');
			return false;
			} // if
		if((empty($username)) || (empty($password))) {	// some basics
			self::$cDBcms->logEvent('CODE ERROR: LDAP auth attempt missing parameter by caller.');
			return false;
			} // if
		// check authed
		$def_port = (((strlen(INI_LDAP_SERVER_URI_PORT) >= 2) && (is_numeric(INI_LDAP_SERVER_URI_PORT))) ? (int)INI_LDAP_SERVER_URI_PORT:389);
		$ldap_servers = self::unserialize_string2arry(INI_LDAP_SERVER_URI,',');
		if((empty($ldap_servers)) || (!is_array($ldap_servers)) || (!isset($ldap_servers[0]))) {
			self::$cDBcms->logEvent('ERROR: No LDAP server/s configured.');
			return false;
			} // if
		$ldapconn = false;
		foreach($ldap_servers as $lds) {
			if(!isset($lds[0])) continue;	// false marker
			if(empty($lds[0])) continue;
			$lds = $lds[0];
			if(preg_match('/\:[0-9]{3,5}$/', $lds))	{	// check if port is supplied
				$port = preg_replace('/^(.*:)([0-9]{3,5})$/', '\2', $lds);	// strip the off server
				$lds = preg_replace('/\:[0-9]{3,5}$/', '', $lds);	// strip the off port
				} // if
			else $port = $def_port;
			if((self::can_connect2host($lds,$port,INI_LDAP_SERVER_TIMEOUT,false)) &&	// don't hang if no LDAP server
				(($ldapconn = @ldap_connect($lds, $port)) !== false)) {
				self::$cDBcms->logEvent('INFO: LDAP connect to ' . $lds . ':' . $port);
				if(self::chk_ldap_connection_authed($ldapconn, $username, $password)) {
					self::$cDBcms->logEvent('INFO: User "' . $username . '" authenticated on ' . $lds . ':' . $port);
					return true;	// authed ok
					} // if
				} // if
			// keep going
			} // foreach
		if($ldapconn === false) {
			self::$disabled = true;
			self::$cDBcms->logEvent('ERROR: Failed to connect to a LDAP server.');
			return false;
			} // if
		self::$cDBcms->logEvent('WARNING: Failed to auth "' . $username . '".');
		return false;	// ???
		} // is_user_ldap_authed()

	public static function logout_ldap_user() {
		if(isset($_SESSION['ldap'])) unset($_SESSION['ldap']);
		// that's it
		return true;
		} // logout_ldap_user()

} // Ccms_ldap

class Ccms_auth extends Ccms_base {
	private static $group_manager = false;	// time saver

	protected static $apps_auth_ok_chkd = false;	// timesaver
	protected static $apps_auth_ok = false;
	protected static $apps_login = false;
	protected static $apps_session_started = false;
	protected static $eula_checked = false;	// timesaver

	protected static $login_local = false;

	protected static $cApps_Auth = false;

	protected static $login_allowed = false;
	protected static $user2apache = false;
	protected static $access_logged = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		self::log_user2apache();
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_ldap_ok() {	// check if LDAP is setup link function
		return Ccms_ldap::is_ldap_ok();
		} // is_ldap_ok()

	public static function chk_add_default_user_domain($username) {
		if((strlen(INI_LDAP_DEF_DOMAIN) > 4) &&	// have a default domain
			(!preg_match('/^.+@.+$/', $username))) {	// and no domain in username
			$username .= '@' . INI_LDAP_DEF_DOMAIN;	// add default domain
			self::$cDBcms->logEvent('INFO: Using default domain for "' . $username . '".');
			} // if
		else self::$cDBcms->logEvent('INFO: Domain part of "' . $username . '".');
		return $username;
		} // chk_add_default_user_domain()

	public static function sanitize($str) {
			// @TODO This might better belong in Cdatabase_xxx classes,
			// since correct SQL escaping could vary between databases.
			if (function_exists('sqlite_escape_string')) {
				return sqlite_escape_string($str);
			}
			if (method_exists('SQLite3','escapeString')) {
				return SQLite3::escapeString($str);
			}
			if (function_exists('mysql_escape_string')) {
				return mysql_escape_string($str);
			}
			return $str;
		}

	protected static function is_apps_auth_ok() {	// check if apps auth function
		if(!self::$apps_auth_ok_chkd) {
			self::$apps_auth_ok_chkd = true;	// do it once
			self::$apps_auth_ok = false;
			if(!INI_APPS_AUTH_BOOL) return false;
			if(!file_exists(APPS_FS_CLASSES_DIR . 'apps_auth.php')) return false;
			if(!method_exists('Capps_auth', 'is_page_allowed')) return false;
			if(!method_exists('Capps_auth', 'is_navbar_element_allowed')) return false;
			if(!method_exists('Capps_auth', 'login')) return false;
			if(!method_exists('Capps_auth', 'init')) return false;
			if(!method_exists('Capps_auth', 'is_login_current')) return false;
			if(!method_exists('Capps_auth', 'logout')) return false;
			if(!method_exists('Capps_auth', 'get_short_name')) return false;
			if(!method_exists('Capps_auth', 'get_title')) return false;
			if(!method_exists('Capps_auth', 'get_JS')) return false;
			if(!method_exists('Capps_auth', 'get_html')) return false;
			self::$apps_auth_ok = true;
			} // if
		return self::$apps_auth_ok;
		} // is_apps_auth_ok()

	public static function is_page_allowed($name) {
		if(!self::is_apps_auth_ok()) return true;
		return Capps_auth::is_page_allowed($name);
		} // is_page_allowed()

	public static function is_navbar_element_allowed($name) {
		if(!self::is_apps_auth_ok()) return true;
		return Capps_auth::is_navbar_element_allowed($name);
		} // is_navbar_element_allowed()

	public static function is_apps_auth_login_current() {	// check if apps auth function
		if((self::is_apps_auth_ok()) &&
			(Capps_auth::is_login_current() == false)) {
			return false;
			} // if
		return true;
		} // is_apps_auth_login_current()

	public static function is_apps_auth_logged_in() {	// check if apps auth function
		// if(!self::is_apps_auth_ok()) return false;
		if((isset($_SESSION['apps_login'])) &&
			($_SESSION['apps_login']) &&
			(isset($_SESSION['user'])) &&	// check failed API calls leaving mixed up session data
			($_SESSION['user']) &&
			(!self::is_session_timed_out())) {
			return true;
			} // if
		return false;
		} // is_apps_auth_logged_in()

	protected static function init_apps_authed() {	// check if apps auth function
		if(!self::is_apps_auth_ok()) return true;	// ok don't logout
		if(self::$apps_session_started) return true;	// don't redo
		self::$apps_session_started = true;
		if(!self::is_apps_auth_ok()) return false;
		if(!self::$cApps_Auth) self::$cApps_Auth = new Capps_auth();	// run __construct()
		return Capps_auth::init(self::get_logged_in_username());
		} // init_apps_authed()

	protected static function is_session_timed_out($update_time = true) {
		if(empty($_SESSION['user']['time'])) return false;	// no session or no timeout
		if(empty(self::$session_timeout)) return false;	// no session_timeout (yet), no timeout
		if(((int)$_SESSION['user']['time'] + self::$session_timeout) < time()) return true;
		if($update_time) {
			$_SESSION['user']['time'] = time();
			$_SESSION['session_timeout'] = self::$session_timeout;	// copy for session browser and backup
			} // if
		return false;
		} // is_session_timed_out()

	protected static function is_still_logged_in($update_time = true) {
		if(!isset($_SESSION['user'])) return false;
		if(self::is_session_timed_out($update_time)) {
			// login timeout
			self::logout_user();
			return false;
			} // if
		if((self::is_apps_auth_logged_in()) &&
			(!self::is_apps_auth_login_current())) {
			// remote login finished
			self::logout_user();
			return false;
			} // if
		return true;
		} // is_still_logged_in()

	public static function is_a_cookie_login() {
		if((INI_ALLOW_COOKIE_LOGIN_BOOL) &&
			// already logged in (self::is_login_allowed()) &&
			(isset($_COOKIE[CMS_LOGIN_COOKIE_NAME])) &&
			(!empty($_COOKIE[CMS_LOGIN_COOKIE_NAME]))) {
			return true;
			} // if
		return false;
		} // is_a_cookie_login()

	public static function get_user_login_cookie_id($user_id) {
		$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_added" .
			" FROM  cms_users" .
			" WHERE cms_user_id = " . (int)$user_id . "";
		if(($user = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user))) {
			$cookie_id = $user['cms_user_id'] . ':' . session_id() . ':' . sha1($user['cms_user_name'] . $user['cms_user_added']) ;
			return $cookie_id;
			} // if
		return false;
		} // get_user_login_cookie_id()

	protected static function inc_login_count() {
		$login_cnt = self::get_user_json_data_key('cms_user_login_count');
		if(!$login_cnt) $login_cnt = 0;
		$login_cnt++;
		self::update_user_json_data('cms_user_login_count', $login_cnt);

		$login_datetime = self::get_gm_datetime();
		self::update_user_json_data('cms_user_last_login', $login_datetime);

		$user = self::get_logged_in_username();
		if(!empty($user)) {
			self::log_msg('User: ' . $user . ' logged in','info');
			} // if

		return true;
		} // inc_login_count()

	protected static function do_login_chores($user_admin) {
		// do login set ups
		self::inc_login_count();
		clearstatcache();
		Ccms_content_cache::reset_caches(false);
		unset($_SESSION['logging_in_flg']);
		$_SESSION['user']['logged_in_time'] = time();	// login timeout in seconds
		if($user_admin) {
			if (((!Ccms::do_cms_warnings()) || (!Ccms::do_cms_cli_warnings(true))) &&
				(self::getMsgsCount() > 0) &&
				(INI_DB_DIE_ON_ERRORS_BOOL)) {
				echo self::getMsgs();
				echo '<br>';
				die("Failed installation checks.");
				} // if

			if((self::is_apps_auth_ok()) &&
				(method_exists('Capps_auth','do_apps_warnings')))
					Capps_auth::do_apps_warnings(true);
			Ccms_apps::do_std_app_warnings();
			$cUP = new Ccms_update(true);	// check it
			} // if
		return true;
		} // do_login_chores()

	protected static function do_apps_login($user_name,$pass_word) {
		if(Ccms_auth::is_apps_auth_ok()) {
			if(Capps_auth::login($user_name,$pass_word)) {
				self::do_login_chores(false);	// do login set ups
				return true;
				} // if
			// else
			// just fall thru return false to allow local only login
			// used on install and configuration
			} // if
		return false;
		} // do_apps_login()

	protected static function get_group_manager_ids(&$user_admin,&$user_group_ids) {
		if($user_admin)  return '';
		// check if in an admin group
		$group_ids = explode(':',$user_group_ids);
		$group_manager_ids = array();
		foreach($group_ids as $gid) {
			// check if an admin
			$admin = self::$cDBcms->get_data_in_table('cms_groups','cms_group_admin','cms_group_id = ' . $gid);
			if($admin) {
				$user_admin = true;
				break;
				} // if
			// check if a group manager
			$manager_ids = self::$cDBcms->get_data_in_table('cms_groups','cms_group_admin_ids','cms_group_id = ' . $gid);
			if($manager_ids === false) continue;
			$mids = explode(':',$manager_ids);
			if(in_array($user_id, $mids)) $group_manager_ids[] = $gid;
			} // foreach
		if((!$user_admin) && (count($group_manager_ids) > 0)) {
			$user_group_manager_ids = implode(':', $group_manager_ids);
			return $user_group_manager_ids;
			} // if
		return $group_manager_ids;	// @TODO check this
		} // get_group_manager_ids()

	public static function log_in_user_id($user_or_email,$remember = false, $auth_type = false) {
		if((self::$cDBcms->is_table_present('cms_users')) &&
			($user_rows = self::$cDBcms->query("SELECT COUNT(*) AS total FROM  cms_users WHERE  cms_user_enabled = 1")) &&
			($user_rows = self::$cDBcms->fetch_array($user_rows)) &&
			($user_rows['total'] > 0)) {

			$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_password_md5,cms_user_admin,cms_user_group_ids" .
				" ,cms_user_auth_ldap,cms_user_email,cms_user_mobile" .
				" FROM  cms_users" .
				" WHERE  cms_user_enabled = 1 AND ( cms_user_id = " . (int)$user_or_email . " OR cms_user_name = '" . $user_or_email . "' OR cms_user_email = '" . $user_or_email . "' )" ;
			if(($user = self::$cDBcms->query($sql_query)) &&
				($user = self::$cDBcms->fetch_array($user))) {
				$user_id = $user['cms_user_id'];
				$user_name = $user['cms_user_name'];
				$user_password_md5 = $user['cms_user_password_md5'];
				$user_admin = $user['cms_user_admin'];
				$user_group_ids = $user['cms_user_group_ids'];
				$cms_user_auth_ldap = $user['cms_user_auth_ldap'];
				$cms_user_email = $user['cms_user_email'];
				$cms_user_mobile = $user['cms_user_mobile'];

				$user_group_manager_ids = self::get_group_manager_ids($user_admin, $user_group_ids);

				$_SESSION['user'] = array(
					'id' => $user_id,
					'name' => $user_name,
					'time' => time(),	// time in seconds
					'admin' => $user_admin,	// administrator flag
					'group_manager_ids' => $user_group_manager_ids,
					'group_ids' => $user_group_ids,	// group ids array
					'type' => ($auth_type ? $auth_type:($cms_user_auth_ldap ? 'LDAP':'local')),
					'email' => $cms_user_email,
					'phone' => $cms_user_mobile,
					);
				if((INI_ALLOW_COOKIE_LOGIN_BOOL) &&
					($remember)) {
					$cookie_id = self::get_user_login_cookie_id($user_id);
					$next_time = time() + INI_SESSIONS_COOKIE_TIMEOUT_SECS;
					setcookie(CMS_LOGIN_COOKIE_NAME, $cookie_id, $next_time,'/');	// 90 days
					self::update_user_json_data('cms_user_login_cookie_time', $next_time);
					} // if
				else if(isset($_COOKIE[CMS_LOGIN_COOKIE_NAME])) {
					setcookie(CMS_LOGIN_COOKIE_NAME, 0, time() - 3600,'/');	// expire cookie
					} // else if

				self::do_login_chores($user_admin);	// do login set ups
				return true;	// on the AppsCMS
				} // if
			} // if
		return false;	// not on the AppsCMS
		} // log_in_user_id()

	public static function cms_cookie_banner_closed() {
		$timeout = time() + ((int)CMS_C_COOKIE_BANNER_TTL * 24 * 3600);
		self::update_user_json_data('cms_user_cookie_banner_time', time());
		} // cms_cookie_banner_closed()

	public static function is_user_logged_in($update_time = false) {
		// echo 'SID: ' . session_id() . '<br>' . PHP_EOL;	var_dump($_SESSION); exit(0);	// test
		if(isset($_SESSION['user'])) {
			if(!self::is_session_timed_out()) return true;
			} // if
		return false;
		} // is_user_logged_in()

	public static function is_apps_user() {
		if(!self::is_user_logged_in()) return false;
		return self::is_apps_auth_logged_in();
		} // is_apps_user()

	public static function is_admin_user() {
		if(self::is_user_logged_in()) {
			if((int)$_SESSION['user']['admin'] > 0) return true;
			} // if
		return false;
		} // is_admin_user()

	public static function is_group_manager($gids = -1) {
		if(!self::is_user_logged_in()) return false;
		if(self::$group_manager !== false) return (self::$group_manager ? true:false);
		self::$group_manager = 0;
		if(self::is_admin_user()) self::$group_manager = 1;
		else if((isset($_SESSION['user']['group_manager_ids'])) &&
			(!empty($_SESSION['user']['group_manager_ids'])) &&
			(self::is_user_logged_in())) { // is a group manager
			if(($gids == -1) && (!empty($_SESSION['user']['group_manager_ids']))) self::$group_manager = 1; // is a group manager of something
			else {
				$mids = explode(':',$_SESSION['user']['group_manager_ids']);
				$gids = explode(':',$gids);
				foreach($gids as $gid) {
					if((int)$gid == 0) { self::$group_manager = 1; break; } // all groups
					else if(in_array($gid,$mids)) { self::$group_manager = 1; break; }
					} // foreach
				} // else
			} // if
		return (self::$group_manager ? true:false);
		} // is_group_manager()

//	public static function is_group_user($gids) {
//		if(self::is_admin_user()) true;
//		if((isset($_SESSION['user']['group_user_ids'])) &&
//			(!empty($_SESSION['user']['group_user_ids'])) &&
//			(self::is_user_logged_in())) { // is a group user
//			$mids = explode(':',$_SESSION['user']['group_user_ids']);
//			$gids = explode(':',$gids);
//			foreach($gids as $gid) {
//				if((int)$gid == 0) { return true; } // all groups
//				else if(in_array($gid,$mids)) { return true; }
//				} // foreach
//			} // if
//		return false;
//		} // is_group_user()

	public static function is_config_user() {
		if(self::is_admin_user()) return true;
		return self::is_group_manager(-1);
		} // is_config_user()

	public static function check_user_group_ids($group_ids) {
		if(strlen($group_ids) == 0) return false;
		$op_group_ids = explode(':',(string)$group_ids);
		if(in_array(0,$op_group_ids)) return true;	// all groups
		if(!isset($_SESSION['user']['group_ids'])) return false;
		// else logged
		$user_group_ids = explode(':',(string)$_SESSION['user']['group_ids']);
		if(in_array(0,$user_group_ids)) return true;
		foreach($user_group_ids as $uid) {
			if(in_array($uid,$op_group_ids)) return true;
			} // foreach
		return false;
	} // check_user_group_ids()

	public static function after_login($failed=false) {
		if(!$failed) {
			self::inc_login_count();
			} // if
		if((!$failed) && (!INI_LOGIN_FAIL2REFERER_BOOL)) {
			// normal post login page
			// clean up to stop repeats to same action (i.e. login)
			self::$action = false;
			unset($_SESSION['action']);
			Ccms::unset_get_or_post('action');
			self::$cms_action = false;
			unset($_SESSION['cms_action']);
			Ccms::unset_get_or_post('cms_action');
			$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
			header('Location: ' . $url);
			exit(0);
			} // if

		$referer = $_SERVER['HTTP_REFERER'];
		if (((self::$ssl_required) && (substr($referer,0,strlen(CMS_SSL_URL)) == CMS_SSL_URL)) ||
			((!self::$ssl_required) && (substr($referer,0,strlen(CMS_WWW_URL)) == CMS_WWW_URL))) {
			// Redirect to referer if it's part of our site

			if(self::$ssl_required)
				$referer = preg_replace('/^http:/','https:',$referer);	// change referrer to https
			$referer = preg_replace('/&?login_failed=\\w+/','',$referer);	// clean previous fail
			$referer = preg_replace('/&?action=.*login/','',$referer);	// stop circular redirects
			$referer = preg_replace('/\\?$/','',$referer);	// remove the trailing ? if present

			if ($failed) {
				$referer .= strpos($referer,'?') === false ? '?' : '&';
				$referer .= 'login_failed=true';
				} // if
			} // if
		else {
			// Otherwise something funky's going on, just go to homepage
			$referer = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
			if ($failed) $referer .= '?login_failed=true';
			} // else

		header('Location: ' . $referer);
		exit(0);
		} // after_login()

	public static function login_failed() {
		if(INI_LOGIN_FAIL2REFERER_BOOL) self::after_login(true);		// will not return
		self::addMsg('Login failed.','warning');
		return;
	}

	public static function login_user() {	// read login forms and check
		if(!self::is_login_allowed()) {
			$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
			header('Location: ' . $url);
			exit (0);
			} // if
		if(self::is_still_logged_in()) {
			unset($_SESSION['action']);
			// no this is circular	self::after_login();
			return true;
			} // if

		self::$login_local = self::get_or_post('local_login');
		if((!self::$login_local) &&
			(self::is_apps_auth_ok()) && // use apps login (from remote auth)
			(!Ccms::is_get_or_post('user_name')) &&
			(!Ccms::is_get_or_post('user_password')) &&
			($response = Capps_auth::login())) {
			if(isset($_SESSION['action'])) unset($_SESSION['action']);
			if(Ccms_auth::is_user_logged_in()) $_SESSION['apps_login'] = true;
			else $_SESSION['apps_login'] = false;
			// logged in
			self::after_login();
			} // if
		$user_name = '';
		$user_password_md5 = '';
		$user_id = 0;
		if(Ccms::is_get_or_post('user')) {	// blind login
			if((self::$cDBcms->is_table_present('cms_users')) &&
				(!$user_name = self::$cDBcms->get_data_in_table('cms_users','cms_user_name',
					"cms_user_enabled = 1 AND  cms_user_name = '" . Ccms::get_or_post('user') . "'" .
					(INI_WEBSITE_CLOSED_BOOL ? ' AND cms_user_admin = 1':'')))) {
				// username not found
				self::login_failed();
				} //if
			// else username found
			} // if
		else if((Ccms::is_get_or_post('user_name')) &&
			(Ccms::is_get_or_post('user_password'))) {

			if(self::$login_local) {
				if(self::do_apps_login(Ccms::get_or_post('user_name'), Ccms::get_or_post('user_password'))) {
					if(isset($_SESSION['action'])) unset($_SESSION['action']);
					$_SESSION['apps_login'] = true;
					$_SESSION['LOGGED_IN'] = Capps_auth::get_short_name();
					// logged in
					self::do_eula();		// will redirect if EULA required
					self::after_login();
					} // if
				else if((self::$cDBcms->is_table_present('cms_users')) &&
					($user_rows = self::$cDBcms->query("SELECT COUNT(*) AS total FROM  cms_users WHERE cms_user_enabled = 1" .
						(INI_WEBSITE_CLOSED_BOOL ? ' AND cms_user_admin = 1':''))) &&
					($user_rows = self::$cDBcms->fetch_array($user_rows)) &&
					($user_rows['total'] > 0)) {
					// have live admins
					$user_name = self::sanitize(Ccms::get_or_post('user_name'));

					$where = " WHERE  cms_user_enabled = 1";
					if((CMS_C_ALLOW_PHONE_LOGIN) && (CMS_C_ALLOW_EMAIL_LOGIN)) {
						$where .= " AND ( cms_user_name = '" . $user_name . "' OR cms_user_email = '" . $user_name . "' OR cms_user_mobile = '" . $user_name . "')";
						} // if
					else if(CMS_C_ALLOW_EMAIL_LOGIN) {
						$where .= " AND ( cms_user_name = '" . $user_name . "' OR cms_user_email = '" . $user_name . "' )";
						} // if
					else if(CMS_C_ALLOW_PHONE_LOGIN) {
						$where .= " AND ( cms_user_name = '" . $user_name . "' OR cms_user_mobile = '" . $user_name . "')";
						} // if
					else $where .= " AND cms_user_name = '" . $user_name . "'";
					if(INI_WEBSITE_CLOSED_BOOL) $and_sql .= ' AND cms_user_admin = 1';

					$sql_query = "SELECT  cms_user_id,cms_user_password_md5,cms_user_auth_ldap" .
						" FROM  cms_users" . $where . " LIMIT 1";
					if(($user = self::$cDBcms->query($sql_query)) &&
						($user = self::$cDBcms->fetch_array($user))) {
						$user_id = $user['cms_user_id'];
						$auth_ldap = $user['cms_user_auth_ldap'];
						$user_password_md5 = $user['cms_user_password_md5'];
						} // if
					else {
						self::log_msg('Username not found.');
						self::login_failed();
						return false;
						} // else
					} // if

	//		print_r($_POST); exit(0);	// test
	//		print_r($_SESSION); exit(0);	// test

				if(((int)$auth_ldap > 0) && // use ldap
					(Ccms_ldap::is_user_ldap_authed(self::get_or_post('user_name'), self::get_or_post('user_password'))) &&
					(self::log_in_user_id($user_id,(self::get_or_post_checkbox('remember') ? true:false)))) {
					if(isset($_SESSION['action'])) unset($_SESSION['action']);
					$_SESSION['LOGGED_IN'] = 'LDAP/AD';
					// logged in
					self::do_eula();		// will redirect if EULA required
					self::after_login();
					} // if
				else if(((int)$auth_ldap > 0) && (!INI_LOCAL_LOGIN_AUTH_SERVER_NOT_FOUND_BOOL)) {
					self::log_msg('External Authentication Login failed.');
					self::login_failed();
					return false;
					} // else if
				else if((md5(Ccms::get_or_post('user_password')) == $user_password_md5) &&	// use local
					(self::log_in_user_id($user_id,((self::get_or_post('remember') == 'on') ? true:false)))) {
					if(isset($_SESSION['action'])) unset($_SESSION['action']);
					$_SESSION['LOGGED_IN'] = 'Local';
					// logged in
					self::do_eula();		// will redirect if EULA required
					self::after_login();
					} // if

				} // if

			self::log_msg('Login failed.');
			self::login_failed();
			return false;
			} // if
		else {
			// no, it redirects, use the INI_LOGIN_VIA_HOMEPAGE_BOOL = true	self::login_failed();
			// just fall thru to putup login page
			return false;
			}
		return self::is_user_logged_in();	// logged in
		} // login_user()

	public static function logout_user($redirect = false) {

		$user = self::get_logged_in_username();
		if(!empty($user)) {
			self::update_user_json_data('cms_user_last_logoff', self::get_gm_datetime());
			self::log_msg('User: ' . $user . ' logged out','info');
			} // if

		if(isset($_SESSION['apps_login'])) {
			if($_SESSION['apps_login']) {
				if(self::is_apps_auth_ok()) Capps_auth::logout();
				} // if
			} // if
		unset($_SESSION['user']);
		unset($_SESSION['action']);
		Ccms::unset_get_or_post('action');

		// make sure it is completely logout, stop redirect loop
		unset($_SESSION['apps_login']);
		unset($_SESSION['LOGGED_IN']);
		unset($_SESSION['ldap']);
		unset($_SESSION['user']);
		unset($_SESSION['action']);

		Ccms_content_cache::reset_caches(false);

		Ccms_ldap::logout_ldap_user();
		if(isset($_SESSION['apps_login'])) {
			if(self::is_apps_auth_logged_in()) {
				Capps_auth::logout();
				} // if
			} // if
		unset($_SESSION['apps_login']);
		unset($_SESSION['LOGGED_IN']);
		Ccms_proxy::clear_file_proxy(); // clear user session proxy list
		// too much session_destroy();

		if($redirect) {	// goto home page
			$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
			header('Location: ' . $url);
			exit (0);
			} // if
		return true;
		} // logout_user()

	public static function start_user_session() {
		if((self::$session_timeout !== false) &&
			(!empty($_SESSION)) &&
			(is_array($_SESSION)) &&
			(count($_SESSION) > 0)) {
			// session already
			self::log_msg('Session already open.','info');
			return true;
			} // if
		if(self::$session_timeout === false) {
			if(self::is_a_cookie_login()) {
				// session lifetime for remembered logins
				self::$session_timeout = INI_SESSIONS_COOKIE_TIMEOUT_SECS;
				} // if
			else self::$session_timeout = INI_SESSIONS_USER_TIMEOUT_SECS;
			} // if
		if(self::is_a_cookie_login()) {
			// session lifetime for remembered logins
			session_set_cookie_params(INI_SESSIONS_COOKIE_TIMEOUT_SECS);
			} // if
		else session_set_cookie_params(INI_SESSIONS_USER_TIMEOUT_SECS);

		session_start();

		self::is_still_logged_in();

		if((self::is_a_cookie_login()) &&
			(!isset($_SESSION['user']))) {
			// do cookie login
			$ids = explode(':',$_COOKIE[CMS_LOGIN_COOKIE_NAME]);
			if((self::get_user_login_cookie_id($ids[0]) == $_COOKIE[CMS_LOGIN_COOKIE_NAME]) &&
				(is_readable(session_save_path() . '/sess_' . $ids[1]))) {
				self::log_in_user_id($ids[0],true);
				$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
				header('Location: ' . $url);
				exit (0);
				} // if
			} // if

		if((INI_ALWAYS_LOGIN_BOOL) &&
			(basename($_SERVER['PHP_SELF']) != 'login.php') &&
			((!Ccms::is_get_or_post('action')) ||
			((Ccms::get_or_post('action') != 'login') && (Ccms::get_or_post('action') != 'cms_login')))) {
			// @TODO check url
			if(!self::is_user_logged_in()) {
				$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'login.php';
				header('Location: ' . $url);
				exit (0);
				} // if
			} // if
		else {
			if(self::is_user_logged_in()) {
				// still in time
				if(self::is_a_cookie_login()) {
					setcookie(CMS_LOGIN_COOKIE_NAME, $_COOKIE[CMS_LOGIN_COOKIE_NAME], time() + INI_SESSIONS_COOKIE_TIMEOUT_SECS,'/');	// 90 days
					} // if
				} // if
			} // else
		if(!self::init_apps_authed()) {
			self::addMsg('Apps authentication initialization failed.','warn');
			$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'logout.php';
			header('Location: ' . $url);
			exit (0);
			} // if
		return true; //ok
		} // start_user_session()

	private static function is_ip_local_subnet($ip) {
		$local_subnets = array('127.0.0.','172.16.','192.88.99.','192.168.', '10.', '::1' );
		foreach($local_subnets as $n) {
			if(substr($ip,0,strlen($n)) == $n) {
				return true;	// not public
				} // if
			} //foreach
		return false;
		} // is_ip_local_subnet()

	private static function get_client_ip_address_via_public_proxy() {
		// see http://en.wikipedia.org/wiki/X-Forwarded-For

		global $_SERVER;
		$ip = null;
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else if(getenv('HTTP_X_FORWARDED_FOR')) {
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} // else if

		if(empty($ip)) return null;	// no proxy used

		$ip_array = explode(',',$ip);
		$ip = $ip_array[0];

		// filter out local subnets
		if(!self::is_ip_local_subnet($ip)) return null;	// not public
		return $ip;
		} // get_client_ip_address_via_public_proxy()

	public static function get_client_ip_address() {
		global $_SERVER;
		if(self::$client_ip !== false) return self::$client_ip;

		if((self::$client_ip = self::get_client_ip_address_via_public_proxy())) return self::$client_ip;

		if (isset($_SERVER)) {
			if (isset($_SERVER['HTTP_CLIENT_IP'])) {
				self::$client_ip = $_SERVER['HTTP_CLIENT_IP'];
			} else if(isset($_SERVER['REMOTE_ADDR'])) {
				self::$client_ip = $_SERVER['REMOTE_ADDR'];
			}
		} else {
			if (getenv('HTTP_CLIENT_IP')) {
				self::$client_ip = getenv('HTTP_CLIENT_IP');
				}
			elseif(getenv('REMOTE_ADDR')) {
				self::$client_ip = getenv('REMOTE_ADDR');
				}
		} // else

		if((!self::$client_ip) && (isset($_SERVER['REMOTE_ADDR']))) self::$client_ip = $_SERVER['REMOTE_ADDR'];	// as a last resort

		return self::$client_ip;
		} // get_client_ip_address()

	protected static function check_login_ip_allowed($log_flg = true) {
		if(self::is_cli()) return true;

		$client_ip = self::get_client_ip_address();

		if((!defined('INI_ALLOWED_LOGIN_IPS')) ||
			(strlen(INI_ALLOWED_LOGIN_IPS) < 4)) return true;	// always ok

		$country = '';
		$allowed = self::unserialize_string2arry(INI_ALLOWED_LOGIN_IPS,',');
		foreach($allowed as $aw) {
			$allow = $aw[0];
			if(preg_match('/^[a-z]*$/i',$allow)) {	// country name
				if(!function_exists('geoip_country_name_by_name')) {
					if($log_flg) self::$cDBcms->logEvent('WARNING: PECL geoip >= 2.0 not found.');
					return false;
					} // if
				else if(!self::is_ip_local_subnet ($client_ip)) {
					$country = @geoip_country_name_by_name($client_ip);
					if((!empty($country)) &&
						(preg_match('/' . $allow . '/i',$country))) return true;	// its ok
					} // else if
				} // if
			else if(preg_match ('/^[0-9\.\/]*$/', $allow)) {	// ipv4 address or range
				if(self::ipCIDRCheck($client_ip,$allow)) return true;	// its OK
				} // else
			else if(preg_match ('/^[0-9:]*$/', $allow)) {	// ipv6 address
				if($client_ip == $allow) return true;	// its OK
				} // else
			} // foreach
		if($log_flg) self::log_msg ('Failed login attempt from ' . $client_ip . (!empty($country) ? '(' . $country . ')':'') . ', IP not allowed.','warn');
		return false;
		} // check_login_ip_allowed()

	public static function is_login_allowed() {
		if(self::$login_allowed) return true;

		if((!self::is_apps_auth_logged_in()) &&
			(self::$session_cookie_ok) &&
			(self::$have_session) &&
			(self::check_login_ip_allowed())
			)
			self::$login_allowed = true;
		return self::$login_allowed;
		} // is_login_allowed()

	public static function get_chg_password_lnk(&$txt,$span_flg = true,$label='&nbsp;**&nbsp;',$class=false) {
		if (!self::is_user_logged_in()) return false;
		if($_SESSION['user']['type'] == 'local') {	// only for local users
			$icon = Ccms_html::get_navbar_icon_text('chg_passwd',$label);
			if($span_flg) $txt .= '<span style="font-size: 10px; font-style: normal;font-weight:normal;">';
			$class_str = $class ? ' class="' . $class . '"' : '';
			$txt .= '<a href="index.php?cms_action=get_password" title="Change Local Password"' . $class_str . '>' . $icon . '</a>';
			if($span_flg) $txt .= '</span>';
			} // if
		} // get_chg_password_lnk()

	protected static function get_auth_types() {
		$auths = array();
		if((self::is_apps_auth_ok()) &&
			(Capps_auth::init_remote())) {
			$auths[] = array(
				// 'name' => Capps_auth::get_short_name (),
				'name' => 'Login via: ' . Capps_auth::get_short_name (),
				'title' => 'Login with ' . Capps_auth::get_title() . ' authentication.',
				'text' => Capps_auth::get_html(),
				'JS' => Capps_auth::get_JS(),
				);
			} // if

		ob_start();
		require(CMS_FS_OPS_DIR . 'cms_login_local_form.php');
		$text = ob_get_clean();
		$auths[] = array(
			// 'name' => (self::is_ldap_ok() ? ((strlen(INI_LDAP_DEF_DOMAIN) >4) ? '@' . INI_LDAP_DEF_DOMAIN:'LDAP') . ' or Local':'Local'),
			'name' => 'Login via: ' . CMS_C_CO_NAME,
			'title' => 'Login with local authentication.',
			'text' => $text,
			'JS' => '',
			);
		return $auths;
		} // get_auth_types()

	protected static function get_auth_simple($auth_text,$class = '') {
		// generate a plain form
		$auths = self::get_auth_types();
		$text = array();

//		$text[] = '<div class="auth_drop" style="display: block;">';
//		for($i = 0; $i < count($auths); $i++) {
//			$title = $auths[$i]['title'];
//			$text[] = '	<div class="auth_drop_section">';
//			$text[] = '		<div class="auth_drop" id="id_auth_dropper[' . $i . '][cntl]"' .
//				($db ? ' onclick="auth_drop_toggle(\'id_auth_dropper[' . $i . '][text]\',true);"':'') .
//				(!empty($title) ? ' title="' . $title . '"':'') .
//				'><h4>' . $auths[$i]['name'] .
//				'</h4></div>';
//			$text[] = '		<div class="auth_drop" id="id_auth_dropper[' . $i . '][text]" style="display: ' .
//				($db ? 'none':'block') .
//				';">';
//			$text[] = '			' . $auths[$i]['text'];
//			$text[] = '		</div>';
//			$text[] = '	</div>';
//			} // for
//		$text[] = '</div>';
		$text[] = $auths[0]['text'];
		return (!empty($text) ? PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL:'');
		} // get_auth_simple()

	protected static function get_auth_droppers($auth_text,$class = '',$db = true) {
		if(($db) && ((self::$ssl_in_use) || (INI_ALLOW_NON_SSL_LOGIN_BOOL)))	{ // drop box with a login form, one less screen reload
			$text = Ccms_html::set_JS_password_resource(false);	// get pw show/reveal first
			$auths = self::get_auth_types();
			$form = $auths[0]['text'];
			$pntr_text = '<span style="cursor: pointer;">' . $auth_text . '</span>';
			$text .= Ccms_html::getFormSimpleDropPanel($pntr_text,$form);	//
			return PHP_EOL . $text . PHP_EOL;
			} // if
		if((preg_match('/login/',(self::$action ? self::$action:self::$page_info['action']))) ||	// app already logging in
			(preg_match('/login/',(self::$cms_action ? self::$cms_action:self::$page_info['cms_action'])))) {	// cms already logging in
			$text = Ccms_html::set_JS_password_resource(false);	// get pw show/reveal first
			$text .= self::get_auth_simple($auth_text, $class);
			} // if
		else { // needing a URL
			$text = '<a class="' . $class . '" href="' . (self::$has_ssl_available ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?cms_action=cms_login">' . $auth_text . '</a>';
			} // else
		return PHP_EOL . $text . PHP_EOL;
		} // get_auth_droppers()

	protected static function get_user_details() {
		$user_details = self::get_logged_in_username();
		$roles = array();
		if(self::is_admin_user()) $roles[] = 'Admin';
		if(self::is_group_manager()) $roles[] = 'Manager';
		if(isset($_SESSION['LOGGED_IN'])) $roles[] = $_SESSION['LOGGED_IN'];

		if(!empty($roles)) $user_details .= '(' . implode(', ',$roles) . ')';
		return $user_details;
		} // get_user_details()

	public static function get_login_logout($class= '', $include_chg_pw = false) {
		$txt = '';
		if(self::is_user_logged_in()) {
			if(($_SESSION['user']['type'] == 'local') &&
				!Ccms_auth::is_apps_auth_logged_in()) {	// only for local users
				$include_chg_pw = true;
				} // if
			$user_details = self::get_user_details();
			$icon = Ccms_html::get_navbar_icon_text('logout','Log&nbsp;out');
			$txt .= '<a'. (!empty($class) ? ' class="' . $class . '"':'') . ' href="logout.php"' . (!empty($user_details) ? ' title="' . $user_details . '"':'') . ' onclick="Ccms_cursor.setWait();">' . $icon . '</a>';
			if ($include_chg_pw) self::get_chg_password_lnk($txt,false);
			} // if
		else if(self::is_login_allowed()) {
			$icon = Ccms_html::get_navbar_icon_text('login','User:&nbsp;Login');
			$auths_details = self::get_auth_droppers($icon,$class);	// ,INI_NAV_BAR_BOOL);
			$txt .= $auths_details;
			} // if
		return $txt;
		} // get_login_logout()

	public static function get_signin_signout($class= '', $db = true, $include_chg_pw = false) {	// similiar to get_login_logout() with cosmetic differences
		$txt = '';
		if(self::is_user_logged_in()) {
			if(($_SESSION['user']['type'] == 'local') &&
				!Ccms_auth::is_apps_auth_logged_in()) {	// only for local users
				$include_chg_pw = true;
				} // if
			$user_details = self::get_user_details();
			// self::get_chg_password_lnk($txt,false);
			$icon = Ccms_html::get_navbar_icon_text('logout','Sign&nbsp;out');
			$txt .= '<a'. (!empty($class) ? ' class="' . $class . '"':'') . ' href="logout.php"' . (!empty($user_details) ? ' title="' . $user_details . '"':'') . ' onclick="Ccms_cursor.setWait();">' . $icon . '</a>';
			if ($include_chg_pw) self::get_chg_password_lnk($txt,false);
			} // if
		else if(self::is_login_allowed()) {
			$icon = Ccms_html::get_navbar_icon_text('login','User:&nbsp;Sign&nbsp;in');
			$auths_details = self::get_auth_droppers($icon,$class,$db);
			$txt .= $auths_details;
			} // if
		return $txt;
		} // get_signin_signout()

	public static function set_password() {
		$user_name = self::get_or_post('user_name');
		$user_password = self::get_or_post('user_password');
		$user_confirm = self::get_or_post('user_confirm');
		$user_password_md5 = '';
		$user_id = self::get_or_post('user_id');
		$user_auth = self::get_or_post('user_auth');

		if((!$user_name) || (!$user_id) || (!$user_auth) ||
			(!$user_password) || (!$user_confirm)) {
			self::$cDBcms->logEvent('ERROR: Call to set password is missing parameters.');
			return false;	// missing something
			} // if

		$user_name = self::sanitize($user_name);

		$sql_query = "SELECT  cms_user_id" .
			" FROM  cms_users" .
			" WHERE  cms_user_enabled = 1 AND  cms_user_name = '" . $user_name . "'" .
			" LIMIT 1";
		if(($user_ary = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user_ary))) {
			$user_id = $user['cms_user_id'];
			if((int)$user_id != (int)Ccms::get_or_post('user_id')) {
				self::addMsg('Username and user id do not match.');
				return false;
				}
			} // if
		else {
			self::addMsg('Username: ' . $user_name . ' not found.');
			return false;
			} // else

		$cms_user_password = html_entity_decode($user_password);
		$cms_user_confirm = html_entity_decode($user_confirm);
		if(strlen($cms_user_password) < 4) {
			self::addMsg('Password too short.');
			} // else if
		else if($cms_user_password != $cms_user_confirm) {
			self::addMsg('Password/confirm error.');
			} // if
		else {
			$fields = array();
			$fields['cms_user_password_md5'] = md5($cms_user_password);
			if(self::$cDBcms->perform('cms_users',$fields,'update',"cms_user_id = " . (int)$user_id . "")) {
				self::$cDBcms->logEvent('Set new local password for ' . $user_name . ".");
				self::log_in_user_id($user_id,false);
				self::addMsg('Set new password for ' . $user_name . ".",'info');
				$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
				header('Location: ' . $url);
				exit (0);
				} // if
			} // if
		self::addMsg('Set password failed.');
		$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?cms_action=get_password';
		header('Location: ' . $url);
		exit (0);
		return false;	// never gets here
		} // set_password()

	public static function get_logged_in_username() {
		if(self::is_cli()) {
			$user = Ccms_posix::get_current_username();
			return $user;
			} // if
		if(!self::is_user_logged_in()) return '';
		if(!isset($_SESSION['user']['name'])) return '';
		if(empty($_SESSION['user']['name'])) return '';
		return $_SESSION['user']['name'];
		} // get_logged_in_username()

	public static function is_eula_enabled($key = false) {
		if(!CMS_C_EULA_ENABLE) return false;
		if((!$key) && (strlen(CMS_C_EULA_LINK) < 8)) return false;
//		$user = self::get_logged_in_username();
//		if(empty($user)) return false;
		return true;
		} // is_eula_enabled()

	public static function get_user_json_name($user = '') {
		if(empty($user)) $user = self::get_logged_in_username();
		if(empty($user)) {
			if((defined('CMS_C_DEFAULT_CLIENT_NAME')) &&
				(CMS_C_DEFAULT_CLIENT_NAME == 'SID') &&
				(!empty(self::$session_id))) $user = self::$session_id;
			else $user = self::get_client_ip_address();	// use IP address as substitute
			if(empty($user)) return false;
			} // if
		return $user;
		} // get_user_json_name()

	public static function get_user_json_data_ary($user = '') {
		if(!$user = self::get_user_json_name($user)) return false;
		$json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		$json_def = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		if(!file_exists($json_file)) $json = $json_def;
		else {
			$json = self::load_json($json_file);
			$json = array_merge($json_def,$json);	// merge in new variables
			} // else
		if(!isset($json['cms_user'])) return array();
		return $json['cms_user'];
		} // get_user_json_data_ary()

	public static function save_user_json_data_ary($data,$user = '') {
		if(!$user = self::get_user_json_name($user)) return false;
		$json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		if(!file_exists($json_file)) $json = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		else $json = self::load_json($json_file);
		if(!is_array($json)) $json = array();
		$json['cms_user'] = $data;
		if(INI_LOG_USER_UPDATES_BOOL) {
			self::log_msg('User: ' . $user . ', Variables: ' . json_encode($json),'info');
			} // if
		return self::save_json($json);
		} // save_user_json_data_ary()

	public static function get_user_json_data_key($key,$user = '') {
		if((empty($user)) &&
			(!$user = self::get_user_json_name($user))) return false;
		$json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		if(!file_exists($json_file)) $json = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		else $json = self::load_json($json_file);
		if(!isset($json['cms_user'][$key])) return false;
		return $json['cms_user'][$key];
		} // get_user_json_data_key()

	public static function update_user_json_data($key,$new_val,$user = '') {
		if(!$user = self::get_user_json_name($user)) return false;
		$json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		if(!file_exists($json_file)) $json = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		else $json = self::load_json($json_file);
		$json['username'] = $user;
		$json['cms_user'][$key] = $new_val;
		if(INI_LOG_USER_UPDATES_BOOL) {
			self::log_msg('User: ' . $user . ', Variables: ' . json_encode($json),'info');
			} // if
		return self::save_json($json_file, $json);
		} // update_user_json_data()

	public static function is_eula_agreement_required($key = false) {
		// the basics first
		if((self::is_cli()) || (self::is_rebuild())) return false;
		if(Ccms::is_get_or_post('ajax')) return false;
		// if(self::get_or_post('cms_action') == 'get_eula') return false;
		if(self::get_or_post('cms_action') == 'eula') return false;
		if(self::get_or_post('action') == 'eula') return false;
		if(!CMS_C_EULA_ALL) {
			if(!self::is_user_logged_in()) return false;
			if(!self::is_eula_enabled($key)) return false;
			} // if

		if(empty($key)) $key = 'cms_user_eula_time';
		$agree_time = self::get_user_json_data_key($key);
		if(!$agree_time) return true;
		$ttl_time = CMS_C_EULA_TTL * 24 * 3600;	// days to seconds
		if(($agree_time > 0) && ($agree_time + $ttl_time) > time()) return false;
		// else required
		return true;
		} // is_eula_agreement_required()

	public static function do_eula() {		// will redirect if EULA required
		if((!CMS_C_EULA_ALL) && (!self::is_user_logged_in())) return false;
		if(!self::is_eula_agreement_required()) return false;
		if((self::$cms_action) == 'get_eula') return false;
		$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?cms_action=get_eula';
		header('Location: ' . $url);
		exit (0);
		} // do_eula()

	public static function get_eula_time() {
		if(!self::is_eula_enabled()) return false;
		$agree_time = self::get_user_json_data_key('cms_user_eula_time');
		if(!$agree_time) return false;
		return $agree_time;
		} // get_eula_time()

	public static function check_eula_form() {
		// if(!self::is_eula_enabled()) return false;
		$user_name = self::get_or_post('user_name');
		$user_id = self::get_or_post('user_id');
		$user_auth = self::get_or_post('user_auth');
		$body_id = self::get_or_post('body_id');
		$tool_id = self::get_or_post('tool_id');
		if((!$user_name) || (!$user_auth)) {
			if(self::get_or_post('eula_submit') != 'eula_save') {
				self::$cDBcms->logEvent('ERROR: Call to check_eula_form is missing parameters.');
				return false;	// missing something
				} // if
			} // if

		if((self::get_or_post('eula') == 'agreed') ||
			(self::get_or_post('cms_eula') == 'agreed')) {
			// save they agreed
			if($body_id) {
				Ccms::update_body_terms2show($body_id,time());
				$url = $_SERVER['HTTP_REFERER'];
				header('Location: ' . $url);
				exit (0);
				} // if
			else if($tool_id) {
				Ccms::update_tool_terms2show($tool_id,time());
				$url = $_SERVER['HTTP_REFERER'];
				header('Location: ' . $url);
				exit (0);
				} // else if
			else {
				self::update_user_json_data('cms_user_eula_time',time());
				$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
				header('Location: ' . $url);
				exit (0);
				} // else
			} // if
		// else reset eula and logout
		self::logout_user();
		self::update_user_json_data('cms_user_eula_time',0);
		$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // check_eula_form()

//	public static function get_cookie_ok_time() {
//		$user = self::get_logged_in_username();
//		if(empty($user)) {	// not logged in
//			if(isset($_SESSION['cookie_ok_time'])) return $_SESSION['cookie_ok_time'];
//			return false;
//			} //if
//
//		$cookie_ok_time = self::get_user_json_data_key('cms_user_login_cookie_time',$user);
//		return $cookie_ok_time;
//		} // get_cookie_ok_time()

//	public static function check_cookie_ok_form() {
//		if(!self::is_eula_enabled()) return false;
//		$user_name = self::get_or_post('user_name');
//		$user_id = self::get_or_post('user_id');
//		$user_auth = self::get_or_post('user_auth');
//		if((!$user_id) || (!$user_name) || (!$user_auth) ||
//			(self::get_or_post('eula_submit') != 'eula_save')) {
//			self::$cDBcms->logEvent('ERROR: Call to check_eula_form is missing parameters.');
//			return false;	// missing something
//			} // if
//
//		if(self::get_or_post('eula') == 'agreed') {
//			// save they agreed
//			$fields = array();
//			$fields['cms_user_eula_time'] = time();
//			if(!Ccms::$cDBcms->perform('cms_users',$fields,'update',
//				"cms_user_id = " . (int)$user_id . "")) {
//				Ccms::addMsg('User EULA update, ' . $user_name . " failed");
//				Ccms::$cDBcms->logEvent('ERROR: User EULA update, ' . $user_name . ' failed.');
//				} // if
//			$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
//			header('Location: ' . $url);
//			exit (0);
//			}
//		// else reset eula and logout
//		self::logout_user();
//		$fields = array();
//		$fields['cms_user_eula_time'] = 0;
//		if(!Ccms::$cDBcms->perform('cms_users',$fields,'update',
//			"cms_user_id = " . (int)$user_id . "")) {
//			Ccms::addMsg('User EULA update, ' . $user_name . " failed");
//			Ccms::$cDBcms->logEvent('ERROR: User EULA update, ' . $user_name . ' failed.');
//			} // if
//		$url = (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
//		header('Location: ' . $url);
//		exit (0);
//		} // check_cookie_ok_form()

	public static function log_user_access() {
		if(self::$access_logged) return true;
		self::$access_logged = true;

		$access_cnt = self::get_user_json_data_key('cms_user_access_count');
		if(!$access_cnt) $access_cnt = 0;
		$access_cnt++;
		self::update_user_json_data('cms_user_access_count', $access_cnt);

		$access_datetime = self::get_gm_datetime();
		self::update_user_json_data('cms_user_access_time', $access_datetime);

		return true;
		} // log_user_access()

	public static function log_user2apache($user = false) {
		if(self::is_cli()) return false;
		if((!defined('CMS_C_USER2APACHE')) ||
			(!CMS_C_USER2APACHE) ||
			(self::$user2apache))
			return false;
		self::$user2apache = true;	// only once
		if(empty($user)) $user = self::get_logged_in_username();
		if(empty($user)) return false;	// $user = 'UserNotLoggedIn';
		if((self::$ajax) && (CMS_C_USER2APACHE_AJAX)) $user .= '-Ajax';
		self::log_msg($user . ' access: ' . (empty($_SERVER['REQUEST_URI']) ? 'noURI':$_SERVER['REQUEST_URI']),'info');
		if(function_exists('apache_note')) apache_note('username',$user);
		else {	// (?)
			// @TODO nothing done at this atage
			return false;
			} // else
		return true;
		} // log_user2apache()

	// dynamic methods

} // Ccms_auth
