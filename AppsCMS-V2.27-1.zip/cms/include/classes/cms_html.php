<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_html.php 2067 2021-04-13 06:11:26Z robert0609 $
 */

/**
 * Description of cms_html
 * static html class for AppsCMS
 *
 * @author robert0609
 */

class Ccms_html extends Ccms_general {

	public static $admin_menu_output = false;
	public static $tools_menu_output = false;

	protected static $calendar_sent = false;
	protected static $calendar_ids = false;

	protected static $rgbcp_sent = false;
	protected static $rgbcp_ids = false;

	private static $admin_scroll2anchor_done = array();

	protected static $tla = false;

	function __construct() {
		parent::__construct();
		// self::send_downloads();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function send_downloads() {	// check for downloads and send them
		// need to initiate downloads before any header info is send.
		if ((!isset($_SESSION['downloads'])) || (empty($_SESSION['downloads']))) return 0;
		foreach ($_SESSION['downloads'] as $k => $dn) {	// foreach to skip changes
			unset($_SESSION['downloads'][$k]);
			if (!file_exists($dn)) continue;
			// send a download
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="'.basename($dn).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($dn));
			readfile($dn);

			header('Refresh:0');
			exit(0);
			} // foreach
		} // send_downloads()

	public static function gen_group_selection_list($name, $cms_group_ids = 0, $size_max = '', $params = '') {
		if(!is_array($cms_group_ids)) $cms_group_ids = explode(':', $cms_group_ids);
		$sql_query = "SELECT" .
			" cms_group_id,cms_group_name,cms_group_enabled,cms_group_admin" .
			" FROM cms_groups ORDER BY cms_group_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
//			$options[] = array(
//					'value' => -1,
//					'selected' => false,
//					'text' => ' - Select Group - ',
//					'params' => ' disabled selected hidden',
//					);
			$options[] = array(
					'value' => 0,
					'selected' => (in_array(0,$cms_group_ids) ? true:false),
					'text' => 'All Groups (default)',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				$options[] = array(
					'value' => $row['cms_group_id'],
					'selected' => (in_array((int)$row['cms_group_id'],$cms_group_ids) ? true:false),
					'text' => $row['cms_group_name'] . ' (' . ($row['cms_group_enabled'] == true ? 'enabled':'disabled') . ($row['cms_group_admin'] == 1 ? ', admin':'') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No groups setup)</span>',
					);
		self::$cDBcms->free_result($result);
		if(empty($size_max)) $size_max = 6;
		if(count($options) < $size_max) $size_max = count($options);
		return self::gen_selection_list($name, $options, 'size="' . $size_max . '" ' . $params, false, true,false);
	} // gen_group_selection_list()

	public static function gen_group_user_selection_list($name, $cms_group_user_ids = 0, $size_max = '', $params = '') {
		if(!is_array($cms_group_user_ids)) $cms_group_user_ids = explode(':', $cms_group_user_ids);
		$sql_query = "SELECT" .
			" cms_user_id,cms_user_name,cms_user_enabled" .
			" FROM cms_users ORDER BY cms_user_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
//			$options[] = array(
//					'value' => -1,
//					'selected' => false,
//					'params' => ' disabled selected hidden',
//					'text' => ' - Select User/s - ',
//					);
			$options[] = array(
					'value' => 0,
					'selected' => (in_array(0,$cms_group_user_ids) ? true:false),
					'text' => ' All Users (enabled)',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				$options[] = array(
					'value' => $row['cms_user_id'],
					'selected' => (in_array((int)$row['cms_user_id'],$cms_group_user_ids) ? true:false),
					'text' => $row['cms_user_name'] . ' (' . ($row['cms_user_enabled'] == true ? 'enabled':'disabled') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No users setup)</span>',
					);
		self::$cDBcms->free_result($result);
		if(empty($size_max)) $size_max = 6;
		if(count($options) < $size_max) $size_max = count($options);
		return self::gen_selection_list($name, $options, 'size="' . $size_max . '" ' . $params);
	} // gen_group_user_selection_list()

	public static function manager_selection_list($name, $cms_group_admin_ids = 0, $size_max = '', $params = '') {
		if(!is_array($cms_group_admin_ids)) $cms_group_admin_ids = explode(':', $cms_group_admin_ids);
		$sql_query = "SELECT" .
			" cms_user_id,cms_user_name,cms_user_enabled" .
			" FROM cms_users ORDER BY cms_user_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => -1,
					'selected' => false,
					'text' => ' - Select Group Manager/s - ',
					'params' => ' disabled selected hidden',
					);
			$options[] = array(
					'value' => 0,
					'selected' => false,
					'text' => 'No Group Manager - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				$options[] = array(
					'value' => $row['cms_user_id'],
					'selected' => (in_array((int)$row['cms_user_id'],$cms_group_admin_ids) ? true:false),
					'text' => $row['cms_user_name'] . ' (' . ($row['cms_user_enabled'] == true ? 'enabled':'disabled') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No users setup)</span>',
					);
		self::$cDBcms->free_result($result);
		if(empty($size_max)) $size_max = 6;
		if(count($options) < $size_max) $size_max = count($options);
		return self::gen_selection_list($name, $options, 'size="' . $size_max . '" ' . $params);
	} // manager_selection_list()

	public static function page_start_comment($file, $prn = true) {	// outputs a stx marker for the php file
		return Ccms_trckr::page_start_track_comment($file, $prn);
	} // page_start_comment()

	public static function page_end_comment($file, $prn = true) {	// outputs a etx marker for the php file
		return Ccms_trckr::page_end_track_comment($file, $prn);
	} // page_end_comment()

	public static function get_AppsCMS_title($prefix = false, $suffix = false) {
		// get title and format in an orderly fashion
		return ($prefix ? $prefix . ' - ':'') .
			CMS_PROJECT_NAME . ' (' . CMS_PROJECT_SHORTNAME . ')' . ' - ' . CMS_PROJECT_VERSION .
			($suffix ? ' - ' . $suffix:'');
	}// get_AppsCMS_title()

	public static function prn_AppsCMS_title($prefix = false, $suffix = false) {
		// get title and format in an orderly fashion
		echo self::get_AppsCMS_title($prefix, $suffix);
	}// prn_AppsCMS_title()

	public static function get_body_dir($body = false, $prefix_it = false) {	 // used by the AppsCMS to make google loved URIs
		// $prefix_it is rarely needed as the <base href="http://some.where/"> sets the prefix
		$dir = ($prefix_it ? APPS_WS_DIR:'');	// home dir
		if(isset($body['cms_body_dir'])) {
			$dir .= $body['cms_body_dir'];	// not loved by Google (has no connection to the page name
			} // if
		else if(count($body) > 0) {
			$dir .= self::getDottedKeys2Var($body,'*.cms_body_dir');
			if(empty($dir)) return '';
			} // if
		else {
			// @TODO add error msg, maybe ??
			} // else
		return $dir;	// default to home, no info
		} // get_body_dir()

	public static function get_body_uri($body = false, $prefix_it = false) {	 // used by the AppsCMS to make google loved URIs
		// $prefix_it is rarely needed as the <base href="http://some.where/"> sets the prefix
		$uri = ($prefix_it ? DOCROOT_WS_BASE_DIR:'') . 'index.php';	// home uri
		if(empty($body)) {	// got current body
			if((int)self::$body_id > 0) return $uri . '?body=' . self::$body_id;
			return $uri;	// default to home, no info
			} // if
		if(!is_array($body)) {
			// @TODO check the $body exists
			return $uri .= '?body=' . urlencode ($body);	// no choices
			} // if
		else if(isset($body['cms_body_id'])) {
			$uri .= '?body=' . $body['cms_body_id'];	// not loved by Google (has no connection to the page name
			if(isset($body['cms_body_name'])) $uri .= '&name=' . urlencode ($body['cms_body_name']); // for google
			} // if
		else if((isset($body['cms_body_name'])) &&
			(strlen($body['cms_body_name']) > 4)) {
			$uri .= '?body=' . urlencode ($body['cms_body_name']);	// loved by Google
			} // if
		else if(count($body) > 0) {
			$id = self::getDottedKeys2Var($body,'*.cms_body_id');
			if(!empty($id)) {
				$uri .= '?body=' . $id;	// not loved by Google (has no connection to the page name
				} // if
			} // if
		else {
			// @TODO add error msg, maybe ??
			} // else
		return $uri;	// default to home, no info
		} // get_body_uri()

	private static function get_row_image_uri(&$row,$idx,$path,$uri,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$value = '';
		if(!is_array($row)) $value = $row;
		else if((isset($row[$idx])) && (!empty($row[$idx]))) $value = $row[$idx];
		else return $default;
		$cCMS_C = new Ccms_config();
		return $cCMS_C->show_image($value,$uri,$class,$alt);
		} // get_row_image_uri()

	private static function get_body_tool_elem_uri(&$body_tool,$name,$path,$uri,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$value = '';
		if(!is_array($body_tool)) $value = $body_tool;
		else if((isset($body_tool[$name])) && (!empty($body_tool[$name]))) $value = $body_tool[$name];
		else return $default;

		if((!is_string($value)) || (is_numeric($value))) return $default;

		if((file_exists($path . $value))) return $uri . $value;

//		$parts = parse_url($value);
//		if((!empty($parts['scheme'])) &&
//			(!empty($parts['host']))) {
//			return htmlentities($value);
//			} // if
		self::addMsg('Cannot find "' . $uri . $value . '".','warn');
		return $default;
		} // get_body_tool_elem_uri()

	private static function get_body_legal_h1() {
		$body = self::chk_body_get(false);
		$value = '';
		if(!empty($body['cms_body_H1']))
			$value = $body['cms_body_H1'];
		else if(!empty($body['cms_body_name']))
			$value = $body['cms_body_name'];
		return $value;
		} // get_body_legal_h1()

	private static function chk_link_get($link) {
		if((!is_array($link)) && (is_numeric($link)) && ((int)$link > 0)) {
			$sql = 'SELECT * FROM lm_links WHERE lm_link_id = ' . (int)$link;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($link = self::$cDBcms->fetch_array($result))) {
				return $link;
				} // if
			} // if
		return $link;
		} // chk_link_get()

	public static function get_link_icon_uri($link,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$link = self::chk_link_get($link);
		return self::get_row_image_uri($link, 'lm_link_icon_url', $path, $uri,$default,$class,$alt);
		} // get_link_icon_uri()

	public static function get_link_image_uri($link,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$link = self::chk_link_get($link);
		return self::get_row_image_uri($link, 'lm_link_image_url', $path, $uri,$default,$class,$alt);
		} // get_link_image_uri()

	private static function chk_section_get($section) {
		if((!is_array($section)) && (is_numeric($section)) && ((int)$section > 0)) {
			$sql = 'SELECT * FROM lm_sections WHERE lm_section_id = ' . (int)$section;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($section = self::$cDBcms->fetch_array($result))) {
				return $section;
				} // if
			} // if
		return $section;
		} // chk_section_get()

	public static function get_section_icon_uri($section,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$section = self::chk_section_get($section);
		return self::get_row_image_uri($section, 'lm_section_icon_url', $path, $uri,$default,$class,$alt);
		} // get_section_icon_uri()

	public static function get_section_image_uri($section,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$section = self::chk_section_get($section);
		return self::get_row_image_uri($section, 'lm_section_image_url', $path, $uri,$default,$class,$alt);
		} // get_section_image_uri()

	private static function chk_body_get($body) {
		if($body === false) $body = self::$body_id;
		if(empty($body)) $body = self::get_or_post ('cms_body_id');	// body edit
		if(empty($body)) $body = self::get_or_post ('cms_body_clone_from_id');	// body clone

		if((!is_array($body)) && (is_numeric($body)) && ((int)$body > 0)) {
			$sql = 'SELECT * FROM cms_bodies WHERE cms_body_id = ' . (int)$body;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($body = self::$cDBcms->fetch_array($result))) {
				return $body;
				} // if
			} // if
		// check for assoc arry
		$k = @key($body);
		if(!empty($k)) $body = $body[$k];
		if(!empty($body['cms_body_id'])) {
			$sql = 'SELECT * FROM cms_bodies WHERE cms_body_id = ' . (int)$body['cms_body_id'];
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($body = self::$cDBcms->fetch_array($result))) {
				return $body;
				} // if
			} // if
		return $body;
		} // chk_body_get()

	public static function get_body_icon_uri($body = false,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$body = self::chk_body_get($body);
		return self::get_row_image_uri($body, 'cms_body_icon_url', $path, $uri,$default,$class,$alt);
		} // get_body_icon_uri()

	public static function get_body_image_uri($body = false,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$body = self::chk_body_get($body);
		return self::get_row_image_uri($body, 'cms_body_image_url', $path, $uri,$default,$class,$alt);
		} // get_body_image_uri()

	public static function get_body_logo_uri($class = 'logo',$body_id = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$text = self::get_body_icon_uri($body_id,'',$class,$alt);
		if(empty($text))
			$text = self::get_body_image_uri($body_id,'',$class,$alt);
		return $text;
		} // get_body_logo_uri()

	public static function get_body_terms_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = APPS_FS_DIR;
		$uri = APPS_WS_DIR;
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_tool_elem_uri($body, 'cms_body_terms_url', $path, $uri,$default);
		} // get_body_terms_uri()

	public static function get_body_terms_upfirst($body) {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		return $body['cms_body_terms_upfirst'];
		} // get_body_terms_upfirst()

	public static function is_body_terms2show($body) {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(!$body['cms_body_terms_upfirst']) return false;
		if(!Ccms_auth::is_eula_agreement_required('Body-agree-' . $body['cms_body_name'])) return false;
		return true;
		} // is_body_terms2show()

	public static function update_body_terms2show($body,$new) {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(!Ccms_auth::update_user_json_data('Body-agree-' . $body['cms_body_name'],$new)) return false;
		return true;
		} // update_body_terms2show()

	public static function get_body_readme_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = APPS_FS_DIR;
		$uri = APPS_WS_DIR;
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_tool_elem_uri($body, 'cms_body_readme_url', $path, $uri,$default);
		} // get_body_readme_uri()

	public static function get_body_release_notes_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = APPS_FS_DIR;
		$uri = APPS_WS_DIR;
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_tool_elem_uri($body, 'cms_body_release_notes_url', $path, $uri,$default);
		} // get_body_release_notes_uri()

	public static function get_body_acknowledgment_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = APPS_FS_DIR;
		$uri = APPS_WS_DIR;
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_tool_elem_uri($body, 'cms_body_acknowledgment_url', $path, $uri,$default);
		} // get_body_acknowledgment_uri()

	public static function get_body_licence_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = APPS_FS_DIR;
		$uri = APPS_WS_DIR;
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_tool_elem_uri($body, 'cms_body_licence_url', $path, $uri,$default);
		} // get_body_licence_uri()

	private static function chk_tool_get($tool) {
		if($tool === false) $tool = self::$tool_id;
		if(empty($tool)) $tool = self::get_or_post ('cms_tool_id');

		if((!is_array($tool)) && (is_numeric($tool)) && ((int)$tool > 0)) {
			$sql = 'SELECT * FROM cms_tools WHERE cms_tool_id = ' . (int)$tool;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($tool = self::$cDBcms->fetch_array($result))) {
				return $tool;
				} // if
			} // if
		// check for assoc arry
		if((empty($tool)) || (!is_array($tool))) return false;
		$k = key($tool);
		if(!empty($tool[$k]['cms_tool_id'])) {
			$sql = 'SELECT * FROM cms_tools WHERE cms_tool_id = ' . (int)$tool[$k]['cms_tool_id'];
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($tool = self::$cDBcms->fetch_array($result))) {
				return $tool;
				} // if
			} // if
		return $tool;
		} // chk_tool_get()

	private static function get_tool_elem_h1() {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get(false);
		$value = $tool['cms_tool_name'];
		return $value;
		} // get_tool_elem_h1()

	public static function get_tool_icon_uri($tool,$default = '',$class = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_row_image_uri($tool, 'cms_tool_icon_url', $path, $uri,$default,$class);
		} // get_tool_icon_uri()

	public static function get_tool_image_uri($tool,$default = '',$class = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_row_image_uri($tool, 'cms_tool_image_url', $path, $uri,$default,$class);
		} // get_tool_image_uri()

	public static function get_tool_readme_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_body_tool_elem_uri($tool, 'cms_tool_readme_url', $path, $uri,$default);
		} // get_tool_readme_uri()

	public static function get_tool_release_notes_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_body_tool_elem_uri($tool, 'cms_tool_release_notes_url', $path, $uri,$default);
		} // get_tool_release_notes_uri()

	public static function get_tool_terms_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_body_tool_elem_uri($tool, 'cms_tool_terms_url', $path, $uri,$default);
		} // get_tool_terms_uri()

	public static function get_tool_terms_upfirst($tool) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($tool);
		return $tool['cms_tool_terms_upfirst'];
		} // get_tool_terms_upfirst()

	public static function is_tool_terms2show($tool) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($tool);
		if(!$tool['cms_tool_terms_upfirst']) return false;
		if(!Ccms_auth::is_eula_agreement_required('Tool-agree-' . $tool['cms_tool_name'])) return false;
		return true;
		} // is_tool_terms2show()

	public static function update_tool_terms2show($tool,$new) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($tool);
		if(!Ccms_auth::update_user_json_data('Tool-agree-' . $tool['cms_tool_name'],$new)) return false;
		return true;
		} // update_tool_terms2show()

	public static function get_tool_acknowledgment_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_body_tool_elem_uri($tool, 'cms_tool_acknowledgment_url', $path, $uri,$default);
		} // get_tool_acknowledgment_uri()

	public static function get_tool_licence_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_body_tool_elem_uri($tool, 'cms_tool_licence_url', $path, $uri,$default);
		} // get_tool_licence_uri()

	public static function get_disclaimer_text() {
		$text = array();
		if(strlen(CMS_C_CUSTOM_FOOTER_LINK_NAME) > LMC_MIN_NAME_LEN) {
			$text[] = '				<a href="' . ((strlen(CMS_C_CUSTOM_FOOTER_LINK) > LMC_MIN_NAME_LEN) ? CMS_C_CUSTOM_FOOTER_LINK:'index.php?cms_action=disclaimer') . '"';
			$text[] = '					' . ((strlen(CMS_C_CUSTOM_FOOTER_LINK_TITLE) > LMC_MIN_NAME_LEN) ? ' title="' . CMS_C_CUSTOM_FOOTER_LINK_TITLE . '"':'');
			$text[] = '					onclick="Ccms_cursor.setWait();"';
			$text[] = '					>';
			$text[] = '					<strong>' . CMS_C_CUSTOM_FOOTER_LINK_NAME . '</strong>';
			$text[] = '				</a>';
			} // if
		else $text[] = '&nbsp;';
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_disclaimer_text()

	public static function get_release_notes_text() {
		$rn = ETC_WS_EXT_INCLUDES_DIR . 'ReleaseNotes.md';
		if(file_exists($rn)) return $rn;
		$rn = ETC_WS_EXT_INCLUDES_DIR . 'ReleaseNotes.txt';
		if(file_exists($rn)) return $rn;
		return '';
		} // get_release_notes_text()

	public static function get_readme_text() {
		$rd = ETC_WS_EXT_INCLUDES_DIR . 'README.md';
		if(file_exists($rd)) return $rd;
		$rd = ETC_WS_EXT_INCLUDES_DIR . 'README.txt';
		if(file_exists($rd)) return $rd;
		return '';
		} // get_readme_text()

	protected static function get_chk_legal_link_text($link) {
		if(strlen($link) < LMC_MIN_NAME_LEN) return false;
		$uri = $link;	// to start
		if(!file_exists($uri)) $uri = ETC_WS_EXT_INCLUDES_DIR . $link;
		else if(!file_exists($uri)) {
			self::addMsg('Failed to read "' . $link . '".');
			return false;
			} // if
		return $uri;
		} // get_chk_legal_link_text()

	public static function get_cookie_text() {
		return self::get_chk_legal_link_text(CMS_C_COOKIE_POLICY_LINK);
		} // get_cookie_text()

	public static function get_terms_text() {
		return self::get_chk_legal_link_text(CMS_C_TERMS_LINK);
		} // get_terms_text()

	public static function get_licence_text() {
		return self::get_chk_legal_link_text(CMS_C_LICENCE_LINK);
		} // get_licence_text()

	public static function get_agree_dialog(&$tla) {
		$text = '';

		if(!Ccms_auth::is_eula_enabled('terms')) return $text;
		if(empty($tla['terms'])) return $text;
		if(!$tla['terms_upfirst']) return $text;
		if(!$tla['terms_show']) return $text;

		$show = $tla['terms_show'];
		$name = 'terms';
		$terms = $tla['terms'];

		$text .= <<< EOTSTY
		<style>
			/* override modal background */
			#id_{$name}_id_dlg__modal {
				background-color: lightblue;	/* should be covered !! */
				border-radius: 7px;
				border: 2px solid black;
				}

			/* give h1 a boost */
			#id_{$name}_id_dlg__body h1 {
				text-align: center;
				color: purple;
				}

		</style>
EOTSTY;

		$form_id = '';
		$class = '';	// usually 'page_body'
		ob_start();
		include(CMS_FS_OPS_DIR . 'cms_eula_form.php');
		$body_text = ob_get_clean();

		// this could be done by calling panels separately
		$id = "id_{$name}_dlg_";
		$class_name = '';
		$h1 = '';
		$header = '';
		$footer = '';

		$cModal = new Ccms_modal();
		$text .= $cModal->get_modal($id, $body_text, $class_name, $h1, $header, $footer, $name,true);
		$m_name = $cModal->get_name();
		$m_show = ($show ? 'true':'false');
		$text .= <<< EOTJS

		<script type="text/javascript">
			function show_{$name}_modal() {
			{$m_name}_open_modal();
			} // show_{$name}_modal()

		var show = {$m_show};
		if(show) {
			show_{$name}_modal();	// open dialog
			} // if

		</script>

EOTJS;
		return $text;

		} // get_agree_dialog()

	public static function &get_releasenotes_terms_licence_ack_uris() {
		if(self::$tla) return self::$tla;	// do once
		$tla = array(
			'body_id' => self::$body_id,
			'tool_id' => self::$tool_id,
			'h1' => false,
			'readme' => false,
			'release_notes' => false,
			'eula' => (CMS_C_EULA_ENABLE ? CMS_C_EULA_LINK:false),
			'eula_upfirst' => CMS_C_EULA_ENABLE,	// for cms to manage
			'eula_show' => Ccms_auth::is_eula_agreement_required(),	// for cms to manage
			'terms' => false,
			'terms_upfirst' => false,	// for apps to manage
			'terms_show' => false,	// for apps to manage
			'licence' => false,
			'acknowledgement' => false,
			'cookies' => self::get_cookie_text(),
			'html' => false,
			'version' => false,
			);
		if($tla['body_id']) {
			$tla['h1'] = self::get_body_legal_h1();
			$tla['readme'] = self::get_body_readme_uri($tla['body_id'],false);
			$tla['release_notes'] = self::get_body_release_notes_uri($tla['body_id'],false);
			$tla['terms'] = self::get_body_terms_uri($tla['body_id'],false);
			$tla['terms_upfirst'] = self::get_body_terms_upfirst($tla['body_id']);
			$tla['terms_show'] = self::is_body_terms2show($tla['body_id']);	// for apps to manage
			$tla['licence'] = self::get_body_licence_uri($tla['body_id'],false);
			$tla['acknowledgement'] = self::get_body_acknowledgment_uri($tla['body_id'],false);
			$tla['version'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', "cms_body_id = " . $tla['body_id']);
			} // if
		else if($tla['tool_id']) {
			$tla['h1'] = self::get_tool_elem_h1();
			$tla['readme'] = self::get_tool_readme_uri($tla['tool_id'],false);
			$tla['release_notes'] = self::get_tool_release_notes_uri($tla['tool_id'],false);
			$tla['terms'] = self::get_tool_terms_uri($tla['tool_id'],false);
			$tla['terms_upfirst'] = self::get_tool_terms_upfirst($tla['body_id']);
			$tla['terms_show'] = self::is_tool_terms2show($tla['body_id']);	// for apps to manage
			$tla['licence'] = self::get_tool_licence_uri($tla['tool_id'],false);
			$tla['acknowledgement'] = self::get_tool_acknowledgment_uri($tla['tool_id'],false);
			$tla['version'] = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', "cms_tool_id = " . $tla['tool_id']);
			} // else if
		else {	// get site docs
			$tla['readme'] = self::get_readme_text();
			$tla['release_notes'] = self::get_release_notes_text();
			$tla['terms'] = self::get_terms_text();
			$tla['licence'] = self::get_licence_text();
			$tla['version'] = CMS_C_APPS_MAJOR_VERSION;
			} // else
		$bt_uri ='';
		if($tla['body_id']) $bt_uri = '&body=' . $tla['body_id'];
		else if($tla['tool_id']) $bt_uri = '&tool_id=' . $tla['tool_id'];
		else {
			$bt_uri = '';
			} // else
		$text = array();
		if(!empty($tla['cookies'])) $text[] = '<a href="index.php?cms_action=cookies">Cookies</a>';
		if(!empty($tla['terms'])) $text[] = '<a href="index.php?cms_action=terms' . $bt_uri . '">Terms</a>';
		if(!empty($tla['licence'])) $text[] = '<a href="index.php?cms_action=licence' . $bt_uri . '">Licence</a>';
		if(!empty($tla['acknowledgement'])) $text[] = '<a href="index.php?cms_action=acknowledgement' . $bt_uri . '">Acknowledgement</a>';
		if(Ccms_auth::is_group_manager()) {
			if(!empty($tla['release_notes'])) $text[] = '<a href="index.php?cms_action=release_notes' . $bt_uri . '">Release Notes</a>';
			if(!empty($tla['readme'])) $text[] = '<a href="index.php?cms_action=readme' . $bt_uri . '">Read Me</a>';
			} // if
		if(!empty($tla['version'])) $text[] = ' Version: <i>' . $tla['version'] . '</i>';
		if(!empty($text)) $tla['html'] = PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		self::$tla = $tla;
		return self::$tla;
		} // get_releasenotes_terms_licence_ack_uris()

	public static function show_page_legals() {
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		echo $tla['html'];
		echo Ccms::get_agree_dialog($tla);
		} // show_page_legals()

	public static function get_about_text_link() {
		$text = array();
		if(CMS_C_SHOW_CMS_ABOUT_LINK) {
			if((INI_ALLOW_ABOUT_MANUAL_LINKS_BOOL) || (Ccms_auth::is_user_logged_in())) {
				$text[] = '<a href="index.php?cms_action=cms_about" title="About ' . self::$version_str . '"';
				$text[] = '	onclick="Ccms_cursor.setWait();">';
				$text[] = '	' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION;
				$text[] = '</a>';
				} // if
			else $text[] = (self::is_debug() ? ' (Debug)':'&nbsp;');
			} // if
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_about_text_link()

	public static function get_show_counter_text() {
		$text = array();

		if(CMS_C_SHOW_VISITOR_COUNTER) {
			$text[] = "Visitor # " . number_format(self::$visitor_cnt) . ".";
			} // if

		// show visited to site count
		if(CMS_C_SHOW_COOKIE_COUNTER) {
			$text[] = '	<script type="text/javascript">';
			$text[] = '		Ccms_cookie.showClientVisitsCntrCookie("visits","Visited","times.",' . (int)CMS_C_SHOW_COOKIE_COUNTER  . ');';
			$text[] = '	</script>';
			} // if
		else $text[] = '&nbsp;'; // no cookie access
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_show_counter_text()

	public static function get_copyright_text() {
		$text = array();
		if(strlen(CMS_C_META_COPYRIGHT) > LMC_MIN_NAME_LEN) {
			$text[] = CMS_C_META_COPYRIGHT . ' &copy; ' . date('Y') . ' ';
			if((defined('CMS_C_WEB_SITE_ADDRESS')) &&
				(strlen(CMS_C_WEB_SITE_ADDRESS) > LMC_MIN_NAME_LEN)) {
				$text[] = '	<a href="' . CMS_C_WEB_SITE_ADDRESS . '" target="_blank">' . trim(CMS_C_CO_NAME) . '</a>';
				} // if
			else $text[] = trim(CMS_C_CO_NAME);
			} // if
		else $text[] = '&nbsp;'; // no cookie access
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_copyright_text()

	private static function get_icon_file_elem($type,$id_name,$title,$class,$nbar) {
		if((empty($type)) || (empty($id_name))) return '';
		if((empty($title)) && (is_string($id_name))) $title = $id_name;
//		if((!$nbar) && (CMS_C_MENU_ICONS_ALLOW === false))
//			return $title;
//		if(($nbar) && (INI_NAV_BAR_SHOW_ICONS_BOOL === false))
//			return $title;

		$icon = false;
		if(((!$nbar) && (CMS_C_MENU_ICONS_ALLOW)) ||
			(($nbar) && (INI_NAV_BAR_SHOW_ICONS_BOOL))) {
			switch(strtolower($type)) {	// try the basic types first
			case 'admin':
			case 'manage':
			case 'config':
			case 'settings':
				$icon = ((strlen(CMS_C_ADMIN_ICON) > 4) ? CMS_C_ADMIN_ICON : 'admin.png');
				break;
			case 'tools':
				$icon = ((strlen(CMS_C_TOOLS_ICON) > 4) ? CMS_C_TOOLS_ICON : 'tools.png');
				break;
			case 'log_in':
			case 'cms_login':
				$icon = ((strlen(CMS_C_LOGIN_ICON) > 4) ? CMS_C_LOGIN_ICON : 'login.png');
				break;
			case 'log_out':
			case 'logout':
				$icon = ((strlen(CMS_C_LOGOUT_ICON) > 4) ? CMS_C_LOGOUT_ICON : 'logout.png');
				break;
			case 'change_password':
			case 'chg_passwd':
				$icon = ((strlen(CMS_C_CHG_PASSWD_ICON) > 4) ? CMS_C_CHG_PASSWD_ICON : 'chg_passwd.png');
				break;
			default:
				break;
				} // switcn
			} // if
		if(!$icon) {
			switch($type) {
			case 'body':
				// now try page / app icons, $type is either a body id or a body name.
				$icon = self::$cDBcms->get_data_in_table('cms_bodies', ($nbar ? 'cms_body_icon_url':'cms_body_image_url'),
						"cms_body_id = " . (int)$id_name . " OR cms_body_name = '" . self::$cDBcms->input($id_name) . "'");
				break;
			case 'link':
				$icon = self::$cDBcms->get_data_in_table('lm_links', ($nbar ? 'lm_link_icon_url':'lm_link_image_url'),
						"lm_link_id = " . (int)$id_name . " OR lm_link_name = '" . self::$cDBcms->input($id_name) . "'");
				break;
			case 'tool':
				$icon = self::$cDBcms->get_data_in_table('cms_tools', ($nbar ? 'cms_tool_icon_url':'cms_tool_image_url'),
						"cms_tool_id = " . (int)$id_name . " OR cms_tool_name = '" . self::$cDBcms->input($id_name) . "'");
				break;
			default:
				break;
				} // switch
			} // if
		if(empty($icon))  return $title;

		$path = '';	// empty
		if(file_exists($icon)) $path = $icon;
		else if(file_exists(ETC_FS_ICONS_DIR . $icon)) $path = ETC_WS_ICONS_DIR . $icon;
		else if(file_exists(ETC_FS_IMAGES_DIR . $icon)) $path = ETC_WS_IMAGES_DIR . $icon;
		else if(file_exists(CMS_FS_ICONS_DIR . $icon)) $path = CMS_WS_ICONS_DIR . $icon;
		// @TODO check $icon as a URL
		if(empty($path)) return $title;

		$text = '<img alt="icon" class="' . $class . '" src="' . $path . '">';
		if((!self::$tiny_flg) && (!self::$tablet_flg)) {	// small device
			$text .= $title;
			} // if
		return $text;
		} // get_icon_file_elem()

	public static function get_navbar_icon_text($id_name, $title = false, $class = "cms_nav_bar") {
		return self::get_icon_file_elem('nbar', $id_name, $title, $class, true);
		} // get_navbar_icon_text()

	public static function get_menu_icon_text($id_name, $title = false, $class = "menu_link_icon") {
		return self::get_icon_file_elem('body', $id_name, $title, $class, false);
		} // get_menu_icon_text()

	public static function get_tool_icon_text($id_name, $title = false, $class = "menu_link_icon") {
		return self::get_icon_file_elem('tool', $id_name, $title, $class, false);
		} // get_tool_icon_text()

	public static function get_link_icon_text($id_name, $title = false, $class = "menu_link_icon") {
		return self::get_icon_file_elem('link', $id_name, $title, $class, false);
		} // get_link_icon_text()

	public static function get_body_image_text($img, $alt = '', $class = '') {
		if(empty($img)) return $alt;
		$path = '';	// empty
		if(file_exists($img)) $path = $img;
		else if(file_exists(ETC_FS_IMAGES_DIR . $img)) $path = ETC_FS_IMAGES_DIR . $img;
		else if(file_exists(ETC_FS_IMAGES_DIR . $img)) $path = ETC_WS_IMAGES_DIR . $img;
		else if(file_exists(CMS_FS_IMAGES_DIR . $img)) $path = CMS_WS_IMAGES_DIR . $img;
		if(empty($path)) return $alt;

		$text = '<img alt="body image"' .
				(!empty($alt) ? ' alt="' . $alt . '"':'') .
				(!empty($class) ? ' class="' . $class . '"':'') .
				' src="' . $path . '">';
		return $text;
		} // get_body_image_text()

	public static function get_body_icon_text($img, $alt = '', $class = '') {
		if(empty($img)) return $alt;
		$path = '';	// empty
		if(file_exists($img)) $path = $img;
		else if(file_exists(ETC_FS_ICONS_DIR . $img)) $path = ETC_FS_ICONS_DIR . $img;
		else if(file_exists(ETC_FS_ICONS_DIR . $img)) $path = ETC_WS_ICONS_DIR . $img;
		else if(file_exists(CMS_FS_ICONS_DIR . $img)) $path = CMS_WS_ICONS_DIR . $img;
		if(empty($path)) return $alt;

		$text = '<img alt="body"' .
				(!empty($alt) ? ' alt="' . $alt . '"':'') .
				(!empty($class) ? ' class="' . $class . '"':'') .
				' src="' . $path . '">';
		return $text;
		} // get_body_icon_text()

	public static function get_ws_links($sel0_option, $show_disabled = true) {
		$file_list = array();
		$file_list[] = (!empty($sel0_option) ? $sel0_option:'-- Select --');
		$file_list[] = 'index.php';
		$file_list[] = 'index.php?cms_action=home';
		if(self::is_links_manager_inuse())
			$file_list[] = 'index.php?cms_action=lm_show_links';

//		$paths = array(
//			PAGE_BODIES_WS_DIR,
//			);
//		foreach($paths as $path) {
//			if($dh = opendir(DOCROOT_FS_BASE_DIR . $path)) {
//				while (($file = readdir($dh)) !== false) {
//					if(preg_match('/\.php|\.htm|\.html|\.txt/',$file)) $file_list[] = $path . $file;
//					} // while
//				closedir($dh);
//				} // if
//			} // foreach

		$sql_body_query = "SELECT  cms_body_id, cms_body_name, cms_body_file" .
			", cms_body_title,cms_body_group_ids,cms_body_default,cms_body_enabled" .
			" FROM  cms_bodies" .
			" ORDER BY  cms_body_default DESC, cms_body_order ASC,cms_body_id ASC;";
		if($result_body = self::$cDBcms->query($sql_body_query)) {
			while($body = self::$cDBcms->fetch_array($result_body)) {
				// if(!Ccms_auth::check_user_group_ids($body['cms_body_group_ids'])) continue;
				$filename = PAGE_BODIES_FS_DIR . $body['cms_body_file'];
				if((!file_exists($filename)) || (!is_readable($filename))) {
					continue;
					} // if
				$file_list[] = self::get_body_uri($body) . ((($show_disabled) && ((int)$body['cms_body_enabled'] <= 0)) ? ' (disabled)':'');
				} // while
			} // if

		// add the plugin URIs
		$plugins_enabled = self::unserialize_string2arry(CMS_C_ENABLED_PLUGINS,':');
		foreach($plugins_enabled as $plugin_ary) {
			if(isset($plugin_ary[0])) $plugin = $plugin_ary[0];	// grid style
			else $plugin = $plugin_ary;	// old/manual style
			$class = 'C' . $plugin . '_plugin';
			if((Ccms_autoloader::find_plugin($class)) && ($class::is_enabled())) {
				$text = $class::get_engage_uri();
				if(!empty($text)) $file_list[] = $text;
				} // if
			} // foreach

		// add the other URIs
		$file_list[] = 'index.php?cms_action=cms_about';
		$file_list[] = 'index.php?cms_action=cms_manual';
		$file_list[] = 'index.php?cms_action=disclaimer';
		$file_list[] = 'login.php';
		$file_list[] = 'logout.php';
		return $file_list;
	} // get_ws_links()

	public static function get_simple_select($name,$value,$options,$params = false, $id = false,$title = false) {
		// intended to replace checkboxes in form control
		// (i.e. when checkbox is unchecked it returns nothing)
		// with good options, label should be unnecessary
		$text = '';
		$text .= '<select name="' . $name . '"' . ($params ? ' ' . $params:'') . ($id ? ' id="' . $id . '"':'') . ($title ? ' title="' . $title . '"':'') . '>';
		foreach($options as $v) {
			$text .= '<option value="' . rawurlencode($v) . '">' . htmlentities($v) . '</option>';
			} // foreach
		$text .= '</select>' . PHP_EOL;
		return $text;
		} // get_simple_select()

	public static function get_keyed_select($name,$value,$options,$params = false, $id = false,$title = false) {
		// intended to replace checkboxes in form control
		// (i.e. when checkbox is unchecked it returns nothing)
		// with good options, label should be unnecessary
		// also this is good on/off select using 0 and 1 as the keys
		$text = '';
		$text .= '<select name="' . $name . '"' . ($params ? ' ' . $params:'') . ($id ? ' id="' . $id . '"':'') . ($title ? ' title="' . $title . '"':'') . '>';
		foreach($options as $k => $v) {
			$text .= '<option value="' . $k . '"' . (($k == $value) ? ' SELECTED':'') . '>' . htmlentities($v) . '</option>';
			} // foreach
		$text .= '</select>' . PHP_EOL;
		return $text;
		} // get_keyed_select()

	public static function make_ws_link_select_options() {
		$file_list = self::get_ws_links('-- Select Link URI to Copy --');
		return self::add_svalues_options($file_list,'-1');
	} // make_ws_link_select_options()

	public static function add_svalues_options($svalues,$value) {
		$text = '';
		foreach($svalues as $sv) {
			if((!empty($sv)) || (is_numeric($sv))) {
				$svt = preg_replace('/\n|\r/i', ' ',  strip_tags($sv));
				$text .= PHP_EOL . '<option value="' . $svt . '"' . (($value == $sv) ? ' SELECTED':'') . '>' . $svt . '</option>';
				} // if
			} // foreach
		return $text;
	} // add_svalues_options()

	protected static function gen_selection_list($name, $options, $params = '', $exc = false, $bare = false, $onchange_submit = false) {
		if((empty($options)) || (!is_array($options))) return '';
		if($exc) {
			if(!is_array($exc)) $exc = preg_split('/[\s,\;\;]+/',$exc);
			} // if
		else $exc = array();
		$id = '';
		$text = PHP_EOL;
		if(!$bare) {
			$text .= '<div class="cms_select_filtered">' . PHP_EOL;
			if(!empty($name)) {
				$id = 'id_' . $name;
				$text .= Ccms_edit::get_select_option_filter($id, '',-1,Ccms_edit::count_sel_opts($options)) . PHP_EOL;
				} // if
			} // if
		$text .= '<select' .
			(!empty($id) ? ' id="' . $id . '"':'') .
			(!empty($name) ? ' name="' . $name . '"':'') .
			(!$bare ? ' onclick="javascript:cms_filter_select_click(this);"':'') .
			($onchange_submit ? ' onchange="this.form.submit();"':'');
		if(!empty($params)) $text .= ' ' . $params;
		if((preg_match('/multiple/i',$params)) && (!preg_match('/title="/i', $params))) {
			$text .= ' title="Hold Ctl key down to select multiple options."';
			} // if
		$text .= '>' . PHP_EOL;
		for($i = 0, $n = count($options); $i < $n; $i++) {
			$option = &$options[$i];
			if((in_array($option['value'],$exc)) || (in_array($option['text'],$exc))) continue;
			$text .= PHP_EOL .
				'<option value="' . htmlentities($option['value']) . '"' .
				($option['selected'] ? ' SELECTED':'');
			if(!empty($option['params'])) $text .= ' ' . $option['params'];
			$text .= '>';
			$text .= $option['text'];
			$text .= '</option>' . PHP_EOL;
			} // for
		$text .= PHP_EOL . '</select>' . PHP_EOL;
		if(!$bare) $text .= '</div>' . PHP_EOL;
		return $text;
	} // gen_selection_list()

	public static function gen_user_selection_list($name, $cms_user_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT cms_user_id,cms_user_name,cms_user_enabled,cms_user_admin" .
			" FROM cms_users ORDER BY cms_user_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($cms_user_id ? false:true),
					'params' => ' disabled selected hidden',
					'text' => ' - Select User - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['cms_user_id'],$exc_ids)) continue;
				$options[] = array(
					'value' => $row['cms_user_id'],
					'selected' => ((int)$row['cms_user_id'] == (int)$cms_user_id ? true:false),
					'text' => $row['cms_user_name'] . ' (' . ($row['cms_user_enabled'] == true ? 'enabled':'disabled') . ($row['cms_user_admin'] == 1 ? ', admin':'') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No users setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_user_selection_list()

	public static function gen_link_selection_list($name, $lm_link_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT lm_link_id,lm_link_name,lm_link_title,lm_link_description" .
			",lm_link_section_id,lm_section_name,lm_link_new_page, lm_link_image_url, lm_link_icon_url" .
			",lm_section_order,lm_section_title,lm_link_order,lm_link_enabled, lm_link_ssl, lm_link_add_name2url,lm_section_enabled,lm_section_id" .
			" FROM  lm_links as l LEFT JOIN lm_sections as s ON l.lm_link_section_id = s.lm_section_id" .
			" WHERE lm_link_id > 0" .
			" AND (l.lm_link_section_id = s.lm_section_id OR l.lm_link_section_id = 0)" .
			" ORDER BY lm_section_name,lm_link_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($lm_link_id ? false:true),
					'text' => ' - Select Link - ',
					'params' => ' disabled selected hidden',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['lm_link_id'],$exc_ids)) continue;
				$text = (empty($row['lm_section_name']) ? '(no section)':$row['lm_section_name']) .
						' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')';
				$text .= " -&gt; ";
				$text .= $row['lm_link_name'] . ' (' . ($row['lm_link_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['lm_link_id'] == (int)$lm_link_id ? ' **':'');
				$options[] = array(
					'value' => $row['lm_link_id'],
					'selected' => ((int)$row['lm_link_id'] == (int)$lm_link_id ? true:false),
					'text' => $text,
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No links setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_link_selection_list()

	public static function gen_section_selection_options($lm_section_id = 0, $exc_ids = false, $bare = false, $onchange_submit = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT lm_section_id,lm_section_name,lm_section_enabled" .
			" FROM lm_sections ORDER BY lm_section_name,lm_section_order";
		$options = array();
		$cnt = 0;
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			if(!$bare) {
				$options[] = array(
						'value' => 0,
						'selected' => ($lm_section_id ? false:true),
						'params' => ($onchange_submit ? ' disabled selected hidden':''),
						'text' => ' - Select Section - ',
						);
				} // if
			$options[] = array(
					'value' => 0,
					'selected' => false,
					'text' => '(Base parent)',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['lm_section_id'],$exc_ids))
					continue;
				$seld = false;
				if(((int)$lm_section_id > 0) &&
					((int)$lm_section_id == (int)$row['lm_section_id']))
					$seld = true;
				$options[] = array(
					'value' => $row['lm_section_id'],
					'selected' => $seld,
					'text' => (self::is_debug() ? 'ID: ' . $row['lm_section_id'] . ', ':'') . $row['lm_section_name'] . ' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')' . ($seld ? ' **':''),
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No sections setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return $options;
	} // gen_section_selection_options()

	public static function gen_link_section_js_selection_list($name, $lm_section_id, $params = '', $exc_ids = false, $bare = false, $onchange_submit = false) {
		$sql_query = "SELECT lm_section_id,lm_section_name,lm_section_enabled,lm_section_parent_id" .
			" FROM lm_sections" .
			" WHERE lm_section_id = " . (empty($lm_section_id) ? 0:(int)$lm_section_id);
		$options = array();
		$cnt = 0;
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
			($row = self::$cDBcms->fetch_array($result))) {
			$options[] = array(
				'value' => (empty($row['lm_section_id']) ? 0:$row['lm_section_id']),
				'selected' => false,
				'text' => (self::is_debug() ? 'ID: ' . $row['lm_section_id'] . ', ':'') . $row['lm_section_name'] . ' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['lm_section_id'] == (int)$lm_section_id ? ' **':''),
				);
			} // if
		else {
			$options[] = array(
				'value' => 0,
				'selected' => false,
				'text' => '(Orphaned Link)',
				);
			} // else
		return self::gen_selection_list($name, $options, $params, false, $bare,$onchange_submit);
	} // gen_link_section_js_selection_list()

	public static function gen_parent_section_js_selection_list($name, $lm_section_id, $params = '', $exc_ids = false, $bare = false, $onchange_submit = false) {
		$sql_query = "SELECT lm_section_id,lm_section_name,lm_section_enabled,lm_section_parent_id" .
			" FROM lm_sections" .
			" WHERE lm_section_id = " . (int)$lm_section_id;
		$options = array();
		$cnt = 0;
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
			($row = self::$cDBcms->fetch_array($result))) {
//			if(!empty($exc_ids)) {
//				if(in_array($row['lm_section_id'],$exe_ids)) continue;
//				} // if
			$stat = '';
			if((int)$row['lm_section_parent_id'] == 0) {
				$stat .= ' (Base parent)';
				} // if
			else {
				$section_parent_name = Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_name',"lm_section_id = " . (int)$row['lm_section_parent_id'] . "");
				$stat .= (self::is_debug() ? 'ID: ' . $row['lm_section_parent_id'] . ', ':'') . (empty($section_parent_name) ? '(Orphan)':$section_parent_name);
				$stat .= ' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')';
				} // else
			$stat .= ((int)$row['lm_section_id'] == (int)$lm_section_id ? ' **':'');
			$options[] = array(
				'value' => $row['lm_section_id'],
				'selected' => false,
				'text' => $stat,
				);
			} // if
		else {
			$options[] = array(
				'value' => '-1',
				'selected' => false,
				'text' => '(Base parent)',
				);
			} // else
		return self::gen_selection_list($name, $options, $params, false, $bare,$onchange_submit);
	} // gen_parent_section_js_selection_list()

	public static function gen_section_selection_list($name, $lm_section_id = 0, $params = '', $exc_ids = false, $bare = false, $onchange_submit = true) {
		$options = self::gen_section_selection_options($lm_section_id,$exc_ids,$bare,$onchange_submit);
		return self::gen_selection_list($name, $options, $params, false, $bare,$onchange_submit);
	} // gen_section_selection_list()

	public static function gen_body_selection_list($name, $cms_body_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT cms_body_id,cms_body_installed,cms_body_name,cms_body_enabled,cms_body_group_ids" .
			" FROM cms_bodies ORDER BY cms_body_order";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($cms_body_id ? false:true),
					'text' => ' - Select Body - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['cms_body_id'],$exc_ids)) continue;
				if(!Ccms_auth::is_group_manager($row['cms_body_group_ids'])) continue;
				$options[] = array(
					'value' => $row['cms_body_id'],
					'selected' => ((int)$row['cms_body_id'] == (int)$cms_body_id ? true:false),
					'text' => $row['cms_body_name'] . ' (' . ($row['cms_body_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['cms_body_id'] == (int)$cms_body_id ? ' **':''),
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No page bodies setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_body_selection_list()

	public static function gen_tool_selection_list($name, $cms_tool_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT cms_tool_id,cms_tool_name,cms_tool_enabled" .
			" FROM cms_tools ORDER BY cms_tool_order";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($cms_tool_id ? false:true),
					'params' => ' disabled selected hidden',
					'text' => ' - Select Tool - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['cms_tool_id'],$exc_ids)) continue;
				$options[] = array(
					'value' => $row['cms_tool_id'],
					'selected' => ((int)$row['cms_tool_id'] == (int)$cms_tool_id ? true:false),
					'text' => $row['cms_tool_name'] . ' (' . ($row['cms_tool_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['cms_tool_id'] == (int)$cms_tool_id ? ' **':''),
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No tools setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_tool_selection_list()

	public static function is_iframeable_url($url, $add_msg = true) {
		// return false if full url or error, anti click jacking may be in play
		if(!$parts = parse_url($url)) return false;
		if(((isset($parts['scheme'])) && (!empty($parts['scheme']))) ||
			((isset($parts['host'])) && (!empty($parts['host'])))) {
			// not local
			$url_headers = get_headers($url);
			if($url_headers) {
				foreach ($url_headers as &$value) {
					if(preg_match('/X-Frame-Options.*DENY|X-Frame-Options.*SAMEORIGIN|X-Frame-Options.*ALLOW-FROM/i',$value)) {
						if($add_msg)
							self::addMsg('URL: "' . $url . '" only allowed in new page.',(CMS_C_EXT_URL_NEW_PAGE ? 'warn':'error'));
						return false;
						} // if
					} // foreach
				} // if
			} // if
		return true;
	} // is_iframeable_url()

	public static function get_body_app_run_scripts($name,$cms_object,$option0,$body_dir) {
		$option_cnt = 0;
		$base = preg_replace('/\/.*$/','/',($body_dir . '/'));	// a start folder
		if((!empty($body_dir)) && (!empty($base))) {
			$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Body URL or Include code.">' . PHP_EOL;
			$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select Body URL - ') . '</option>' . PHP_EOL;
			if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
			$script_base = APPS_WS_DIR . $base . 'cli/';
			$scripts = @scandir(DOCROOT_FS_BASE_DIR . $script_base);
			if(empty($scripts)) return 'NA';
			foreach($scripts as $file) {
				$script = $script_base . $file;
				if(!self::is_file_usable($script)) continue;
				if(!preg_match('/\.php$|\.sh$/',$file)) continue;
				$text .= '<option value="' . rawurlencode($file) .'"' . ($file == $cms_object ? ' SELECTED':'') . '>' . $script . '</option>';
				$option_cnt++;
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $cms_object . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No application script found.)</span>';
			return $text;
			} // if
		return $text;
		} // get_body_app_run_scripts()

	private static function  get_body_tools_ext_file_selection_recurse($path,&$text,&$file_url,&$option_cnt,$base = '',$depth = 0) {	// recursive
		if($depth >= (int)INI_TOOLS_SEARCH_DEPTH_MAX) return false;	// no deeper
		$files = @scandir($path . $base);
		if(empty($files)) return false;
		sort($files);
		for($i = 0, $n = count($files); $i < $n; $i++) {
			$file = $files[$i];
			if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN,$file)) continue;	// no hiddens, version control or directory nav
			$file_path = preg_replace('/^\//','',$base . '/' . $file);
			$file_path = self::clean_path($file_path);
			if(is_dir($path . $file_path)) {
				self::get_body_tools_ext_file_selection_recurse($path,$text,$file_url,$option_cnt, $file_path,($depth + 1));	// recurse
				} // if
			else if(preg_match('/\.htm$|\.php$|\.html$|\.txt$|\.md$|\.crt$|\.csr$|\.key$/i',$file)) {
				$option_cnt++;
				$text .= PHP_EOL . '<option style="text-align:left;" value="' . htmlentities($file_path) . '"' . (($file_path == $file_url) ? ' SELECTED':'') . '>' . $file_path . (($file_path == $file_url) ? ' **':'') . '</option>' . PHP_EOL;
				} // else if
			} // for
		return true;
		} // get_body_tools_ext_file_selection_recurse()

	public static function get_body_dir_selection($name,$cms_body_url,$option0,$body_dir) {
		$option_cnt = 0;
		$base = preg_replace('/\/.*$/','/',($body_dir . '/'));	// a start folder
		if((!empty($body_dir)) && (!empty($base))) {
			$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Body URL or Include code.">' . PHP_EOL;
			$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select Body URL - ') . '</option>' . PHP_EOL;
			if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
			self::get_body_tools_ext_file_selection_recurse(APPS_FS_DIR,$text,$cms_body_url,$option_cnt,$base);	// recurse
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $cms_body_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No body files found in "' . self::clean_path(APPS_WS_DIR . $base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_body_dir_selection()

	public static function get_tools_dir_selection($name,$cms_tool_url,$option0 = false,$tool_dir = '') {
		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Tool URL or Include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select Tool URL - ') . '</option>' . PHP_EOL;
		if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		$option_cnt = 0;
		if(!empty($tool_dir)) $base = preg_replace('/\/.*$/','/',($tool_dir . '/'));	// a start folder
		else $base = '';
		self::get_body_tools_ext_file_selection_recurse(LOCAL_FS_TOOLS_DIR,$text,$cms_tool_url,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;
		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $cms_tool_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_error">(No tool files found in "' . LOCAL_FS_TOOLS_DIR . $base . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_tools_dir_selection()

	public static function get_ext_code_dir_selection($name,$ext_code_url,$option0 = false) {
		$option_cnt = 0;
		$base = ETC_WS_EXT_INCLUDES_DIR;	// a start folder
		if(!file_exists(ETC_FS_EXT_INCLUDES_DIR))
			self::chkdir (ETC_FS_EXT_INCLUDES_DIR);

		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Ext include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select External Code Include File - ') . '</option>' . PHP_EOL;
		if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		self::get_body_tools_ext_file_selection_recurse(DOCROOT_FS_BASE_DIR,$text,$ext_code_url,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;

		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $ext_code_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No include files found in "' . self::clean_path(APPS_WS_DIR . $base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_ext_code_dir_selection()

	public static function get_ssl_dir_selection($name,$ssl_url,$option0 = false) {
		$option_cnt = 0;
		$base = ETC_WS_SSL_INCLUDES_DIR;	// a start folder
		if(!file_exists(ETC_FS_SSL_INCLUDES_DIR))
			self::chkdir (ETC_FS_SSL_INCLUDES_DIR);

		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Ext include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select SSL Cert File - ') . '</option>' . PHP_EOL;
		$text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		self::get_body_tools_ext_file_selection_recurse(DOCROOT_FS_BASE_DIR,$text,$ssl_url,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;

		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $ssl_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No include files found in "' . self::clean_path($base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_ssl_selection()

	public static function get_page_body_id() {
		if(!self::$left_column) return 'cms_page_body_nolc';
		if(!self::$right_column) return 'cms_page_body_wlc';
		return 'cms_page_body_wlrc';;
		} // get_page_body_id()

	public static function get_link_frame_id() {
		if(!self::$left_column) return 'cms_link_frame_nolc';
		if(!self::$right_column) return 'cms_link_frame_wlc';
		return 'cms_link_frame_wlrc';;
		} // get_link_frame_id()

	public static function get_admin_scroll2anchor($topOffset = false, $js_flg = true, $name = 'Top', $class = '') {
		if(in_array($name,self::$admin_scroll2anchor_done)) return '';	// not more than once with the same name
		$nsp_name = preg_replace('/[^0-9a-zA-Z]+/','_',$name);	// remove spaces and other silly chars
		self::$admin_scroll2anchor_done[] = $nsp_name;
		$text = '' . PHP_EOL;
		$text .= '<a name="' . $nsp_name . '"></a>' . PHP_EOL;
		if(($js_flg) && (!self::$tablet_flg)) {
			$htm_name = htmlentities($name);
			$block = (self::$block_html ? 'true':'false');
			if(!is_numeric($topOffset)) $topOffset = 'false';
			$text .= <<< EOTANCH

<span id="id_cms_goto_{$nsp_name}_box"
	class="admin_scroll2anchor_box {$class}"
	ondragend="javascript:cms_dragend_elem_save('id_cms_goto_{$nsp_name}_box');"
	ondragstart="javascript:cms_drag_start(event);"
	draggable="true" onclick="javascript:cms_scroll2Name('{$nsp_name}',{$topOffset});"
	title="Back to {$name}"
	>{$htm_name}
</span>

EOTANCH;

			$bid = self::get_page_body_id();
			$text .= <<< EOTSCR

<script  type="text/javascript">
	function check_goto_top_box(id) {
		var x = document.getElementById('{$bid}');
		if(!x) return;
		var blk = {$block};
		var b = document.getElementById(id);
		if(!blk) { // inline
			var sY = window.scrollY;
			var iH = window.innerHeight;
			if(sY > (iH / 3)) {	// down the page
				cms_dragend_elem_restore(id);
				b.style.display = 'block';
				} // if
			else {	// at/near top of page
				b.style.display = 'none';
				} // else
			} // if
		else { // block
			var sT = x.scrollTop;
			var oH = x.offsetHeight;
			if(sT > (oH / 3)) { // block down the window
				cms_dragend_elem_restore(id);
				b.style.display = 'block';
				} // if
			else { // at/near top window
				b.style.display = 'none';
				} // else
			} // else if
		} // check_goto_top_box

EOTSCR;

		$text .= <<< EOTEVS

	document.addEventListener("DOMContentLoaded", function() {
		check_goto_top_box('id_cms_goto_{$nsp_name}_box');
		window.addEventListener("resize", function() {
			check_goto_top_box('id_cms_goto_{$nsp_name}_box');
			}); // function

		if({$block})
			document.getElementById('{$bid}').addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		else
			window.addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		}); // function
</script>

EOTEVS;

			} // if
		return $text;
		} // get_admin_scroll2anchor()

	public static function get_admin_scroll2pageTop($class = '') {
		$name = 'Top';
		if(in_array($name,self::$admin_scroll2anchor_done)) return '';	// not more than once with the same name
		$nsp_name = preg_replace('/[^0-9a-zA-Z]+/','_',$name);	// remove spaces and other silly chars
		self::$admin_scroll2anchor_done[] = $nsp_name;
		if(self::$block_html) {
			$bod = self::get_page_body_id();
			} // if
		else $bod = '';
		$text = '' . PHP_EOL;
		if(!self::$tablet_flg) {
			$htm_name = htmlentities($name);
			$block = (self::$block_html ? 'true':'false');
			$text .= <<< EOTANCH

<span id="id_cms_goto_{$nsp_name}_box"
	class="admin_scroll2anchor_box {$class}"
	ondragend="javascript:cms_dragend_elem_save('id_cms_goto_{$nsp_name}_box');"
	ondragstart="javascript:cms_drag_start(event);"
	draggable="true" onclick="javascript:cms_scroll2PageTop('{$bod}');"
	title="Goto admin top."
	>{$name}</span>

EOTANCH;

			$bid = self::get_page_body_id();
			$text .= <<< EOTSCR

<script  type="text/javascript">
	function check_goto_top_box(id) {
		var x = document.getElementById('{$bid}');
		if(!x) return;
		var blk = {$block};
		var b = document.getElementById(id);
		if(!blk) { // inline
			var sY = window.scrollY;
			var iH = window.innerHeight;
			if(sY > (iH / 3)) {	// down the page
				cms_dragend_elem_restore(id);
				b.style.display = 'block';
				} // if
			else {	// at/near top of page
				b.style.display = 'none';
				} // else
			} // if
		else { // block
			var sT = x.scrollTop;
			var oH = x.offsetHeight;
			if(sT > (oH / 3)) { // block down the window
				cms_dragend_elem_restore(id);
				b.style.display = 'block';
				} // if
			else { // at/near top window
				b.style.display = 'none';
				} // else
			} // else if
		} // check_goto_top_box

EOTSCR;

		$text .= <<< EOTEVS

	document.addEventListener("DOMContentLoaded", function() {
		check_goto_top_box('id_cms_goto_{$nsp_name}_box');
		window.addEventListener("resize", function() {
			check_goto_top_box('id_cms_goto_{$nsp_name}_box');
			}); // function

		if({$block})
			document.getElementById('{$bid}').addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		else
			window.addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		}); // function
</script>

EOTEVS;

			} // if
		return $text;
		} // get_admin_scroll2pageTop()

	public static function get_social_media($location) {
		if(!defined('PL_CMS_SOCIALMEDIA_SM_LOCATION')) return false;
		if(PL_CMS_SOCIALMEDIA_SM_LOCATION != $location) return false;
		// we have social media
		$text = Ccms_socialmedia_plugin::generate('SM',$location);
		return $text;
		} // get_social_media()

	public static function output_noscript_warning() {
		echo '	<noscript>'  . PHP_EOL .
			'		<span class="cms_msg_warning">'  . PHP_EOL .
			'			Detected that your browser\'s JavaScript maybe disabled.<br>'  . PHP_EOL .
			'			You need JavaScript enabled and functional in your browser to utilize the functionality of this website.'  . PHP_EOL .
			'		</span>'  . PHP_EOL .
			'	</noscript>' . PHP_EOL;
		} // output_noscript_warning()

	public static function output_link_or_tool_text($uri, $https = false, $extra_styles = false) {
		// echo Ccms::get_admin_scroll2pageTop();
		// outside a page_body	$id_frame = (self::$left_column ? (self::$right_column ? 'cms_link_frame_wlrc':'cms_link_frame_wlc'):'cms_link_frame_nolc');
		$id_frame = 'cms_link_frame';	// inside a page body (no margins needed)
		$parts = parse_url($uri);
		if(!empty($parts['scheme'])) {
			if((self::$ssl_in_use) && (!preg_match('/https/i',$parts['scheme']))) {	// check for security conflict
//				$text = Ccms_reverse_proxy::init_reverse_proxy_frame($uri, $id_frame);
//				echo $text;
//				$url = '';
				$url = Ccms_reverse_proxy::get_reverse_proxy_src($uri);	// use the proxy to fill frame
				} // if
			else $url = $uri;	// let it go
			} // if
		else {
			if($https) {
				$url = CMS_SSL_URL . $uri;
				} // if
			else $url = $uri;
			} // else
		echo '<div id="'. self::get_link_frame_id() . '"' .
			' class="' . ((self::$tablet_flg) ? 'link_frame_tablet':'link_frame_moz') . '"' .
			(!empty($extra_styles) ? ' style="' . $extra_styles . '"':'') . '>' . PHP_EOL;
		//echo '	<div class="page_container">' . PHP_EOL;
		self::output_noscript_warning();
		echo '		<iframe src="' . $url . '" class="tools ' . ((self::$tablet_flg) ? 'iframe_tablet':'iframe_moz') . '" id="' . $id_frame . '" ' .
			(!empty($extra_styles) ? ' style="' . $extra_styles . '"':'') .
			' scrolling="auto"' .
			// (!self::$block_html ? ' onload="this.style.height=(this.contentWindow.document.body.scrollHeight+20)+\'px\';"':'') .
			'>' . PHP_EOL;
		echo '			<p>Your browser does not support iframes. <a href="' . $uri . '">Click to show</a></p>' . PHP_EOL;
		echo '		</iframe>' . PHP_EOL;
		//echo '	</div>' . PHP_EOL;
		echo '</div>' . PHP_EOL;
		if(isset($_SESSION['action'])) unset($_SESSION['action']);
		if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
		} // output_link_or_tool_text()

	public static function output_body_core($body) {
		if((!empty($body['filepath'])) &&
			($filename = $body['filepath']) &&
			(is_readable($filename))) {
			self::page_start_comment($filename);
			if($body['cms_body_cached'] > 0) {
				Ccms_content_cache::cache_content($filename, false, true);
				} // if
			else {
				include $filename;
				} // else
			self::page_end_comment($filename);
			} // if
		else if((!empty($body['proxy_url'])) &&
			($proxy_url = $body['proxy_url'])) {
			self::page_start_comment(rawurlencode($proxy_url));
			$id_frame = 'cms_link_frame';	// inside a page body (no margins needed)
			$frm_url = Ccms_reverse_proxy::get_reverse_proxy_src($proxy_url);	// use the proxy to fill frame
			echo '		<iframe src="' . $frm_url .
				'" class="tools ' . ((self::$tablet_flg) ? 'iframe_tablet':'iframe_moz') .
				'" id="' . $id_frame . '" ' .
				' scrolling="auto">' . PHP_EOL;
			echo '			<p>Your browser does not support iframes. <a href="' . $proxy_url . '">Click to show</a></p>' . PHP_EOL;
			echo '		</iframe>' . PHP_EOL;
			self::page_end_comment(rawurlencode($proxy_url));
			} // else if
		else return false;
		return true;
		} // output_body_core()

	public static function get_inc_method_callback($inc_file_or_func) {
		if(preg_match('/[ !?@]+/',$inc_file_or_func)) return false;	// not legal
		$cl_fn = preg_split('/::|->|\(|,|\)/',$inc_file_or_func);
		if(count($cl_fn) >= 2) {
			if((Ccms_autoloader::find_class($cl_fn[0])) &&
				(method_exists($cl_fn[0],$cl_fn[1]))) {
				$callback = $cl_fn[0] . '::' . $cl_fn[1];
				return $callback;
				} // if
			if((Ccms_autoloader::find_plugin($cl_fn[0])) &&
				(method_exists($cl_fn[0],$cl_fn[1]))) {
				$callback = $cl_fn[0] . '::' . $cl_fn[1];
				return $callback;
				} // if
			} // if
		return false;
		} // get_inc_method_callback()

	public static function output_include_body_text($inc_file_or_func,$more_globals_ary = '',$inc_top_msgs = true, $inc_bot_msgs = true) {
		if(!empty($more_globals_ary)) {
			foreach($more_globals_ary as $g) {
				global $$g;
				} // foreach
			} // if
		if(empty(self::$ajax)) {	// no positioning in ajax responses
			echo '<div id="'. self::get_page_body_id() . '">' . PHP_EOL;
			echo '	<div class="page_container">' . PHP_EOL;
			self::output_noscript_warning();
			if(!self::$body_full_view) {
				echo PHP_EOL;
				if($inc_top_msgs) include CMS_FS_INCLUDES_DIR . "cms_msgs.php";
				} // if
			}	// if

		if(!empty($inc_file_or_func)) {
			if(is_readable($inc_file_or_func)) {
				if(preg_match('/\.(md|txt)$/i',$inc_file_or_func))
					echo Ccms_media_conv_plugin::get_text_file2html($inc_file_or_func);
				else include($inc_file_or_func);
				$smtxt = self::get_social_media('center_left');
				if(!empty($smtxt)) echo $smtxt . PHP_EOL;
				$smtxt = self::get_social_media('center_right');
				if(!empty($smtxt)) echo $smtxt . PHP_EOL;
				} // if
			else if($callback = self::get_inc_method_callback ($inc_file_or_func)) {
				call_user_func($callback);
				$smtxt = self::get_social_media('center_left');
				if(!empty($smtxt)) echo $smtxt . PHP_EOL;
				$smtxt = self::get_social_media('center_right');
				if(!empty($smtxt)) echo $smtxt . PHP_EOL;
				} // if
			else {
				self::addMsg('Missing file or function: "' . $inc_file_or_func . '"');
				self::$cDBcms->logEvent('ERROR: Missing file or function: "' . $inc_file_or_func . '"');
				} // else
			} // if

		if(empty(self::$ajax)) {	// no positioning in ajax responses
			if(!self::$body_full_view) {
				if($inc_bot_msgs) include CMS_FS_INCLUDES_DIR . "cms_msgs.php";
				} // if
			echo '	</div>' . PHP_EOL;
			echo '</div>' . PHP_EOL;
			if(isset($_SESSION['action'])) unset($_SESSION['action']);
			} // if
		} // output_include_body_text()

	public static function output_include_legal_text($inc_file,$h1) {
		if(empty(self::$ajax)) {	// no positioning in ajax responses
			echo '<div id="'. self::get_page_body_id() . '">' . PHP_EOL;
			echo '	<div class="page_container">' . PHP_EOL;
			self::output_noscript_warning();
			}	// if
		if(!empty($h1)) echo PHP_EOL . '<h1 class="page_body">' . $h1 . '</h1>' . PHP_EOL;
		echo PHP_EOL . '		<div class="page_body cms_legal">' . PHP_EOL;
		if(is_readable($inc_file)) {
			if(preg_match('/\.(md|txt)$/i',$inc_file))
				echo Ccms_media_conv_plugin::get_text_file2html($inc_file);
			else include($inc_file);
			} // if
//		else if($callback = self::get_inc_method_callback ($inc_file)) {
//			call_user_func($callback);
//			} // if
		else {
			self::addMsg('Missing legal file: "' . $inc_file . '"');
			self::$cDBcms->logEvent('ERROR: Missing legal file: "' . $inc_file . '"');
			} // else

		echo PHP_EOL . '		</div>' . PHP_EOL;
		if(empty(self::$ajax)) {	// no positioning in ajax responses
			echo '	</div>' . PHP_EOL;
			echo '</div>' . PHP_EOL;
			} // if
		} // output_include_legal_text()

	public static function get_header_tools_pdb_text($outer = true) {
		$text = '';
		if((!self::$header_tools_sent) &&
			(self::$cms_action != 'get_eula') &&
			(Ccms::get_tool_cnt() > 0)) {
			ob_start();
			include CMS_FS_INCLUDES_DIR . "cms_tools_menu.php";
			$tools = ob_get_clean();
			if(!empty($tools)) {
				if($outer) {
					$text .= Ccms_drop_box::hover_block('Tools',$tools);
					} // if
				else {
					$text .= Ccms_drop_box::hover_block('Tools',$tools);
					} // else
				} // if
			self::$header_tools_sent = !empty($text);
			} // if
		return $text;
		} // get_header_tools_pdb_text()

	public static function get_header_abmin_pdb_text($outer = true) {
		$text = '';
		if((Ccms_auth::is_group_manager()) &&
			(self::$cms_action != 'get_eula')) {
			ob_start();
			include CMS_FS_INCLUDES_DIR . "cms_config_menu.php";
			$admin = ob_get_clean();
			if(!empty($admin)) {
				if($outer) {
					$text .= Ccms_drop_box::hover_block('Admin',$admin);
					} // if
				else {
					$text .= Ccms_drop_box::hover_block('Admin',$admin);
					} // else
				} // if
			self::$header_admin_sent = !empty($text);
			} // if
		return $text;
		} // get_header_abmin_pdb_text()

	public static function get_header_menu_pdb_text($outer = true) {
		$text = '';
		if((!self::$header_menu_sent) &&
			(self::$cms_action != 'get_eula') &&
			(Ccms::get_body_cnt() > 0)) {
			ob_start();
			include CMS_FS_INCLUDES_DIR . "cms_bodies_menu.php";
			$bodies = ob_get_clean();
			if(!empty($bodies)) {
				if($outer) {
					$text .= Ccms_drop_box::hover_block('Menu',$bodies);
					} // if
				else {
					$text .= Ccms_drop_box::hover_block('Main Menu',$bodies);
					} // else
				} // if
			self::$header_menu_sent = !empty($text);
			} // if
		return $text;
		} // get_header_menu_pdb_text()

	public static function get_header_admin_tools_pdb_text() {
		$text = '';
		if(self::$menu_in_header) {
			$text .= self::get_header_menu_pdb_text();
			$text .= self::get_header_tools_pdb_text();
			$text .= self::get_header_abmin_pdb_text();
			} //if
		return $text;
		} // get_header_admin_tools_pdb_text()

	public static function get_JS_calendar_resource($prn_flg = true) {
		// output links for calendar
		$text = array();
		if(!self::$calendar_sent) {
			self::$calendar_sent = true;
			$text[] = '		<link rel="stylesheet" type="text/css" href="' . Ccms_minify_plugin::minify_css(CMS_WS_LIB_DIR . 'calendar/calendar.css') . '">';
			$text[] = '		<script type="text/javascript" src="' . Ccms_minify_plugin::minify_js(CMS_WS_LIB_DIR . 'calendar/calendar.js') . '"></script>';
			} // if
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // get_JS_calendar_resource()

	private static function set_JS_calendar_elem(&$text,$id,&$date_fmt_cntl) {
		$text[] = 'Ccalendar.set(' . $id . ',' . $date_fmt_cntl . ');';
		if(!isset(self::$calendar_ids[$id])) self::$calendar_ids[] = $id;
		} // set_JS_calendar_elem()

	public static function set_JS_calendar_init($ids,$date_fmt_cntl = 'y-m-d',$prn_flg = true) {
		// $ids can be an array of values or a single value
		$text = array();
		if(!empty($ids)) {
			if(!self::$calendar_ids) self::$calendar_ids = array();
			if(!is_array($ids)) self::set_JS_calendar_elem ($text, $ids, $date_fmt_cntl);	// single id string
			else { // an array of id strings
				foreach($ids as &$id) self::set_JS_calendar_elem ($text, $id, $date_fmt_cntl);
				} // else
			} // if
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // set_JS_calendar_init()

	public static function get_JS_colour_picker_resource($prn_flg = true) {
		// output links for calendar
		$text = array();
// @TODO replace colour picker
//		if(!self::$rgbcp_sent) {
//			self::$rgbcp_sent = true;
//			$text[] = '		<link rel="stylesheet" type="text/css" href="' . Ccms_minify_plugin::minify_css(CMS_WS_DIR . 'rgbcp.css') . '">';
//			$text[] = '		<script type="text/javascript" src="' . Ccms_minify_plugin::minify_js(CMS_WS_DIR . 'rgbcp.js') . '"></script>';
//			} // if
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // get_JS_colour_picker_resource()

	public static function set_JS_colour_picker_onclick($id) {
		// @TODO not ready debugged
		$text = '';	// onclick="cPicker.create_colour_picker(\'' . $id . '\');"';
		return $text;
		} // set_JS_colour_picker_onclick()

	public static function set_JS_password_resource($prn_flg = true) {
		if((self::$password_resource_done) || (Ccms::$ajax)) return '';
		self::$password_resource_done = true;
		if((INI_REVEAL_PASSWORD_BOOL) || (INI_SHOW_PASSWORD_BOOL)) {
			$reveal = (INI_REVEAL_PASSWORD_BOOL ? 'true':'false');
			$text =<<< EOTJS

			<script type="text/javascript">
				if(typeof togglePassWD != "function") {

					function mouseoverPassWD(ev,chkcb,id,id_img) {
						var obj = document.getElementById(id);
						setInpType(obj,'text',chkcb,id_img);
						} // mouseoverPassWD()

					function mouseoutPassWD(ev,chkcb,id,id_img) {
						var obj = document.getElementById(id);
						setInpType(obj,'password',chkcb,id_img);
						} // mouseoutPassWD()

					function togglePassWD(ev,chkcb,id,id_img) {
						var obj = document.getElementById(id);
						var val = obj.value;
						if(!chkcb.type) {
							if(obj.type == 'password') setInpType(obj,'text',chkcb,id_img);
							else setInpType(obj,'password',chkcb,id_img);
							} // if
						else if({$reveal}) chkcb.checked = false;
						else {
							if(chkcb.checked) setInpType(obj,'text',id_img);
							else setInpType(obj,'password',id_img);
							} // else
						} // togglePassWD()

					function setInpType(obj, new_type,chkcb,id_img) {
						var new_obj = document.createElement('input');
						new_obj.type = new_type;
						if(obj.size) new_obj.size = obj.size;
						if(obj.value) new_obj.value = obj.value;
						if(obj.name) new_obj.name = obj.name;
						if(obj.placeholder) new_obj.placeholder = obj.placeholder;
						if(obj.id) new_obj.id = obj.id;
						if(obj.className) new_obj.className = obj.className;
						obj.parentNode.replaceChild(new_obj,obj);
						var img = document.getElementById(id_img);
						if(img) {
							var src = img.src;
							if(new_obj.type == 'password')
								img.src = src.replace('closed','open');
							else
								img.src = src.replace('open','closed');
							console.log(img.src);
							} // if
						return new_obj;
						} // setInpType();

					} // if
			</script>

EOTJS;
			if($prn_flg) echo $text;
			return $text;
			} // if
		return '';
		} // set_JS_password_resource()

	public static function set_JS_password_input($name,$title = '',$value = '',$chk_strength = false,$allow_autocomplete = false,$prn_flg = true,$extras = '') {
		static $idx = 0;
		$mh_id = 'id_' . $name . $idx++;	// incr id of form, may have more than one form
		return self::set_JS_password_input_by_id($mh_id,$name, $title, $value, $chk_strength, $allow_autocomplete, $prn_flg,$extras);
		} // set_JS_password_input()

	public static function set_JS_password_input_by_id($mh_id,$name,$title = '',$value = '',$chk_strength = false,$allow_autocomplete = false,$prn_flg = true,$extras = '') {
		$text = array();
		$mh_id_cb = $mh_id . '_cb';
		$mh_id_img = $mh_id . '_img';
		$text[] = self::set_JS_password_resource(false);
		$text[] = '		<div>';
		// $text[] = '		<input type="hidden" id="id_username" name="username" placeholder="Username" value="' . Ccms_auth::get_logged_in_username() . '">';	// stop popup asking user for password
		if(!$allow_autocomplete) $text[] = '		<input type="password" style="display:none;"> <!--Stop autocomplete-->';
		if($chk_strength) {
			$pwd_chks = self::get_password_chk_regex();
			$text[] = '		<input class="std" type="password" placeholder="Password" pattern="' . $pwd_chks['pattern'] . '" id="' . $mh_id . '" name="' . $name . '" value="' . $value . '" title="' . $pwd_chks['title'] . '"';
			} // if
		else $text[] = '		<input class="std" style="display: inline-block;" type="password" placeholder="Password" id="' . $mh_id . '" name="' . $name . '" value="' . $value . '"';
		if(!empty($extras)) $text[] = $extras;
		if(!$allow_autocomplete) $text[] = '			autocomplete="new-password"';
		if(!empty($title)) $text[] = '			title="' . $title . '"';
		$text[] = '		/>';
		if(INI_SHOW_PASSWORD_BOOL) {
			$text[] = '		<span id="' . $mh_id_cb . '"';
			if(INI_REVEAL_PASSWORD_BOOL) {
				$text[] = '			onmouseover="mouseoverPassWD(event,this,\'' . $mh_id . '\',\'' . $mh_id_img . '\');"';
				$text[] = '			onmouseout="mouseoutPassWD(event,this,\'' . $mh_id . '\',\'' . $mh_id_img . '\');"';
				// $text[] = '			title="reveal"';
				// $text[] = '			disabled="ON"';
				$text[] = '>';
				} // if
			else {
				$text[] = '		onclick="togglePassWD(event,this,\'' . $mh_id . '\',\'' . $mh_id_img . '\')"';
				// $text[] = '		onclick="document.getElementById(\'' . $mh_id . '\').type = (this.checked ? \'text\' : \'password\');"';
				// $text[] = '			title="show"';
				$text[] = '>';
				} // else
			$text[] = '			<img name="eye_img" class="eye_img" id="' . $mh_id_img . '"';
			$text[] = '				src="cms/images/icons/eye_open.png"/></span>';
			} // if
		$text[] = '		</div>';
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // set_JS_password_input_by_id()

	public static function add_JS_geolcation_to_form($prn_flg = true,$refresh = false) {
		if(!CMS_C_GEOLOCATE_ALLOW) return '';	// empty string
		if(!self::$ssl_in_use) return '';	// empty string
		if((!$refresh) &&
			(((int)self::$geo_location_loc_time + (int)CMS_C_GEOLOCATE_TTL) < time())) return '';
		$text = array();
		if(self::is_debug())
			$text[] = '		<p id="id_geolation_message" style="text-align: center; font-size:x-small; font-weight: lighter; font-style: italic;"></p>';
		$text[] = '		<input type="hidden" id="id_geo_latitude" name="geo_latitude" value=""/>';
		$text[] = '		<input type="hidden" id="id_geo_longitude" name="geo_longitude" value=""/>';
		$text[] = '		<input type="hidden" id="id_geo_accuracy" name="geo_accuracy" value=""/>';
		$text[] = '		<script type="text/javascript">';
		if(self::is_debug())
			$text[] = '			var el_geo_msg = document.getElementById("id_geolation_message");';
		$text[] = '			var el_geo_latitude = document.getElementById("id_geo_latitude");';
		$text[] = '			var el_geo_longitude = document.getElementById("id_geo_longitude");';
		$text[] = '			var el_geo_accuracy = document.getElementById("id_geo_accuracy");';
		$text[] = '';
		$text[] = '			function get_geo_location() {';
		$text[] = '				if (navigator.geolocation) {';
		$text[] = '					navigator.geolocation.getCurrentPosition(save_geo_location,error_geo_location);';
		$text[] = '					} //if';
		if(self::is_debug()) {
			$text[] = '				else { ';
			$text[] = '					el_geo_msg.innerHTML = "Geolocation is not supported by this browser.";';
			$text[] = '					} // else';
		} // if
		$text[] = '				} // get_geo_location()';
		$text[] = '';
		$text[] = '			function save_geo_location(position) {';
		$text[] = '				el_geo_latitude.value = position.coords.latitude;';
		$text[] = '				el_geo_longitude.value = position.coords.longitude;';
		$text[] = '				el_geo_accuracy.value = position.coords.accuracy;';
		if(self::is_debug())
			$text[] = '				el_geo_msg.innerHTML = "Latitude: " + position.coords.latitude + "&deg;&nbsp;Longitude: " + position.coords.longitude + "&deg;&nbsp;Accuracy: 	&plusmn;" + position.coords.accuracy + "m"';
		$text[] = '				} // save_geo_location()';
		$text[] = '';
		$text[] = '			function error_geo_location(position) {';
		if(self::is_debug())
			$text[] = '				el_geo_msg.innerHTML = position.message;';
		$text[] = '				} // save_geo_location()';
		$text[] = '';
 		$text[] = '			window.addEventListener("DOMContentLoaded",get_geo_location);';
		$text[] = '		</script>';

		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // add_JS_geolcation_to_form()

	protected static function get_clientMeta_sender() {
		if(!CMS_C_CLIENTMETA_ALLOW) return '';
		if((self::$ssl_required) && (!self::$ssl_in_use)) return '';

		$deb_ms = (int)CMS_C_CLIENTMETA_MIN_MS;
		if($deb_ms < 200) $deb_ms = 200;

		$text = <<< EOTMD

		<script type="text/javascript">
			var cmsMetadata_deb_ms = {$deb_ms};	// don't be hasty
		</script>

EOTMD;
		$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_metadata.js',false);
		return $text;
		} // get_clientMeta_sender()

	public static function get_return2search_link($found = false) {
		// if(self::get_or_post('cancel')) return;
		if($found) {
			echo '&nbsp;&nbsp;<span class="cms_msg_success"><img alt="success" src="' . CMS_WS_IMAGES_DIR . 'success.gif">Found here</span>';
			} // if
		echo Ccms_search::get_form_search_inputs();
		} // get_return2search_link()

	public static function get_link_html($link) {
		$text = '';
		if(empty($link)) return '&nbsp;';
		if((Ccms_auth::is_admin_user()) && (LMC_SHOW_CONF_LINKS)) {
			$text .= '<a href="index.php?cms_action=cms_edit_links&link_edit_id=' . $link['lm_link_id'] . '&lm_link_qk_anchor=null&cms_return_action=lm_show_links"';
			$text .= ' title="Configure link,">';
			$text .= '<img class="lm_cog" src="cms/images/icons/cog.gif" alt="cog"/>';
			$text .= '</a>' . PHP_EOL;
			} // if
		$url_parts = parse_url($link['lm_link_url']);
		$url = '';

		if((empty($url_parts['scheme'])) &&
			(empty($url_parts['host'])) &&
			($link['lm_link_ssl']))
			$url .= (self::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL);

		if($link['lm_link_new_page']) {
			$url .= $link['lm_link_url'] . ((int)$link['lm_link_add_name2url'] ? '?name=' . trim($link['lm_link_name']):'');
			} // if
		else {
			$url .= 'index.php?cms_action=link&link_id=' . (int)$link['lm_link_id'] . '&name=' . urlencode(trim($link['lm_link_name']));
			} // else

		if($link['lm_link_new_page']) {
			$text .= '<a href="' . $url . '"';
			$text .= ' target="_blank"';
			$text .= ' title="' . (!empty($link['lm_link_title']) ? strip_tags($link['lm_link_title']) . PHP_EOL:'') . (LMC_SHOWINNEWTAB ? '(in a new tab)':'') . '"';
			} // if
		else {
			$text .= '<a href="' . $url . '"';
			if(!empty($link['lm_link_title'])) $text .= ' title="' . strip_tags($link['lm_link_title']) . '"';
			} // else

		$text .= ' class="link_body">';

		if(!empty($link['lm_link_image_url'])) {
			$cCMS_C = new Ccms_config();
			$text .= $cCMS_C->show_image($link['lm_link_image_url'],ETC_WS_IMAGES_DIR,CMS_C_SMALL_IMAGE_HEIGHT);
			$text .= '<br>';
			} // if
//		if(!empty($link['lm_link_icon_url'])) {
//			if(!isset($cCMS_C)) $cCMS_C = new Ccms_config();
//			$text .= $cCMS_C->show_image($link['lm_link_icon_url'],ETC_WS_ICONS_DIR,CMS_C_SMALL_IMAGE_HEIGHT);
//			$text .= '<br>';
//			} // if
		$text .= trim($link['lm_link_name']);
		$text .= '</a>';
		if((LMC_SHOW_LINK_DESCRIPTION) &&
			(!empty($link['lm_link_description']))) $text .= '<br><small>' . $link['lm_link_description'] . '</small>';
		if((!empty($link['lm_link_comments'])) && (Ccms_auth::is_admin_user())) {
			$text .= '&nbsp;';
			$text .= self::getSimpleNotesDD($link['lm_link_comments']);
			} // if
		return $text;
		} // get_link_html()

	public static function get_live_search_input($name,$value,$ajax_uri = '',$title = '',$class = '',$callback = false) {
		// made from "https://www.w3schools.com/php/php_ajax_livesearch.asp"

		$id = 'id_' . $name;
		if(!empty($callback)) {
			$_SESSION['callbacks']['cms_livesearch'][$name]['func'] = $callback;
			$ajax_uri = 'cms/cms_ajax.php?ajax=cms_livesearch&name=' . urlencode($name);
			} // if
		else if(empty($ajax_uri)){
			Ccms::addMsg(__CLASS__ . '::' . __METHOD__ . ' has no ajax_uri for "' . $name . '".');
			return '';
			} // else
		$pre = $name . '_';
		if(!empty($title)) $title = ' title="' . $title . '"';
		$text =<<< EOT_GLSI
		<script type="text/javascript">'
			function {$pre}showResult(str) {
				if (str.length==0) {
					document.getElementById("{$id}").innerHTML="";
					document.getElementById("{$id}").style.border="0px";
					return;
				} // if
				if (window.XMLHttpRequest) {
					// code for IE7+, Firefox, Chrome, Opera, Safari
					xmlhttp=new XMLHttpRequest();
					} // if
				else {	// code for IE6, IE5
					xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				} // else
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("{$id}").innerHTML=this.responseText;
						document.getElementById("{$id}").style.border="1px solid #A5ACB2";
						} // if
					} // if
				var url = "{$ajax_uri}" + "&q=" + encodeURI(str);	// assume ajax_url already has steering (not need ?)
				xmlhttp.open("GET",url,true);
				xmlhttp.send();
				} // {$pre}showResult()

			function {$pre}selectResult(obj) {
				var new_value = document.getElementById("{$id}").innerHTML;
				document.getElementById("{$id}_inp").innerHTML = new_value;
				} // {$pre}selectResult()

		</script>

		<div class="cms_live_search_input {$class}">
			<input id="{$id}_inp" type="text" oninput="{$pre}showResult(this.value)" value="${value}" {$title}>
			<div id="{$id}" onclick="{$pre}selectResult(this)"></div>
		</div>

EOT_GLSI;

		return $text;
		} // get_live_search_input()

	public static function get_cookie_banner($class = '') {

		switch(CMS_C_COOKIE_BANNER_POSITION) {
		case 'top':
			$b_class = 'cookie_banner_top';
			break;
		case 'bottom':
			$b_class = 'cookie_banner_bottom';
			break;
		default:
			return '';	// no banner
			} // switch

		// don't pester user
		if($close_time = Ccms_auth::get_user_json_data_key('cms_user_cookie_banner_time')) {
			$next_time = $close_time + ((int)CMS_C_COOKIE_BANNER_TTL * 24 * 3600);
			if((int)$next_time > time()) return '';
			} // if
		else {
			$bc_key = 'cookie_banner_time';
			$timeout = time() + ((int)CMS_C_COOKIE_BANNER_TTL * 24 * 3600);
			if((isset($_COOKIE[$bc_key])) &&
				($bc_time = (int)$_COOKIE[$bc_key])) {
				if((int)$bc_time < $timeout) return '';	// no banner
				} // if
			} // else

		$c_file = DOCROOT_FS_BASE_DIR . CMS_C_COOKIE_BANNER_LINK;
		if(!@file_exists($c_file)) {
			$c_file = ETC_FS_EXT_INCLUDES_DIR . CMS_C_COOKIE_BANNER_LINK;
			if(!@file_exists($c_file)) return '';
			} // if
		if(preg_match('/.*\.(html|htm)$/i',$c_file)) $msg = file_get_contents($c_file);
		else {
			ob_start();
			include($c_file);
			$msg = ob_get_clean();
			} // else

		$text = '';
		$text .= <<< EOTXT

		<style>
		div.cookie_banner_top,
		div.cookie_banner_bottom {
			display: block;
			background-color: white;
			color: black;
			border: 1px solid grey;
			font-size: inherit;
			opacity: 1;
			transition: opacity 0.5s;
			text-align: center;
			z-index: +1000;
			width: 100%;
			}
		div.cookie_banner_top {
			position: fixed;
			top: 0px;
			}
		div.cookie_banner_bottom {
			position: fixed;
			bottom: 0px;
			}
		span.cookie_banner_close {
			float: right;
			cursor: pointer;
			padding: 0px 7px;
			font-size: 2em;
			}
		</style>

		<script type="text/javascript">
			function close_cookie_banner(obj) {
				var banner = obj.parentElement;
				if(banner) banner.style.display = 'none';
//				var expires = new Date();
//				expires.setTime({$timeout});
//				Ccms_cookie.set('{$bc_key}', {$timeout});

				var xmlhttp = false;
				if (window.XMLHttpRequest) {
					// code for IE7+, Firefox, Chrome, Opera, Safari
					xmlhttp = new XMLHttpRequest();
					} // if
				else {	// code for IE6, IE5
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} // else
				if(!xmlhttp) return;
				var url = 'cms/cms_ajax.php?ajax=cms_cookie_banner_closed';
				xmlhttp.open("GET",url,true);
				xmlhttp.send();
				} // close_cookie_banner()
		</script>

		<div class="{$b_class} {$class} ">
			<span class="cookie_banner_close" onclick="close_cookie_banner(this);" title="Close">&times;</span>
			<div style="padding: 5px 0px;">
				{$msg}
			</div>
		</div>

EOTXT;

		return $text;
		} // get_cookie_banner()

	public static function hilite_filter(&$filter,&$text) {
		$txt = strip_tags($text);
		if(empty($filter)) return $txt;	// show all
		if(empty($txt)) return '';
		for($i = 0; $i < count($filter); $i++) {
			$f = &$filter[$i];
			if(empty($f)) continue;
			$pat = '/(' . $f . ')/i';
			$txt = preg_replace($pat, '<b style="color: red;">$0</b>', $txt);
			} // foeach
		return $txt;
		} // hilite_filter()

	private static function get_tree_view_recurs(&$tree,&$text,$filter,$depth = 1) {

		foreach($tree as $k => &$v) {
			if(is_array($v)) {
				$text .= str_repeat("\t",$depth) . '<li class="cms_tv">';
				$text .= '	<span class="cms_tv" onclick="cms_tv_toggle_ul(this);">' . $k . ':</span>' . PHP_EOL;
				$text .= str_repeat("\t",$depth) . '	<ul class="cms_tv"' . (($depth > 2) ? ' style="display: none;"':'') . '>' . PHP_EOL;
				if(empty($v)) $text .= 'empty()';
				else {
					self::get_tree_view_recurs($tree[$k],$text,$filter,($depth + 2));
					} // if
				$text .= str_repeat("\t",$depth) . '	</ul>' . PHP_EOL;
				} // if
			else {
				switch(strtolower(gettype($v))) {
				case 'boolean':
					$vb = ($v ? 'true':'false');
					$vt = self::hilite_filter($filter,$vb);
					break;
				case 'integer':
				case 'double':
				case 'string':
				default:
					if(is_null($v)) {
						$vt = 'null';
						break;
						} // if
					$vt = self::hilite_filter($filter,strval($v));
					break;
				case 'array':
					if(empty($v)) {
						$vt = 'empty';
						break;
						} // if
					$vt = self::hilite_filter($filter,strval($v));
					break;
//				case 'object':
//				case 'resource':
//				case 'null':
//					$vt = '(' . gettype($v) . ')';
//					break;
					} // switch
				$kt = self::hilite_filter($filter,$k);
				$text .= str_repeat("\t",$depth) .
					'<li class="cms_tv"><span style="font-style: italic;">' . $kt . ':</span> ' .
					$vt . '</li>' . PHP_EOL;
				} // else
			} // foreach
			return $depth;
		} // get_tree_view_recurs()

	public static function get_tree_view($id,&$tree,$filter = false) {
		// creates a simple tree view form an array
		$text = '';
		static $sty_done = false;
		if(!$sty_done) {
			$sty_done = true;
			$text .= <<< EOTSTY
				<style>
				ul.cms_tv, li.cms_tv {
					list-style-type: none;
					margin: 0;
					}
				span.cms_tv {
					font-weight: bold;
					font-style: italic;
					}
				span.cms_tv:hover {
					text-decoration: underline;
					font-size: 1.05em;
					}
				</style>

				<script type="text/javascript">
					function cms_tv_toggle_ul(obj) {
						if(!obj) return false;
						var parent = obj.parentNode;
						var ul = parent.getElementsByTagName("UL")[0];
						if(ul) {
							if(ul.style.display == 'none')
								ul.style.display = 'block';
							else ul.style.display = 'none';
							} // if
						return true;
						} // cms_tv_toggle_ul()
				</script>

EOTSTY;
			} // if

		$text .= '<ul class="cms_tv" id="cms_tv_' . $id . '">' .PHP_EOL;
		self::get_tree_view_recurs($tree,$text,$filter);
		$text .= '</ul>' .PHP_EOL;
		return $text;
		} // get_tree_view()

	public static function getFormSimpleDropPanel($label,&$form) {
		if(empty($form)) return '';	// no form
		$text = PHP_EOL;
		$text .= Ccms_drop_box::panel_block($label,$form);
		return $text . PHP_EOL;
		} // getFormSimpleDropPanel()

	public static function getSimpleNotesDD($text) {

		$text = <<< EOTTXT

		<div class="cms_ddwn_outer">
			<span>
				<img class="cms_ddwn_img" src="cms/images/icons/notes.gif" alt="notes"/>
			</span>
			<div class="cms_ddwn_inner">
			{$text}
			</div>
		</div>

EOTTXT;
		return $text;
		} // getSimpleNotesDD()

} // Ccms_html
