<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_app_base.php 2033 2021-04-05 09:31:30Z robert0609 $
 */

/**
 * Description of Ccms_app_base
 *
 * Provides an local app base classs
 * It should be used to extend to in all app class
 *
 * @author robert0609
 */

class Ccms_app_base extends Ccms_base {

	protected $web_url = false;
	const EXCLUDED_APP_NAMEs= "images:include:javascript:lib:stylesheets";	// not allowed app names (same apps/ std folders)

	function __construct() {
		Ccms_sm::get_bodies_defines();
		$this->get_web_url();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function is_app_name_allowed($name) {
		$exd = explode(':',self::EXCLUDED_APP_NAMEs);
		if(in_array($name,$exd)) return false;

		return true;
		} // is_app_name_allowed()

	public static function get_ajax_text($ajax) {
		// dummy function for virtual override
		return false;	// return nothing if here
		} // get_ajax_text()

	public static function get_1shot_token() {
		$sorc = 'T' . self::$client_ip . 'K' . microtime() . 'N';
		return md5($sorc);
		} // get_1shot_token()

	public static function get_session_token() {
		$sorc = 'T' . self::$client_ip . 'K' . session_id() . 'N';
		return md5($sorc);
		} // get_session_token()

// dynamic methods
	public function get_web_url() {
		if($this->web_url === false) {
			$this->web_url = self::get_current_body_uri();
			} // if
		return $this->web_url;
		} // get_web_url()

	public function is_cms_admin_chg_allowed() {	// a virtual function, most likely overriden by app
		if(Ccms_auth::is_admin_user()) return true;
		return false;
		} // is_cms_admin_chg_allowed()

	public function is_cms_manager_chg_allowed() {	// a virtual function, most likely overriden by app
		// if($this->is_cms_admin_chg_allowed()) return true;
		if(Ccms_auth::is_admin_user()) return true;
		if(Ccms_auth::is_group_manager()) return true;
		return false;
		} // is_cms_manager_chg_allowed()

	public static function set_next_body_file($next_body_filename = false) {
		if(empty($next_body_filename)) {	// clear next body setting
			if(isset($_SESSION['next_body_filename'])) {
				unset($_SESSION['next_body_filename']);
				return true;
				} // if
			return false;
			} // if
		if(!file_exists($next_body_filename)) return false;
		$_SESSION['next_body_filename'] = $next_body_filename;
		return true;
		} // set_next_body_file()

// static methods overriden if app has the method
	public static function do_app_warnings() {	// virtual
		return true;	// ok, it's not me
		} // do_app_warnings()

	public static function do_app_ini_saved() {	// virtual
		return true;	// ok, it's not me
		} // do_app_ini_saved()

	public static function get_trans_report_options($values) {	// virtual
		return false;
		} // get_trans_report_options()

	public static function &get_ini_app_input_ctl() {	// virtual
		static $grid_inputs = array();
		return $grid_inputs;	// it's a reference
		} // get_ini_app_input_ctl()

	public static function is_app_setup_key_funcs_used($key) {	// virtual
		return false;
		} // is_app_setup_key_funcs_used()

	public static function show_app_setup_value($sect,$key,$name,$value) {	// virtual
		return false;	// not me
		} // show_app_setup_value()

	public static function input_app_setup_form_text($sect,$key,$name,$value) {	// virtual
		return false;	// not me
		} // input_app_setup_form_text()

	public static function get_app_setup_form_value($sect,$key,$name,$value) {	// virtual
		return null;	// not me
		} // get_app_setup_form_value()

} // Ccms_app_base

