<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of cms
 * The top class for cms
 *
 * @author robert0609
 */
class Ccms extends Ccms_sm {

	function __construct() {

		self::$page_start_time = microtime(true);

		set_error_handler('Ccms::global_error_handler');

// doesn't work as intended now as PHP 7 make an assumption on value before checking errorhandler
//		// hook in global error handler
//		self::$prevErrorHandler = set_error_handler('Ccms_base::cms_error_handler',(E_ALL | E_STRICT));

		// do critical checks
		if(!self::chk_bld_crit_dirs()) {		// should never happen
			echo self::getMsgs();
			echo "\nCritical errors found (1). Exiting.\n";
			exit (1);
			} // if
		self::$cDBcms = new Ccms_DB_config(); // also reads in configuration definitions

		// complete the defines from the ini file
		self::define_install_settings();
		// $this->php_mods = get_loaded_extensions();
		if(!self::is_cli()) {	// stop PHP 7 complaining
			if ((INI_ALLOW_HTTP_COMPRESSION_BOOL) &&
				// (!in_array('eAccelerator', $this->php_mods)) &&
				(!Ccms::is_get_or_post('ajax'))) {
				self::set_chk_php_value("zlib.output_compression", 'On');
				} //if
			else {
				self::set_chk_php_value("zlib.output_compression", 'Off');
				} // else
			} // if

		if (!defined('INI_TIMEZONE_TZ'))
			date_default_timezone_set("Australia/Melbourne"); // set a default
		else
			date_default_timezone_set(INI_TIMEZONE_TZ);

		// until this point the any DB logging is disabled (so don't log init() ops.)
		if(defined('CMS_C_LOGS_DB_OPS')) {
			switch(CMS_C_LOGS_DB_OPS) {
			case 'all':
				Ccms_database_common::$m_bSaveDBtransactions = true;
				break;
			case 'debug':
				if(self::$is_debug) Ccms_database_common::$m_bSaveDBtransactions = true;
				break;
			case 'none':
			default:
				break;
				} // switch
			} // if

		Ccms_apps::get_settings();
		if(!self::is_rebuild()) {	// don't do twice
			if(empty(self::$ajax))
				self::$cDBcms->checkDBversion(self::$cDBcms->m_bNew); // if new DB will rebuild install and CSS files

			self::get_bodies_defines();	// to define APPs_ constants
			} // if

		Ccms_sessions::init();

		// set user local
		$locale = self::get_user_locale();
		setlocale(LC_ALL,$locale);

		parent::__construct();
		if(!self::is_rebuild()) {
			self::$cAL = new Ccms_apps(); // reads in apps configuration definitions
			if(empty(self::$ajax)) {
				self::send_downloads();
				self::$visitor_cnt = $this->get_visitor_count();
				} // if
			} // if
		self::$version_str = self::get_version_str();

		self::$cDBcms->m_bDB_checked = true;
		self::do_download_file();

		if((defined('CMS_C_EULA_ALL')) &&
			(CMS_C_EULA_ALL))
			Ccms_auth::do_eula();

		self::chk_geo_location();
		$this->log_http_access();

		self::log_file_maintanence();	// @TODO remove, code test
		} // __construct()

	function __destruct() {
		// $this->log_http_access();
		parent::__destruct();
		if (is_object(self::$cDBcms))
			self::$cDBcms->close();
		if(!empty($_SESSION)) {
			if((empty($_SESSION[CMS_PROJECT_SHORTNAME])) ||
				(!is_array($_SESSION[CMS_PROJECT_SHORTNAME])))
				$_SESSION[CMS_PROJECT_SHORTNAME] = array();
			$_SESSION[CMS_PROJECT_SHORTNAME]['current'] = CMS_PROJECT_VERSION;
			} // if
		} // __destruct()

// dynamic functions

// static functions

	public static function show_stats() {
		$text = date('d M Y');
		if (CMS_C_SHOW_STATS) {
			$text .= ', Used: ' . number_format((memory_get_peak_usage() / 1024)) . 'kB';
			self::$page_end_time = microtime(true); // not quite the end
			$text .= sprintf(", %0.3f seconds.", self::$page_end_time - self::$page_start_time);
			if((Ccms_auth::is_user_logged_in()) &&
				(CMS_C_GEOLOCATE_ALLOW) &&
				(self::$geo_location_latitude) &&
				(self::$geo_location_longitude)) {
				$timeout = (int)CMS_C_GEOLOCATE_TTL + (int)self::$geo_location_loc_time;
				if($timeout > time()) {
					$text .= '<br>' . PHP_EOL;
					$text .= '<p id="id_geolation_message_stat" style="text-align: center; font-size:xx-small; font-weight: lighter; font-style: italic;">';
					$text .= 'Latitude: ' . self::$geo_location_latitude . '&deg;, Longitude: ' . self::$geo_location_longitude . '&deg;' . (self::$geo_location_accuracy ? ', &plusmn;' . self::$geo_location_accuracy . 'm':'') . ' on ' . date('d/m/Y H:i:s',self::$geo_location_loc_time) . '</p>';
					$text .= '</p>' . PHP_EOL;
					} // if
				} // if
		} // if
		else
			$text .= '&nbsp;'; // something
		return $text;
	} // show_stats()

	public static function do_analytics_include() {
		if (
			// (!self::is_debug()) && // not DEBUG
			// (self::is_production()) &&
			(strlen(INI_ANALYTICS_EXT_INC) > 4)) {
			$config_host = parse_url(CMS_C_WEB_SITE_ADDRESS, PHP_URL_HOST);
			$run_host = $_SERVER['SERVER_NAME'];
			if((stripos($config_host,$run_host) !== false) || (stripos($run_host,$config_host) !== false)) {	// backwards / forwards check
				$ap = ETC_FS_EXT_INCLUDES_DIR . INI_ANALYTICS_EXT_INC;
				if(!is_readable($ap)) {
					$ap = DOCROOT_FS_BASE_DIR . INI_ANALYTICS_EXT_INC;
					if(!is_readable($ap)) return;
					} // if
				Ccms::page_start_comment(INI_ANALYTICS_EXT_INC);
				include($ap);
				Ccms::page_end_comment(INI_ANALYTICS_EXT_INC);
				} // if
			} //if
	} // do_analytics_include()

} // Ccms
