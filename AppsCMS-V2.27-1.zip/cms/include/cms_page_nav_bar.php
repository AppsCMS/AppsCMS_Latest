<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_page_nav_bar.php 1961 2021-01-25 10:09:54Z robert0609 $
 */


if(!INI_NAV_BAR_BOOL) return;

global $navbar_prefix, $menu_only;
if(!isset($navbar_prefix)) $navbar_prefix = '';
if(!isset($menu_only)) $menu_only = false;

$grid = Ccms::get_navbar_grid($menu_only);
if(((!Ccms::show_left_column()) || (Ccms::$body_full_view)) &&
	(Ccms::is_hover_boxes_ok())) {

	if(Ccms::get_tool_cnt(true) > 0) {	// put tools drop down in here
		ob_start();
		include CMS_FS_INCLUDES_DIR . "cms_tools_menu.php";
		$tools = ob_get_clean();
		if(!empty($tools)) {
			$icon = Ccms_html::get_navbar_icon_text('Tools');
			$text = Ccms_drop_box::hover_block($icon, $tools);
			$tool_grid = array( array('',$icon,'','text' => $text));
			if(preg_match('/left/i', INI_NAV_BAR_LINKS_POSITION)) $grid = array_merge ($tool_grid,$grid);
			else  $grid = array_merge ($grid,$tool_grid);
			} // if
		} // if

	if(Ccms_auth::is_group_manager()) {	// put admin drop down in here
		ob_start();
		include CMS_FS_INCLUDES_DIR . "cms_config_menu.php";
		$admin = ob_get_clean();
		if(!empty($admin)) {
			$icon = Ccms_html::get_navbar_icon_text('Admin');
			$text = Ccms_drop_box::hover_block($icon, $admin);
			$admin_grid = array( array('',$icon . 'Admin','','text' => $text));
			if(preg_match('/left/i', INI_NAV_BAR_LINKS_POSITION)) $grid = array_merge ($admin_grid,$grid);
			else  $grid = array_merge ($grid,$admin_grid);
			} // if
		} // if
	} // if

if(count($grid) > 0) {
	$i_cnt = count($grid) + 1;
	$liw_text = '';
	$ul_text = '';
	if(strlen(INI_NAV_BAR_LINKS_POSITION) > 2) {
		$lw = INI_NAV_BAR_LINKS_POSITION;
		if(Ccms::$body_full_view) {
			if(preg_match('/[0-9]px|[0-9]%/i', $lw)) $liw_text = ' style="text-align: center; min-width: ' . $lw . ';"';
			} // if
		else {
			if(preg_match('/right/i', $lw)) {
				$ul_text = ' style="float: right; justify-content: flex-end;"';
				$liw_text = ' style="text-align: center;"';
				} // if
//			else if(preg_match('/center|centre/i', $lw)) {
//				$ul_text = ' style="text-align: center;'; ?????
//				$liw_text = ' style="text-align: center;"';
//				} // if
			else if(preg_match('/left/i', $lw)) {
				$ul_text = ' style="float: left;"';
				$liw_text = ' style="text-align: center;"';
				} // if
			else if(preg_match('/even|spread/i', $lw)) {
				$w = (int)((100 - 2 - $i_cnt)/($i_cnt + 1));	// - 2 - $i_cnt to stop wrapping
				$liw_text = ' style="text-align: center; max-width: ' . $w . 'vw;"';
				} // if
			else if(preg_match('/[0-9]px|[0-9]%/i', $lw)) $liw_text = ' style="text-align: center; min-width: ' . $lw . ';"';
			} // else
		} // if
	$cur_uri = basename($_SERVER['REQUEST_URI']);

	Ccms::page_start_comment(__FILE__);
?>
<div <?php
	if(!Ccms::$body_full_view) {
		$id = 'cms_navbar_nolc';
		if(Ccms::show_left_column()) {
			if(Ccms::show_right_column()) $id = 'cms_navbar_wlrc';
			else $id = 'cms_navbar_wlc';
			} // if
		echo 'id="' . $id . '"' . (INI_NAV_BAR_RIGHT_BOOL ? ' style="float: right; position: sticky; right: 10px;"':'');
		} // if
	else {
		echo $navbar_prefix . 'cms_navbar"';
		} // else
		?>>
	<div>
	<ul class="<?php echo $navbar_prefix; ?>cms_nav_bar"<?php echo $ul_text; ?>>
<?php
	if(Ccms::$body_full_view) {
		echo Ccms_msgs::getMsgsStack() . PHP_EOL;
		} // if

		for($i = 0;$i < $i_cnt; $i++) {
			if(!isset($grid[$i])) continue;
			$lk = (isset($grid[$i]['uri']) ? $grid[$i]['uri']:$grid[$i][0]);
			$txt = (isset($grid[$i]['nb_icon']) ? $grid[$i]['nb_icon']:$grid[$i][1]);
			$tit = (isset($grid[$i]['title']) ? $grid[$i]['title']:$grid[$i][2]);
			if(empty($txt)) {
				$txt = '(empty)';
				$tit .= '(missing link text for link URL; ' . addslashes(htmlentities($lk)) . ' on row ' . $i . ', check config)';
				} // if
			if((!isset($grid[$i]['uri'])) && (isset($grid[$i]['text']))) {	// a drop down or similar
				echo '		<li class="' . $navbar_prefix . 'cms_nav_bar"' . $liw_text . '>' . $grid[$i]['text'] . '</li>' . PHP_EOL;
				} // if
			else if($cur_uri != $lk) {
				echo '		<li class="' . $navbar_prefix . 'cms_nav_bar"' . $liw_text . '>' . '<a class="' . $navbar_prefix . 'cms_nav_bar" href="' . $lk . '"' . ' onclick="Ccms_cursor.setWait();"' . (!empty($tit) ? ' title="' . $tit . '"':'') . '>' . $txt . '</a>' . '</li>' . PHP_EOL;
				} // if
			else echo '		<li class="' . $navbar_prefix . 'cms_nav_bar_on"' . $liw_text . '>' . $txt . '</li>' . PHP_EOL;
			} // for

		if((!Ccms::show_left_column()) &&
			(INI_NAV_BAR_RIGHT_BOOL) &&
			(!preg_match('/logout|login/',Ccms::$action))) {	// make room for admin drop down
			if((Ccms_auth::is_user_logged_in()) || (CMS_C_SHOW_LOGIN_LINK)) {
				if(!Ccms::$body_full_view) {
					// echo '		<li class="' . $navbar_prefix . 'cms_nav_bar_on" style="width: 25px; border: 0 none #ffffff">' . ' ' . '</li>' . PHP_EOL;
					$text = Ccms_auth::get_login_logout($navbar_prefix . 'cms_nav_bar');
					} // if
				else if(Ccms::$body_full_view) {
					$text = Ccms_auth::get_signin_signout($navbar_prefix . 'cms_nav_bar');
					} // if
				if(!empty($text))
					echo '		<li class="' . $navbar_prefix . 'cms_nav_bar"' . $liw_text . '>' . $text . '</li>' . PHP_EOL;

				} // if
			} // if
?>
	</ul>
	</div>
</div>
<?php
	Ccms::page_end_comment(__FILE__);
	} // if
