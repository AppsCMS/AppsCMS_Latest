<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_page_footer.php 2008 2021-03-02 09:51:18Z robert0609 $
 */

if(INI_FOOTER_BOOL) {
	if((CMS_C_CUSTOM_FOOTER) && (is_readable(PAGE_FOOTER_FS_INC))) {
		Ccms::page_start_comment(PAGE_FOOTER_INC);
		include PAGE_FOOTER_FS_INC;
		Ccms::page_end_comment(PAGE_FOOTER_INC);
		} // if
	else {
		Ccms::page_start_comment(__FILE__);
?>

<div id="cms_footer">
	<table class="page_bottom">
		<caption>Page footer</caption>
		<tr class="page_bottom">
			<td>&nbsp;</td>
			<td class="page_bottom" style="min-width: 25%; text-align: left;">
				<?php echo Ccms::get_disclaimer_text(); ?>
			</td>
<?php
		$smtxt = Ccms::get_social_media('footer_left');
		if(!empty($smtxt)) echo '<td class="page_top" style="text-align: left;" rowspan="2">' . $smtxt . '</td>' . PHP_EOL;
?>
			<td class="page_bottom" style="text-align: center;">
				<?php echo Ccms::get_copyright_text(); ?>
			</td>
<?php
		$smtxt = Ccms::get_social_media('footer_center');
		if(!empty($smtxt)) echo '<td class="page_top" style="text-align: left;" rowspan="2">' . $smtxt . '</td>' . PHP_EOL;
?>
<?php
		$smtxt = Ccms::get_social_media('footer_right');
		if(!empty($smtxt)) echo '<td class="page_top" style="text-align: right;" rowspan="2">' . $smtxt . '</td>' . PHP_EOL;
?>
			<td class="page_bottom" style="min-width: 25%; text-align: right;">
				<?php echo Ccms::get_about_text_link(); ?>
			</td>
			<td>&nbsp;</td>
		</tr>
		<tr class="page_bottom">
			<td>&nbsp;</td>
			<td class="page_bottom" style="min-width: 25%; text-align: left;">
				<?php Ccms::show_page_legals(); 	?>
			</td>
			<td class="page_bottom" style="text-align: center;">
				<?php echo Ccms::show_stats(); ?>
			</td>
			<td class="page_bottom" style="min-width: 25%; text-align: right;">
				<?php echo Ccms::get_show_counter_text(); ?>
			</td>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<?php

		echo Ccms::get_cookie_banner();

		Ccms::page_end_comment(__FILE__);
		} // else
} // if

