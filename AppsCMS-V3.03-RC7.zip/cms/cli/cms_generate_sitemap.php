<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_generate_sitemap.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE', true);	// tell configure

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

Ccms::addInfoMsg('Starting -> sitemap generator for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.');

if((defined('CMS_C_WEB_SITE_ADDRESS')) &&
	(strlen(CMS_C_WEB_SITE_ADDRESS) > 8) &&
	(Ccms::has_dns_record(CMS_C_WEB_SITE_ADDRESS))) {
	new Ccms_xml_sitemap();
	} // if
else Ccms::addMsg ('Main Web Site URL not set or no DNS record found.');

$msgs = Ccms::getMsgs();
$msgs = preg_replace('/\<br\>|\<br\/\>|\<\/p\>|\<\/tr\>/i', PHP_EOL,  strip_tags($msgs));
$msgs = preg_replace('/&nbsp;/i', '', $msgs);
echo $msgs;

Ccms::addInfoMsg('Finished -> sitemap generator for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.');

exit(0);

// eof
