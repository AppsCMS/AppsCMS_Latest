#!/bin/bash
# set -x
#	Applications Management System Library for PHP (AppsCMS) App Filesystem Wrapper
#	===============================================================================
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_wrap_apps.sh 2856 2022-10-10 04:29:47Z robert0609 $

# pack up file structure for Applications Management System Library for PHP
# all the files to be packed are in the cms/ directory (including examples).

FVERSION="V3.03-RC4"
DT="$(date '+%Y%m%d-%H%M%S')"
PROG="$(basename "$0")"
BDIR="$(dirname "$0")"
echo "$PROG $DT - $FVERSION"
SQSF_DDIRS="apps"
B2T=0
SVNSETPROPS=0

source cms/cli/cms_include.sh

USAGE="USAGE: $PROG [-h|--help] [--wrap-apps (default)] [-b2t|--branch2trunk] [-s|--set-svn-props]\n
  Wrap $SQSF_DDIRS application directories into a read only squashfs file.\n
  See technical manual for more information.\n
  --branch2trunk, wrap branch app directories to trunk directory on SVN versions (if the same trunk directory exists).\n
    e.g. wrap \"/some/base/dir/branches/app_dir\" to \"/some/base/dir/trunk/app_dir.sqsf\".\n
  On non other file structures, --branch2trunk is ignored and\n
    places the apps .sqsf files in the source (DOCROOT) directory.\n
  Note: The --branch2trunk option helps to reduce clutter in branches to trunk\n
    (i.e. development to published) structures.\n
   --set-svn-props, set svn keywords properties.\n
"

out_msg "AppsCMS application wrapper: $PROG - $DT - $FVERSION" info

function squash_app_dir() { # $1=dir
	local SQSF="${1}_fs_sqsh.sqsh"
	local SDIR="$(realpath "$BDIR" | sed 's|cms/cli||')"
	local DDIR="$SDIR"
	local TMP=""
	if [ $B2T -ne 0 ]; then
		if [ -n "$(echo "$SDIR" | grep trunk)" ]; then
			out_msg "\"$SDIR\" is trunk. Not wrapping \"$1\"." warn
			return 0	# ok
		fi
		TMP="$(echo "$SDIR" | sed 's|branches|trunk|')"
		if [ -d "$TMP" ]; then
			DDIR="$TMP"
		else
			out_msg "Destination \"${TMP}\" not found for option --branch2trunk." warn
			out_msg "Wrap \"${SDIR}${1}\" to \"${TMP}${SQSF}\" not available." warn
			return 1
		fi
	fi
	if [ ! -f "${DDIR}cms_lib_sqsh.sqsh" ]; then
		out_msg "\"${DDIR}\" is not an AppsCMS directory." info
		return 0
	fi

	out_msg "Wrap \"${SDIR}${1}\" to \"${DDIR}${SQSF}\"." info

	if [ -n "$(findmnt "${SDIR}${1}")" ]; then
		out_msg "$SQSF is mounted, cannot continue." err
		return 1
	fi
	if [ -f "${SDIR}${SQSF}" ]; then rm -f "${SDIR}${SQSF}" > /dev/null 2>&1; fi	# unclutter
	if [ -f "${DDIR}${SQSF}" ]; then rm -f "${DDIR}${SQSF}" > /dev/null 2>&1; fi	# clean
	mksquashfs "${SDIR}${1}" "${DDIR}${SQSF}" -info -force-uid 0 -force-gid 0 -no-duplicates > /dev/null
	if [ $? -ne 0 ]; then
		out_msg "Failed to wrap $SQSF." err
		return 1
	else
		ls -lh "${DDIR}${SQSF}"
		out_msg "Wrapped $SQSF." ok
	fi
	return 0
} # squash_app_dir()

while [ -n "$1" ]
do
	case "$1" in
	-s|--set-svn-props )
		SVNSETPROPS=1
		;;
	-b2t|--branch2trunk)
		B2T=1
		;;
	* )
		out_msg "Option $1 unknown." err
		echo -e $USAGE
		exit 1
		;;
	esac
	shift
done

# set svn Id keywords
if [ $SVNSETPROPS -ne 0 ]; then
	out_msg "PropSet SVN Keywords in \"${SQSF_DDIRS}\"." info
	# everything in ${SQSF_DDIRS} except PEAR
	find "${SQSF_DDIRS}" -type f | egrep -v 'svn|git|/lib' | while read F
	do
		svn propset svn:keywords "Id" "$F" 2&> /dev/null
	done
fi

for D in $SQSF_DDIRS
do
	squash_app_dir "$D"
done

exit 0

# EOF
