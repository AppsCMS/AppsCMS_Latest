#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_ws_socks.sh 2788 2022-09-04 11:49:25Z robert0609 $

# websockets daemon control script for Applications Management System Library for PHP (AppsCMS)
#

BASE_DIR="$(pwd | sed 's|cms/cli||' )"
PROG="cms/cli/$(basename "$0")"
cd "$BASE_DIR"
source cms/cli/cms_include.sh
FVERSION="$INC_VERSION"
# echo $(basename "$0") $@	# test

function help() { #
	echo "Usage: $PROG [-h|--help] [--start|-st|--status|--stop]"
	echo "  Where:"
	echo "    --start - start websockets daemon,"
	echo "    -st|--status - get websockets daemon status,"
	echo "    --stop - stop websockets daemon."
} # help()

function ws_start() { # cli $@
	php cms/cms_ws_server.php start $@ &
	if [ $? -ne 0 ]; then
		out_msg "Failed to start WS socks daemon." err
		return 1
	fi
	out_msg "Started WS socks daemon." ok
	return 0
} # ws_start()

function ws_status() { # cli $@
	local TXT="$(php cms/cms_ws_server.php status $@)"
	local RET=$?
	out_msg "$TXT"	# info
	return $RET
} # ws_status()

function ws_stop() { # cli $@
	local TXT="$(php cms/cms_ws_server.php stop $@)"
	local RET=$?
	out_msg "$TXT"	# info
	return $RET
} # ws_stop()

case "$1" in
	--start)
		ws_start $@
		exit $?
		;;
	-st|--status)
		ws_status $@
		exit $?
		;;
	--stop)
		ws_stop $@
		exit $?
		;;
	*)
		help
		exit 0
		;;
esac

# EOF

