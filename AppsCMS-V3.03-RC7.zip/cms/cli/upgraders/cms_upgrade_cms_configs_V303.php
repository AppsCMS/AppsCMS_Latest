<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_update_cms_configs_V303.php 2869 2022-10-15 04:59:15Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('REBUILD_MODE',	true);	// tell configure i am rebuilding (same as rebuild from web)

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

if(!function_exists('Ccms_DB_install::upgrade_DB_lmc_V303')) {
	echo "AppCMS library method: Ccms_DB_install::upgrade_DB_lmc_V303, not found";
	exit (1);
	} // if
if(!Ccms_DB_install::upgrade_DB_lmc_V303()) exit(2);

exit(0);	// ok

// done
// eof
