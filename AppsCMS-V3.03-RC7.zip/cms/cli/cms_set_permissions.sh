#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_set_permissions.sh 2913 2022-10-25 09:57:50Z robert0609 $

# set special directories for apache access
# need sudo privileges, take care running as root

FVERSION="V3.03-RC7"

source cms/cli/cms_include.sh

SET_PERMS=0	# default to not set permisions (needs sudo)
is_sudoer
if [ $? -eq 0 ]; then
	SET_PERMS=1	# in the sudo zoo
else
	out_msg "Sudo not available for $USER." err
	out_msg "Need to run \"./cms_lib_sqsh.sh --set-perms\" as root or sudo from site (DOCROOT)." info
	exit 1
fi

NOK=0
WWW_USER=''
function get_apache_username() {
	local AP_DIRS

	# try to find a run apache daemon
	WWW_USER="$(ps -A  -o user:20,comm | egrep '([a|A]pache|[h|H]ttpd)' | grep -v `whoami` | grep -v root | head -n1 | awk '{ print $1 }')"
	if [ -z "$WWW_USER" ]; then
		out_msg 'Apache user name not detected running.' 'warn'
	fi

	if [ -z "$WWW_USER" ]; then
		# try to find the apache user name in the /etc/password file (not best way)
		WWW_USER="$(egrep -i '^apache|:apache|www.*daemon' /etc/passwd | awk -F':' '{ print $1 }')"
		if [ -z "$WWW_USER" ]; then
			out_msg 'Apache user name not found /etc/passwd' 'warn'
		fi
	fi

	if [ -z "$WWW_USER" ]; then
		# try to find the user name by configs (quirky at best)
		AP_DIRS="/etc/httpd /etc/apache /etc/apache2"
		for D in $AP_DIRS
		do
			WWW_USER="$(grep -irw '^[\s]*user' "$D" 2> /dev/null | head -n 1 | awk '{ print $2 }')"	
			if [ -n "$WWW_USER" ]; then break; fi
		done
		if [ -z "$WWW_USER" ]; then
			out_msg 'Apache user name not found scanning configs.' 'warn'
		fi
	fi


	if [ -z "$WWW_USER" ]; then
		out_msg 'Apache user name not found.' 'err'
		return 1	# not found
	fi
	return 0	# found
} # get_apache_username()

get_apache_username
if [ $? -ne 0 -o -z "$WWW_USER" ]; then
	out_msg "Apache user name not found, cannot check user permissions and group permissions membership." err
	exit 1
else
	out_msg "Apache is running as user: $WWW_USER" info

	DOCROOT_GROUP="$(stat -c '%G' ../)"
	out_msg "DOCROOT group is: $DOCROOT_GROUP" info

	getent group $DOCROOT_GROUP | grep $WWW_USER > /dev/null
	if [ $? -ne 0 ]; then
		out_msg "Apache user: $WWW_USER, is NOT a member of DOCROOT group: $DOCROOT_GROUP" err
		exit 3
	else
		out_msg "Apache user: $WWW_USER, is a member of DOCROOT group is: $DOCROOT_GROUP" info
	fi
fi

PROG="$(basename "$0")"
BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null

BASE_DIR="$(pwd)"

UGROUP="$1"	# "$(id -g)"
if [ -z "$UGROUP" ]; then
	UGROUP="$(stat -c "%G" .)"
fi

UUSER="$2"	# "$(id -g)"
if [ -z "$UUSER" ]; then
	UUSER="$(stat -c "%U" .)"
fi

USAGE="Usage: sudo $PROG [group_to_use] [user_to_use]"

if [ $USER != root -a $SUZOO -eq 0 ]; then
	out_msg "Must be the root (or sudo) user." err
	exit 10
fi
if [ -z "$UGROUP" ]; then
	out_msg "Could not find user group." err
	echo -e "$USAGE"
	exit 11
fi
out_msg "Using user $UUSER and group $UGROUP." info

# check $WWW_USER is in the $UGROUP group
A="$(groups $WWW_USER)"; B="${A#*:}";
ACHK="$(echo "$B" | grep "$WWW_USER")"
if [ -z "$ACHK" ]; then
	out_msg "Adding $WWW_USER user to $UGROUP group" info
	usermod -a -G "$UGROUP" "$WWW_USER"
	if [ $? -ne 0 ]; then
		out_msg "Failed to add user $WWW_USER to $UGROUP group." err
		exit 13
	fi
fi
# else already there

set_file_perms() { #  $1=file $2=user $3=group
	local FILE="$1"
	local USER="$2"
	local GROUP="$3"
	out_msg "Settings permission on \"$FILE\"." info
	$SUDO_BIN chmod ug+rw,o+r,o-w "$FILE"
	if [ $? -ne 0 ]; then
		out_msg "Failed to chmod ug+rw,o+r,o-w on \"$FILE\"." err
		NOK=1
	fi
	if [ -n "$(echo "$FILE" | egrep -i '\.sh$')" ]; then
		$SUDO_BIN chmod +x "$F"
		if [ $? -ne 0 ]; then
			out_msg "Failed to chmod ug+x,o-x on  \"$FILE\"." err
			NOK=1
		fi
	fi

	$SUDO_BIN chown ${USER}:${GROUP} "$FILE"
	if [ $? -ne 0 ]; then
		out_msg "Failed to chown ${USER}:${GROUP} on \"$FILE\"." err
		NOK=1
	fi
	return $NOK
} # set_file_perms()

set_dir_perms() { # $1=dir $2=user $3=group
	local F
	local X
	local DIR="$1"
	local USER="$2"
	local GROUP="$3"

	$SUDO_BIN chmod 0775 cms/cli/cms_set_permissions.sh	# make sure it works in sqsh
	find "$DIR" -maxdepth 1 | sort | while read F
	do
		# echo "F=$F"	# test
		BN="$(basename "$F")"
		if [ "$BN" == "." -o "$BN" == ".." ]; then continue; fi
		is_readonly_mount "$F"
		if [ $? -eq 0 ]; then 	# read only
			out_msg "\"$F\" readonly." info
			continue
		fi

		out_msg "Settings perms on \"$F\"." info
		$SUDO_BIN chmod -R ug+rw,o+r,o-w "$F"
		if [ $? -ne 0 ]; then
			out_msg "Failed to chmod -R ug+rw,o+r,o-w \"$F\"." err
			NOK=1
		fi

		$SUDO_BIN chown -R ${USER}:${GROUP} "$F"
		if [ $? -ne 0 ]; then
			out_msg "Failed to chown  -R ${USER}:${GROUP} \"$F\"." err
			NOK=1
		fi
		# make shell scripts executable
		for X in $(find "$F" -type f -name \*.sh )
		do
			$SUDO_BIN chmod ug+x,o-x "$X"
			if [ $? -ne 0 ]; then
				out_msg "chmod failed to set execute perms on \"$X\"." err
				NOK=1
			fi
		done
	done
	if [ $NOK -ne 0 ]; then
		out_msg "Failed to set perms on \"$1\"." err
	else
		out_msg "Set perms on \"$1\"." ok
	fi
	$SUDO_BIN chmod 0775 cms/cli/cms_set_permissions.sh	# make sure it works in sqsh
	return $NOK		# 0 == ok
} # set_dir_perms()

# create any missing var/ driectories
CHK_DIRS=" \
	var/logs/ \
	var/sessions/ \
	var/cache/ \
	var/Trash/ \
	var/variables/ \
	var/exports/ \
"

for D in $CHK_DIRS
do
	if [ ! -d "$D" ]; then
		$SUDO_BIN mkdir -p "$D"
		if [ $? -ne 0 ]; then
			out_msg "Failed to mkdir \"$D\"." err
			exit 1
		fi
	fi
done

out_msg "Setting DOCROOT $UUSER:$UGROUP files." info
for F in $(ls -a | egrep -v '^(etc|var|cms|apps)$')
do
	set_file_perms "$F" $UUSER $UGROUP
done

out_msg "Setting DOCROOT $UUSER:$UGROUP directories." info
for S in $(ls -a | egrep -v '^(etc|var)$')
do
	set_dir_perms "$S" $UUSER $UGROUP
done

if [ $SUZOO -ne 0 ]; then
	out_msg "Setting DOCROOT $WWW_USER:$UGROUP directories." info
	for D in $(ls -a | egrep -i '^(etc|var)$')
	do
		set_dir_perms "$D" $WWW_USER $UGROUP
	done
else 
	out_msg "No sudo available to set $WWW_USER permissions." err
fi

popd > /dev/null

exit $NOK

# done

# EOF
