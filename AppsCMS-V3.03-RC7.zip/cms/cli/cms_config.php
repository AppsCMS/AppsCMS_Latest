<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_config.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure

// $cms_docroot = preg_replace('/\/(apps|cms)\/.*$/','',__DIR__);	// test
require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$ret=-1;
if(empty($argv[1])) {
	Ccms::addMsg('Missing option or config name.');
	exit(1);
	} // if
switch($argv[1]) {
case '--list':
case '-l':
	$filter = null;
	$exclude = null;
	if(!empty($argv[2])) {
		$filter = $argv[2];
		if(!empty($argv[3])) {
			$exclude = $argv[3];
			} // if
		} // if
	$ret = list_configs($filter,$exclude);
	break;
default:
	$config_name = $argv[1];
	$new_value = null;
	if(!empty($argv[2])) $new_value = $argv[2];
	$ret = get_set_config($config_name,$new_value);
	break;
	} // switch
exit($ret);

function list_configs($filter = null,$exclude = null) {

	$def_consts = get_defined_constants(true);
	$user_consts = &$def_consts['user'];
	if(empty($filter)) {
		var_export($user_consts);
		return 0;
		} // if
	foreach($user_consts as $k => &$v) {
		if((stripos($k,$filter) === false) && (stripos($v,$filter) === false)) continue;
		if(!empty($exclude)) {
			if((stripos($k,$exclude) !== false) || (stripos($v,$exclude) !== false)) continue;
			} // if
		echo "'" . $k . "' => '" . $v . "'," . PHP_EOL;
		} // foreach
	return 0;
	} // list_configs()


function get_set_config($config_name,$new_value = null) {
	$old_value = null;
	$config_key = strtoupper($config_name);

	if(defined($config_key)) $old_value = constant($config_key);

	if(preg_match('/^CMS_S_/',$config_key)) {
		if(is_null($old_value)) $old_value = Ccms_base::get_cms_ini_value($config_key);
		if((!empty($new_value)) && ($new_value != $old_value) &&
			(!Ccms_base::set_cms_ini_value(preg_replace('/^CMS_S_/','',$config_key),$new_value))) {
			Ccms::addMsg('Failed to set config name: ' . $config_key . ' to "' . $new_value . '"');
			return 10;
			} // if
		} // if
	else if(preg_match('/^APP_/',$config_key)) {
		if(is_null($old_value)) $old_value = Ccms_apps::get_apps_ini_value($config_key);
		if((!empty($new_value)) && ($new_value != $old_value) &&
			(!Ccms_apps::set_apps_ini_value(preg_replace('/^APP_/','',$config_key),$new_value))) {
			Ccms::addMsg('Failed to set config name: ' . $config_key . ' to "' . $new_value . '"');
			return 11;
			} // if
		} // if
	else if(preg_match('/^CMS_C_|^LM_C_|^PL_/',$config_key)) {
		if(is_null($old_value)) {
			if(!$old_value = Ccms::get_cms_config_value($config_key)) {
				$old_value = null;
				Ccms::addMsg('Failed to get config name: ' . $config_key . ' to "' . $new_value . '"');
				return 12;
				} // if
			} // if
		if((!empty($new_value)) && ($new_value != $old_value)) {
			if(!Ccms::set_cms_config_value($config_key,$new_value)) {
				Ccms::addMsg('Failed to set config name: ' . $config_key . ' to "' . $new_value . '"');
				return 13;
				} // if
			} // if
		} // if
	else {
		Ccms::addMsg('Cannot identify type of config name (i.e. CMS_S_|CMS_C_|LM_C_|PL_|APP_): ' . $config_key);
		return 2;
		} // else

	if(is_null($old_value)) {
		Ccms::addMsg('Config name: ' . $config_key . ' not found.');
		} // if
	else Ccms::addMsg('Config name: ' . $config_key . ' old value = "' . $old_value . '"','info');

	if((!empty($new_value)) && ($new_value != $old_value))
		Ccms::addMsg('Config name: ' . $config_key . ' new value = "' . $new_value . '"','success');
	return 0;
	} // get_set_config()

// eof
