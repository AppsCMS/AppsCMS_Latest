/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_drag_drop.js 2786 2022-08-31 05:40:44Z robert0609 $
 */

function cms_drag_start(event) {
	if(typeof app_ov_drag_start === 'function') {	// check for apps replacment
		return app_ov_drag_start(event);
		} // if
	var style = window.getComputedStyle(event.target, null);
	var str = (parseInt(style.getPropertyValue("left")) - event.clientX) + ',' + (parseInt(style.getPropertyValue("top")) - event.clientY) + ',' + event.target.id;
	event.dataTransfer.setData("Text", str);
} // drag_start()

function cms_drop(event) {
	if(typeof app_ov_drag === 'function') {	// check for apps replacment
		return app_ov_drag(event);
		} // if
	var offset = event.dataTransfer.getData("Text").split(',');
	var dm = document.getElementById(offset[2]);
	if (dm) {
		dm.style.left = (event.clientX + parseInt(offset[0], 10)) + 'px';
		dm.style.top = (event.clientY + parseInt(offset[1], 10)) + 'px';
		event.preventDefault();
		return false;
		} // if
	return true;
} // drop()

function cms_drag_over(event) {
	if(typeof app_ov_drag_over === 'function') {	// check for apps replacment
		return app_ov_drag_over(event);
		} // if
	event.preventDefault();
	return false;
} // drag_over()

function cms_remove_drag_events() {
	document.body.removeEventListener('ondragstart', cms_drag_start);
	document.body.removeEventListener('ondragover', cms_drag_over);
	document.body.removeEventListener('ondrop', cms_drop);
} // cms_remove_drag_events()

function cms_dragend_elem_restore(id,bound_id) {	// restore the save position of an element
	var elem = document.getElementById(id);
	if (!elem) return;

	// document.body.addEventListener('ondragover',cms_drag_over);
	// document.body.addEventListener('ondrop', cms_drop);

	elem.draggable = true;
	var name = 'CMS_dargend_' + id;
	var cpos = Ccms_cookie.get(name);
	if (!cpos) return;
	var lt = cpos.split(',');
	var left = lt[0];
	var top = lt[1];
	// elem.style.position = 'absolute';
	var npos = elem.getBoundingClientRect(); // now position

	var width = npos.right - npos.left;
	var w = window.innerWidth;
	if (left < 0)
	left = 0;
	else if (left > (w - (2 * width)))
	left = (w - (2 * width));

	var height = npos.bottom - npos.top;
	var h = window.innerHeight;
	if (top < 0)
	top = 0;
	else if (top > (h - (2 * height)))
	top = (h - (2 * height));

	if(bound_id) {	// keep in boundary box
		var bound = document.getElementById(bound_id);
		if (bound) {
			if(top < bound.offsetTop)
				top = bound.offsetTop + 2;
			if(left < bound.offsetLeft)
				left = bound.offsetLeft + 2;
			if(top > (bound.offsetTop + bound.offsetHeight - elem.clientHeight))
				top = (bound.offsetTop + bound.offsetHeight - elem.clientHeight) - 2;
			if(left > (bound.offsetLeft + bound.offsetWidth - elem.clientWidth))
				left = (bound.offsetLeft + bound.offsetWidth - elem.clientWidth) - 2;
			} // if
		} // if

	elem.style.top = top + 'px';
	elem.style.left = left + 'px';
	console.log(name,cpos);
} // cms_dragend_elem_restore()

function cms_dragend_elem_save(id,bound_id) {	// save the dragged end position of element
	var elem = document.getElementById(id);
	if (!elem) return;
	var npos = elem.getBoundingClientRect(); // now position

	if(bound_id) {	// keep in boundary box
		var bound = document.getElementById(bound_id);
		if (bound) {
			if(npos.top < bound.offsetTop)
				npos.top = bound.offsetTop + 2;
			if(npos.left < bound.offsetLeft)
				npos.left = bound.offsetLeft + 2;
			if(npos.top > (bound.offsetTop + bound.offsetHeight - elem.clientHeight))
				npos.top = (bound.offsetTop + bound.offsetHeight - elem.clientHeight) - 2;
			if(npos.left > (bound.offsetLeft + bound.offsetWidth - elem.clientWidth))
				npos.left = (bound.offsetLeft + bound.offsetWidth - elem.clientWidth) - 2;
			} // if
		} // if

	var cpos = npos.left + ',' + npos.top;
	var name = 'CMS_dargend_' + id;
	Ccms_cookie.set(name, cpos, 365);
	console.log(name,cpos);
} // cms_dragend_elem_save()

// EOF

