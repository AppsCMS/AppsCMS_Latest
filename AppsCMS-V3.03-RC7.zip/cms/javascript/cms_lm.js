/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_edit.js 2786 2022-08-31 05:40:44Z robert0609 $
 */

var last_get_lm_filtered_links_call = null;	// speed limiter

function get_lm_filtered_links_page() {
	if(last_get_lm_filtered_links_call != null) {	// clear it
		window.clearTimeout(last_get_lm_filtered_links_call);
		last_get_lm_filtered_links_call = null;
		} // if
	// restart if
	last_get_lm_filtered_links_call = window.setTimeout(
		function () {
			var keywords = document.forms["filter"]["keywords"].value;
			keywords = encodeURI(keywords);
			var body_url = 'cms_get_filtered_links_page&keywords=' + keywords;
			cms_ajax_body_page(body_url, 'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
			}, 600);
	} // get_lm_filtered_links_page()

function send_lm_section_states() {
	if(!lm_section_ids) return false;	// no ids
	// lm_section_ids should have the state of the sections
	var xmlhttp = false;
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
		} // if
	else {	// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	} // else
	if(!xmlhttp) return false;
	var url = 'cms/cms_ajax.php?ajax=lm_save_filtered_sections_state';
	xmlhttp.open("POST",url);
	xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
	var states = {
		lm_section_states: lm_section_ids,
		};
	xmlhttp.onreadystatechange = function () {	// dummy func to stop firefox bug dropping post data
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			var json = JSON.parse(xmlhttp.responseText);
			console.log(json);
			} // if
		};
	var post = JSON.stringify(states);
	xmlhttp.send(post);
	return true;
	} // send_lm_section_states()

function set_lm_open_links_button(open,id) {
	var id_btn = 'id_btn_lm_open_tabs_sect_links_' + id;	// open all btn
	var btn = document.getElementById(id_btn);
	if(!btn) return false;
	if(open) btn.style.display = '';
	else btn.style.display = 'none';
	return true;
	} // set_lm_open_links_button()

function lm_roll_down_sect_link(dv,sect_ids_tree) {
	dv.setAttribute('data-sect-state','down');
	//dv.style.maxHeight = '100vh';
	dv.style.display = 'block';
// don't play, looks like a compound error in FF
//		var height = dv.offsetHeight;
//		dv.style.height = (height + 0) + 'px';
//		var par = dv.parentElement;
//		if(par) {
//			var sp = par.getElementsByTagName('SPAN')[0];
//			if(sp) {
//				height = sp.offsetHeight;
//				sp.style.height = (height + 0) + 'px';
//				} // if
//			} // if
	} // lm_roll_down_sect_link()

var open_lm_lks_last_op = false;	// used to stop double event trigger
function toggle_lm_roll_sect_links(event,obj,id,sect_ids_tree) {
	if(open_lm_lks_last_op) {
		open_lm_lks_last_op = false;
		return false;
		} // if
	var id_dv = 'id_div_sect_links_' + id;	// toggle links div
	var dv = document.getElementById(id_dv);
	if(!dv) return false;

	event.stopPropagation();
	var btn = obj;
	if(obj.tagName != 'BUTTON') {
		var ch_id = 'id_btn_lm_roll_sect_links_' + id;
		var btns = obj.getElementsByTagName("BUTTON");
		for(var btnIdx in btns) {
			if(btns[btnIdx].id == ch_id) {
				btn = btns[btnIdx];
				break;
				} // if
			} // for
		} // if

	if(dv.getAttribute('data-sect-state') == 'up') {	// open if
		lm_roll_down_sect_link(dv,sect_ids_tree);
		btn.innerHTML = '<img src="cms/images/DbChevUp.gif" style="height: 12px;">';
		set_lm_open_links_button(true,id);
		} // if
	else {	// open it
		dv.setAttribute('data-sect-state','up');
		//dv.style.maxHeight = '0px';
		dv.style.display = 'none';
		btn.innerHTML = '<img src="cms/images/DbChevDn.gif" style="height: 12px;">';
		set_lm_open_links_button(false,id);
		} // else
	if(lm_section_ids) // keep track
		lm_section_ids[id]['state'] = dv.getAttribute('data-sect-state');
	return send_lm_section_states();
	} // toggle_lm_roll_sect_links()

function collapse_lm_sect_all() {
	if(!lm_section_ids) return;
	for (const [i,v] of Object.entries(lm_section_ids)) {
		var id = i;
		var id_dv = 'id_div_sect_links_' + id;
		var dv = document.getElementById(id_dv);
		if(!dv) continue;
		dv.setAttribute('data-sect-state','up');
		// dv.style.maxHeight = '0px';
		dv.style.display = 'none';
		var id_btn = 'id_btn_lm_roll_sect_links_' + id;
		var btn = document.getElementById(id_btn);
		btn.innerHTML = '<img src="cms/images/DbChevDn.gif" style="height: 12px;">';	// plus sign
		lm_section_ids[id]['state'] = dv.getAttribute('data-sect-state');
		set_lm_open_links_button(false,id);
		} // for
	return send_lm_section_states();
	} // collapse_lm_sect_all()

function expand_lm_sect_all() {
	if(!lm_section_ids) return;
	for (const [i,v] of Object.entries(lm_section_ids)) {
		var id = i;
		var id_dv = 'id_div_sect_links_' + id;
		var dv = document.getElementById(id_dv);
		if(!dv) continue;
		lm_roll_down_sect_link(dv);
		var id_btn = 'id_btn_lm_roll_sect_links_' + id;
		var btn = document.getElementById(id_btn);
		btn.innerHTML = '<img src="cms/images/DbChevUp.gif" style="height: 12px;">';
		lm_section_ids[id]['state'] = dv.getAttribute('data-sect-state');
		set_lm_open_links_button(true,id);
		} // for
	return send_lm_section_states();
	} // expand_lm_sect_all()

function open_lm_tabs_sect_links(event,obj,sect_id) {
	event.stopPropagation();
	open_lm_lks_last_op = true;
	if(!lm_section_links_urls) return false;
	if(lm_section_links_urls.length <= 0) return false;
	if(!lm_section_links_urls[sect_id]['links']) return false;
	var links = lm_section_links_urls[sect_id]['links'];
	var sect_name = lm_section_links_urls[sect_id]['name'];
	if(!links) return false;
	var lk_cnt = 0;
	for(const link_id in links) lk_cnt++;	//must be !!!
	if(!confirm('Section: ' + sect_name + "\n" + 'Open all ' + lk_cnt + ' URL links in tabs?')) return false
	for(const link_id in links) {
		var uri = links[link_id]['uri'];
		window.open(uri);
		} // for
	return true;
	} // open_lm_tabs_sect_links()



// EOF

