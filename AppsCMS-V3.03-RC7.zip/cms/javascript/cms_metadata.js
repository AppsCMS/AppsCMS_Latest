/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_metadata.js 2786 2022-08-31 05:40:44Z robert0609 $
 */

function Ccms_metadata() {

	// internels
	this.self = this;
	var last_send_call = null;
	var deb_ms = 2000;	// wait time before sending (a debounce)
	if((cmsMetadata_deb_ms) &&
		(cmsMetadata_deb_ms > 200))
		deb_ms = cmsMetadata_deb_ms;

	function empty (mixed_var) {	// from php.js lib
		var undef, key, i, len;
		var emptyValues = [undef, null, false, 0, "", "0"];
		for (i = 0, len = emptyValues.length; i < len; i++) {
			if (mixed_var === emptyValues[i]) {
				return true;
				} // if
			} // for
		if (typeof mixed_var === "object") {
			for (key in mixed_var) {
				// TODO: should we check for own properties only?
				//if (mixed_var.hasOwnProperty(key)) {
					return false;
				//	} // if
				} // for
			return true;
			} // if
		return false;
		} // empty()

	this.set_client_meta = function() {
		if(last_send_call != null) {	// clear it
			window.clearTimeout(last_send_call);
			last_send_call = null;
			} // if

		last_send_call = window.setTimeout(function() {

			try {
				var d = new Date();
				var n = navigator;
				// console.log(n);
				var isIE = (/*@cc_on!@*/false || !!document.documentMode);	// Internet Explorer 6-11
				var isVivaldi = !!/ Viv\/[0-9\.]+| Vivaldi\/[0-9\.]+/.test(n.userAgent); // Vivaldi 1.9
				var isOpera = ((!isVivaldi && !!window.opr && !!opr.addons) || !!window.opera || n.userAgent.indexOf(' OPR/') >= 0);	// Opera 8.0+
				var isChrome = (!isVivaldi && !isOpera && (!!/Google Inc/.test(n.vendor) && !!window.chrome));	// Chrome 1 - 79
//							var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) {
//								return p.toString() === "[object SafariRemoteNotification]";
//								})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));	// Safari 3.0+ "[object HTMLElementConstructor]"
				var isFirefox = (!isVivaldi && !isOpera && typeof InstallTrigger !== 'undefined');	// Firefox 1.0+
				var isSafari = (!isFirefox && /Safari\/[0-9]+/.test(n.userAgent));
				var clientMeta = {
					window_innerWidth: window.innerWidth,
					window_innerHeight: window.innerHeight,
					window_outerWidth: window.outerWidth,
					window_outerHeight: window.outerHeight,
					screen_width: screen.width,
					screen_height: screen.height,
					screen_colourDepth: screen.colorDepth,
					screen_pixelDepth: screen.pixelDepth,
					screen_availWidth: screen.availWidth,
					screen_availHeight: screen.availHeight,
					user_lang: (n.language || n.userLanguage),
					char_set: document.characterSet,
					timezone_minutes: d.getTimezoneOffset(),
					time_ms: d.getTime(),
					date: d.toJSON(),
					cookies_enabled: n.cookieEnabled,
					name: n.appName,
					code_name: n.appCodeName,
					platform: n.platform,
					product: n.product,
					vendor: n.vendor,
					agent: n.userAgent,
					version: n.appVersion,
					isIE5IE6: (window.XMLHttpRequest ? false:true),
					isOpera: isOpera,	// Opera 8.0+
					isFirefox: isFirefox,	// Firefox 1.0+
					isSafari: isSafari,	// Safari 3.0+ "[object HTMLElementConstructor]"
					isIE: isIE,	// Internet Explorer 6-11
					isEdge: (!(isIE || !!document.documentMode) && !!window.StyleMedia),	// Edge 20+
					isChrome: isChrome,	// Chrome 1 - 79
					isEdgeChromium: (isChrome && (n.userAgent.indexOf("Edg") != -1)),	// Edge (based on chromium) detection
					isVivaldi: isVivaldi, // Vivaldi 1.9
					isBlinkEng: ((isChrome || isOpera) && !!window.CSS),	// Blink engine detection
					};
				}
			catch (e) {
				var clientMeta = {
					error: 'Failed to read client metadata.',
					};
				// console.log(clientMeta);
				}
			Ccms_cookie.set_client_meta(clientMeta);

			var cleanClientMeta = {};
			for ( var k in clientMeta) {
				if(empty(clientMeta[k])) continue;
				cleanClientMeta[k] = clientMeta[k];
				} // for
			var jmeta = {
				clientMeta: cleanClientMeta,
				};

			var xmlhttp = false;
			if (window.XMLHttpRequest) {
				// code for IE7+, Firefox, Chrome, Opera, Safari
				xmlhttp = new XMLHttpRequest();
				} // if
			else {	// code for IE6, IE5
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} // else
			if(!xmlhttp) return;
			var bref = document.getElementById('cms_base_ref').href;
			var url = (bref ? bref:'') + 'cms/cms_ajax.php?ajax=cms_client_metadata';
			xmlhttp.open("POST",url);
			xmlhttp.setRequestHeader("Content-Type", "application/json");
			var post = JSON.stringify(jmeta);
			xmlhttp.send(post);
			},deb_ms);	// don't be hasty
		} // set_client_meta()

	} // Ccms_metadata

var cmsMetadata = new Ccms_metadata;

window.addEventListener("load",cmsMetadata.set_client_meta);	// get client metadata
window.addEventListener("scroll",cmsMetadata.set_client_meta);	// get client metadata
window.addEventListener("resize",cmsMetadata.set_client_meta);	// get client metadata


// EOF

