/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_body_funcs.js 2786 2022-08-31 05:40:44Z robert0609 $
 */


function cms_get_selected_ws_image() {
	var vv = document.getElementById('ws_image_list_id');
	var ls = document.getElementById('ws_image_selected_id');
	if(vv.selectedIndex > 0) {
		ls.value = vv.value;
		cms_copyToClipboard(vv.value);
		} // if
	else ls.value = '';
	} // cms_get_selected_ws_image()

function cms_get_selected_ws_link() {
	var vv = document.getElementById('ws_link_list_id');
	var ls = document.getElementById('ws_link_selected_id');
	if(vv.selectedIndex > 0) {
		ls.value = vv.value;
		cms_copyToClipboard(vv.value);
		} // if
	else ls.value = '';
	} // cms_get_selected_ws_link()

function cms_ajax_upload_image() {
	if(!cms_ajaxOps['cms_edit_ws_image_upload']) {
		// proto of function Ccms_ajaxOps(ajax_url_op,ajax_feedback_id,ajax_result_id,op_data,run_scripts) {	// class to hold the everything
		cms_ajaxOps['cms_edit_ws_image_upload'] = new Ccms_ajaxOps('cms_edit_ws_image_upload','uploading_image_id','ws_image_selector_id','',false);
		} // if
	// do ajax request
	var file_input = document.getElementById('ws_image_upload_id');
	var file_data = file_input.files[0]; // Getting the properties of file from file field
	var form_data = new FormData(); // Creating object of FormData class
	form_data.append("file", file_data) // Appending parameter named file with properties of file_field to form_data
	var res = cms_ajaxOps['cms_edit_ws_image_upload'].doAjaxRequest('',form_data);
	// not required while(cms_ajaxOps['cms_edit_ws_image_upload'].ajax_running) continue;	// wait
	file_input.value = '';	// reset input
	return res;
	} // cms_ajax_upload_image()

function cms_ajax_body_page(body_url,body_name_id) {
	if(body_name_id.length < 4) return;
	if(!cms_ajaxOps[body_name_id]) {
		// proto of function Ccms_ajaxOps(ajax_url_op,ajax_feedback_id,ajax_result_id,op_data,run_scripts) {	// class to hold the everything
		cms_ajaxOps[body_name_id] = new Ccms_ajaxOps(body_name_id,body_name_id,false);
		} // if
	// do ajax request
	var res = cms_ajaxOps[body_name_id].doAjaxRequest(body_url,'');
	return res;
	} // cms_ajax_body_page()

function cms_clear_form_to_empty(form_id) {
	var form = document.getElementById(form_id);
	if(!form) return false;
	form.reset();
	var elements = form.elements;
	for(i=0; i<elements.length; i++) {
		field_type = elements[i].type.toLowerCase();
		switch(field_type) {
		case "text":
		case "password":
		case "textarea":
		case "hidden":
			elements[i].value = "";
			break;
		case "number":
			elements[i].value = "0";
			break;
		case "radio":
		case "checkbox":
			if (elements[i].checked) {
				elements[i].checked = false;
				} // if
			break;
		case "select-one":
		case "select-multi":
			elements[i].selectedIndex = -1;
			break;
		default:
			break;
			} // switch
		} // for
	return form;
	} // cms_clear_form_to_empty()

function cms_validate_form_required(form_id) {
	var form = document.getElementById(form_id);
	if(!form) return false;
	var elements = form.elements;
	for(i=0; i<elements.length; i++) {
		var elem = elements[i];
		if((!(elem.getAttribute("readonly")) || elem.readonly) &&
			(!(elem.getAttribute("disabled")) || elem.disabled) &&
			((elem.getAttribute("pattern")) || (elem.getAttribute("required")))) { // should be validated

			field_type = elements[i].type.toLowerCase();
			switch(field_type) {
			case "text":
			case "password":
			case "textarea":
				if(elements[i].value.length == 0) return false;
				break;
			case "hidden":
				break;
			case "number":
				if(elements[i].value.length == 0) return false;
				break;
			case "radio":
			case "checkbox":
				break;
			case "select-one":
			case "select-multi":
				if(elements[i].selectedIndex <= 0) return false;
				break;
			default:
				break;
				} // switch
			} // if
		} // for
	return true;
	} // cms_validate_form_required()

	function cms_get_html_translation_table(table, quote_style) {
		//  discuss at: http://phpjs.org/functions/cms_get_html_translation_table/
		// original by: Philip Peterson
		//  revised by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
		// bugfixed by: noname
		// bugfixed by: Alex
		// bugfixed by: Marco
		// bugfixed by: madipta
		// bugfixed by: Brett Zamir (http://brett-zamir.me)
		// bugfixed by: T.Wild
		// improved by: KELAN
		// improved by: Brett Zamir (http://brett-zamir.me)
		//    input by: Frank Forte
		//    input by: Ratheous
		//        note: It has been decided that we're not going to add global
		//        note: dependencies to php.js, meaning the constants are not
		//        note: real constants, but strings instead. Integers are also supported if someone
		//        note: chooses to create the constants themselves.
		//   example 1: cms_get_html_translation_table('HTML_SPECIALCHARS');
		//   returns 1: {'"': '&quot;', '&': '&amp;', '<': '&lt;', '>': '&gt;'}

		var entities = {},
			hash_map = {},
			decimal = {};
		var constMappingTable = {},
			constMappingQuoteStyle = {};
		var useTable = {},
			useQuoteStyle = {};

		// Translate arguments
		constMappingTable[0] = 'HTML_SPECIALCHARS';
		constMappingTable[1] = 'HTML_ENTITIES';
		constMappingQuoteStyle[0] = 'ENT_NOQUOTES';
		constMappingQuoteStyle[2] = 'ENT_COMPAT';
		constMappingQuoteStyle[3] = 'ENT_QUOTES';

		useTable = !isNaN(table) ? constMappingTable[table] : table ? table.toUpperCase() : 'HTML_SPECIALCHARS';
		useQuoteStyle = !isNaN(quote_style) ? constMappingQuoteStyle[quote_style] : quote_style ? quote_style.toUpperCase() : 'ENT_COMPAT';

		if (useTable !== 'HTML_SPECIALCHARS' && useTable !== 'HTML_ENTITIES') {
			throw new Error('Table: ' + useTable + ' not supported');
		  // return false;
		}

		entities['38'] = '&amp;';
		if (useTable === 'HTML_ENTITIES') {
			entities['160'] = '&nbsp;';
			entities['161'] = '&iexcl;';
			entities['162'] = '&cent;';
			entities['163'] = '&pound;';
			entities['164'] = '&curren;';
			entities['165'] = '&yen;';
			entities['166'] = '&brvbar;';
			entities['167'] = '&sect;';
			entities['168'] = '&uml;';
			entities['169'] = '&copy;';
			entities['170'] = '&ordf;';
			entities['171'] = '&laquo;';
			entities['172'] = '&not;';
			entities['173'] = '&shy;';
			entities['174'] = '&reg;';
			entities['175'] = '&macr;';
			entities['176'] = '&deg;';
			entities['177'] = '&plusmn;';
			entities['178'] = '&sup2;';
			entities['179'] = '&sup3;';
			entities['180'] = '&acute;';
			entities['181'] = '&micro;';
			entities['182'] = '&para;';
			entities['183'] = '&middot;';
			entities['184'] = '&cedil;';
			entities['185'] = '&sup1;';
			entities['186'] = '&ordm;';
			entities['187'] = '&raquo;';
			entities['188'] = '&frac14;';
			entities['189'] = '&frac12;';
			entities['190'] = '&frac34;';
			entities['191'] = '&iquest;';
			entities['192'] = '&Agrave;';
			entities['193'] = '&Aacute;';
			entities['194'] = '&Acirc;';
			entities['195'] = '&Atilde;';
			entities['196'] = '&Auml;';
			entities['197'] = '&Aring;';
			entities['198'] = '&AElig;';
			entities['199'] = '&Ccedil;';
			entities['200'] = '&Egrave;';
			entities['201'] = '&Eacute;';
			entities['202'] = '&Ecirc;';
			entities['203'] = '&Euml;';
			entities['204'] = '&Igrave;';
			entities['205'] = '&Iacute;';
			entities['206'] = '&Icirc;';
			entities['207'] = '&Iuml;';
			entities['208'] = '&ETH;';
			entities['209'] = '&Ntilde;';
			entities['210'] = '&Ograve;';
			entities['211'] = '&Oacute;';
			entities['212'] = '&Ocirc;';
			entities['213'] = '&Otilde;';
			entities['214'] = '&Ouml;';
			entities['215'] = '&times;';
			entities['216'] = '&Oslash;';
			entities['217'] = '&Ugrave;';
			entities['218'] = '&Uacute;';
			entities['219'] = '&Ucirc;';
			entities['220'] = '&Uuml;';
			entities['221'] = '&Yacute;';
			entities['222'] = '&THORN;';
			entities['223'] = '&szlig;';
			entities['224'] = '&agrave;';
			entities['225'] = '&aacute;';
			entities['226'] = '&acirc;';
			entities['227'] = '&atilde;';
			entities['228'] = '&auml;';
			entities['229'] = '&aring;';
			entities['230'] = '&aelig;';
			entities['231'] = '&ccedil;';
			entities['232'] = '&egrave;';
			entities['233'] = '&eacute;';
			entities['234'] = '&ecirc;';
			entities['235'] = '&euml;';
			entities['236'] = '&igrave;';
			entities['237'] = '&iacute;';
			entities['238'] = '&icirc;';
			entities['239'] = '&iuml;';
			entities['240'] = '&eth;';
			entities['241'] = '&ntilde;';
			entities['242'] = '&ograve;';
			entities['243'] = '&oacute;';
			entities['244'] = '&ocirc;';
			entities['245'] = '&otilde;';
			entities['246'] = '&ouml;';
			entities['247'] = '&divide;';
			entities['248'] = '&oslash;';
			entities['249'] = '&ugrave;';
			entities['250'] = '&uacute;';
			entities['251'] = '&ucirc;';
			entities['252'] = '&uuml;';
			entities['253'] = '&yacute;';
			entities['254'] = '&thorn;';
			entities['255'] = '&yuml;';
			} // if

		if (useQuoteStyle !== 'ENT_NOQUOTES') {
			entities['34'] = '&quot;';
			} // if
		if (useQuoteStyle === 'ENT_QUOTES') {
			entities['39'] = '&#39;';
			} // if
		entities['60'] = '&lt;';
		entities['62'] = '&gt;';

		// ascii decimals to real symbols
		for (decimal in entities) {
			if (entities.hasOwnProperty(decimal)) {
				hash_map[String.fromCharCode(decimal)] = entities[decimal];
				} // if
			} // for

		return hash_map;
		} // cms_get_html_translation_table()

	function cms_html_entity_decode(string, quote_style) {
		//  discuss at: http://phpjs.org/functions/cms_html_entity_decode/
		// original by: john (http://www.jd-tech.net)
		//    input by: ger
		//    input by: Ratheous
		//    input by: Nick Kolosov (http://sammy.ru)
		// improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
		// improved by: marc andreu
		//  revised by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
		//  revised by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
		// bugfixed by: Onno Marsman
		// bugfixed by: Brett Zamir (http://brett-zamir.me)
		// bugfixed by: Fox
		//  depends on: cms_get_html_translation_table
		//   example 1: cms_html_entity_decode('Kevin &amp; van Zonneveld');
		//   returns 1: 'Kevin & van Zonneveld'
		//   example 2: cms_html_entity_decode('&amp;lt;');
		//   returns 2: '&lt;'

		var hash_map = {},
			symbol = '',
			tmp_str = '',
			entity = '';
		tmp_str = string.toString();

		if (false === (hash_map = this.cms_get_html_translation_table('HTML_ENTITIES', quote_style))) {
			return false;
			} // if

		// fix &amp; problem
		// http://phpjs.org/functions/cms_get_html_translation_table:416#comment_97660
		delete(hash_map['&']);
		hash_map['&'] = '&amp;';

		for (symbol in hash_map) {
			entity = hash_map[symbol];
			tmp_str = tmp_str.split(entity).join(symbol);
			} // for

		tmp_str = tmp_str.split('&#039;').join("'");

		return tmp_str;
		} // cms_html_entity_decode()

	async function cms_copyToClipboard(text) {
		if(!text) return false;
		if (window.clipboardData && clipboardData.setData) {	// ie
			clipboardData.setData('text/plain', text);
			return true;
			} // if
		/* Others */
		try {
			var dummy = document.createElement("textarea");
			// to avoid breaking orgain page when copying more words
			// cant copy when adding below this code
			// dummy.style.display = 'none'
			document.body.appendChild(dummy);
			//Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
			dummy.value = text;
			dummy.select();
			document.execCommand("copy");
			document.body.removeChild(dummy);
			console.log('Copied text to clipboard.',text);
			return true;
			}
		catch(e) {
			console.log('Failed to copy text to clipboard.',e);
			}
		return false;
		} // cms_copyToClipboard()

	function cms_copyElemToClipboard(event,obj) {
		if(obj.value) return cms_copyToClipboard(obj.value);
		if(obj.innerText) return cms_copyToClipboard(obj.innerText);
		return false;	// @TODO others
		} // cms_copyElemToClipboard()

