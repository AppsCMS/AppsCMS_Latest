<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_footer.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

if(!CMS_S_FOOTER_BOOL) return;

if((CMS_C_CUSTOM_FOOTER) && (is_readable(PAGE_FOOTER_FS_INC))) {
	Ccms::page_start_comment(PAGE_FOOTER_INC);
	include PAGE_FOOTER_FS_INC;
	Ccms::page_end_comment(PAGE_FOOTER_INC);
	return;
	} // if

Ccms::page_start_comment(__FILE__);
?>

	<table class="page_bottom">
		<caption>Page footer</caption>
		<tr class="page_bottom">
			<td>&nbsp;</td>
			<td class="page_bottom">
				<?= Ccms::get_disclaimer_text() ?>
			</td>
<?php
		$smtxt = Ccms::get_social_media('footer_left');
		if(!empty($smtxt)) echo '<td class="page_top" style="text-align: left;" rowspan="2">' . $smtxt . '</td>' . PHP_EOL;
?>
			<td class="page_bottom" style="text-align: center;">
				<?= Ccms::get_copyright_text() ?>
			</td>
<?php
		$smtxt = Ccms::get_social_media('footer_center');
		if(!empty($smtxt)) echo '<td class="page_top" style="text-align: left;" rowspan="2">' . $smtxt . '</td>' . PHP_EOL;
?>
<?php
		$smtxt = Ccms::get_social_media('footer_right');
		if(!empty($smtxt)) echo '<td class="page_top" style="text-align: right;" rowspan="2">' . $smtxt . '</td>' . PHP_EOL;
?>
			<td class="page_bottom" style="min-width: 25%; text-align: right;">
				<?= Ccms::get_about_text_link() ?>
			</td>
			<td>&nbsp;</td>
		</tr>
		<tr class="page_bottom">
			<td>&nbsp;</td>
			<td class="page_bottom" style="min-width: 25%; text-align: left; white-space: nowrap;">
				<?php Ccms::show_page_legals(); 	?>
			</td>
			<td class="page_bottom" style="text-align: center;">
				<?= Ccms::show_stats() ?>
			</td>
			<td class="page_bottom" style="min-width: 25%; text-align: right; white-space: nowrap;">
				<?= Ccms::get_show_counter_text() ?>
			</td>
			<td>&nbsp;</td>
		</tr>
	</table>
<?php

echo Ccms::get_cookie_banner();

Ccms::page_end_comment(__FILE__);

