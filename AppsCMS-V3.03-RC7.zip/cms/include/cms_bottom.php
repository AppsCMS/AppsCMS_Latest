<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_bottom.php 2795 2022-09-10 09:37:50Z robert0609 $
 */

	Ccms::get_code_errors();
	Ccms::saveMsgs();
	Ccms_ops::do_site_sess_close();

