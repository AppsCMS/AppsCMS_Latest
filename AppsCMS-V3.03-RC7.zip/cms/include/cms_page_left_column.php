<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_left_column.php 2827 2022-10-05 13:45:55Z robert0609 $
 */

// echo Ccms::chk_ob_buffer();

if(!Ccms::show_left_column()) return;
	Ccms::page_start_comment(__FILE__);
?>
<!--	<div>-->
		<table class="left_container" style="min-height: 100%">
			<caption>Left Column</caption>
<?php
		$smtxt = Ccms::get_social_media('left_column_top');
		if(!empty($smtxt)) echo '<tr class="left_container"><td class="left_container">' . $smtxt . '</td></tr>' . PHP_EOL;


			$flgs = Ccms::get_column_layout('left_column','left_container');

?>
<?php		if(!Ccms::show_right_column()) { ?>
<?php			if((!$flgs['admin_menu_flg']) && 
					(Ccms_base::is_group_manager())) { ?>
			<tr class="left_container">
				<td class="left_container">
<?php					echo Ccms::get_admin_menu('left'); ?>
				</td>
			</tr>
<?php				} // if ?>
<?php			} // if ?>
<?php		if((!$flgs['bodies_menu_flg']) && (!$flgs['bodies_items_flg']) && (Ccms::get_body_cnt() > 0)) { ?>
			<tr class="left_container">
				<td class="left_container">
<?php					echo Ccms_apps::get_apps_menus('left_column'); 	?>
				</td>
			</tr>
<?php			} //if ?>
<?php		if(!Ccms::show_right_column()) { ?>
<?php			if((!$flgs['tool_menu_flg']) && (!$flgs['tools_items_flg']) &&
				(Ccms::get_tool_cnt() > 0)) { ?>
			<tr class="left_container">
				<td class="left_container">
<?php					echo Ccms::get_tools_menu('left'); ?>
				</td>
			</tr>
<?php				} //if ?>
<?php			} // if ?>
<?php
		$smtxt = Ccms::get_social_media('left_column_bottom');
		if(!empty($smtxt)) echo '<tr class="left_container"><td class="left_container">' . $smtxt . '</td></tr>' . PHP_EOL;
?>
			<tr class="left_container">
				<td class="left_container" style="height: 100%;">&nbsp;</td>
			</tr>
		</table>
<!--	</div>-->
<?php
	Ccms::page_end_comment(__FILE__);

	