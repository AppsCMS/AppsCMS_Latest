<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_header.php 2909 2022-10-24 07:34:08Z robert0609 $
 */

if((CMS_C_CUSTOM_HEADER) && (is_readable(PAGE_HEADER_FS_INC))) {
	Ccms::page_start_comment(PAGE_HEADER_INC);
	include PAGE_HEADER_FS_INC;
	$atxt = Ccms::get_header_admin_tools_pdb_text();
	if(!empty($atxt)) echo '<br>' . $atxt . PHP_EOL;
	Ccms::page_end_comment(PAGE_HEADER_INC);
	return;
	} // if

Ccms::page_start_comment(__FILE__);
?>
	<table class="page_top" style="height: <?= CMS_S_HEADER_HEIGHT ?>;">
		<caption>Page header</caption>
		<tr class="page_top">
			<td class="page_top" style="text-align: left;">&nbsp;</td>
			<td style="text-align: left;"><?= Ccms::get_home_link() ?></td>		
		
<?php	$atxt = Ccms::get_header_admin_tools_pdb_text(); 
		if(!empty($atxt)) {		?>
			<td class="page_top" style="text-align: left;">
				<?= $atxt ?>
			</td>
<?php		} // if ?>

<?php	$smtxt = Ccms::get_social_media('header_left');
		if(!empty($smtxt)) {	?>
			<td class="page_top no_print" style="text-align: left;">
				<?= $smtxt ?>
			</td>
<?php		} // if ?>
			
			<td class="page_top" style="text-align: center;">
				<div class="top_title">
					<?= Ccms::get_header_bar_title() ?>
				</div>
			</td>
					
<?php	// sort where the login and social media sit
		$smtxt = Ccms::get_social_media('header_right');
		$txt = '';
		if((CMS_C_SHOW_LOGIN_LINK) &&	// login shown (otherwise use direct URL)
			(Ccms_auth::is_login_allowed()) &&	// can login
			(!preg_match('/login|logout/',self::get_app_action() . self::get_cms_action()))) {	// app or cms already logging in
			// do a simple login
			$txt = Ccms_auth::get_login_logout();
			} // if
		if(!empty($txt)) {
			if(!empty($smtxt)) { ?>
					
			<td class="page_top no_print" style="text-align: right;">
				<?= $smtxt ?> 
			</td>
<?php				} // if ?>
			<td class="page_top no_print" style="text-align: right; font-size: smaller;">
				<div class="top_auth">
					<?= $txt ?>
				</div>
			</td>
<?php			} // if
		else if(!empty($smtxt)) { ?>
			<td class="page_top no_print" style="text-align: right; width: 25%;">
				<?= $smtxt ?>
			</td>
<?php		} // if ?>
			<td class="page_top no_print" style="float: right;">&nbsp;</td>
		</tr>
	</table>
<?php

Ccms::page_end_comment(__FILE__);
