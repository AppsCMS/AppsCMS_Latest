<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_body.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php
$body_cnt = Ccms::get_body_cnt();
$filename = '';
$body = '';
if($body_cnt > 0) {
	if(!$body = Ccms::get_body()) {	// should not happen
		Ccms::log_msg('ERROR: Could not find a page body.');
		return;
		} // if
	} // if
if(Ccms::is_full_body_view()) {	// should not get gere
	Ccms::output_body_core($body);
	return;
	} // if
if(Ccms::is_iframe_body_view()) {
	$url = Ccms::get_body_uri($body,false,true);
	$title = Ccms::get_body_title($body);
	Ccms::output_iframe_site_text($url,$title);
	return;
	} // if
?>

<table class="page_body">
	<?php if($body_cnt > 0) echo '<caption>' . $body['cms_body_name'] . ' body</caption>' . PHP_EOL ?>
	<?php if((Ccms::$cms_body_default_msgs) && (Ccms::getMsgsCount())) { ?>

	<tr class="page_body_msgs">
		<td class="page_body_msgs">
			<?= Ccms::getMsgsTable() ?>
		</td>
	</tr>
	<?php } //if ?>
<?php
if($body_cnt > 0) {
?>

	<tr class="page_body">
		<td class="page_body">
<?php
		Ccms::output_body_core($body);
?>
		</td>
	</tr>
<?php	} // if ?>
<?php if((Ccms::$cms_body_default_msgs) && (Ccms::getMsgsCount())) { ?>
	<tr class="page_body_msgs">
		<td class="page_body_msgs">
			<?= Ccms::getMsgsTable() ?>
		</td>
	</tr>
<?php } //if ?>
</table>

<?php Ccms::page_end_comment(__FILE__) ?>
