<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_tools.php 2891 2022-10-18 04:58:45Z robert0609 $
 */

$cCMS_C = new Ccms_config();

$cms_tool_id = 0;
$cms_tool_op = '';
$cms_tool_clone = false;
$cms_tool_clone_from_id = Ccms::get_or_post("cms_tool_clone_from_id");
$cms_tool_clone_insert = ((Ccms::get_or_post("cms_tool_clone") == 'true') ? true:false);
$cms_tool_clone_dir = Ccms::get_or_post('cms_tool_clone_dir');

Ccms_export::export_table('cms_tools');
if(Ccms::get_cms_action() == 'cms_edit_tools') { // a bit of caution
	$tool = false;
	Ccms_content_cache::reset_caches(false);
	$cms_tool_id = Ccms::get_or_post('tool_edit_id');

	$cms_tool_installed = Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_installed',"cms_tool_id = " . (int)$cms_tool_id . "");
	if($cms_tool_installed) {	// if its installed limit change allowed
		$not_allowed_chgs = explode(',',
			'cms_tool_name,cms_tool_version,cms_tool_name,cms_tool_description,cms_tool_title,' .
			'cms_tool_icon_url,cms_tool_image_url,cms_tool_terms_url,cms_tool_terms_upfirst,cms_tool_acknowledgment_url,' .
			'cms_tool_licence_url,cms_tool_release_notes_url,cms_tool_readme_url.' .
			'cms_tool_new_page,cms_tool_include,cms_tool_ssl, cms_tool_login_required, cms_tool_add_name2url,' .
			'cms_tool_readme_url,cms_tool_url,cms_tool_debug_only,cms_tool_comments,cms_tool_package_excludes');
		} // if
	else $not_allowed_chgs = array();

	if(Ccms::get_or_post('submit') == 'cancel') {
		$cms_tool_op = '';
		} // if
	else if((Ccms::is_get_or_post('delete')) &&
		((Ccms::is_get_or_post('tool_edit_id')) || (Ccms::is_get_or_post('cms_tool_id')))) {
		$cms_tool_op = 'delete';
		$cms_tool_id = (int)(Ccms::is_get_or_post('cms_tool_id') ? Ccms::get_or_post('cms_tool_id'):Ccms::get_or_post('tool_edit_id'));

		$sql_query = "SELECT  cms_tool_name,cms_tool_enabled" .
					" FROM  cms_tools WHERE  cms_tool_id = '" . (int)$cms_tool_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($tool = Ccms::$cDBcms->fetch_array($result))) {
			foreach($tool as $k => &$v) $$k = $v;
			} // if
		} // else if
	else if((Ccms::is_get_or_post('confirm_delete')) && (Ccms::is_get_or_post('cms_tool_id'))) {
		$cms_tool_op = 'confirm_delete';
		$cms_tool_id = (int)Ccms::get_or_post('cms_tool_id');

		$sql_query = "DELETE FROM  cms_tools WHERE  cms_tool_id = '" . (int)$cms_tool_id . "'";
		Ccms::$cDBcms->query($sql_query);
		new Ccms_xml_sitemap();	// do sitemap
		$cms_tool_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('add')) {
		$cols = Ccms::$cDBcms->get_columns_list('cms_tools',true);
		foreach($cols as $c => $v) $$c = $v;

		$sql_query = "SELECT MAX(cms_tool_order) AS max_cms_tool_order FROM  cms_tools";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			($row = Ccms::$cDBcms->fetch_array($result))) {
			$cms_tool_order = $row['max_cms_tool_order'] + 100;	// next app
			} // if
		else Ccms::$cDBcms->free_result($result);

		$cms_tool_op = 'add';
		$cms_tool_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('insert')) && (Ccms::is_get_or_post('cms_tool_id'))) {
		$cms_tool_op = 'insert';
		} // else if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('cms_tool_id'))) {
		$cms_tool_op = 'save';
		} // else if
	else if((Ccms::is_get_or_post('clone')) && (Ccms::is_get_or_post('cms_tool_id'))) {
		$cms_tool_op = 'clone';
		$cms_tool_clone = true;
		} // else if
	else if((Ccms::is_get_or_post('package')) && ((int)$cms_tool_id > 0)) {
		$cms_tool_op = 'package';
		$cms_tool_name = Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_name',"cms_tool_id = " . $cms_tool_id);
		} // else if
	else if((Ccms::get_or_post('build_package') == 'package') &&
		((int)Ccms::get_or_post ('package_id') > 0) &&
		(Ccms::get_or_post('build') != 'done')) {
		$cms_tool_op = 'build_package';
		$cms_tool_id = (int)Ccms::get_or_post ('package_id');
		$cms_tool_name = Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_name',"cms_tool_id = " . $cms_tool_id);
		} // else if
	else if((Ccms::is_get_or_post('install')) && (Ccms_auth::is_admin_user())) {
		$cms_tool_op = 'install';
		} // else if
	else if((Ccms::is_get_or_post('install_package')) && (Ccms_auth::is_admin_user())) {
		$cms_tool_op = 'install_package';
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('export'))) {
		$cms_user_op = 'export';
		$cms_user_id = 0;
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('import'))) {
		$cms_user_op = 'import';
		$cms_user_id = 0;
		Ccms_export::import_table('cms_tools');
		} // else if
	else if((CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$cms_tool_op = 'reloadDB';
		$cms_tool_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_tool_op = 'cancel';
		$cms_tool_id = 0;
		} // else if
	else if(($cms_tool_id = (int)Ccms::get_or_post('tool_edit_id')) > 0) {
		$cms_tool_op = 'edit';

		$sql_query = "SELECT  cms_tool_name,cms_tool_url, cms_tool_order, cms_tool_version" .
			", cms_tool_name, cms_tool_description, cms_tool_title, cms_tool_debug_only" .
			", cms_tool_icon_url, cms_tool_image_url, cms_tool_terms_url,cms_tool_terms_upfirst, cms_tool_acknowledgment_url, cms_tool_licence_url, cms_tool_release_notes_url,cms_tool_readme_url" .
			", cms_tool_new_page, cms_tool_include, cms_tool_enabled, cms_tool_ssl, cms_tool_add_name2url, cms_tool_group_ids, cms_tool_comments, cms_tool_package_excludes" .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_tool_added','cms_tool_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_tool_updated','cms_tool_updated') .
			" FROM  cms_tools WHERE  cms_tool_id = '" . (int)$cms_tool_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($tool = Ccms::$cDBcms->fetch_array($result))) {
			foreach($tool as $k => &$v) $$k = $v;
			Ccms::$cDBcms->free_result($result);
			} // if
		else { // not found
			$cms_tool_id = 0;
			$cms_tool_op = '';
			$cms_tool_added = '';
			$cms_tool_updated = '';
			} // else
		} // if

	if(($cms_tool_op == 'save') || ($cms_tool_op == 'clone') || ($cms_tool_op == 'insert')) {
		// do it once
		$cms_tool_id = (int)Ccms::get_or_post('cms_tool_id');
		$cms_tool_url = rawurldecode(Ccms::get_or_post('cms_tool_url'));
		$cms_tool_name = html_entity_decode(Ccms::get_or_post('cms_tool_name'));
		$cms_tool_description = html_entity_decode(Ccms::get_or_post('cms_tool_description'));
		$cms_tool_title = html_entity_decode(Ccms::get_or_post('cms_tool_title'));
		$cms_tool_order = (int)Ccms::get_or_post('cms_tool_order');
		$cms_tool_version = Ccms::get_or_post('cms_tool_version');

		$cms_tool_group_ids = implode(':',Ccms::get_or_post('cms_tool_group_ids'));
		$cms_tool_enabled = Ccms::get_or_post_checkbox('cms_tool_enabled');
		$cms_tool_ssl = Ccms::get_or_post_checkbox('cms_tool_ssl');
		$cms_tool_add_name2url = Ccms::get_or_post_checkbox('cms_tool_add_name2url');
		$cms_tool_include = Ccms::get_or_post_checkbox('cms_tool_include');
		$cms_tool_new_page = Ccms::get_or_post_checkbox('cms_tool_new_page');
		$cms_tool_debug_only = Ccms::get_or_post_checkbox('cms_tool_debug_only');

		$cms_tool_icon_url = $cCMS_C->get_image('cms_tool_icon_url', Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_icon_url','cms_tool_id = ' . (int)$cms_tool_id),ETC_WS_ICONS_DIR);
		$cms_tool_image_url = $cCMS_C->get_image('cms_tool_image_url', Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_image_url','cms_tool_id = ' . (int)$cms_tool_id),ETC_WS_IMAGES_DIR);
		$cms_tool_terms_url = Ccms::get_or_post('cms_tool_terms_url');
		$cms_tool_terms_upfirst = Ccms::get_or_post_checkbox('cms_tool_terms_upfirst');
		$cms_tool_acknowledgment_url = Ccms::get_or_post('cms_tool_acknowledgment_url');
		$cms_tool_licence_url = Ccms::get_or_post('cms_tool_licence_url');
		$cms_tool_readme_url = Ccms::get_or_post('cms_tool_readme_url');
		$cms_tool_release_notes_url = Ccms::get_or_post('cms_tool_release_notes_url');
		$cms_tool_comments = Ccms::get_or_post('cms_tool_comments');
		$cms_tool_package_excludes = Ccms::get_or_post('cms_tool_package_excludes');

		$cms_tool_added = html_entity_decode(Ccms::get_or_post('cms_tool_added'));
		$cms_tool_updated = html_entity_decode(Ccms::get_or_post('cms_tool_updated'));

		if((!$cms_tool_clone_insert) && (!$cms_tool_installed)) {
			Ccms_DB_checks::is_tool_name_ok($cms_tool_name, $cms_tool_op);
			Ccms_DB_checks::is_tool_url_ok($cms_tool_url, $cms_tool_op);
			} // if

		if(($cms_tool_clone_insert) && (!Ccms::getMsgsCount('error'))) {	// update it
			if((int)$cms_tool_clone_from_id > 0) {
				Ccms_DB_checks::is_tool_name_ok($cms_tool_name, $cms_tool_op);
				if(strlen($cms_tool_clone_dir) < LM_C_MIN_NAME_LEN) {
					Ccms::addMsg('Clone tool directory is to short.');
					} // if
				else {
					$tool_url = preg_replace('/^.*\//','',$cms_tool_url);
					$old_tool_dirpath = Ccms::clean_path(LOCAL_FS_TOOLS_DIR . preg_replace('/\/[^\/]*$/','',$cms_tool_url));
					$old_tool_dir = substr($old_tool_dirpath,strlen(LOCAL_FS_TOOLS_DIR));
					$new_tool_dirpath = Ccms::clean_path(LOCAL_FS_TOOLS_DIR . $cms_tool_clone_dir);
					$new_tool_dir = substr($new_tool_dirpath,strlen(LOCAL_FS_TOOLS_DIR));
					$new_tool_url = Ccms::clean_path($new_tool_dir . '/' . $tool_url);
					Ccms_DB_checks::is_tool_url_ok($new_tool_url, $cms_tool_op);
					} // else

				if(Ccms::getMsgsCount('error')) {
					$cms_tool_op = false;
					} // if
				else if(!Ccms::recurse_copy($old_tool_dirpath,$new_tool_dirpath)) {	// copy it
					Ccms::addMsg('Failed to copy tool directory from "' . $old_tool_dirpath . '" to "' . $new_tool_dirpath . '".');
					$cms_tool_op = false;
					} // if
				else {
					Ccms::addMsg('Copied tool directory from "' . $old_tool_dirpath . '" to "' . $new_tool_dirpath . '".','success');
					$cms_tool_url = $new_tool_url;
					$cms_tool_clone_insert = false;	// done
					} // else
				} // if
			} // if

		if(!Ccms::getMsgsCount('error')) {	// update it
			if(($cms_tool_op == 'save') || ($cms_tool_op == 'insert')) {
				$names = array(
					'cms_tool_name','cms_tool_url','cms_tool_description','cms_tool_title','cms_tool_order',
					'cms_tool_version','cms_tool_group_ids','cms_tool_enabled','cms_tool_ssl',
					'cms_tool_add_name2url','cms_tool_include','cms_tool_new_page','cms_tool_debug_only',
					'cms_tool_icon_url','cms_tool_image_url','cms_tool_terms_url','cms_tool_terms_upfirst','cms_tool_acknowledgment_url',
					'cms_tool_licence_url','cms_tool_readme_url','cms_tool_release_notes_url','cms_tool_comments','cms_tool_package_excludes');
				$fields = array();
				foreach($names as $name) {
					if(!in_array($name,$not_allowed_chgs)) $fields[$name] = $$name;
					} // foreach

				if(($cms_tool_op == 'insert') &&
					(!Ccms::$cDBcms->perform('cms_tools',$fields,'insert',''))) {
					Ccms::addMsg('Tool insert, ' . $cms_tool_name . " failed");
					} // if
				else if(($cms_tool_op == 'save') &&
					(!Ccms::$cDBcms->perform('cms_tools',$fields,'update',"cms_tool_id = " . (int)$cms_tool_id . ""))) {
					Ccms::addMsg('Tool update, ' . $cms_tool_name . " failed");
					} // if
				else if(!$cms_tool_clone_insert) {
					// Ccms_base::unset_cms_sess_var('cms_tool_id');
					Ccms_export::export_table('cms_tools');
					Ccms::backupOnSave();
					Ccms::addMsg('Saved tool config.','success');
					} // else
				new Ccms_xml_sitemap();	// do sitemap
				$cms_tool_id = 0;
				$cms_tool_op = '';
				} // if
			} // if
		if((($cms_tool_op == 'clone') || ($cms_tool_clone_insert)) &&
			(((int)$cms_tool_clone_from_id > 0) || ((int)$cms_tool_id > 0))) {
			$cms_tool_clone_from_id = (((int)$cms_tool_clone_from_id > 0) ? $cms_tool_clone_from_id:$cms_tool_id);
			$cms_tool_clone = true;	// retry !!
			$cms_tool_op = 'insert';
			$cms_tool_id = 0;
			Ccms::addMsg('Cloning local tool "' . $cms_tool_name . '".','info');
			} // if
		} // if
	} // if
$cnt = Ccms::$cDBcms->get_row_count_in_table('cms_tools');

$icon_paths = array(LOCAL_WS_TOOLS_ICONS_DIR,ETC_WS_ICONS_DIR);
$image_paths = array(LOCAL_WS_TOOLS_IMAGES_DIR,ETC_WS_IMAGES_DIR);

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php if(($cms_tool_op == 'package') && ((int)$cms_tool_id > 0)) { ?>
<form name="edit_tool" action="<?= $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_tools' ?>" method="post" enctype="multipart/form-data">
<?= Ccms_search::get_form_search_hidden_inputs() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Local Tool Packager</h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
<?php
		$cToolInstall = new Ccms_tool_install('package',$cms_tool_id,false);
?>
 		</td>
	</tr>
</table>
</form>
<?php
		return;
		} // if

	if((Ccms_tool_install::is_tool_pkg_ops_ok()) && ($cms_tool_op == 'install')) {

		$package_file = Ccms_tool_install::get_package_upload_file();
?>

<form name="edit_tool" action="<?= $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_tools' ?>" method="post" enctype="multipart/form-data">
<?= Ccms_search::get_form_search_hidden_inputs() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Local Tool Installer</h1>
		</th>
	</tr>
<?php if((Ccms_tool_install::is_tool_pkg_ops_ok()) && (!$package_file)) { ?>
	<tr class="page_config">
		<th class="page_config">
			Select Local Tool Package to Install.
			<input type="hidden" name="cms_tool_id" value="0"/>
			<input type="hidden" name="install" value="install"/>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<label>
				Select Package Zip File:
				<input type="file"
					class="page_config"
					accept=".zip"
					name="packageToUpload"
					id="packageToUpload"
					onchange="javascript:document.getElementById('packageUpload').disabled = false;"
					>
				<button type="submit"
					class="page_config"
					title="Check/Install Package"
					name="submit"
					value="install_package"
					id="packageUpload"
					DISABLED
					>Install Package</button>
				<input type="submit"
					class="page_config"
					name="submit"
					value="cancel"
					>
			</label>
 		</td>
	</tr>
<?php	} // if
	else if(Ccms_tool_install::is_tool_pkg_ops_ok()) { ?>
	<tr class="page_config">
		<th class="page_config">
			Install Local Tool Package.
			<input type="hidden" name="cms_tool_id" value="0"/>
			<input type="hidden" name="install_package" value="install_package"/>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
<?php
		$cToolInstall = new Ccms_tool_install('install',0,$package_file);
?>
 		</td>
	</tr>
<?php	} // else ?>
</table>
</form>

<?php
		return;
		} // if
?>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Tools Config</h1>
		</th>
	</tr>
	<?php if((Ccms_tool_install::is_tool_pkg_ops_ok()) && ($cms_tool_op == 'build_package') && ((int)$cms_tool_id > 0)) { ?>
	<tr class="page_config"><th class="page_config">Package Local Tool - <?= $cms_tool_name ?></th></tr>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Building package. Download will follow. Click
			<button type="button" onclick="window.location.href='index.php?cms_action=cms_edit_tools&build=done';">Close</button>
			to return to tools page.
			<?php
				$cPackage = new Ccms_tool_install('build_package',$cms_tool_id);
				$cms_tool_op = '';
			?>
		</td>
	</tr>
	<?php } // if ?>
	<?php if($cms_tool_op == 'install_package') { ?>
	<tr class="page_config"><th class="page_config">Install Body / Application from Package</th></tr>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php $cPackage = new Ccms_tool_install('install_package') ?>
		</td>
	</tr>
	<?php } // if ?>
	<?php if($cms_tool_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php Ccms::$cDBcms->installDatabase('cms_tools',true ,true) ?>
		</td>
	</tr>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<?php } // if ?>
	<form name="edit_tool" action="<?= $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_tools' ?>" method="post" enctype="multipart/form-data">
	<?= Ccms_search::get_form_search_hidden_inputs() ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Select tool name:&nbsp;
			<?=  Ccms::gen_tool_selection_list('tool_edit_id',$cms_tool_id,'id="prim_id" size="1" onchange="javascript:setConfigButtons();"') ?>
			<?php if($cnt > 0) { ?>
			&nbsp;&nbsp;
			<button id="b_edit_id" name="edit" value="edit" type="submit" onclick="Ccms_cursor.setWait();">Edit</button>
			&nbsp;&nbsp;
			<button id="b_delete_id" name="delete" value="delete" type="submit" onclick="Ccms_cursor.setWait();">Delete</button>
			<?php	} //if ?>
			&nbsp;&nbsp;
			<button name="add" value="add" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			&nbsp;&nbsp;
			<button name="install" value="install" type="submit" onclick="Ccms_cursor.setWait();" title="Install application package.">Install</button>
			<?php if((Ccms_auth::is_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
			&nbsp;&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise tools table in database." onClick="return confirm_check('Clear and re-initialise tools table in database?')">Reload</button>
			<?php	} // if ?>
			<?= Ccms_export::get_table_form_text('cms_tools') ?>
			<?php Ccms::get_return2search_link() ?>
			<span id="working_id">&nbsp;</span>
			<script type="text/javascript">

				function confirm_check(txt) {
					if(confirm(txt)) {
						document.getElementById('working_id').innerHTML = '<?= Ccms_msgs::make_message_text('submiting input.', 'working') ?>';
						Ccms_cursor.setWait();
						cms_sleep(2000);	// allow img to load
						return true;
						} // if
					return false;
					} // confirm_check()

				function setConfigButtons() {
					var sel = document.getElementById('prim_id');
					if(!sel) return;
					if(sel.selectedIndex > 0) {
						document.getElementById('b_edit_id').disabled = false;
						document.getElementById('b_delete_id').disabled = false;
					} else {
						document.getElementById('b_edit_id').disabled = true;
						document.getElementById('b_delete_id').disabled = true;
					} // else
					} // setBodyConfigButtons()
				setConfigButtons();	// initial
			</script>
		</td>
	</tr>

	<?php
	if((($cms_tool_op == 'edit') || ($cms_tool_op == 'save') ||
		($cms_tool_op == 'add') || ($cms_tool_op == 'insert')) &&
		(isset($cms_tool_id))) {
		$row = 0;
	?>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<tr class="page_config">
		<th class="page_config">
			<?php if($cms_tool_id == 0) {
				echo 'Add Tool' . ($cms_tool_clone ? ' Clone':'');
				} // if
			else {
				echo 'Edit Tool' .
					'&nbsp;&nbsp;<span class="page_config">(Added:&nbsp;' . $cms_tool_added .
					'&nbsp;&nbsp;Updated:&nbsp;' . $cms_tool_updated . ')</span>';
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_tool_name))
					Ccms::get_return2search_link(true);
				} // else
			?>

			<input type="hidden" name="cms_tool_id" value="<?= $cms_tool_id ?>"/>
			<input type="hidden" name="cms_tool_name_old" value="<?= htmlentities($cms_tool_name) ?>"/>
			<input type="hidden" name="cms_tool_added" value="<?= htmlentities($cms_tool_added) ?>"/>
			<input type="hidden" name="cms_tool_updated" value="<?= htmlentities($cms_tool_updated) ?>"/>
<?php if ($cms_tool_clone) { ?>
			<input type="hidden" name="cms_tool_url" value="<?= $cms_tool_url ?>"/>
			<input type="hidden" name="cms_tool_clone" value="true"/>
			<input type="hidden" name="cms_tool_clone_from_id" value="<?= $cms_tool_clone_from_id ?>"/>
<?php	} // if ?>
		</th>
	</tr>

	<tr class="page_config" style="position: sticky; top: 0px; background-color: ivory;">
		<td class="page_config">
			<?php if($cms_tool_id == 0) { ?>
			<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
		<?php if(!$cms_tool_installed) { ?>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
		<?php	} // if ?>
			<?php if((Ccms_tool_install::is_tool_pkg_ops_ok()) && (!$cms_tool_installed)) { ?>
			&nbsp;&nbsp;
			<button name="package" value="package" type="submit" title="Create local tool package for - <?= $cms_tool_name ?>.">Package</button>
			<?php	} // if ?>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>

	<tr>
		<td>
			<table class="page_config page_config_edit">
<?php if($cms_tool_installed) { ?>
				<tr class="page_config">
					<th class="page_config">Installed Tool:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Local tool is installed from a package with only minimum changes allowed.','info') ?>
					</td>
				</tr>
<?php	} // if ?>
<?php if($cms_tool_clone) { ?>
				<tr class="page_config">
					<th class="page_config">Cloning Local Tool:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Make changes to the cloned tool of "' . $cms_tool_name . '" to ensure uniqueness.<br>And set a new tool directory.','info') ?>
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Tool Sub Directory:</th>
					<td class="page_config">
						<input type="text" name="cms_tool_clone_dir" size="40" value="<?= $cms_tool_clone_dir ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Unique local tool directory name under &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot;. Minimum of <?= LM_C_MIN_NAME_LEN ?> characters.
						<br>NOTE: only one directory level allowed.
					</td>
				</tr>
<?php	} // if ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Name:</th>
					<td class="page_config" style="min-width: 320px;" <?= ($cms_tool_installed ? ' title="Installed tool package (limited changes allowed)."':'') ?>>
						<input type="text" name="cms_tool_name" <?= (in_array('cms_tool_name',$not_allowed_chgs) ? ' DISABLED':'') ?> size="40" value="<?= $cms_tool_name ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Unique tool name. Appears on page as a tool heading. Minimum of <?= LM_C_MIN_NAME_LEN ?> characters.
					</td>
				</tr>
<?php if((!$cms_tool_clone) && !in_array('cms_tool_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Tool URL:</th>
					<td class="page_config">
						<?=  Ccms::get_tools_dir_selection('cms_tool_url',$cms_tool_url) ?>
					</td>
					<td class="page_config">
						The &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot; directory URI / index file index for the local tool.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_description',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Description:</th>
					<td class="page_config">
						<input type="text" name="cms_tool_description" size="80" value="<?= $cms_tool_description ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Tool description (optional), an admin note.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_title',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Title:</th>
					<td class="page_config">
						<input type="text" name="cms_tool_title" size="80" value="<?= $cms_tool_title ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Tool title (optional), appears when mouse is hovered over tool name.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_version',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Version:</th>
					<td class="page_config">
						<input type="text" name="cms_tool_version" size="80" value="<?= $cms_tool_version ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Tool version (optional), for information only.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_package_excludes',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Excluded:</th>
					<td class="page_config">
						<input type="text" name="cms_tool_package_excludes" size="80" value="<?= $cms_tool_package_excludes ?>" autocapitalize="off">
					</td>
					<td class="page_config">
						Package builder exclusions (not seen by user).
						List separated by comas of excluded directories (builder does not descend into the directory).
						And files are matched directly.
						Used to stop data directories and files from being included in the package.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_comments',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<textarea name="cms_tool_comments" cols="45" rows="2"><?= $cms_tool_comments ?></textarea>
					</td>
					<td class="page_config">
						<?= Ccms::getAdminCommentHint('edit_tools',$cms_tool_name) ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_group_ids',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th width ="150px" class="page_config" valign="top">Select group/s:</th>
					<td class="page_config">
						<?=  Ccms::gen_group_selection_list('cms_tool_group_ids[]',$cms_tool_group_ids,10, 'multiple') ?>
					</td>
					<td class="page_config">
						Select the groups the tool can appear under.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_order',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Display Order:</th>
					<td class="page_config">
						<input type="number" name="cms_tool_order" size="5" value="<?= $cms_tool_order ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Sorting order of tool. Used to control the order of the tool in this section. Low numbers at the top of the page, ascending down the page.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_enabled',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Enabled:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_enabled"<?= ((($cms_tool_enabled == 1) || ($cms_tool_op == 'add')) ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to enable tool, uncheck to disable tool.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_debug_only',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Debug:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_debug_only"<?= ($cms_tool_debug_only == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to allow content only in debug mode, uncheck to use otherwise.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_include',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Include Tool:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_include"<?= ($cms_tool_include == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to include the tool code directly into the page
						(can use the theme settings directly)
						instead of using an iframe (as an independant web page).
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_ssl',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">SSL:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_ssl"<?= ($cms_tool_ssl == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to use only SSL encryption, uncheck to use the default.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_new_page',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">New Tab:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_new_page"<?= ($cms_tool_new_page == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to open URL in a new browser tab or window, uncheck to disable new tab or window.
						<br>
						NOTE: If the local tool produces a frame set, it should be shown on a new tab.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_add_name2url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Add Name to URL:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_add_name2url"<?= ($cms_tool_add_name2url == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						 Check to add tool name to URL.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_icon_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Icon URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('cms_tool_icon_url', $cms_tool_icon_url, $icon_paths,'',false) ?>
					</td>
					<td class="page_config">
						An icon or small logo used in navigation bars and menu.
						On small devices the icon replaces text.
						Stored in the &quot;<?= implode(' and ', $icon_paths) ?>&quot; directories.
						<br>
						<?= Ccms::get_tool_icon_uri($tool,'(no icon set)') ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_image_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Image URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('cms_tool_image_url', $cms_tool_image_url, $image_paths,'',false) ?>
					</td>
					<td class="page_config">
						An image associated with the local tool.
						Can be used with the local tool for special purposes.
						Stored in the &quot;<?= implode(' and ',$image_paths) ?>&quot; directories.
						<br>
						<?= Ccms::get_tool_image_uri($tool,'(no image set)') ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_readme_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Readme:</th>
					<td class="page_config">
						<?=  Ccms::get_tools_dir_selection('cms_tool_readme_url',$cms_tool_readme_url,' - Select Readme File - ',$cms_tool_url) ?>
					</td>
					<td class="page_config">
						A readme URI for the local tool.
						It is a URI to a file in <?= LOCAL_WS_TOOLS_DIR ?> directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_release_notes_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Release Notes:</th>
					<td class="page_config">
						<?=  Ccms::get_tools_dir_selection('cms_tool_release_notes_url',$cms_tool_release_notes_url,' - Select Release Notes File - ',$cms_tool_url) ?>
					</td>
					<td class="page_config">
						A release notes URI for the local tool.
						It is a URI to a file in <?= LOCAL_WS_TOOLS_DIR ?> directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_terms_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Agreed to Terms:</th>
					<td class="page_config">
						<?=  Ccms::get_tools_dir_selection('cms_tool_terms_url',$cms_tool_terms_url,' - Select Terms of Use File - ',$cms_tool_url) ?>
					</td>
					<td class="page_config">
						 A Terms of Use or Terms and Conditions URI for the use of the local tool.
						 It is a URI to a file in <?= LOCAL_WS_TOOLS_DIR ?> directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_terms_upfirst',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Terms of Use:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_tool_terms_upfirst"<?= ($cms_tool_terms_upfirst == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Show the terms and conditions as a EULA on tool first use.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_acknowledgment_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Acknowledgment:</th>
					<td class="page_config">
						<?=  Ccms::get_tools_dir_selection('cms_tool_acknowledgment_url',$cms_tool_acknowledgment_url,' - Select Acknowledgement File - ',$cms_tool_url) ?>
					</td>
					<td class="page_config">
						 An acknowledgment URI for third party content used in the local tool.
						 It is a URI to a file in <?= LOCAL_WS_TOOLS_DIR ?> directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_tool_licence_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Licence:</th>
					<td class="page_config">
						<?=  Ccms::get_tools_dir_selection('cms_tool_licence_url',$cms_tool_licence_url,' - Select Licence File - ',$cms_tool_url) ?>
					</td>
					<td class="page_config">
						A licence URI for content used in the local tool.
						It is a URI to a file in <?= LOCAL_WS_TOOLS_DIR ?> directory.
					</td>
				</tr>
<?php	} // if ?>

			</table>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: right;">
			<?php if($cms_tool_id == 0) { ?>
			<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
		<?php if(!$cms_tool_installed) { ?>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
		<?php	} // if ?>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>

	<?php } else if(($cms_tool_op == 'delete') && (isset($cms_tool_id)) && ($cms_tool_id > 0)) { ?>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<tr class="page_config"><th class="page_config">Delete Tool - <?= $cms_tool_name ?></th></tr>
	<input type="hidden" name="cms_tool_id" value="<?= $cms_tool_id ?>"/>
	<input type="hidden" name="cms_tool_name" value="<?= htmlentities($cms_tool_name) ?>"/>
	<tr class="page_config">
		<td class="page_config">
			Please confirm.
			&nbsp;&nbsp;
			<button name="confirm_delete" value="confirm_delete" type="submit" onclick="Ccms_cursor.setWait();">Confirm Delete</button>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>
	<?php }  ?>
	</form>
	<tr class="page_config"><th class="page_config">Summary</th></tr>
	<tr class="page_config">
		<td class="page_config">
			Tools can appear in panel drop boxes or on the navigation bar (if the bar is enabled).
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<table class="page_config">
				<tr class="page_config" style="position: sticky; top: 0px; background-color: ivory;">
					<th class="page_config" title="Tool name and options.">Name</th>
					<th class="page_config"></th>

					<th width="70px" class="page_config" title="Tool index file or URL in the <?= LOCAL_WS_TOOLS_DIR ?> directory.">URL</th>

					<th width="30px" class="page_config" title="Nav bar and menu icon.\nUsed on small devices instead of text labels.\nStored in the <?= ETC_WS_ICONS_DIR ?> directory.">Icon</th>
					<th width="40px" class="page_config" title="Local tool general image.\nStored in the <?= ETC_WS_IMAGES_DIR ?> directory.">Image</th>
					<th width="70px" class="page_config" title="Local tool readme.\nNOTE: Can be an entire or external URL or a file reference in <?= APPS_WS_DIR ?>">Read Me</th>
					<th width="70px" class="page_config" title="Local tool release notes.\nNOTE: Can be an entire or external URL or a file reference in <?= APPS_WS_DIR ?>">Release Notes</th>
					<th width="70px" class="page_config" title="Local tool terms and conditions.\nNOTE: Can be an entire or external URL or a file reference in <?= APPS_WS_DIR ?>">Terms</th>
					<th width="70px" class="page_config" title="Local tool acknowledgments.\nNOTE: Can be an entire or external URL or a file reference in <?= APPS_WS_DIR ?>">Acknow&rsquo;</th>
					<th width="70px" class="page_config" title="Local tool licence.\nNOTE: Can be an entire or external URL or a file reference in <?= APPS_WS_DIR ?>">Licence</th>

					<th class="page_config">Groups</th>
					<th class="page_config">Description</th>
					<th class="page_config" title="Admin comments.">Comments</th>
				</tr>
	<?php
		$sql_query = "SELECT  cms_tool_id,cms_tool_name,cms_tool_title,cms_tool_version,cms_tool_installed,cms_tool_url,cms_tool_description,cms_tool_enabled, cms_tool_ssl" .
			", cms_tool_add_name2url,cms_tool_group_ids,cms_tool_new_page,cms_tool_include,cms_tool_order, cms_tool_debug_only" .
			", cms_tool_icon_url, cms_tool_image_url, cms_tool_terms_url, cms_tool_terms_upfirst, cms_tool_acknowledgment_url" .
			", cms_tool_licence_url,cms_tool_readme_url,cms_tool_release_notes_url, cms_tool_comments, cms_tool_package_excludes" .
			" FROM  cms_tools ORDER BY  cms_tool_order,cms_tool_id";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$row = 0;
			while($tool = Ccms::$cDBcms->fetch_array($result)) {
				echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">';

				echo '<td class="page_config" style="text-align: left; white-space: nowrap;">';
				if(Ccms::is_debug()) echo 'ID: ' . $tool['cms_tool_id'] . ', ';
				echo '<a class="multi" href="index.php?cms_action=cms_edit_tools&tool_edit_id=' . $tool['cms_tool_id'] . '" title="' . strip_tags($tool['cms_tool_title']) . '"><b>' . $tool['cms_tool_name'] . '</b></a>';
				echo '<br><span class="multi">Enabled: ' . ($tool['cms_tool_enabled'] ? 'yes':'no') . ' </span>';
				echo '<br><span class="multi" title="Display order">Order: ' . $tool['cms_tool_order'] . '</span>';
				echo '<br><span class="multi" title="Checked: only used in debug mode, unchecked otherwise used.">Debug: ' . ($tool['cms_tool_debug_only'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="' . ($tool['cms_tool_installed'] ? 'Installed tool package, limited changes allowed.':'') . '">Can Change: ' . (!$tool['cms_tool_installed'] ? 'yes':'no') . '</span>';
				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left;  white-space: nowrap; border-right: 1px solid grey;">';
				echo '<span class="multi" title="Tool version">Version: ' . (empty($tool['cms_tool_version']) ? '(empty)':$tool['cms_tool_version']) . '</span>';
				echo '<br><span class="multi" title="Include code or iframe">Include: ' . ($tool['cms_tool_include'] ? 'include':'iframe') . '</span>';
				echo '<br><span class="multi" title="Use SSL encryption">SSL: ' . ($tool['cms_tool_ssl'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="In a new tab/window">New: ' . ($tool['cms_tool_new_page'] ? 'yes':'no') . '</span>';
				echo '<br><span class="multi" title="Add tool name to URL">Add Name: ' . ($tool['cms_tool_add_name2url'] ? 'yes':'no') . '</span>';

				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">';
				echo '<span class="multi" title="File in ' . LOCAL_TOOLS_DIR . '">' . $tool['cms_tool_url'] . ' </span>';
				if(Ccms::is_debug()) {
					if(!file_exists(LOCAL_FS_TOOLS_DIR . $tool['cms_tool_url'])) {
						echo '<br>' . Ccms::make_message_text('Missing "' . $tool['cms_tool_url'] . '".','error');
						} // if
					else {
						echo '<br>' . Ccms::make_message_text('URL Ok.','info');
						} // if
					} // if
				echo '</td>' . PHP_EOL;

				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_tool_icon_uri($tool,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_tool_image_uri($tool,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_tool_readme_uri($tool,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_tool_release_notes_uri($tool,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' .
						Ccms::get_tool_terms_uri($tool,'(empty)') .
						($tool['cms_tool_terms_upfirst'] ? '<br>(Show on first use)':'') .
						' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_tool_acknowledgment_uri($tool,'(empty)') . ' </td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . Ccms::get_tool_licence_uri($tool,'(empty)') . ' </td>' . PHP_EOL;

				echo '<td class="page_config">' . Ccms::get_group_ids_text($tool['cms_tool_group_ids'],false) . '</td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left; border-right: 1px solid grey;">' . $tool['cms_tool_description'] . '</td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left;">' . $tool['cms_tool_comments'] . '</td>' . PHP_EOL;
				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			Ccms::$cDBcms->free_result($result);
			} // if
		else echo '<tr class="page_config"><td class="page_config" style="text-align: left" colspan="5"><span class="cms_msg_info">(No tools setup in "' . LOCAL_WS_TOOLS_DIR . '")</span></td></tr>' . PHP_EOL;
		?>
			</table>
		</td>
	</tr>
</table>

<?php
Ccms::page_end_comment(__FILE__);

