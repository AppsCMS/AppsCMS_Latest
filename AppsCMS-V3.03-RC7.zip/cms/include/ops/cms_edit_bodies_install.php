<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_bodies_install.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

//$cms_apps_types = Ccms_DB_checks::get_apps_types_configs();
//
if(!Ccms_app_install::is_app_pkg_ops_ok()) return;

Ccms::page_start_comment(__FILE__);

$package_file = Ccms_app_install::get_package_upload_file();

?>

<form name="edit_body" action="<?= $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_bodies' ?>" method="post" enctype="multipart/form-data">
<?= Ccms_search::get_form_search_hidden_inputs() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Page Bodies / Apps Installer</h1>
		</th>
	</tr>
<?php if(!$package_file) { ?>
	<tr class="page_config">
		<th class="page_config">
			Select Application Package to Install.
			<input type="hidden" name="cms_body_id" value="0"/>
			<input type="hidden" name="install" value="install"/>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<label>
				Select Package Zip File:
				<input type="file"
					class="page_config"
					accept=".zip"
					name="packageToUpload"
					id="packageToUpload"
					onchange="javascript:document.getElementById('packageUpload').disabled = false;"
					>
				<button type="submit"
					class="page_config"
					title="Check/Install Package"
					name="submit"
					value="install_package"
					id="packageUpload"
					DISABLED
					>Install Package</button>
				<input type="submit"
					class="page_config"
					name="submit"
					value="cancel"
					>
			</label>
 		</td>
	</tr>
<?php	} // if
	else { ?>
	<tr class="page_config">
		<th class="page_config">
			Install Application Package.
			<input type="hidden" name="cms_body_id" value="0"/>
			<input type="hidden" name="install_package" value="install_package"/>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
<?php
		$cAppInstall = new Ccms_app_install('install',0,$package_file);
?>
 		</td>
	</tr>
<?php	} // else ?>
</table>
</form>

<?php
Ccms::page_end_comment(__FILE__);
