<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_bodies.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

$cms_apps_types = Ccms_DB_checks::get_apps_types_configs();
$readonly_apps = false;
if(Ccms::is_apps_readonly()) {
	$readonly_apps = true;
	Ccms::addMsg("Applications are read only.",'warn');
	} // if

function can_cron($cms_body_type) {
	global $cms_apps_types;
	$can_cron = false;
	if((!isset($cms_apps_types[$cms_body_type]['cron'])) ||		// new
		($cms_apps_types[$cms_body_type]['cron'])) // edit
		$can_cron = true;
	return $can_cron;
	} // can_cron()

function make_new_body_text($file = false,$input = '') {
	$text = '';
	if(empty($file)) return '';
	if(preg_match('/\.php$/i',$file)) {	// assume php
		$text .= '<?= Ccms::page_start_comment(__FILE__,false); ?>' . PHP_EOL . PHP_EOL;
		} // if
	$text .= (!empty($input) ? $input:"<p>Add page body code or text here.</p>") . PHP_EOL . PHP_EOL;
	if(preg_match('/\.php$/i',$file)) {
		$text .= '<?= Ccms::page_end_comment(__FILE__,false); ?>' . PHP_EOL . PHP_EOL;
		} // if
	return $text;
} // make_new_body_text()

$cCMS_C = new Ccms_config();
if(Ccms::$cms_page_info['html_wysiwyg_allow']) {
	global $cWYSIWYG;
	$cWYSIWYG = Ccms_wysiwyg::get_wysiwyg_class();
	} // if

$cms_body_id = 0;
$cms_body_op = '';
$cms_body_clone = false;
$cms_body_clone_from_id = Ccms::get_or_post("cms_body_clone_from_id");
$cms_body_clone_insert = ((Ccms::get_or_post("cms_body_clone") == 'true') ? true:false);
$cms_body_prefix = Ccms::get_or_post('cms_body_prefix');

Ccms_export::export_table('cms_bodies');
if(Ccms::get_cms_action() == 'cms_edit_bodies') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	$cms_body_id = Ccms::get_or_post('body_edit_id');
	$edit_col_names = array(
		'cms_body_name','cms_body_app_key','cms_body_virtual_name','cms_body_lang','cms_body_version','cms_body_file','cms_body_meta_description',
		'cms_body_meta_keywords','cms_body_title','cms_body_order','cms_body_group_ids',
		'cms_body_default','cms_body_nomenu','cms_body_login_page', 'cms_body_login_required', 'cms_body_enabled','cms_body_cached',
		'cms_body_debug_only','cms_body_default_msgs','cms_body_full_view','cms_body_iframe_view','cms_body_ssl','cms_body_manual_url',
		'cms_body_icon_url','cms_body_image_url','cms_body_terms_url','cms_body_release_notes_url',
		'cms_body_readme_url','cms_body_acknowledgment_url','cms_body_licence_url',
		'cms_body_description','cms_body_H1','cms_body_H1_title','cms_body_purpose','cms_body_info1','cms_body_info2','cms_body_terms_upfirst',
		'cms_body_crontab_enable','cms_body_crontab_time','cms_body_crontab_job','cms_body_comments','cms_body_package_excludes',
		'cms_body_dir','cms_body_type');
	$body_urls= array('cms_body_manual_url','cms_body_icon_url','cms_body_image_url','cms_body_terms_url',
		'cms_body_release_notes_url','cms_body_readme_url','cms_body_acknowledgment_url','cms_body_licence_url');

	$is_link = false;	// init
	$cms_body_installed = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_installed',"cms_body_id = " . (int)$cms_body_id . "");
	if($cms_body_installed) {	// if its installed limit change allowed
		$not_allowed_chgs = explode(',',
			'cms_body_version,cms_body_name,cms_body_app_key,cms_body_virtual_name,cms_body_lang,cms_body_dir,cms_body_type,cms_body_nomenu,' .
			'cms_body_ssl,cms_body_meta_keywords,cms_body_meta_description,cms_body_title,' .
			'cms_body_debug_only,cms_body_default_msgs,cms_body_description,' .
			'cms_body_H1,cms_body_H1_title,cms_body_purpose,cms_body_info1,cms_body_info2,' .
			'cms_body_icon_url,cms_body_image_url,cms_body_manual_url,cms_body_terms_url,cms_body_terms_upfirst,cms_body_release_notes_url,' .
			'cms_body_readme_url,cms_body_acknowledgment_url,cms_body_licence_url,' .
			'cms_body_file,cms_body_cached,cms_body_full_view,cms_body_iframe_view,' .
			'cms_body_crontab_enable,cms_body_crontab_time,cms_body_crontab_job');
		} // if
	else if($readonly_apps) {	// inside a readonly squash fs
		$not_allowed_chgs = explode(',',
			'cms_body_version,cms_body_name,cms_body_lang,cms_body_dir,cms_body_type,cms_body_file');
		} // else if
	else $not_allowed_chgs = array();
	$allowed_chgs = array();

	$body = false;
	if(Ccms::get_or_post('submit') == 'cancel') {
		$cms_body_op = '';
		} // if
	else if((Ccms::is_get_or_post('delete')) &&
		((Ccms::is_get_or_post('body_edit_id')) || (Ccms::is_get_or_post('cms_body_id')))) {
		$cms_body_op = 'delete';
		$cms_body_id = (int)(Ccms::is_get_or_post('cms_body_id') ? Ccms::get_or_post('cms_body_id'):Ccms::get_or_post('body_edit_id'));

		$sql_query = "SELECT  cms_body_name,cms_body_app_key,cms_body_virtual_name,cms_body_lang,cms_body_dir,cms_body_file,cms_body_enabled" .
					" FROM  cms_bodies WHERE  cms_body_id = '" . (int)$cms_body_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($body = Ccms::$cDBcms->fetch_array($result))) {
			foreach($body as $k => &$v) $$k = $v;
			} // if
		} // else if
	else if((Ccms::is_get_or_post('confirm_delete')) && (Ccms::is_get_or_post('cms_body_id'))) {
		$cms_body_op = 'confirm_delete';
		$cms_body_id = (int)Ccms::get_or_post('cms_body_id');
		$cms_body_delete_only = Ccms::get_or_post_checkbox('cms_body_delete_only');
		$cms_body_name = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_name',"cms_body_id = " . $cms_body_id);
		$cms_body_app_key = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_app_key',"cms_body_id = " . $cms_body_id);
		if(Ccms_app_install::uninstall_application($cms_body_id,$cms_body_delete_only)) {
			Ccms::addMsg('Deleted app page body file and DB entry only for "' . $cms_body_name . '"' .
				($cms_body_delete_only ? ', shared apps dir remains intact.':', including the apps dir'),'success');
			} // if
		else {
			Ccms::addMsg('Failed to deleted app "' . $cms_body_name . '".','warn');
			} // else
		new Ccms_xml_sitemap();	// do sitemap
		$cms_body_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('add')) {
		$cols = Ccms::$cDBcms->get_columns_list('cms_bodies',true);
		foreach($cols as $c => $v) $$c = $v;
		if(!LM_C_LINKS_MANAGER_ENABLE) {
			$sql_query = "SELECT cms_body_name,cms_body_default,cms_body_enabled" .
						" FROM  cms_bodies WHERE cms_body_default = 1 AND cms_body_nomenu < 1";
			if((!$result = Ccms::$cDBcms->query($sql_query)) ||
				(Ccms::$cDBcms->num_rows($result) < 1)) {
				$cms_body_default = 1;	// first page
				} // if
			else Ccms::$cDBcms->free_result($result);
			} // if

		$sql_query = "SELECT MAX(cms_body_order) AS max_cms_body_order FROM  cms_bodies";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			($row = Ccms::$cDBcms->fetch_array($result))) {
			$cms_body_order = $row['max_cms_body_order'] + 100;	// next app
			} // if
		else Ccms::$cDBcms->free_result($result);

		$cms_body_login_page = 0;	// DONT add as login page
		$cms_body_op = 'add';
		$cms_body_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('insert')) && (Ccms::is_get_or_post('cms_body_id'))) {
		$cms_body_op = 'insert';
		} // else if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('cms_body_id'))) {
		$cms_body_op = 'save';
		} // else if
	else if((Ccms::is_get_or_post('clone')) && (Ccms::is_get_or_post('cms_body_id'))) {
		$cms_body_op = 'clone';
		$cms_body_clone = true;
		$cms_body_clone_from_id = Ccms::get_or_post("cms_body_clone_from_id");
		if(empty($cms_body_clone_from_id)) $cms_body_clone_from_id = Ccms::get_or_post("cms_body_id");
		if((int)$cms_body_clone_from_id > 0) {
			$cms_body_clone_insert = true;	// ((Ccms::get_or_post("cms_body_clone") == 'true') ? true:false);
			$sql_query = "SELECT cms_body_id," . implode(',',$edit_col_names) .
				", " . Ccms::$cDBcms->get_db_sql_localtime('cms_body_added','cms_body_added') .
				", " . Ccms::$cDBcms->get_db_sql_localtime('cms_body_updated','cms_body_updated') .
				" FROM  cms_bodies WHERE  cms_body_id = '" . (int)$cms_body_clone_from_id . "'";
			if(($result = Ccms::$cDBcms->query($sql_query)) &&
				(Ccms::$cDBcms->num_rows($result) > 0) &&
				($body = Ccms::$cDBcms->fetch_array($result))) {
				foreach($body as $k => &$v) {
					if(!in_array($k,$not_allowed_chgs)) $allowed_chgs[] = $k;
					$$k = $v;
					} // foreach
				Ccms::$cDBcms->free_result($result);
				$cms_body_id = 0;
				} // if
			} // if
		else { // not found
			$cms_body_id = 0;
			$cms_body_op = '';
			$cms_body_added = '';
			$cms_body_updated = '';
			} // else
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_body_op = 'cancel';
		$cms_body_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('package')) && ((int)$cms_body_id > 0)) {
		$cms_body_op = 'package';
		$cms_body_name = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_name',"cms_body_id = " . $cms_body_id);
		} // else if
	else if((Ccms::get_or_post('build_package') == 'package') &&
		((int)Ccms::get_or_post ('package_id') > 0) &&
		(Ccms::get_or_post('build') != 'done')) {
		$cms_body_op = 'build_package';
		$cms_body_id = (int)Ccms::get_or_post ('package_id');
		$cms_body_name = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_name',"cms_body_id = " . $cms_body_id);
		} // else if
	else if((Ccms::is_get_or_post('install')) && (Ccms_auth::is_admin_user())) {
		$cms_body_op = 'install';
		} // else if
	else if((Ccms::is_get_or_post('install_package')) && (Ccms_auth::is_admin_user())) {
		$cms_body_op = 'install_package';
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('export'))) {
		$cms_user_op = 'export';
		$cms_user_id = 0;
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('import'))) {
		$cms_user_op = 'import';
		$cms_user_id = 0;
		Ccms_export::import_table('cms_bodies');
		} // else if
	else if((CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$cms_body_op = 'reloadDB';
		$cms_body_id = 0;
		} // else if
	else if(($cms_body_id !== false) &&
		( ((Ccms::is_get_or_post('edit')) && (Ccms::is_get_or_post('body_edit_id'))) ||
			(Ccms::is_get_or_post('body_edit_id')) ) ) {
		if(!is_numeric($cms_body_id)) {	// probably the name
			$name = $cms_body_id;
			$cms_body_id = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_id',"cms_body_name = '" . $name . "'");
			if((int)$cms_body_id <= 0) {
				Ccms::addMsg('Failed to find "' . $name . '" body.');
				return;
				} // if
			} // if
		$cms_body_op = 'edit';

		$sql_query = "SELECT cms_body_id," . implode(',',$edit_col_names) .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_body_added','cms_body_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_body_updated','cms_body_updated') .
			" FROM  cms_bodies WHERE  cms_body_id = '" . (int)$cms_body_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($body = Ccms::$cDBcms->fetch_array($result))) {
			foreach($body as $k => &$v) {
				// if(!in_array($k,$not_allowed_chgs)) $allowed_chgs[] = $k;
				$$k = $v;
				} // foreach
			Ccms::$cDBcms->free_result($result);
			} // if
		else { // not found
			$cms_body_id = 0;
			$cms_body_op = '';
			$cms_body_added = '';
			$cms_body_updated = '';
			} // else
		} // else if

	if(($cms_body_op == 'save') || ($cms_body_op == 'insert')) {
		// do it once
		$cms_body_id = (int)Ccms::get_or_post('cms_body_id');
		$cms_body_version = Ccms::get_or_post('cms_body_version');
		$cms_body_name = $cCMS_C->get_sanitized_text('cms_body_name');
		$cms_body_app_key = Ccms_base::format_app_key($cCMS_C->get_sanitized_text('cms_body_app_key'));
		$cms_body_virtual_name = Ccms_base::format_virtual_name($cCMS_C->get_sanitized_text('cms_body_virtual_name'));
		$cms_body_virtual_name = strtolower(preg_replace('/[^\w]|-/', '_', $cms_body_virtual_name));
		$cms_body_lang = Ccms::get_or_post('cms_body_lang');

		$cms_body_type = Ccms::get_or_post('cms_body_type');
		if(!$cms_body_type) $cms_body_type = Ccms_DB_checks::APP_TYPE_NONE;

		$cms_body_file = $cCMS_C->get_sanitized_text('cms_body_file');
		$cms_body_dir = $cCMS_C->get_sanitized_text('cms_body_dir');
//		$cms_body_dir = preg_replace('/ |-/', '_', $cms_body_dir);
//		$cms_body_dir = preg_replace('/^\//', '', $cms_body_dir);
		$cms_body_dir = Ccms_base::format_app_dir($cms_body_dir);

//		$cms_body_file = preg_replace('/ |-/', '_', $cms_body_file);
//		$cms_body_file = preg_replace('/^\//', '', $cms_body_file);
		$cms_body_file = Ccms_base::format_app_dir($cms_body_file,'php');

		$cms_body_meta_description = $cCMS_C->get_sanitized_text('cms_body_meta_description');
		$cms_body_meta_keywords = $cCMS_C->get_sanitized_text('cms_body_meta_keywords');
		$cms_body_title = $cCMS_C->get_sanitized_text('cms_body_title');
		$cms_body_order = (int)Ccms::get_or_post('cms_body_order');
		$cms_body_group_ids = implode(':',Ccms::get_or_post('cms_body_group_ids'));
		$cms_body_default = Ccms::get_or_post_checkbox('cms_body_default');
		$cms_body_nomenu = Ccms::get_or_post_checkbox('cms_body_nomenu');
		$cms_body_login_page = Ccms::get_or_post_checkbox('cms_body_login_page');
		$cms_body_login_required = Ccms::get_or_post_checkbox('cms_body_login_required');
		$cms_body_enabled = Ccms::get_or_post_checkbox('cms_body_enabled');
		$cms_body_cached = Ccms::get_or_post_checkbox('cms_body_cached');
		$cms_body_debug_only = Ccms::get_or_post_checkbox('cms_body_debug_only');
		$cms_body_default_msgs = Ccms::get_or_post_checkbox('cms_body_default_msgs');
		$cms_body_ssl = Ccms::get_or_post_checkbox('cms_body_ssl');
		$cms_body_full_view = Ccms::get_or_post_checkbox('cms_body_full_view');
		$cms_body_iframe_view = Ccms::get_or_post_checkbox('cms_body_iframe_view');

		$cms_body_manual_url = Ccms::get_or_post('cms_body_manual_url');
		$cms_body_icon_url = $cCMS_C->get_image('cms_body_icon_url', Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_icon_url','cms_body_id = ' . (int)$cms_body_id),ETC_WS_ICONS_DIR);
		$cms_body_image_url = $cCMS_C->get_image('cms_body_image_url', Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_image_url','cms_body_id = ' . (int)$cms_body_id),ETC_WS_IMAGES_DIR);
		$cms_body_terms_url = Ccms::get_or_post('cms_body_terms_url');
		$cms_body_terms_upfirst = Ccms::get_or_post_checkbox('cms_body_terms_upfirst');
		$cms_body_release_notes_url = Ccms::get_or_post('cms_body_release_notes_url');
		$cms_body_readme_url = Ccms::get_or_post('cms_body_readme_url');
		$cms_body_acknowledgment_url = Ccms::get_or_post('cms_body_acknowledgment_url');
		$cms_body_licence_url = Ccms::get_or_post('cms_body_licence_url');

		$cms_body_description = Ccms::get_or_post('cms_body_description');
		$cms_body_H1 = Ccms::get_or_post('cms_body_H1');
		$cms_body_H1_title = Ccms::get_or_post('cms_body_H1_title');
		$cms_body_purpose = Ccms::get_or_post('cms_body_purpose');
		$cms_body_info1 = Ccms::get_or_post('cms_body_info1');
		$cms_body_info2 = Ccms::get_or_post('cms_body_info2');
		$cms_body_comments = Ccms::get_or_post('cms_body_comments');
		$cms_body_package_excludes = Ccms::get_or_post('cms_body_package_excludes');

		if(!empty($not_allowed_chgs)) { // fill missing and not allowed with current values
			$sql_query = "SELECT cms_body_id," . implode(',',$not_allowed_chgs) .
//				", " . Ccms::$cDBcms->get_db_sql_localtime('cms_body_added','cms_body_added') .
//				", " . Ccms::$cDBcms->get_db_sql_localtime('cms_body_updated','cms_body_updated') .
				" FROM  cms_bodies WHERE  cms_body_id = '" . (int)$cms_body_id . "'";
			if(($result = Ccms::$cDBcms->query($sql_query)) &&
				(Ccms::$cDBcms->num_rows($result) > 0) &&
				($body = Ccms::$cDBcms->fetch_array($result))) {
				foreach($body as $k => &$v) {
					// if(!in_array($k,$not_allowed_chgs)) $allowed_chgs[] = $k;
					$$k = $v;
					} // foreach
				Ccms::$cDBcms->free_result($result);
				} // if
			} // if

		// check body file
		$old_body_file = '';
		$old_body_dir = '';
		if((int)$cms_body_id > 0) {
			$old_body_file = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_file','cms_body_id = ' . (int)$cms_body_id);
			$old_body_dir = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_dir','cms_body_id = ' . (int)$cms_body_id);
			} // if
		else if((int)$cms_body_clone_from_id > 0) {
			$old_body_file = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_file','cms_body_id = ' . (int)$cms_body_clone_from_id);
			$old_body_dir = Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_dir','cms_body_id = ' . (int)$cms_body_clone_from_id);
			} // if

		$is_link = ((((int)$cms_body_id > 0) && (is_link(APPS_BODIES_FS_DIR . $old_body_file))) ? true:false);
		if((!$is_link) &&
				(($cms_body_op == 'clone') || ($cms_body_clone_insert)) &&
				(((int)$cms_body_clone_from_id > 0) || ((int)$cms_body_id > 0))) {
				$cms_body_clone_from_id = (((int)$cms_body_clone_from_id > 0) ? $cms_body_clone_from_id:$cms_body_id);
				$cms_body_clone = true;	// retry !!
				$cms_body_op = 'insert';
				$cms_body_id = 0;
				Ccms::addMsg('Cloning body "' . $cms_body_name . '" page / app.','info');
				} // else if

		if(!$cms_body_installed) {
			if(can_cron($cms_body_type)) {
				$cms_body_crontab_enable = Ccms::get_or_post_checkbox('cms_body_crontab_enable');
				$cms_body_crontab_time = $cCMS_C->get_cron_times('cms_body_crontab_time', Ccms::$cDBcms->get_data_in_table('cms_bodies','cms_body_crontab_time','cms_body_id = ' . (int)$cms_body_id));
				$cms_body_crontab_job = Ccms::get_or_post('cms_body_crontab_job');
				} // if

			$cms_body_added = $cCMS_C->get_sanitized_text('cms_body_added');
			$cms_body_updated = $cCMS_C->get_sanitized_text('cms_body_updated');

			if((Ccms::$cms_page_info['html_wysiwyg_allow']) && (!$is_link)) {
				$ws_text_area = $cWYSIWYG->input_edit_text($cms_body_file);
				} // if

			if(($cms_body_op == 'save') || ($cms_body_op == 'insert')) {

				// check uniquenesses
				if($new = Ccms_DB_checks::is_body_name_ok($cms_body_name, $cms_body_op, $cms_body_prefix))
					$cms_body_name = $new;
				if($new = Ccms_DB_checks::is_body_app_key_ok($cms_body_app_key, $cms_body_op, $cms_body_prefix))
					$cms_body_app_key = $new;
				if((!empty($cms_body_virtual_name)) &&
						($new = Ccms_DB_checks::is_virtual_name_ok($cms_body_virtual_name, $cms_body_op, $cms_body_prefix)))
						$cms_body_virtual_name = $new;

				$cms_body_type = ((int)$cms_body_type % count($cms_apps_types));
				if((!empty($cms_body_dir)) ||
					(isset($cms_apps_types[$cms_body_type]['app_dirs']))) {
					if($new = Ccms_DB_checks::is_body_dir_ok($cms_body_dir,$cms_body_op, $cms_body_prefix))
						$cms_body_dir = $new;
					} // if
				if($new = Ccms_DB_checks::is_body_file_ok($cms_body_type,$cms_body_file,$cms_body_op, $cms_body_prefix))
					$cms_body_file = $new;

				$cms_apps_in_dir = 0;
				$names_in_dir = array();
				if(!empty($cms_body_dir)) {
					$sql_dir = "SELECT cms_body_name FROM cms_bodies WHERE cms_body_dir = '" . $cms_body_dir . "' ORDER BY cms_body_name";
					if($res_dir = Ccms::$cDBcms->query($sql_dir)) {
						while($dir = Ccms::$cDBcms->fetch_array($res_dir)) {
							$cms_apps_in_dir++;
							if($cms_body_name == $dir['cms_body_name']) continue;	//me
							$names_in_dir[] = $dir['cms_body_name'];
							} // while
						if(!empty($names_in_dir)) {
							$names_in_dir_msg = '<br>' .Ccms::make_message_text('App directory "' . $cms_body_dir . '" also contains ' . implode(', ',$names_in_dir) . ' applications.','warn');
							} // if
						} // if
					} // if
				if(($cms_body_clone) && ($cms_apps_in_dir > 1)) {
					$cms_body_prefix = Ccms_base::format_app_dir($cms_body_prefix);
					if(strlen($cms_body_prefix) < 2) {
						Ccms::addMsg('App name prefix too short.');
						} // if
					} // if

				if(Ccms_DB_checks::is_body_file_required($cms_body_type)) {
					if((((int)$cms_body_id > 0) || ((int)$cms_body_clone_from_id > 0)) &&
						(!empty($cms_body_file)) && (!empty($old_body_file))) {
						$cms_body_filepath = APPS_BODIES_FS_DIR . $cms_body_file;
						$old_body_filepath = APPS_BODIES_FS_DIR . $old_body_file;
						if((file_exists($old_body_filepath)) ||
							(is_readable($old_body_filepath)) ||
							($is_link)) {
							if((!$is_link) && (!is_writable($old_body_filepath))) {
								Ccms::addMsg('Body file "' . $old_body_filepath . '" is not writeabe.');
								} // if
							else if((!empty($old_body_file)) && (!empty($cms_body_file)) &&
								($old_body_filepath != $cms_body_filepath)) { // move (or copy) it
								$cms_body_path = dirname($cms_body_filepath);
								if((!$is_link) && ($cms_body_clone_insert) &&
									((int)$cms_body_clone_from_id > 0)) {
									if(!copy($old_body_filepath,$cms_body_filepath)) {	// copy it
										Ccms::addMsg('Failed to copy body file from "' . $old_body_file . '" to "' . $cms_body_file . '".');
										} // if
									else {
										Ccms::addMsg('Copied body file from "' . $old_body_file . '" to "' . $cms_body_file . '".','success');
										} // else
									} // if
								else {
									if((!Ccms::chkdir($cms_body_path)) ||
										(!@rename($old_body_filepath, $cms_body_filepath))) {
										Ccms::addMsg('Failed to move body file from "' . $old_body_file . '" to "' . $cms_body_file . '".');
										} // if
									else {
										Ccms::addMsg('Moved body file from "' . $old_body_file . '" to "' . $cms_body_file . '".','success');
										} // else
									} // else
								} // if
							Ccms::chmod_chown($old_body_filepath);
							Ccms::chmod_chown($cms_body_filepath);
							} // if
						else {	// a missing file
							Ccms::addMsg('Missing body file "' . $cms_body_filepath . '".','warning');
							} // else
						} // if
					else if((!empty($cms_body_file)) && ((int)$cms_body_id <= 0)) {	// new file
						$cms_body_filepath = APPS_BODIES_FS_DIR . $cms_body_file;
						if((file_exists($cms_body_filepath)) && (is_readable($cms_body_filepath))) {
							Ccms::addMsg('File with the same name already exists. Appending text.','warning');
							$ws_text_area .= PHP_EOL . file_get_contents($cms_body_filepath);
							} // if
						else {
							Ccms::addMsg('New app body file.','info');
							$ws_text_area = make_new_body_text($cms_body_filepath,$ws_text_area);
							} // else
						} // else if
					else if(!Ccms::getMsgsCount('error')) Ccms::addMsg('Unknown body file operation.');

					if((!empty($cms_body_dir)) &&
						(isset($cms_apps_types[$cms_body_type]['app_dirs']))) {
						if((((int)$cms_body_id > 0) || ((int)$cms_body_clone_from_id > 0)) &&
							(!empty($cms_body_dir)) && (!empty($old_body_dir))) {
							$cms_body_dirpath = APPS_FS_DIR . $cms_body_dir;
							$old_body_dirpath = APPS_FS_DIR . $old_body_dir;
							if((is_dir($cms_body_dirpath)) ||
								(is_dir($old_body_dirpath)) ||
								($is_link)) {
								if((!$is_link) && (!is_writable($old_body_dirpath))) {
									Ccms::addMsg('Body file "' . $old_body_dirpath . '" is not writeabe.');
									} // if
								else if(($old_body_dir != $cms_body_dir) &&
									(!empty($old_body_dir)) && (!empty($cms_body_dir)) &&
									($old_body_dirpath != $cms_body_dirpath)) { // move (or copy) it
									if((!$is_link) && ($cms_body_clone_insert) &&
										((int)$cms_body_clone_from_id > 0)) {
										if(!Ccms::recurse_copy($old_body_dirpath,$cms_body_dirpath)) {	// copy it
											Ccms::addMsg('Failed to copy application directory from "' . $old_body_dir . '" to "' . $cms_body_dir . '".');
											} // if
										else {
											Ccms::addMsg('Copied application directory from "' . $old_body_file . '" to "' . $cms_body_file . '".','success');
											} // else
										} // if
									else {
										if((!is_dir($old_body_dirpath)) ||
											(!Ccms::recurse_move($old_body_dirpath, $cms_body_dirpath)) ||
											(!is_dir($cms_body_dirpath))) {
											Ccms::addMsg('Failed to move application directory from "' . $old_body_dir . '" to "' . $cms_body_dir . '".');
											} // if
										else {
											Ccms::addMsg('Moved application directory from "' . $old_body_dir . '" to "' . $cms_body_dir . '".','success');
											} // if
										} // else
									} // if
								Ccms::chmod_chown($old_body_dirpath);
								Ccms::chmod_chown($cms_body_dirpath);
								} // if
							else {	// a missing dir
								if(!Ccms::chkdir($cms_body_dirpath, true, false)) {
									Ccms::addMsg('Failed to create/check "' . $cms_body_dir . '" directory.');
									} // if
								} // else
							} // if
						else if((!empty($cms_body_dir)) && ((int)$cms_body_id <= 0)) {	// new file
							$cms_body_dirpath = APPS_FS_DIR . $cms_body_dir;
							if((is_dir($cms_body_dirpath)) && (is_readable($cms_body_dirpath))) {
								Ccms::addMsg('Directory with the same name already exists (new).','warning');
								} // if
							} // else if
						else if((!empty($cms_body_dir)) && ((int)$cms_body_id > 0)) {	// new apps dir
							$cms_body_dirpath = APPS_FS_DIR . $cms_body_dir;
							if((!CMS_C_ALLOW_APPS_DIR_SHARE) && (is_dir($cms_body_dirpath)) && (is_readable($cms_body_dirpath))) {
								Ccms::addMsg('Directory with the same name already exists (change).','warning');
								} // if
							else if(Ccms::chkdir($cms_body_dirpath)) {
								Ccms::addMsg('Created new apps "' . $cms_body_dirpath . '" directory.','info');
								} // if
							} // else if
			//			else if((!Ccms::getMsgsCount('error')) &&
			//				(!Ccms::getMsgsCount ('warn')))
			//				Ccms::addMsg('Unknown application directory operation.');
						} // if

					if(($cms_body_op != 'clone') && (!Ccms::getMsgsCount('error'))) {
						if(!$is_link) {
							if((!empty($ws_text_area)) && (strlen($ws_text_area) > 10)) {	// update file
								$cms_body_filepath = APPS_BODIES_FS_DIR . $cms_body_file;
								if(!$fh = Ccms::file_safe_wopen($cms_body_filepath, 'w')) {
									Ccms::addMsg('Failed to open body file "' . $cms_body_filepath . '".');
									} // if
								else {	// add some text to the new file
									if(!fwrite($fh, $ws_text_area)) {
										Ccms::addMsg('Failed to save text to body file "' . APPS_BODIES_WS_DIR . $cms_body_file . '".');
										} // if
									else {
										Ccms::addMsg('Save text to body file "' . APPS_BODIES_WS_DIR . $cms_body_file . '".','success');
										} // else
									Ccms::file_safe_wclose($fh,$cms_body_filepath);
									} // else
								} // if
							else Ccms::addMsg ('Body text is too small (less than 10 characters), not saved', 'warning');
							} // if
						} // if

					if($is_link) Ccms::addMsg('"' . $cms_body_file . '" is a symbolic link.','info');
					} // if

				if((!Ccms::getMsgsCount('error')) && (CMS_C_ALLOW_APPS_DIR_SHARE) &&
					(!empty($old_body_dir)) && (!empty($cms_body_dir))) {
					if((!$cms_body_clone) && ($cms_body_op != 'clone')) {	// move all same app_dirs to same dest
						$sql_mv = "UPDATE cms_bodies SET cms_body_dir = '" . $cms_body_dir . "' WHERE cms_body_dir = '" . $old_body_dir . "';";
						if(!Ccms::$cDBcms->query($sql_mv)) {
							Ccms::addMsg('Failed to UPDATE apps directory for "' . $old_body_dir . '" to "' . $cms_body_dir . '".');
							$cms_body_dir = $old_body_dir;
							$cms_body_filepath = $old_body_dirpath;
							} // if
						} // if
					else {	// copy all with same app_dirs to same dest and add prefix
						$sql_mv = "UPDATE cms_bodies SET cms_body_dir = '" . $cms_body_dir . "' WHERE cms_body_dir = '" . $old_body_dir . "';";
						if(!Ccms::$cDBcms->query($sql_mv)) {
							Ccms::addMsg('Failed to UPDATE apps directory for "' . $old_body_dir . '" to "' . $cms_body_dir . '".');
							$cms_body_dir = $old_body_dir;
							$cms_body_filepath = $old_body_dirpath;
							} // if
						} // else
					} // if

				if(($cms_body_op != 'clone') && (!Ccms::getMsgsCount('error'))) {	// update it
					if((int)$cms_body_default > 0) {	// if default page body
						$sql_query = "SELECT cms_body_id,cms_body_default" .
									" FROM  cms_bodies WHERE cms_body_default = 1 AND cms_body_nomenu < 1";
						if($result = Ccms::$cDBcms->query($sql_query)) {
							while($default = Ccms::$cDBcms->fetch_array($result)) {
								// turn off any other default pages
								Ccms::$cDBcms->query('UPDATE cms_bodies SET cms_body_default = 0 WHERE cms_body_id = ' . $default['cms_body_id'] . ';');
								} // while
							} // if
						} // if
					if((int)$cms_body_login_page > 0) {	// if login page body
						$sql_query = "SELECT cms_body_id,cms_body_login_page" .
									" FROM  cms_bodies WHERE cms_body_login_page = 1 AND cms_body_nomenu < 1";
						if($result = Ccms::$cDBcms->query($sql_query)) {
							while($default = Ccms::$cDBcms->fetch_array($result)) {
								// turn off any other default pages
								Ccms::$cDBcms->query('UPDATE cms_bodies SET cms_body_login_page = 0 WHERE cms_body_id = ' . $default['cms_body_id'] . ';');
								} // while
							} // if
						} // if

					$fields = array();
					foreach($edit_col_names as $name) {
						if(!in_array($name,$not_allowed_chgs)) $fields[$name] = $$name;
						} // foreach
					// do some sanity checks
					if((isset($fields['cms_body_login_page'])) &&
						($fields['cms_body_login_page'] > 0))
						$fields['cms_body_login_required'] = 0;
					if(!empty($cms_body_dir)) {
						$prefix_rm = array(APPS_WS_DIR . $cms_body_dir . '/', APPS_WS_DIR . $old_body_dir . '/');	// to remove
						foreach ($body_urls as $k) {	// remove app/dir from url
							if(empty($fields[$k])) continue;
							$v = $fields[$k];
							foreach($prefix_rm as $p) {
								$l = strlen($p);
								if(substr($v,0,$l) == $p)
									$fields[$k] = substr($v,$l);
								} // foreach
							} // foreach
						} // if

					if(($cms_body_op == 'insert') &&
						(!Ccms::$cDBcms->perform('cms_bodies',$fields,'insert',''))) {
						Ccms::addMsg('Body insert, ' . $cms_body_name . " failed");
						} // if
					else if(($cms_body_op == 'save') &&
						(!Ccms::$cDBcms->perform('cms_bodies',$fields,'update',"cms_body_id = " . (int)$cms_body_id . ""))) {
						Ccms::addMsg('Body update, ' . $cms_body_name . " failed");
						} // if
					else {

						if(!empty($old_body_dir)) {	// update other apps in same directory
							$sql_dir = "SELECT cms_body_id FROM cms_bodies WHERE cms_body_dir = '" . $old_body_dir . "'";
							if($res_dir = Ccms::$cDBcms->query($sql_dir)) {
								while($dir = Ccms::$cDBcms->fetch_array($res_dir)) {
									$sql_upd = "UPDATE cms_bodies SET cms_body_dir = '" . $cms_body_dir . "' WHERE cms_body_id = " . (int)$cms_body_dir;
									if(!Ccms::$cDBcms->query($sql_upd)) {
										Ccms::addMsg('Failed to update application directory in same directory.');
										break;
										} // if
									} // while
								} // if
							} // if

						// Ccms_base::unset_cms_sess_var('cms_body_id');
						Ccms_export::export_table('cms_bodies');
						if($api_map = Ccms_api_map::get_api_resource_map(true)) {
							self::addMsg('Rebuild API map.','info');
							} // if
						Ccms::addMsg('Saved body config.','success');
						} // else
					new Ccms_xml_sitemap();	// do sitemap
					$cms_body_id = 0;
					$cms_body_clone_from_id = 0;
					$cms_body_op = '';
					} // if
				} // if
			} // if
		else {	// is installed only limited control
			$fields = array();
			foreach($edit_col_names as $name) {
				if(!in_array($name,$not_allowed_chgs)) $fields[$name] = $$name;
				} // foreach
			// do some sanity checks
			if((isset($fields['cms_body_login_page'])) &&
				($fields['cms_body_login_page'] > 0))
				$fields['cms_body_login_required'] = 0;

			if(($cms_body_op == 'insert') &&
				(!Ccms::$cDBcms->perform('cms_bodies',$fields,'insert',''))) {
				Ccms::addMsg('Body insert, ' . $cms_body_name . " failed");
				} // if
			else if(($cms_body_op == 'save') &&
				(!Ccms::$cDBcms->perform('cms_bodies',$fields,'update',"cms_body_id = " . (int)$cms_body_id . ""))) {
				Ccms::addMsg('Body update, ' . $cms_body_name . " failed");
				} // if
			} // else

		// create/ check app dirs
		if((!$readonly_apps) && (!$is_link) &&
			(!Ccms::getMsgsCount('error')) &&
			(isset($cms_apps_types[$cms_body_type]['app_dirs'])) &&
			(!empty($cms_body_dir))) {
			$cms_body_dirpath = APPS_FS_DIR . $cms_body_dir;
			if(Ccms::chkdir($cms_body_dirpath)) {
				$cms_app_dirs = &$cms_apps_types[$cms_body_type]['app_dirs'];
				foreach($cms_app_dirs as $dir) {
					$cms_app_dir = $cms_body_dirpath  . '/' . $dir;
					if(!Ccms::chkdir($cms_app_dir)) {
						Ccms::addMsg('Failed to create app "' . $dir . '".');
						} // if
					} // foreach
				} // if
			else Ccms::addMsg('Failed to create apps directory "' . $cms_body_dir . '".');
			} // if

		$cms_body_id = 0;
		$cms_body_op = '';
		$cms_body_added = '';
		$cms_body_updated = '';
		} // if
	} // if
$cnt = Ccms::$cDBcms->get_row_count_in_table('cms_bodies');
$row = 0;
$is_editable_viewable = ((!Ccms::$cms_page_info['html_wysiwyg_allow'] || $cms_body_installed) ? false:
		((((int)$cms_body_id > 0) && (isset($cms_body_file)) && (is_link(APPS_BODIES_FS_DIR . $cms_body_file))) ? false:true));

$icon_paths = array(APPS_WS_ICONS_DIR, ETC_WS_ICONS_DIR);
$image_paths = array(APPS_WS_IMAGES_DIR, ETC_WS_IMAGES_DIR);

$cms_apps_names_msg = '';
$cms_apps_in_dir = 0;
if(!empty($cms_body_dir)) {
	$sql_dir = "SELECT cms_body_name FROM cms_bodies WHERE cms_body_dir = '" . $cms_body_dir . "' ORDER BY cms_body_name";
	if($res_dir = Ccms::$cDBcms->query($sql_dir)) {
		$names_in_dir = array();
		while($dir = Ccms::$cDBcms->fetch_array($res_dir)) {
			$cms_apps_in_dir++;
			if($cms_body_name == $dir['cms_body_name']) continue;	//me
			$names_in_dir[] = $dir['cms_body_name'];
			} // while
		if(!empty($names_in_dir)) {
			$cms_apps_names_msg = '<br>' .Ccms::make_message_text('App directory "' . $cms_body_dir . '" also contains ' . implode(', ',$names_in_dir) . ' applications.','warn');
			} // if
		else {
			$icon_paths[] = APPS_WS_DIR . $cms_body_dir . '/icons/';
			$image_paths[] = APPS_WS_DIR . $cms_body_dir . '/images/';
			} // else
		} // if
	} // if

Ccms::page_start_comment(__FILE__);

if(Ccms::$cms_page_info['html_wysiwyg_allow']) {
	$text = $cWYSIWYG->get_wysiwyg_library();
	echo $text;
	} // if

?>

<style>
	a {
		text-align: left;
		/*white-space: nowrap;*/
		}
	.multi {
		text-align: left;
		white-space: nowrap;
		padding: 3px 5px;
		}
	.wrap {
		text-align: left;
		white-space: normal;
		padding: 3px 5px;
		}
</style>

<?php
	if(($cms_body_op == 'package') && ((int)$cms_body_id > 0)) {
		include(CMS_FS_OPS_DIR . 'cms_edit_bodies_package.php');
		return;
		} // if
	if($cms_body_op == 'install') {
		include(CMS_FS_OPS_DIR . 'cms_edit_bodies_install.php');
		return;
		} // if
?>

<?= Ccms::get_admin_scroll2pageTop() ?>
<form name="edit_body" action="<?= $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_bodies' ?>"
	onsubmit="cms_ws_onsubmit(event,this,'wysiwyg_data_id');"
	method="post" enctype="multipart/form-data">
	<input id="wysiwyg_data_id" type="hidden" name="wysiwyg_data" value="">
<?= Ccms_search::get_form_search_hidden_inputs() ?>
<span id="ws_config" style="display: block;">
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Page Bodies / Apps Control</h1>
		</th>
	</tr>
	<?php if((Ccms_app_install::is_app_pkg_ops_ok()) &&
		($cms_body_op == 'build_package') && ((int)$cms_body_id > 0)) { ?>
	<tr class="page_config"><th class="page_config">Package Body / Application - <?= $cms_body_name ?></th></tr>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Building package. Download will follow. Click
			<button type="button" onclick="window.location.href='index.php?cms_action=cms_edit_bodies&build=done';">Close</button>
			to return to applications page.
			<?php $cPackage = new Ccms_app_install('build_package',$cms_body_id) ?>
		</td>
	</tr>
	<?php } // if ?>
	<?php if((Ccms_app_install::is_app_pkg_ops_ok()) &&
		($cms_body_op == 'install_package')) { ?>
	<tr class="page_config"><th class="page_config">Install Body / Application from Package</th></tr>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php $cPackage = new Ccms_app_install('install_package') ?>
		</td>
	</tr>
	<?php } // if ?>
	<?php if((!$readonly_apps) && ($cms_body_op == 'reloadDB')) { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php Ccms::$cDBcms->installDatabase('cms_bodies',true ,true) ?>
		</td>
	</tr>
	<?php } // if ?>
	<?php if((!$readonly_apps) && ($cms_body_op != 'delete')) { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Select body name:&nbsp;
			<?=  Ccms::gen_body_selection_list('body_edit_id',$cms_body_id,'id="prim_id" size="1" onchange="javascript:setConfigButtons();"') ?>
			&nbsp;&nbsp;
			<?php if($cms_body_id > 0) { ?>
<!--			<button id="b_edit_id" name="edit" value="edit" type="submit" onclick="Ccms_cursor.setWait();">Edit</button>
			&nbsp;&nbsp;-->
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
			<button id="b_delete_id" name="delete" value="delete" type="submit" onclick="Ccms_cursor.setWait();">Delete</button>
			&nbsp;&nbsp;
			<?php	} // if ?>
			<button name="add" value="add" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			&nbsp;&nbsp;
			<?php if(Ccms_app_install::is_app_pkg_ops_ok()) { ?>
			<button name="install" value="install" type="submit" onclick="Ccms_cursor.setWait();" title="Install application package.">Install</button>
			<?php	} // if ?>
			<?php if((Ccms_auth::is_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
			&nbsp;&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise bodies table in database." onClick="return confirm_check('Clear and re-initialise bodies table in database?')">Reload</button>
			<?php	} // if ?>
			<?= Ccms_export::get_table_form_text('cms_bodies') ?>
			<?php Ccms::get_return2search_link() ?>
			<span id="working_id">&nbsp;</span>
			<script type="text/javascript">

				function confirm_check(txt) {
					if(confirm(txt)) {
						document.getElementById('working_id').innerHTML = '<?= Ccms_msgs::make_message_text('submiting input.', 'working') ?>';
						cms_sleep(2000);	// allow img to load
						return true;
						} // if
					return false;
					} // confirm_check()

				function setConfigButtons() {
					var sel = document.getElementById('prim_id');
					if(!sel) return;
					if(sel.selectedIndex > 0) {
						// document.getElementById('b_edit_id').disabled = false;
						document.getElementById('b_delete_id').disabled = false;
					} else {
						// document.getElementById('b_edit_id').disabled = true;
						document.getElementById('b_delete_id').disabled = true;
					} // else
					} // setBodyConfigButtons()
				setConfigButtons();	// initial
			</script>
		</td>
	</tr>
	<?php } // if ?>

	<?php

	if((($cms_body_op == 'edit') || ($cms_body_op == 'save') ||
		($cms_body_op == 'add') || ($cms_body_op == 'insert') || ($cms_body_op == 'clone')) &&
		(isset($cms_body_id))) {
		if(!empty($cms_body_file)) {
			$is_link = (is_link(APPS_BODIES_FS_DIR . $cms_body_file) ? true:false);
			if((!$is_link) && (!empty($cms_body_dir)) &&
				(is_link(APPS_FS_DIR . $cms_body_dir)))
				$is_link = true;
			} // if
		else $is_link = false;

		if(empty($cms_body_app_key)) {	// make a default
			$cms_body_app_key = Ccms::format_app_key($cms_body_name);
			} // if

		$row = 0;
	?>
	<tr class="page_config">
		<th class="page_config">

			<?php if($cms_body_id == 0) {
				echo 'Add Body / App' . ($cms_body_clone ? ' Clone':'');
				} // if
			else {
				echo 'Edit Body' .
					'&nbsp;&nbsp;<span class="page_config">(Added:&nbsp;' . $cms_body_added .
					'&nbsp;&nbsp;Updated:&nbsp;' . $cms_body_updated . ')</span>';
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_body_name))
					Ccms::get_return2search_link(true);
				} // else
			if(!empty($cms_body_manual_url)) {
				if(file_exists(APPS_FS_DIR . $cms_body_dir . '/docs/' . $cms_body_manual_url)) { ?>
					<a href="index.php?cms_action=app_manual<?= '&app=' . $cms_body_id ?>" target="_blank"><?= $cms_body_name ?>: Application Manual</a>.
				<?php	}	} // if ?>

			<input type="hidden" name="cms_body_id" value="<?= $cms_body_id ?>"/>
			<input type="hidden" name="cms_body_name_old" value="<?= htmlentities($cms_body_name) ?>"/>
			<input type="hidden" name="cms_body_app_key_old" value="<?= htmlentities($cms_body_app_key) ?>"/>
			<input type="hidden" name="cms_body_dir_old" value="<?= htmlentities($cms_body_dir) ?>"/>
			<input type="hidden" name="cms_body_type_old" value="<?= htmlentities($cms_body_type) ?>"/>
			<input type="hidden" name="cms_body_added" value="<?= htmlentities($cms_body_added) ?>"/>
			<input type="hidden" name="cms_body_updated" value="<?= htmlentities($cms_body_updated) ?>"/>
<?php if (!$is_link && $cms_body_clone) { ?>
			<input type="hidden" name="cms_body_clone" value="true"/>
			<input type="hidden" name="cms_body_clone_from_id" value="<?= $cms_body_clone_from_id ?>"/>
<?php	} // if ?>
		</th>
	</tr>
	<tr class="page_config" style="position: sticky; top: 0px; background-color: ivory;">
		<td class="page_config">
			<button onclick="cms_setView('ws_config');" type="button" disabled="true">Config</button>
			&nbsp;&nbsp;
		<?php if($is_editable_viewable) { ?>
			<button onclick="cms_setView('ws_text_input');" type="button" title="Goto edit page body <?= (Ccms::$cms_page_info['html_wysiwyg_allow'] ? '(' . $cWYSIWYG->get_wysiwyg_title() . ')':'') ?>.">Editor</button>
			<?php if(preg_match('/\.htm$|\.html$/i',$cms_body_file)) { ?>
			&nbsp;&nbsp;
			<button onclick="cms_setView('ws_text_view');" type="button" title="Goto to view page body.">View</button>
			<?php	} // if ?>
			&nbsp;&nbsp;
		<?php	} // if ?>
			<?php if($cms_body_id == 0) { ?>
			<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
		<?php if(!$is_link && !$cms_body_installed) { ?>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
		<?php	} // if ?>
		<?php if((Ccms_app_install::is_app_pkg_ops_ok()) &&
				(!$cms_body_installed)) { ?>
			&nbsp;&nbsp;
			<button name="package" value="package" type="submit" title="Create application package for - <?= $cms_body_name ?>.">Package</button>
		<?php	} // if ?>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		<?php if(!$is_editable_viewable) { ?>
			&nbsp;&nbsp;
			<span><b>Note:</b> Body file not editable type (i.e not .html). Use source code editor on &quot;<?= APPS_BODIES_WS_DIR . $cms_body_file ?>&quot;.</span>
		</td>
	</tr>
<?php	} // if ?>
	<tr>
		<td>
			<table class="page_config page_config_edit">
<?php if($cms_body_installed) { ?>
				<tr class="page_config">
					<th class="page_config">Installed App:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Application is installed from a package with only minimum changes allowed.','info') ?>
					</td>
				</tr>
<?php	} // if ?>
<?php if($cms_body_clone) { ?>
				<tr class="page_config">
					<th class="page_config">Cloning An App:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Make changes to the cloned application of "' . $cms_body_name . '" to ensure uniqueness.','info') . $cms_apps_names_msg ?>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Name:</th>
					<td class="page_config" style="min-width: 320px;" <?= ($cms_body_installed ? ' title="Installed application package (limited changes allowed)."':'') ?>>
						<input type="text" name="cms_body_name" <?= (in_array('cms_body_name',$not_allowed_chgs) ? ' DISABLED':'') ?> size="45" value="<?= $cms_body_name ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?> REQUIRED/>
					</td>
					<td class="page_config">
						 Unique body name. Appears in link URL (keep as plain text). Minimum of <?= LM_C_MIN_NAME_LEN ?> characters.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Key:</th>
					<td class="page_config" style="min-width: 320px;" <?= ($cms_body_installed ? ' title="Installed application package (limited changes allowed)."':'') ?>>
						<input type="text" name="cms_body_app_key" <?= (in_array('cms_body_app_key',$not_allowed_chgs) ? ' DISABLED':'') ?> size="45" value="<?= $cms_body_app_key ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?> REQUIRED/>
					</td>
					<td class="page_config">
						 Unique application key i.e. &quot;(APP_KEY)&quot; (keep as plain text with no white space). Minimum of <?= LM_C_MIN_NAME_LEN ?> characters.
					</td>
				</tr>
<?php if(($cms_body_clone) && (($apps_in_dir > 1) || (!empty($cms_body_prefix)))) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Apps Name Prefix:</th>
					<td class="page_config">
						<input type="text" name="cms_body_prefix" size="45" value="<?= $cms_body_prefix ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Prefix added to other body files and other app names using the same application directory (minimum of 2 characters).
						<br>
						Non alphanumeric leading characters are removed. Non alphanumeric characters converted to an underscore.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_virtual_name',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Virtual Folder Name: (optional)</th>
					<td class="page_config">
						<input type="text" name="cms_body_virtual_name" <?= (in_array('cms_body_virtual_name',$not_allowed_chgs) ? ' DISABLED':'') ?> size="45" value="<?= $cms_body_virtual_name ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Enter the virtual folder name to link to this app (optional).
						e.g. instead of &quot;index.php?app=id&quot; uses &quot;virtual_name&quot;.
						Often the application lowercase name is entered with any whitespace and punctuation removed.
						See <a href="index.php?cms_action=cms_manual#coding_shortcuts" target="_blank">Technical Manual</a> for more information.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_virtual_name',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App / body language: (Optional)</th>
					<td class="page_config">
						<?= Ccms_language::get_language_selector('cms_body_lang', $cms_body_lang,false, $params = false,(in_array('cms_body_lang',$not_allowed_chgs) ? ' DISABLED':'')) ?>
					</td>
					<td class="page_config">
						Select the app / body text language.The default base language the applications are written (i.e. the source language of the app / body text for translators).
						<br><b>Note:</b> The <?= CMS_PROJECT_SHORTNAME ?> core language is &quot;<?= CMS_CORE_LANG ?>&quot; and is the default language.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_description',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Description:</th>
					<td class="page_config">
						<textarea name="cms_body_description" cols="45" rows="3" <?= ($cms_body_installed ? ' readonly':'') ?>><?= $cms_body_description ?></textarea>
					</td>
					<td class="page_config">
						Enter a page / application description, can be short text description (Note: newlines are used to encapsulate paragraphs),
						an include file or a static class method (e.g. class::method called as class::method(body_id,name).
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_title',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Page Title:</th>
					<td class="page_config">
						<input type="text" name="cms_body_title" size="45" value="<?= $cms_body_title ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Page title (optional), appears in the head element at the top of the browser web page.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_H1',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">H1:</th>
					<td class="page_config">
						<input type="text" name="cms_body_H1" size="45" value="<?= $cms_body_H1 ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						H1 heading (optional), used only by the application and the sitemap.
						Provides an easily configurable H1 title.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_H1_title',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">H1 Title:</th>
					<td class="page_config">
						<input type="text" name="cms_body_H1_title" size="45" value="<?= $cms_body_H1_title ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						H1 heading title (optional), used only by the application and the sitemap.
						Provides an easily configurable H1 title.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_type',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Type:</th>
					<td class="page_config">
						<?php
							if($cms_body_installed) {
								echo $cms_apps_types[$cms_body_type]['name'] . ' <b>Installed application.</b>';
								echo '<input type="hidden" name="cms_body_type" value="' . $cms_body_type . '">';
								} // if
							else {
								echo '<select name="cms_body_type" REQUIRED>';
								foreach($cms_apps_types as $k => &$v) {
									echo '	<option value="'. $k . '"' . (($k == $cms_body_type) ? ' SELECTED':'') .
											(($k <= 0) ? ' disabled selected hidden':'') .
											' title="' . strip_tags(preg_replace('/<br>|<\/br>/i',PHP_EOL,$v['desc'])) . '"' .
											'>' .
											$v['name'] .
											(($k > 0) ? ' (' . strip_tags(preg_replace('/<br>|<\/br>/i',PHP_EOL,$v['title'])) . ')':'') .
											'</option>';
									} // foreach
								echo '</select>';
								} // else
						?>
					</td>
					<td class="page_config">
						<?= Ccms_DB_checks::get_apps_types_descriptions('Application types.',true) ?>
						<br>
						Refer to <a href="index.php?cms_action=cms_manual#AppModules" target="_blank">Technical Manual</a> for more information.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_file',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App File (URL):</th>
					<td class="page_config">
						<input type="text" name="cms_body_file" size="45" value="<?= $cms_body_file ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?> REQUIRED/>
					</td>
					<td class="page_config">
						Unique body filename (.htm or .html to use WYSIWYG editor, no spaces).
						 Saved in <?= APPS_BODIES_WS_DIR ?> directory.
						 <br>
						 Recommend using the _body suffix (e.g. example_body.php). Minimum of 6 characters.
						<?php if($is_link) echo '<br>Is a symbolic link and cannot be cloned.' ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_dir',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Directory:</th>
					<td class="page_config">
						<input type="text" name="cms_body_dir" size="45" value="<?= $cms_body_dir ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						<?= (CMS_C_ALLOW_APPS_DIR_SHARE ? 'Shared or unique':'Unique') ?> application directory name (optional). Minimum of <?= LM_C_MIN_NAME_LEN ?> characters.
						<?php if($is_link) echo '<br>Is a symbolic link and cannot be cloned.' ?>
						<?= $cms_apps_names_msg ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_version',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Version:</th>
					<td class="page_config">
						<input type="text" name="cms_body_version" size="45" value="<?= $cms_body_version ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						 Application version number or string.
						 Used to track application versions.
						 Enter a version tracking value.
						 (optional)
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_purpose',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Purpose:</th>
					<td class="page_config">
						<textarea name="cms_body_purpose" cols="45" rows="3" <?= ($cms_body_installed ? ' readonly':'') ?>><?= $cms_body_purpose ?></textarea>
					</td>
					<td class="page_config">
						Enter a page/app purpose, intended for application use only.
						can be short text (Note: newlines are used to encapsulate paragraphs),
						an include file or a method (e.g. class::method called as class::method(body_id,name).
						Not used by <?= CMS_PROJECT_SHORTNAME ?>, for application use only.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_info1',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Info 1:</th>
					<td class="page_config">
						<textarea name="cms_body_info1" cols="45" rows="3" <?= ($cms_body_installed ? ' readonly':'') ?>><?= $cms_body_info1 ?></textarea>
					</td>
					<td class="page_config">
						Enter a page/app information 1, intended for application use only.
						can be short text (Note: newlines are used to encapsulate paragraphs),
						an include file or a method (e.g. class::method called as class::method(body_id,name).
						Not used by <?= CMS_PROJECT_SHORTNAME ?>, for application use only.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_info2',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">App Info 2:</th>
					<td class="page_config">
						<textarea name="cms_body_info2" cols="45" rows="3" <?= ($cms_body_installed ? ' readonly':'') ?>><?= $cms_body_info2 ?></textarea>
					</td>
					<td class="page_config">
						Enter a page/app information 2, intended for application use only.
						can be short text (Note: newlines are used to encapsulate paragraphs),
						an include file or a method (e.g. class::method called as class::method(body_id,name).
						Not used by <?= CMS_PROJECT_SHORTNAME ?>, for application use only.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_manual_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Application Manual:</th>
					<td class="page_config">
						<?=  Ccms::get_body_dir_selection('cms_body_manual_url',$cms_body_manual_url,' - Select App Manual - ',$cms_body_dir . '/docs') ?>
					</td>
					<td class="page_config">
						Select the file containing the application&rsquo;s manual in &quot;<?= APPS_WS_DIR . $cms_body_dir . '/docs/' ?>&quot; directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_comments',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<textarea name="cms_body_comments" cols="45" rows="2"><?= $cms_body_comments ?></textarea>
					</td>
					<td class="page_config">
						<?= Ccms::getAdminCommentHint('edit_body',$cms_body_name) ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_package_excludes',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Excluded:</th>
					<td class="page_config">
						<input type="text" name="cms_body_package_excludes" size="45" value="<?= $cms_body_package_excludes ?>" autocapitalize="off">
					</td>
					<td class="page_config">
						Package builder exclusions (not seen by user).
						List separated by comas of excluded directories (builder does not descend into the directory).
						And files are matched directly.
						Used to stop data directories and files from being included in the package.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_group_ids',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th width ="150px" class="page_config" valign="top">Select group/s:</th>
					<td class="page_config">
						<?=  Ccms::gen_group_selection_list('cms_body_group_ids[]',$cms_body_group_ids, 10, ' multiple') ?>
					</td>
					<td class="page_config">
						Select the groups the page or application can appear under.
						Users need to belong to selected groups to see this application.
						<br>
						If another method is used to control application usage,
						it is recommended that &quot;All Groups&quot; is selected to avoid conflict.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_meta_description',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Meta Description:</th>
					<td class="page_config">
						<input type="text" name="cms_body_meta_description" size="45" value="<?= $cms_body_meta_description ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Meta description (optional, leave blank to use the general web site description), appears the head element of the web page.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_meta_keywords',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Meta Keywords:</th>
					<td class="page_config">
						<input type="text" name="cms_body_meta_keywords" size="45" value="<?= $cms_body_meta_keywords ?>" autocapitalize="off" <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Meta keywords (optional, leave blank to use the general web site keywords), keywords / phrases separated by commas, appears the head element of the web page for search engines.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_order',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Page Body Order:</th>
					<td class="page_config">
						<input type="number" name="cms_body_order" size="5" value="<?= $cms_body_order ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Sorting order for body. Used to control the order of the body. Low numbers at the top of the page, ascending down the page.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_default',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Default Page:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_default"<?= ($cms_body_default == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to set to be the default page body (other page bodies with default are turned off, only one allowed), uncheck to make a normal body. In the absence of a default page body the lowest enabled page body order is used.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_nomenu',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">No Menu:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_nomenu"<?= ($cms_body_nomenu == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						 Body is NOT shown in menu, body/app is an accessory or helper application.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_login_page',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Login Page:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_login_page"<?= ($cms_body_login_page == 1 ? ' CHECKED':'');?>
							onclick="return confirm('This will be the only login page. Are you sure?')"
							/>
					</td>
					<td class="page_config">
						Check to set to be the login page body (other page bodies with login are turned off, only one allowed), uncheck to make a normal body. In the absence of a login page body any page may have login link to login functions.).
						<br>
						<?= Ccms::make_message_text('If this page does NOT have a login form with a POST with username and password to URL index.php?action=login you will not be able to login.','warn') ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_login_required',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Login Required:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_login_required"<?= ($cms_body_login_required == 1 ? ' CHECKED':'');?>
							/>
					</td>
					<td class="page_config">
						Check to allow this body/application to only appear when logged in. Not allowed on login page.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_enabled',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Enabled:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_enabled"<?= ((($cms_body_enabled == 1) || ($cms_body_op == 'add')) ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to enable body / application, uncheck to disable body / application.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_ssl',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">SSL:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_ssl"<?= ($cms_body_ssl == 1 ? ' CHECKED':'');?> <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Check to enable SSL only protocol on the body, uncheck to use default protocol.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_full_view',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Full Body View:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_full_view"<?= ($cms_body_full_view == 1 ? ' CHECKED':'');?> <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Check to use the entire body page. It contains all the page details. (i.e. no header, nav bar, left column or footer output by the AppsCMS, but there functionality can be included by the full view page code). The AppsCMS still outputs the head variables and checkes the login state.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_iframe_view',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Iframe Body View:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_iframe_view"<?= ($cms_body_iframe_view == 1 ? ' CHECKED':'');?> <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Check to use the body page in an iframe.
						The page header, left column, right column and footer remain as configured.
						<b>Notes:</b>
						<ul class="page_config cols">
							<li class="page_config">
								Full body view overrides this iframe setting.
							</li>
							<li class="page_config">
								The page must be part of this web site (directing to external web sites is not supported).
							</li>
							<li class="page_config">
								The page is a stand alone website.
							</li>
							<li class="page_config">
								When the iframe request is received, the iframe setting here is disabled and the
								<b>full body view setting</b> is enabled, allow the web to fully generated from application body code.
							</li>
							<li class="page_config">
								SSL protocol is used with iframe applications / bodies.
							</li>
						</ul>

					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_cached',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Cached:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_cached"<?= ($cms_body_cached == 1 ? ' CHECKED':'');?> <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Check to allow content caching (if content cache is enabled), uncheck to disable caching.
						<br>
						<b>IMPORTANT NOTE:</b> Pages / applications with dynamic content should not be cached, only page that have static content should be cached (e.g. a simple intro or contact page).
						<br> User&rsquo;s cached contents are cleared at login.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_debug_only',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Debug:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_debug_only"<?= ($cms_body_debug_only == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to allow content only in debug mode (not seen in production mode), uncheck to allow in any mode.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_default_msgs',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Messages:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_default_msgs"<?= ($cms_body_default_msgs == 1 ? ' CHECKED':'');?> <?= ($cms_body_installed ? ' readonly':'') ?>/>
					</td>
					<td class="page_config">
						Check to allow default message read operation, uncheck to use message reads in page code only.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_icon_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Icon URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('cms_body_icon_url', $cms_body_icon_url, $icon_paths,'',false) ?>
					</td>
					<td class="page_config">
						An icon or small logo used in navigation bars and menu.
						On small devices the icon replaces text.
						Stored in the "<?= ETC_WS_ICONS_DIR ?>" directory,
						in the "<?= APPS_WS_ICONS_DIR ?>" directory or
						the application&rsquo;s &quot;<?= APPS_WS_DIR . $cms_body_dir . '/icons/' ?>&quot; icon directory.
						<br>
						<?= Ccms::get_body_icon_uri($body,'(no icon set)') ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_image_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Image URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('cms_body_image_url', $cms_body_image_url, $image_paths,'',false) ?>
					</td>
					<td class="page_config">
						An image associated with the page or application.
						Can be used with the page or application for special purposes.
						Stored in the "<?= ETC_WS_IMAGES_DIR ?>" directory,
						in the "<?= APPS_WS_IMAGES_DIR ?>" directory or
						the application&rsquo;s &quot;<?= APPS_WS_DIR . $cms_body_dir . '/images/' ?>&quot; images directory.
						<br>
						<?= Ccms::get_body_image_uri($body,'(no image set)') ?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_crontab_enable',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Cron Job Enable:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_crontab_enable"<?= ($cms_body_crontab_enable == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to allow standard application CRON job, uncheck to disable application CRON job.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_crontab_time',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Crontab Timing:</th>
					<td class="page_config" colspan="2">
						Enter the application crontab timing.<br>
						<?= $cCMS_C->inp_cron_times('cms_body_crontab_time', $cms_body_crontab_time);?>
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_crontab_job',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Cron Job Script:</th>
					<td class="page_config">
						<?=  Ccms::get_body_app_run_scripts('cms_body_crontab_job',$cms_body_crontab_job,' -- Select Cron Script -- ',$cms_body_dir) ?>
					</td>
					<td class="page_config">
						Select the CRON job script to use from &quot;<?= APPS_WS_DIR . $cms_body_dir . '/cli' ?>&quot; directory to engage CRON job.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_readme_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Readme:</th>
					<td class="page_config">
						<?=  Ccms::get_body_dir_selection('cms_body_readme_url',$cms_body_readme_url,
								' - Select Readme File - ',$cms_body_dir . '/docs') ?>
					</td>
					<td class="page_config">
						The readme URI for the use of the page or application.
						It is a URI to a file in the &quot;<?= APPS_WS_DIR . $cms_body_dir . '/docs' ?>&quot; directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_release_notes_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Release Notes:</th>
					<td class="page_config">
						<?=  Ccms::get_body_dir_selection('cms_body_release_notes_url',$cms_body_release_notes_url,
								' - Select Release Notes File - ',$cms_body_dir . '/docs') ?>
					</td>
					<td class="page_config">
						The release notes URI for the use of the page or application.
						It is a URI to a file in the &quot;<?= APPS_WS_DIR . $cms_body_dir . '/docs' ?>&quot; directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_terms_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Terms of Use:</th>
					<td class="page_config">
						<?=  Ccms::get_body_dir_selection('cms_body_terms_url',$cms_body_terms_url,
								' - Select Terms of Use File - ',$cms_body_dir . '/docs') ?>
					</td>
					<td class="page_config">
						A Terms of Use or Terms and Conditions URI for the use of the page or application.
						It is a URI to a file in the &quot;<?= APPS_WS_DIR . $cms_body_dir . '/docs' ?>&quot; directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_terms_upfirst',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Agreed to Terms:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_body_terms_upfirst"<?= ($cms_body_terms_upfirst == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Show the terms and conditions as a EULA on application first use.
						<br>
						<b>NOTE:</b> The <?= CMS_PROJECT_SHORTNAME ?> config &quot;EULA Enable&quot; needs to enabled for this setting to work.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_acknowledgment_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Acknowledgment:</th>
					<td class="page_config">
						<?=  Ccms::get_body_dir_selection('cms_body_acknowledgment_url',$cms_body_acknowledgment_url,
								' - Select Acknownledgement File - ',$cms_body_dir . '/docs') ?>
					</td>
					<td class="page_config">
						An acknowledgment URI for third party content used in the page or application.
						It can be a full URL or a URI to a file in &quot;<?= APPS_WS_DIR . $cms_body_dir . '/docs' ?>&quot; directory.
					</td>
				</tr>
<?php	} // if
	if(!in_array('cms_body_licence_url',$not_allowed_chgs)) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Licence:</th>
					<td class="page_config">
						<?=  Ccms::get_body_dir_selection('cms_body_licence_url',$cms_body_licence_url,
								' - Select Licence File - ',$cms_body_dir . '/docs') ?>
					</td>
					<td class="page_config">
						A licence URI for content used in the page or application.
						It can be a full URL or a URI to a file in &quot;<?= APPS_WS_DIR . $cms_body_dir . '/docs' ?>&quot; directory.
					</td>
				</tr>
<?php	} // if ?>
			</table>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: right;">
			<button onclick="cms_setView('ws_config');" type="button" disabled="true">Config</button>
			&nbsp;&nbsp;
		<?php if($is_editable_viewable) { ?>
			<button onclick="cms_setView('ws_text_input');" type="button" title="Goto edit page body <?= (Ccms::$cms_page_info['html_wysiwyg_allow'] ? '(' . $cWYSIWYG->get_wysiwyg_title() . ')':'') ?>.">Editor</button>
			<?php if(preg_match('/\.htm$|\.html$/i',$cms_body_file)) { ?>
			&nbsp;&nbsp;
			<button onclick="cms_setView('ws_text_view');" type="button" title="Goto to view page body.">View</button>
			<?php	} // if ?>
			&nbsp;&nbsp;
		<?php	} // if ?>
			<?php if($cms_body_id == 0) { ?>
			<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
		<?php if(!$is_link && !$cms_body_installed) { ?>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
		<?php	} // if ?>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>
	<?php } else if(($cms_body_op == 'delete') && (isset($cms_body_id)) && ($cms_body_id > 0)) { ?>
	<tr class="page_config"><th class="page_config">Delete App/Body - <?= $cms_body_name ?></th></tr>
	<input type="hidden" name="cms_body_id" value="<?= $cms_body_id ?>"/>
	<input type="hidden" name="cms_body_name" value="<?= htmlentities($cms_body_name) ?>"/>
	<tr class="page_config">
		<td class="page_config">
			Please confirm.
			<?php if(!empty($cms_apps_names_msg)) echo $cms_apps_names_msg ?>
			&nbsp;&nbsp;
			<input type="checkbox" name="cms_body_delete_only" title="Delete only the page body, don't change the <?= APPS_WS_DIR . $cms_body_dir ?> directory." CHECKED/>
			&nbsp;&nbsp;
			<button name="confirm_delete" value="confirm_delete" type="submit" onclick="Ccms_cursor.setWait();">Confirm Delete</button>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>
	<?php	} ?>

	<?php if($cms_body_op != 'delete') { ?>
	<tr class="page_config"><th class="page_config">Page Body / Application Summary</th></tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			Page bodies and applications configuration.
			See <a href="index.php?cms_action=cms_manual" target="_blank">Technical Manual</a> for more information.
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<?php include( CMS_FS_OPS_DIR . 'cms_edit_bodies_list.php') ?>
		</td>
	</tr>
	<?php	} ?>

</table>

</span>


<?php
if((($cms_body_op == 'edit') || ($cms_body_op == 'save') ||
	($cms_body_op == 'add') || ($cms_body_op == 'insert')) &&
	(isset($cms_body_id))) {
	$cms_body_filepath = APPS_BODIES_FS_DIR . $cms_body_file;
	if((!empty($cms_body_file)) && (file_exists($cms_body_filepath)) && (is_readable($cms_body_filepath)) &&
		(($fs = filesize($cms_body_filepath)) > 2) &&
		($fh = @fopen($cms_body_filepath,'r'))) {
		$body_text = fread($fh,$fs);
		if(isset($fh)) fclose($fh);
		} // if
	else {	// new or lost file
		$body_text = make_new_body_text();
		} // else
	$page_name = (!empty($cms_body_name) ? $cms_body_name . (!empty($cms_body_file) ? ' (' . $cms_body_file . ')':''):'New');

	if($is_editable_viewable) {
		include(CMS_FS_OPS_DIR . 'cms_edit_bodies_editor.php');
		} // if
	} // if
?>

</form>

<script type="text/javascript">
	// window.onload = cms_setView('ws_config');
</script>

<?php
Ccms::page_end_comment(__FILE__);
