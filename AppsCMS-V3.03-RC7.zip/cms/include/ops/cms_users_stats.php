<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_users_stats.php 2795 2022-09-10 09:37:50Z robert0609 $
 */

/**
 * Description of session_browser
 * general AppsCMS session browser
 *
 * @author robert0609
 */

$csv = array();

$filter = Ccms_search::get_form_search_input_keywords_ary();
$exact = Ccms::get_or_post_checkbox('exact');
$show_expired = Ccms::get_or_post_checkbox('show_expired');
if(!$filter) $filter = array();

function help() {
	$text = "Enter search keywords, separated by spaces, to search dates, names, etc. in users.";
	return $text;
	} // help()

//function bool_user(&$val) {
//	if(is_array($val)) {
//		foreach($val as $k => &$v) {
//			bool_user($v);	// recurse
//			} // foreach
//		} // if
//	if($val === true) $val = '(bool true)';
//	else if($val === false) $val = '(bool false)';
//	} // bool_user()

function filter_user_stat(&$filter,$n,&$v,$exact) {
	if(empty($filter)) return '';	// show all
	if(empty($n)) return false;

//	bool_user($v);
	$str = strtolower((empty($n) ? '':$n));
	$txt = str_replace(PHP_EOL," ",print_r($v,true));
	$str .= ' ' . strtolower($txt);
	if(empty($str)) return false;
	$meta = Ccms_search::search_cmp($filter, $str,$exact);
	if(!$meta) return false;
	return Ccms_search::make_meta_search_text($meta);
} // filter_user_stat()

//	The contents of CMS_FS_CMS_USER_DEFAULT json;-
//	{
//		"username": "",
//		"cms_user": {
//			"cms_user_ip_addr": 0,
//			"cms_user_eula_time": 0,
//			"cms_user_cookie_banner_time": 0,
//			"cms_user_login_cookie_time": 0,
//			"cms_user_login_count": 0,
//			"cms_user_last_login": 0,
//			"cms_user_last_logoff": 0,
//			"cms_user_access_count": 0,
//			"cms_user_access_time": 0
//			}
//	}

function pretty_user(&$filter,&$cms_user,$idx,&$csv_row) {
	if(empty($cms_user[$idx])) $txtx = 'N.A.';
	else {
		switch($idx) {
		case "cms_user_eula_time":
		case "cms_user_cookie_banner_time":
		case "cms_user_login_cookie_time":
		case "cms_user_last_login":
		case "cms_user_last_logoff":
		case "cms_user_access_time":
			$txtx = Ccms::get_localtime_from_utc($cms_user[$idx]);
			// $txtx = date('Y-m-d H:i:s',$cms_user[$idx]) .'Z';
			break;
		case "cms_user_access_count":
		case "cms_user_login_count":
		case "cms_user_ip_addr":
			$txtx = $cms_user[$idx];
			break;
		default:	// what
			$txt = print_r($cms_user,true);
			$txt = str_replace(PHP_EOL,"\t\n",$txt);
			$txtw = wordwrap($txt, 80, "\n\t->\t", true);
			$txtx = preg_replace('/\n\t->\t\[/',' [',$txtw);	// remove over wrapped
			break;
			} // switch
		} // else
	$csv_row[] = $txtx;
	$txt = Ccms::hilite_filter($filter, $txtx);
//	$txt = "<pre>" . $txt . "</pre>";

	return $txt;
} // pretty_user()

$cms_users_stats = Ccms::get_or_post('cms_users_stats');

$users_stats = Ccms_general::get_users_stats();
$last_line_num = count($users_stats);

$lines_max = Ccms::get_or_post('lines_max');
if((!$lines_max) || ($lines_max > 100)) $lines_max = 100;
if($lines_max > 1000) $lines_max = 1000;

$line_start = 1;
if(Ccms::is_get_or_post('next')) $line_start += $lines_max;
else if(Ccms::is_get_or_post('prev')) $line_start -= $lines_max;
if($line_start < 1) $line_start = 1;
$line_end = $line_start + $lines_max - 1;

?>

<?php if(!Ccms::is_get_or_post('ajax')) { ?>
<?php Ccms::page_start_comment(__FILE__) ?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<script type="text/javascript">
	var last_ajax_run_call = null;
	var ajax_running = false;
	var ajax_deb = 1200;
	function ajax_run(id) {
		if(ajax_running) return;
		if(last_ajax_run_call != null) {	// clear it
			window.clearTimeout(last_ajax_run_call);
			last_ajax_run_call = null;
			} // if
		// restart if
		last_ajax_run_call = window.setTimeout(function(id) {
			// return;	// test
			ajax_running = true;
			var min_l = 2;
			var keywords = document.getElementById(id).value.toString();
			if((keywords.length < min_l) ||
				(keywords.length == 0)) {
				document.getElementById('page_contents_ajax').innerHTML = "Minimum of " + min_l + " characters required.";
				ajax_running = false;
				return;
				} // if
			var fb = document.getElementById('id_form_keywords');	// save in the form too
			if(fb) fb.value = keywords;
			keywords = encodeURI(keywords);
			var exact = document.getElementById(id + '_exact').checked;
			var show_expired = document.getElementById(id + '_show_expired').checked;
			var body_url = 'cms_users_stats&search=' + keywords + (exact ? '&exact=on':'') + (show_expired ? '&show_expired=on':'');
			cms_ajax_body_page(body_url,'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
			ajax_running = false;
			return;
			},
		ajax_deb, id);
		} // ajax_run()
</script>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config" style="text-align: left">
			<h1 class="page_config">User Statics</h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form method="post" name="cms_users_stats" action="index.php?cms_action=cms_users_stats">
				<?= Ccms_search::get_form_search_hidden_inputs() ?>
				<input type="text"
					id="keywords_inp"
					name="keywords_inp" size="40"
					oninput="javascript:ajax_run('keywords_inp');"
					value="<?= implode(' ',$filter) ?>"
					style="width: unset;"
					title="<?= help() ?>" autofocus autocapitalize="off"/>
				<button name="search" value="search" type="submit" onclick="Ccms_cursor.setWait();" title="Start the search.">Search</button>
				<label>Exact:
					<input type="checkbox"  id="keywords_inp_exact" name="exact"
						onchange="this.form.submit();"
						title="Check for exact match." <?= (Ccms::get_or_post_checkbox('exact') ? ' CHECKED':'') ?>
						/>
				</label>
				<label>Expired:
					<input type="checkbox"  id="keywords_inp_show_expired" name="show_expired"
						onchange="this.form.submit();"
						title="Show expired sessions." <?= (Ccms::get_or_post_checkbox('show_expired') ? ' CHECKED':'') ?>
						/>
				</label>
			</form>
		</td>
	</tr>
</table>
<span id="page_contents_ajax">
<?php	} // if ?>
	<table class="page_config">
<?php if(!empty($users_stats)) { ?>
		<form name="cms_users_stats" action="index.php?cms_action=cms_users_stats" method="post" enctype="multipart/form-data">
		<input type="hidden" name="cms_users_stats" value="<?= urlencode($cms_users_stats) ?>"/>
		<input type="hidden" name="start_line" value="<?= $line_start ?>"/>
		<tr class="page_config">
			<td class="page_config">
				<select name="lines_max" onchange="this.form.submit()" style="width: 50px;" title="Sessions per page.">
<?php
		$lines_max_tab = array(10,20,50,100,200,500,1000);
		foreach($lines_max_tab as $ml) {
			if($ml >= $last_line_num) $lines_max = $ml;
			echo '					<option value="' . $ml . '"' . (($ml == $lines_max) ? ' SELECTED':'') . '>' . $ml . '</option>';
			if($ml > $last_line_num) break;
			} // foreach
?>
				</select> users.
<?php	if($line_start > 1) { ?>
				<button type="submit" onclick="Ccms_cursor.setWait();" name="prev" value="prev" title="Click for previous page.">Previous</button>
<?php		} // if ?>
<?php	if((int)$last_line_num > $line_end) { ?>
				<button type="submit" onclick="Ccms_cursor.setWait();" name="next" value="next" title="Click for next page.">Next</button>
<?php		} // if ?>

					Server local time set to: <?= date_default_timezone_get() ?>
				</td>
			</tr>
			<tr class="page_config">
				<td class="page_config">
					<table class="page_config">
						<tr class="page_config">
							<th class="page_config" style="text-align: center;">User</th>
							<th class="page_config" style="text-align: left;">IP Address</th>
							<th class="page_config" style="text-align: left;">Accessed</th>
							<th class="page_config" style="text-align: left;">Last Access</th>
							<th class="page_config" style="text-align: left;">Logins</th>
							<th class="page_config" style="text-align: left;">Last Login</th>
							<th class="page_config" style="text-align: left;">Last Logoff</th>
							<th class="page_config" style="text-align: left;">EULA Time</th>
							<th class="page_config" style="text-align: left;">Cookie Accepted</th>
							<th class="page_config" style="text-align: left;">Remember Login To</th>
							<th class="page_config" style="text-align: center;">Expired</th>
						</tr>
<?php

				$csv[] = array(	// csv header row
					'User','IP Address','Accessed','Last Access','Logins','Last Login','Last Logoff',
					'EULA Time','Cookie Accepted','Remember Login To','Expired');
				$row = 0; $line_num = 0;
				$cnt = 0;
				ksort($users_stats);
				foreach($users_stats as $v) {	// do user defined
					$data = &$v['data'];
					$n = $data['username'];
					// remove unused
					unset($data['_JSON_ModTime']);
					unset($data['_JSON_ModUser']);
					$cms_user = &$data['cms_user'];
					$csv_row = array();
					if(($meta = filter_user_stat($filter,$n,$cms_user,$exact)) === false) continue;
					echo '	<tr class="' . (($cnt++ & 1) ? 'page_config_odd':'page_config_even') . '">' . PHP_EOL;

					echo '		<td class="page_config" style="font-weight: bold;">' . Ccms::hilite_filter($filter, $n) . $meta . '</td>';
					$csv_row[] = Ccms::hilite_filter($filter, $n);;	// . $meta;

					echo '<td class="page_config">' . pretty_user($filter,$cms_user,'cms_user_ip_addr',$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,'cms_user_access_count',$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,'cms_user_access_time',$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,'cms_user_login_count',$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,'cms_user_last_login',$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,'cms_user_last_logoff',$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,"cms_user_eula_time",$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,"cms_user_cookie_banner_time",$csv_row) . '</td>';
					echo '<td class="page_config">' . pretty_user($filter,$cms_user,"cms_user_login_cookie_time",$csv_row) . '</td>';

					echo '<td class="page_config">' . ($v['expired'] ? 'Yes':'No') . '</td>';
					$csv_row[] = ($v['expired'] ? 'Yes':'No');
					echo PHP_EOL . '	</tr>' . PHP_EOL;
					$csv[] = $csv_row;
					} // foreach
				//Ccms_base::unset_cms_sess_var('download_dir');
				//Ccms_base::unset_cms_sess_var('download_file');
				if($cnt == 0) {
					echo '	<tr><td class="page_config">' .'Nothing found.' . '</td></tr>';
					} // if
				else {	// save CSV and setup download
					$user = Ccms_auth::get_logged_in_username();
					$csv_file = rawurlencode($user) . '-user_stats_tmp.csv';
					$csv_dl_tmp = VAR_FS_EXPORT_DIR . $csv_file;
					if($fp = fopen($csv_dl_tmp, 'w')) {
						foreach ($csv as $fields) {
							fputcsv($fp, $fields);
							} // foreach
						fclose($fp);
						Ccms_base::set_download_dir(VAR_FS_EXPORT_DIR);
						$dl_url = (self::is_ssl_required() ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?download_file=' . rawurlencode($csv_file);
						echo '<tr><td class="page_config" colspan="10">' .
							'<button name="download_file" value="download_file" type="button" title="Click to download CSV." onclick="window.open(\'' . $dl_url . '\');">Download CSV</button>' .
							'</td></tr>' . PHP_EOL;
						} // if
					} // else
				} // if
?>
				</table>
			</td>
		</tr>
		<input type="hidden" name="last_line_num" value="<?= $line_num ?>"/>
		<tr class="page_config">
			<td class="page_config">
<?php	if($line_start > 1) { ?>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="prev" value="prev" title="Click for previous page.">Previous</button>
<?php		} // if ?>
<?php	if($line_num > $line_end) { ?>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="next" value="next" title="Click for next page.">Next</button>
<?php		} // if ?>
			</td>
		</tr>
		</form>
	</table>

<?php
if(!Ccms::is_get_or_post('ajax')) {
	echo '</span>';
	Ccms::page_end_comment(__FILE__);
	} // if

