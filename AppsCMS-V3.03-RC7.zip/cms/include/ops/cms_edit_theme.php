<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_theme.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

$cms_theme_id = 0;
$cms_theme_op = '';
if(Ccms::get_cms_action() == 'cms_edit_theme') { // a bit of caution
	if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('edit_options_ary')) &&
		(is_array(Ccms::get_or_post('edit_options_ary')))) {
		$theme = Ccms::get_or_post('edit_options_ary');

		// get any background images
		$img_idxs = array('BODY_BKGD_IMAGE','HEADER_BKGD_IMAGE','FOOTER_BKGD_IMAGE','NAV_BAR_ELEM_BKGD_IMAGE','NAV_BAR_ELEM_HOVER_BKGD_IMAGE','PAGE_BODY_BKGD_IMAGE','SM_BKGD_IMAGE');  // same index as $theme['ThemeSettings']
		$cCMS_C = new Ccms_config();
		foreach($img_idxs as $n) {
			$theme['ThemeSettings'][$n] = $cCMS_C->get_image($n, '', ETC_FS_BACKGROUNDS_DIR);
//			$idx = $n . '_new';
//			if((isset($_FILES[$idx]['name'])) && (!empty($_FILES[$idx]['name']))) {
//				$i = $cCMS_C->get_image($idx, '', ETC_WS_BACKGROUNDS_DIR);
//				$theme['ThemeSettings'][$n] = $i;
//				} // if
//			else if((isset($_POST[$n]))) $theme['ThemeSettings'][$n] = $_POST[$n];
			} // foreach

		// put borders, etc. back together and strip browser back slashes
		Ccms_options::convert_ini_cms_form_input($theme);
		Ccms::save_cms_ini_settings($theme);

		Ccms::unset_get_or_post('save');
		Ccms::unset_get_or_post('edit_options_ary');
		} // if
	else if((Ccms::is_get_or_post('reloadINI')) && (Ccms::get_or_post('reloadINI') == 'reloadINI')) {
		if(Ccms::reload_ini_default_settings()) {
			Ccms::addMsg("Set theme to default settings.",'info');
			} // if
		$cms_theme_op = '';
		$cms_theme_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_theme_op = 'cancel';
		$cms_theme_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('name')) {
		$cms_theme_op = 'scroll';
		$cms_theme_id = Ccms::get_or_post('name');
		} // else if
	} // if
?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php
	$h1 = 'Theme Configuration';
	$conf = Ccms::read_cms_ini_settings(false,Ccms::get_install_ini_sections());
	$comments = Ccms::read_cms_ini_comments(false,Ccms::get_install_ini_sections());
	new Ccms_edit('cms_edit_theme', $h1, $conf, $comments);

Ccms::page_end_comment(__FILE__);
