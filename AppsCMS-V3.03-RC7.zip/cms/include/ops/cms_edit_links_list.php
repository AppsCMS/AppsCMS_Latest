<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_links_list.php 2898 2022-10-20 11:20:40Z robert0609 $
 */


if(Ccms::get_cms_action() == 'cms_edit_links') { // a bit of caution
	if(($lm_link_qk_op = Ccms::get_or_post('lm_link_qk_op')) &&
		($lm_link_qk_id = Ccms::get_or_post('lm_link_qk_id'))) {	// single value change
		switch($lm_link_qk_op) {
		case 'edit_link_qk_section':
			if($lm_link_qk_section_id = Ccms::get_or_post('lm_link_qk_section_id')) {
				$sql = "UPDATE lm_links SET lm_link_section_id = " . (int)$lm_link_qk_section_id . ' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
				if(!Ccms::$cDBcms->query($sql)) {
					Ccms::addMsg('Failed to update link section.');
					} // if
				} // if
			break;
		case 'edit_link_input':
			if(($lm_link_qk_type = Ccms::get_or_post('lm_link_qk_type')) &&
				($lm_link_qk_name = Ccms::get_or_post('lm_link_qk_name')) &&
				($lm_link_qk_value = Ccms::get_or_post('lm_link_qk_value'))) {
				$sql = false;
				switch($lm_link_qk_type) {
				case 'checkbox':
					switch($lm_link_qk_name) {
					case 'lm_link_qk_delete': // confirm already checked
						if($lm_link_qk_value == 'on') {
							$sql = "DELETE FROM lm_links" .
								' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
							} // if
						break;
					default:
					$sql = "UPDATE lm_links SET " . $lm_link_qk_name . " = '" . (($lm_link_qk_value == 'on') ? 1:0) . "'" .
						' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
					break;
						} // switch
					break;
				case 'number':
					$sql = "UPDATE lm_links SET " . $lm_link_qk_name . " = " . (int)$lm_link_qk_value . "" .
						' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
					break;
				default:	// treat the rest as text
					$sql = "UPDATE lm_links SET " . $lm_link_qk_name . " = '" . $lm_link_qk_value . "'" .
						' WHERE lm_link_id = ' . (int)$lm_link_qk_id;
					break;
					} // switch
				if(!Ccms::$cDBcms->query($sql)) {
					Ccms::addMsg('Failed to update link ID: ' . (int)$lm_link_qk_id . ', name: ' . $lm_link_qk_name . '.');
					} // if
				else Ccms::addDebugMsg('Updated link ID: ' . (int)$lm_link_qk_id . ', name: ' . $lm_link_qk_name . '.','success');
				} // if
			break;
		default:
			break;
			} // switch
		$lm_link_qk_id = 0;
		$lm_link_qk_op = '';
		} // if
	} // if
$edit_link_qk_section_filter = Ccms::get_or_post_keyed_session_var('edit_link_qk_section_filter');
$edit_link_qk_section_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_link_qk_section_enabled');

$edit_link_qk_link_filter = Ccms::get_or_post_keyed_session_var('edit_link_qk_link_filter');
$edit_link_qk_link_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_link_qk_link_enabled');

if((!Ccms::is_get_or_post('link_edit_id')) &&
	(Ccms::get_or_post('lm_link_qk_anchor') != '_null')) {	// return anchor
	$edit_link_qk_anchor = Ccms::get_or_post_keyed_session_var('lm_link_qk_anchor');
	} // if
else $edit_link_qk_anchor = false;	// edit the link
$layout_data = Ccms_lm_filter::find_sections_links_layout(
	array(
		'section' => array(
			'enabled' => $edit_link_qk_section_enabled,
			'keywords' => $edit_link_qk_section_filter,
			),
		'link' => array(
			'enabled' => $edit_link_qk_link_enabled,
			'keywords' => $edit_link_qk_link_filter,
			'anchor' => $edit_link_qk_anchor,
			),
		),true,true);	// generates a heirachical array of required links with orphans
$row_cnt = 0;

function out_link_section_by_parent(&$row_cnt,&$layout_data,$layout_idx,$heading) {
	static $rec_cnt = 0;
	static $cCMS_C = false;
	static $done = array();
	if($rec_cnt > 100) return false;
	$rec_cnt++;
	if(!$cCMS_C) $cCMS_C = new Ccms_config();
	$ret_anch = '';
	$one_down = array();
	if(!empty($layout_data[$layout_idx])) {
		echo '				<table class="page_config">';
		$last_sect_id = false;
		foreach($layout_data[$layout_idx] as $section_id => &$v) {
			if(empty($v['data']['lm_section_id'])) continue;
			$section = &$v['data'];
			$sel_params = ' onclick="lm_select_fill_options(event,this);"' .
				' onchange="lm_select_fill_options(event,this)" size="1"';
			if(!empty($v['links'])) {	// has links in section
				$links = &$v['links'];
?>
					<tr class="page_config" ondblclick="toggle_lm_edit_section_links(this,event,'<?= $section_id ?>');">
						<th width ="25px" class="page_config" title="Double click to collapse/expand section.">
							<img alt="bin" style="height: 20px;" src="<?= CMS_WS_ICONS_DIR ?>bin.gif"/>
						</th>
						<th width="150px" class="page_config" style="padding-left: 10px;"
							title="<?= strip_tags($section['lm_section_description']) . '\n' . $section['lm_section_title'] ?>">
							<a href="index.php?cms_action=cms_edit_sections&section_edit_id=<?= $section['lm_section_id'] ?>"
								title="Click to edit section.">
								<?= $heading . ' ' .$section['lm_section_name'] ?>
							</a>
						</th>
						<th width="150px" class="page_config" title="Link name">Link</th>
						<th class="page_config" style="text-align: center;" title="Link image">Image</th>
						<th class="page_config" style="text-align: center;" title="Link icon">Icon</th>
						<th width="70px" class="page_config" title="Display order">Order</th>
						<th width="70px" class="page_config">Enabled</th>
						<th width="40px" class="page_config" title="Use SSL encryption">SSL</th>
						<th width="40px" class="page_config" title="In a new tab/window">New</th>
						<th width="50px" class="page_config" title="Add name to URL">Add Name</th>
						<th class="page_config">Description</th>
						<th class="page_config">Comments</th>
					</tr>
<?php

				foreach($links as $lm_link_id => &$vl) {
					$link = &$vl['data'];
					$ret_anch = 'anch_link_' . $link['lm_link_id'];
					$titex = (!empty($link['lm_link_url']) ? '\n(' . $link['lm_link_url'] . ')':'');
?>
					<tr class="<?= (($row_cnt & 1) ? 'page_config_odd':'page_config_even') ?>" id="id_link_row[<?= $section_id ?>][<?= $lm_link_id ?>]">
						<td class="page_config" style="text-align: left">
							<input type="checkbox" name="lm_link_qk_delete"
								onchange="if(confirm('Delete link: '<?= $link['lm_link_name'] ?>.'))
									submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								title="Delete link: <?= $link['lm_link_name'] ?>"/>
						</td>
						<td class="page_config" style="text-align: left">
							<a name="<?= $ret_anch ?>"></a>
							<form name="link_qk_section_edit" action="<?= $_SERVER['PHP_SELF'] ?>" method="get">
								<?php echo Ccms::gen_link_section_js_selection_list('lm_link_qk_section_id', $section['lm_section_id'],$sel_params, false, true, false); ?>
								<input type="hidden" name="cms_action" value="cms_edit_links"/>
								<input type="hidden" name="lm_link_qk_id" value="<?= $link['lm_link_id'] ?>"/>
								<input type="hidden" name="lm_link_qk_op" value="edit_link_qk_section"/>
								<input type="hidden" name="edit_link_qk_section_filter" value="<?= (!empty(urlencode($layout_data['filt']['section']['keywords'])) ?:'') ?>"/>
								<input type="hidden" name="lm_link_qk_anchor" value="<?= $ret_anch ?>"/>
							</form>
						</td>
						<td class="page_config" style="text-align: left">
							<a href="index.php?cms_action=cms_edit_links&link_edit_id=<?= $link['lm_link_id'] ?>&lm_link_qk_anchor=_null"
								title="Click to edit link: '<?= strip_tags($link['lm_link_title']) . (($link['lm_link_new_page'] && CMS_C_SHOWINNEWTAB) ? ' (in a new tab)':'') . $titex ?>">
								<?= (Ccms::is_debug() ? 'ID: ' . $link['lm_link_id'] . ', ':'') . $link['lm_link_name'] ?>
							</a><?= (!$link['lm_link_enabled'] ? '<br>(disabled)':'') ?>
						</td>
						<td class="page_config" style="text-align: center">
							<?= $cCMS_C->show_image($link['lm_link_image_url'],ETC_WS_IMAGES_DIR,'page_config'); ?>
						</td>
						<td class="page_config" style="text-align: center">
							<?= $cCMS_C->show_image($link['lm_link_icon_url'],ETC_WS_ICONS_DIR,'page_config'); ?>
						</td>
						<td class="page_config" style="text-align: left">
							<input type="number" name="lm_link_order" size="5"
								value="<?= $link['lm_link_order'] ?>"
								style="width: 40px;"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								autocapitalize="off"/>
						</td>
						<td class="page_config" style="text-align: left">
							<input type="checkbox" name="lm_link_enabled"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								<?= ($link['lm_link_enabled'] == 1 ? ' CHECKED':'') ?>/>
						</td>
						<td class="page_config" style="text-align: left">
							<input type="checkbox" name="lm_link_ssl"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								<?= ($link['lm_link_ssl'] ? ' CHECKED':'') ?>/>
						</td>
						<td class="page_config" style="text-align: left">
							<input type="checkbox" name="lm_link_new_page"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								<?= ($link['lm_link_new_page'] ? ' CHECKED':'') ?>/>
						</td>
						<td class="page_config" style="text-align: left">
							<input type="checkbox" name="lm_link_add_name2url"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								<?= ($link['lm_link_add_name2url'] ? ' CHECKED':'') ?>/>
						 </td>
						<td class="page_config" style="text-align: left">
							<input type="text" name="lm_link_description"
								value="<?= $link['lm_link_description'] ?>"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								autocapitalize="off"/>
						</td>
						<td class="page_config" style="text-align: left">
							<input type="text" name="lm_link_comments"
								value="<?= $link['lm_link_comments'] ?>"
								onchange="submit_edit_link_qk_section_input(event,this,'<?= $link['lm_link_id'] ?>','<?= $ret_anch ?>');"
								autocapitalize="off"/>
						</td>
					</tr>

<?php					
					$row_cnt++;
					echo '  <!-- Link Row Cnt: ' . $row_cnt . ' -->' . PHP_EOL;
					} // foreach
				} // if
			else {
?>
					<tr class="page_config">
						<td class="page_config" style="text-align: left" colspan="12">
							No links in section: <b><?= $section['lm_section_name'] ?></b>.
						</td>
					</tr>
<?php	
				// flush();
				} // else
			if(!empty($v['sections'])) $one_down[] = &$v;	// accumulate for end of section
			} // foreach
		if(!empty($one_down)) {
			foreach($one_down as $sect) {
				$sect['filt'] = &$layout_data['filt'];
?>
					<tr class="page_config" id="id_link_row[<?= $section_id ?>][sub_sections]">
						<td class="page_config" style="text-align: left" colspan="12">
							<?php out_link_section_by_parent($row_cnt,$sect,$layout_idx,$heading); ?>
						</td>
					</tr>
<?php	
				} // foreach	
			} // if
		echo '				</table>';
		} // if
	if($rec_cnt > 0) $rec_cnt--;
	return true;
	} // out_link_section_by_parent()

Ccms::page_start_comment(__FILE__) 
?>

			<script type="text/javascript">
				var lm_select_sect_opts = <?= Ccms_base::json_encode((object)Ccms_html::gen_section_selection_options(0,false,true,false), JSON_PRETTY_PRINT) ?>;
				function lm_select_fill_options(event,sel_obj) {
					if(event.type == 'change') {
						sel_obj.form.submit();
						return true;
						} // if
					else if((event.type == 'click') &&
						(sel_obj.options.length < 5)) {	// 5 ?!?!
						// fill select options
						sel_obj.onclick = null;	// stop further click events
						var seld_option = false;
						try {
							seld_option = sel_obj.options[sel_obj.selectedIndex];	// get currect selected
							}
						catch(e) {
							seld_option = false;
							}
						// fill select options
						sel_obj.options.length = 0;	// clear it
						for(var i in lm_select_sect_opts) {
							var s_opt = lm_select_sect_opts[i];
							var seld = false;
							if(seld_option.value == s_opt.value) seld = true
							var n_opt = document.createElement("option");
							n_opt.value = s_opt.value;
							n_opt.text = s_opt.text;
							n_opt.selected = seld;
							// n_opt.style = s_opt.style;
							sel_obj.appendChild(n_opt);
							} // for
						return true;
						} // if
					return false;
					} // lm_select_fill_options()

				var last_edit_link_qk_section_filter_call = null;
				function chk_link_section_filter(event,obj) {
					if(event.keyCode == 13) {
						obj.form.submit();
						return true;
						} // if
					if((event.type == 'click') &&
						(obj.type == 'checkbox')) {
						obj.form.submit();
						return true;
						} // if
					// don't submit on every char event, wait
					if(last_edit_link_qk_section_filter_call != null) {	// clear it
						window.clearTimeout(last_edit_link_qk_section_filter_call);
						last_edit_link_qk_section_filter_call = null;
						} // if
					// restart if
					last_edit_link_qk_section_filter_call = window.setTimeout(
						function (event,obj) {
							var keywords = obj.value;
							if((keywords.length > 2) ||
								(keywords.length == 0)) {
								obj.form.submit();
								return true;
								} // if
							return false;
							},
						1200, event, obj);
					} // chk_link_section_filter()

				function submit_edit_link_qk_section_input(event,obj,id,anchor) {
					if(obj.tagName != 'INPUT')
						return false;
					var name = obj.name;
					var form = document.createElement("FORM");

					form.method = "POST";
					form.action = "<?= $_SERVER['PHP_SELF'] ?>";

					var element1 = document.createElement("input");
					element1.value = "cms_edit_links";
					element1.name = "cms_action";
					form.appendChild(element1);

					var element2 = document.createElement("input");
					element2.name = "lm_link_qk_op";
					element2.value = "edit_link_input";
					form.appendChild(element2);

					var element3 = document.createElement("input");
					element3.value = id;
					element3.name = "lm_link_qk_id";
					form.appendChild(element3);

					var element4 = document.createElement("input");
					element4.value = obj.type;
					element4.name = 'lm_link_qk_type';
					form.appendChild(element4);

					var element5 = document.createElement("input");
					element5.name = "lm_link_qk_name";
					element5.value = name;
					form.appendChild(element5);

					var element6 = document.createElement("input");
					if(obj.type == 'checkbox') {
						var chkd = obj.checked;
						element6.value = (chkd ? 'on':'off');
						} // if
					else element6.value = obj.value;
					element6.name = 'lm_link_qk_value';
					form.appendChild(element6);

					var element7 = document.createElement("input");
					element7.name = "lm_link_qk_anchor";
					element7.value = (anchor ? anchor:'');
					form.appendChild(element7);

					document.body.appendChild(form);
					form.submit();

					} // submit_edit_link_qk_section_input()

			function toggle_lm_edit_section_links(obj,event,section_id) {
				const parent = obj.parentNode;
				const children = parent.childNodes;
				const pattern = /^id_link_row\[[0-9]+\]/;
				for(let i = 0; i < children.length;i++) {
					var element = children[i];
					if(!element.id) continue;
					if(!pattern.test(element.id)) continue;
					if(element.style.display == 'none') {
						element.style.display = '';
						} // if
					else {
						element.style.display = 'none';
						} // else
					// console.log(element);
					} // for
				
				} // toggle_lm_edit_section_links()
			
			</script>
			<style>
				#summary_id select {
					font-size: 0.9em;
					max-width: 300px;
					min-width: 240px;
					}
			</style>
			<h3 class="page_config">Filters</h3>
			&nbsp;
			<form name="link_section_edit_filter" action="<?= $_SERVER['PHP_SELF'] ?>" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_links"/>
				<!--<input type="hidden" name="edit_link_qk_section"/>-->
				<input type="hidden" name="lm_link_qk_op" value="edit_link_qk_section_filter"/>
				<label>
					<input type="text" name="edit_link_qk_section_filter"
						value="<?= $edit_link_qk_section_filter ?>"
						oninput="chk_link_section_filter(event,this);"
						title="Enter filter keywords (separated by spaces) to find sections."
						/>
					<input type="checkbox" name="edit_link_qk_section_enabled"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only enabled sections."
						<?= ($edit_link_qk_section_enabled ? ' CHECKED':'') ?>/>
					only enabled sections.
					&nbsp;
					<input type="text" name="edit_link_qk_link_filter"
						value="<?= $edit_link_qk_link_filter ?>"
						oninput="chk_link_section_filter(event,this);"
						title="Enter filter keywords (separated by spaces) to find links."
						/>
					<input type="checkbox" name="edit_link_qk_link_enabled"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only enabled links"
						<?= ($edit_link_qk_link_enabled ? ' CHECKED':'') ?>/>
					only enabled links.
				</label>
			</form>

			<span id="summary_id">
		<?php out_link_section_by_parent($row_cnt,$layout_data,'sections','Links in Section:') ?>
		<?php out_link_section_by_parent($row_cnt,$layout_data,'link_orphans','Orphaned Links:') ?>

<?php
		if((!empty($layout_data['filt']['section']['keywords'])) && (!$layout_data['section_cnt']))	{		
			$msg = '(No sections found with keywords: ' . $layout_data['filt']['section']['keywords'] . ')';
			echo '<span class="cms_msg_warning">' . $msg . '</span><br>' . PHP_EOL;
			} // if
		
		if((!empty($layout_data['filt']['link']['keywords'])) && (!$layout_data['link_cnt'])) {
			$msg = '(No section links found with keywords: ' . $layout_data['filt']['link']['keywords'] . ')';
			echo '<span class="cms_msg_warning">' . $msg . '</span><br>' . PHP_EOL;
			} // if
		
		if((!empty($layout_data['filt']['link']['keywords'])) && (!$layout_data['orphan_link_cnt'])) {
			$msg = '(No orphan links found with keywords: ' . $layout_data['filt']['link']['keywords'] . ')';
			echo '<span class="cms_msg_warning">' . $msg . '</span><br>' . PHP_EOL;
			} // if
		
		if((empty($layout_data['filt']['section']['keywords'])) && (!$layout_data['section_cnt']) &&
			(empty($layout_data['filt']['link']['keywords'])) && (!$layout_data['link_cnt']) && (!$layout_data['orphan_link_cnt'])) {
			$msg = '(No section/links setup)';
			echo '<span class="cms_msg_warning">' . $msg . '</span><br>' . PHP_EOL;
			} // if
		
?>
			</span>

<?php if (!empty($edit_link_qk_anchor)) { ?>

			<script>

				cms_scroll2Name('<?= $edit_link_qk_anchor ?>');	// scroll anchor

			</script>

<?php	} // if

Ccms::page_end_comment(__FILE__);
