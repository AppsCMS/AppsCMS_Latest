<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_links_import_bm.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

define('BM_TEST_COUNT_MAX', 50);	// maximum debug count

function output_uri($mark,$name) {
	global $bm_check_urls,$bm_check_timeout_ms,$bm_online;
	if(!isset($mark['title'])) return false;
	if(isset($mark['children'])) return true;
	if(!isset($mark['uri'])) return false;
	$uri = $mark['uri'];
	if($bm_check_urls) {
		$new_url = Ccms::chk_web_host_up($uri,$bm_check_timeout_ms,false,true);
		if(is_numeric($new_url)) {
			$bm_online = false;	// mS timeout, not available
			$checked = ' (not found, ' . $new_url . ').';
			} // if
		else if(!$new_url) {
			$bm_online = false;	// mS timeout, not available
			$checked = ' (not found, timed out).';
			} // if
		else {
			$bm_online = true;
			$uri = $new_url;
			$checked = ' (checked online).';
			} // else
		} // if
	else $checked = '.';
	$text = '';
	$text .= 'URL: ' . '<a href="' . $uri .'" target="_blank">' . $uri . '</a>' . $checked . PHP_EOL;
	$text .= PHP_EOL . '<br>' . '<input type="text" name="' . $name . '[uri]" ' .
		' value="' . $uri . '" style="width: 90%;"/>' . PHP_EOL;
	return $text;
	} // output_uri()

$bookmarks = Ccms_lm_bookmarks::import_bookmarks_selections();
if(!$bookmarks) return;

global $bm_count,$bm_section_ids,$bm_empty_ids,$bm_check_urls,$bm_check_timeout_ms,$bm_online;

$bm_total = $bookmarks['total'];
$bm_type = $bookmarks['type'];
$bms_dest = '&quot;' . $bookmarks['sect_dest'] . "&quot;";
$bm_check_urls = $bookmarks['check_urls'];
$bm_check_timeout_ms = $bookmarks['check_timeout_ms'];
$bm_online = false;
$bm_count = 0;
$bm_section_ids = array();
$bm_empty_ids = array();

set_time_limit(7200);
$vars_max = ini_get('max_input_vars');
if((int)$vars_max < (4 * $bm_total)) {
	if(!self::set_chk_php_value('max_input_vars', (string)(4 * $bm_total))) {
		Ccms::addMsg('Failed to set the number of post variables to ' . ((4 * $bm_total)),'warn');
		} // if
	$vars_max = ini_get('max_input_vars');
	} // if

function draw_child_section(&$s_bookmarks,$id,$name) {
	global $bm_count,$bm_section_ids,$bm_empty_ids,$bm_check_urls,$bm_online;
	$level = $s_bookmarks['level'];
	$link_cnt = 0;
	// if($level >= 4) return;	// test
	foreach($s_bookmarks as $k => &$mark) {
//		if((Ccms::is_debug()) &&
//			($bm_count > BM_TEST_COUNT_MAX))
//			break;	// test
		if(!is_numeric($k)) continue;
		if(empty($mark)) continue;
		$s_id = $id . '_' . $k . '';
		$s_name = $name . '[' . $k . ']';
		$uri_text = output_uri($mark,$s_name);
		if(!$uri_text) continue;	// skip it
		if($bm_check_urls) {
			$checked = '';
			if($uri_text === true) $checked = ' CHECKED';
			else if($bm_online) $checked = ' CHECKED';
			} // if
		else $checked = ' CHECKED';

?>
			<table class="page_config" id="<?= $s_id ?>tb" style="padding-left: 10px;">
				<tr class="page_config">
					<th class="page_config">
						<input type="checkbox"
							name="<?= $s_name ?>[cb]"
							id="<?= $s_id ?>cb"
							onchange="toggle_bm_section(this,'<?= $s_id ?>');"
							<?= $checked ?>>
						<?= PHP_EOL . (isset($mark['children']) ? 'New Sub Section: ':'New Link: ') . $mark['title'] . PHP_EOL ?><br>
						<input type="text" name="<?= $s_name ?>[title]" value="<?= $mark['title'] ?>" style="width: 90%;"/>
					</th>
				</tr>
				<tr class="page_config" id="<?= $s_id ?>">
					<td class="page_config" style="text-align: left">
<?php
						if(isset($mark['children'])) {
							$link_cnt += draw_child_section($mark['children'],$s_id,$s_name);
							} // if
						else if($uri_text) {
							echo $uri_text;
							$link_cnt++;
							}
						else echo "Error";
?>
					</td>
				</tr>
			</table>
<?php
		ob_flush();
		flush();
		if(!$link_cnt) { // turn off folder
			$bm_empty_ids[] = $s_id . 'tb';
			}
		else $bm_section_ids[] = $s_id;
		$bm_count++;
		} // foreach
		return $link_cnt;
	} // draw_child_section()

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<script type="text/javascript">
	function bm_hide_all(obj) {
		if(typeof sect_ids === 'undefined') return;
		for(var i = 0; i < sect_ids.length; i++) {
			var s_id = sect_ids[i];
			var tr = document.getElementById(s_id);
			if(!tr) continue;
			tr.style.display = 'none';

			var cb = document.getElementById(s_id + 'cb');
			if(!cb) continue;
			cb.checked = false;
			} // for
		} // bm_hide_all()

	function bm_show_all(obj) {
		if(typeof sect_ids === 'undefined') return;
		for(var i = 0; i < sect_ids.length; i++) {
			var s_id = sect_ids[i];
			var tr = document.getElementById(s_id);
			if(!tr) continue;
			tr.style.display = '';

			var cb = document.getElementById(s_id + 'cb');
			if(!cb) continue;
			cb.checked = true;
			} // for
		} // bm_show_all()

	function toggle_bm_section(obj,sect_id) {
		var tr = document.getElementById(sect_id);
		if(obj.checked) {	// turn on section
			tr.style.display = '';
			} // if
		else {	// turn off section
			tr.style.display = 'none';
			} // else
		} // toggle_bm_section()

	function cms_enable_selected_bm_import(obj) {
		if(!confirm('Import selected bookmarks?')) return false;
		var form = obj.form;

		var il = document.getElementById('ajax-loader');
		if(il) il.style.display = 'none';
		return true;
		} // cms_enable_selected_bm_import()

	function remove_empty_sections() {	// remove empty sections
		for(var i = 0; i < empty_ids.length; i++) {
			var id_tb = empty_ids[i];
			var tb = document.getElementById(id_tb);	// enclosing table
			if(!tb) continue;
			tb.style.display = 'none';
			} // for
		// stop the spinner
		var sp = document.getElementById('ajax-loader');
		if(sp) sp.style.display = 'none';
		} // remove_empty_sections()

</script>

<?= Ccms::get_admin_scroll2pageTop() ?>
<form method="post" name="edit_link" action="<?= $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_links' ?>" enctype="multipart/form-data">
<input type="hidden" name="bm_section_id" value="<?= Ccms::get_or_post('bm_section_id') ?>"/>
<input type="hidden" name="bm_section_new" value="<?= Ccms::get_or_post('bm_section_new') ?>"/>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h2 class="page_config">Bookmarks Import Selection</h2>
			<br>
			Select the <?= $bm_type ?> bookmarks required to import as sections (folders) and links (URLs).
			<p class="page_config">
				Import <?= $bm_type ?> bookmarks from &quot;<?= $bookmarks['file'] ?>&quot; to <?= $bms_dest ?> sections and links.
			</p>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<div class="cms_sticky_left">
				<button name="show" value="show_all" type="button" onclick="bm_show_all(this);" title="Show and select all.">Show All</button>
				<button name="show" value="hide_all" type="button" onclick="bm_hide_all(this);" title="Hide and unselect all.">Hide All</button>
				&nbsp;&nbsp;
				<?php if(!Ccms::get_or_post_checkbox('bm_check_urls')) { ?>
				<label>&nbsp;Check URLs:
					<input type="checkbox"
						class="page_config"
						style="width: 20px;"
						name="bm_check_urls"
						title="Check URLs exist. This can be time consuming on large import."
						CHECKED>
				</label>
				<label>&nbsp;URL Timeout:
					<input type="number" class="page_config"
						name="bm_check_timeout_ms"
						title="Enter milliseconds to wait for URL, typically 500 to 3000 milliseconds."
						min="100" max="10000" step="50" style="width: 50px"
						value="<?= Ccms::get_or_post('bm_check_timeout_ms') ?>">
				</label>
				Longer times increase the wait time for checking URLs.
				<?php	} // if ?>
				<button name="import_bookmarks" value="import_bookmarks" type="submit"
					onclick="return cms_enable_selected_bm_import(this);"
					title="Import selected bookmarks.">Import</button>
				<button name="cancel" value="import_bookmarks" type="submit" formnovalidate>Cancel</button>
				<div id="ajax-loader" class="std">
					&nbsp;<img alt="loading" src="cms/images/ajax-loader.gif"/>
					&nbsp;<?= ($bm_check_urls ? 'Checking ':'Formating ') . $bm_total ?> Bookmarks.
				</div>
			</div>
		</td>
	</tr>
</table>
<?php // ob_flush(); flush() ?>
<table class="page_config">
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
<?php

	$level = $bookmarks['level'];
	$link_cnt = 0;
	foreach($bookmarks as $k => &$mark) {
//		if((Ccms::is_debug()) &&
//			($bm_count > BM_TEST_COUNT_MAX))
//			break;	// test
		if(!is_numeric($k)) continue;
		if(empty($mark)) continue;
		$id = 'id_bm_' . $k . '';
		$name = 'bm_cb[' . $k . ']';
		$uri_text = output_uri($mark,$name);
		if(!$uri_text) continue;	// skip it
		// if($k < 1) continue; // test
?>
			<table class="page_config" id="<?= $id ?>tb" style="padding-left: 10px;">
				<tr class="page_config">
					<th class="page_config">
						<input type="checkbox"
							name="<?= $name ?>[cb]"
							id="<?= $id ?>cb"
							onchange="toggle_bm_section(this,'<?= $id ?>');"
							CHECKED>
						<?= PHP_EOL . (isset($mark['children']) ? 'New Sub Section: ':'New Link: ') . $mark['title'] ?><br>
						<input type="text" name="<?= $name ?>[title]" value="<?= $mark['title'] ?>" style="width: 90%;"/>
					</th>
				</tr>
				<tr class="page_config" id="<?= $id ?>">
					<td class="page_config" style="text-align: left">
<?php
						if(isset($mark['children'])) {
							$link_cnt += draw_child_section($mark['children'],$id,$name);
							} // if
						else if($uri_text) {
							echo $uri_text;
							$link_cnt++;
							} // if
						else echo "Error";
						// if(Ccms::is_debug()) $bm_count = 0;	// test
?>
					</td>
				</tr>
			</table>
<?php
		ob_flush();
		flush();
		if(!$link_cnt) { // turn off folder
			$bm_empty_ids[] = $id . 'tb';
			}
		else $bm_section_ids[] = $id;
		$bm_count++;
		} // foreach
?>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<?= $link_cnt ?> usable bookmarks found (<?= $bm_total ?> total).
		</td>
	</tr>
</table>
</form>

<script type="text/javascript">
	var sect_ids = <?= Ccms_base::json_encode($bm_section_ids) ?>;
	var empty_ids = <?= Ccms_base::json_encode($bm_empty_ids) ?>;

	window.addEventListener("load",remove_empty_sections);	// remove empty sections

</script>

<?php Ccms::page_end_comment(__FILE__) ?>
