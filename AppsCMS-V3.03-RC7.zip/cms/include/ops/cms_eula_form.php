<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_eula_form.php 2793 2022-09-10 06:40:19Z robert0609 $
 */

$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
$link = CMS_C_EULA_LINK;	// default
$has_form = CMS_C_EULA_HAS_FORM;	// default
$info = true;	// default
$show_save = false;
if((((int)$tla['body_id'] > 0) || ((int)$tla['tool_id'] > 0)) &&	// app or tool stuff
	(!empty($tla['terms']))) {
	$link = $tla['terms'];
	$info = !$tla['terms_show'];	// show form
	$show_save = ($tla['terms_show'] && $tla['terms_upfirst']);	// show save button
	$user_name = Ccms::get_cms_sess_var('user.name');
	$user_id = Ccms::get_cms_sess_var('user.id');
	$user_auth = Ccms::get_cms_sess_var('user.type');
	$has_form = false;
	} // if
else if(!Ccms_auth::is_eula_enabled()) {
	Ccms::reset_session_actions();	// stop circular redirects
	$url = (Ccms::is_ssl_required() ? CMS_SSL_URL:CMS_WWW_URL) . Ccms::get_body_uri();
	header('Location: ' . $url);
	exit (0);
	} // if
else if(!$has_form) {	// default whole site eula
	if(Ccms_auth::is_user_logged_in()) $info = false;	// live user can show form
	else $info = Ccms::get_or_post('info');	// just show eula, no form
	$show_save = ($tla['eula_show'] && $tla['eula_upfirst']);
	Ccms::reset_session_actions();
	if(!$info) {
		$user_name = Ccms::get_cms_sess_var('user.name');
		$user_id = Ccms::get_cms_sess_var('user.id');
		$user_auth = Ccms::get_cms_sess_var('user.type');
		if((!$user_name) || (!$user_id) || (!$user_auth)) {
			if(!CMS_C_EULA_ALL) $info = true;	// don't show form
			else {
				$user_name = Ccms_auth::get_user_json_name();
				$user_id = 0;
				$user_auth = 'open_eula';
				} // else
			} // if
		} // if
	} // if

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php if((!$has_form) && (!$info)) { ?>
<form name="set_user_eula" action="index.php" method="post" enctype="multipart/form-data" autocomplete="off">
<input type="hidden" name="action" value="eula"/>
<input type="hidden" name="user_id" value="<?= $user_id ?>"/>
<input type="hidden" name="user_name" value="<?= htmlentities($user_name) ?>"/>
<input type="hidden" name="user_auth" value="<?= htmlentities($user_auth) ?>"/>
<?php	} //if ?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_body">
	<tr class="page_body">
		<td class="page_body">
			<?php
			// local file or remote
			if(file_exists(ETC_FS_EXT_INCLUDES_DIR . $link)) {	// local file
				include(ETC_FS_EXT_INCLUDES_DIR . $link);
				} // if
			else if(file_exists(DOCROOT_FS_BASE_DIR . $link)) {	// local file
				if(preg_match('/\.html$|\.htm$/i',$link)) {
					readfile(DOCROOT_FS_BASE_DIR . $link);
					} // if
				else if(preg_match('/\.md$|\.txt$/i',$link)) {	// markdown
					echo Ccms_media_conv_plugin::get_text_file2html(DOCROOT_FS_BASE_DIR . $link);
					} // if
				else {
					include(DOCROOT_FS_BASE_DIR . $link);
					} // else
				} // if
			else {	// remote link
				Ccms::output_iframe_site_text($link);
				} // else
			?>
			<input type="hidden" name="body_id" value="<?= $tla['body_id'] ?>"/>
			<input type="hidden" name="tool_id" value="<?= $tla['tool_id'] ?>"/>
		</td>
	</tr>
<?php if(!$has_form) { ?>
	<tr class="page_body">
		<td class="page_body" style="float: right;">
<?php	if(!$info) { ?>
			<?php if($show_save) { ?>
			<label style="font-size: 1.2em;">I agree</label>
			<input id="id_eula_chk" name="eula" value="agreed" type="checkbox" onclick="document.getElementById('id_eula_submit').disabled = false;"/>
			&nbsp;&nbsp;
			<button id="id_eula_submit" name="eula_submit" value="eula_save" type="submit" onclick="Ccms_cursor.setWait();" DISABLED>Save</button>
			<?php	} else { ?>
			<label style="font-size: 1.2em;">I agreed</label>
			<input name="eula" value="agreed" type="checkbox" onclick="document.getElementById('id_eula_submit').disabled = false;" CHECKED/>
			<button id="id_eula_submit" name="eula_submit" value="eula_save" type="submit" onclick="Ccms_cursor.setWait();" DISABLED>Save</button>
			<?php	} // else ?>
<?php		}
		else { ?>
			<label style="font-size: 1.2em;">I agreed </label>
			<input type="checkbox" CHECKED DISABLED/>
<?php		} // else ?>
		</td>
	</tr>
<?php	} //if ?>
</table>
<?php if((!$has_form) && (!$info)) { ?>
</form>
<?php
	} //if
Ccms::page_end_comment(__FILE__);
