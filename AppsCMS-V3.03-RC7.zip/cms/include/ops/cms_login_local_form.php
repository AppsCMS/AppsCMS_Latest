<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_login_local_form.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

global $user_name;
if(!isset($user_name)) $user_name = '';
$login_url = (Ccms::is_ssl_required() ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?action=login';

?>
<?php Ccms::page_start_comment(__FILE__) ?>
<style>
	.gotcha_li {		
		} 
	table.gotcha_li {
		width: 250px;
		}
	td.gotcha_li {
		vertical-align: central;
		}
</style>
<div>
<?php Ccms::set_JS_password_resource() ?>
	<form method="post" name="login" action="<?= $login_url ?>">
	<input type="hidden" name="action" value="login"/>
	<input type="hidden" name="local_login" value="true"/>
	<table class="page_body">
		<tr class="page_body">
			<th width="200px" class="page_body">Name:</th>
			<td class="page_body" style="text-align: left;">
				<input type="text" id="id_user_name" placeholder="User name" name="user_name" value="<?= $user_name ?>" autocorrect="off" autocapitalize="off" title="Enter username" autofocus/>
			</td>
			<td class="page_body">&nbsp;</td>
		</tr>
		<tr class="page_body">
			<th class="page_body">Password:</th>
			<td class="page_body" style="text-align: left;">
				<?php Ccms::set_JS_password_input('user_password', 'Enter password','',false,true) ?>
			</td>
			<td class="page_body">&nbsp;</td>
		</tr>
<?php if(CMS_S_ALLOW_COOKIE_LOGIN_BOOL) {
	$l_int = Ccms::get_human_fmt_time_interval(CMS_S_SESSIONS_COOKIE_TIMEOUT_SECS,"days");
?>
		<tr class="page_body">
			<th class="page_body">Remember Login:</th>
			<td class="page_body" style="text-align: left;">
				<input type="checkbox" name="remember" title="Check to remember login for <?= $l_int ?>." CHECKED/>
			</td>
			<td class="page_body">&nbsp;</td>
		</tr>
<?php	} // if ?>
<?php if((CMS_S_ADD_GOTCHA_LOGIN_BOOL) && (Ccms_gotcha_plugin::is_enabled())) { ?>
		<tr class="page_body">
			<th class="page_body"></th>
			<td class="page_body">
					<?= Ccms_gotcha_plugin::generate('gotcha_id','', true,'gotcha_li') ?>
			</td>
			<td class="page_body">&nbsp;</td>
		</tr>
<?php	} // if ?>
		<tr class="page_body">
			<th class="page_body"></th>
			<td class="page_body" style="text-align: left;">
				<button type="submit" name="submit" value="login" onclick="Ccms_cursor.setWait();">Login</button>
				<button type="submit" name="submit" value="cancel" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</td>
			<td class="page_body">&nbsp;</td>
		</tr>
	</table>
	<?php Ccms_location::add_JS_browser_geolocation_form_text() ?>
	</form>
</div>
<?php
Ccms::page_end_comment(__FILE__);
