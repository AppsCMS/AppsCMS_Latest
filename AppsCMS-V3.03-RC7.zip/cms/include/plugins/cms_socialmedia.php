<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_socialmedia.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of Social Media plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 *
 */

class Ccms_socialmedia_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_socialmedia';

	protected static $sub_plugins = false;
	protected static $sub_plugin_cfgs = false;

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	protected static function get_subplugins() {
		if(self::$sub_plugins !== false) return self::$sub_plugins;	// time saver

		$path = CMS_FS_PLUGINS_DIR . self::PLUGIN . '/';
		self::$sub_plugins = array();
		if($dh = opendir($path)) { // check plugin location
			while (($file = readdir($dh)) !== false) {
				if(preg_match('/\.php$/',$file)) {
					include_once($path . $file);
					$p = preg_replace('/.php$/', '', strtolower($file));
					$class = 'C' . $p . '_subplugin';
					if(@class_exists($class)) {
						self::$sub_plugins[$p] = array(
							'class' => $class,
							'plugin' => $p,
							'title' => $class::get_title(),
							'enabled' => ($class::is_enabled() ? true:false),
							'description' => $class::get_description(),
							// 'cfg' => $class::get_sql_install_data(),
							);
						} // if
					} // if
				} // while
			closedir($dh);
			ksort(self::$sub_plugins);
			} // if
		return self::$sub_plugins;
		} // get_subplugins()

	protected static function get_subplugin_cfgs() {
		if(self::$sub_plugin_cfgs !== false) return self::$sub_plugin_cfgs;	// time saver

		$path = CMS_FS_PLUGINS_DIR . self::PLUGIN . '/';
		self::$sub_plugin_cfgs = array();
		if($dh = opendir($path)) { // check plugin location
			while (($file = readdir($dh)) !== false) {
				if(preg_match('/\.php$/',$file)) {
					include_once($path . $file);
					$p = preg_replace('/.php$/', '', strtolower($file));
					$class = 'C' . $p . '_subplugin';
					if(@class_exists($class)) {
						self::$sub_plugin_cfgs[$p] = array(
							'class' => $class,
							'plugin' => $p,
							'title' => $class::get_title(),
							'enabled' => ($class::is_enabled() ? true:false),
							// 'description' => $class::get_description(),
							'cfg' => $class::get_sql_install_data(),
							);
						} // if
					} // if
				} // while
			closedir($dh);
			ksort(self::$sub_plugin_cfgs);
			} // if
		return self::$sub_plugin_cfgs;
		} // get_subplugin_cfgs()

	public static function is_enabled() {	// required function, check plugin enabled
		if(preg_match('/edit_|login|logout/',Ccms::get_app_action())) return false;	// not on config pages
		if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		if(!PL_CMS_SOCIALMEDIA_SM_ENABLE) return false;
		if(Ccms::is_tiny()) return false;	// wont fit
		$spls = self::get_subplugins();
		foreach($spls as $sp) if($sp['enabled']) return true;
		return false;
		} // is_enabled()

	public static function get_ajax_engage_uri() {	// default uri to engage plugin
		return CMS_WS_DIR . 'cms_ajax.php?ajax=socialMediaFrm&plugin=' . self::PLUGIN;
		} // get_ajax_engage_uri()

	public static function get_list_SM_subplugins() {
		return self::get_subplugins();
		} // get_list_SM_subplugins()

	public static function is_this_ajax_plugin($ajax) {	// required function, check for ownership of ajax op by this plugin
		if(!self::is_enabled()) return false;	// default return
		switch(PL_CMS_SOCIALMEDIA_SM_LOCATION) {
		case 'in_page_horizontal':
		case 'in_page_vertical':
			break;
		default:
			return false;
		} // switch
		switch($ajax) {
		case 'socialMedia': return true;
		case 'socialMediaFrm': return true;
		default: break;
		} // switch
		return false;
		} // is_this_plugin()

	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		// return '';	// default return
		$text = '';
		switch($ajax) {
		case 'socialMedia':
			$text .= self::generate('AJAX',$ajax);	// assume it is in an iframe
			break;
		case 'socialMediaFrm':
			$text .= '<!DOCTYPE html>' . PHP_EOL .
				'<html><head>' . PHP_EOL .
				'	<base href="' . Ccms::$cms_page_info['base_ref'] . '">' . PHP_EOL .
				'	<link rel="stylesheet" type="text/css" href="' . Ccms_minify_plugin::minify_css(ETC_WS_CSS_DIR . 'cms_styles_main.css') . '">' . PHP_EOL .
				'</head><body>' . PHP_EOL;
			$text .= self::generate('AJAX',$ajax);	// assume it is in an iframe
			$text .= '</body></html>' . PHP_EOL;
			break;
		default: break;
		} // switch
		return $text;
		} // get_ajax_text()

	public static function init_body_insert() {
		if(!self::is_enabled()) return '';
		self::get_subplugins();
		$text = array();
		$text[] = '<!-- Begin init social media code -->';
		foreach(self::$sub_plugins as &$pp) {	// add missing sub plugins
			if(!$pp['class']::is_enabled()) continue;
			$text[] = '			' . $pp['class']::init_body_insert();
			} // foreach
		$text[] = '<!-- End init social media code -->';
		return (!empty($text) ? PHP_EOL .implode(PHP_EOL,$text) . PHP_EOL:'');
		} // init_body_insert()

	public static function generate($id,$suffix = '',$params = array()) {	// assume it is in an iframe
		if(!self::is_enabled()) return '';
		self::get_subplugins();

		$lt = ''; $hi = ''; $si = ''; $sp_enc = true;
		// the height is quirky (often has a unnecessary padding)
		switch(PL_CMS_SOCIALMEDIA_SM_LOCATION) {
		case 'footer_left':
			$params['style'] = 'style="max-height: ' . CMS_S_FOOTER_HEIGHT . '";';
			$sc = 'social_media_left no-print';
			$lt = 'h';
			break;
		case 'header_left':
			$params['style'] = 'style="max-height: ' . CMS_S_HEADER_HEIGHT . '";';
			$sc = 'social_media_left no-print';
			$lt = 'h';
			break;
		case 'left_column_bottom':
			$params['style'] = 'style="max-height: ' . CMS_S_FOOTER_HEIGHT . '";';
			$sc = 'social_media no-print';
			$lt = 'v';
			break;
		case 'left_column_top':
			$params['style'] = 'style="max-height: ' . CMS_S_HEADER_HEIGHT . '";';
			$sc = 'social_media no-print';
			$lt = 'v';
			break;
		case 'footer_right':
			$params['style'] = 'style="max-height: ' . CMS_S_FOOTER_HEIGHT . '";';
			$sc = 'social_media_right no-print';
			$lt = 'h';
			break;
		case 'header_right':
			$params['style'] = 'style="max-height: ' . CMS_S_HEADER_HEIGHT . '";';
			$sc = 'social_media_right no-print';
			$lt = 'h';
			break;
		case 'center_left':
			$sc = 'social_media_center_left no-print';
			$lt = 'v';
			$hi = 'arrow-left.gif';
			$si = 'arrow-right.gif';
			break;
		case 'center_right':
			$sc = 'social_media_center_right no-print';
			$lt = 'v';
			$hi = 'arrow-right.gif';
			$si = 'arrow-left.gif';
			break;
		case 'in_page_horizontal':
			$sc = 'social_media no-print';
			$lt = 'h';
			$hi = '';
			$si = '';
			$sp_enc = false;
			break;
		case 'in_page_vertical':
			$sc = 'social_media no-print';
			$lt = 'v';
			$hi = '';
			$si = '';
			$sp_enc = false;
			break;
		default:
			return '';
		} // switch

		$text = array();
		if(!empty(self::$sub_plugins)) {
			if(!empty($si)) {
				$text[] = '<script type="text/javascript">';
				$text[] = '	function hide_sm() {';
				$text[] = '		document.getElementById(\'' . $id . $suffix . '\').style.display = \'none\';';
				$text[] = '		document.getElementById(\'' . $id . $suffix . '_hidden\').style.display = \'block\';';
				$text[] = '		} // hide_sm()';
				$text[] = '';
				$text[] = '	function show_sm() {';
				$text[] = '		document.getElementById(\'' . $id . $suffix . '_hidden\').style.display = \'none\';';
				$text[] = '		document.getElementById(\'' . $id . $suffix . '\').style.display = \'block\';';
				$text[] = '		} // show_sm()';
				$text[] = '';
				$text[] = '</script>';
				$text[] = '';
				$text[] = '<span id="' . $id . $suffix . '_hidden" class="' . $sc . '" style="display: none;">';
				$text[] = '	<a onclick="javascript:show_sm();" title="Show SM">' .
								'<img alt="show" src="' . CMS_WS_IMAGES_DIR . '' . $si . '" width="10" height="15"/></a>';
				$text[] = '</span>';
				} // if
			if($sp_enc) $text[] = '<span id="' . $id . $suffix . '" class="' . $sc . '">';
			$text[] = '<table class="social_media">';
			if(!empty($hi)) {	// only on center_left and center_right
				$text[] = '<tr class="social_media"><td class="social_media">';
				$text[] = '		<a onclick="javascript:hide_sm();" title="Hide SM">' .
									'<img alt="show" src="' . CMS_WS_IMAGES_DIR . '' . $hi . '" width="20" height="20"/></a>';
				$text[] = '</td></tr>';
				} // if
			if($lt == 'h')
				$text[] = '	<tr class="social_media">';
			$sort_order = PL_CMS_SOCIALMEDIA_SM_ORDER;
			if(!empty($sort_order)) $sort_order = explode(':',$sort_order);
			else $sort_order = array();
			foreach(self::$sub_plugins as $p => $sp) {	// add missing sub plugins
				if(in_array($p,$sort_order)) continue;
				$sort_order[] = $p;
				} // foreach
			foreach($sort_order as $sp) {
				$pp = self::$sub_plugins[$sp];
				if(!$pp['class']::is_enabled()) continue;
				if($lt == 'v')
					$text[] = '	<tr class="social_media">';
				$text[] = '		<td class="social_media">';
				$text[] = '			' . $pp['class']::generate($id,$suffix,$params);
				$text[] = '		</td>';
				if($lt == 'v')
					$text[] = '	</tr>';
				} // foreach
			if($lt == 'h')
				$text[] = '	</tr>';
			if(!empty($hi)) {	// only on center_left and center_right
				$text[] = '<tr class="social_media"><td class="social_media">';
				$text[] = '		<a onclick="javascript:hide_sm();" title="Hide SM">' .
									'<img alt="show" src="' . CMS_WS_IMAGES_DIR . '' . $hi . '" width="20" height="20"/></a>';
				$text[] = '</td></tr>';
				} // if
			$text[] = '</table>';
			if($sp_enc) $text[] = '</span>';
			} // if
		return (!empty($text) ? PHP_EOL .implode(PHP_EOL,$text) . PHP_EOL:'');
		} // generate()

	public static function get_title() {	// get the plugin title
		return 'Social Media';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		$text = 'The ' . CMS_PROJECT_SHORTNAME . ' Social Media plugin (' . self::PLUGIN . ') is used to provide social media links.'
			. '<br>To use the Social Media plugin in , enter "'
			. htmlentities('<iframe src="' . CMS_WS_DIR . 'cms_ajax.php?ajax=socialMediaFrm&plugin=' . self::PLUGIN . '" frameborder="0" scrolling="no"></iframe>')
			. '"<br> OR add "'
			. htmlentities('<span id="SMin_page"></span>')
			. '" into the .html file.'
			. '<br>The Social Media plugin has sub-plugins:';

		self::get_subplugins();
		if(!empty(self::$sub_plugins)) {
			$text .= PHP_EOL . '<ul>';
			foreach (self::$sub_plugins as $sn => $sp) {
				$text .= '<li class="page_config">' . $sp['description'] . '</li>';
				} // foreach
			$text .= '</ul>' . PHP_EOL;
			} // if
		return $text;
		} // get_description()

	protected static function get_sql_install_data() {
		$cfg = array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "SM_ENABLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "false",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Enable",
				'cms_config_description' => "Set true to enable all social media, false to disable all.",
				),	// row data
			array(
				'cms_config_key' => "SM_LOCATION",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "header_right",
				'cms_config_allowed_values' => "header_left:header_right:left_column_top:left_column_bottom:center_left:center_right:footer_left:footer_right:in_page_horizontal:in_page_vertical",
				'cms_config_name' => "Location",
				'cms_config_description' => "Set the location where the social media links appear on the page.<br>" .
											"Header Left, Header Right - placed in header left or right side of title,<br>" .
											"Left Column Top, Left Column Bottom - placed at top or bottom of the left column (if left column is off, it is not displayed),<br>" .
											"Center Left, Center Right - placed at fixed position on the left or right center of the page,<br>" .
											"Footer Left, Footer Right - placed in footer left or right side of center.<br>" .
											"In Page Horizontal, In Page Vertical - placed in the page body, add " . htmlentities('<iframe src="' . CMS_WS_DIR . 'cms_ajax.php?ajax=socialMediaFrm&plugin=' . self::PLUGIN . '" frameborder="0" scrolling="no"></iframe>') . " where you need the social media plugins to appear.<br>" .
											"NOTE: It may be necessary to adjust the header or footer height to accomodate the social media buttons.<br>" .
											"Social media links do not appear on setup or administration pages.",
				),	// row data
			array(
				'cms_config_key' => "SM_ORDER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Display Order",
				'cms_config_description' => "Set the order you want social media types to appear.",
				'cms_config_show_func' => "show_sm_order",
				'cms_config_input_func' => "input_sm_order",
				'cms_config_save_func' => "save_sm_order",
				),	// row data
			);
		self::get_subplugin_cfgs();
		if(!empty(self::$sub_plugin_cfgs)) {
			foreach(self::$sub_plugin_cfgs as $sp => $pp) {
				$cfg = array_merge($cfg, $pp['cfg']);
				} // foreach
			} // if
		return $cfg;
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_socialmedia_plugin

