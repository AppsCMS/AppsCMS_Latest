<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit.php 2909 2022-10-24 07:34:08Z robert0609 $
 */

/**
 * Description of Ccms_edit
 *
 * Provides common methods for generation for editing config html layout for INI/JSON based arrays.
 *
 * @author robert0609
 */

class Ccms_edit extends Ccms_options {

	const THIRD_LEV_TOKEN = '__SUB_ARRAY__';
	const SEARCH_FILTER_DROP_SIZE_MIN = 8;
	private static $last_posted_data = false;

	protected $sect_idx = 0;

	protected static $js_done = false;

	function __construct($name = false,$h1 = false,$conf = false,$comments = false,$opts_ary = false) {
		parent::__construct();
		if(($name) && ($comments)) {	// the must have
			$this->show_edit_ini_json_page($name, $h1, $conf, $comments, $opts_ary);
			} // if
		else if(!$par = get_parent_class($this)) {
			self::log_msg('Missing parameters from "' . __CLASS__ . '" _construct().');
			} // else
		else if(!preg_match('/_DB_edit$/',$par)) {
			self::log_msg('No application configuration settings available.','info');
			} // else
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function get_posted_data($p_name,$control_json,$old_data = null,$use_typedef_as_default = false) {
		if(!isset($_POST[$p_name])) return false;
		$new_data = $_POST[$p_name];
		if((empty($new_data)) || (!is_array($new_data))) return false;
		if(empty($control_json)) {
			self::addMsg('Cannot check value inputs types, missing control data.');
			return false;
			} // if
		foreach($control_json as $sect_name => &$sect) {
			if(!isset($new_data[$sect_name])) {
				if(preg_match('/(comment|_.+)/',$sect_name)) continue;
				if(!empty($old_data[$sect_name]))
					self::addMsg('POST data missing from section "' . $sect_name . '".');
				continue;
				} // if
			foreach($control_json[$sect_name] as $key => &$sect_control) {
				if(isset($sect_control['input']['type'])) {
					switch($sect_control['input']['type']) {
					case 'checkbox': // do null checkout returns
						if(!isset($new_data[$sect_name][$key]))
							$new_data[$sect_name][$key] = 'off';
						break;
					default:
						break;
						} // switch
					} // if
				else if(isset($sect_control['_form_get_func'])) {
					$func = $sect_control['_form_get_func'];
					if($callback = Ccms::get_inc_method_callback($func)) {

						$elem_name = $p_name . '[' . $sect_name . '][' . $key . ']';
						$elem_value = $new_data[$sect_name][$key];

						if(!empty($sect_control['app_key'])) {	// direct from an app.comments.ini primary class method
							$cms_app_ini_key = preg_replace('/^' . $sect_control['app_key'] . '/','',$key);
							$new_val = call_user_func_array($callback, array($sect_control,$cms_app_ini_key,$elem_name,$elem_value));
							} // if
						else {
							$new_val = call_user_func_array($callback, array($sect_control,$key,$elem_name,$elem_value));
							} // else
						if(!is_null($new_val))
							$new_data[$sect_name][$key] = $new_val;
						} // if
					} // else if
				else {	// just a normal form value
					// already there
					} // else
				} // foreach
			} // foreach

		if(!is_null($old_data)) {
			foreach($new_data as $sect_name => &$sect) {	// transfer sub-arrays (not part of the setup form)
				foreach($new_data[$sect_name] as $key => &$v) {
					if($v == self::THIRD_LEV_TOKEN) {
						if((isset($old_data[$sect_name][$key])) &&
							(is_array($old_data[$sect_name][$key]))) {
							$new_data[$sect_name][$key] = $old_data[$sect_name][$key];
							} // if
						else $new_data[$sect_name][$key] = array();	// ????
						continue;
						} // if
					if(($use_typedef_as_default) &&
						(array_key_exists($key,$old_data[$sect_name])) &&
						(!is_array($v))) {
						$value = strval($v);	// release ref
						if(is_bool($old_data[$sect_name][$key])) {
							switch(strtolower($value)) {
							default:
							case 'false':
							case '0':
								$new_data[$sect_name][$key] = false;
								break;
							case 'true':
							case '1':
								$new_data[$sect_name][$key] = true;
								break;
								} // switch
							} // if
						else if(is_numeric($old_data[$sect_name][$key])) {
							if(is_float($value)) $new_data[$sect_name][$key] = (float)$value;
							else $new_data[$sect_name][$key] = (int)$value;
							} // else if
						// else ok
						} //if
					} // foreach
				} // foreach
			} // if
		self::$last_posted_data = $new_data;
		return $new_data;
		} // get_posted_data()

// dynamic methods
	protected function get_hn($hn,$encap,$alt = false) {
		$h_str = $alt;
		if((!is_array($this->efrm[$hn])) &&
			(is_string($this->efrm[$hn])))
			$h_str = $this->efrm[$hn];
		else if((isset($this->efrm[$hn][$this->sect_idx])) &&
			(is_string($this->efrm[$hn][$this->sect_idx])))
			$h_str = $this->efrm[$hn][$this->sect_idx];
		if(!$h_str) return '';
		if(!$encap) return ' ' . $h_str . ' ';
		return '<' . $hn . '>' . $h_str . '</' . $hn . '>' . PHP_EOL;
		} // get_hn()

	protected function get_h1_h2_h3($encap,$hn = false) {
		$txt = '';
		if($hn !== false) $txt = $this->get_hn($hn,$encap);
		else {	// else search
			for($n = 1; $n <= 3; $n++) {
				if(!$t = $this->get_hn('h' . $n,$encap)) continue;
				$txt .= $t;
				} // for
			} // else
		if(empty($txt)) return;

		if($encap) {
?>
			<tr class="<?= $this->efrm['class'] ?>">
				<th class="<?= $this->efrm['class'] ?>" style="text-align: left;">
<?php
			} // if
		echo $txt;
		if($encap) {
?>
				</th>
			</tr>
<?php
			} // if
		} // get_h1_h2_h3()

	protected function ins_dyn_ctl_js() {
		if(self::$js_done) return;	// do once

?>
	<script type="text/javascript">

		function switchover_dyn_ctl(id_chkbx,id_norm) {
			var chkbox = document.getElementById(id_chkbx);
			var norm = document.getElementById(id_norm);
			if(chkbox.checked) {
				norm.style.display = 'none';
				} // if
			else {
				norm.style.display = 'inline-block';
				} // else
			} // switchover_dyn_ctl()

	</script>
<?php
		} // ins_dyn_ctl_js()

	protected function gen_sys_val(&$conf,&$comments,&$sect_name,&$key,&$value,&$row) {
		$disabled = self::getDottedKeys2Var($this->efrm['not_shown'],$sect_name . '.' . $key);
		if($disabled === true) return true;

		if((substr($sect_name,0,2) == '__') || (substr($key,0,2) == '__')) {	// not used value (a preserver or archive
			if(isset($conf[$sect_name][$key])) {
				echo '						<input type="hidden" name="' . $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']' . '" value="' . rawurlencode($conf[$sect_name][$key]) . '"/>' . PHP_EOL;
				} // if
			return true;
			} // if
		if((substr($sect_name,0,1) != '_') && (substr($key,0,1) != '_')) return false;	// not a system value
		if(!$this->efrm['show_sys_vals']) {
			$val = (isset($conf[$sect_name][$key]) ? $conf[$sect_name][$key]:'');
			if((empty($val)) && (isset($comments[$sect_name][$key]['default']))) $val = $comments[$sect_name][$key]['default'];
			echo '						<input type="hidden" name="' . $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']' . '" value="' . rawurlencode($val) . '"/>' . PHP_EOL;
			} // if
		else {
			$this->show_edit_ini_json_section_value($conf,$comments,$sect_name,$key,$value,$row,true,true,$this->efrm['use_typedef_as_default'],true);
			} // else
		return true;
		} // gen_sys_val()

	private function get_is_defined($elem_value, $undef = false) {
		switch(strtolower($elem_value)) {
		case 'true':
		case 'false':
			return $elem_value;	// these have sys definitions
		default:
			break;
			} // switch
		if(($undef) && (defined($elem_value))) {
			if($this->efrm['show_constant_name']) {
				$val = $elem_value . ' (' . constant($elem_value) . ')';
				} // if
			else $val = constant($elem_value);
			} // if
		else $val = $elem_value;
		return $val;
		} // get_is_defined()

	private function get_elem_params(&$elem) {
		$params = '';
		if((isset($elem['params'])) &&
			(!empty($elem['params']))) {
			$params = ' ' . preg_replace('/=([0-9]+)/','="\1"',$elem['params']) . ' ';	// add the quote
			} // if
		return $params;
		} // get_elem_params()

	private function make_input_elem_select(&$conf,&$comments,&$sect_name,&$key,
			&$sect_control,&$elem_value,&$val_readonly,&$required) {

		$elem_name = $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']';
		$id = 'id_' . $elem_name;

		if((isset($sect_control['select']['options'])) &&
			(is_array($sect_control['select']['options']))) {
			$options = &$sect_control['select']['options'];
			$type = &$sect_control['select']['type'];
			$params = $this->get_elem_params($sect_control['select']);
			switch(strtolower($type)) {
			case 'multiple':
			case 'multi':
				$multi = ' multiple ';
				$elem_name .= '[]';
				break;
			default:
				$multi = '';
				break;
				} // switch
			// check if a search filter used
			echo self::get_select_option_filter($id, '',-1,Ccms_edit::count_sel_opts($options));
			echo '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $elem_name . '"' . $params . $multi .
				($val_readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' . PHP_EOL;
			$select_done = false;
			foreach($options as $n => $v) {
				if(empty($v)) continue;
				if(is_array($v)) {
					$n = (isset($v['name']) ? $v['name']:$n);	// new name (usually empty so it cannot be posted when required)
					$val = (isset($v['value']) ? $this->get_is_defined($v['value'],true):'');
					$opt_params = (isset($v['params']) ? ' ' . $v['params']:'');
					} // if
				else {
					$opt_params = '';
					$val = $this->get_is_defined($v,true);
					} // else
				if(empty($val)) continue;
				if((empty($multi)) && ($select_done)) $selected = '';
				else {
					if(is_array($elem_value)) {
						if(in_array($n, $elem_value)) $selected = ' SELECTED';
						else $selected = '';
						} // if
					else {
						if(($n == $elem_value) || ($val == $elem_value)) { $select_done = true; $selected = ' SELECTED'; } // if
						else $selected = '';
						} // else
					} // else
				echo '	<option ' . 'value="' . $n . '"' . $selected . $opt_params . '>' . htmlentities($val) . '</option>' . PHP_EOL;
				} // foreach
			echo '</select>' . PHP_EOL;
			if(!empty($multi)) {
			echo <<<EOTJS
			<script type="text/javascript">
				cms_preventDefSelectEvent('{$id}');
			</script>
EOTJS;
				} // if
			return true;
			} // if
		return false;
		} // make_input_elem_select()

	private function make_input_elem_datalist(&$conf,&$comments,&$sect_name,&$key,
			&$sect_control,&$elem_value,&$val_readonly,&$required) {

		$elem_name = $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']';
		$id = 'id_' . $elem_name;

		if((isset($sect_control['datalist']['options'])) &&
			(is_array($sect_control['datalist']['options']))) {
			$options = &$sect_control['datalist']['options'];
			echo '<input id="' . $id . '" name="' . $elem_name . '"' .
				' value="' . $this->get_is_defined($elem_value,true) . '"' .
				' list="' . $id . '_dl' . '"' .
				($val_readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' . PHP_EOL;
			echo '<datalist id="' . $id . '_dl' . '">' .PHP_EOL;
			foreach($options as $n => $v) {
			if(empty($v)) continue;
				if(is_array($v)) {
					$n = (isset($v['name']) ? $v['name']:$n);	// new name (usually empty so it cannot be posted when required)
					$val = (isset($v['value']) ? $this->get_is_defined($v['value'],true):'');
					$opt_params = (isset($v['params']) ? ' ' . $v['params']:'');
					} // if
				else {
					$opt_params = '';
					$val = $this->get_is_defined($v,true);
					} // else
				if(is_array($elem_value)) {
					if(in_array($n, $elem_value)) $selected = ' **';
					else $selected = '';
					} // if
				else {
					if(($n == $elem_value) || ($val == $elem_value)) { $selected = ' **'; } // if
					else $selected = '';
					} // else
				echo '	<option ' . 'value="' . $n . '"' . $selected . $opt_params . '>' . htmlentities($val) . '</option>' . PHP_EOL;
				} // foreach
			echo '</datalist>' . PHP_EOL;
			return true;
			} // if
		return false;
		} // make_input_elem_datalist()

	private function make_input_elem_input(&$conf,&$comments,&$sect_name,&$key,
			&$sect_control,&$elem_value,&$val_readonly,&$required) {

		$elem_name = $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']';
		$id = 'id_' . $elem_name;

		if(isset($sect_control['input']['type'])) {
			$type = &$sect_control['input']['type'];
			$prec = (isset($sect_control['input']['prec']) ? (int)$sect_control['input']['prec']:false);
			$params = $this->get_elem_params($sect_control['input']);
			$val = $this->get_is_defined($elem_value);
			switch(strtolower($type)) {
			case 'textarea':
				echo '<textarea id="' . $id . '" name="' . $elem_name . '"' .
					$params . ($val_readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' .
					htmlentities($val) .
					'</textarea>' . PHP_EOL;
				break;
			case 'password':
				set_JS_password_input($elem_name,'',$val,true);
				break;
			case 'checkbox':
			case 'radio';
				if((empty($val)) && (!strlen($val)) && (isset($sect_control['default']))) $val = $sect_control['default'];
				echo '<input type="' . $type . '" id="' . $id . '" name="' . $elem_name . '"' . ((($val == 'on') || ((int)$val == 1)) ? ' CHECKED':'') .
					$params . ($val_readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' . PHP_EOL;
				break;
			case 'file':
				echo '<input type="' . $type . '" id="' . $id . '" name="' . $elem_name . '"' .
					$params . ($val_readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' . PHP_EOL;
				break;
			case 'hidden':
				echo '<input type="' . $type . '" id="' . $id . '" name="' . $elem_name . '" value="' . htmlentities($val) . '"' . '>' . PHP_EOL;
				break;
			case 'show':	// show value in a span
				echo '<span " id="' . $id . '">' . htmlentities($val) . '</span>' . PHP_EOL;
				break;
			case 'number':
				if((empty($val)) && (!strlen($val)) && (isset($sect_control['default']))) $val = $sect_control['default'];
				if(($prec !== false) && (is_numeric($prec))) $val = sprintf('%.' . $prec . 'f', (float)$val);
				// fall thru
			case 'text':
			default:
				echo '<input type="' . $type . '" id="' . $id . '" name="' . $elem_name . '" value="' . htmlentities($val) . '"' .
					$params . ($val_readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' . PHP_EOL;
				break;
				} // switch
			return true;
			} // if
		return false;
		} // make_input_elem_input()

	private function make_input_elem_func(&$conf,&$comments,&$sect_name,&$key,
			&$sect_control,&$elem_value,&$val_readonly,&$required) {

		$func = $sect_control['_form_input_func'];
		if(!$callback = Ccms::get_inc_method_callback($func)) return false;

		$elem_name = $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']';
		$id = 'id_' . $elem_name;

		if(!empty($sect_control['app_key'])) {	// direct from an app.comments.ini primary class method
			$cms_app_ini_key = preg_replace('/^' . $sect_control['app_key'] . '/','',$key);
			$text = call_user_func_array($callback, array($sect_control,$cms_app_ini_key,$elem_name,$elem_value));
			} // if
		else
			$text = call_user_func_array($callback, array($sect_control,$key,$elem_name,$elem_value));

		if(!empty($text)) {
			echo $text;
			return true;
			} // if
		return false;
		} // make_input_elem_func()

	private function make_std_input_element(&$conf,&$comments,&$sect_name,&$key,
			&$sect_control,&$elem_value,&$val_readonly,&$required) {
		$elem_name = $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']';
		$id = 'id_' . $elem_name;

		echo self::make_type_input($elem_name,	// name
			$sect_name,	// section_name
			$key,	// key
			$elem_value,	// value
			false,	// size
			$val_readonly,	// readonly
			$this->efrm['use_typedef_as_default'],	// use type as default
			$required);	// required
		} // make_std_input_element()

	protected function make_input_elem(&$conf,&$comments,&$sect_name,&$key,$readonly) {
		if(is_array($readonly)) {
			if(isset($readonly[$sect_name][$key])) $val_readonly = $readonly[$sect_name][$key];
			else $val_readonly = false;
			} // if
		else $val_readonly = $readonly;
		if(is_array($this->efrm['required'])) $required = self::getDottedKeys2Var($this->efrm['required'],$sect_name . '.' . $key);
		else $required = $this->efrm['required'];

		if(($required) && ($val_readonly)) $required = false;	// stop a lock up

		// $elem_value = (isset($conf[$sect_name][$key]) ? $conf[$sect_name][$key]:'');
		if((self::is_key_in_array($sect_name, $conf)) &&
			(self::is_key_in_array($key, $conf[$sect_name]))) {
			$elem_value = $conf[$sect_name][$key];
			}
		else $elem_value = '';	// not in $conf

		$sect_control = &$comments[$sect_name][$key];

		if(is_array($sect_control)) {
			if(isset($sect_control['select'])) {
				$this->make_input_elem_select($conf,$comments,$sect_name,$key,
					$sect_control,$elem_value,$val_readonly,$required);
				} // if
			else if(isset($sect_control['datalist'])) {
				$this->make_input_elem_datalist($conf,$comments,$sect_name,$key,
					$sect_control,$elem_value,$val_readonly,$required);
				} // if
			else if(isset($sect_control['input'])) {
				$this->make_input_elem_input($conf,$comments,$sect_name,$key,
					$sect_control,$elem_value,$val_readonly,$required);
				} // else if
			else if(isset($sect_control['_form_input_func'])) {
				if(!$this->make_input_elem_func($conf,$comments,$sect_name,$key,
					$sect_control,$elem_value,$val_readonly,$required)) {
					$this->make_std_input_element($conf,$comments,$sect_name,$key,
						$sect_control,$elem_value,$val_readonly,$required);
					} // if
				} // else if
			else {
				// not used here
				} // else
			} // if
		else {
			$this->make_std_input_element($conf,$comments,$sect_name,$key,
					$sect_control,$elem_value,$val_readonly,$required);
			} // else
		// return true;
		} // make_input_elem()

	protected function show_edit_ini_json_section_value(&$conf,&$comments,&$sect_name,&$key,&$value,&$row,$readonly,$sys_flg = false) {
		$disabled = self::getDottedKeys2Var($this->efrm['not_shown'],$sect_name . '.' . $key);
		if($disabled === true) return;
		if(is_array($value)) {
			$text_val = (isset($value['text']) ? $value['text']:(isset($value['comment']) ? $value['comment']:''));
			} // if
		else $text_val = $value;
		$elem_name = urlencode($sect_name . '_' . $key);
		if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $elem_name)) {
			$td_seld_class = $this->efrm['class'] . ' row_inline cms_hilite_selected';	// hilite select/found/named value
			} // if
		else $td_seld_class = $this->efrm['class'] . ' row_inline';

		?>

										<tr class="<?= $this->efrm['class'] . (($row & 1) ? '_odd':'_even') ?>">
											<td class="<?= $this->efrm['class'] ?>" style="vertical-align: top;">
												<?= '<a name="' . $elem_name . '"></a>' ?>
												<?= ($sys_flg ? $key : self::make_nice_name($key)) . ':' . ($this->efrm['show_code_links'] ? '<br>(' . $this->efrm['prefix'] . $key . ')':'') ?>
											</td>
											<td class="<?= $td_seld_class ?>">
												<?= $this->make_input_elem($conf,$comments,$sect_name,$key,$readonly) ?>
											</td>
											<td class="<?= $this->efrm['class'] ?>" style="vertical-align: top;"><?= $text_val ?></td>
										</tr>
		<?php
											$row++;
		} // show_edit_ini_json_section_value()

	protected function show_edit_ini_json_section_table(&$conf,&$comments,&$sect_name,&$section) {
		if((preg_match('/^_/',$sect_name)) || (!is_array($section))) return;
?>
									<table class="<?= $this->efrm['class'] ?>" border="1">
										<tr class="<?= $this->efrm['class'] ?>"
											<?= ($this->efrm['sticky_col_heads'] ? ' style="position: sticky; top: 0px; background-color: ivory; z-index: 2;"':'') ?>>
											<th class="<?= $this->efrm['class'] ?>"><h3 class="page_config">Name/Key</h3></th>
											<th class="<?= $this->efrm['class'] ?>" style="text-align: left"><h3 class="page_config">Value/Setting</h3></th>
											<th class="<?= $this->efrm['class'] ?>"><h3 class="page_config">Comments/Help</h3></th>
										</tr>
								<?php 	$row = 0;
										foreach($section as $key => $value) {
											if($key == 'comment') continue;
											$type = self::getDottedKeys2Var($comments, $sect_name . '.' . $key . '.select.type');
											$func = self::getDottedKeys2Var($comments, $sect_name . '.' . $key . '._form_input_func');
											if((isset($conf[$sect_name][$key])) &&
												((is_null($func)) || (empty($func))) &&
												((is_null($type)) || ($type != 'multiple'))) {
												if ((is_array($conf[$sect_name][$key])) || ($conf[$sect_name][$key] === self::THIRD_LEV_TOKEN)) {
													echo '<input type="hidden" name="' . $this->efrm['ary_name'] . '[' . $sect_name . '][' . $key . ']' . '" value="' . self::THIRD_LEV_TOKEN . '"/>' . PHP_EOL;
													continue; // sub-sub-array in json
													} // if
												} // if
											if($this->gen_sys_val($conf, $comments, $sect_name, $key, $value, $row)) continue;	// return true is system value
											$this->show_edit_ini_json_section_value($conf, $comments, $sect_name, $key, $value, $row,$this->efrm['readonly']);
											} // foreach ?>
									</table>
<?php
		} // show_edit_ini_json_section_table()

	protected function show_edit_ini_json_section(&$conf,&$comments) {
		foreach($comments as $sect_name => $section) {
		$disabled = self::getDottedKeys2Var($this->efrm['not_shown'],$sect_name);
		if($disabled === true) { $this->sect_idx++; continue; }
		if(preg_match('/^_/i',$sect_name)) { ?>
				<tr class="<?= $this->efrm['class'] ?>">
					<td class="<?= $this->efrm['class'] ?>">
						<?= $section ?>
					</td>
				</tr>
<?php
			continue;
			} // if
?>
				<tr class="<?= $this->efrm['class'] ?>">
					<td class="<?= $this->efrm['class'] ?>">
						<table class="<?= $this->efrm['class'] ?>" border="0">
							<tr class="<?= $this->efrm['class'] ?>">
								<th class="<?= $this->efrm['class'] ?> row_inline">
									<a name="<?= urlencode($sect_name) ?>"></a>
									<?= $this->get_hn('h2',true,self::unmake_hungarion_fmt($sect_name)) ?>
								</th>
								<th class="<?= $this->efrm['class'] ?>" style="text-align: left" valign="bottom"><?php
									if((isset($comments[$sect_name]['comment'])) &&
										(!empty($comments[$sect_name]['comment']))) {
										echo $comments[$sect_name]['comment'];
										} // if
									else echo '&nbsp;';
								?></th>
							</tr>
							<tr class="<?= $this->efrm['class'] ?>">
								<td class="<?= $this->efrm['class'] ?>" colspan="2">
									<?php $this->show_edit_ini_json_section_table($conf,$comments,$sect_name,$section) ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr class="<?= $this->efrm['class'] ?>"><td class="<?= $this->efrm['class'] ?>">&nbsp;</td></tr>
<?php

			$this->sect_idx++;
			} // foreach
		} // show_edit_ini_json_section()

	protected function get_extra_form(&$extra_form) {
		if((!$extra_form) || (empty($extra_form))) return false;
?>
				<tr class="<?= $this->efrm['class'] ?>">
					<td class="<?= $this->efrm['class'] ?>">
						<?= $extra_form ?>
					</td>
				</tr>
<?php
		return true;
		} // get_extra_form()

	protected function get_pre_form_buttons(&$name,&$conf,&$comments) {
?>

						<tr class="<?= $this->efrm['class'] ?>">
							<td class="<?= $this->efrm['class'] ?>">
								<div class="cms_sticky_left">
									<?= Ccms::get_return2search_link() ?>
									<?php if($this->efrm['show_cancel']) { ?>
									&nbsp;&nbsp;
									<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" title="Cancel changes and reload." formnovalidate>Cancel</button>
									<?php	} // if ?>
									<?php if(($this->efrm['show_reload']) && (Ccms_auth::is_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
									&nbsp;&nbsp;
									<button name="reloadINI" value="reloadINI" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise default."
											onClick="return confirm('Clear and re-initialise default?.')"<?= ($this->efrm['readonly'] ? ' READONLY':'') ?>>Defaults</button>
									<a name="DEFAULT_INSTALL_BUTTON"></a>
									<?php	} // if ?>
									<?php if($this->efrm['show_new']) { ?>
									&nbsp;&nbsp;
									<button name="new" value="new" type="button" onclick="set_new_edit_form('<?= 'id_' . $name ?>');" title="Click for new"<?= ($this->efrm['readonly'] ? ' READONLY':'') ?>>New</button>
									<?php	} // if ?>
									<?php if($this->efrm['show_save']) { ?>
									&nbsp;&nbsp;
									<button name="save" value="save" type="submit" title="Click to save"<?= ($this->efrm['readonly'] ? ' READONLY':'') ?>>Save</button>
									<?php if((self::is_debug()) && (!empty($this->efrm['dest_name']))) echo '<span class="' . $this->efrm['class'] . '">to &quot;' . $this->efrm['dest_name'] . '&quot;.</span>' . PHP_EOL ?>
									<?php	} // if ?>
								</div>
							</td>
						</tr>

<?php
		} // get_pre_form_buttons()

	protected function get_post_form_buttons(&$name,&$conf,&$comments) {
?>

						<tr class="<?= $this->efrm['class'] ?>">
							<td class="<?= $this->efrm['class'] ?>" style="text-align: right">
								<?php $this->get_h1_h2_h3(false,'h2') ?>
								<?php if($this->efrm['show_new']) { ?>
								&nbsp;&nbsp;
								<button name="new" value="new" type="button" onclick="set_new_edit_form('<?= 'id_' . $name ?>');" title="Click for new"<?= ($this->efrm['readonly'] ? ' READONLY':'') ?>>New</button>
								<?php	} // if ?>
								<?php if($this->efrm['show_save']) { ?>
								&nbsp;&nbsp;
								<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();" title="Click to save"<?= ($this->efrm['readonly'] ? ' READONLY':'') ?>>Save</button>
								<?php	} // if ?>
								<?php if($this->efrm['show_cancel']) { ?>
								&nbsp;&nbsp;
								<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" title="Cancel changes and reload." formnovalidate>Cancel</button>
								<?php	} // if ?>
								<?php if(($this->efrm['show_reload']) && (Ccms_auth::is_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
								&nbsp;&nbsp;
								<button name="reloadINI" value="reloadINI" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise default."
										onClick="return confirm('Clear and re-initialise default?.')"
										<?= ($this->efrm['readonly'] ? ' READONLY':'') ?>>Defaults</button>
								<a name="DEFAULT_INSTALL_BUTTON"></a>
								<?php	} // if ?>
							</td>
						</tr>

<?php
		} // get_post_form_buttons()

	protected function show_edit_ini_json_form(&$name,&$conf,&$comments) {
		$this->ins_dyn_ctl_js();
?>
			<tr class="<?= $this->efrm['class'] ?>">
				<td class="<?= $this->efrm['class'] ?>">
					<form method="post" id="id_<?= $name ?>"
						name="<?= $name ?>"
						onsubmit="if(validate_edit_form('<?= 'id_' . $name ?>')) { Ccms_cursor.setWait(); return true; } else false;"
						action="<?= (!empty($this->efrm['cms_action_uri']) ? $this->efrm['cms_action_uri']:$this->efrm['action_uri']) ?>">
					<table class="<?= $this->efrm['class'] ?>" style="border: 0; padding: 0;">
	<?php		$this->get_extra_form($this->efrm['pre_extra_form']) ?>
	<?php		echo Ccms_search::get_form_search_hidden_inputs() . PHP_EOL ?>
	<?php		$this->get_pre_form_buttons($name, $conf, $comments) ?>
	<?php		$this->show_edit_ini_json_section($conf, $comments) ?>
	<?php		$this->get_post_form_buttons($name, $conf, $comments) ?>
	<?php		$this->get_extra_form($this->efrm['post_extra_form']) ?>
					</table>
					</form>
	<?php		echo self::getMsgsStack() ?>
				</td>
			</tr>
<?php
		} // show_edit_ini_json_form()

	protected function get_extra_text(&$extra_text) {
		if((!$extra_text) || (empty($extra_text))) return false;
?>
				<tr class="<?= $this->efrm['class'] ?>">
					<td class="<?= $this->efrm['class'] ?>">
						<?= $extra_text ?>
					</td>
				</tr>
<?php
		return true;
		} // get_extra_text()

	private function get_edit_options(&$opts_ary,$h1) {
		$this->efrm = array(
			'action_uri' => '',
			'cms_action_uri' => '',
			'ary_name' => 'edit_options_ary',
			'class' => 'page_config',
			'dest_file' => ETC_FS_CMS_CONFIG,
			'not_shown' => false,		// an array of not shown entries
			'post_extra_form' => false,	// extra at the end inside the form
			'pre_extra_form' => false,	// extra at the beginning inside the form
			'post_extra_text' => false,	// extra at the end of the table
			'pre_extra_text' => false,	// extra at the beginning of the table
			'prefix' => 'CMS_S_',
			'readonly' => false,		// true = everything readonly or can be an array of keys that selects readonly elements, false = nothing readonly
			'show_code_links' => self::is_debug(),
			'show_scroll2top' => true,
			'show_new' => false,
			'show_save' => true,
			'show_cancel' => true,
			'show_reload' => true,
			'show_found_name' => true,
			'show_constant_name' => false,
			'show_sys_vals' => self::is_debug(),
			'sticky_col_heads' => false,
			'required' => false,
			'use_typedef_as_default' => false,
			'use_last_posted' => false,
			'h1' => $h1,		// this should not be an array, only one h1 allowed per page
			'h2' => false,		// this is usually the section name, these could be arrays in an extended class
			'h3' => false,		// these could be arrays in an extended class
			'ext' => array(),	// extension controls used in an extended class
			);
		if(!self::get_cms_action())
			$this->efrm['action_uri'] = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
		else
			$this->efrm['cms_action_uri'] = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];

		foreach($this->efrm as $n => $v) {
			if(isset($opts_ary[($n)])) $this->efrm[($n)] = $opts_ary[($n)];
			} // for
		// do specials
		if(isset($opts_ary['dest_name'])) self::log_msg('Code error: "dest_name" is computed from "dest_file".','ERROR');
		$this->efrm['dest_name'] = basename($this->efrm['dest_file']);
		if($this->efrm['readonly'] === true) {
			$this->efrm['show_new'] = false;
			$this->efrm['show_save'] = false;
			$this->efrm['show_cancel'] = false;
			$this->efrm['show_reload'] = false;
			} // if
		} // get_edit_options()

	private function get_last_posted_data(&$conf) {
		if(!self::$last_posted_data) return;	// nothing saved
		if(!$this->efrm['use_last_posted']) return;
		foreach($conf as $k => &$v) {
			if((isset(self::$last_posted_data[$k])) &&
				((gettype(self::$last_posted_data[$k])) == gettype($conf[$k]))) {
				// use previous vale
				$conf[$k] = self::$last_posted_data[$k];
				} // if
			} // foreach
		self::$last_posted_data = false;
		} // get_last_posted_data()

	public function show_edit_ini_json_page($name,$h1,&$conf,&$comments,$opts_ary = false) {
		$this->get_edit_options($opts_ary,$h1);
		$this->get_last_posted_data($conf);
		if(!self::$js_done) {
			self::$js_done = true;	// the last one of
			if($this->efrm['show_scroll2top']) echo self::get_admin_scroll2pageTop();
			Ccms::get_JS_colour_picker_resource();
			if(($this->efrm['show_new']) || ($this->efrm['show_save'])) {
?>
	<script type="text/javascript">

		function set_new_edit_form(form_id) {
			var form = cms_clear_form_to_empty(form_id);
			} // set_new_edit_form()

		function validate_edit_form(form_id) {
			if(!cms_validate_form_required(form_id)) return false;
			Ccms_cursor.setWait();
			return true;
 			} // validate_edit_form()

	</script>
<?php
			} // if
		} // if
?>
		<table class="<?= $this->efrm['class'] ?>">
		<?= $this->get_h1_h2_h3(true,'h1') ?>
		<?= $this->get_extra_text($this->efrm['pre_extra_text']) ?>
		<?= $this->show_edit_ini_json_form($name, $conf, $comments) ?>
		<?= $this->get_extra_text($this->efrm['post_extra_text']) ?>
		</table>
<?php	if((!self::get_or_post('cancel')) &&
			($this->efrm['show_found_name']) &&
			($name = Ccms::get_or_post('name'))) {
			$keywords = Ccms::get_or_post('keywords');
	?>
		<script type="text/javascript">
			cms_showFoundName('<?= $name ?>','<?= (!empty($keywords) ? $keywords:'') ?>');
		</script>
<?php
			} // if
		} // show_edit_ini_json_page()

} // Ccms_edit
