<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api_funcs.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of Ccms_api_funcs
 *
 * API execute class
 *
 * Refer to cms_api_map.php for API mapping.
 *
 * @author robert0609
 */

require_once 'cms_api_base.php';	// speed up (no autoloader needed)

class Ccms_api_funcs extends Ccms_api_base {

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

// dynamic methods
	protected function cmd_api_resource($method,&$func_cntl,&$params) {	// special case
		if($method != 'get') return false;
		$resource = Ccms_api_map::get_api_resource_map(false,true);
		$this->filter_api_keys($resource);
		if(empty($resource)) return false;
		return $resource;
		} // cmd_api_resource()

	protected function cmd_api_summary($method,&$func_cntl,&$params) {	// special case
		$summary = Ccms_api_map::get_api_resource_map();
		$this->filter_api_keys($summary);
		return $summary;
		} // cmd_api_summary()

	protected function cmd_api_open($method,&$func_cntl,&$params) {
		return Ccms_auth::login_api_user($params);
		} // cmd_api_open()

	protected function cmd_api_close($method,&$func_cntl,&$params) {
		return Ccms_auth::logout_api_user($params);
		} // cmd_api_close()

	private function tail_file(&$file,&$params) {
		if(empty($file)) return 'File not found.';
		$tail = $params['tail'];
		$grep = (!empty($params['grep']) ? ' | grep ' . $params['grep']:'');
		$ret = '';
		$output = '';
		if(!preg_match('/\.zip$/i',$file)) $cmd = 'cat "' . $file . '" ' . $grep . ' | tail -' . $tail;
		else $cmd = 'unzip -p "' . $file . '" ' . $grep . ' | tail -' . $tail;
		$err = exec($cmd, $output, $ret);
		if($ret) return false;
		return $output;
		} // tail_file()

	protected function cmd_api_cms_log($method,&$func_cntl,&$params) {
		$log_file = self::get_cms_log_filename();
		return $this->tail_file($log_file,$params);
		} // cmd_api_cms_log()

	protected function cmd_api_cli_log($method,&$func_cntl,&$params) {
		$log_file = self::get_cli_log_filename();
		return $this->tail_file($log_file,$params);
		} // cmd_api_cli_log()

	protected function cmd_api_error_cms_log($method,&$func_cntl,&$params) {
		$log_file = self::get_cms_error_filename();
		return $this->tail_file($log_file,$params);
		} // cmd_api_error_log()

	protected function cmd_api_error_cli_log($method,&$func_cntl,&$params) {
		$log_file = self::get_cli_error_filename();
		return $this->tail_file($log_file,$params);
		} // cmd_api_error_cli_log()

} // Ccms_api_funcs
