<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_SQLite.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of Ccms_SQLite
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_database_sqlite.php');

class Ccms_SQLite extends Ccms_database_sqlite {

	protected static $cmsDBinstallDone = false;
	public static $cmsDBreconstructDone = false;

	function __construct($database_file = false) {
		if(!$database_file) {
			if(!defined('CMS_S_DB_SQLITE_DATABASE')) {
				$db_file = Ccms_base::get_cms_ini_value('DB_SQLITE_DATABASE','DataBaseAccess');
				if(empty($db_file)) {
					self::addMsg('INI define SQLite DB missing.');
					if(self::is_cli()) exit(10);
					return;
					} // if
				define('CMS_S_DB_SQLITE_DATABASE',$db_file);
				} // if
			$database_file = ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE;
			} // if
		parent::__construct($database_file,'cms_configs');
		if(!$this->m_bNew) {	// check it is real
			if((!$res = $this->query('SELECT cms_config_value FROM cms_configs WHERE cms_config_key = \'CMS_C_ENABLED_PLUGINS\'')) ||
				(!$v = $this->fetch_array($res))) {	// bad
				$this->m_bNew = true;
				} // if
			} // if
		} // __construct()

	function __destruct() {
		// clean before I go home
		$this->close();
		parent::__destruct();
		} // __destruct()

	// methods
	public function init($install_tables) {
		if(!$this->is_ok()) return false;
		if(($this->m_bNew) || ($install_tables)) {
			self::chmod_chown($this->m_sDatabase);
//			if(!defined('USE_JSON_REBUILD'))
//				define('USE_JSON_REBUILD', true);
			if(($this->m_bNew) && (!self::is_debug())) {
				die('ERROR: Failed to open SQLite DB.');
				return false;
				} // if
			else if(!$this->installDatabase('',true,false)) {
				die('ERROR: Failed to install SQLite DB tables.');
				return false;
				} // if
			} // if
		$this->m_bNew = false;
		return true;
		} // init()

	public function close() {
		$this->save_reconstruct_DB_data();
		parent::close();
		} // close()

	public function save_reconstruct_DB_data($always = false) {
		if((defined('CMS_S_DB_SQLITE_JSON_MIRROR_BOOL')) &&
			(CMS_S_DB_SQLITE_JSON_MIRROR_BOOL) &&
			(!self::$cmsDBreconstructDone) &&
			(($this->db_chgd) || ($always)) &&
			(Ccms_auth::is_admin_user()) &&
			(!self::is_ajax())) {
			self::$cmsDBreconstructDone = true;	// dont repeat
			$install_scripts = Ccms_DB_install::get_installDBscriptsSQLite();
			$json_file = ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE . '.json';
			return $this->export_db2json($install_scripts,$json_file);
			} // if
		return false;
		} // save_reconstruct_DB_data()

	public function installDatabase($table = '', $verbose = false, $drop = false) {
		if(empty($table)) {	// full install (rebuild)
			if(self::$cmsDBinstallDone) return true;	// done
			self::$cmsDBinstallDone = true;	// only once
			} // if

		$install_scripts = Ccms_DB_install::get_installDBscriptsSQLite();

		$res = $this->install_db_tables($table,$install_scripts,true,$drop);
		if((!self::$cmsDBreconstructDone) && ($res) &&
			(Ccms_base::get_cms_ini_value('DB_SQLITE_JSON_MIRROR_BOOL','DataBaseAccess'))) {
			self::$cmsDBreconstructDone = true;	// dont repeat
			if(($this->m_bNew) ||
				((defined('USE_JSON_REBUILD')) && (USE_JSON_REBUILD))) {
				$json_file = ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE . '.json';
				$this->import_json2db($install_scripts,$json_file,$drop,$verbose);
				} // i
			} // if
		if(($res) &&
			(($table == 'cms_configs') || (empty($table)))) {
			$cms_plugins = Ccms::get_cms_config_value('CMS_C_ENABLED_PLUGINS');
			Ccms::do_plugin_installs($cms_plugins);
			} // if
		$this->db_chgd = true;
		return $res;
		} // installDatabase()

} // Ccms_SQLite
