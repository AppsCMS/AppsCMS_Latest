<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_sassc.php 2910 2022-10-24 09:59:51Z robert0609 $
 */

/**
 * Description of Ccms_sassc
 *
 * interface to sassc scss compiler
 *
 * @author robert0609
 */

use ScssPhp\ScssPhp\Compiler;

class Ccms_sassc extends Ccms_base {

	function __construct($src_f = false, $dest = false) {
		// parent::__construct();
		if((empty($src_f)) || (empty($dest))) return;
		self::compile_scss_f2f($src_f, $dest);
		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

	// static methods
		
	// dynamic methods
		
	public static function compile_scss_t2t(&$src_t) {	// compiles the .scss text
		if(empty($src_t)) return false;
		// compile scss file
		// which compiler
		if(is_readable(CMS_FS_LIB_DIR . 'scssphp/scss.inc.php')) {
			// see "https://scssphp.github.io/scssphp/"
			require_once (CMS_FS_LIB_DIR . 'scssphp/scss.inc.php');
			// not here use ScssPhp\ScssPhp\Compiler;
			try {
				$compiler = new Compiler();
				$text = @$compiler->compileString($src_t)->getCss();
				return $text;
				} // try
			catch(Exception $e) {
				self::addAdminMsg('SASSC compiler f2f error: ' . var_export($e,true));
				return false;
				} // catch
			} // if

		self::addAdminMsg('Failed to run sassc.');
		return false;
		} // compile_scss_t2t()

	public static function compile_scss_f2f($src_f, $dest) {	// compiles the .scss file
		if((empty($src_f)) || (empty($dest))) return false;
		if((!file_exists($src_f)) || (!is_readable($src_f)) || (!is_writable($dest))) return false;
		// compile scss file
		// which compiler
		if(is_readable(CMS_FS_LIB_DIR . 'scssphp/scss.inc.php')) {
			// see "https://scssphp.github.io/scssphp/"
			require_once (CMS_FS_LIB_DIR . 'scssphp/scss.inc.php');
			// not here use ScssPhp\ScssPhp\Compiler;
			try {
				$compiler = new Compiler();
				file_put_contents($dest, @$compiler->compileString(file_get_contents($src_f))->getCss());
				} // try
			catch(Exception $e) {
				self::addAdminMsg('SASSC compiler t2t error: ' . var_export($e,true));
				return false;
				} // catch
			} // if
		else {
			self::addAdminMsg('Failed to run sassc.');
			return false;
			} // else
			
		return true;
		} // compile_scss_f2f()

} // Ccms_sassc

