<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_base_sm_gs.php 2886 2022-10-16 15:03:38Z robert0609 $
 */

/**
 * Description of cms_base_sm_gs state machine gs class
 * Used to hold getters and setters for system state variables
 *
 * processing only done when value required (not as a bulk initialisation)
 * and don't do it more than once
 *
 * @author robert0609
 */

require_once 'cms_base_file.php';	// speed up for proxy (no autoloader needed)

class Ccms_base_sm_gs extends Ccms_base_file {

	// common variables
	public static $cms_page_info = false;
	protected static $cms_ssl_context = false;

	// state machine variables accessible only by there getters (and setters)
	// when set contain false, true or a string
	private static $sm_app_action = null;
	private static $sm_cms_action = null;
	private static $sm_mode_change = null;

	private static $sm_admin_user = null;
	private static $sm_ajax_op = null;
	private static $sm_api = null;
	private static $sm_api_user = null;
	private static $sm_apps_user = null;
	private static $sm_block_html = null;
	private static $sm_body_full_view = null;
	private static $sm_body_iframe_view = null;
	private static $sm_can_test = null;
	private static $sm_chrome = null;
	private static $sm_cli = null;
	private static $sm_cron = null;
	private static $sm_debug = null;
	private static $sm_edge = null;
	private static $sm_fox = null;
	private static $sm_group_manager = null;
	private static $sm_has_ssl_available = null;
	private static $sm_have_session = null;
	private static $sm_html5 = null;
	private static $sm_iframe_req = null;
	private static $sm_moz_4 = null;
	private static $sm_production = null;
	private static $sm_rebuild = null;
	private static $sm_safari = null;
	private static $sm_session_cookie = null;
	private static $sm_ssl_in_use = null;
	private static $sm_ssl_required = null;
	private static $sm_tablet = null;
	private static $sm_tiny = null;
	private static $sm_tooltips = null;
	private static $sm_core_language = null;
	private static $sm_user_language = null;
	private static $sm_user_locale = null;
	private static $sm_user_logged_in = null;
	private static $sm_username = null;
	private static $sm_version_str = null;
	private static $sm_www = null;
	
	private static $sm_rewrite = null;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// state machine variables getters and setters
	public static function get_app_action($set = null) {
		if(!is_null($set))
			self::$sm_app_action = $set;
		if(is_null(self::$sm_app_action)) {
			$action = Ccms_base::get_or_post('action');
			if(empty($action)) $action = Ccms_base::get_or_post('app_action');
			if($action == 'body') $action = false;	// @TODO why ????
			else if($action == 'app') $action = false;	// @TODO why ????
			self::$sm_app_action = (!empty($action) ? strtolower($action):false);
			} // if
		return self::$sm_app_action;
		} // get_app_action()

	public static function get_cms_action($set = null) {
		if(!is_null($set))
			self::$sm_cms_action = $set;
		if(is_null(self::$sm_cms_action)) {
			$action = Ccms_base::get_or_post('cms_action');
			self::$sm_cms_action = (!empty($action) ? strtolower($action):false);
			} // if
		return self::$sm_cms_action;
		} // get_cms_action()

	public static function is_mode_change($set = null) {	 // used to detect transitions in operational mode/state (ie logged in to logged out, etc)
		if(!is_null($set))
			self::$sm_mode_change = $set;
		if(is_null(self::$sm_mode_change)) {
			if(preg_match('/login|logout|signin|signout|rebuild|cms_edit/i',self::get_cms_action() . self::get_app_action() . (!empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER']:''))) {
				self::set_cms_sess_var(2,'modchg');		// 1 for this change and 1 for a redirect
				self::$sm_mode_change = true;
				} // if
			else if(($cnt = self::get_cms_sess_var('modchg')) && ($cnt > 0)) {
				$cnt--;
				self::$sm_mode_change = true;
				self::set_cms_sess_var($cnt,'modchg');
				} // else if
			else self::$sm_mode_change = false;
			} // if
		return self::$sm_mode_change;
		} // is_mode_change()

	public static function get_core_language($set = null) {
		if(!is_null($set)) self::$sm_core_language = $set;
		if(is_null(self::$sm_core_language)) {
			if((defined('CMS_S_LANGUAGE_CODE')) &&
				(!empty(CMS_S_LANGUAGE_CODE))) 
				self::$sm_core_language = CMS_S_LANGUAGE_CODE;
			else if(($lang = Ccms_base::get_cms_ini_value('CMS_S_LANGUAGE_CODE')) &&
				(!empty($lang))) 
				self::$sm_core_language = $lang;
			else self::$sm_core_language = CMS_CORE_LANG;
			} // if
		return self::$sm_core_language;
		} // get_core_language()

	public static function get_user_language($set = null) {
		if(!is_null($set)) self::$sm_user_language = $set;
		if(is_null(self::$sm_user_language)) {
			// e.g. $_SERVER['HTTP_ACCEPT_LANGUAGE'] = "en-AU,en-US;q=0.7,en;q=0.3";
			if((!!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) ||
				(empty($_SERVER['HTTP_ACCEPT_LANGUAGE']))) {
				return self::get_core_language();
				} // if
			$lang_qs = explode(',',$_SERVER['HTTP_ACCEPT_LANGUAGE']);
			$langs = array();
			foreach($lang_qs as $lq) {
				$l_q = explode(';',$lq);
				if(isset($l_q[1])) $langs[($l_q[0])] = (int)substr($l_q[1],2);
				else $langs[($l_q[0])] = (int)1;
				} // foreach
			krsort($langs);
			reset($langs);
			$hk = ''; $hq = 0.0;
			foreach ($langs as $key => $val) {	// this should not be necessary !!!!
				if($val > $hq) { $hq = $val; $hk = $key; }	// pick highest Q
				} // foreach
			self::$sm_user_language = $hk;
			} // if
		return self::$sm_user_language;
		} // get_user_language()

	public static function get_user_locale($set = null) {
		if(!is_null($set)) self::$sm_user_locale = $set;
		if(is_null(self::$sm_user_locale)) {
			if(self::is_cli()) {
				self::$sm_user_locale = self::get_core_language();
				} // if
			else if(!function_exists('locale_accept_from_http')) {	// uninstalled pkg
				$lang = ($l = self::get_cms_sess_var('clientMetadata','user_lang') ? $l:false);	// from horse's mouth
				if(!$lang) $lang = self::get_user_language();	// browser ?!?!
				self::$sm_user_locale = $lang;
				} // if
			else {	// use a bit more sophification
				if((empty($lang)) && (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) &&
					(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE']))) {
					$locale = locale_accept_from_http($_SERVER['HTTP_ACCEPT_LANGUAGE']);
					} // if
				else if(!empty($lang)) $locale = locale_accept_from_http($lang);
				else $locale = false;
				if(empty($locale)) {
					$lang = self::get_user_language();	// browser ?!?!
					$locale = locale_accept_from_http($lang);
					} // if
				self::$sm_user_locale = $locale;
				} // else
			} // if
		return self::$sm_user_locale;
		} // get_user_locale()

	public static function is_debug($set = null) {
		if(!is_null($set)) self::$sm_debug = $set;
		if(is_null(self::$sm_debug)) {
			if(defined('CMS_S_DEBUG_BOOL')) self::$sm_debug = CMS_S_DEBUG_BOOL;
			else return true;
			} // if
		return self::$sm_debug;
		} // is_debug()

	public static function is_production($set = null) {
		if(!is_null($set)) self::$sm_production = $set;
		if(is_null(self::$sm_production)) {
			$production = (!defined('CMS_C_WEB_SITE_ADDRESS') ? Ccms::get_cms_config_value('CMS_C_WEB_SITE_ADDRESS'):CMS_C_WEB_SITE_ADDRESS);
			$production = preg_replace('/^http[s]*:\/\//', '', $production);
			$production = preg_replace('/\/.*$/', '', $production);

			$current = CMS_DOMAIN;
			self::$sm_production = (($production == $current) ? true:false);
			} // if
		return self::$sm_production;
		} // is_production()

	public static function can_test($set = null) {
		if(!is_null($set)) self::$sm_can_test = $set;
		if(!is_null(self::$sm_can_test)) return self::$sm_can_test;
		if(!self::is_cli()) {
			self::$sm_can_test = false;
			return self::$sm_can_test;
			} // if
		$can_test_ips = '';
		if(!defined('CMS_S_CAN_TEST_APPS_CIDR'))
			$can_test_ips = self::get_cms_ini_value ('CAN_TEST_APPS_CIDR','AppsControlSettings');	//
		else $can_test_ips = CMS_S_CAN_TEST_APPS_CIDR;
		if(strlen($can_test_ips) < 4) {
			self::$sm_can_test = false;
			return self::$sm_can_test;
			} // if
		$nets = explode(',',$can_test_ips);
		foreach($nets as $net) {
			if($net == '!0.0.0.0') {
				self::$sm_can_test = false;
				break;
				} // if
			if($net == '0.0.0.0') {
				self::$sm_can_test = true;
				break;
				} // if
			if(self::ipCIDRCheck(self::$cms_client_ip,$net)) {
				self::$sm_can_test = true;	// on test network
				break;
				} // if
			} // foreach
		return self::$sm_can_test;
		} // can_test()

	public static function is_rebuild($set = null) {
		if(!is_null($set)) self::$sm_rebuild = $set;
		if(is_null(self::$sm_rebuild)) {
			self::$sm_rebuild = (((defined('REBUILD_MODE')) && (REBUILD_MODE)) ? true:false);
			} // if
		return self::$sm_rebuild;
		} // is_rebuild()

	public static function is_www($set = null) {
		if(!is_null($set)) self::$sm_www = $set;
		if(is_null(self::$sm_www)) {
			if((defined('WWW_CALL')) && (WWW_CALL)) self::$sm_www = true;
			else if((!empty($_SERVER['REQUEST_URI'])) &&
				(preg_match('/index\.php$/',$_SERVER['REQUEST_URI']))) self::$sm_www = $set;
			else self::$sm_www = false;
			} // if
		return self::$sm_www;
		} // is_www()

	public static function get_ajax($set = null) {
		if(!is_null($set)) self::$sm_ajax_op = $set;
		if(is_null(self::$sm_ajax_op)) {
			if(Ccms_base::is_get_or_post('ajax'))	// standard ajax call have a function/class/plupin name
				self::$sm_ajax_op = Ccms_base::get_or_post('ajax');
			else if((defined('AJAX_CALL')) && (AJAX_CALL)) self::$sm_ajax_op = true;	// Something
			else self::$sm_ajax_op = false;
			} // if
		return self::$sm_ajax_op;
		} // get_ajax()

	public static function is_ajax($set = null) {	// to keep the in_ scheme
		return (self::get_ajax($set) ? true:false);
		} // is_ajax()

	public static function is_iframe_request($set = null) {	// to keep the in_ scheme
		if(!is_null($set)) self::$sm_iframe_req = $set;
		if(is_null(self::$sm_iframe_req)) {
			if((isset($_SERVER['HTTP_SEC_FETCH_DEST'])) &&
				($_SERVER['HTTP_SEC_FETCH_DEST'] == 'iframe' ))
				self::$sm_iframe_req = true;
			else self::$sm_iframe_req = false;
			} // if
		return self::$sm_iframe_req;
		} // is_iframe_request()

	public static function is_api($set = null) {
		if(!is_null($set)) self::$sm_api = $set;
		if(is_null(self::$sm_api)) {
			if((defined('API_CALL')) && (API_CALL)) self::$sm_api = true;
			else if(Ccms_base::is_get_or_post('api')) self::$sm_api = true;	// old apps api
			else if((!empty($_SERVER['PHP_SELF'])) &&
				(preg_match('/\/api.php|\/api\/.+/',$_SERVER['PHP_SELF']))) self::$sm_api = true;
			else self::$sm_api = false;
			} // if
		return self::$sm_api;
		} // is_api()

	public static function is_cli($set = null) {
		if(!is_null($set)) self::$sm_cli = $set;
		if(is_null(self::$sm_cli)) {
			self::$sm_cli = (((defined('CLI_MODE')) && (CLI_MODE)) ? true:false);
			} // if
		return self::$sm_cli;
		} // is_cli()

	public static function is_cron($set = null) {
		if(!is_null($set)) self::$sm_cron = $set;
		if(is_null(self::$sm_cron)) {
			self::$sm_cron = (((defined('CRON_MODE')) && (CRON_MODE)) ? true:false);
			} // if
		return self::$sm_cron;
		} // is_cron()

	public static function is_tiny($set = null) {
		if(!is_null($set)) self::$sm_tiny = $set;
		if(is_null(self::$sm_tiny)) {
			self::$sm_tiny = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_tiny;
		} // is_tiny()

	public static function is_tablet($set = null) {
		if(!is_null($set)) self::$sm_tablet = $set;
		if(is_null(self::$sm_tablet)) {
			self::$sm_tablet = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_tablet;
		} // is_tablet()

	public static function is_computer_device() {
		return (!self::is_tiny_device() && !self::is_tablet_device());
		} // is_computer_device()

	public static function have_session($set = null) {
		if(!is_null($set)) self::$sm_have_session = $set;
		if(is_null(self::$sm_have_session)) {
			self::$sm_have_session = (empty(session_id()) ? false:true);
			} // if
		return self::$sm_have_session;
		} // have_session()

	public static function session_cookie_ok($set = null) {
		if(!is_null($set)) self::$sm_session_cookie = $set;
		if(is_null(self::$sm_session_cookie)) {
			self::$sm_session_cookie = self::have_session();
			} // if
		return self::$sm_session_cookie;
		} // session_cookie_ok()

	public static function use_tooltips($set = null) {
		if(!is_null($set)) self::$sm_tooltips = $set;
		if(is_null(self::$sm_tooltips)) {
			self::$sm_tooltips = false;	// default
			} // if
		return self::$sm_tooltips;
		} // use_tooltips()

	public static function use_block_html($set = null) {
		if(!is_null($set)) self::$sm_block_html = $set;
		if(is_null(self::$sm_block_html)) {
			self::$sm_block_html = CMS_S_PAGE_STYLE_BLOCK_BOOL;
			if ((self::is_full_body_view()) || (!CMS_S_HEADER_BOOL) || (!CMS_S_FOOTER_BOOL))
				self::$sm_block_html = false;
			else if ((CMS_C_CUSTOM_HEADER) || (CMS_C_CUSTOM_FOOTER))
				self::$sm_block_html = false;

			if (self::is_tablet())
				self::$sm_block_html = false;
			if (self::is_tiny())
				self::$sm_block_html = false;
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_block_html;
		} // use_block_html()

	public static function is_full_body_view($set = null) {
		if(!is_null($set)) self::$sm_body_full_view = $set;
		if(is_null(self::$sm_body_full_view)) {
			if(self::is_iframe_request())
				self::$sm_body_full_view = true;
			else if(!empty(self::$cms_page_info['cms_body_full_view']))
				self::$sm_body_full_view = true;
			else self::$sm_body_full_view = false;
			} // if
		return self::$sm_body_full_view;
		} // is_full_body_view()

	public static function is_iframe_body_view($set = null) {
		if(!is_null($set)) self::$sm_body_iframe_view = $set;
		if(is_null(self::$sm_body_iframe_view)) {
			if(self::is_iframe_request())
				self::$sm_body_iframe_view = false;
			else if((!self::is_full_body_view()) &&
				(!empty(self::$cms_page_info['cms_body_iframe_view'])))
				self::$sm_body_iframe_view = true;
			else self::$sm_body_iframe_view = false;
			} // if
		return self::$sm_body_iframe_view;
		} // is_iframe_body_view()


	public static function is_moz4($set = null) {
		if(!is_null($set)) self::$sm_moz_4 = $set;
		if(is_null(self::$sm_moz_4)) {
			self::$sm_moz_4 = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_moz_4;
		} // is_moz4()

	public static function is_firefox($set = null) {
		if(!is_null($set)) self::$sm_fox = $set;
		if(is_null(self::$sm_fox)) {
			self::$sm_fox = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_fox;
		} // is_firefox()

	public static function is_chrome($set = null) {
		if(!is_null($set)) self::$sm_chrome = $set;
		if(is_null(self::$sm_chrome)) {
			self::$sm_chrome = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_chrome;
		} // is_chrome()

	public static function is_safari($set = null) {
		if(!is_null($set)) self::$sm_safari = $set;
		if(is_null(self::$sm_safari)) {
			self::$sm_safari = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_safari;
		} // is_safari()

	public static function is_ms_edge($set = null) {
		if(!is_null($set)) self::$sm_edge = $set;
		if(is_null(self::$sm_edge)) {
			self::$sm_edge = false; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_edge;
		} // is_ms_edge()

	public static function is_html5($set = null) {
		if(!is_null($set)) self::$sm_html5 = $set;
		if(is_null(self::$sm_html5)) {
			self::$sm_html5 = true; // default
			new Ccms_detector();	// detect client device and browser
			} // if
		return self::$sm_html5;
		} // is_html5()

	public static function get_version_str() {
		if(!is_null(self::$sm_version_str)) return self::$sm_version_str;
		if(Ccms_base::is_get_or_post('ajax')) self::$sm_version_str = '';	// not done for ajax, speed it up
		else {
			$v_str = '';	// wrong CMS_C_TITLE;

			if (self::is_group_manager()) {
				$v_str .= '' .strip_tags(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION);
				$v_str .= ', DB V' . self::$cDBcms->m_sVersion;
				$v_str .= (self::is_debug() ? ', (Debug)' : '');
				$v_str .= (self::can_test() ? ', (Testing)' : '');
				$v_str .= (self::is_production() ? ', (Production)' : ', (Develop)');
				} // if

			if(!self::is_rebuild()) {
				// PHP function 'svn_status' used to work
				// get version stats
				// check for svn status
				$revision = false; $sretv = false;
				// eg # Last Changed Rev: 2111
				exec("/usr/bin/svn info " . DOCROOT_FS_BASE_DIR . " | grep -iE 'Last.*:' | sed 's/Last.*: //' | awk '{ print $1 }'",$revision,$sretv);
				if(($sretv == 0) && (!empty($revision)) && (count($revision) == 3)) {	// ok
					// $revision[0] == user
					$v_str .= ', SVN: ' . $revision[1] . ' ' . $revision[2];
					} // if

				// check for git status
				$branch = false; $bretv = false;
				// eg # On branch develop
				exec("/usr/bin/git status " . DOCROOT_FS_BASE_DIR . " | grep -i 'on branch'",$branch,$bretv);
				if(($bretv == 0) && (!empty($branch)) && (count($branch) == 1)) {	// ok
					$cdate = false; $cdretv = false;
					// eg 2017-07-31 14:57:26 +1000
					exec("/usr/bin/git show --format=%ai " . DOCROOT_FS_BASE_DIR . " | head -n 1",$cdate,$cdretv);
					if(($cdretv == 0) && (!empty($cdate))) { // ok
						$branch = preg_replace('/^.*on branch /i','',$branch[0]);
						$v_str .= ', GIT: ' . $branch . ' ' . date('d/m/Y', strtotime($cdate[0]));
						} // if
					} // if
				} // if
			self::$sm_version_str = $v_str;
			} // else
		return self::$sm_version_str;
		} //get_version_str()

	public static function has_ssl_available($set = null) {
		if(!is_null($set)) self::$sm_has_ssl_available = $set;
		if(is_null(self::$sm_has_ssl_available)) {
			$connection_context_option = array(
				'ssl' => array(
					'capture_peer_cert' => true,
					'verify_peer' => false,
					'verify_peer_name' => false,
					'allow_self_signed' => true,
					),
				);
			$stream = stream_context_create($connection_context_option);
			$domain = CMS_DOMAIN;	// it's me !!!!
			$url = 'ssl://' . $domain . ':443';
			$socket = @stream_socket_client($url, $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $stream );

			if($socket) {
				self::$sm_has_ssl_available = true;
				fclose($socket);
				} // if
			else self::$sm_has_ssl_available = false;
			} // if
		return self::$sm_has_ssl_available;
		} // has_ssl_available()

	public static function is_ssl_inuse($set = null) {
		if(!is_null($set)) self::$sm_ssl_in_use = $set;
		if(is_null(self::$sm_ssl_in_use)) {
			if((!empty($_SERVER['HTTPS'])) &&
				($_SERVER['HTTPS'] == 'on')) {
				self::$sm_ssl_in_use = true;	// running on SSL
				} //if
			else self::$sm_ssl_in_use = false;
			} // if
		return self::$sm_ssl_in_use;
		} // is_ssl_inuse()

	public static function is_ssl_required($set = null) {
		if(!is_null($set)) self::$sm_ssl_required = $set;
		if(is_null(self::$sm_ssl_required)) {
			if(self::is_cli())
				self::$sm_ssl_required = false;
			else if(self::is_api()) {
				if(CMS_C_API_SSL)
					self::$sm_ssl_required = true;
				else {
					self::$sm_ssl_required = false;
					} //
				} // if
			else if(self::get_ajax()) {	// match the original web site for ajax
				if((!empty($_SERVER['HTTPS'])) &&
					($_SERVER['HTTPS'] == 'on'))
					self::$sm_ssl_required = true;
				else self::$sm_ssl_required = false;
				} // if
			else if(self::is_iframe_body_view())
				self::$sm_ssl_required = true;
			else if(CMS_S_ALLOW_NON_SSL_LOGIN_BOOL)
				self::$sm_ssl_required = false;
			else if(CMS_S_ALWAYS_USE_SSL_BOOL)
				self::$sm_ssl_required = true;
			else if(self::is_user_logged_in())
				self::$sm_ssl_required = true;
			else if((!empty($_SERVER['PHP_SELF'])) &&
				(preg_match('/login|logout/i',$_SERVER['REQUEST_URI'])) &&
				(Ccms_auth::is_login_allowed()))
				self::$sm_ssl_required = true;
			else if(self::get_app_action()) {
				if((preg_match('/login|logout|edit.*|apps.*/',(self::get_cms_action() ? self::get_cms_action():self::get_app_action()))) &&
					(Ccms_auth::is_login_allowed()))
					self::$sm_ssl_required = true;
				else {
					switch((self::get_cms_action() ? self::get_cms_action():self::get_app_action())) {
					case 'tool':
						if(self::$cDBcms->get_data_in_table('cms_tools','cms_tool_ssl','cms_tool_id = ' . (int)self::$cms_tool_id))
							self::$sm_ssl_required = true;
						break;
					default:
						break;
						} // switch
					} // else
				} // if
			else {
				if((isset(self::$cms_page_info['body']['cms_body_ssl'])) &&
					(self::$cms_page_info['body']['cms_body_ssl'] > 0))
					self::$sm_ssl_required = true;
				} // else
			if((CMS_S_ALLOW_SELF_SIGNED_SSL_BOOL) &&
				(self::$sm_ssl_required) &&
				(!self::is_api())) {
				self::$cms_ssl_context = stream_context_set_default(
					array(
						'ssl' => array(
							'verify_peer' => false,
							'verify_peer_name' => false,
							),
						)
					);
				} // if
			} // if
		return self::$sm_ssl_required;
		} // is_ssl_required()

	public static function is_user_logged_in($set = null) {
		if(!is_null($set)) self::$sm_user_logged_in = $set;
		if(is_null(self::$sm_user_logged_in)) {
			if(Ccms_api_jwt::is_use_jwt_ok()) {
				self::$sm_user_logged_in = Ccms_api_jwt::is_jwt_user();
				} // if
			else if(!self::have_session()) return false;	// session not initiated yet
			else if(($user = self::get_cms_sess_var('user')) &&
				(!Ccms_auth::is_session_timed_out()))
				self::$sm_user_logged_in = true;
			else self::$sm_user_logged_in = false;
			} // if
		return self::$sm_user_logged_in;
		} // is_user_logged_in()

	public static function is_apps_user($set = null) {
		if(!is_null($set)) self::$sm_apps_user = $set;
		if(is_null(self::$sm_apps_user)) {
			if(!self::have_session()) return false;
			if(!self::is_user_logged_in()) self::$sm_apps_user = false;
			else if(self::is_apps_auth_logged_in()) self::$sm_apps_user = true;
			else self::$sm_apps_user = false;
			} // if
		return self::$sm_apps_user;
		} // is_apps_user()

	public static function is_admin_user($set = null) {
		if(!is_null($set)) self::$sm_admin_user = $set;
		if(is_null(self::$sm_admin_user)) {
			if(self::is_cli()) self::$sm_admin_user = true;
			else if((self::is_api()) && 
				(Ccms_api_jwt::is_use_jwt_ok()) && 
				(Ccms_api_jwt::is_jwt_admin())) {
				self::$sm_admin_user = true;
				} // if
			else {
				if(!self::have_session()) return false;
				else if(!self::is_user_logged_in()) self::$sm_admin_user = false;
				else if(self::get_cms_sess_var('user','admin')) self::$sm_admin_user = true;
				else self::$sm_admin_user = false;
				} // else
			} // if
		return self::$sm_admin_user;
		} // is_admin_user()

	public static function is_api_user($set = null) {
		if(!is_null($set)) self::$sm_api_user = $set;
		if(is_null(self::$sm_api_user)) {
			if(!CMS_C_API_ENABLE) self::$sm_api_user = false;
			else if(Ccms_api_jwt::is_use_jwt_ok()) {
				self::$sm_api_user = Ccms_api_jwt::sm_api_user();
				} // else if
			// else if(self::is_admin_user()) self::$sm_admin_user = true;
			else if(!self::have_session()) return false;
			else if(!self::is_user_logged_in()) self::$sm_admin_user = false;
			else if(self::get_cms_sess_var('user','API')) self::$sm_api_user = true;
			else self::$sm_api_user = false;
			} // if
		return self::$sm_api_user;
		} // is_api_user()

	public static function has_apache_rewrite($set = null) {
		if(!is_null($set)) self::$sm_rewrite = $set;
		if(is_null(self::$sm_rewrite)) {
			self::$sm_rewrite = false;
			if(function_exists('apache_get_modules')) {
				$found = array_filter(apache_get_modules(), function($d) {	// find module
					if(stripos($d,'rewrite') !== false) return true;	// found
					return false;
					});
				if(!empty($found)) self::$sm_rewrite = true;
				}// if			
			} // if
		return self::$sm_rewrite;
		} // has_apache_rewrite()

	public static function get_logged_in_username($set = null, $chk = false) {
		if(!is_null($set)) self::$sm_username = $set;
		if((is_null(self::$sm_username)) || ($chk)) {
			if(self::is_cli()) {
				$user = Ccms_posix::get_current_username();
				if(!$user) $user = 'CLI';
				self::$sm_username = $user;
				} // if
			else if(Ccms_api_jwt::is_use_jwt_ok()) {
				self::$sm_username = Ccms_api_jwt::get_jwt_username();
				} // else if
			else if(!self::have_session()) return false;	// session not initiated yet
			else if(!self::get_cms_sess_var('user','name')) self::$sm_username = 'Guest';
			else self::$sm_username = self::get_cms_sess_var('user','name');
			} // if
		return self::$sm_username;
		} // get_logged_in_username()

	public static function is_group_manager($gids = -1) {
		if(!self::is_user_logged_in()) return false;
		if(!is_null(self::$sm_group_manager)) return (self::$sm_group_manager ? true:false);

		self::$sm_group_manager = 0;
		if(self::is_admin_user()) self::$sm_group_manager = 1;
		else {
			if(Ccms_api_jwt::is_use_jwt_ok()) {
				$group_manager_ids = Ccms_api_jwt::get_jwt_group_manager_ids();
				} // else if
			else $group_manager_ids = self::get_cms_sess_var('user','group_manager_ids');

			if(!empty($group_manager_ids)) {
				if($gids == -1) self::$sm_group_manager = 1; // is a group manager of something
				else {
					$mids = explode(':',$group_manager_ids);
					$gids = explode(':',$gids);
					foreach($gids as $gid) {
						if((int)$gid == 0) { self::$sm_group_manager = 1; break; } // all groups
						else if(in_array($gid,$mids)) { self::$sm_group_manager = 1; break; }
						} // foreach
					} // else
				} // if
			} // else
		return (self::$sm_group_manager ? true:false);
		} // is_group_manager()

	public static function check_user_group_ids($group_ids) {
		if(strlen($group_ids) == 0) return false;
		$op_group_ids = explode(':',(string)$group_ids);
		if(in_array(0,$op_group_ids)) return true;	// all groups
		if(self::is_admin_user()) {
			self::$sm_group_manager = 1;
			return true;
			} // if
		else if(Ccms_api_jwt::is_use_jwt_ok()) {
			$group_manager_ids = Ccms_api_jwt::get_jwt_group_manager_ids();
			} // else if
		else $group_manager_ids = self::get_cms_sess_var('user','group_manager_ids');

		if(!$group_ids = self::get_cms_sess_var('user','group_ids')) return false;
		// else logged
		$user_group_ids = explode(':',(string)$group_ids);
		if(in_array(0,$user_group_ids)) return true;
		foreach($user_group_ids as $uid) {
			if(in_array($uid,$op_group_ids)) return true;
			} // foreach
		return false;
	} // check_user_group_ids()

	public static function is_config_user() {
		if(self::is_admin_user()) return true;
		return self::is_group_manager(-1);
		} // is_config_user()

	public static function is_cms_action() {
		if(self::get_cms_action()) return true;
		return self::get_app_action();
		} // is_cms_action()

	public static function is_admin_action($action = false) {
		if(!$action) $action = self::get_cms_action ();
		if(empty($action)) return false;
		if(preg_match('/login|logout/',$action)) return false;
		if(preg_match('/^cms_[_a-z]+$|^app[s]?_extend$/',$action)) return true;
//		switch($action) {	// too slow
//		case 'admin_extend':
//		// case 'apps_manual':
//		case 'cms_about':
//		case 'cms_browse_sessions':
//		case 'cms_users_stats':
//		case 'cms_debug_code':
//		case 'cms_debug_vars':
//		case 'cms_edit_apps':
//		case 'cms_edit_bodies':
//		case 'cms_edit_config':
//		case 'cms_edit_groups':
//		case 'cms_edit_header_footer':
//		case 'cms_edit_install':
//		case 'cms_edit_links':
//		case 'cms_edit_search':
//		case 'cms_edit_sections':
//		case 'cms_edit_theme':
//		case 'cms_edit_tools':
//		case 'cms_edit_users':
//		case 'cms_log_view':
//		case 'cms_manual':
//		case 'cms_rebuild_setup':
//		case 'update_sitemap':
//			return true;
////		case 'cookies':
////		case 'terms':
////		case 'licence':
////		case 'acknowledgement':
////		case 'release_notes':
////		case 'readme':
////		case 'link':
////		case 'tool':
////		case: 'get_password':
//		default:
//			break;
//			} // switch
		return false;
		} // is_admin_action()

	public static function reset_session_actions($more_idxs = false) {

		self::unset_cms_sess_var('action');
		Ccms_base::unset_get_or_post('action');

		self::unset_cms_sess_var('app_action');
		Ccms_base::unset_get_or_post('app_action');

		self::unset_cms_sess_var('cms_action');
		Ccms_base::unset_get_or_post('cms_action');

		if(!empty($more_idxs)) {
			if(!is_array($more_idxs)) {
				self::unset_cms_sess_var($more_idxs);
				} // if
			else { // array
				foreach($more_idxs as $idx) {
					self::unset_cms_sess_var($idx);
					} // foreach
				} // else
			} // if

		} // reset_session_actions()

} // Ccms_base_sm_gs
