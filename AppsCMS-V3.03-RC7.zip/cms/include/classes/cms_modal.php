<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_modal.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of cms_modal
 * dynamic modal class for AppsCMS
 *
 * Based on examples provided "https://www.w3schools.com/howto/howto_css_modals.asp"
 * 
 * @author robert0609
 */

class Ccms_modal extends Ccms_general {

	protected $styles_sent = false;
	protected $JS_sent = false;
	protected $modal_sent = false;
	
	protected $name = 'cms_modal';	// a name prefix for everything
	protected $id = '';
	protected $class_name = '';
	protected $class_str = '';	// e.g. ' class="class_name"'
	protected $theme = false;	// a pointer to the space
	protected $was_open = 'false';	// string for JS
	
	function __construct($was_open = false) {
		parent::__construct();
		$this->was_open = ($was_open ? 'true':'false');	// string for direct JS
		if(!$this->theme) {
			$this->theme = &Ccms_base::$cms_ini['ThemeSettings'];
			} // if
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// dynamic methods
	public function get_name() { return $this->name; } //  get_name()

	protected function get_styles(&$text) {
		if($this->styles_sent) return;
		$this->styles_sent = true;

		$text .= <<< EOCSS

	<style>
		/* the Whole Modal */
		#id_{$this->name}_container {
			display: none; /* Hidden by default */
			position: fixed; /* Stay in place */
			z-index: 1; /* Sit on top */
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			overflow: auto; /* Enable scroll if needed */
			background-color: rgb(0,0,0); /* Fallback color */
			background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
			}
		
		/* modal Content */
		#id_{$this->name}_modal {
			max-height: calc(100vw - 100px);
			max-width: calc(100vh - 100px);
			/* padding: 5px; */
			scroll-behavior: auto;
			}

		.{$this->name}_content {
			/* height: {$this->theme['MODAL_HEIGHT']}; */
			/* width: {$this->theme['MODAL_WIDTH']}; */
			
			position: relative;
			display: inline-block;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
			/* margin-top: 50px; */
			/* margin-right: auto; */
			/* margin-bottom: auto; */
			/* margin-left: auto; */
			padding: 5px;
			
			background-color: {$this->theme['MODAL_BKGD_COLOUR']};
			color: {$this->theme['MODAL_FONT_COLOUR']};
			border: {$this->theme['MODAL_BORDER']};
			font-family: {$this->theme['MODAL_FONT_FAMILY']};
			font-size: {$this->theme['MODAL_FONT_SIZE']};
			font-style: {$this->theme['MODAL_FONT_STYLE']};
			font-weight: {$this->theme['MODAL_FONT_WEIGHT']};
			/* overflow: hidden; */
			padding: 0;
			box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
			animation-name: fadein_{$this->name};
			animation-duration: 0.7s;
			}

		/* Add Animation */
		@keyframes fadein_{$this->name} {
			0% { opacity: 0; }
			100% { opacity: 1; }
			} 

		/* modal Header */
		.{$this->name}_header {
			padding: 2px 16px;
			}
		/* header logo */
		logo_' . $this->id {
			width: 100%;
			height: auto'
			}
		/* modal Body */
		.{$this->name}_body { 
			padding: 2px 16px;
			}

		/* The Close Button */
		.{$this->name}_close {
			float: right;
			font-size: 28px;
			font-weight: bold;
			}

		.{$this->name}_close:hover,
		.{$this->name}_close:focus {
			text-decoration: underline;
			cursor: pointer;
			}

		/* modal Footer */
		.{$this->name}_footer {
			padding: 2px 16px;
			}

   </style>

EOCSS;
		return true;
		} // get_styles()

	protected function get_JS(&$text,$go_home) {
		if($this->JS_sent) return;
		$this->JS_sent = true;
		$m_go_home = ($go_home ? 'true':'false');
		$text .= <<< EOJS

	<script type="text/javascript">
		// status 
		var {$this->name}_open_status = {$this->was_open};
		
		// Get the button that opens the cms_modal
		var {$this->name}_btn = document.getElementById("id_{$this->name}_btn");
		if({$this->name}_btn) {	// user has supplied open button
			// When the user clicks on the button, open the cms_modal
			{$this->name}_btn.onclick = {$this->name}_open_modal();
			} // if

		function {$this->name}_open_modal() {
			// Get the cms_modal
			var {$this->name} = document.getElementById('id_{$this->name}_container');
			{$this->name}.style.display = "block";
			{$this->name}_open_status = true;
			} // {$this->name}_open_modal()

		// Get the <span> element that closes the modal
		var {$this->name}_close = document.getElementsByClassName("{$this->name}_close")[0];
		if({$this->name}_close) {
			// When the user clicks on <span> (x), close the cms_modal
			{$this->name}_close.onclick = function() {
				{$this->name}_close_modal();
				} // {$this->name}_close.onclick()
			} // if

		function {$this->name}_close_modal() {
			var go_home = {$m_go_home};
			var {$this->name} = document.getElementById('id_{$this->name}_container');
			{$this->name}.style.display = "none";
			{$this->name}_open_status = false;
			if(go_home) {	// go if form not filled, etc
				window.location.href = 'index.php';
				} // if
			} // {$this->name}_close_modal()

		// When the user clicks anywhere outside of the cms_modal, close it
		window.onclick = function(event) {
			if (event.target == {$this->name}_close) {
				{$this->name}_close_modal();
				} // if
			} // window.onclick()
		
		if({$this->name}_open_status) {$this->name}_open_modal(); 

	</script>

EOJS;
		return true;
		} // get_JS()

	protected function get_modal_header(&$text,&$h1,&$header) {

		if(!empty($header)) {
			$text .= <<< EOHDR
		
		<div id="id_{$this->name}_header" class="{$this->name}_header {$this->class_name}">
			{$header}
		</div>

EOHDR;
			return true;		
			} // if
			
		$h1_part = (!empty($h1) ? '<h1' . $this->class_str . ' style="text-align: center;">' . $h1 . '</h1>' . PHP_EOL:'');
		
		if(strlen(CMS_C_LOGO_IMAGE) > 4) {
			$logo = '<img alt="logo" class="logo logo_' . $this->id . '" src="' . (file_exists(DOCROOT_FS_BASE_DIR . CMS_C_LOGO_IMAGE) ? CMS_C_LOGO_IMAGE:ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE) . '" alt="' . trim(strip_tags(CMS_C_CO_NAME)) . ' Logo" title="' . trim(CMS_C_TITLE) . '">' . PHP_EOL;
			} // if
		else $logo = '<h2' . $this->class_str . ' style="text-align: center;">' . trim(CMS_C_CO_NAME) . '</h2>' . PHP_EOL;
		
		$text .= <<< EOTOP
		
		<div id="id_{$this->name}_header" class="{$this->name}_header {$this->class_name}">
			<table>
				<tr>
					<td style="text-align: left; width: 20%;">
						<a href="index.php">{$logo}</a>
					</td>
					<td style="text-align: center;">{$h1_part}</td>
					<td style="text-align: right; width: 20%;">
						<span class="{$this->name}_close {$this->class_name}" title="Close">&times;</span>
					</td>
				</tr>
			</table>
		</div>
EOTOP;
		return true;		
		} // get_modal_header()

	protected function get_modal_body(&$text,&$body_text) {
		$text .= <<< EOBODY
		
		<div id="id_{$this->name}_body" class="{$this->name}_body {$this->class_name}">
			{$body_text}
		</div>
		
EOBODY;
	
		return true;		
		} // get_modal_body()

	public function get_modal_footer(&$text,&$footer) {
		if(!empty($footer)) {
			$text .= <<< EOFOOT
		
		<div id="id_{$this->name}_footer" class="{$this->name}_footer {$this->class_name}">
			{$footer}
		</div>
		
EOFOOT;
			} // if
		
		return true;		
		} // get_modal_footer()

	public function get_modal($id, &$body_text, $class_name = '', $h1 = '', $header = '', $footer = '',$name = '',$go_home = false) {
		if(empty($id)) return false;
		if(empty($body_text)) return false;
		$id = preg_replace('/\./','_',$id);
		if($this->modal_sent) {
			if($this->id === $id)	return true;
			// else another modal dialog
			$this->styles_sent = false;
			$this->JS_sent = false;
			} // if
		$this->modal_sent = true;
		$this->id = $id;
		if(!empty($name)) $this->name = $name;
		$this->name .= '_' . $this->id;
		$this->class_name = $class_name;
		$this->class_str = (!empty($this->class_name)  ? ' class="' . $this->class_name . '"':'');
		
		$text = '';
		$this->get_styles($text);
		$text .= '<span id="id_' . $this->name . '_container">' . PHP_EOL;
		
		$text .= <<< EOTOP
		
	<!-- Modal content STX -->
	<div id="id_{$this->name}_modal" class="{$this->name}_content {$this->class_name}">
EOTOP;
		$this->get_modal_header($text, $h1, $header);
		$this->get_modal_body($text, $body_text);
		$this->get_modal_footer($text, $footer);
		
		$text .= <<< EOBOT
		
	</div> 
	<!-- Modal content ETX -->
		
EOBOT;
		
		$text .= '</span>' . PHP_EOL;

		$this->get_JS($text,$go_home);

		return $text;		
		} // get_modal()

	} // Ccms_modal
