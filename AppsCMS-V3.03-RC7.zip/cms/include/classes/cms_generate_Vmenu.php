<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_generate_Vmenu.php 2815 2022-09-22 00:16:25Z robert0609 $
 */

class Ccms_generate_Vmenu extends Ccms_base {
	// put up a single column menu table (the old fashioned way)
	// this would be a whole lot better using W3 WAI-ARIA (too many browsers dragging their feet)

	protected $row = false;
	protected $id = false;
	protected $use_js = false;
	protected $search_mode = true;
	protected $search_min_req_entries = 48;
	protected $caption = false;
	protected $text = false;
	public $style_class = false;

	function __construct($id_txt, $style_class, &$table, $use_js = true, $search_mode = true, $search_min_req_entries = false, $caption = false) {
		$this->row = 0;
		$this->id = 'id_' . $id_txt . '_';
		$this->use_js = $use_js;
		$this->search_mode = $search_mode;
		if($search_min_req_entries)
			$this->search_min_req_entries = $search_min_req_entries;
		$this->caption = $caption;
		$this->style_class = $style_class;
		parent::__construct();
		$this->text = '';
		$this->gen_Vmenu($table);
		// full of bugs $text = self::get_pretty_html_doc($this->text);
		// $text = self::get_pretty_html_doc($this->text);
		} // __construct()

	function  __destruct() {
		parent::__destruct();
		} // __destruct()
// static

// methods

	public function get_text() { return $this->text; } // get_text()

	protected function gen_tr_th(&$th) {
		if(!empty($th['uri'])) {
			$this->text .= '<tr class="' . $this->style_class . '">';
			$this->text .= '<th class="' . $this->style_class . '"' .
				' id="' . $this->id . 'th' . $this->row . '"' .
				'>';
			$this->text .= '<a href="' . $th['uri'] . '"' .
				' id="' . $this->id . 'a' . $this->row . '"' .
				((!empty($th['new']) && $th['new']) ? ' target="_blank"':'') .
				(!empty($th['confirm']) ? ' onclick="return confirm(\'' . $th['confirm'] . '\');"':(empty($th['new']) ? ' onclick="Ccms_cursor.setWait();"':'')) .
				(!empty($th['params']) ? ' ' . $th['params']:'') .
				(!empty($th['title']) ? ' title="' . $th['title'] . '"':'') .
				'>' .
				$th['text'] .
				'</a>';
			$this->text .= '</th>';
			$this->text .= '</tr>' . PHP_EOL;
			} // if
		else {
			$this->text .= '<tr class="' . $this->style_class . '">';
			$this->text .= '<th class="' . $this->style_class . '"' .
				(isset($th['title']) ? ' title="' . $th['title'] . '"':'') . ' id="' . $this->id . 'th">' .
				$th['text'] . '</th>';
			$this->text .= '</tr>' . PHP_EOL;
			} // else
		} // gen_tr_th()

	protected function gen_tr_td(&$td) {
		if(empty($td['text'])) return;
		$this->row++;
		if((!empty($td['uri'])) && (!empty($_SERVER['REQUEST_URI'])) &&
			(basename($_SERVER['REQUEST_URI']) == $td['uri'])) {
			$td_class = $this->style_class . ' ' . $this->style_class . '_selected';
			} // if
		else $td_class = $this->style_class;
		if(($this->use_js) && (empty($td['new']))) {
			$this->text .= '	<tr class="' . $this->style_class . (!empty($td['uri']) ? (($this->row & 1) ? '_odd':'_even') . ' href_linked':'') . '"' .
				' id="' . $this->id . 'tr' . $this->row . '"' .
				(!empty($td['uri']) ? ' onclick="' .
				(!empty($td['confirm']) ? 'if(confirm(\'' . $td['confirm'] . '\')) ':(empty($td['new']) ? 'Ccms_cursor.setWait();':'')) .
				' document.location.href = \'' . $td['uri'] . '\';"':'') .
				// ' window.location.href = \'' . $td['uri'] . '\';"':'') .
				(!empty($td['params']) ? ' ' . $td['params']:'') .
				(!empty($td['title']) ? ' title="' . $td['title'] . '"':'') .
				'>';
			$this->text .= '<td class="' . $td_class . '"' .
				' id="' . $this->id . 'td' . $this->row . '"' .
				'>' . $td['text'] . '</td>';
			$this->text .= '</tr>' . PHP_EOL;
			return;
			} // if
		$this->text .= '	<tr class="' . $this->style_class . (!empty($td['uri']) ? (($this->row & 1) ? '_odd':'_even'):'') . '"' .
			' id="' . $this->id . 'tr' . $this->row . '"' .
			'>';
		if(!empty($td['uri'])) {
			$this->text .= '<td class="' . $td_class . '"' .
				' id="' . $this->id . 'td' . $this->row . '"' .
				'>';
			$this->text .= '<a href="' . $td['uri'] . '"' .
				' id="' . $this->id . 'a' . $this->row . '"' .
				((!empty($td['new']) && $td['new']) ? ' target="_blank"':'') .
				(!empty($td['confirm']) ? ' onclick="return confirm(\'' . $td['confirm'] . '\');"':(empty($td['new']) ? ' onclick="Ccms_cursor.setWait();"':'')) .
				(!empty($td['params']) ? ' ' . $td['params']:'') .
				(!empty($td['title']) ? ' title="' . $td['title'] . '"':'') .
				'>' .
				$td['text'] .
				'</a>';
			$this->text .= '</td>';
			} // if
		else {	// just text (probably a submenu)
			$this->text .= '<td class="' . $this->style_class . '"' .
				' id="' . $this->id . 'td' . $this->row . '"' .
				'>';
			$this->text .= $td['text'];
			$this->text .= '</td>';
			} // else
		$this->text .= '</tr>' . PHP_EOL;
		} // gen_tr_td()

	protected function gen_tr_td_search(&$table) {
		if(!$this->search_mode) return;
		if(count($table['td']) < $this->search_min_req_entries) return;
		// add search input
		$this->text .= '	<tr class="' . $this->style_class . '">';
		$this->text .= '<td class="' . $this->style_class . '">';
		$this->text .= '<input type="text"' .
			' id="' . $this->id . 'inp"' .
			' oninput="Cfilter_PDBs.on_filter(this,\'' . $this->id . '\');"' .
			' onchange="Cfilter_PDBs.on_filter(this,\'' . $this->id . '\');"' .
			' placeholder="Filter Menu"' .
			' title="Enter keywords to filter menu.">';
		$this->text .= '</td>';
		$this->text .= '</tr>' . PHP_EOL;
		} // gen_tr_td_search()

	protected function gen_Vmenu(&$table) {
		$this->text .=  PHP_EOL . '<table class="' . $this->style_class . '" id="' . $this->id . 'tb">' . PHP_EOL;
		if(!empty($this->caption)) $this->text .= '<caption>' . $this->caption . '</caption>' . PHP_EOL;
		if(isset($table['th'])) $this->gen_tr_th ($table['th']);
		$this->gen_tr_td_search($table);	// add search input
		if(isset($table['td'])) {
			foreach($table['td'] as &$td) {
				$this->gen_tr_td($td);
				} // foreach
			} // if
		// $this->gen_tr_td_search($table);	// add search input
		$this->text .= '</table>' . PHP_EOL;
		} // gen_Vmenu()

} // Ccms_generate_Vmenu

