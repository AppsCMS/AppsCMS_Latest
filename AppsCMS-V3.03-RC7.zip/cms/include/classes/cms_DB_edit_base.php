<?php
/*
 * Applications Management System Library Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_edit_base.php 2825 2022-10-05 10:31:21Z robert0609 $
 */

/**
 * Description of Ccms_DB_edit_base
 *
 * Provides the common and base methods, etc. for Ccms_DB_edit.
 *
 * @author robert0609
 */

class Ccms_DB_edit_base extends Ccms_edit {

	const ABS_MAX_ROWS = 1000;	// maximum number of rows on screen
	const MAX_PAGES_TO_SELECT = 50;
	const PAGE_SIZE_MIN = 10;
	const PAGE_SIZES = '10,20,50,100,200,500,1000';
	const AJAX_SELECT_MAX_DEF = 10;	// default maximumselect rows
	const SQL_DEBUG_TYPE_DESIGNATOR = 'SQLdbgDSGtype';	// usually used in UNIONs and multiple SELECTs to identify the SQL match

	const FORM_DB_SEP = '&#124;';
	const NO_INDEX_STR = '__NO_IDX__';	// string used by JS to change indexes/ids to real values

	protected static $use_ajax_save = false;

	protected $cEditDB = false;
	protected $db_name_id = false;

	protected $class = false;
	protected $class_even = false;
	protected $class_odd = false;
	protected $class_text = false;	// for text column (<td>) only
	protected $class_number = false;	// for number column (<td>) only
	protected $class_head_row = false;	// usuallt puts up a sticky heading

	protected $new_entry_row = false;

	protected $rel_ops = array();

	protected $edit_DB_info = array(
		'table' => '',
		'table_op' => '',
		'page_size' => 0,	// size in rows of a page
		'page_idx' => 0,	// current page index (0 => page 1)
		'page_max' => 0,	// max pages
		'row_cnt' => 0,		// rows from DB select
		'row_cntr' => 0,
		'max_rows_per_page' => 0,
		'max_DB_select_rows' => 0,
		'form_name' => false,
		'app_name' => false,
		'read_only' => false,
		'free_form' => false,
		'required_form' => false,
		'sort_col' => false,
		'sort_dir' => false,
		'install_scripts' => false,
		'columns_heads' => false,
		'columns_num' => false,
		'db_keywords' => false,
		'db_keywords_ary' => false,
		'col_filters' => false,
		'sql' => false,
		'row_editor' => false,
		'tol_id' => false,	// top of list, usually the last edited row id
		);
	protected static $form_JS_done = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

// virtual methods (for inderitance)

	protected function get_DB_row_heading_form_pre(&$table_details) {	// virtual
		return '';
		} // get_DB_row_heading_form_pre()

	protected function get_DB_row_heading_form_post(&$table_details) {	// virtual
		return '';
		} // get_DB_row_heading_form_post()

	protected function get_DB_filter_prev_next_page_sticky_pre_form() {	// virtual
		return '';
		} // get_DB_filter_prev_next_page_sticky_pre_form()

	protected function get_DB_filter_prev_next_page_sticky_post_form() {	// virtual
		return '';
		} //get_DB_filter_prev_next_page_sticky_post_form()

	protected function allow_DB_row(&$table_details,&$row) {	// virtual
		// allows custom row filtering
		// return false if no allowed
		return true;	// allowed
		} // allow_DB_row()

	protected function filter_DB_columns(&$table_details,$columns = false) {	// virtual
		// allows custom column filtering
		if(!$columns) $columns = $table_details['edit']['columns'];
		// filter the column array and return result
		return $columns;	// allowed
		} // filter_DB_columns()

	protected function allow_DB_row_cell(&$table_details,&$col_name,&$col_info,&$row,$row_id){	// virtual
		// allows custom row cell filtering
		// return false if no allowed
		return true;	// allowed
		} // allow_DB_row_cell()

	protected function allow_DB_form_elem(&$table_details,&$col_name,&$col_info,&$row) { // virtual
		// allows custom form elem filtering
		// return false if no allowed
		return true;	// allowed
		} // allow_DB_form_elem()

	protected function add_DB_sql_virt_where($table,&$table_details,&$sql_parts) {	// virtual function
		// allows custom aditions to SQL where string
		// $sql_parts is an array of the sql query given by refence for alteration (if required)

		$virt_where = '';	// return empty if nothing to add to SQL where
		return $virt_where;
		} // add_DB_sql_virt_where()

	protected function format_DB_data_value($table,$col_name,$col_info,$data) {	// virtual function
		// virtual hook, typically used to format text and number (e.g. currency).
		return $data;
		} // format_DB_data_value()

	protected function get_DB_ext_form_elem_text($col_form_name,$col_info,$data) {	// virtual function
		return '';
		} // get_DB_ext_form_elem_text()

// dynamic methods
	protected function get_TR_class() {	// keeps track off the TR rows
		$this->edit_DB_info['row_cntr'] += 1;
		return (($this->edit_DB_info['row_cntr'] & 1) ? $this->class_odd:$this->class_even);
		} // get_TR_class()

	protected function get_DB_form_controls($max_rows_per_page = 0, $max_DB_select_rows = 0) {
		if(self::is_ajax()) return;
		$edit = &$this->edit_DB_info;
		// fixer uppers
		if($max_rows_per_page) {
			$edit['max_rows_per_page'] = $max_rows_per_page;
			if(($edit['max_rows_per_page'] < 0) ||
				($edit['max_rows_per_page'] > self::ABS_MAX_ROWS))
				$edit['max_rows_per_page'] = self::ABS_MAX_ROWS;
			} // if
		else $edit['max_rows_per_page'] = self::ABS_MAX_ROWS;

		if($max_DB_select_rows) $edit['max_DB_select_rows'] = $max_DB_select_rows;
		if($edit['max_DB_select_rows'] <= 0) $edit['max_DB_select_rows'] = self::AJAX_SELECT_MAX_DEF;

		$table = self::get_or_post('table');
		if(($table) && ($table != $edit['table'])) {
			// reset for new table
			foreach($edit as $k => &$v) {
				switch($k) {
				case 'install_scripts':
				case 'form_name':
					// leave it there
					break;
				case 'table_op':
					$edit[$k] = '';
					break;
				case 'page_size':	// size in rows of a page
				case 'page_idx':	// current page
				case 'page_max':	// max pages
				case 'row_cnt':		// rows from DB select
				case 'row_cntr':
				case 'max_rows_per_page':
				case 'max_DB_select_rows':
					$edit[$k] = 0;
					break;
				default:
					$edit[$k] = false;
					break;
					} // switch
				} // foreach
			$edit['table'] = $table;
			} // if

		self::chk_get_or_post('table',$edit['table']);
		self::chk_get_or_post('table_op',$edit['table_op']);
		if($edit['table_op'] == 'cancel') $edit['table'] = false;

		self::chk_get_or_post('free_form',$edit['free_form']);
		self::chk_get_or_post('required_form',$edit['required_form']);

		if(self::is_get_or_post('db_keywords')) {
			$edit['db_keywords'] = self::get_or_post('db_keywords');
			if(!empty($edit['db_keywords'])) {
				$edit['db_keywords_ary'] = explode(' ', strtolower($edit['db_keywords']));
				$edit['col_filters_on'] = false;
				} // else
			else $edit['db_keywords_ary'] = array();
			} // if
		if(empty($edit['db_keywords'])) {	// @TODO allow seach by global keywords and column filters
			self::chk_get_or_post('col_filters_on',$edit['col_filters_on']);
			if($edit['col_filters_on'])
				self::chk_get_or_post('col_filters', $edit['col_filters']);
			} // else

		self::chk_get_or_post('page_size',$edit['page_size']);
		self::chk_get_or_post('page_idx',$edit['page_idx']);
		if(($page_num = self::get_or_post('page_num')) &&	// came from the page_idx + 1 input or select
			((int)$page_num > 0) &&
			($edit['table_op'] != 'prev') &&
			($edit['table_op'] != 'next')) {
			$edit['page_idx'] = $page_num - 1;
			} // if
		if(($edit['page_size'] < 2) || ($edit['page_size'] > $edit['max_rows_per_page']))
			$edit['page_size'] = $edit['max_rows_per_page'];

		if($edit['table']) {	// in a table
			self::chk_get_or_post('sort_col', $edit['sort_col']);
			self::chk_get_or_post('sort_dir', $edit['sort_dir']);
			} // if
		else { // reset sort
			$edit['sort_col'] = false;
			$edit['sort_dir'] = false;
			} //  else

		} // get_DB_form_controls()

	protected function get_DB_form_JS($action_uri,$ajax_uri,$ajax_DB_column_uri) {
		if(self::$form_JS_done) return '';	// done already
		self::$form_JS_done = true;

		$form_name = $this->edit_DB_info['form_name'];
		$DB_table = $this->edit_DB_info['table'];
		if(empty($DB_table)) {
			$DB_table = self::get_or_post('table');
			if(empty($DB_table)) {
				self::log_msg('INFO: Table value not set for forms.');
				} // if
			} // if

		$text = '	<script type="text/javascript" src="' . Ccms_minify_plugin::minify_js(CMS_WS_DIR . 'cms_DB_edit.js') .'"></script>' . PHP_EOL;

		$text .= <<< EOTFAJS

	<script type="text/javascript">

		window.addEventListener("load",
			function () {
				if(!cmsDBops) {
					console.log("Cannot find cmsDBops class.");
					return;
					} // if
				// setup the call values
				var ext = {
					action_uri: '{$action_uri}',
					ajax_uri: '{$ajax_uri}',
					ajax_DB_column_uri: '{$ajax_DB_column_uri}',
					form_name: '{$form_name}',
					DB_table: '{$DB_table}',
					};
				cmsDBops.set_ext_values(ext);
				// alert('Alert test');
				},
			false
			);

	</script>

EOTFAJS;
		return $text;
		} // get_DB_form_JS()

	protected function get_DB_table_selector($action_uri,$current_table,$title = '',$params = '') {

		$table_cnt = 0;
		$text = '';
		$text .= '	<select id="id_' . $this->edit_DB_info['form_name'] . '_table" name="table"' .
				(!empty($params) ? ' ' . $params:'') .
				(!empty($title) ? ' title="' . $title . '"':'') .
				'>' . PHP_EOL;
		foreach($this->edit_DB_info['install_scripts'] as $t => &$col) {	// make table select options
			if(!isset($col['edit']['text'])) continue;	// not edited manually
			$table_cnt++;
			$text .= '		<option value="' . $t . '"' . (($t == $current_table) ? ' SELECTED':'') . '>' .
					$col['edit']['text'] . '</option>';
			} // foreach
		$text .= '	</select>' . PHP_EOL;
		if(!$table_cnt) return '';
		return $text;
		} // get_DB_table_selector()

	protected function get_DB_relation_joined(&$table_details,$col_name,$chk_joined = true) {
		$relation = self::getDottedKeys2Var($table_details, 'edit.columns.' . $col_name . '.relation');
		if(!$relation)	// can be prefixxed with 'columns.'
			$relation = self::getDottedKeys2Var($table_details, 'edit.' . $col_name . '.relation');
		if($relation) {
			if(($chk_joined) &&
				((isset($relation['joined'])) && (!$relation['joined'])) // special case, normally no join is required as the select drop downs do a seperate lookup
				) return false;
			return $relation;
			} // if
		return false;
		} // get_DB_relation_joined()

	public function &get_DB_column_headings(&$table_details) {
		if($this->edit_DB_info['columns_heads']) return $this->edit_DB_info['columns_heads'];
		$this->edit_DB_info['columns_heads'] = array();
		if((!isset($table_details['edit']['columns'])) ||
			(!is_array($table_details['edit']['columns'])) ||
			(count($table_details['edit']['columns']) < 1)) {
			self::addMsg('Table "' . $this->edit_DB_info['table'] . '" edit.columns control missing.');
			return false;
			}
		$columns = $this->filter_DB_columns($table_details);
		$this->edit_DB_info['columns_heads'] = array();
		foreach($columns as $c => &$v) {
			if($v['type'] == 'hidden') continue;
			$this->edit_DB_info['columns_heads'][$c] = $v;
			} // for
		$this->edit_DB_info['columns_num'] = count($this->edit_DB_info['columns_heads']);
		return $this->edit_DB_info['columns_heads'];
		} // get_DB_column_headings()

	protected function get_DB_col_sort_hrefs($action_uri,&$table_details,$head,$col_name, $title = '') {
		$edit = &$this->edit_DB_info;

		$uri_suffix = '';
//		$uri_suffix = '&col_filters_on=' . ($edit['col_filters_on'] ? 'on':'off') . '' .
//			'&free_form=' . ($edit['free_form'] ? 'on':'off') . '' .
//			'&required_form=' . ($edit['required_form'] ? 'on':'off') . '' .
//			'&db_keywords=' . urlencode($edit['db_keywords']) . '';

		if((self::is_debug()) && ((empty($title)))) $title = 'Debug: ' . $col_name;
		$me = (($edit['sort_col'] == $col_name) ? '*':'');
		$text = '<div class="page_database col_DB_head">';
		$text .= '<div' . (!empty($title) ? ' title="' . $title . '"':'') . '>' .
			$me . $head . $me .
			'</div>';
		$text .= '<div>' .
					'<a href="' . $action_uri . '&table=' . $edit['table'] . '&sort_col=' . $col_name . '&sort_dir=ASC'. $uri_suffix . '">' .
						((!empty($me) && ($edit['sort_dir'] == 'ASC')) ? '(':'') .
						'<img alt="up arrow" class="page_database col_DB_head" src="' . CMS_WS_ICONS_DIR . 'up.gif' . '">' .
						((!empty($me) && ($edit['sort_dir'] == 'ASC')) ? ')':'') .
					'</a>' .
				 '</div>';
		$text .= '<div>' .
					'<a href="' . $action_uri . '&table=' . $edit['table'] . '&sort_col=' . $col_name . '&sort_dir=DESC'. $uri_suffix . '">' .
						((!empty($me) && ($edit['sort_dir'] == 'DESC')) ? '(':'') .
						'<img alt="down arrow" class="page_database col_DB_head" src="' . CMS_WS_ICONS_DIR . 'down.gif' . '">' .
						((!empty($me) && ($edit['sort_dir'] == 'DESC')) ? ')':'') .
					'</a>' .
				 '</div>';
		$text .= '</div>';
		return $text;
		} // get_DB_col_sort_hrefs()

	protected function get_DB_row_heading($action_uri,&$table_details) {
		$columns = $this->get_DB_column_headings($table_details);
		if($columns === false) return false;

		$form_id = 'id_db_table_heading_form';
		$js_func = 'cmsDBops.send_DB_col_filters(this);';

		$edit = &$this->edit_DB_info;
		echo '<br>' . PHP_EOL;
		echo '<table id="id_table_' . $form_id . '" ' . $this->class . '>' . PHP_EOL;
		echo '	<tr' . $this->class_head_row . '>' . PHP_EOL;
		if($edit['col_filters_on']) {
			echo '	<form id="' . $form_id . '" action="' . $action_uri . '" method="post" enctype="multipart/form-data">';
			echo $this->get_DB_row_heading_form_pre($table_details);
			echo '			<input type="hidden" name="form_name" value="' . $edit['form_name'] . '">' . PHP_EOL;
			echo '			<input type="hidden" name="table" value="' . $edit['table'] . '">' . PHP_EOL;
			// echo '			<input type="hidden" name="db_keywords" value="' . $edit['db_keywords'] . '">' . PHP_EOL;
			} // if
		echo '		<th' . $this->class . '>' . '&nbsp;' . '</th>' . PHP_EOL;	// the bin

		if((self::is_debug()) && (empty($edit['columns_heads'][($table_details['edit']['row_id_name'])]))) {	// extra column for Row ID
			// put up row ID as it's not in the column list
			echo '		<th' . $this->class . '>' .
				$this->get_DB_col_sort_hrefs($action_uri, $table_details, 'ID', $table_details['edit']['row_id_name'],'Table row ID\n(Debug only)') .
				'</th>' . PHP_EOL;
			} // if

		foreach($edit['columns_heads'] as $col => &$h) {
			if(($edit['required_form']) &&
				((!isset($h['required'])) || (!$h['required']))) continue;
			$title = ((isset($table_details['edit']['columns'][$col]['title'])) ? $table_details['edit']['columns'][$col]['title']:'');
			// use the 'edit' setting instead	if($table_details['edit']['row_id_name'] == $col) continue;;	// don't list ID column
			if(!$edit['col_filters_on']) $col_filt = '';
			else {
				$col_filt = '<br><input name="col_filters[' . $col . ']" value="';
				if(isset($edit['col_filters'][$col])) $col_filt .= $edit['col_filters'][$col];
				$col_filt .= '"';
				$col_filt .= ' oninput="' . $js_func . '"';
				$col_filt .= ' title="Enter keywords for ' . $h['head'] . ' column."';
				$col_filt .= '>' . PHP_EOL;
				} // else

			echo '		<th' . $this->class . '>' .
				$this->get_DB_col_sort_hrefs($action_uri, $table_details, $h['head'], $col,$title) .
				$col_filt .
				'</th>' . PHP_EOL;
			} // foreach
		if($edit['col_filters_on']) {
			echo $this->get_DB_row_heading_form_post($table_details);
			echo '	</form>' . PHP_EOL;
			} // if
		echo '	</tr>' . PHP_EOL;
		return $this->prn_or_buffer_text();
		} // get_DB_row_heading()

	protected function get_DB_row_id_val(&$table_details,&$row,$row_id = false) {
		if(($row_id == false) || ((int)$row_id <= 0)) {
			if(isset($row[($table_details['edit']['row_id_name'])])) $row_id = $row[($table_details['edit']['row_id_name'])];
			else {
				$row_id = self::NO_INDEX_STR;
//				self::addMsg('Missing row_id_name for table "' . $this->edit_DB_info['table'] . '".');
//				return '(Error: missing row_id_name)';
				} // else
			} // if
		return $row_id;
		} // get_DB_row_id_val()

	protected function get_DB_form_elem(&$table_details,&$col_name,$row_id,&$col_info,&$row,&$js_func) {	// to allow easy overirde

		if(!$this->allow_DB_form_elem($table_details,$col_name,$col_info,$row)) return '';

		// $edit = &$table_details['edit'];
		$data = (isset($row[$col_name]) ? $row[$col_name]:'');
		$readonly = ($this->edit_DB_info['read_only'] ? ' READONLY':'');
		if(empty($col_info['name'])) $col_info['name'] = $col_name;	// add column name (column name used on form may different)
		if(empty($js_func)) $col_form_name = 'columns[' . $col_name . ']';
		else $col_form_name = 'columns.' . $col_name;
		$extras = (isset($col_info['params']) ? ' ' . $col_info['params']:'') .
			((isset($col_info['required']) && $col_info['required']) ? ' REQUIRED':'') . $readonly;
		if((isset($col_info['inp_func'])) && ($col_info['inp_func'])) {
			// overrides 'type' and 'relation', a 'class::method' or a 'global_function',
			// paramters are ($column_name,$col_info,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
			$func = $col_info['inp_func'];
			if((is_callable($func)) ||
				(function_exists($func))) {
				$self = $this;
				$text = $func($col_form_name,$col_info,$data,$js_func,$extras,$self);
				} // if
			else {
				self::addDebugMsg('Cannot call input function "' . $func . '()".');
				$text = '(error)';
				} // else
			} // if
		else if(isset($col_info['relation'])) {	// get the relation sip select
			$text = $this->get_DB_relation_select($js_func,$table_details,$col_name,$row_id,$data,$col_info['relation'],$extras);
			} // if
		else if(!$this->edit_DB_info['free_form']) {
			$data = $this->format_DB_data_value($this->edit_DB_info['table'],$col_name,$col_info,$data);	// get virtual changes
			switch($col_info['type']) {	// fmt some types
			case 'password':
				$text = (empty($data) ? '(empty)':'(Set)');	// never preload
				break;
			case 'checkbox':
				$text = ($data ? 'on':'off');
				break;
			case 'date':
				$text = preg_replace('/ 00:00:00$/','',$data);
				break;
			case 'hidden':
				$text = '';
				break;
			case 'enum':
				if(!empty($col_info['keys'])) {	// inherit select enum
					$keys = &$col_info['keys'];
					if(isset($keys[strtolower($data)])) {
						$text = $keys[strtolower($data)];
						break;
						} // if
					} // if
				$text = $data;	// odd import maybe ??
				break;
			default:
				$text = $data;
				break;
				} // switch
			} // else if
		else {
			$id = $col_form_name . '[' . $row_id . ']';	// a unique ID
			switch($col_info['type']) {
			case 'show':
				$text = '<div>' . $data . '</div>';	// non editable columns
				break;
			case 'enum':	// special type for MySQL enum datatypes
				$text = '<select onchange="' . $js_func . '" id="' . $id . '" name="' . $col_form_name . '"' . $extras . '>';
				$text .= '<option value="" selected disabled hidden>' . '- Select -' . '</option>';
				if(isset($col_info['enum'])) {
					$enum = &$col_info['enum'];
					for($i = 0; $i < count($enum); $i++) {
						$text .= '<option value="' . $i . '"' .
							(((!empty($data)) && (!strcasecmp($data,$enum[$i]))) ? ' SELECTED':'') .
							'>' .
							$enum[$i] .
							'</option>';
						} // for
					} // if
				if(isset($col_info['keys'])) {
					$keys = &$col_info['keys'];
					foreach($keys as $k => &$val) {
						$text .= '<option value="' . $k . '"' .
							(((!empty($data)) && (!strcasecmp($data,$k))) ? ' SELECTED':'') .
							'>' .
							$val .
							'</option>';
						} // for
					} // if
				$text .= '</select>';
				break;
			case 'radio':
				$enum = &$col_info['enum'];
				$text = '<div style="display: inline-flex;">';
				for($i = 0; $i < count($enum); $i++) {
					$text .= '<div style="margin: 0 3px;"><input type="radio" onchange="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $i . '"' . (($data == $i) ? ' CHECKED':'') . $extras . '>' . $enum[$i] . '</div>';
					} // for
				$text .= '</div>';
				break;
			case 'checkbox':
				$text = '<input type="checkbox" onchange="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" ' . (((int)$data > 0) ? ' CHECKED':'') . $extras . '>';
				break;
			case 'float':
				$text = '<input type="number" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '"' . $extras . '>';
				break;
			case 'password':
				// 	public static function set_JS_password_input_by_id($mh_id,$name,$title = '',$value = '',$chk_strength = false,$allow_autocomplete = false,$prn_flg = true,$extras = '') {
				$text = Ccms::set_JS_password_input_by_id($id,$col_form_name,'','',false,false,false,'oninput="' . $js_func . '" ' . $extras);
				break;
			case 'number':
				$text = '<input type="number" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '"' . $extras . '>';
				break;
			case 'date':
				if(empty($data)) $data = date('Y-m-d');	// today
				$text = '<input type="date" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . preg_replace('/ 00:00:00$/','',$data) . '"' . $extras . '>';
				break;
			case 'textarea':
				$text = '<textarea oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '"' . $extras . '>' . $data . '</textarea>';
				break;
			case 'uri':
				$text = '<input type="url" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '"' . $extras . '>';
				break;
			case 'email':
				$text = '<input type="email" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '"' . $extras . '>';
				break;
			case 'phone':
				$text = '<input type="tel" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '"' . $extras . '>';
				break;
			default:
				$text = $this->get_DB_ext_form_elem_text($col_form_name,$col_info,$data);	// virtual function
				if(!empty($text)) break;
				// else fail thru
			case 'text':	// the last default
				$text = '<input type="text" oninput="' . $js_func . '" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '"' . $extras . '>';
				break;
			case 'hidden':
				$text = '<input type="hidden" id="' . $id . '"  name="' . $col_form_name . '" value="' . $data . '">';
				break;
				} // switch
			} // else
		return $text;
		} // get_DB_form_elem()

	protected function get_DB_table_row_cells($action_uri,&$table_details,&$row,$row_id = false) {	// called by ajax
		$row_id = $this->get_DB_row_id_val($table_details, $row, $row_id);
		$row_input_id = 'id_db_table_row_id_cell[' . $row_id . ']';
		if(self::$use_ajax_save) {
			$js_func = 'if(cmsDBops.send_DB_form(this)) { Ccms_cursor.setWait(); return true; } else return false;';
			} // if
		else {
			$js_func = 'if(cmsDBops.save_DB_form(this)) { Ccms_cursor.setWait(); return true; } else return false;';
			} // else

		$text = '';
		$text .= '' . PHP_EOL;
		$text .= '			<td' . $this->class . '><label>';
		if(self::$use_ajax_save) {
			if((int)$row_id > 0) {
				$text .= '<button type="button" onclick="cmsDBops.delete_DB_row(\'' . $row_id . '\',\'' . $this->edit_DB_info['table'] . '\',this);" name="delete" value="delete[' . $row_id . ']" style="padding: 0;" title="Delete Row"><img alt="bin" style="height: 20px;" src="' . CMS_WS_ICONS_DIR . 'bin.gif"/></button>';
				} // if
			} // if
		else {	// has a save button
			if((int)$row_id > 0) {
				$text .= '<button type="button" onclick="cmsDBops.delete_DB_row(\'' . $row_id . '\',\'' . $this->edit_DB_info['table'] . '\',this);" name="delete" value="delete[' . $row_id . ']" style="padding: 0;" title="Delete Row"><img alt="bin" style="height: 20px;" src="' . CMS_WS_ICONS_DIR . 'bin.gif"/></button>';
				$text .= '<button type="submit" onsubmit="' . $js_func . '" name="submit" value="save" style="display: none; padding: 0;" title="Save Row">Save</button>';
				} // if
			else {
				$text .= '<button type="submit" onsubmit="' . $js_func . '" name="submit" value="save" style="padding: 0;" title="Save new Row" DISABLED>Save</button>';
				} // else
			} // else
		$text .= '</label></td>' . PHP_EOL;

		$columns = $this->filter_DB_columns($table_details);
		if((self::is_debug()) && (empty($columns[($table_details['edit']['row_id_name'])]))) {	// extra column for Row ID
			// put up row ID as it's not in the column list
			$text .= '			<td' . $this->class . '><label' . $this->class . ' id="' . $row_input_id . '"' .
				(isset($row[self::SQL_DEBUG_TYPE_DESIGNATOR]) ? ' title="' . $row[self::SQL_DEBUG_TYPE_DESIGNATOR] . '"':'') .
				'>' .
				(((int)$row_id == 0) ? '(new)':(int)$row_id) .
				'</label></td>' . PHP_EOL;
			} // if

		foreach($columns as $col_name => &$col_info) {
			if(!$this->allow_DB_row_cell($table_details,$col_name,$col_info,$row,$row_id)) continue;
			if(($this->edit_DB_info['required_form']) &&
				((!isset($col_info['required'])) || (!$col_info['required']))) continue;
			$elem = $this->get_DB_form_elem($table_details,$col_name,$row_id,$col_info,$row,$js_func);
			if($col_info['type'] == 'hidden') {
				// $text .= $elem  . PHP_EOL;
				} // if
			else {
				switch($col_info['type']) {
				case 'number':
				case 'float':
				case 'double':
					$td_class = $this->class_number;
					break;
				default:
					$td_class = $this->class_text;	// default
					break;
					} //switch
				if(!empty($col_info['show_func'])) {
					$func = $col_info['show_func'];
					if((is_callable($func)) ||
						(function_exists($func))) {
						$elem = $func($col_info['name'],$col_info,(is_array($elem) ? implode(' - ',$elem):$elem));
						} // if
					else {
						self::addDebugMsg('Cannot call input function "' . $func . '()".');
						$elem = '(error)';
						} // else
					} // if
				$text .= '			<td' . $td_class . '>' .
						'<label' . $this->class .
						'>' .
						(is_array($elem) ? implode(' - ',$elem):$elem) .
						'</label>' .
						'</td>' . PHP_EOL;
				} // else
			} // foreach
		return PHP_EOL . $text . PHP_EOL;
		} // get_DB_table_row_cells()

	protected function get_DB_table_row($action_uri,&$table_details,$row) {
		if(!$this->allow_DB_row($table_details, $row)) return '';

		$tab_row_id = (isset($row[($table_details['edit']['row_id_name'])]) ? $this->edit_DB_info['row_cntr']:self::NO_INDEX_STR);
		$row_id = $this->get_DB_row_id_val($table_details,$row);
		$tr_id = 'id_DB_tr_elem[' . $this->edit_DB_info['table'] . '][' . $row_id . ']';
		$tr_func = ' ondblclick="cmsDBops.tr_dbl_click(\'' . $this->edit_DB_info['table'] . '\',\'' . $row_id . '\',this);"';
		$text = '';
		// $text .= '	<tr' . $tr_func . ' ' id="id_db_table_row[' . $tab_row_id . ']"' . $this->get_TR_class() . '>' . PHP_EOL;
		$text .= '	<tr id="' . $tr_id . '"' . $tr_func . ' ' . $this->get_TR_class() . '>' . PHP_EOL;
		$text .= '		' . $this->get_DB_table_row_cells($action_uri, $table_details, $row, $row_id) . PHP_EOL;
		$text .= '	</tr>' . PHP_EOL;
		return $text;
		} // get_DB_table_row()


	protected function get_DB_form_table_row_cells($action_uri,&$table_details,&$row,$row_id = false) {	// called by ajax
		$row_id = $this->get_DB_row_id_val($table_details, $row, $row_id);
		// $form_id = 'id_db_table_row_form[' . $row_id . ']';
		$form_id = 'db_table_row_form';
		$row_input_id = 'id_db_table_row_id_cell[' . $row_id . ']';
		// $js_func = 'cmsDBops.send_DB_form(\'' . $form_id . '\',\'' . $row_input_id . '\',this);';
		if(self::$use_ajax_save) {
			$js_func = 'cmsDBops.send_DB_form(this);';
			} // if
		else {
			$js_func = 'cmsDBops.save_DB_form(this);';
			} // else
		// $edit = &$table_details['edit'];

		$form = '';
		$form .= '' . PHP_EOL;
		$form .= '		<form id="' . $form_id . '" name="db_table_form_row[' . $row_id . ']" action="' . $action_uri . '" method="POST">' . PHP_EOL;
		$form .= '			<input type="hidden" name="form_name" value="' . $this->edit_DB_info['form_name'] . '">' . PHP_EOL;
		$form .= '			<input type="hidden" name="table" value="' . $this->edit_DB_info['table'] . '">' . PHP_EOL;
		if(!isset($edit['columns'][($table_details['edit']['row_id_name'])])) {	// put in a hidden row id
			$form .= '			<input type="hidden" name="' . $table_details['edit']['row_id_name'] . '" value="' . $row_id . '">' . PHP_EOL;
			} // if
		if(self::is_debug()) {
			$form .= '			<input type="hidden" name="row_id" value="' . $row_id . '"' . '>' . PHP_EOL;
			} // if
		else {
			$form .= '			<input type="hidden" name="row_id" value="' . $row_id . '"' . ' id="' . $row_input_id . '"' . '>' . PHP_EOL;
			} // else
		$form .= '' . PHP_EOL;
		$form .= '			<td' . $this->class . '><label>';
		if(self::$use_ajax_save) {
			if((int)$row_id > 0) {
				$form .= '<button type="button" onclick="cmsDBops.delete_DB_row(\'' . $row_id . '\',\'' . $this->edit_DB_info['table'] . '\',this);" name="delete" value="delete[' . $row_id . ']" style="padding: 0;" title="Delete Row"><img alt="bin" style="height: 20px;" src="' . CMS_WS_ICONS_DIR . 'bin.gif"/></button>';
				} // if
			} // if
		else {	// has a save button
			if((int)$row_id > 0) {
				$form .= '<button type="button" onclick="cmsDBops.delete_DB_row(\'' . $row_id . '\',\'' . $this->edit_DB_info['table'] . '\',this);" name="delete" value="delete[' . $row_id . ']" style="padding: 0;" title="Delete Row"><img alt="bin" style="height: 20px;" src="' . CMS_WS_ICONS_DIR . 'bin.gif"/></button>';
				$form .= '<button type="submit" onsubmit="return ' . $js_func . '" name="submit" value="save" style="display: none; padding: 0;" title="Save Row">Save</button>';
				} // if
			else {
				$form .= '<button type="submit" onsubmit="return ' . $js_func . '" name="submit" value="save" style="padding: 0;" title="Save new Row" DISABLED>Save</button>';
				} // else
			} // else
		$form .= '</label></td>' . PHP_EOL;

		$columns = $this->filter_DB_columns($table_details);
		if((self::is_debug()) && (empty($columns[($table_details['edit']['row_id_name'])]))) {	// extra column for Row ID
			// put up row ID as it's not in the column list
			$form .= '			<td' . $this->class . '><label' . $this->class . ' id="' . $row_input_id . '"' .
				(isset($row[self::SQL_DEBUG_TYPE_DESIGNATOR]) ? ' title="' . $row[self::SQL_DEBUG_TYPE_DESIGNATOR] . '"':'') .
				'>' .
				(((int)$row_id == 0) ? '(new)':(int)$row_id) .
				'</label></td>' . PHP_EOL;
			} // if

		foreach($columns as $col_name => &$col_info) {
			if(!$this->allow_DB_row_cell($table_details,$col_name,$col_info,$row,$row_id)) continue;
			if(($this->edit_DB_info['required_form']) &&
				((!isset($col_info['required'])) || (!$col_info['required']))) continue;
			$elem = $this->get_DB_form_elem($table_details,$col_name,$row_id,$col_info,$row,$js_func);
			if($col_info['type'] == 'hidden')
				$form .= $elem  . PHP_EOL;
			else {
				$form .= '			<td' . $this->class . '>' .
						'<label' . $this->class .
						'>' .
						(is_array($elem) ? implode(' - ',$elem):$elem) .
						'</label>' .
						'</td>' . PHP_EOL;
				} // else
			} // foreach
		$form .= '		</form>' . PHP_EOL;
		return PHP_EOL . $form . PHP_EOL;
		} // get_DB_form_table_row_cells()

	protected function get_DB_form_table_row($action_uri,&$table_details,$row) {
		if(!$this->allow_DB_row($table_details, $row)) return '';

		$tab_row_id = (isset($row[($table_details['edit']['row_id_name'])]) ? $this->edit_DB_info['row_cntr']:self::NO_INDEX_STR);
		$row_id = $this->get_DB_row_id_val($table_details,$row);
		$tr_id = 'id_DB_tr_elem[' . $this->edit_DB_info['table'] . '][' . $row_id . ']';
		$tr_func = ' ondblclick="cmsDBops.tr_dbl_click(\'' . $this->edit_DB_info['table'] . '\',\'' . $row_id . '\',this);"';
		$text = '';
		// $text .= '	<tr' . $tr_func . ' ' id="id_db_table_row[' . $tab_row_id . ']"' . $this->get_TR_class() . '>' . PHP_EOL;
		$text .= '	<tr id="' . $tr_id . '"' . $tr_func . ' ' . $this->get_TR_class() . '>' . PHP_EOL;
		$text .= '		' . $this->get_DB_form_table_row_cells($action_uri, $table_details, $row, $row_id) . PHP_EOL;
		$text .= '	</tr>' . PHP_EOL;
		return $text;
		} // get_DB_form_table_row()

	protected function get_DB_page_selector() {
		$edit = &$this->edit_DB_info;
		if(($edit['page_max'] <= 1) &&	// only one page
			($edit['row_cnt'] < self::PAGE_SIZE_MIN))
			return '';
		$text = PHP_EOL;
		$text .= '			<label><button type="submit" name="table_op" value="prev"' . (((int)$edit['page_idx'] > 0) ? '':' DISABLED') . ' title="Previous page">Previous</button></label>' . PHP_EOL;
		if($edit['page_max'] > self::MAX_PAGES_TO_SELECT) {
			$text .= '<label title="Enter page number (1 to ' . ($edit['page_max'] - 0) . ') to go to.">' . PHP_EOL;
			$text .= '<input type="number" style="width: 40px" name="page_num" value="' . ($edit['page_idx'] + 1) . '" min="1" max="' . ($edit['page_max'] - 0) . '">' . PHP_EOL;
			$text .= '&nbsp;' . $edit['page_max'] . ' pages.' . '</label>' . PHP_EOL;
			} // if
		else {
			$text .= '			<label><select name="page_idx" onchange="this.form.submit(); return true;" title="Select page">' . PHP_EOL;
			for($p = 0; $p < $edit['page_max']; $p++) {
				$text .= '<option value="' . $p . '"' . (($p == $edit['page_idx']) ? ' SELECTED':'') . '>' . ($p + 1) . '</option>';
				} // for
			$text .= '			</select></label>' . PHP_EOL;
			} // else
		$text .= PHP_EOL;
		$text .= '			<label><button type="submit" name="table_op" value="next"' . ((((int)$edit['page_idx'] + 1) < (int)$edit['page_max']) ? '':' DISABLED') . ' title="Next page">Next</button></label>' . PHP_EOL;
		$text .= '			&nbsp;' . PHP_EOL;
		return $text;
		} // get_DB_page_selector()

	protected function get_DB_page_size_selector() {
		$edit = &$this->edit_DB_info;
		if(($edit['page_max'] <= 1) &&	// only one page
			($edit['row_cnt'] < self::PAGE_SIZE_MIN))
			return '';
		if(!empty($edit['page'])) $edit['page_size'] = self::ABS_MAX_ROWS;

		$sizes = explode(',',self::PAGE_SIZES);
		$out_flg = false;
		$text = PHP_EOL;
		$text .= '			<label><select name="page_size" onchange="this.form.submit(); return true;" title="Select page size">' . PHP_EOL;
		for($s = 0; $s < count($sizes); $s++) {
			if($sizes[$s] > $edit['max_rows_per_page']) continue;
			if($sizes[$s] >= ($edit['row_cnt'] + $edit['page_size'])) continue;
			$text .= '<option value="' . $sizes[$s] . '"' . (($sizes[$s] == $edit['page_size']) ? ' SELECTED':'') . '>' . $sizes[$s] . '</option>';
			$out_flg = true;	// have something
			} // for
		$text .= PHP_EOL;
		$text .= '			</select></label>' . PHP_EOL;
		$text .= '			&nbsp;' . PHP_EOL;
		if(!$out_flg) return '';
		return $text;
		} // get_DB_page_size_selector()

	protected function get_DB_filter_prev_next_page_form_elems($action_uri) {
		$text = '		<form action="' . $action_uri . '" method="POST" onsubmit="Ccms_cursor.setWait();">';
		$text .= $this->get_DB_filter_prev_next_page_sticky_pre_form();
		$text .= '			<input type="hidden" name="table" value="' . $this->edit_DB_info['table'] . '">';
		// $text .= '			<label><button type="submit" name="table_op" value="new">New</button></label>';
		$text .= '			<label>' . Ccms_html::get_keyed_select("free_form", $this->edit_DB_info['free_form'], array('View','Edit'), 'onChange="this.form.submit()"',false,"Select form edit/view mode.");
		$text .= '			' . self::FORM_DB_SEP;
		$text .= '			<label>' . Ccms_html::get_keyed_select("col_filters_on", $this->edit_DB_info['col_filters_on'], array('No Col Filters','Use Col Filters'), 'onChange="this.form.submit()"' . (!empty($this->edit_DB_info['db_keywords']) ? ' DISABLED':''),false,"Select to show column search keywords or not.");
		$text .= '			' . self::FORM_DB_SEP;
		$text .= '			<label>' . Ccms_html::get_keyed_select("required_form", $this->edit_DB_info['required_form'], array('Show All','Required Only'), 'onChange="this.form.submit()"',false,"Select to show only required entries or all entries.");
		$text .= '			' . self::FORM_DB_SEP;
		$text .= '			<label><input type="text" name="db_keywords" onInput="cms_DB_submit_form(this);" value="' . (!empty($this->edit_DB_info['db_keywords']) ? $this->edit_DB_info['db_keywords']:'') . '" title="Enter keywords that match any column data\nMultipe keywords match in a column." autofocus></input></label>';
		$text .= '			<label><input type="checkbox" name="include_free" onChange="this.form.submit()" title="Check to include unallocated entries."' . (self::get_or_post_checkbox('include_free') ? ' CHECKED':'') . '></label>';
		$text .= '			<label><button type="submit" name="table_op" value="db_filter">Filter</button></label>';
		$text .= '			' . self::FORM_DB_SEP;
		// $text .= '			&nbsp;';
		$text .= '			' . $this->get_DB_page_size_selector();
		$text .= '			' . $this->get_DB_page_selector();
		//not used $text .= '			<label><button type="submit" name="table_op" value="save">Save</button></label>';

		if($this->edit_DB_info['free_form'] <= 0)
			$text .= '			<label><button type="button" name="table_op" value="new"' .
				' onclick="cmsDBops.tr_dbl_click(\'' . $this->edit_DB_info['table'] . '\',\'' . 0 . '\',this);"' .
				'>New</button></label>';

		$text .= '			<label><button type="submit" name="table_op" value="cancel" formnovalidate>Cancel</button></label>';
		$text .= $this->get_DB_filter_prev_next_page_sticky_post_form();
		$text .= '		</form>';
		$text .= <<< EOTSUB
		<script type="text/javascript">
			var last_cms_DB_submit_call = null;
			var cms_DB_submit_deb = 1200;
			function cms_DB_submit_form(obj) {
				if(last_cms_DB_submit_call != null) {	// clear it
					window.clearTimeout(last_cms_DB_submit_call);
					last_cms_DB_submit_call = null;
					} // if
				// restart if
				last_cms_DB_submit_call = window.setTimeout(function(obj) {
					if(obj.form) {
						obj.form.submit();
						} // if
					},cms_DB_submit_deb, obj);
				} // cms_DB_submit_form()
		</script>

EOTSUB;
		return $text;
		} // get_DB_filter_prev_next_page_form_elems()

	protected function get_DB_filter_prev_next_page_form_sticky($action_uri,$top = false) {
		if($top) $text = '	<div class="cms_sticky_top">';
		else $text = '	<div class="cms_sticky_left">';
		// $text .= '<label title="Rows found.">Rows: ' . $this->edit_DB_info['row_cnt'] . '.</label>';
		$text .= $this->get_DB_filter_prev_next_page_form_elems($action_uri);
		$text .= '<label title="Rows found.">Rows: ' . $this->edit_DB_info['row_cnt'] . '.</label>';
		$text .= '<label><button type="submit" name="export" value="' . $this->edit_DB_info['table'] . '" title="Export ' . $this->edit_DB_info['table'] . ' table as CSV.">Export</button></label>';
		$text .= '<label>
				<input type="file"
					accept=".csv"
					id="input_csv_id"
					onchange="document.getElementById(\'id_table_import\').disabled = false;"
					title="Select CSV file to import ' . $this->edit_DB_info['table'] . ' table."
					>
				<button type="submit"
					name="import"
					value="' . $this->edit_DB_info['table'] . '"
					id="id_table_import"
					title="Click to import ' . $this->edit_DB_info['table'] . ' table from CSV file."
					onclick="return confirm(\'Are you sure ?\nThis will overwrite.\',true);"
					DISABLED>
					Import
				</button>
				</label>';
		$text .= '	</div>'. PHP_EOL;
		return $text;
		} // get_DB_filter_prev_next_page_form_sticky()

	public function get_DB_filter_prev_next_page_form($action_uri) {
		$text = '	<div>';
		$text .= $this->get_DB_filter_prev_next_page_form_elems($action_uri);
		$text .= '	</div>'. PHP_EOL;
		return $text;
		} // get_DB_filter_prev_next_page_form()

	protected function get_DB_row_footing($action_uri,&$table_details) {
		echo '</table>';
		echo '<br>' . PHP_EOL;
		return $this->prn_or_buffer_text();
		} // get_DB_row_footing()

	public function get_DB_select_table(&$action_uri) {
		$this->edit_DB_info['columns_heads'] = false; // new table

		$text_sel = $this->get_DB_table_selector($action_uri,$this->edit_DB_info['table']);

		echo '		<h3 class="page_config">' . 'Select Table to Edit' . '</h3>';
		if(self::is_debug()) echo ' (' . $this->cEditDB->get_name() . ')';
		if(empty($text_sel)) {
			self::addDebugMsg('(No table editor settings found in "install_scripts".)','warn');
			return $this->prn_or_buffer_text();
			} // if
		echo '<br>';
		echo '		<form action="' . $action_uri . '" name="table" method="post" onsubmit="Ccms_cursor.setWait();">';
		echo '		' . $text_sel;
		echo '			<label><button type="submit" name="edit" value="table">Edit Table</button></label>';
		echo '		</form>';
		return $this->prn_or_buffer_text();
		} // get_DB_select_table()

	protected static function get_csv_file($table) {
		$csv_file = VAR_FS_TEMP_DIR . $table . '.csv';
		$name = $table . '_ImportFile';
		if((isset($_FILES[$name]['name'])) &&
			(!empty($_FILES[$name]['name']))) { // check image location
			$tmp_name = $_FILES[$name]['tmp_name'];
			if(move_uploaded_file($tmp_name, $csv_file)) {
				self::chmod_chown($csv_file);
				return $csv_file;
				} // if
			} // if
		return false;
		} // get_csv_file()

} // Ccms_DB_edit_base
