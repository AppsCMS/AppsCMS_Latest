<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_base_utils.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of cms_base_virts
 * contains utility methods often used outside of scope (i.e. no new declaration)
 * the bottom class
 *
 * @author robert0609
 */

class Ccms_base_utils {

	private static $sm_cms_sess_type = false;
	private static $sm_cms_sess_ptr = null;	// special case, independent session values
	private static $sm_cms_sess_saved = false;	// special case
	private const CMS_SESS = '.cms';	// following hidden dot name

	function __construct() {
		} // __construct()

	function __destruct() {
		self::save_cms_sess();
		} // __destruct()

// virtual methods

// static methods
	protected static function &get_cms_sess_type() {
		if(self::$sm_cms_sess_type) return self::$sm_cms_sess_type;
		if(defined('CMS_S_LOCAL_SESSIONS_BOOL')) {	// early version settings
			self::$sm_cms_sess_type = (CMS_S_LOCAL_SESSIONS_BOOL ? 'PHP_FILE':'APACHE_FILE');
			} // if
		else if(defined('CMS_S_SESSION_TYPE')) {
			self::$sm_cms_sess_type = CMS_S_SESSION_TYPE;
			} // else if
		return self::$sm_cms_sess_type;
		} // get_cms_sess_type()
		
	protected static function is_sys_sess_ok() {
		if(!isset($_SESSION)) return false;
		if(!is_array($_SESSION)) return false;
		return true;
		} // is_sys_sess_ok()

	protected static function is_cms_sess_ok() {
		if(is_null(self::$sm_cms_sess_ptr)) return false;
		if(!is_array(self::$sm_cms_sess_ptr)) return false;
		return true;
		} // is_cms_sess_ok()

	protected static function init_cms_sess_ptr() {	// special case
		$type = self::get_cms_sess_type();
		switch($type) {	// sort as most complex first, make sure we get a session
		default:
		case 'CMS_MYSQL':	// uses a MySQL database table.
		case 'CMS_FILE':	// cms filesystem (similar to PHP_FILE)
			// local control, secure session data
			if(!empty($_SESSION[self::CMS_SESS])) {
				self::$sm_cms_sess_ptr = $_SESSION[self::CMS_SESS];
				unset($_SESSION[self::CMS_SESS]);
				} // if
			else self::$sm_cms_sess_ptr = array();	// first time
			break;
		case 'PHP_FILE':	// php code
		case 'APACHE_FILE':	// native apache
			// system control
			if(empty($_SESSION[self::CMS_SESS])) $_SESSION[self::CMS_SESS] = array();	// first time
			self::$sm_cms_sess_ptr = &$_SESSION[self::CMS_SESS];
			self::$sm_cms_sess_saved = true;	// saved by default into global session
			break;
			} // switch
		} // init_cms_sess_ptr()

	protected static function is_cms_sess_saved() {
		return self::$sm_cms_sess_saved;
		} // is_cms_sess_saved()

	protected static function get_cms_sess_data() {
		return array(self::CMS_SESS => self::$sm_cms_sess_ptr);
		} // get_cms_sess_data()

	protected static function save_cms_sess() {	// special case
		if(self::$sm_cms_sess_saved) return false;	// do once
		if(!self::is_sys_sess_ok()) return false;
		if(!self::is_cms_sess_ok()) return false;
		$_SESSION[self::CMS_SESS] = &self::$sm_cms_sess_ptr;		// save cms session (using a pointer)
		self::$sm_cms_sess_saved = true;	// using a pointer
		return true;
		} // save_cms_sess()

	protected static function &get_cms_sess_ptr() {	// special case
		return self::$sm_cms_sess_ptr;
		} // get_cms_sess_ptr()

	protected static function set_cms_sess_var($value, ...$keys) {	// special case
		if(!is_array(self::$sm_cms_sess_ptr)) return null;
		return self::setVar2DottedKeys(self::$sm_cms_sess_ptr,$keys,$value);
		} // set_cms_sess_var()

	public static function get_cms_sess_var(...$keys) {	// special case
		if(empty(self::$sm_cms_sess_ptr)) return null;
		return self::getDottedKeys2Var(self::$sm_cms_sess_ptr, $keys);
		} // get_cms_sess_var()

	protected static function unset_cms_sess_var(...$keys) {	// special case
		if(empty(self::$sm_cms_sess_ptr)) return false;
		return self::unsetDottedKeys(self::$sm_cms_sess_ptr,$keys);
		} // unset_cms_sess_var()

	public static function issetDottedKeys2Var($data, $dotted_keys, $dot = '.') {
		$sections = explode($dot, $dotted_keys);
		for ($i = 0; $i < count($sections);$i++) {
			$sect = &$sections[$i];
			if ($sect == '*') {	// check descenders
				$k = key($data);	// skip over this index
				$ds = array_splice($sections,($i + 1));	// extract remaining keys
				$dk = implode($dot,$ds);	// make keys array
				$da = $data[$k];
				$ret = self::issetDottedKeys2Var($da, $dk, $dot);
				if($ret) return true;
				} // if
			if (!is_array($data) || !array_key_exists($sect, $data)) {
				// not there
				return false;
				} // if
			$data = $data[$sect];
			} // for
		return true;	// is there
		} // issetDottedKeys2Var()

	public static function getDottedKeys2Var($data, $dotted_keys, $dot = '.', $err_ret = null) {
		if(empty($data)) return $err_ret;
		$sections = (!is_array($dotted_keys) ? explode($dot, $dotted_keys):$dotted_keys);
		for ($i = 0; $i < count($sections);$i++) {
			$sect = &$sections[$i];
			if ($sect == '*') {	// check descenders
				$k = key($data);	// skip over this index
				$ds = array_splice($sections,($i + 1));	// extract remaining keys
				$dk = implode($dot,$ds);	// make keys array
				$da = $data[$k];
				$data = self::getDottedKeys2Var($da, $dk, $dot);
				if(!empty($data)) return $data;
				} // if
			if (!is_array($data) || !array_key_exists($sect, $data)) {
				// error occurred
				return $err_ret;
				} // if
			$data = $data[$sect];
			} // for
		return $data;	// done
		} // getDottedKeys2Var()

	public static function setVar2DottedKeys(&$data, $dotted_keys,$value, $dot = '.') {
		if(!is_array($data)) $data = array();
		$sections = (!is_array($dotted_keys) ? explode($dot, $dotted_keys):$dotted_keys);
		foreach ($sections as $sect) {
			//	if(empty($sect)) return false; // .. ??
			if(!isset($data[$sect])) $data[$sect] = array();
			if(!array_key_exists($sect, $data)) $data[$sect] = null;
			$data = &$data[$sect];
			} // foreach
		$data = $value;
		return true;	// done
		} // setVar2DottedKeys()

	public static function unsetDottedKeys(&$data, $dotted_keys, $dot = '.') {
		if(!is_array($data)) return false;
		if(empty($dotted_keys)) return false;
		$sections = (!is_array($dotted_keys) ? explode($dot, $dotted_keys):$dotted_keys);
		for($i = 0; $n = count($sections), $i < $n; ) {
			if((empty($data)) || (!is_array($data))) return false;
			if(empty($sections[$i])) return false;	// no route
			$sect = $sections[$i];
			if(!isset($data[$sect])) return false;	// no route
			if(++$i >= $n) {	// end of dot route
				if(!empty($data[$sect])) {	// found it
					unset($data[$sect]);
					return true;	// done
					} // if
				break;
				} // if
			$data = &$data[$sect];
			} // for
		return false;	// not found
		} // unsetDottedKeys()

// dynamic methods

} // Ccms_base_utils
