<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_sm.php 2909 2022-10-24 07:34:08Z robert0609 $
 */

/**
 * Description of _sm
 * The top class for cms_sm state machine
 *
 * @author robert0609
 */

/* @TODO
 * State Machine Truth Table
 * ======================================================================================================================================================
 * |                           |                                        Detected Enviroment Flags                                                       |
 * | Settings (bools)          | is_tablet() | is_tiny() | use_block_html() | is_moz4() | is_firefox() | is_chrome() | is_safari() | is_ms_edge() | is_html5() |
 * |===========================|=============|===========|=============|============|==========|=============|=============|===========|================|
 * | CMS_S_DEBUG_BOOL            |             |           |             |            |          |             |             |           |                |
 * | CMS_S_PAGE_STYLE_BLOCK_BOOL |             |           |             |            |          |             |             |           |                |
 * | CMS_S_HEADER_BOOL           |             |           |             |            |          |             |             |           |                |
 * | CMS_S_FOOTER_BOOL           |             |           |             |            |          |             |             |           |                |
 * | CMS_S_NAV_BAR_BOOL          |             |           |             |            |          |             |             |           |                |
 * | CMS_S_LEFT_COLUMN_BOOL      |             |           |             |            |          |             |             |           |                |
 * | CMS_S_RIGHT_COLUMN_BOOL     |             |           |             |            |          |             |             |           |                |
 * | self::$cms_bodies_cnt         |             |           |             |            |          |             |             |           |                |
 * | self::$cms_tools_cnt          |             |           |             |            |          |             |             |           |                |
 * | self::$cms_nav_bar_grid_cnt         |             |           |             |            |          |             |             |           |                |
 * | CMS_C_CUSTOM_HEADER       |             |           |             |            |          |             |             |           |                |
 * | CMS_C_CUSTOM_FOOTER       |             |           |             |            |          |             |             |           |                |
 * ======================================================================================================================================================
 * @TODO complete SM layout
 *
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_general.php');	// speed up, save class lookup

class Ccms_sm extends Ccms_general {

	public static $cms_admin_menu_output = false;
	protected static $cms_admin_config_items = false;
	public static $cms_tools_menu_output = false;
	protected static $cms_tools_menu_items = false;

	protected static $cms_bodies_menu_items = false;

	private static $cms_tla = false;
	protected static $cms_ws_links_options = false;

	protected static $cms_header_received = false;

	function __construct() {

		self::$cms_docroot = DOCROOT_FS_BASE_DIR;
		$this->do_globals();

		if(!self::is_cli()) {

			self::$cms_header_received = headers_list();

			// some versions of PHP and Apache don't use the same version info path
			$ver = false;
			if(function_exists('apache_get_version')) $ver = apache_get_version();
			if((empty($ver)) && (!empty($_SERVER['SERVER_SOFTWARE']))) $ver = $_SERVER['SERVER_SOFTWARE'];
			if(!empty($ver))
				self::$cms_httpd_version = preg_replace('/^apache\/([0-9\.]+) .*$/i','\1',$ver);
			else self::$cms_httpd_version = '2.4.0';

			if(CMS_S_PHP_GBL_VAL_USE_BOOL) {
				self::set_chk_php_value('max_execution_time',CMS_S_PHP_GBL_VAL_EXEC_TIME);	// PHP_INI_ALL
				self::set_chk_php_value('memory_limit',CMS_S_PHP_GBL_VAL_MEMORY);	// PHP_INI_ALL
				self::set_chk_php_value('post_max_size',CMS_S_PHP_GBL_VAL_POST_SIZE,true);	// PHP_INI_PERDIR (per dir)
				self::set_chk_php_value('max_file_uploads',CMS_S_PHP_GBL_VAL_UPLOAD_FILES, true);	// PHP_INI_SYSTEM (in php.ini only)
				self::set_chk_php_value('upload_max_filesize',CMS_S_PHP_GBL_VAL_UPLOAD_SIZE,true);	// PHP_INI_PERDIR (per dir)
				} // if
			} // if

		// debug definitions
		if (self::is_cli()) {
			// self::set_chk_php_value('output_buffering', '4096',true);	// PHP_INI_PERDIR (per dir)
			self::set_chk_php_value('display_errors', 'On');
			self::set_chk_php_value('display_startup_errors', 'On');
			self::set_chk_php_value('html_errors', 'Off');
			} // if
		else if ((self::is_api()) && (self::is_debug ())) {
			// self::set_chk_php_value('output_buffering', '4096',true);	// PHP_INI_PERDIR (per dir)
			self::set_chk_php_value('display_errors', 'On');
			self::set_chk_php_value('display_startup_errors', 'On');
			self::set_chk_php_value('html_errors', 'Off');
			} // else if
		else if (self::is_debug()) {
			// self::set_chk_php_value('output_buffering', '4096',true);	// PHP_INI_PERDIR (per dir)
			self::set_chk_php_value('display_errors', 'On');
			self::set_chk_php_value('display_startup_errors', 'On');
			self::set_chk_php_value('html_errors', 'On');
			} // else if
		else {
			// self::set_chk_php_value('output_buffering', '4096',true);	// PHP_INI_PERDIR (per dir)
			self::set_chk_php_value('display_errors', 'Off');
			self::set_chk_php_value('display_startup_errors', 'Off');
			self::set_chk_php_value('html_errors', 'Off');
			} // else
		parent::__construct();

		$this->is_ssl_inuse();
		if(self::is_ajax()) return;
		if(self::is_api()) return;

		if(!$this->make_head_values()) {
			self::addMsg('Failed to make head values.');
			} // if

		self::use_tooltips($this->show_cms_title_tooltips());

		// do time savers
		self::is_drop_down_menus_in_header();
		self::show_left_column();
		self::show_right_column();

		self::initMsgs();
		Ccms_auth::log_user_access();
		} // __construct()

	function __destruct() {
		Ccms_auth::log_user2apache();
		parent::__destruct();
		} // __destruct()

// dynamic functions
	private function do_globals() {

		// first get actions
		if(self::get_cms_action()) {
			self::set_cms_sess_var(self::get_cms_action(),'cms_action');
			} // if
		else {
			if (!self::get_app_action()) {
				self::set_cms_sess_var(self::get_app_action(),'action');
				} // if
			else if (self::get_cms_sess_var('action')) {
				self::get_app_action(self::get_cms_sess_var('action'));
				self::unset_cms_sess_var('action');
				} // else if
			else if (self::get_cms_sess_var('cms_action')) {
				self::get_cms_action(self::get_cms_sess_var('cms_action'));
				self::unset_cms_sess_var('cms_action');
				} // else if
			else {

				} // else
			} // else

		if((self::is_api()) && (!CMS_C_API_ENABLE)) {	// not allowed
			self::log_msg('API call from ' . Ccms_auth::get_client_ip_address() . ', API disabled.', 'error');
			exit(10000);
			} // if

		if(!self::is_ajax()) self::unset_cms_sess_var('callbacks');	// make non persistent

		self::$cms_app = Ccms::get_or_post('app');

		if(self::is_cms_action()) {	//
			self::$cms_tool_name = self::get_or_post('tool_id');
			if(!empty(self::$cms_tool_name)) {
				if((is_numeric(self::$cms_tool_name)) && (($id = (int)self::$cms_tool_name) > 0)) {
					// get the correct name, assume self::$cms_body_name is the id
					self::$cms_tool_id = $id;
					self::$cms_tool_name = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_name', "cms_tool_id = " . $id );
					} // if
				else {
					self::$cms_tool_id = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_id', "cms_tool_name = '" . self::$cms_tool_name . "'");
					} //else
				if((int)self::$cms_tool_id > 0) {
					self::$cms_tool_version = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', "cms_tool_id = " . self::$cms_tool_id);
					} // if
				} // if
			self::$lm_link_name = self::get_or_post('link_id');
			if(!empty(self::$lm_link_name)) {
				if((is_numeric(self::$lm_link_name)) && (($id = (int)self::$lm_link_name) > 0)) {
					// get the correct name, assume self::$cms_body_name is the id
					self::$lm_link_id = $id;
					self::$lm_link_name = self::$cDBcms->get_data_in_table('lm_links', 'lm_link_name', "lm_link_id = " . $id );
					} // if
				else {
					self::$lm_link_id = self::$cDBcms->get_data_in_table('lm_links', 'lm_link_id', "lm_link_name = '" . self::$lm_link_name . "'");
					} //else
				} // if
			} // if

		self::$cms_body_name = self::get_or_post('app');
		if(empty(self::$cms_body_name)) self::$cms_body_name = self::get_or_post('body');
		if(empty(self::$cms_body_name)) self::$cms_body_name = self::get_or_post('frm');
		if(!empty(self::$cms_body_name)) {
			if((is_numeric(self::$cms_body_name)) && (($id = (int)self::$cms_body_name) > 0)) {
				// get the correct name, assume self::$cms_body_name is the id
				self::$cms_body_id = $id;
				$body = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_name,cms_body_app_key,cms_body_virtual_name, cms_body_lang', "cms_body_id = " . $id );
				foreach($body as $k => &$v) self::$$k = $v;	// quick
				if(empty(self::$cms_body_name)) self::$cms_body_id = false;
				} // if
			else {
				self::$cms_body_id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_name = '" . self::$cms_body_name . "' OR cms_body_dir = '" . self::$cms_body_name . "'");
				if(empty(self::$cms_body_id)) {
					self::$cms_body_id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_app_key = '" . self::$cms_body_name . "' OR cms_body_dir = '" . self::$cms_body_name . "'");
					} // else if
				else if(empty(self::$cms_body_id)) self::$cms_body_name = false;
				else {
					$body = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_name,cms_body_app_key,cms_body_virtual_name,cms_body_lang', "cms_body_id = " . self::$cms_body_id);
					foreach($body as $k => &$v) self::$$k = $v;	// quick
					} // else
				} //else
			if((int)self::$cms_body_id > 0) {
				self::$cms_body_version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', "cms_body_id = " . self::$cms_body_id);
				} // if
			// if(!self::get_app_action()) self::get_app_action('body');
			} // if

		if(!empty(self::$cms_body_id))
			self::set_cms_sess_var(self::$cms_body_id,'body');
		else if (self::get_cms_sess_var('body')) {
			self::$cms_body_id = self::get_cms_sess_var('body');
			self::unset_cms_sess_var('body');	// only use once
			} // else if

		self::$cms_plugin = self::get_or_post('plugin');
		if (!empty(self::$cms_plugin)) { // execute plugin
			$class = 'C' . self::$cms_plugin . '_plugin';
			if ((Ccms_autoloader::find_plugin($class)) &&
				(method_exists($class, 'is_enabled')) &&
				($class::is_enabled(self::$cms_plugin))) {

				if ($class::execute_form()) {
					$url = $class::executed_url(); // get return point
					Ccms::saveMsgs();
					Ccms_base::do_redirect_uri($url);
				} // if
			} // if
		} // if
	} // do_globals()

// static functions

	public static function is_drop_down_menu_admin_in_header() {
		if(self::is_cli()) return false;
		if(!is_null(self::$cms_menu_admin_in_header)) return self::$cms_menu_admin_in_header;
		if((!CMS_S_HEADER_BOOL) ||
			(CMS_C_CUSTOM_HEADER) ||
			(!self::is_group_manager())) {
			self::$cms_menu_admin_in_header = false;
			} // if
		else if((!CMS_S_HEADER_MENU_ADMIN_BOOL) && 
			(self::show_nav_bar())) {	
			self::$cms_menu_admin_in_header = false;
			} // else if
		else if((!CMS_S_HEADER_MENU_ADMIN_BOOL) && 
			(self::show_left_column())) {
			self::$cms_menu_admin_in_header = false;
			} // if
		else self::$cms_menu_admin_in_header = true;
		return self::$cms_menu_admin_in_header;
		} // is_drop_down_menu_admin_in_header()

	public static function is_drop_down_menu_apps_in_header() {
		if(self::is_cli()) return false;
		if(!is_null(self::$cms_menu_apps_in_header)) return self::$cms_menu_apps_in_header;
		if((!CMS_S_HEADER_BOOL) ||
			(CMS_C_CUSTOM_HEADER) || 
			(!CMS_S_HEADER_MENU_APPS_BOOL)) {
			self::$cms_menu_apps_in_header = false;
			} // if
		else self::$cms_menu_apps_in_header = true;
		return self::$cms_menu_apps_in_header;
		} // is_drop_down_menu_apps_in_header()

	public static function is_drop_down_menu_tools_in_header() {
		if(self::is_cli()) return false;
		if(!is_null(self::$cms_menu_tools_in_header)) return self::$cms_menu_tools_in_header;
		if((!CMS_S_HEADER_BOOL) ||
			(CMS_C_CUSTOM_HEADER) || 
			(!CMS_S_HEADER_MENU_TOOLS_BOOL)) {
			self::$cms_menu_tools_in_header = false;
			} // if
		else self::$cms_menu_tools_in_header = true;
		return self::$cms_menu_tools_in_header;
		} // is_drop_down_menu_tools_in_header()

	public static function is_drop_down_menus_in_header() {
		if(self::is_cli()) return false;
		// self::$cms_menus_in_header = true;	// test
		if(!is_null(self::$cms_menus_in_header)) return self::$cms_menus_in_header;
		if((!self::is_drop_down_menu_admin_in_header()) &&
			(!self::is_drop_down_menu_apps_in_header()) &&
			(!self::is_drop_down_menu_tools_in_header())) {
			self::$cms_menus_in_header = false;
			} // if
		else if((self::get_app_action() == 'get_eula') ||	// not on EULA page
			(self::get_cms_action() == 'get_eula') ||	// not on EULA page
			((CMS_S_HEADER_BOOL) && (self::is_tiny())))
			self::$cms_menus_in_header = false;
		else if((!CMS_S_HEADER_BOOL) ||
			(CMS_C_CUSTOM_HEADER) ||
			(self::is_moz4 ()) ||
			(!self::is_html5()))
			self::$cms_menus_in_header = false;
		else self::$cms_menus_in_header = true;
		return self::$cms_menus_in_header;
		} // is_drop_down_menus_in_header()

	private static function is_admin_tools() {
		if (self::is_cli())
			return false;
		if ((self::get_or_post('action') == 'login') ||
			(self::get_or_post('action') == 'cms_login'))
			return false;
		if (Ccms_auth::is_admin_user())
			return true;
		else if (Ccms::get_tool_cnt() > 0)
			return true;
		return false;
	} // is_admin_tools()

	protected static function is_eula_only() {
		if(!CMS_C_EULA_ENABLE) return false;
		if((self::get_app_action() == 'get_eula') ||	// may not on EULA page
			(self::get_cms_action() == 'get_eula')) {	// may not on EULA page
			$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
			if($tla['eula_show']) return true;
			} // if
		return false;
		} // is_eula_only()

	public static function show_nav_bar() {
		if(!is_null(self::$cms_nav_bar)) return self::$cms_nav_bar;
		if(is_null(self::$cms_nav_bar)) {
			if((!defined('CMS_S_NAV_BAR_BOOL')) ||
				(!CMS_S_NAV_BAR_BOOL))
				self::$cms_nav_bar = false;
			else self::$cms_nav_bar = true;
			} // if
		return self::$cms_nav_bar;
		} // show_nav_bar()

	public static function show_left_column() {
		if(!is_null(self::$cms_left_column)) return self::$cms_left_column;
		if((self::is_cli()) || (self::is_eula_only()) || (!CMS_S_LEFT_COLUMN_BOOL) ||
			// (self::show_nav_bar()) || // shown in nav bar
			(self::is_tiny()))
			self::$cms_left_column = false;
		else {
			// this part closely mimics the cms_page_left_column.php file
			self::$cms_left_column = false;	// assume off to start
			if(Ccms::get_body_cnt() > 0) self::$cms_left_column = true;
			else if(!self::show_right_column ()) {
				if((!self::$cms_tools_menu_output) &&
					(Ccms::get_tool_cnt() > 0))
					self::$cms_left_column = true;
				else if((!self::$cms_admin_menu_output) &&
					(self::is_group_manager()))
					self::$cms_left_column = true;
				else if(self::is_admin_tools())
					self::$cms_left_column = true;
				} // if
			} // else
		return self::$cms_left_column;
		} // show_left_column()

	public static function show_right_column() {
		if(!is_null(self::$cms_right_column)) return self::$cms_right_column;
		if((self::is_cli()) || (self::is_eula_only()) ||	// not on EULA page
			(!CMS_S_LEFT_COLUMN_BOOL) ||
			(!CMS_S_RIGHT_COLUMN_BOOL) ||
			// (self::show_nav_bar()) ||	// shown in nav bar
			(self::is_tiny()))
			self::$cms_right_column = false;
		else {
			// this part closely mimics the cms_page_right_column.php file
			self::$cms_right_column = false;	// assume off
			if((CMS_S_RIGHT_COLUMN_BOOL) && (Ccms::get_body_cnt() > 0)) {
				if((!self::$cms_tools_menu_output) &&
					(Ccms::get_tool_cnt() > 0))
					self::$cms_right_column = true;
				else if((!self::$cms_admin_menu_output) &&
					(self::is_group_manager()))
					self::$cms_right_column = true;
				else if(self::is_admin_tools())
					self::$cms_right_column = true;
				} // if
			} // else
		return self::$cms_right_column;
	} // show_right_column()

	public static function get_bodies($init = false) {
		if (self::$cms_bodies === false) { // not set yet
			$nav_bar_cnt = false;
			if(!Ccms::is_ajax()) {
				$nav_bar_grid = array();
				$nav_bar_cnt = self::get_navbar_grid_sanitised($nav_bar_grid);
				} // if
			self::$cms_bodies = array();

			$sql_query = "SELECT  cms_body_id,cms_body_version,cms_body_installed,cms_body_nomenu,cms_body_name,cms_body_app_key,cms_body_virtual_name,cms_body_lang,cms_body_title, cms_body_cached,cms_body_full_view,cms_body_iframe_view" .
				", cms_body_ssl, cms_body_enabled, cms_body_file, cms_body_group_ids,cms_body_default, cms_body_debug_only" .
				", cms_body_default_msgs, cms_body_login_page, cms_body_login_required, cms_body_description, cms_body_type, cms_body_dir" .
				" FROM  cms_bodies" .
				" WHERE  cms_body_enabled > 0" .
				(!self::is_user_logged_in() ? "":" AND cms_body_login_page = 0") .
				(self::is_user_logged_in() ? "":" AND cms_body_login_required = 0") .
				(self::is_debug() ? "":" AND cms_body_debug_only = 0") .
				" ORDER BY  cms_body_order,cms_body_name,cms_body_id";
			if (($result = self::$cDBcms->query($sql_query)) &&
				(self::$cDBcms->num_rows($result) > 0)) {
				$row = 0;
				while ($body = self::$cDBcms->fetch_array($result)) {
					if (!self::check_user_group_ids($body['cms_body_group_ids'])) continue;
					if(!Ccms_auth::is_page_allowed($body['cms_body_app_key'])) continue;
					if(Ccms::is_ajax()) continue;
//					if((!self::is_ssl_inuse()) &&
//						(((int)$body['cms_body_ssl']) || ((int)$body['cms_body_iframe_view'] > 0))
//						) continue;

					$url = '';
					$proxy_url = '';
					if(!is_readable(APPS_BODIES_FS_DIR . $body['cms_body_file'])) continue;
					$url .= Ccms::get_body_uri($body);

					if((!$init) && ($nav_bar_cnt) && (self::is_on_navbar($nav_bar_grid, $url))) continue;

					self::$cms_bodies[($body['cms_body_id'])] = array(
						'id' => $body['cms_body_id'],
						'name' => Ccms_html::get_navbar_icon_text($body['cms_body_id'],$body['cms_body_name']),
						'virtual_name' => $body['cms_body_virtual_name'],
						'app_lang' => $body['cms_body_lang'],
						'version' =>  $body['cms_body_version'],
						'cached' => $body['cms_body_cached'],
						'default_page' =>  $body['cms_body_default'],
						'nomenu' => $body['cms_body_nomenu'],
						'login_page' => $body['cms_body_login_page'],
						'login_required' => $body['cms_body_login_required'],
						'file' =>  $body['cms_body_file'],
						'full_view' =>  $body['cms_body_full_view'],
						'iframe_view' => $body['cms_body_iframe_view'],
						'ssl' =>  $body['cms_body_ssl'],
						'uri' => $url,
						'proxy_url' => $proxy_url,
						'type' => $body['cms_body_type'],
						'title' => (!empty($body['cms_body_title']) ? strip_tags($body['cms_body_title']) : ''),
						'debug_only' => $body['cms_body_debug_only'],
						'app_dir' => (empty($body['cms_body_dir']) ? '':$body['cms_body_dir']),
						'app_key' => self::get_app_key($body),
						'app_name' => self::get_app_name($body),
						);
					if(((int)self::$cms_body_id > 0) && (self::$cms_body_id == $body['cms_body_id'])) {
						self::$cms_app_dir = (empty($body['cms_body_dir']) ? '':$body['cms_body_dir']);
						self::$cms_app_key = self::get_app_key($body);
						self::$cms_app_name = self::get_app_name($body);
						self::$cms_app_type = $body['cms_body_type'];
						} // if
				} // while
			} //if
		self::$cDBcms->free_result($result);
		} // if
		return self::$cms_bodies;
	} // get_bodies()

	public static function get_body_cnt() {
		if (self::$cms_bodies_cnt === false) { // not set yet
			self::$cms_bodies_cnt = count(self::get_bodies(true));
		} // if
		return self::$cms_bodies_cnt;
	} // get_body_cnt()

	public static function get_tools($redo = false) {
		if(($redo) || (self::$cms_tools === false)) { // not set yet
			self::$cms_tools = array();
			if((CMS_S_TOOLS_LOGIN_REQD_BOOL) && (!self::is_user_logged_in())) return self::$cms_tools;

			$sql_query = "SELECT  cms_tool_id,cms_tool_name,cms_tool_version,cms_tool_url,cms_tool_title, cms_tool_debug_only" .
				", cms_tool_new_page, cms_tool_enabled, cms_tool_ssl, cms_tool_login_required, cms_tool_group_ids, cms_tool_add_name2url" .
				" FROM  cms_tools" .
				" WHERE  cms_tool_enabled > 0" .
				(self::is_user_logged_in() ? "":" AND cms_tool_login_required = 0") .
				(self::is_debug() ? "":" AND cms_tool_debug_only = 0") .
				" ORDER BY  cms_tool_order,cms_tool_name,cms_tool_id";
			if (($result = self::$cDBcms->query($sql_query)) &&
				(self::$cDBcms->num_rows($result) > 0)) {
				$row = 0;
				while ($tool = self::$cDBcms->fetch_array($result)) {
					if(empty($tool['cms_tool_url'])) continue;
					if(!file_exists(LOCAL_FS_TOOLS_DIR . $tool['cms_tool_url'])) continue;
					if (!self::check_user_group_ids($tool['cms_tool_group_ids']))
						continue;

					$url = Ccms_sm::get_tool_uri($tool);

					self::$cms_tools[] = array(
						'id' => 'cms_tool_id',
						'name' => $tool['cms_tool_name'],
						'version' => $tool['cms_tool_version'],
						'uri' => $url,
						'ssl' => $tool['cms_tool_ssl'],
						'new' => (($tool['cms_tool_new_page']) ? '" target="_blank' : ''),
						'title' => (!empty($tool['cms_tool_title']) ? strip_tags($tool['cms_tool_title']) : LOCAL_WS_TOOLS_DIR . $tool['cms_tool_url']) . (($tool['cms_tool_new_page'] && CMS_C_SHOWINNEWTAB) ? PHP_EOL . '(in a new tab)' : ''),
					);
				} // while
			} //if
			self::$cDBcms->free_result($result);
		} // if
		return self::$cms_tools;
	} // get_tools()

	public static function get_tool_cnt($redo = false) {
		if (($redo) || (self::$cms_tools_cnt === false)) { // not set yet
			self::$cms_tools_cnt = count(Ccms::get_tools($redo));
		} // if
		return self::$cms_tools_cnt;
	} // get_tool_cnt()

	public static function get_body_version($body_dir_id = false) {	// $body(array), $dir or $id
		if(empty($body_dir_id)) return self::$cms_body_version;
		if(is_array($body_dir_id)) {
			$version = self::getDottedKeys2Var($body_dir_id,'cms_body_version');
			if(!empty($version)) return $version;
			$id = self::getDottedKeys2Var($body_dir_id,'cms_body_id');
			if((!empty($id)) &&
				($version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', "cms_body_id = " . $id)))
				return $version;
			if($version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version',
				"cms_body_id = " . $body_dir_id['cms_body_id'] . " OR cmc_body_dir '" . $body_dir_id['cms_body_dir'] . "'"))
				return $version;
			if(isset($body['cms_body_version'])) return $body['cms_body_version'];
			} // if
		if(((int)$body_dir_id > 0) &&
			($version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version',"cms_body_id = " . (int)$body_dir_id)))
			return $version;
		if($version = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version',"cms_body_dir = '" . $body_dir_id . "'"))
			return $version;	// wobbly, miltiple apps can be one dir
		return self::$cms_body_version;
		} // get_body_version()

	public static function get_tool_version($tool = false) {
		if((empty($tool)) && (!empty(self::$cms_tool_version))) return self::$cms_tool_version;
		$version = self::getDottedKeys2Var($tool,'cms_tool_version');
		if(!empty($version)) return $version;
		$id = self::getDottedKeys2Var($tool,'cms_tool_id');
		if((!empty($id)) &&
			($version = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', "cms_tool_id = " . $id)))
			return $version;
		return self::$cms_tool_version;
		} // get_tool_version()

	public static function get_home_body() {
		global $cCMS;
		$body = $cCMS->lookup_default_body(true);
		return $body;
		} // get_home_body()

	public static function get_home_filepath() {	// for include
		$body = self::get_home_body();
		if(!empty($body)) {
			$filepath = self::get_body_filepath ($body);
			return $filepath;
			} // if
		// dont return index.php, it has called this method
		return false;
		} // get_home_filepath()

	public static function get_home_link() {
		$body = self::get_home_body();
		if(!empty($body)) $url = self::get_body_uri ($body);
		else $url = (Ccms::is_ssl_required() ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		$text = '<a href="' . $url . '"' .
			' onclick="Ccms_cursor.setWait();" title="Home Page">';
		if(strlen(CMS_C_LOGO_IMAGE) > 4) {
			if(is_readable(CMS_C_LOGO_IMAGE)) $img = CMS_C_LOGO_IMAGE;
			else $img = ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE;
			$text .= ' <img class="logo" src="' . $img. '" alt="Home">';
			} // if
		else $text .= '<strong>Home</strong>';
		$text .= '</a>';
		return $text;
		} // get_home_link()

	public static function &get_navbar_grid_sanitised(&$cms_nav_bar_grid = null, $privileged = true) {
		$nav_bar_grid = array();	// clean it
		static $nav_bar_grid_cnt = 0;	// for ref return
		if(!self::show_nav_bar()) return $nav_bar_grid_cnt;
		if(($privileged) && (self::$cms_nav_bar_grid_sanitised_privileged)) {
			if(is_null($cms_nav_bar_grid)) return self::$cms_nav_bar_grid_sanitised_privileged;
			$cms_nav_bar_grid = self::$cms_nav_bar_grid_sanitised_privileged;
			return self::$cms_nav_bar_grid_sanitised_privileged_cnt;
			} // if
		else if((!$privileged) && (self::$cms_nav_bar_grid_sanitised)) {
			if(is_null($cms_nav_bar_grid)) return self::$cms_nav_bar_grid_sanitised;
			$cms_nav_bar_grid = self::$cms_nav_bar_grid_sanitised;
			return self::$cms_nav_bar_grid_sanitised_cnt;
			} // if
		
		if(defined('CMS_C_NAVBAR_LINKS') && (strlen(CMS_C_NAVBAR_LINKS) > 8)) { // 6 is the minimum size for of serialized array
			// echo CMS_C_NAVBAR_LINKS;	// test
			$grid_all = self::chk_unserialize(CMS_C_NAVBAR_LINKS);	// hot fix for PHP5 on V2.19-2
			foreach ($grid_all as $g) { // check body enabled
				$bid = false;
				$uri = (!empty($g[0]['uri']) ? $g[0]['uri']:$g[0]);
				if(preg_match('/^menu=/',$uri)) {
					$nav_bar_grid[] = $g;
					$nav_bar_grid_cnt++;
					continue;
					} // if

				if((preg_match('/login.php|action=.*login/i',$uri)) &&
					((self::is_user_logged_in()) ||
					(preg_match('/cms_login/',self::get_cms_action())) ||
					(preg_match('/login/',self::get_app_action())))) {
					continue;
					} // if
				else if((preg_match('/logout.php|action=.*logout/i',$uri)) &&
					((!self::is_user_logged_in()) ||
					(preg_match('/cms_logout/',self::get_cms_action())) ||
					(preg_match('/logout/',self::get_app_action())))) {
					continue;
					} // if
				else {
					if (preg_match('/^id_(app|body)_[0-9]+/', $uri)) {	// new style nav link
						$bid = preg_replace('/^id_(app|body)_([0-9]+).*$/', '$2', $uri);
						} // if
					else if (preg_match('/^.*(app|body)=[0-9]+&name=/i', $uri)) {	// old style nav link
						$bid = preg_replace('/^.*(app|body)=([0-9]+)&name=.*$/i', '$2', $uri);
						} // if
					if (empty($bid)) $g['bid'] = 0;
					} // if

				if(!empty($bid)) {
					$where = "cms_body_id = '" . (int)$bid . "' AND cms_body_enabled > 0" .
						((self::is_debug() && !$privileged) ? "":" AND cms_body_debug_only = 0");
					if(!$body = self::$cDBcms->get_data_in_table('cms_bodies', '*', $where)) continue;
					if(!is_readable(APPS_BODIES_FS_DIR . $body['cms_body_file'])) continue;

					$g['group'] = self::check_user_group_ids($body['cms_body_group_ids']);
					$g['allowed'] = Ccms_auth::is_navbar_element_allowed($g[1]);

					if($privileged) {
						if(!$g['group']) continue;
						if(!$g['allowed']) continue;
						} // if

					// add keyed values to decode the Ccms_options::grid_input_form_elems() method
					$g['name'] = $body['cms_body_name'];
					$g['app_key'] = $body['cms_body_app_key'];
					$g['bid'] = (int)$body['cms_body_id'];
					$g['uri'] = $uri;
					$g['text'] = $g[1];
					$g['title'] = $g[2];
					$icon = Ccms_html::get_navbar_icon_text($g['bid'],$g[1]);
					if(!empty($icon)) $g['nb_icon'] = $icon;
					else $g['nb_icon'] = $g[1];
					$g['mn_icon'] = Ccms_html::get_menu_icon_text($g['bid'],$g[1]);
					$g['manual'] = $body['cms_body_manual_url'];
					$g['icon'] = $body['cms_body_icon_url'];
					$g['image'] = $body['cms_body_image_url'];
					$g['debug_only'] = ($body['cms_body_debug_only'] ? true:false);
					$g['production'] = !$g['debug_only'];

					// get text for the application, menus, etc.
					$g['description'] = $body['cms_body_description'];
					$g['purpose'] = $body['cms_body_purpose'];
					$g['info1'] = $body['cms_body_info1'];
					$g['info2'] = $body['cms_body_info2'];
					$g['version'] = $body['cms_body_version'];
					} // if
				$nav_bar_grid[] = $g;
				$nav_bar_grid_cnt++;
				} // foreach
			} // if
		else { // something gone wrong
			self::addAdminMsg('Missing NAV BAR link settings.');
			if(Ccms_auth::is_admin_user()) {
				$nav_bar_grid[] = array(0 => array('uri' => 'menu=admin'));
				$nav_bar_grid_cnt++;
				} // if
			} // if

		if($privileged) {
			self::$cms_nav_bar_grid_sanitised_privileged = $nav_bar_grid;
			self::$cms_nav_bar_grid_sanitised_privileged_cnt = $nav_bar_grid_cnt;
			if(is_null($cms_nav_bar_grid)) return self::$cms_nav_bar_grid_sanitised_privileged;
			$cms_nav_bar_grid = self::$cms_nav_bar_grid_sanitised_privileged;
			return self::$cms_nav_bar_grid_sanitised_privileged_cnt;
			} // if
		else if(!$privileged) {
			self::$cms_nav_bar_grid_sanitised = $nav_bar_grid;
			self::$cms_nav_bar_grid_sanitised_cnt = $nav_bar_grid_cnt;
			if(is_null($cms_nav_bar_grid)) return self::$cms_nav_bar_grid_sanitised;
			$cms_nav_bar_grid = self::$cms_nav_bar_grid_sanitised;
			return self::$cms_nav_bar_grid_sanitised_cnt;
			} // if
		} // get_navbar_grid_sanitised()

	public static function &get_navbar_grid($menu_only = false) {	// need this to return a pointer for both options to save time
		if (((!$menu_only) && (self::$cms_nav_bar_grid === false)) || 
			(($menu_only) && (self::$cms_nav_bar_grid_menu_only === false))) { // not set yet
			$nav_bar_grid = array();
			if($nav_bar_grid_cnt = self::get_navbar_grid_sanitised($nav_bar_grid)) {

				// add bodies to nav bar grid here for other purposes
				$body_cnt = self::get_body_cnt();
				$cms_bodies = self::get_bodies();
				$nav_bar_grid['apps'] = array();
				$navbar_apps = &$nav_bar_grid['apps'];
				foreach($cms_bodies as &$body) {
					$navbar_apps[($body['name'])] = $body;
					} // foreach

//				if (($tool_cnt = self::get_tool_cnt(true)) > 0) {
//					self::$cms_tools_on_navbar = true;
//					$cms_tools = self::get_tools();
//					foreach ($cms_tools as $tool) {
//						if(!Ccms_auth::is_navbar_element_allowed($tool['name'])) continue;
//						self::$nav_bar_grid[] = array(
//							0 => $tool['uri'] . $tool['new'],
//							1 => $tool['name'],
//							2 => $tool['title'],
//							'tid' => $tool['id'],
//							'uri' => $tool['uri'] . $tool['new'],
//							'title' => $tool['title'],
//							'nb_icon' => $tool['name'],
//							'mn_icon' => $tool['name'],
//							'version' => self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', 'cms_tool_id = ' . $tool['id']),
//							);
//
//						self::$nav_bar_grid_cnt++;
//						} // foreach
//					self::$cms_tools_cnt = 0;
//					self::$cms_tools = array();
//				} // if

				if(!$menu_only) {
					// nothing for now
					} // if
			} // if
		if(!$menu_only) {
			self::$cms_nav_bar_grid_cnt = $nav_bar_grid_cnt;
			self::$cms_nav_bar_grid = $nav_bar_grid; 
			} // if
		else {
			self::$cms_nav_bar_grid_cnt = $nav_bar_grid_cnt;
			self::$cms_nav_bar_grid_menu_only = $nav_bar_grid; 
			} // else
		} // if
	if(!$menu_only) return self::$cms_nav_bar_grid;
	else return self::$cms_nav_bar_grid_menu_only; 
	} // get_navbar_grid()

	public static function get_navbar_cnt() {
		if (self::$cms_nav_bar_grid_cnt === false) { // not set yet
			self::get_navbar_grid();
		} // if
		return self::$cms_nav_bar_grid_cnt;
	} // get_navbar_cnt()

	public static function set_form_cms_return_action() {	// set return action required
		if(!self::is_get_or_post('cms_return_action')) return;
		$cms_return_action = rawurldecode(Ccms::get_or_post('cms_return_action'));
		echo '<input type="hidden" name="cms_return_action" value="' . rawurlencode($cms_return_action) . '"/>' . PHP_EOL;
	} // set_form_cms_return_action()

	public static function do_cms_return_action() {	// does not return action required
		if(!$cms_return_action = self::get_cms_sess_var('cms_return_action')) {
			if(!self::is_get_or_post('cms_return_action')) return;
			$cms_return_action = rawurldecode(Ccms::get_or_post('cms_return_action'));
			} // else
		if(!headers_sent()) {
			self::unset_cms_sess_var('cms_return_action');
			$url = 'index.php?cms_action=' . $cms_return_action;
			Ccms_base::do_redirect_uri($url);
			} // if
		self::set_cms_sess_var($cms_return_action,'cms_return_action');
		// exit(0);
	} // do_cms_return_action()

	public static function chk_domain_to_host() {
		if(!CMS_S_HOSTS_URLS_CHECKED_BOOL) return true;	// ok
		if(self::is_cli()) return true;	// ok, on CLI
		$doms = explode(':',CMS_S_HOSTS_URLS_ALLOWED);
		if(empty($doms)) return true;	// nothing to check
		if((in_array($_SERVER['HTTP_HOST'],$doms))) return true;	// ok

		// else it's not me
		self::addMsg('Domain error, requested domain "' . $_SERVER['HTTP_HOST'] . '".');
		$url = CMS_S_HOSTS_URLS_ERROR_URL;
		if(!empty($url)) {	// have redirect
			$proto = "";
			if(!preg_match('/^http:\/\/|^https:\/\//i',$url)) $proto = "http://";
			Ccms_base::do_redirect_uri($proto . $url);
			} // if
		return false;
		} // chk_domain_to_host()

	public static function get_body_title($body = false) {	 // used by the AppsCMS to make google loved URIs
		if(empty($body)) $body = self::$cms_page_info['body'];
		$title = '';
		$title .= $body['cms_body_title'];
		return CMS_C_TITLE . (!empty($title) ? ' - ' . $title:'');
		} // get_body_title()

	public static function get_body_dir($body = false, $prefix_it = false) {
		// $prefix_it is rarely needed as the <base href="http://some.where/"> sets the prefix
		if(empty($body)) $body = self::$cms_page_info['body'];
		$dir = ($prefix_it ? APPS_WS_DIR:'');	// home dir
		if(isset($body['cms_body_dir'])) {
			$dir .= $body['cms_body_dir'];	// not loved by Google (has no connection to the page name
			} // if
		else if((is_array($body)) && (count($body) > 0)) {
			$dir .= self::getDottedKeys2Var($body,'cms_body_dir');
			if(empty($dir)) return '';
			} // if
		else {
			// @TODO add error msg, maybe ??
			} // else
		return $dir;	// default to home, no info
		} // get_body_dir()

	public static function get_body_filepath($body = false) {
		if(empty($body)) $body = self::$cms_page_info['body'];
		$filepath = self::clean_path(APPS_BODIES_FS_DIR . $body['cms_body_file']);
		return $filepath;
		} // get_body_filepath()

	public static function get_body_uri($body = false, $prefix_it = false, $nofrm = false) {	 // used by the AppsCMS to make google loved URIs
		// $prefix_it is rarely needed as the <base href="http://some.where/"> sets the prefix
		$uri = ($prefix_it ? CMS_URI_ALIAS:'') . 'index.php';	// home uri
		if(empty($body)) {
			if(empty(self::$cms_page_info['body'])) return $uri;
			$body = self::$cms_page_info['body'];
			} // if

		if((!$nofrm) && (!empty($body['cms_body_iframe_view'])) &&
			((int)$body['cms_body_iframe_view'] > 0) &&
			(!self::is_iframe_request())) {	// for get around security bugs in browsers
			// is link to to an iframe
			if((isset($body['cms_body_id'])) && ((int)$body['cms_body_id'] > 0)) {
				$body_pre = '?frm=';
				$uri = CMS_SSL_URL . 'index.php' . $body_pre . $body['cms_body_id'];	// not loved by Google (has no connection to the page name
				return $uri;	// iframe link
				} // if
			} // if
		$body_pre = '?app=';

		if(empty($body)) {	// got current body
			if($vfs_name = self::get_vfs_name()) {
				$uri = ($prefix_it ? CMS_URI_ALIAS:'') . $vfs_name;	// vfs uri
				return $uri;
				} // if
			if(!empty(self::$cms_body_virtual_name)) return $uri . '/' . self::$cms_body_virtual_name;
			if((int)self::$cms_body_id > 0) return $uri . $body_pre . self::$cms_body_id;
			return $uri;	// default to home, no info
			} // if
		if(!is_array($body)) {
			if((is_numeric($body)) && ((int)$body > 0)) {
				$body_defines = Ccms_sm::get_bodies_defines();
				if((!empty($body_defines[(int)$body]['cms_body_virtual_name'])) && (self::has_apache_rewrite())) {
					$uri = ($prefix_it ? CMS_URI_ALIAS:'') . $body_defines[(int)$body]['cms_body_virtual_name'];
					return $uri;
					} // if
				} // if
			// @TODO check the $body exists
			return $uri .= $body_pre . urlencode ($body);	// no choices
			} // if
		else if((!empty($body['cms_body_virtual_name'])) && (self::has_apache_rewrite())) {
			$uri = ($prefix_it ? CMS_URI_ALIAS:'') . $body['cms_body_virtual_name'];	// vfs uri
			} // if
		else if((isset($body['cms_body_id'])) && ((int)$body['cms_body_id'] > 0)) {
			$uri .= $body_pre . $body['cms_body_id'];	// not loved by Google (has no connection to the page name
			if(isset($body['cms_body_name'])) $uri .= '&name=' . urlencode ($body['cms_body_name']); // for google
			} // if
		else if((isset($body['cms_body_name'])) &&
			(strlen($body['cms_body_name']) > 4)) {
			$uri .= $body_pre . urlencode ($body['cms_body_name']);	// loved by Google
			} // if
		else if(count($body) > 0) {
			$id = self::getDottedKeys2Var($body,'cms_body_id');
			if(!empty($id)) {
				$uri .= $body_pre . $id;	// not loved by Google (has no connection to the page name
				} // if
			} // if
		else {
			// @TODO add error msg, maybe ??
			self::addDebugMsg('No default page.', 'warn');
			} // else
		return $uri;	// default to home, no info
		} // get_body_uri()

	public static function get_tool_title($tool = false) {	 // used by the AppsCMS to make google loved URIs
		$title = '';
		if(isset($tool['cms_tool_title'])) {
			$title .= $tool['cms_tool_title'];
			} // if
		return CMS_C_TITLE . (!empty($title) ? ' - ' . $title:'');
		} // get_tool_title()

	public static function get_link_title($link = false) {	 // used by the AppsCMS to make google loved URIs
		$title = '';
		if(isset($link['lm_link_title'])) {
			$title .= $link['lm_link_title'];
			} // if
		return CMS_C_TITLE . (!empty($title) ? ' - ' . $title:'');
		} // get_link_title()

	public static function get_tool_uri($tool) {	 // used by the AppsCMS to make google loved URIs
		if(!is_array($tool)) {
			if(((int)$tool > 0) &&
				(!$tool = self::$cDBcms->get_data_in_table('cms_tools',
					array('cms_tool_id','cms_tool_name','cms_tool_url','cms_tool_new_page','cms_tool_add_name2url'),
					'cms_tool_id = ' . (int)$tool))) {
				return false;
				} // if
			} // if
		$uri = '';
		if (!$tool['cms_tool_new_page']) {
			$uri.= 'index.php?cms_action=tool&tool_id=' . (int) $tool['cms_tool_id'] . '&name=' . urlencode($tool['cms_tool_name']);
			} // if
		else {
			$uri .= LOCAL_WS_TOOLS_DIR . $tool['cms_tool_url'] . ((int) $tool['cms_tool_add_name2url'] ? '?name=' . urlencode($tool['cms_tool_name']) : ''). '" target="_blank';
			} // else
		return $uri;	// default to home, no info
		} // get_tool_uri()

	private static function get_row_image_uri(&$row,$idx,$path,$uri,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$value = '';
		if(!is_array($row)) $value = $row;
		else if(!empty($row[$idx])) {
			$value = $row[$idx];
			if(!file_exists(DOCROOT_FS_BASE_DIR . $value)) {
				if(!empty($row['cms_body_dir'])) $value = APPS_WS_DIR . $row['cms_body_dir'] . '/' . $row[$idx];
				} // if
			} // if
		else return $default;
		$cCMS_C = new Ccms_config();
		return $cCMS_C->show_image($value,$uri,$class,$alt);
		} // get_row_image_uri()

	private static function chk_link_get($link) {
		if((!is_array($link)) && (is_numeric($link)) && ((int)$link > 0)) {
			$sql = 'SELECT * FROM lm_links WHERE lm_link_id = ' . (int)$link;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($link = self::$cDBcms->fetch_array($result))) {
				return $link;
				} // if
			} // if
		return $link;
		} // chk_link_get()

	public static function get_link_icon_uri($link,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$link = self::chk_link_get($link);
		return self::get_row_image_uri($link, 'lm_link_icon_url', $path, $uri,$default,$class,$alt);
		} // get_link_icon_uri()

	public static function get_link_image_uri($link,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$link = self::chk_link_get($link);
		return self::get_row_image_uri($link, 'lm_link_image_url', $path, $uri,$default,$class,$alt);
		} // get_link_image_uri()

	private static function chk_section_get($section) {
		if((!is_array($section)) && (is_numeric($section)) && ((int)$section > 0)) {
			$sql = 'SELECT * FROM lm_sections WHERE lm_section_id = ' . (int)$section;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($section = self::$cDBcms->fetch_array($result))) {
				return $section;
				} // if
			} // if
		return $section;
		} // chk_section_get()

	public static function get_section_icon_uri($section,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$section = self::chk_section_get($section);
		return self::get_row_image_uri($section, 'lm_section_icon_url', $path, $uri,$default,$class,$alt);
		} // get_section_icon_uri()

	public static function get_section_image_uri($section,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$section = self::chk_section_get($section);
		return self::get_row_image_uri($section, 'lm_section_image_url', $path, $uri,$default,$class,$alt);
		} // get_section_image_uri()

	private static function chk_body_get($body_col) {
		if($body_col === false) $body_col = self::$cms_body_id;
		if(empty($body_col)) $body_col = self::get_or_post ('cms_body_id');	// body edit
		if(empty($body_col)) $body_col = self::get_or_post ('cms_body_clone_from_id');	// body clone

		if((!empty($body_col)) && (!is_array($body_col))) {
			$sql = 'SELECT * FROM cms_bodies' .
				' WHERE cms_body_dir = \'' . $body_col . '\'' .
				' OR cms_body_name = \'' . $body_col . '\'' .
				' OR cms_body_app_key = \'' . $body_col . '\'' .
				' OR cms_body_id = ' . (int)$body_col;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($body = self::$cDBcms->fetch_array($result))) {
				return $body;
				} // if
			} // if
		if((empty($body_col)) && ($cms_app_var = self::get_or_post('app'))) {
			list($cms_app_dir,$cms_app_uri) = explode('/',$cms_app_var);
			$sql = 'SELECT * FROM cms_bodies WHERE cms_body_dir = \'' . $cms_app_dir . '\'';
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($body = self::$cDBcms->fetch_array($result))) {
				return $body;
				} // if
			} // if

		// check for assoc arry
		if(!empty($body_col['cms_body_id'])) {
			$id = $body_col['cms_body_id'];
			$sql = 'SELECT * FROM cms_bodies WHERE cms_body_id = ' . (int)$id;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($body = self::$cDBcms->fetch_array($result))) {
				return $body;	// all columns
				} // if
			} // if
		return $body_col;
		} // chk_body_get()

	private static function get_body_elem_uri(&$body,$name,$default = '',$path = false,$uri = false, $base_only = true) {	 // used by the AppsCMS to make google loved URIs
		if(empty($path)) $path = APPS_FS_DIR;
		if(empty($uri)) $uri = APPS_WS_DIR;
		$value = '';
		if(!is_array($body)) $value = $body;
		else if((isset($body[$name])) && (!empty($body[$name]))) $value = $body[$name];
		else return $default;

		if((!is_string($value)) || (is_numeric($value))) return $default;

		if((file_exists($path . $value))) return ($base_only ? $value:$uri . $value);	// in a common dir
		if(!empty($body['cms_body_dir'])) {
			if(file_exists($path . $body['cms_body_dir'] . '/docs/' . $value)) {
				if(!$base_only) return $uri . $body['cms_body_dir'] . '/doc/' . $value;
				return $value;
				} // if
			} // if

//		$parts = parse_url($value);
//		if((!empty($parts['scheme'])) &&
//			(!empty($parts['host']))) {
//			return htmlentities($value);
//			} // if
		self::addMsg('Cannot find "' . $value . '".','warn');
		return $default;
		} // get_body_elem_uri()

	public static function get_body_elem_h1($cms_body_id = false) {
		$body = self::chk_body_get($cms_body_id);
		$value = '';
		if(!empty($body['cms_body_H1']))
			$value = $body['cms_body_H1'];
		else if(!empty($body['cms_body_name']))
			$value = $body['cms_body_name'];
		return $value;
		} // get_body_elem_h1()

	public static function is_body_terms2show($body) {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(!$body['cms_body_terms_upfirst']) return false;
		if(!Ccms_auth::is_eula_agreement_required('Body-agree-' . $body['cms_body_name'])) return false;
		return true;
		} // is_body_terms2show()

	public static function update_body_terms2show($body,$new) {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(!Ccms_auth::update_user_json_data('Body-agree-' . $body['cms_body_name'],$new)) return false;
		return true;
		} // update_body_terms2show()

	public static function get_body_icon_uri($body = false,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$body = self::chk_body_get($body);
		return self::get_row_image_uri($body, 'cms_body_icon_url', $path, $uri,$default,$class,$alt);
		} // get_body_icon_uri()

	public static function get_body_image_uri($body = false,$default = '',$class = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$body = self::chk_body_get($body);
		return self::get_row_image_uri($body, 'cms_body_image_url', $path, $uri,$default,$class,$alt);
		} // get_body_image_uri()

	public static function get_body_logo_uri($class = 'logo',$cms_body_id = false,$alt = false) {	 // used by the AppsCMS to make google loved URIs
		$text = self::get_body_icon_uri($cms_body_id,'',$class,$alt);
		if(empty($text))
			$text = self::get_body_image_uri($cms_body_id,'',$class,$alt);
		return $text;
		} // get_body_logo_uri()

	public static function get_body_terms_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_elem_uri($body, 'cms_body_terms_url',$default);
		} // get_body_terms_uri()

	public static function get_body_terms_upfirst($body) {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		return $body['cms_body_terms_upfirst'];
		} // get_body_terms_upfirst()

	public static function get_body_readme_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_elem_uri($body, 'cms_body_readme_url',$default);
		} // get_body_readme_uri()

	public static function get_body_release_notes_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_elem_uri($body, 'cms_body_release_notes_url',$default);
		} // get_body_release_notes_uri()

	public static function get_body_manual_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_elem_uri($body, 'cms_body_manual_url',$default);
		} // get_body_manual_uri()

	public static function get_body_acknowledgment_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_elem_uri($body, 'cms_body_acknowledgment_url',$default);
		} // get_body_acknowledgment_uri()

	public static function get_body_licence_uri($body,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$body = self::chk_body_get($body);
		if(empty($body['cms_body_dir'])) return (!empty($default) ? '(no dir)':'');
		return self::get_body_elem_uri($body, 'cms_body_licence_url',$default);
		} // get_body_licence_uri()

	private static function chk_tool_get($tool) {
		if($tool === false) $tool = self::$cms_tool_id;
		if(empty($tool)) $tool = self::get_or_post ('cms_tool_id');

		if((!is_array($tool)) && (is_numeric($tool)) && ((int)$tool > 0)) {
			$sql = 'SELECT * FROM cms_tools WHERE cms_tool_id = ' . (int)$tool;
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($tool = self::$cDBcms->fetch_array($result))) {
				return $tool;
				} // if
			} // if
		// check for assoc arry
		if((empty($tool)) || (!is_array($tool))) return false;
		$k = key($tool);
		if(!empty($tool[$k]['cms_tool_id'])) {
			$sql = 'SELECT * FROM cms_tools WHERE cms_tool_id = ' . (int)$tool[$k]['cms_tool_id'];
			if(($result = self::$cDBcms->query($sql)) &&
				(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
				($tool = self::$cDBcms->fetch_array($result))) {
				return $tool;
				} // if
			} // if
		return $tool;
		} // chk_tool_get()

	public static function update_tool_terms2show($tool,$new) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($tool);
		if(!Ccms_auth::update_user_json_data('Tool-agree-' . $tool['cms_tool_name'],$new)) return false;
		return true;
		} // update_tool_terms2show()

	public static function is_tool_terms2show($tool) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($tool);
		if(!$tool['cms_tool_terms_upfirst']) return false;
		if(!Ccms_auth::is_eula_agreement_required('Tool-agree-' . $tool['cms_tool_name'])) return false;
		return true;
		} // is_tool_terms2show()

	private static function get_tool_elem_uri(&$tool,$name,$path,$uri,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$value = '';
		if(!is_array($tool)) $value = $tool;
		else if((isset($tool[$name])) && (!empty($tool[$name]))) $value = $tool[$name];
		else return $default;

		if((!is_string($value)) || (is_numeric($value))) return $default;

		if((file_exists($path . $value))) return $uri . $value;

//		$parts = parse_url($value);
//		if((!empty($parts['scheme'])) &&
//			(!empty($parts['host']))) {
//			return htmlentities($value);
//			} // if
		self::addMsg('Cannot find "' . $uri . $value . '".','warn');
		return $default;
		} // get_tool_elem_uri()

	private static function get_tool_elem_h1($cms_tool_id = false) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($cms_tool_id);
		$value = $tool['cms_tool_name'];
		return $value;
		} // get_tool_elem_h1()

	public static function get_tool_icon_uri($tool,$default = '',$class = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_ICONS_DIR;
		$uri = ETC_WS_ICONS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_row_image_uri($tool, 'cms_tool_icon_url', $path, $uri,$default,$class);
		} // get_tool_icon_uri()

	public static function get_tool_image_uri($tool,$default = '',$class = false) {	 // used by the AppsCMS to make google loved URIs
		$path = ETC_FS_IMAGES_DIR;
		$uri = ETC_WS_IMAGES_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_row_image_uri($tool, 'cms_tool_image_url', $path, $uri,$default,$class);
		} // get_tool_image_uri()

	public static function get_tool_readme_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_tool_elem_uri($tool, 'cms_tool_readme_url', $path, $uri,$default);
		} // get_tool_readme_uri()

	public static function get_tool_release_notes_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_tool_elem_uri($tool, 'cms_tool_release_notes_url', $path, $uri,$default);
		} // get_tool_release_notes_uri()

	public static function get_tool_terms_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_tool_elem_uri($tool, 'cms_tool_terms_url', $path, $uri,$default);
		} // get_tool_terms_uri()

	public static function get_tool_terms_upfirst($tool) {	 // used by the AppsCMS to make google loved URIs
		$tool = self::chk_tool_get($tool);
		return $tool['cms_tool_terms_upfirst'];
		} // get_tool_terms_upfirst()

	public static function get_tool_acknowledgment_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_tool_elem_uri($tool, 'cms_tool_acknowledgment_url', $path, $uri,$default);
		} // get_tool_acknowledgment_uri()

	public static function get_tool_licence_uri($tool,$default = '') {	 // used by the AppsCMS to make google loved URIs
		$path = LOCAL_FS_TOOLS_DIR;
		$uri = LOCAL_WS_TOOLS_DIR;
		$tool = self::chk_tool_get($tool);
		return self::get_tool_elem_uri($tool, 'cms_tool_licence_url', $path, $uri,$default);
		} // get_tool_licence_uri()

	public static function get_AppsCMS_title($prefix = false, $suffix = false) {
		// get title and format in an orderly fashion
		return ($prefix ? $prefix . ' - ':'') .
			CMS_PROJECT_NAME . ' (' . CMS_PROJECT_SHORTNAME . ')' . ' - ' . CMS_PROJECT_VERSION .
			($suffix ? ' - ' . $suffix:'');
	}// get_AppsCMS_title()

	public static function prn_AppsCMS_title($prefix = false, $suffix = false) {
		// get title and format in an orderly fashion
		echo self::get_AppsCMS_title($prefix, $suffix);
	}// prn_AppsCMS_title()

	public static function get_disclaimer_text() {
		$text = array();
		if(strlen(CMS_C_CUSTOM_FOOTER_LINK_NAME) > LM_C_MIN_NAME_LEN) {
			$text[] = '				<a href="' . ((strlen(CMS_C_CUSTOM_FOOTER_LINK) > LM_C_MIN_NAME_LEN) ? CMS_C_CUSTOM_FOOTER_LINK:'index.php?cms_action=disclaimer') . '"';
			$text[] = '					' . ((strlen(CMS_C_CUSTOM_FOOTER_LINK_TITLE) > LM_C_MIN_NAME_LEN) ? ' title="' . CMS_C_CUSTOM_FOOTER_LINK_TITLE . '"':'');
			$text[] = '					onclick="Ccms_cursor.setWait();"';
			$text[] = '					>';
			$text[] = '					<strong>' . CMS_C_CUSTOM_FOOTER_LINK_NAME . '</strong>';
			$text[] = '				</a>';
			} // if
		else $text[] = '&nbsp;';
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_disclaimer_text()

	public static function get_apps_manual_text() {
		if((file_exists(APPS_FS_APPS_MANUAL)) && (is_readable(APPS_FS_APPS_MANUAL))) {
			return APPS_FS_APPS_MANUAL;
			} // if
		return '';
		} // get_apps_manual_text()

	protected static function get_chk_legal_link_text($link) {
		if(strlen($link) < LM_C_MIN_NAME_LEN) return false;
		$uri = $link;	// to start
		if(!file_exists($uri)) $uri = ETC_WS_EXT_INCLUDES_DIR . $link;
		else if(!file_exists($uri)) {
			self::addMsg('Failed to read "' . $link . '".');
			return false;
			} // if
		return $uri;
		} // get_chk_legal_link_text()

	public static function get_release_notes_text() {
		return self::get_chk_legal_link_text(CMS_C_RELEASENOTES_LINK);
		} // get_release_notes_text()

	public static function get_readme_text() {
		return self::get_chk_legal_link_text(CMS_C_README_LINK);
		} // get_readme_text()

	public static function get_cookie_text() {
		return self::get_chk_legal_link_text(CMS_C_COOKIE_POLICY_LINK);
		} // get_cookie_text()

	public static function get_terms_text() {
		return self::get_chk_legal_link_text(CMS_C_TERMS_LINK);
		} // get_terms_text()

	public static function get_licence_text() {
		return self::get_chk_legal_link_text(CMS_C_LICENCE_LINK);
		} // get_licence_text()

	public static function &get_releasenotes_terms_licence_ack_uris() {
		if(self::$cms_tla) return self::$cms_tla;	// do once
		$tla = array(
			'body_id' => self::$cms_body_id,
			'tool_id' => self::$cms_tool_id,
			'h1' => false,
			'readme' => false,
			'release_notes' => false,
			'app_manual' => false,
			'apps_manual' => false,
			'eula' => (CMS_C_EULA_ENABLE ? CMS_C_EULA_LINK:false),
			'eula_upfirst' => CMS_C_EULA_ENABLE,	// for cms to manage
			'eula_show' => Ccms_auth::is_eula_agreement_required(),	// for cms to manage
			'terms' => false,
			'terms_upfirst' => false,	// for apps to manage
			'terms_show' => false,	// for apps to manage
			'licence' => false,
			'acknowledgement' => false,
			'cookies' => self::get_cookie_text(),
			'html' => false,
			'version' => false,
			);
		if($tla['body_id']) {
			$tla['h1'] = self::get_body_elem_h1($tla['body_id']);
			$tla['readme'] = self::get_body_readme_uri($tla['body_id'],false);
			$tla['release_notes'] = self::get_body_release_notes_uri($tla['body_id'],false);
			$tla['app_manual'] = self::get_body_manual_uri($tla['body_id'],false);
			$tla['terms'] = self::get_body_terms_uri($tla['body_id'],false);
			$tla['terms_upfirst'] = self::get_body_terms_upfirst($tla['body_id']);
			$tla['terms_show'] = self::is_body_terms2show($tla['body_id']);	// for apps to manage
			$tla['licence'] = self::get_body_licence_uri($tla['body_id'],false);
			$tla['acknowledgement'] = self::get_body_acknowledgment_uri($tla['body_id'],false);
			$tla['version'] = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_version', "cms_body_id = " . $tla['body_id']);
			} // if
		else if($tla['tool_id']) {
			$tla['h1'] = self::get_tool_elem_h1($tla['body_id']);
			$tla['readme'] = self::get_tool_readme_uri($tla['tool_id'],false);
			$tla['release_notes'] = self::get_tool_release_notes_uri($tla['tool_id'],false);
			$tla['terms'] = self::get_tool_terms_uri($tla['tool_id'],false);
			$tla['terms_upfirst'] = self::get_tool_terms_upfirst($tla['body_id']);
			$tla['terms_show'] = self::is_tool_terms2show($tla['body_id']);	// for apps to manage
			$tla['licence'] = self::get_tool_licence_uri($tla['tool_id'],false);
			$tla['acknowledgement'] = self::get_tool_acknowledgment_uri($tla['tool_id'],false);
			$tla['version'] = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_version', "cms_tool_id = " . $tla['tool_id']);
			} // else if
		else {	// get site docs
			$tla['readme'] = self::get_readme_text();
			$tla['release_notes'] = self::get_release_notes_text();
			$tla['apps_manual'] = self::get_apps_manual_text();
			$tla['terms'] = self::get_terms_text();
			$tla['licence'] = self::get_licence_text();
			$tla['version'] = CMS_C_APPS_MAJOR_VERSION;
			} // else
		$bt_uri ='';
		if($tla['body_id']) $bt_uri = '?app=' . $tla['body_id'] . '&action=';
		else if($tla['tool_id']) $bt_uri = '?tool_id=' . $tla['tool_id'] . '&cms_action=';
		else $bt_uri = '?cms_action=';
		$text = array();
		if(!empty($tla['eula'])) $text[] = '<a href="index.php?cms_action=get_eula">EULA</a>';
		if(!empty($tla['cookies'])) $text[] = '<a href="index.php?cms_action=cookies">Cookies</a>';
		if(!empty($tla['terms'])) $text[] = '<a href="index.php' . $bt_uri . 'terms">Terms</a>';
		if(!empty($tla['licence'])) $text[] = '<a href="index.php' . $bt_uri . 'licence">Licence</a>';
		if(!empty($tla['acknowledgement'])) $text[] = '<a href="index.php' . $bt_uri . 'acknowledgement">Acknowledgement</a>';
		if(self::is_group_manager()) {
			if(!empty($tla['release_notes'])) $text[] = '<a href="index.php' . $bt_uri . 'release_notes">Release Notes</a>';
			if(!empty($tla['apps_manual'])) $text[] = '<a href="index.php?cms_action=apps_manual" target="_blank">Manual</a>';
			if(!empty($tla['app_manual'])) $text[] = '<a href="index.php?app=' . $tla['body_id'] . '&cms_action=app_manual" target="_blank">Manual</a>';
			if(!empty($tla['readme'])) $text[] = '<a href="index.php' . $bt_uri . 'readme">Read Me</a>';
			} // if
		if(!empty($tla['version'])) $text[] = ' Version: <i>' . $tla['version'] . '</i>';
		if(!empty($text)) $tla['html'] = PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		self::$cms_tla = $tla;
		return self::$cms_tla;
		} // get_releasenotes_terms_licence_ack_uris()

	public static function chk_ob_buffer($all = false) {
		if(((Ccms::is_debug()) || ($all)) &&
			($tstat = ob_get_status(true))) {
			$terr = ob_get_contents();	// ob_get_clean();
			$text = PHP_EOL . 'OBstat:' . PHP_EOL . print_r($tstat,true) . PHP_EOL;
			$text .= PHP_EOL . 'OBstat:' . PHP_EOL . print_r($terr,true) . PHP_EOL;
			return $text;
			} // if
		return '';
		} // chk_ob_buffer()

} // Ccms_sm
