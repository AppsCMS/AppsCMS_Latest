<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_wysiwyg.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description
 * cms_wysiwyg functions
 *
 * @author robert0609
 */

class Ccms_wysiwyg extends Ccms_base {

	protected static $wysiwyg_name = '';
	protected static $wysiwygs = false;
	protected static $wysiwyg_ary = array(
		'title' => '',
		'type' => '',
		'comment' => '',
		'library_uri' => '',
		'engage_class' => '',
		'engage_uri' => '',
		'library_uri' => '',
		'configurable' => true,
		'enabled' => false,
		);
	protected static $wysiwyg_msg_ary = array(
		'title' => 'Title for WYSIWYG (not the name).',
		'type' => 'Type of WYSIWYG, select from browser, system, library or custom.',
		'comment' => "A general comment about the WYSIWYG.",
		'library_uri' => 'An initialisation URI (typically javascript, php, etc.) to setup the WYSIWYG (provided by WYSIWYG).',
		'engage_class' => 'WYSIWYG engagement class. Used to extend the ' . CMS_PROJECT_SHORTNAME . ' base WYSIWYG class for more customisation.',
		'engage_uri' => 'The URI (typically javascript, php, etc.) to engage the WYSIWYG (usually a custom script).',
		'configurable' => 'Boolean true/false value to indicate the WYSIWYG in configurable.',
		'enabled' => 'Boolean true/false to indicate whether the WYSIWYG is enabled',
		);
	private static $class_inuse = false;	// WYSIWGY class in use
	protected static $js_done = false;	// once only
	protected static $lib_done = false;	// once only
	protected $edit_body_text = '';	// buffer

	function __construct() {
		parent::__construct();
	} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// methods
	protected static function chk_wysiwyg_uri($uri) {
		if(empty($uri)) return false;
		if($res = self::get_chk_url($uri)) return $res;	// could have redirects
		$l_path = DOCROOT_FS_BASE_DIR . $uri;
		if((file_exists($l_path)) && (is_readable($l_path))) return $l_path;
		return false;
		} // chk_wysiwyg_uri()

	public static function get_wysiwygs($addMsg = false) {
		if(self::$wysiwygs === false) {
			$wysiwygs = &self::$wysiwygs;	// turn it into a useable array
			$wysiwygs = array(
				'None' => array(	// add the textarea browser text editor
					'title' => 'Nil WYSIWYG used',
					'type' => 'Browser',
					'comment' => 'Uses the inbuilt web browser textarea editor.',
					'library_uri' => '',
					"engage_class" => "",
					'engage_uri' => '',
					'configurable' => false,
					'enabled' => true,
					),
				);
			$ws_inbuilt = array(	// same as example_cms.wysiwyg.ini
				'TinyMCE4-System' => array (
					'title' => 'Use TinyMCE',
					'type' => 'System',
					'comment' => "Installed on the host server from the EPEL6 and EPEL7 LINUX rpm repositories.",
					'library_uri' => 'tinymce/tinymce.js',
					"engage_class" => "",
					'engage_uri' => CMS_WS_EXAMPLES_DIR . "tinyMCE_engage.js",	// see cms/examples/tinyMCE_engage.js
					'configurable' => true,
					'enabled' => true,
					),
				"Quill-Library" => array(
					"name" => "Use Quill",
					"title" => "Quill 1.3.6 WYSIWYG",
					"type" => "Library",
					"comment" => "Quill - very simple WYSIWYG installed as part of the " . CMS_PROJECT_SHORTNAME . " libraries.",
					"library_uri" => CMS_WS_LIB_DIR . "quill-1.3.7/quill.js",
					"engage_class" => CMS_WS_LIB_DIR . "quill.php",
					"engage_uri" => CMS_WS_LIB_DIR . "quill_engage.php",
					"configurable" => true,
					"enabled" => true,
					),
				"CKeditor" => array(
					"name" => "CKeditor",
					"title" => "Full featured WYSIWYG rich text editor.",
					"type" => "Library",
					"comment" => "Ckeditor V4.16.0 (requires internet access)",
					"library_uri" => "",
					"engage_class" => "",
					"engage_uri" => CMS_WS_LIB_DIR . "ckeditor/ckeditor_engage.php",
					"configurable" => true,
					"enabled" => true
					),
				);

			if(file_exists(ETC_FS_CMS_WYSIWYGS)) {
				$ws = self::load_json(ETC_FS_CMS_WYSIWYGS);
				foreach($ws_inbuilt as $n => &$w) {	// add missing inbuild wysiwygs
					if(empty($ws[$n])) $ws[$n] = $w;
					} // foreach
				} // if
			else {
				self::log_msg('Using default WYSIWYG config JSON.','warning');
				$ws = $ws_inbuilt;
				} // else
			if(isset($ws['None'])) unset($ws['None']);	// replace with new (maybe) 'None'
			$wysiwygs = array_merge($wysiwygs,$ws);
			if(!file_exists(ETC_FS_CMS_WYSIWYGS)) {
				self::save_json(ETC_FS_CMS_WYSIWYGS, $wysiwygs);
				} // if

			foreach($wysiwygs as $n => &$v) {
				if(empty($v)) continue;
				if((!is_array($v)) ||
					(preg_match('/^_|^\./i',$n))) {
					unset($wysiwygs[$n]);
					continue;	// system value
					} // if
				$v = array_merge(self::$wysiwyg_ary,$v);	// merge to add missing values
//				if(!preg_match('/^none/i',$n)) {
//					if(!self::chk_wysiwyg_uri($v['library_uri'])) {
//						$v['enabled'] = false;
//						if(($addMsg) && ((self::is_debug()) || (self::is_group_manager())))
//							self::addMsg($n . ": library_uri failed to connect.",'warn');
//						continue;
//						} // if
//					if(!self::chk_wysiwyg_uri($v['engage_uri'])) {
//						$v['enabled'] = false;
//						if(($addMsg) && ((self::is_debug()) || (self::is_group_manager())))
//							self::addMsg($n . ": engage_uri failed to connect.",'warn');
//						continue;
//						} // if
//					} // if
				} // foreach
			} // if
		if((defined('CMS_C_WYSIWYG_EDITOR')) &&
			(empty($wysiwyg_name)) &&
			(empty(self::$wysiwyg_name))) {
			$wysiwyg_name = CMS_C_WYSIWYG_EDITOR;
			self::$wysiwyg_name = $wysiwyg_name;	// save it
			} // if
		else if(!empty($wysiwyg_name)) self::$wysiwyg_name = $wysiwyg_name;
		if((!isset(self::$wysiwygs[$wysiwyg_name]['enabled'])) ||
			(!self::$wysiwygs[$wysiwyg_name]['enabled']) ||
			(!Ccms::is_wysiwyg_allowed())) {
			self::$wysiwyg_name = 'None';
			} // if
		return self::$wysiwygs;
		} // get_wysiwygs()

	public static function is_wysiwyg_available($name = false) {
		if(self::$wysiwygs === false) self::get_wysiwygs(true);
		if(empty($name)) $name = CMS_C_WYSIWYG_EDITOR;
		return (isset(self::$wysiwygs[$name]['enabled']) ? self::$wysiwygs[$name]['enabled']:false);
		} // is_wysiwyg_available()

	protected function init($wysiwyg_name = '') {
		self::get_wysiwygs($wysiwyg_name);
		return self::$wysiwyg_name;
	} // init()

	public function get_wysiwyg_title() {
		if(self::$wysiwygs === false) self::get_wysiwygs();
		return self::$wysiwygs[self::$wysiwyg_name]['title'];
		} // get_wysiwyg_title()

	public function get_wysiwyg_library() {
		if(self::$lib_done) return '';
		self::$lib_done = true;
		$w = &self::$wysiwygs[self::$wysiwyg_name];
		$library_url = self::chk_wysiwyg_uri($w['library_uri']);
		if(!$library_url) return $this->get_wysiwyg_ctl_js();
		$text = self::get_wysiwyg_uri_text($library_url);
		$text .= $this->get_wysiwyg_ctl_js();
		return $text;
		} // get_wysiwyg_library()

	public function get_wysiwyg_engage() {
		$w = &self::$wysiwygs[self::$wysiwyg_name];
		$eng_url = self::chk_wysiwyg_uri($w['engage_uri']);
		if(empty($eng_url)) return '';
		$text = self::get_wysiwyg_uri_text($eng_url);
		return $text;
		} // get_wysiwyg_engage()

	public function get_edit_body_text() {
		return $this->edit_body_text;
		} // get_edit_body_text()

	public function output_edit_text($body_text) {
		$this->edit_body_text = $body_text;
		$text = PHP_EOL;
		$text .= '<textarea id="ws_body_text" name="ws_text_area" style="width: 100%; height: 1024px;">' . PHP_EOL;
		$text .= htmlentities($this->edit_body_text) . PHP_EOL;
		$text .= '</textarea>' . PHP_EOL;
		$text .= $this->get_wysiwyg_engage() . PHP_EOL;
		return $text;
		} // output_edit_text()

	public function input_edit_text(&$cms_body_file) {
		$text = self::get_or_post('wysiwyg_data',false);
		if(!empty($text)) return self::get_pretty_html_doc($text);
		$text = self::get_or_post('ws_text_area',false);
		if(preg_match('/\.htm$|\.html$/i',$cms_body_file)) {
			$text = html_entity_decode(self::get_or_post('ws_text_area'),ENT_COMPAT,CMS_S_CHAR_SET);
			$text = self::sanitiseText4Html($text,true,false);	// make sane
			$text = self::reformat_code($text);
			$text = self::get_pretty_html_doc($text);
			} // if
		else if((preg_match('/\.php$/i',$cms_body_file)) &&
			(Ccms::is_get_or_post('ws_text_area'))) {
			$text = self::get_or_post('ws_text_area');
			// $text = preg_replace('/\\([\'\"])/','$1',$text);
			// $text = str_replace("\\'", "'", $text);
			// $text = str_replace('\"', '"', $text);
			$text = str_replace('"\\\n"', 'PHP_EOL', $text);
			} // if
		else {	// treat as plain text
			$text = self::get_or_post('ws_text_area');
			} // else
//		if(!preg_match('/\<\?php|\.php|\?\>/',$text)) {	// dont sanitise php code !!!!
//			$text = self::sanitiseText4Html($text);	// make sane
//			$text = self::reformat_code($text);
//			} // if
		return $text;
		} // input_edit_text()

	protected function get_wysiwyg_ctl_js() {
		if(self::$js_done) return '';
		self::$js_done = true;
		$text = <<<EOTJS

	<script type="text/javascript">
		function cms_getTextArea2View() {	// get text area text and decode
			if (typeof get_ws_html_area === 'function') {
				// some WYSIWGYs have different editor styles
				var html = get_ws_html_area();
				var elem_v = document.getElementById('ws_text_view');
				if(elem_v) {
					elem_v.innerHTML = html;
					} // if
				return;
				} // if
			if (typeof get_ws_text_area === 'function') {
				// some WYSIWGYs have different editor styles
				var txt = get_ws_text_area();
				var elem_v = document.getElementById('ws_text_view');
				if(elem_v) {
					elem_v.innerText = txt;
					} // if
				return;
				} // if
			var elem_a = document.getElementById('ws_text_area');
			var elem_v = document.getElementById('ws_text_view');
			if((!elem_a) || (!elem_v)) return;	// why
			if (typeof elem_a.value !== 'undefined') {
				var txt = elem_a.value;
				var view_txt = cms_html_entity_decode(txt);
				if(view_txt.match(/\<\?|\?\>/g)) {
					elem_v.innerText = view_txt;
					} // if
				else {
					elem_v.innerHTML = view_txt;
					} // else
				} // if
			else elem_v.innerHTML = elem_a.innerHTML;
			} // cms_getTextArea2View()

		function cms_hideDisplayID(id) {
			if(typeof document.getElementById(id) === 'undefined') return;
			var elem = document.getElementById(id);
			if(!elem) return;
			elem.style.display = 'none';
			} // cms_hideDisplayID()

		function cms_showDisplayID(id) {
			if(typeof document.getElementById(id) === 'undefined') return;
			var elem = document.getElementById(id);
			if(!elem) return;
			elem.style.display = 'block';
			} // cms_showDisplayID()

		function cms_setView(id) {
			switch(id) {
				default:
				case 'ws_config':
					cms_showDisplayID('ws_config');
					cms_hideDisplayID('ws_text_input');
					cms_hideDisplayID('ws_text_view_blk');
					break;
				case 'ws_text_input':
					cms_hideDisplayID('ws_config');
					cms_showDisplayID('ws_text_input');
					cms_hideDisplayID('ws_text_view_blk');
					break;
				case 'ws_text_view':
					cms_hideDisplayID('ws_config');
					cms_hideDisplayID('ws_text_input');
					cms_showDisplayID('ws_text_view_blk');
					cms_getTextArea2View();	// get text area text and decode
					break;
				} // switch
			return;
			} // cms_setView()

		function cms_ws_onsubmit(event,obj,id) {
			var hid_v = document.getElementById(id);
			if(!hid_v) return true;	// post data has wysiwyg data
			var val = '';
			if (typeof get_ws_html_area === 'function') {
				// some WYSIWGYs have different editor styles
				val = get_ws_html_area();
				} // if
			else if (typeof get_ws_text_area === 'function') {
				// some WYSIWGYs have different editor styles
				val = get_ws_text_area();
				} // else if
			else {	// get standard textarea data
				var ws_v = document.getElementById('ws_text_area');
				val = ws_v.value;
				} // else
			if(hid_v) hid_v.value = val;
			return true;
			} // cms_ws_onsubmit()

	</script>

EOTJS;

		return $text;
	} // get_wysiwyg_ctl_js()

// static methods
	public static function &get_wysiwyg_class() {
		if(self::$wysiwygs === false) self::get_wysiwygs();
		$w = &self::$wysiwygs[self::$wysiwyg_name];
		$eng_class = self::chk_wysiwyg_uri($w['engage_class']);
		if(empty($eng_class)) {
			self::$class_inuse = new Ccms_wysiwyg();	// only me
			return self::$class_inuse;	// only me
			} // if
		ob_start();
		include_once($eng_class);
		$class = ob_get_clean();
		if((empty($class)) || (!class_exists($class))) {
			$class = preg_replace('/^.*class\s+(\w+)\s+.*$/','\1',file_get_contents($eng_class));
			} // if
		if((empty($class)) || (!class_exists($class))) {
			self::$class_inuse = new Ccms_wysiwyg();	// only me again again
			return self::$class_inuse;	// only me again again
			} // if
		self::$class_inuse = new $class();	// howdy
		return self::$class_inuse;	// howdy
		} // get_wysiwyg_class()

	public static function get_wysiwyg_descriptions() {
		if(self::$wysiwygs === false) self::get_wysiwygs();
		$text = '';
		foreach(self::$wysiwygs as $n => $v) {
			if(!isset($v['enabled'])) $v['enabled'] = false;
			$text .= '<p>';
			$text .= '<b>' . $n . '</b>' . ' - ' . $v['title'] . (!$v['enabled'] ? ' (disabled)':'') . '<br>';
			$text .= 'Type: ' . $v['type'] . '.</br>';
			$text .= $v['comment'];
			$text .= '</p>' . PHP_EOL;
			} // foreach
		return $text;
		} // get_wysiwyg_descriptions()

	protected static function get_wysiwyg_uri_text($uri) {
		// is it JS link or PHP include
		static $here = false;
		$text = '';
		if(preg_match('/.*\.(js|css)$/i',$uri)) {	// JS link
			$uri = str_replace(DOCROOT_FS_BASE_DIR,'',$uri);	// why, permission error ??
			$text .= '<script type="text/javascript" src="' . $uri . '"></script>' . PHP_EOL;
			} // if
		else if((is_readable($uri)) &&
			(preg_match('/.*\.php$/i',$uri))) {	// PHP include
			if($here) {
				self::addAdminMsg('Already in get_wysiwyg_uri_text ob_start().');
				return 'ob_start error.';
				} // if
			$here = true;
			ob_start();
			include($uri);
			$text .= PHP_EOL . ob_get_clean() . PHP_EOL;
			$here = false;
			} // else if
		else {
			$text .= PHP_EOL . file_get_contents($uri) . PHP_EOL;
			} // else
		return $text;
		} // get_wysiwyg_uri_text)

	public static function reformat_code($html, $frameable = false) {
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = true;
		if(!@$dom->loadHTML($html)) return $html;	// probably has code in it.
		$dom->formatOutput = TRUE;
		$text = $dom->saveHTML();
		if(!$frameable) {	// this a hack (not sure it is worth it for pretty code)
			// $lines = preg_split('/\n/',$text);
			$lines = explode(PHP_EOL,$text);
			$cnt = count($lines);
			while(empty($lines[($cnt - 1)])) {	// remove empty lines at end
				unset($lines[($cnt - 1)]);	// remove
				$cnt--;
				} // while
			unset($lines[($cnt - 1)]);	// </body></html> at end
			unset($lines[1]);	// <html><body> on line 2
			unset($lines[0]);	// <DOCTYPE on line 1
			$text = implode(PHP_EOL,$lines);
			} // if
		if(strlen($text) < 8) return $html;
		return $text;
		} // reformat_code()

	public static function input_wysiwyg($name,$value = '') {	// make a select drop boxes for available WYSIWYGs
		$text = '';
		$wsyiwygs = Ccms_wysiwyg::get_wysiwygs();

		$text .= '<select name="' . $name . '">';
		$text .= '	<option value="-1"> -- Select WYSIWYG -- </option>';
		// $text .= '	<option value="None"' . (('None' == $value) ? ' SELECTED':'') . '>None</option>';
		foreach($wsyiwygs as $n => $v) {
			if(!isset($v['enabled'])) continue;	// now a JSON
			// if(!$v['enabled']) continue;
			$text .= '	<option value="' . $n . '"' . (($n == $value) ? ' SELECTED':'') . ' title="' . $v['comment'] . '">' . strip_tags($n) . ($v['enabled'] ? '':' (disabled)') . '</option>';
			} // foreach
		$text .= '</select>' . PHP_EOL;
		return $text;
		} // input_wysiwyg()

	public static function config_wysiwygs($current) {
		if(self::$wysiwygs === false) self::get_wysiwygs();
		$text = '';
		$text =<<< EOTTXT1
			<table class="page_config" style="width: 98%;>
				<tr class="page_config">
					<th class="page_config" style="text-align: left;">Configurable WYSIWYGs:</th>
					<td class="page_config" style="text-align: left;">
						Refer to <a href="index.php?cms_action=cms_manual#WYSIWYGs" target="_blank">Technical Manual</a> for more nformation.
					</td>
				</tr>
				<tr class="page_config">
					<td class="page_config" style="text-align: left;" colspan="2">
EOTTXT1;

		$cwv = self::$wysiwygs;	// add existing
		$cwv['New'] = self::$wysiwyg_ary;	// add a new empty
		foreach($cwv as $wn => $wv) {
			$cv = array_merge(self::$wysiwyg_ary,$wv);
			if(!$cv['configurable']) continue;
			$wnn = '';
			if(!preg_match('/^new$/i',$wn)) $wnn = $wn;
			$text .=<<< EOTCV1
					<table class="page_config" style="width: 98%;>
					<tr class="page_config">
						<th class="page_config" style="text-align: left;" title="WYSIWYG Name">{$wn}:</th>
EOTCV1;
			$text .= '<td class="page_config" style="text-align: left;">';
			$text .= '<input class="page_config" style="width: 120px;" type="text" name="wigs[' . $wn . '][name]" value="' . $wnn . '" title="Enter new name (leave empty to delete config).">';
			$text .= '</td></tr>' . PHP_EOL;

			foreach($cv as $l => $v) {
				if(!isset(self::$wysiwyg_msg_ary[$l])) continue;
				$text .= '<tr class="page_config">';
				$text .= '<th class="page_config" style="text-align: right; width: 120px;">' . $l . '</th>';
				$text .= '<td class="page_config" style="text-align: left;">';
				$title = ' title="' . self::$wysiwyg_msg_ary[$l] . '"';
				if(is_bool($v)) {
					$text .= '<input class="page_config" style="text-align: left;" type="checkbox" name="wigs[' . $wn . '][' . $l . ']" ' . ($v ? 'CHECKED':'') . $title . '>';
					} // if
				else if($l == 'type') {	// use a selector
					$types = array('Browser', 'System', 'Library', 'Custom');
					$text .= '<select name="wigs[' . $wn . '][' . $l . ']">';
					$text .= '	<option value="-1"> -- Select Type -- </option>';
					foreach($types as $tn) {
						$text .= '	<option value="' . $tn . '"' . (($tn == $v) ? ' SELECTED':'') . '>' . $tn . '</option>';
						} // foreach
					$text .= '</select>' . PHP_EOL;
					} // else if
				else {
					$text .= '<input class="page_config" style="width: 95%;" type="text" name="wigs[' . $wn . '][' . $l . ']" value="' . $v . '" ' . $title . '>';
					} // else
				$text .= '</td></tr>' . PHP_EOL;
				} // foreach

			$text .=<<< EOTCV2
				</table>
EOTCV2;
			} // foreach

		$text .=<<< EOTTXT2
					</td>
				</tr>
			</table>

EOTTXT2;

		return $text;
		} // config_wysiwygs()

	public static function save_wysiwyg_configs($wigs) {
		if(self::$wysiwygs === false) self::get_wysiwygs();
		$wysiwygs = &self::$wysiwygs;
		foreach($wigs as $wig => &$w) {
			// do checkboxes
			$w['configurable'] = (empty($w['configurable']) ? false:true);
			$w['enabled'] = (empty($w['enabled']) ? false:true);

			if(empty($w['name'])) {
				if(isset($wysiwygs[$wig]))	// delete wig
					unset($wysiwygs[$wig]);
				continue;
				} // if
			if($wig == 'New') {
				if(!empty($w['name'])) {	// new
					$wysiwygs[($w['name'])] = $w;
					} // if
				continue;
				} // if
			// else
			if(isset($wysiwygs[$wig]))	// replace wig
				unset($wysiwygs[$wig]);
			$wysiwygs[($w['name'])] = $w;
			} // foreach
		return self::save_json(ETC_FS_CMS_WYSIWYGS, $wysiwygs);
		} // save_wysiwyg_configs()


} // Ccms_wysiwyg
