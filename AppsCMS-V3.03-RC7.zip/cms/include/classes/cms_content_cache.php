<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_content_cache.php 2909 2022-10-24 07:34:08Z robert0609 $
 */

/**
 * Description of cms_cache
 * controls and caches static output
 * mostly from include files
 * to provide faster operation of AppsCMS functionality
 * e.g. menu bars, nav bars, drop boxes, selectors, etc.
 *
 * @author robert0609
 */

class Ccms_content_cache extends Ccms_base {

	protected static $cached_content_files = false;

	const CONTENTS_CACHE_EXTENSION = 'contents_cache';	// filename extension used contents cache in the CMS_WS_CONTENT_CACHE_DIR directory

	function __construct() {
		// parent::__construct();
		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

// static methods
	private static function init() {
		if(self::$cached_content_files) return;
		self::$cached_content_files = array(
			// list of content generating files that can be cached
			CMS_FS_INCLUDES_DIR . "cms_page_header.php",
			CMS_FS_INCLUDES_DIR . "cms_page_left_column.php",
			CMS_FS_INCLUDES_DIR . "cms_page_right_column.php",
			CMS_FS_INCLUDES_DIR . "cms_page_nav_bar.php",
			CMS_FS_INCLUDES_DIR . "cms_page_footer.php",
			CMS_FS_OPS_DIR . "cms_about.php",
			CMS_FS_OPS_DIR . "cms_manual.php",
			CMS_FS_OPS_DIR . "cms_disclaimer.tmpl.php",
			CMS_FS_OPS_DIR . "cms_no_cookie.php",
			// user cached files added here
			);
		} // init()

	protected static function is_content_cache_used() {
		if(!defined('CMS_S_CONTENT_CACHE_ENABLE_BOOL')) return false;	// here during rebuilds and upgrades
		if(!CMS_S_CONTENT_CACHE_ENABLE_BOOL) return false;
		if(!self::chkdir(VAR_FS_CACHE_CONTENTS_DIR)) return false;
		self::init();
		return true;
		} // is_content_cache_used()

	protected static function get_cache_dir($is_common_content = false) {
		if(!self::is_content_cache_used()) return false;
		if(!$is_common_content) {	// must be personalised
			$user = self::get_logged_in_username(null,true);
			$clnt_ip = Ccms_auth::get_client_ip_address();
			if(!empty($user)) {
				$cpath = self::clean_path(VAR_FS_CACHE_CONTENTS_DIR . '/' . $clnt_ip . '-' . $user . (!preg_match('/^guest/i',$user) ? '-' . session_id():'') . '/');
				if(self::chkdir($cpath)) return $cpath;
				} // if
			return false;
			} // if
		return self::chkdir(VAR_FS_CACHE_CONTENTS_DIR);
		} // get_cache_dir()

	private static function reset_caches_recurs($cpath,&$cnt,&$deleted,$recurs = true) {
		$ok = true;
		if(empty($cpath)) return $ok;
		$df = @scandir($cpath);
		if(empty($df)) return $ok;
		foreach($df as $f) {
			$path = self::clean_path($cpath . '/' . $f);
			if(is_dir($path)) {
				if(($recurs) && (!preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $f)))
					$ok &= self::reset_caches_recurs ($path, $cnt, $deleted);
				continue;
				} // if
			if(preg_match('/\.' . self::CONTENTS_CACHE_EXTENSION . '$/', $f)) {
				if(@unlink($path) !== false) {
					$deleted++;
					} // if
				else $ok = false;
				$cnt++;
				} // if
			} // foreach
		return $ok;
		} // reset_caches_recurs()

	public static function reset_caches($show_res = true,$clear_all = false) {
		$cnt = 0;
		$deleted = 0;
		if((self::is_rebuild()) || ($clear_all)) {
			$cpath = VAR_FS_CACHE_CONTENTS_DIR;
			$ok = self::reset_caches_recurs($cpath, $cnt, $deleted,true);
			Ccms_language::reset_language_caches();
			Ccms_translate_plugin::clean_translated();
			} // if
		else {
			$cpath = self::get_cache_dir();
			$ok = self::reset_caches_recurs($cpath, $cnt, $deleted,false);
			$ok = self::reset_caches_recurs($cpath, $cnt, $deleted);
			if(is_dir($cpath)) @rmdir($cpath);
			} // else
		if(!$ok) self::addMsg ('Failed to delete all cache files, deleted ' . $deleted . '/' . $cnt . '.');
		else if($show_res) self::addMsg ('Deleted ' . $deleted . ' cache files.','info');
		// Ccms_language::reset_language_caches();
		return $ok;
		} // reset_caches()

	protected static function is_cached_path($inc_file) {
		if(!self::is_content_cache_used()) return false;
		if(!in_array($inc_file, self::$cached_content_files)) return false;
		return true;
		} // is_cached_path()

	protected static function get_cache_path($inc_file, $is_common_content, $cache_it) {
		if(!$cache_it) return false;
		if(self::$cms_error_cnt > 0) return false;	// don't cache rubbish
		if(($is_common_content) && (!self::is_cached_path($inc_file))) return false;
		else if(!self::is_content_cache_used()) return false;
		if(!$cpath = self::get_cache_dir($is_common_content)) return false;
		if(self::is_debug()) $cache_path = $cpath . preg_replace('/[\/\.]/', '_', $inc_file);
		else $cache_path = $cpath . md5($inc_file);
		if(Ccms::is_tablet()) $cache_path .= '-tablet';
		else if(Ccms::is_tiny()) $cache_path .= '-tiny';
		$cache_path .= '.' . self::CONTENTS_CACHE_EXTENSION;
		return $cache_path;
		} // get_cache_path()

	public static function cache_content($inc_file, $is_common_content = false, $cache_it = false) {
		if(!is_readable($inc_file)) {	// source file not found.
			self::addMsg('Content cache failure. Cannot read "' . $inc_file . '".');
			return false;
			} // if
		$cache_path = self::get_cache_path($inc_file,$is_common_content, $cache_it);
		if(($cache_path === false) || (empty($cache_path))) {
			if((!$is_common_content) && ($langs = Ccms_language::get_body_lang_trans_codes($inc_file))) {	// returns true if translation required
				$text = Ccms_html::output_file_body_text($inc_file,true);
				echo Ccms_language::translate_body_html($text,$langs);	// non cached, translated output
				} // if
			else Ccms_html::output_file_body_text($inc_file);	// normal CMS_LANG_DEFAULT non cached output
			return false;	// not cached
			} // if
		// else cache it
		$now = time();
		$ctime = false;	// cache time
		if((self::is_mode_change()) ||
			(!is_readable($cache_path)) ||
			(!$ctime = filemtime($cache_path)) ||
			(((int)$now - (int)$ctime) > (int)CMS_S_CONTENT_CACHE_TTL)) {	// time diff is less then TTL
			// make cache file
			$text = Ccms_html::output_file_body_text($inc_file,true);
			if($langs = Ccms_language::get_body_lang_trans_codes($inc_file)) {	// returns true if translation required
				$text = Ccms_language::translate_body_html($text,$langs);
				} // if
			if(self::$cms_error_cnt > 0) {
				echo $text;
				self::addAdminMsg('Have ' . self::$cms_error_cnt . ' errors in: ' . basename($inc_file));
				return false;	// don't cache rubbish
				} // if
			if(self::file_safe_write($cache_path, $text) === false) {
				$errors = error_get_last();
				self::addMsg('Failed cache contents "' . basename($inc_file) . '". ' . $errors['message']);
				Ccms_html::output_file_body_text($inc_file);
				return false;
				} // if
			} // if
		// else already cached
		readfile($cache_path);	// cache ok to use
		return true;	// translated and cached output
		} // cache_content()

	public static function add_incfile2cache($inc_file) { // for apps include files
		if(!self::is_content_cache_used()) return false;
		if(in_array($inc_file, self::$cached_content_files)) return true;	// already there
		if(!is_readable($inc_file)) {	// source file not found.
			self::addMsg('Cannot add content file "' . $inc_file . '" to cache system.');
			return false;
			} // if
		self::$cached_content_files[] = $inc_file;
		return true;
		} // add_incfile2cache()

// dynamic methods

} // Ccms_content_cache

