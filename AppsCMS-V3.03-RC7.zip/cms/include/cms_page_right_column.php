<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_right_column.php 2819 2022-09-22 13:06:21Z robert0609 $
 */

if(!Ccms::show_right_column()) return;
	Ccms::page_start_comment(__FILE__);
?>
<!--	<div>-->
		<table class="right_container" style="min-height: 100%">
			<caption>Right Column</caption>
<?php
		$smtxt = Ccms::get_social_media('right_column_top');
		if(!empty($smtxt)) echo '<tr class="right_container"><td class="right_container">' . $smtxt . '</td></tr>' . PHP_EOL;

			$flgs = Ccms::get_column_layout('right_column','right_container');

?>
<?php		if((!$flgs['tool_menu_flg']) && (!$flgs['tools_items_flg']) &&
				(Ccms::get_tool_cnt() > 0)) { ?>
			<tr class="right_container">
				<td class="right_container">
					<?= Ccms::get_tools_menu('right_column') ?>
				</td>
			</tr>
<?php			} //if ?>
<?php		if((!$flgs['admin_menu_flg']) && 
				(Ccms_base::is_group_manager())) { ?>
			<tr class="right_container">
				<td class="right_container">
<?php				echo Ccms::get_admin_menu('right') ?>
				</td>
			</tr>
<?php			} // if ?>
<?php
		$smtxt = Ccms::get_social_media('right_column_bottom');
		if(!empty($smtxt)) echo '<tr class="right_container"><td class="right_container">' . $smtxt . '</td></tr>' . PHP_EOL;
?>
			<tr class="right_container">
				<td class="right_container" style="height: 100%;">&nbsp;</td>
			</tr>
		</table>
<!--	</div>-->
<?php
	Ccms::page_end_comment(__FILE__);
