<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_inline.php 2825 2022-10-05 10:31:21Z robert0609 $
 */

Ccms::page_start_comment(__FILE__);

?>
		
	<!--Inline Mode-->

	<div class="cms_lo_page_inline" id="cms_lo_page_inline">
	<table class="cms_lo_page_inline">
<?php if(CMS_S_HEADER_BOOL) { ?>
			<tr class="cms_lo_page_inline">
				<td class="cms_lo_header" id="cms_lo_header">
					<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_header.php',false,CMS_C_PAGE_HEADER_CACHED) ?>
				</td>
			</tr>
<?php	} // if ?>

<?php if(Ccms::show_nav_bar()) { ?>
			<tr class="cms_lo_page_inline">
				<td class="cms_lo_nav_bar" id="cms_lo_nav_bar">
				<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_nav_bar.php',false,CMS_C_NAVBAR_CACHED) ?>
				</td>
			</tr>
<?php	} // if ?>

			<tr class="cms_lo_page_inline">
				<td class="cms_lo_middle" id="cms_lo_middle">
					<table class="cms_lo_middle">
						<tr class="cms_lo_middle">
<?php	if(Ccms::show_left_column()) { ?>
							<td class="cms_lo_left_column" id="cms_lo_left_column">
								<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_left_column.php',true,CMS_C_LEFT_COLUMN_CACHED) ?>
							</td>
<?php		} // if ?>

							<td class="cms_lo_body_column" id="cms_lo_body_column"
								<?php echo (Ccms::is_drag_drop_used() ? ' ondragover="javascript:cms_drag_over(event);" ondrop="javascript:cms_drop(event);"':'') ?>>
								<?php include CMS_FS_INCLUDES_DIR . 'cms_page_body.php' ?>
							</td>

<?php	if(Ccms::show_right_column()) { ?>
							<td class="cms_lo_right_column" id="cms_lo_right_column">
								<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_right_column.php',true,CMS_C_RIGHT_COLUMN_CACHED) ?>
							</td>
<?php		} // if ?>
						</tr>
					</table>
				</td>
			</tr>

<?php	if(CMS_S_FOOTER_BOOL) { ?>
			<tr class="cms_lo_page_inline">
				<td class="cms_lo_footer" id="cms_lo_footer">
					<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_footer.php',false,CMS_C_PAGE_FOOTER_CACHED) ?>
				</td>
			</tr>
<?php		} // if ?>
		</table>
	</div>

<?php
Ccms::page_end_comment(__FILE__);
