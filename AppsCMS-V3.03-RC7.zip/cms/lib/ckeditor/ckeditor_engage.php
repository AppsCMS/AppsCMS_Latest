<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: ckeditor_engage.php 2786 2022-08-31 05:40:44Z robert0609 $
 *
 * see "https://ckeditor.com/docs/ckeditor4/latest/api/CKEDITOR_editor.html"
 */


?>
<script src="//cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>

<script type="text/javascript">

	CKEDITOR.editorConfig = function( config ) {
		config.autoGrow_onStartup = true;
		config.autoGrow_minHeight = 768;
		};

	CKEDITOR.replace( 'ws_body_text' );

</script>
