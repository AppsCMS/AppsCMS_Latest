PHP Packages in Applications Management System Library for PHP (AppsCMS) - README_PEAR.
=======================================================================================
<!-- _SVN_build: $Id: README_PEAR.md 2786 2022-08-31 05:40:44Z robert0609 $ -->
see Licence in each PEAR package directory

NOTES:
------

1. The PEAR packages are archive downloads from pear.php.net and not changed.
2. The prupose is to preserve PEAR packages used by AppsCMS and applications.
3. Only PEAR packages are present as they ar written in PHP, PECL packages are not present here as they are written in C.

Package Tree
------------

``
cms/lib/PEAR
├── Archive_Tar
│   └── Archive_Tar-1.4.14
├── Console_Getopt
│   └── Console_Getopt-1.4.3
├── Mail_Mime
│   └── Mail_Mime-1.10.11
├── Net_GeoIP
│   └── Net_GeoIP-1.0.0
├── Net_IMAP
│   └── Net_IMAP-1.1.3
├── Net_Socket
│   └── Net_Socket-1.2.2
├── PEAR
│   └── PEAR-1.10.13
├── PEAR_Manpages
│   └── PEAR_Manpages-1.10.0
├── Structures_Graph
│   └── Structures_Graph-1.1.1
└── XML_Util
    └── XML_Util-1.4.5

20 directories

``

.EOF.
