<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * Engage system installed tinyMCE WYSIWYG
 * from example in "https://quilljs.com/docs/"
 * _SVN_build: $Id: quill_init.php 2786 2022-08-31 05:40:44Z robert0609 $
 */
?>

<!-- highlight JS -->
<link rel="stylesheet" href="<?= CMS_WS_LIB_DIR ?>quill/highlight-default.min.css">
<script src="<?= CMS_WS_LIB_DIR ?>quill/highlight.min.js"></script>

<!-- Katex included JS -->
<script type="text/javascript" src="<?= CMS_WS_LIB_DIR ?>quill/katex.min.css"></script>
<script type="text/javascript" src="<?= CMS_WS_LIB_DIR ?>quill/katex.min.js"></script>

<!-- Main Quill library -->
<script type="text/javascript" src="<?= CMS_WS_LIB_DIR ?>quill/quill-1.3.7/quill.js"></script>
<!--<script type="text/javascript" src="<?= CMS_WS_LIB_DIR ?>quill/quill-1.3.7/quill.min.js"></script>-->

<!-- Theme included stylesheets -->
<link href="<?= CMS_WS_LIB_DIR ?>quill/quill-1.3.7/quill.snow.css" rel="stylesheet">
<link href="<?= CMS_WS_LIB_DIR ?>quill/quill-1.3.7/quill.bubble.css" rel="stylesheet">

<!-- Core build with no theme, formatting, non-essential modules -->
<!--<link href="<?= CMS_WS_LIB_DIR ?>quill/quill-1.3.7/quill.core.css" rel="stylesheet">-->
<!--<script type="text/javascript" src="<?= CMS_WS_LIB_DIR ?>quill/quill-1.3.7/quill.core.js"></script>-->

