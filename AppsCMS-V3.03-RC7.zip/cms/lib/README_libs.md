Applications Management System Library for PHP (AppsCMS) - README_libs.
=======================================================================
see Licence in cms/LICENCE.txt
<!-- _SVN_build: $Id: README_libs.md 2786 2022-08-31 05:40:44Z robert0609 $ -->

3rd Party Libraries.
--------------------

1. 3rd party libraries used by AppsCMS are placed in "cms/lib/" directory.
2. They are licenced by their respective authors (see the licence files in each library directory).
3 .The libraries have been selected for there ease of use, no required dependencies and simplicity.
4. In some cases the library requires custom values to be entered into code (e.g. directory locations).

Notes
-----

1. cms/include/ini/cms.libs2scan.ini is an index the classes included in AppsCMS index on rebuilds.

.EOF.
