/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
<?php // * _SVN_build: $Id: cms_styles_inline.css.php 2827 2022-10-05 13:45:55Z robert0609 $ ?>
 */

/*
	Document   : inline_styles
	Description:
		Purpose of the stylesheet follows.
		Inline styles, the header, body and footer are sequential top to bottom overflowing the browser window.
		<?= $gen_note ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

<?php

$margin = 0;

$lay_bound = 0;
if(CMS_S_DEBUG_BOOL && CMS_S_DEBUG_LAYOUT_BOOL) {
	$lay_bound = 4;	// border width
	
// see "https://www.w3schools.com/tags/ref_colornames.asp" for colour names
	
?>

/* layout boundary debugging on */
div.cms_lo_page_inline { border: <?= $lay_bound ?>px dotted red; }
td.cms_lo_header { border: <?= $lay_bound ?>px dotted yellow; }
td.cms_lo_nav_bar { border: <?= $lay_bound ?>px dotted blue; }
td.cms_lo_middle { border: <?= $lay_bound ?>px dotted cyan; }
td.cms_lo_left_column { border: <?= $lay_bound ?>px dotted green; }
td.cms_lo_body_column { border: <?= $lay_bound ?>px dotted grey; }
td.cms_lo_right_column { border: <?= $lay_bound ?>px dotted brown; }
td.cms_lo_footer { border: <?= $lay_bound ?>px dotted orange; }

<?php	
	} // if

$sects = 0;

if($theme['ThemeSettings']['HEADER_BOOL'] == 'true') {
	$sects++;
	$header_height = (int)preg_replace('/[a-z]*$/i', '',$theme['ThemeSettings']['HEADER_HEIGHT']);
	} // if
else $header_height = 0;

if($theme['ThemeSettings']['NAV_BAR_BOOL'] == 'true') {
	$sects++;
	$nav_bar_height = (int)preg_replace('/[a-z]*$/i', '',$theme['ThemeSettings']['NAV_BAR_HEIGHT']);
	} // if
else $nav_bar_height = 0;

if($theme['ThemeSettings']['FOOTER_BOOL'] == 'true') {
	$sects++;
	$footer_height = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['FOOTER_HEIGHT']);
	} // if
else $footer_height = 0;

if($theme['ThemeSettings']['LEFT_COLUMN_BOOL'] == 'true')
	$left_column_width = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['LEFT_WIDTH']);
else $left_column_width = 0;

if(($theme['ThemeSettings']['RIGHT_COLUMN_BOOL'] == 'true') && 
	($theme['ThemeSettings']['LEFT_COLUMN_BOOL'] == 'true'))
	$right_column_width = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['RIGHT_WIDTH']);
else $right_column_width = 0;

$sect_gap = ($lay_bound + $margin) * 2;
$hnf = ($header_height + $nav_bar_height + $footer_height + ($sect_gap * ($sects + $sects)));

?>
/* section gap = <?= $sect_gap ?> */

/* the inline layout */
div.cms_lo_page_inline {
	}

	td.cms_lo_header {
		position: relative;
		top: 0px;
		height: <?= $header_height ?>px;
		width: 100%;
		/*overflow: auto;*/
		}
	td.cms_lo_nav_bar {
<?php if($theme['ThemeSettings']['NAV_BAR_STICKY_BOOL'] == 'true') { ?>
		position: -webkit-sticky;
		position: sticky;
		top:	2px;
		z-index:	250;
<?php	} else { ?>
		position: relative;
		top: 0px; 
<?php	} // else ?>
		height: <?= $nav_bar_height ?>px;
		width:	100%;
		margin: 0px;
		/*overflow: auto;*/
		}
	td.cms_lo_nav_bar:hover {
		overflow: unset;
		z-index: 1000;
		}

	td.cms_lo_middle {
		position: relative;
		top: 0px; 
		vertical-align: top;
		width: 100%;
		height: calc(100vh - <?= $hnf ?>px);
		/*overflow: auto;*/
		}

		td.cms_lo_left_column {
			background-color: <?= $theme['ThemeSettings']['LEFT_BKGD_COLOUR'] ?>;
			color:		<?= $theme['ThemeSettings']['LEFT_FONT_COLOUR'] ?>;
			border:		<?= $theme['ThemeSettings']['LEFT_BORDER'] ?>;
			position: relative;
			left: 0px;
			vertical-align: top;
			width: <?= $left_column_width ?>px;
			height: calc(100vh - <?= $hnf ?>px);
			/*overflow: auto;*/
			}
		td.cms_lo_body_column {
<?php if(!empty($theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE'])) { ?>
			background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']) ?>;
			background-repeat: no-repeat;
			background-attachment: local;
			background-size: 100% 100%;
<?php } else { ?>
			background-color: <?= $theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'] ?>;
<?php } // else ?>
			border:		<?= $theme['ThemeSettings']['PAGE_BODY_BORDER'] ?>;
			color:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR'] ?>;
			position: relative;
			left: 0px;
			right: 0px;
			vertical-align: top;
			/*width: 100%;*/
			height: calc(100vh - <?= $hnf ?>px);
			/*overflow: auto;*/
			}
		td.cms_lo_right_column {
			background-color: <?= $theme['ThemeSettings']['RIGHT_BKGD_COLOUR'] ?>;
			color:		<?= $theme['ThemeSettings']['RIGHT_FONT_COLOUR'] ?>;
			border:		<?= $theme['ThemeSettings']['RIGHT_BORDER'] ?>;
			position: relative;
			right: 0px;
			width: <?= $right_column_width ?>px;
			height: calc(100vh - <?= $hnf ?>px);
			vertical-align: top;
			/*overflow: auto;*/
			}

	td.cms_lo_footer {
		position: relative;
		/*bottom: 0px;*/
		width: 100%;
		height: <?= $footer_height ?>px;
		/*overflow: auto;*/
		}

#lm_link_frame {
	z-index:	3;
	width:		100%;
	}

.link_frame_moz {
	/*min-height: calc(100vh - <?= $hnf ?>px);*/
	}
.link_frame_tablet {
	/*min-height: calc(100vh - <?= $hnf ?>px);*/
	}

.iframe_tablet {
	max-width:		100%;
	border-width: 0;
	min-height: calc(100vh - <?= $hnf ?>px);

	}
.iframe_moz {	/* must be inside a relative position container */
	border: 0;
	width: 100%;
	min-height: calc(100vh - <?= $hnf ?>px);
	}

/* eof */

