/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
<?php // * _SVN_build: $Id: cms_styles_block.css.php 2831 2022-10-07 23:42:28Z robert0609 $ ?>
 */

/*
	Document   : main_styles
    Description:
        Purpose of the stylesheet follows.
		Block styles, keep the header and footer at top and bottom of the browser window.
		<?= $gen_note ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/
<?php

$pad = 0;
$margin = 1;

$lay_bound = 0;
if(CMS_S_DEBUG_BOOL && CMS_S_DEBUG_LAYOUT_BOOL) {
	$lay_bound = 5;	// border width
	
// see "https://www.w3schools.com/tags/ref_colornames.asp" for colour names
	
?>

/* layout boundary debugging on */
div.cms_lo_page_block { border: <?= $lay_bound ?>px dotted chartreuse; }
td.cms_lo_header { border: <?= $lay_bound ?>px dotted yellow; }
td.cms_lo_nav_bar { border: <?= $lay_bound ?>px dotted blue; }
td.cms_lo_middle { border: <?= $lay_bound ?>px dotted cyan; }
td.cms_lo_left_column { border: <?= $lay_bound ?>px dotted green; }
td.cms_lo_body_column { border: <?= $lay_bound ?>px dotted grey; }
td.cms_lo_right_column { border: <?= $lay_bound ?>px dotted brown; }
td.cms_lo_footer { border: <?= $lay_bound ?>px dotted orange; }

<?php	
	} // if
$sects = 0;

if($theme['ThemeSettings']['HEADER_BOOL'] == 'true') {
	$sects++;
	$header_height = (int)preg_replace('/[a-z]*$/i', '',$theme['ThemeSettings']['HEADER_HEIGHT']);
	} // if
else $header_height = 0;

if($theme['ThemeSettings']['NAV_BAR_BOOL'] == 'true') {
	$sects++;
	$nav_bar_height = (int)preg_replace('/[a-z]*$/i', '',$theme['ThemeSettings']['NAV_BAR_HEIGHT']);
	} // if
else $nav_bar_height = 0;

if($theme['ThemeSettings']['FOOTER_BOOL'] == 'true') {
	$sects++;
	$footer_height = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['FOOTER_HEIGHT']);
	} // if
else $footer_height = 0;

if($theme['ThemeSettings']['LEFT_COLUMN_BOOL'] == 'true')
	$left_column_width = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['LEFT_WIDTH']);
else $left_column_width = 0;

if(($theme['ThemeSettings']['RIGHT_COLUMN_BOOL'] == 'true') &&
	($theme['ThemeSettings']['LEFT_COLUMN_BOOL'] == 'true'))
	$right_column_width = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['RIGHT_WIDTH']);
else $right_column_width = 0;


$sect_gap = ($lay_bound + $margin) * 2;
$hnf = ($header_height + $nav_bar_height + $footer_height + ($sect_gap * ($sects + $sects)));

?>
/* section gap = <?= $sect_gap ?> */


/* the block layout */
div.cms_lo_page_block {
	position: fixed;
	top: 0px;
	left: 0px;
	bottom: 0px;
	right: 0px;
	}

	td.cms_lo_header {
		position: absolute;
		top: 0px;
		height: <?= $header_height ?>px;
		left: 0px;
		right: 0px;
		margin: 0px;
		/*overflow: auto;*/
		}
	td.cms_lo_nav_bar {
		position: absolute;
		top: <?= $header_height ?>px; 
		height: <?= $nav_bar_height ?>px;
		left: 0px;
		right: 0px;
		margin: 0px;
		/*overflow: auto;*/
		}
	td.cms_lo_nav_bar:hover {
		overflow: unset;
		z-index: 1000;
		}

	td.cms_lo_middle {
		position: absolute;
		top: <?= ($header_height + $nav_bar_height) ?>px; 
		bottom: <?= $footer_height ?>px;
		vertical-align: top;
		left: 0px;
		right: 0px;
		margin: 0px;
		overflow: auto;
		}

		td.cms_lo_left_column {
			background-color: <?= $theme['ThemeSettings']['LEFT_BKGD_COLOUR'] ?>;
			color:		<?= $theme['ThemeSettings']['LEFT_FONT_COLOUR'] ?>;
			border:		<?= $theme['ThemeSettings']['LEFT_BORDER'] ?>;
			position: absolute;
			left: 0px;
			top: 0px; 
			bottom: 0px;
			vertical-align: top;
			width: <?= $left_column_width ?>px;
			overflow: auto;
			}
		td.cms_lo_body_column {
<?php if(!empty($theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE'])) { ?>
			background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']) ?>;
			background-repeat: no-repeat;
			background-attachment: local;
			background-size: 100% 100%;
<?php } else { ?>
			background-color: <?= $theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'] ?>;
<?php } // else ?>
			border:		<?= $theme['ThemeSettings']['PAGE_BODY_BORDER'] ?>;
			color:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR'] ?>;
			position: absolute;
			left: <?= $left_column_width ?>px;
			right: <?= $right_column_width ?>px;
			top: 0px;
			bottom: 0px;
			vertical-align: top;
			width: 100%;
			/*min-height: calc(100vh - <?= $hnf ?>px);*/
			overflow: auto;
			}
		td.cms_lo_right_column {
			background-color: <?= $theme['ThemeSettings']['RIGHT_BKGD_COLOUR'] ?>;
			color:		<?= $theme['ThemeSettings']['RIGHT_FONT_COLOUR'] ?>;
			border:		<?= $theme['ThemeSettings']['RIGHT_BORDER'] ?>;
			position: absolute;
			right: 0px;
			width: <?= $right_column_width ?>px;
			top: 0px; 
			bottom: 0px;
			vertical-align: top;
			overflow: auto;
			}

	td.cms_lo_footer {
		position: absolute;
		left: 0px;
		right: 0px;
		bottom: 0px;
		height: <?= $footer_height ?>px;
		margin: 0px;
		/*overflow: auto;*/
		}

#lm_link_frame {	/* inside an absolute page body */
	z-index:	3;
	width:		100%;
	height:		100%;
	}

#cms_page_frame {
	z-index:	3;
	}

#cms_page_body {
	z-index:	2;
	}

#cms_lo_footer {
	z-index:	50;
	}

.link_frame_moz {
	height: 100%;
	}

.link_frame_tablet {
	-webkit-overflow-scrolling: touch;
	height: 100%;
	}

.iframe_tablet {
	width:	100%;
	border-width: 0;
	height: 100%;
	}

.iframe_moz {
	width:	100%;
	border: 0;
	height: 100%;
	}

/* eof */

