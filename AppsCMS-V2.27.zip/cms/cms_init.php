<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_init.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

// Set the level of error reporting
error_reporting(E_ALL | E_STRICT);

if(file_exists('include/cms_configure.php')) require_once 'include/cms_configure.php';
elseif(file_exists('cms/include/cms_configure.php')) require_once 'cms/include/cms_configure.php';
elseif (file_exists('../../cms/include/cms_configure.php')) require_once '../../cms/include/cms_configure.php'; // for apps to run in (APP_DIR)
else die('ERROR: Failed to find AppsCMS configuration.');

require_once CMS_FS_INCLUDES_DIR . 'cms_auto_class_loader.php';

