
Applications Management System Library for PHP (AppsCMS).
=========================================================
see Licence in cms/LICENCE.txt
SVN Build: $Id: README-apps.txt 1961 2021-01-25 10:09:54Z robert0609 $

The /apps/ directory contains applications code.
Suggested sub-directories;
	/apps/include/classes	(The class autoloader looks in this directory to find auto loaded class code.)
	/apps/plugins	(The plugin autoloader looks in this directory for extra plugins, and the plugins config code.)
	/apps/include/ini/  has the apps.defaults.ini and apps.comments.ini files (when present, are used to defined application settings, when read are prefixed with "APP_" plus the ini file keyname.)

To have apps.ini to be setup via the admin menu, include the apps.comments.ini (the master keyname store with the user comments for each keyname),
and include apps.defaults.ini containing the default values.

The apps/include/example*.php and apps/include/ini/example*.ini provided as examples.
	
The /apps/.htaccess file denies public access to the direct file access to everything in the /apps/ directory.
If web access is required, a seperate sub-directory should be created under /apps/ and a new .htaccess be created
in that sub-directory with the appropiate access settings (recommend that the page bodies be used to provide all required access via include statements).

Refer to the manual for more  information.
