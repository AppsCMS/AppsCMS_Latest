<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_page_body.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>

<?php Ccms::page_start_comment(__FILE__); ?>
<?php

switch(Ccms::$action) {
case 'login':
case 'cms_login':
	if(Ccms_auth::is_user_logged_in()) {
		// already logged in
		Ccms::$action = false;
		} // if
	Ccms::$cms_action = 'cms_login';
	break;
case 'home':
default:
	if((LMC_USE_LM_AS_HOME) &&
		(empty(Ccms::$cms_action)) &&
		(empty(Ccms::$body_id)) &&
		(Ccms::is_links_manager_inuse())) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_lm.php");
		break;
		} // if
case 'body':	// gotcha
	if(!empty(Ccms::$body_id)) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
		} // if
	break;
	} // switch

switch(Ccms::$cms_action) {
case 'cms_login':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_login.php",array('user_name'),true,false);
	break;
case 'no_cookie':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_no_cookie.php",'',false,false);
	break;
case 'get_password':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_get_password.php",array('user_name'));
	break;
case 'get_eula':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_eula_form.php",array('user_name'),false,false);
	break;
case 'cms_edit_tools':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_tools.php");
		} // if
	break;
case 'cms_edit_bodies':
	if(Ccms_auth::is_config_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_bodies.php");
		} // if
	break;
case 'cms_edit_header_footer':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_header_footer.php");
		} // if
	break;
case 'cms_edit_sections':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_sections.php");
		} // if
	break;
case 'cms_edit_links':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_links.php");
		} // if
	break;
case 'cms_edit_groups':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_group.php");
		} // if
	break;
case 'cms_edit_users':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_users.php");
		} // if
	break;
case 'cms_edit_search':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_search.php");
		} // if
	break;
case 'cms_edit_config':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_config.php");
		} // if
	break;
case 'cms_edit_install':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_install.php");
		} // if
	break;
case 'cms_edit_apps':
	if(Ccms_apps::is_ini_congurable()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_apps.php");
		} // if
	break;
case 'cms_edit_theme':
	if(Ccms_auth::is_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_theme.php");
		} // if
	break;
case 'lm_show_links':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_lm.php");
	break;
case 'link':
	if(((int)Ccms::$link_id > 0) &&
		($url = Ccms::$cDBcms->get_data_in_table('lm_links','lm_link_url','lm_link_id = ' . (int)Ccms::$link_id))) {
		$https = Ccms::$cDBcms->get_data_in_table('lm_links','lm_link_ssl','lm_link_id = ' . (int)Ccms::$link_id);
		Ccms::output_link_or_tool_text($url, $https);
		} // if
	else Ccms::output_include_body_text("pages/default.php");
	break;
case 'tool':
	if(((int)Ccms::$tool_id > 0) &&
		($url = Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_url',
				'cms_tool_id = ' . (int)Ccms::$tool_id . (Ccms::is_debug() ? "":" AND cms_tool_debug_only = 0")))) {
		$https = Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_ssl',
				'cms_tool_id = ' . (int)Ccms::$tool_id);
		if(!Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_include',
				'cms_tool_id = ' . (int)Ccms::$tool_id )) {
			Ccms::output_link_or_tool_text(LOCAL_WS_TOOLS_DIR . $url, $https);
			} // if
		else {
			Ccms::output_include_body_text(LOCAL_FS_TOOLS_DIR . $url);
			} // else
		} // if
	else Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
	break;

case 'update_sitemap':
	// if(Ccms_auth::is_admin_user()) {
		new Ccms_xml_sitemap();
	//	} // if
case 'show_sitemap':	// make sure there is a site map
	if(Ccms_xml_sitemap::get_html_sitemap_file()) Ccms::$cms_action = 'show_sitemap';
	else {
		// @TODO empty, do something
		} //else
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_show_sitemap.php");
	break;

case 'disclaimer':
	if(strlen(CMS_C_CUSTOM_FOOTER_LINK) <= 4) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . 'cms_disclaimer.tmpl.php');
		}
	else Ccms::output_link_or_tool_text(CMS_C_CUSTOM_FOOTER_LINK);
	break;

case 'readme':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['readme'])) {
		$readme = $tla['readme'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $readme,$tla['h1'] . ' README.');
		} // if
	break;
case 'release_notes':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['release_notes'])) {
		$release_notes = $tla['release_notes'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $release_notes,$tla['h1'] . ' Release Notes.');
		} // if
	break;
case 'cookies':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['cookies'])) {
		$cookies = $tla['cookies'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $cookies,$tla['h1'] . ' Cookies');
		} // if
	break;
case 'terms':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['terms'])) {
		$terms = $tla['terms'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $terms,$tla['h1'] . ' Terms.');
		} // if
	break;
case 'licence':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['licence'])) {
		$licence = $tla['licence'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $licence,$tla['h1'] . ' Licence.');
		} // if
	break;
case 'acknowledgement':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['acknowledgement'])) {
		$acknowledgement = $tla['acknowledgement'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $acknowledgement,$tla['h1'] . ' Acknowledgement.');
		} // if
	break;

case 'home':
default:
	if((LMC_USE_LM_AS_HOME) &&
		(empty(Ccms::$action)) &&
		(empty(Ccms::$body_id)) &&
		(Ccms::is_links_manager_inuse())) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_lm.php");
		break;
		} // if
	else if((empty(Ccms::$action)) &&
		(empty(Ccms::$body_id))) {
		Ccms::output_include_body_text("");	// just put layout
		break;
		} // if
	break;
case 'cms_about':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_about.php",'',false);
	break;
case 'cms_manual':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_manual.php",'',false);
	break;
case 'apps_manual':
	Ccms::output_include_body_text(APPS_FS_APPS_MANUAL,'',false);
	break;
case 'apps_extend':
	$idx = Ccms::get_or_post('idx');
	if(($idx !== false) && (is_numeric($idx))) {
		$app_admin_uris = Ccms::get_apps_extend_static_func('get_admin_uris');
		$i = (int)$idx - 1;
		if((!is_null($app_admin_uris)) &&
			(isset($app_admin_uris[$i]['uri']))) {
			if((!isset($app_admin_uris[$i]['no_body'])) ||
				(!$app_admin_uris[$i]['no_body'])) {
				$uri = $app_admin_uris[$i]['uri'];
				if(preg_match('/^(http|https):/i',$uri)) {
					Ccms::output_link_or_tool_text($uri);
					} // if
				else Ccms::output_include_body_text($uri);
				} // if
			} // if
		} // if
	break;
case 'app_extend':
	$idx = Ccms::get_or_post('idx');
	$app_name = Ccms::get_or_post('app_name');
	if((!empty($app_name)) && ($idx !== false) && (is_numeric($idx))) {
		$class = 'C' . $app_name . '_app_extend_plugin';
		if(!$pl_a_e = Ccms_autoloader::find_plugin($class)) break;
		if(!method_exists($class,'get_admin_uris')) break;
		$aC = new $class();
		$app_admin_uris = $class::get_admin_uris();
		unset($aC);	// clean up
		if(empty($app_admin_uris)) break;
		$i = (int)$idx - 1;
		if((!isset($app_admin_uris[$i]['no_body'])) ||
			(!$app_admin_uris[$i]['no_body'])) {
			$uri = $app_admin_uris[$i]['uri'];
			if(preg_match('/^(http|https):/i',$uri)) {
				Ccms::output_link_or_tool_text($uri);
				} // if
			else Ccms::output_include_body_text($uri);
			} // if
		} // if
	break;
case 'cms_debug':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_debug.php");
	break;
case 'cms_doxy':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_doxy.php");
	break;
case 'cms_log_view':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_log_view.php");
	break;
case 'cms_browse_sessions':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_session_browser.php");
	break;
case 'cms_users_stats':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_users_stats.php");
	break;
case 'cms_text_view':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_text_view.php");
	break;
case 'show_sitemap':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_show_sitemap.php");
	break;
	} // switch
if(isset($_SESSION['action'])) unset($_SESSION['action']);
if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
if(isset($_SESSION['body'])) unset($_SESSION['body']);

Ccms::page_end_comment(__FILE__);
