<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_edit_header_footer.php 2036 2021-04-06 06:48:53Z robert0609 $
 */

function make_new_hf_text($file,$suffix = '') {
	$text = '';
	$text .= "Add include code or text here.";
	$text .= (!empty($suffix) ? '(' . $suffix . ')':'');
	return $text;
} // make_new_hf_text()

$cCMS_C = new Ccms_config();
if(Ccms::$page_info['html_wysiwyg_allow']) {
	global $cWYSIWYG;
	$cWYSIWYG = Ccms_wysiwyg::get_wysiwyg_class();
	} // if


$cms_hf_op = '';
if(Ccms::$cms_action == 'cms_edit_header_footer') { // a bit of caution
	if(Ccms::is_get_or_post('save')) {
		switch(Ccms::get_or_post('edit')) {
		case 'custom_header':
			$cms_hf_h1_name = 'Custom Header';
			$cms_hf_op = 'save';
			$cms_hf_file = PAGE_HEADER_INC;
			$cms_hf_filepath = PAGE_HEADER_FS_INC;
			$cms_config_keys = array("CMS_C_CUSTOM_HEADER","CMS_C_CUSTOM_HEADER_CACHED");
			break;
		case 'custom_footer':
			$cms_hf_h1_name = 'Custom Footer';
			$cms_hf_op = 'save';
			$cms_hf_file = PAGE_FOOTER_INC;
			$cms_hf_filepath = PAGE_FOOTER_WS_INC;
			$cms_config_keys = array("CMS_C_CUSTOM_FOOTER","CMS_C_CUSTOM_FOOTER_CACHED");
			break;
		default:
			Ccms::addMsg('Unknown header or footer include file operation.');
			$cms_hf_op = '';
			break;
			} // switch
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_hf_op = '';
		} // else if
	else if(Ccms::is_get_or_post('edit')) {
		switch(Ccms::get_or_post('edit')) {
		case 'custom_header':
			$cms_hf_h1_name = 'Custom Header';
			$cms_hf_op = 'edit';
			$cms_hf_name = 'custom_header';
			$cms_hf_file = PAGE_HEADER_INC;
			$cms_hf_filepath = PAGE_BODIES_FS_DIR . $cms_hf_file;
			$cms_hf_enabled = CMS_C_CUSTOM_HEADER;
			$cms_hf_cached = CMS_C_CUSTOM_HEADER_CACHED;
			break;
		case 'custom_footer':
			$cms_hf_h1_name = 'Custom Footer';
			$cms_hf_op = 'edit';
			$cms_hf_name = 'custom_footer';
			$cms_hf_file = 'footer.html.inc';
			$cms_hf_filepath = PAGE_BODIES_FS_DIR . $cms_hf_file;
			$cms_hf_enabled = CMS_C_CUSTOM_FOOTER;
			$cms_hf_cached = CMS_C_CUSTOM_FOOTER_CACHED;
			break;
		default:
			$cms_hf_op = '';
			break;
			} // switch
		} // if
	// else normal

	if($cms_hf_op == 'save') {
		// do it once
		$hf_text_area = $cWYSIWYG->input_edit_text();
		$cms_hf_enabled = Ccms::get_or_post_checkbox('cms_hf_enabled');
		$cms_hf_cached = Ccms::get_or_post_checkbox('cms_hf_cached');

		if((!Ccms::getMsgsCount('error')) &&
			(isset($hf_text_area))) {
			if(strlen($hf_text_area) > 10) {	// update file
				$cms_hf_filepath = PAGE_BODIES_FS_DIR . $cms_hf_file;
				if(!$fh = Ccms::file_safe_wopen($cms_hf_filepath, 'w')) {
					Ccms::addMsg('Failed to open body file "' . $cms_hf_filepath . '".');
					} // if
				else {	// save text to file
					if(!fwrite($fh, $hf_text_area)) {
						Ccms::addMsg('Failed to save text to body file "' . PAGE_BODIES_WS_DIR . $cms_hf_file . '".');
						} // if
					else {
						Ccms::addMsg('Save text to body file "' . PAGE_BODIES_WS_DIR . $cms_hf_file . '".','success');
						} // else
					Ccms::file_safe_wclose($fh,$cms_hf_filepath);
					} // else
				} // if
			else Ccms::addMsg ('Text is too small (less than 10 characters), not saved', 'warning');
			} // if

		if(!Ccms::getMsgsCount('error')) {	// update it
			// update enabled setting
			if((!Ccms::$cDBcms->perform('cms_configs',
				array( 'cms_config_value' => $cms_hf_enabled, ),
				'update',"cms_config_key = '" . $cms_config_keys[0] . "'")) ||

				(!Ccms::$cDBcms->perform('cms_configs',
				array( 'cms_config_value' => $cms_hf_cached, ),
				'update',"cms_config_key = '" . $cms_config_keys[1] . "'"))) {

				Ccms::addMsg('Enable update or cache, ' . $cms_hf_file . " failed");
				Ccms::$cDBcms->logEvent('ERROR: enable or cache update, ' . $cms_hf_file);
				} // if
			} // if
		$cms_hf_op = '';
		} // if
	} // if
$row = 0;
?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php

if(Ccms::$page_info['html_wysiwyg_allow']) {
	$text = $cWYSIWYG->get_wysiwyg_library();
	echo $text;
	} // if

?>

<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<form name="edit_hf" action="<?php echo $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_header_footer'; ?>" method="post" enctype="multipart/form-data">
<?php echo Ccms_search::get_form_search_hidden_inputs(); ?>
<table class="page_config">
	<?php if(empty($cms_hf_op)) { ?>
	<tr class="page_config"><th class="page_config">Custom Header and Footer Summary</th></tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<table class="page_config">
				<tr class="page_config">
					<th width ="150px" class="page_config">Name</th>
					<th width ="70px" class="page_config">Enabled</th>
					<th width ="70px" class="page_config">Cached</th>
					<th class="page_config"></th>
				</tr>
				<tr class="<?php echo (($row++ & 1) ? 'page_config_odd':'page_config_even'); ?>">
					<td class="page_config" style="text-align: left">
						<a href="index.php?cms_action=cms_edit_header_footer&edit=custom_header" title="Edit custom header"><?php echo PAGE_HEADER_INC; ?></a>
					</td>
					<td class="page_config" style="text-align: left"><?php echo (CMS_C_CUSTOM_HEADER ? 'yes':'no'); ?></td>
					<td class="page_config" style="text-align: left"><?php echo (CMS_C_CUSTOM_HEADER_CACHED ? 'yes':'no'); ?></td>
					<td class="page_config" style="text-align: left">Custom header include file.</td>
				</tr>
				<tr class="<?php echo (($row++ & 1) ? 'page_config_odd':'page_config_even'); ?>">
					<td class="page_config" style="text-align: left">
						<a href="index.php?cms_action=cms_edit_header_footer&edit=custom_footer" title="Edit custom footer"><?php echo PAGE_FOOTER_INC; ?></a>
					</td>
					<td class="page_config" style="text-align: left"><?php echo (CMS_C_CUSTOM_FOOTER ? 'yes':'no'); ?></td>
					<td class="page_config" style="text-align: left"><?php echo (CMS_C_CUSTOM_FOOTER_CACHED ? 'yes':'no'); ?></td>
					<td class="page_config" style="text-align: left">Custom footer include file.</td>
				</tr>
			</table>
		</td>
	</tr>
	<?php	} // if ?>
</table>


<?php
if($cms_hf_op == 'edit') {
	if((!empty($cms_hf_file)) &&
		(file_exists($cms_hf_filepath)) &&
		(is_readable($cms_hf_filepath)) &&
		(($fs = filesize($cms_hf_filepath)) > 2) &&
		($fh = @fopen($cms_hf_filepath,'r'))) {
		$hf_text = fread($fh,$fs);
		fclose($fh);
		} // if
	else {	// new or lost file
		$hf_text = make_new_hf_text($cms_hf_filepath);
		} // else
?>

<span id="ws_text_input" style="display: block;">
	<table class="page_config">
		<tr class="page_config">
			<th class="page_config">
				<h1 class="page_config"><?php echo $cms_hf_h1_name; ?> - Editor.</h1>
			</th>
			<td class="page_config" style="text-align: right">
<?php
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == 'custom'))
					Ccms::get_return2search_link(true);
?>

				Enable:<input type="checkbox" name="cms_hf_enabled"<?php echo ($cms_hf_enabled ? ' CHECKED':'');?> title="Check to enable, uncheck to disable"/>
				&nbsp;&nbsp;
				Cached:<input type="checkbox" name="cms_hf_cached"<?php echo ($cms_hf_cached ? ' CHECKED':'');?> title="Check to cache contents, uncheck to disable"/>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_input');" type="button" disabled="true">Editor</button>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_view');" type="button" title="Goto to view.">View</button>
				&nbsp;&nbsp;
				<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
				<input type="hidden" name="edit" value="<?php echo htmlentities($cms_hf_name); ?>"/>
				<?php Ccms::get_return2search_link(); ?>
			</td>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<h2 class="page_config" class="page_body">Available Link URIs</h2>
				<select id="ws_link_list_id" name="ws_link_list" size="1" onchange="javascript:cms_get_selected_ws_link();"><?php echo Ccms::make_ws_link_select_options(); ?></select>
				<br><input type="text" id="ws_link_selected_id" value="" size="60" title="Select/hi-light the link text and copy with Control-C, and paste with Control-V into link path input." autocapitalize="off"/>
			</td>
			<td class="page_config">
				<h2 class="page_config" class="page_body">Available Image URIs</h2>
				<span id="ws_image_selector_id"><?php echo Ccms_options::get_ws_image_uri_selection(); ?></span>
				<input type="file" accept="image/*" id="ws_image_upload_id" name="" onchange="javascript:cms_ajax_upload_image();" title="Select images to upload. Stored in the <?php echo ETC_WS_IMAGES_DIR; ?> directory, and updates the available body image URIs"/>
					<br><input type="text" id="ws_image_selected_id" value="" size="60" title="Select/hi-light the image text and copy with Control-C, and paste with Control-V into Image URL input." autocapitalize="off"/>
					<span id="uploading_image_id"></span>
			</td>
		</tr>
	</table>
	<table class="page_body">
		<tr class="page_body">
			<td class="page_body">
				<?php echo $cWYSIWYG->output_edit_text($hf_text); ?>
			</td>
		</tr>
		<tr class="page_body">
			<td class="page_config" style="text-align: right">
				<button onclick="cms_setView('ws_text_input');" type="button" disabled="true">Editor</button>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_view');" type="button" title="Goto to view.">View</button>
				&nbsp;&nbsp;
				<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</td>
		</tr>
	</table>
</span>

<span id="ws_text_view_blk" style="display: none;">
	<table class="page_config">
		<tr class="page_config">
			<th class="page_config">
				<h1 class="page_config"><?php echo $cms_hf_h1_name; ?> - View.</h1>
			</th>
		</tr>
		<tr class="page_config">
			<td class="page_config" style="text-align: right">
<?php
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == 'custom'))
					Ccms::get_return2search_link(true);
?>

				<button onclick="cms_setView('ws_text_input');" type="button" title="Goto edit (<?php echo $cWYSIWYG->get_wysiwyg_title(); ?>).">Editor</button>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_view');" type="button" disabled="true">View</button>
				&nbsp;&nbsp;
				<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</td>
		</tr>
	</table>
	<table class="page_body">
		<tr class="page_body">
			<td class="page_body">
				<span id="ws_text_view">
					<?php echo $hf_text; ?>
				</span>
			</td>
		</tr>
	</table>
</span>

<?php	} // if ?>
</form>

<?php Ccms::page_end_comment(__FILE__); ?>
