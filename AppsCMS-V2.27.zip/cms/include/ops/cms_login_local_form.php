<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_login_local_form.php 2019 2021-04-01 00:00:05Z robert0609 $
 */

global $user_name;
if(!isset($user_name)) $user_name = '';
$login_url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?action=login';

?>
<?php Ccms::page_start_comment(__FILE__); ?>

<div>
<?php Ccms::set_JS_password_resource(); ?>
	<form method="post" name="login" action="<?php echo $login_url; ?>">
	<input type="hidden" name="action" value="login"/>
	<input type="hidden" name="local_login" value="true"/>
	<table class="page_body">
		<tr class="page_body">
			<th width="150px" class="page_body">Name:</th>
			<td class="page_body" style="text-align: left;">
				<input type="text" id="id_user_name" placeholder="User name" name="user_name" value="<?php echo $user_name; ?>" autocorrect="off" autocapitalize="off" title="Enter username" autofocus/>
			</td>
		</tr>
		<tr class="page_body">
			<th class="page_body">Password:</th>
			<td class="page_body" style="text-align: left;">
				<?php Ccms::set_JS_password_input('user_password', 'Enter password','',false,true); ?>
			</td>
		</tr>
<?php if(INI_ALLOW_COOKIE_LOGIN_BOOL) {
	$l_int = Ccms::get_human_fmt_time_interval(INI_SESSIONS_COOKIE_TIMEOUT_SECS,"days");
?>
		<tr class="page_body">
			<th class="page_body">Remember Login:</th>
			<td class="page_body" style="text-align: left;">
				<input type="checkbox" name="remember" title="Check to remember login for <?php echo $l_int; ?>."/>
			</td>
		</tr>
<?php	} // if ?>
		<tr class="page_body">
			<th class="page_body"></th>
			<td class="page_body" style="text-align: left;">
				<button type="submit" name="submit" value="login" onclick="Ccms_cursor.setWait();">Login</button>
				<button type="submit" name="submit" value="cancel" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</td>
		</tr>
	</table>
	<?php Ccms::add_JS_geolcation_to_form(); ?>
	</form>
</div>
<?php Ccms::page_end_comment(__FILE__); ?>
