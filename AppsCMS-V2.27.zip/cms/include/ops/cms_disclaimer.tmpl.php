<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_disclaimer.tmpl.php 2004 2021-02-28 08:53:00Z robert0609 $
 */

?>
<table class="page_body">
	<caption>Disclaimer for <?php echo strip_tags(CMS_PROJECT_SHORTNAME); ?></caption>
	<tr class="page_body">
		<th class="page_body">
<?php		if(strlen(CMS_C_LOGO_IMAGE) > 4) { ?>
				<img src="<?php echo ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE; ?>" alt="logo">
				&nbsp;
<?php			} // if ?>
				<?php echo CMS_C_CO_NAME; ?> Disclaimer
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				ALL SOFTWARE, FIRMWARE, DOCUMENTS, MATERIALS AND RELATED GRAPHICS IN THIS SITE ARE PROVIDED &quot;AS IS&quot;.
			</p>
			<p class="page_body">
				No warrantees, no guarantees nor suitability for a purpose, are given, expressed or implied.
			</p>
			<p class="page_body">
				<?php echo CMS_C_CO_NAME; ?> is not responsible for software, firmware, documents, materials
				and any other information provided by other web sites.
				Any links to other web sites and Internet resources are provided for convenience
				only and <?php echo CMS_C_CO_NAME; ?> does not express, imply
				nor give any endorsement nor warrantee, to any resource provided by links on this web site.
			</p>
			<!--
			<p class="page_body">
				All trademarks belong to their respective owners.
			</p>
			-->
			<p class="page_body">
				The information contained in this web site is believed to be true and correct.
				<?php echo CMS_C_CO_NAME; ?> makes no representations nor warrantees as to the
				accuracy of any information on this web site.
				The web site user assumes all risk of relying on the information on this web site.
				No commitment is made to update or correct any information that appears on the internet nor on this web site.
			</p>
			<p class="page_body">
				USE OF THIS WEB SITE INDICATES YOUR AGREEMENT TO THE CONDITIONS AND RESTRICTIONS OF THIS &quot;<?php echo CMS_C_CO_NAME; ?> Disclaimer&quot;.
			</p>
<?php		if(strlen(CMS_C_SUPPORT_EMAIL) > 4) { ?>
			<p class="page_body">
				Contact <a href="mailto:<?php echo CMS_C_SUPPORT_EMAIL; ?>">support by email</a>.
			</p>
<?php			} // if ?>
		</td>
	</tr>
</table>
