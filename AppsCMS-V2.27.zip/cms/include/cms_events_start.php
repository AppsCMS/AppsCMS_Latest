<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_events_start.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

	// DO NOT PUT VIEWABLE CODE IN HERE

// see "https://developer.mozilla.org/en-US/docs/Web/API/Window/DOMContentLoaded_event"

?>

<?php Ccms::page_start_comment(__FILE__); ?>

	<script type="text/javascript">
		window.addEventListener('DOMContentLoaded', (event) => {
			// console.log('DOM fully loaded and parsed');
<?php if(Ccms_socialmedia_plugin::is_enabled()) {	?>
			try {
				cms_socialMedia_init();
				} // try
			catch(err) {
				// not available
				} // catch
<?php	} // if	?>
<?php if(Ccms_maplatlong_plugin::is_enabled()) {	?>
			try {
				cms_maplatlong_init();
				} // try
			catch(err) {
				// not available
				} // catch
<?php	} // if	?>
<?php if(Ccms::$tooltips_flg) {	?>
			try {
				cms_titles2tooltips(<?php echo (Ccms::$tablet_flg ? 'true':'false'); ?>);
				} // try
			catch(err) {
				// not available
				} // catch
<?php	} // if	?>
			try {
				Ccms_cursor.restore();	// because some code over rides the body cursor behavior.
				} // try
			catch(err) {
				// not available
				} // catch
			});
	</script>

	<?php if(!INI_ANALYTICS_EXT_INHEAD_BOOL) Ccms::do_analytics_include(); ?>

<?php Ccms::page_end_comment(__FILE__); ?>
