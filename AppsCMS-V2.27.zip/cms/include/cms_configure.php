<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_configure.php 2058 2021-04-12 06:42:55Z robert0609 $
 */

// general program definition constants
define("CMS_PROJECT_NAME",			"Applications Management System Library for PHP");	// Define the project name
define("CMS_PROJECT_SHORTNAME",		"AppsCMS");		// Define the project abreviated name
define("CMS_PROJECT_VERSION",		"V2.27");	// Define the project version
define("CMS_PROJECT_DOMAIN",		"appscms.org");	// the web domain
define("CMS_SESSION_NAME",			"AppsCMSid_");	// session id index
define("CMS_PREFIX",				"cms_");		// AppsCMS prefix

// where is everything
define("DOCROOT_FS_BASE_DIR",	str_replace('\\','/',dirname(dirname(dirname(__FILE__)))) . '/');	// the web page file base, must be LINUX and Windows compatible
//echo DOCROOT_FS_BASE_DIR; // test (turn off compression to see)

//define general stuff

if(isset($_SERVER['SERVER_NAME'])) {	// running as a web app
	//	site status definition
	// if(isset($_SERVER['PHP_SELF'])) {
		// $ws_dir = preg_replace('/\/?cms\/?$/','',substr(dirname($_SERVER['PHP_SELF']),1));

		// changes for PHP 7 from rogue URL tests, sometimes the $_SERVER array is not fully populated
		if(isset($_SERVER['SCRIPT_NAME'])) $ws_uri = $_SERVER['SCRIPT_NAME'];
		else if(isset($_SERVER['PHP_SELF'])) $ws_uri = $_SERVER['PHP_SELF'];
		else if(isset($_SERVER['REQUEST_URI'])) $ws_uri = $_SERVER['REQUEST_URI'];
		else $ws_uri = '';	// should not happen !!!!

		$ws_uri = substr(dirname($ws_uri),1);
		// $ws_dir = preg_replace('/(\/cms\/.*|\/apps\/.*)$/','',$ws_uri);	(?)
		$ws_dir = preg_replace('/(\/cms.*|\/apps.*)$/','',$ws_uri);

		if(strlen($ws_dir) > 2) {
			define("DOCROOT_WS_BASE_DIR",	$ws_dir . '/');	// directory on server with web pages, usually the web pages alias setting
			} /// if
		// DOCROOT_WS_BASE_DIR should have trailing slash but no leading slash,
		// since paths are constructed like '/' . DOCROOT_WS_BASE_DIR . 'index.php'.
		// Thus it should be blank if we're installed on /.
		else define("DOCROOT_WS_BASE_DIR",		'');
//		} // if
//	else define("DOCROOT_WS_BASE_DIR",		'');
	define("CMS_SITE_TYPE",		(!empty($_SERVER['HTTPS']) ? 'NO_SSL':'SSL'));

	define("CMS_DOMAIN",		$_SERVER['SERVER_NAME']);
	define("CMS_DOMAIN_IP",		$_SERVER['SERVER_ADDR']);

	define("CMS_WWW_HOST",		'http://' . CMS_DOMAIN . '/');
	define("CMS_SSL_HOST",		'https://' . CMS_DOMAIN . '/');
	define("CMS_WWW_URL",		CMS_WWW_HOST . DOCROOT_WS_BASE_DIR);
	define("CMS_SSL_URL",		CMS_SSL_HOST . DOCROOT_WS_BASE_DIR);

	define('CMS_NL',			"<br>" . PHP_EOL);

	define('CLI_MODE', false);

	} // if
else if(((defined('CLI_MODE')) && (CLI_MODE)) ||
	(!isset($SERVER))) { // running in CLI
	//	cli status definition
	global $_SERVER;
	$_SERVER = array(	// spoof global
		'HTTP_USER_AGENT' => 'cli',
		);
	if(!defined('CLI_MODE')) define('CLI_MODE', true);

	define("DOCROOT_WS_BASE_DIR",	'');	// directory on server with web pages, usually the web pages alias setting
	define("CMS_SITE_TYPE",		'NO_SSL');

	define("CMS_DOMAIN",		'CLI');
	define("CMS_DOMAIN_IP",		'10.10.10.10');

	define("CMS_WWW_URL",		"http://" . CMS_DOMAIN . '/' . DOCROOT_WS_BASE_DIR);
	define("CMS_SSL_URL",		"https://" . CMS_DOMAIN . '/' . DOCROOT_WS_BASE_DIR);

	define('CMS_NL',			PHP_EOL);

	} // else if
else  { // ?? what am I doing ???
	echo "HOST ERROR: Cannot determine set up requirements.\n";
	if(isset($_SERVER)) {
		echo PHP_EOL . "Server variables " . '($_SERVER)' . ":" . PHP_EOL;
		var_dump($_SERVER);
		} // if
	exit(1);
	} // else

define("CMS_DIR",					'cms/');
define("CMS_WS_DIR",				CMS_DIR);	// to match other define styles
define("CMS_FS_DIR",				DOCROOT_FS_BASE_DIR . CMS_DIR);

// 3rd third library code
define("CMS_WS_LIB_DIR",			CMS_DIR . "lib/");
define("CMS_FS_LIB_DIR",			CMS_FS_DIR . "lib/");

// cli/ never used directly in web code, never directly called
define("CMS_FS_CLI_DIR",			CMS_FS_DIR . "cli/");
define("CMS_WS_CLI_DIR",			CMS_DIR . "cli/");

define("CMS_FS_INCLUDES_DIR",		CMS_FS_DIR . 'include/');
define("CMS_FS_OPS_DIR",			CMS_FS_INCLUDES_DIR . 'ops/');
define("CMS_FS_CLASSES_DIR",		CMS_FS_INCLUDES_DIR . 'classes/');
define("CMS_FS_PLUGINS_DIR",		CMS_FS_INCLUDES_DIR . 'plugins/');
define("CMS_FS_INI_DIR",			CMS_FS_INCLUDES_DIR . 'ini/');

define("CMS_WS_IMAGES_DIR",			CMS_DIR . 'images/');
define("CMS_FS_IMAGES_DIR",			CMS_FS_DIR . 'images/');
define("CMS_WS_ICONS_DIR",			CMS_DIR . 'images/icons/');
define("CMS_FS_ICONS_DIR",			CMS_FS_DIR . 'images/icons/');
define("CMS_WS_IMAGES_MANUAL_DIR",	CMS_DIR . 'images/manual/');
define("CMS_FS_IMAGES_MANUAL_DIR",	CMS_FS_DIR . 'images/manual/');

define("CMS_WS_EXAMPLES_DIR",		CMS_DIR . "examples/");
define("CMS_FS_EXAMPLES_DIR",		CMS_FS_DIR . "examples/");

// the doxygen documentation dirs
define("CMS_WS_DOXY_DIR",			CMS_DIR . "doxy/");
define("CMS_FS_DOXY_DIR",			CMS_DIR . "doxy/");
define("CMS_WS_CMS_APPS_DOXY_DIR",	CMS_WS_DOXY_DIR . "html/");
define("CMS_FS_CMS_APPS_DOXY_DIR",	CMS_FS_DOXY_DIR . "html/");
define("CMS_WS_CMS_DOXY_DIR",		CMS_WS_DOXY_DIR . "cms_html/");
define("CMS_FS_CMS_DOXY_DIR",		CMS_FS_DOXY_DIR . "cms_html/");
define("CMS_WS_APPS_DOXY_DIR",		CMS_WS_DOXY_DIR . "apps_html/");
define("CMS_FS_APPS_DOXY_DIR",		CMS_FS_DOXY_DIR . "apps_html/");

define("ETC_DIR",					'etc/');
define("ETC_FS_DIR",				DOCROOT_FS_BASE_DIR . ETC_DIR);

// css files theme files
define('ETC_WS_CSS_DIR',			ETC_DIR . "css/");
define('ETC_FS_CSS_DIR',			ETC_FS_DIR . "css/");

// ini/ never used directly in web code, never directly called
define("ETC_FS_INI_DIR",			ETC_FS_DIR . "ini/");

// sqlite not allowed to WS, never directly called
define("ETC_FS_SQLITE_DIR",			ETC_FS_DIR . 'sqlite/');

define("ETC_WS_EXT_INCLUDES_DIR",	ETC_DIR . 'ext/');
define("ETC_FS_EXT_INCLUDES_DIR",	ETC_FS_DIR . 'ext/');

define("ETC_WS_SSL_INCLUDES_DIR",	ETC_DIR . 'ssl/');
define("ETC_FS_SSL_INCLUDES_DIR",	ETC_FS_DIR . 'ssl/');

define("ETC_WS_IMAGES_DIR",			ETC_DIR . 'images/');
define("ETC_FS_IMAGES_DIR",			ETC_FS_DIR . 'images/');

define("ETC_WS_ICONS_DIR",	ETC_DIR . 'icons/');
define("ETC_FS_ICONS_DIR",	ETC_FS_DIR . 'icons/');

define("ETC_WS_BACKGROUNDS_DIR",	ETC_DIR . 'backgrounds/');
define("ETC_FS_BACKGROUNDS_DIR",	ETC_FS_DIR . 'backgrounds/');

define("ETC_FS_CMS_WYSIWYGS",		ETC_FS_INI_DIR . 'cms_wysiwyg.json');

define('PAGES_BODIES_DIR',			'page_bodies/');
define('PAGE_BODIES_WS_DIR',		PAGES_BODIES_DIR);
define('PAGE_BODIES_FS_DIR',		DOCROOT_FS_BASE_DIR . PAGES_BODIES_DIR);

define('PAGE_HEADER_INC',			'header.html.inc');
define('PAGE_HEADER_WS_INC',		PAGE_BODIES_WS_DIR . PAGE_HEADER_INC);
define('PAGE_HEADER_FS_INC',		PAGE_BODIES_FS_DIR . PAGE_HEADER_INC);

define('PAGE_FOOTER_INC',			'footer.html.inc');
define('PAGE_FOOTER_WS_INC',		PAGE_BODIES_WS_DIR . PAGE_FOOTER_INC);
define('PAGE_FOOTER_FS_INC',		PAGE_BODIES_FS_DIR . PAGE_FOOTER_INC);

define("VAR_DIR",					'var/');
define("VAR_FS_DIR",				DOCROOT_FS_BASE_DIR . VAR_DIR);

define("VAR_FS_CACHE_DIR",			VAR_FS_DIR . "cache/");
define("VAR_FS_BACKUP_DIR",			VAR_FS_DIR . "backups/");
define("VAR_FS_EXPORT_DIR",			VAR_FS_DIR . "exports/");
define("VAR_FS_TEMP_DIR",			VAR_FS_DIR . "temp/");
define("VAR_FS_TRASH_DIR",			VAR_FS_DIR . "Trash/");
define("VAR_FS_VARIABLES_DIR",		VAR_FS_DIR . "variables/");
define("VAR_FS_USERS_DIR",			VAR_FS_VARIABLES_DIR . "users/");

define("VAR_WS_APPS_DIR",			VAR_DIR . "apps/");
define("VAR_FS_APPS_DIR",			VAR_FS_DIR . "apps/");

define("VAR_WS_CACHE_APPS_DIR",		VAR_DIR . "cache/apps/");
define("VAR_FS_CACHE_APPS_DIR",		VAR_FS_DIR . "cache/apps/");

define("VAR_WS_CACHE_GOTCHA_DIR",	VAR_DIR . "cache/gotcha/");
define("VAR_FS_CACHE_GOTCHA_DIR",	VAR_FS_DIR . "cache/gotcha/");

define("VAR_WS_CACHE_MINIFY_DIR",	VAR_DIR . "cache/min/");
define("VAR_FS_CACHE_MINIFY_DIR",	VAR_FS_DIR . "cache/min/");

// proxy control tables
define("VAR_FS_PROXY_DIR",			VAR_FS_VARIABLES_DIR . "proxy/");

// cache/contents is always an include file, never directly called
define("VAR_FS_CACHE_CONTENTS_DIR",	VAR_FS_DIR . "cache/contents/");

// local session storage directory
define("VAR_FS_SESSION_DIR",		VAR_FS_DIR . 'sessions/');	// session save directory

define("VAR_FS_LOGS_DIR",			VAR_FS_DIR . "logs/");
define("VAR_LOG_FILE",				VAR_FS_LOGS_DIR . CMS_DOMAIN . '_cms-' . date('Ymd') . '.log');
define("VAR_ERROR_LOG_FILE",		VAR_FS_LOGS_DIR . CMS_DOMAIN . '_error_php-' . date('Ymd') . '.log');
define("VAR_ACCESS_CNTR",			VAR_FS_VARIABLES_DIR . "CMS_AccessCntr.dat");
define('SESSION_RELOADED_MRKER',	VAR_FS_VARIABLES_DIR . 'session_reload_mrkr');

ini_set('log_errors','On');
ini_set('error_log',VAR_ERROR_LOG_FILE);

//
// AppsCMS config ini
define("ETC_FS_CMS_CONFIG",			ETC_FS_INI_DIR . 'cms.ini');
define("ETC_FS_CONFIG_JSON",		ETC_FS_INI_DIR . 'cms.json');
define("CMS_FS_CMS_CONFIG_DEFAULT",	CMS_FS_INI_DIR . 'cms.defaults.ini');
define("CMS_FS_CMS_CONFIG_MSGS",	CMS_FS_INI_DIR . 'cms.comments.ini');
define("CMS_FS_CMS_USER_DEFAULT",	CMS_FS_INI_DIR . 'cms.default.user.json');
define("CMS_FS_CMS_RESPONSE_CODES",	CMS_FS_INI_DIR . 'cms.response_codes.ini');
define("CMS_FS_CMS_STD_COLOURS",	CMS_FS_INI_DIR . 'cms.std_colours.ini');

define("LOCAL_TOOLS_DIR",			'localtools/');
define("LOCAL_WS_TOOLS_DIR",		LOCAL_TOOLS_DIR);
define("LOCAL_FS_TOOLS_DIR",		DOCROOT_FS_BASE_DIR . LOCAL_TOOLS_DIR);

define("APPS_DIR",					'apps/');
define("APPS_WS_DIR",				APPS_DIR);
define("APPS_FS_DIR",				DOCROOT_FS_BASE_DIR . APPS_DIR);
define('APPS_FS_CLI_DIR',			APPS_FS_DIR . 'cli/');
define('APPS_WS_CLI_DIR',			APPS_WS_DIR . 'cli/');
define("APPS_FS_INCLUDE_DIR",		APPS_FS_DIR . 'include/');
define("APPS_FS_PLUGINS_DIR",		APPS_FS_INCLUDE_DIR . 'plugins/');
define("APPS_FS_CLASSES_DIR",		APPS_FS_INCLUDE_DIR . 'classes/');
define('APPS_FS_LIB_DIR',			APPS_FS_DIR . 'lib/');
define('APPS_WS_LIB_DIR',			APPS_WS_DIR . 'lib/');
define('APPS_FS_IMAGES_DIR',		APPS_FS_DIR . 'images/');
define('APPS_WS_IMAGES_DIR',		APPS_WS_DIR . 'images/');
define('APPS_FS_JAVASCRIPT_DIR',	APPS_FS_DIR . 'javascript/');
define('APPS_WS_JAVASCRIPT_DIR',	APPS_WS_DIR . 'javascript/');
define('APPS_FS_STYLESHEETS_DIR',	APPS_FS_DIR . 'stylesheets/');
define('APPS_WS_STYLESHEETS_DIR',	APPS_WS_DIR . 'stylesheets/');

// apps config ini
define("APPS_FS_INI_DIR",			APPS_FS_INCLUDE_DIR . 'ini/');
define("ETC_FS_APPS_CONFIG",		ETC_FS_DIR . 'ini/apps.ini');
define("APPS_FS_APPS_CONFIG_DEFAULT",	APPS_FS_INI_DIR . 'apps.defaults.ini');
define("APPS_FS_CONFIG_MSGS",		APPS_FS_INI_DIR . 'apps.comments.ini');
define("ETC_FS_APPS_CONFIG_JSON",	ETC_FS_DIR . 'ini/apps.json');	// default location

// not available directly from web
define("APPS_FS_APPS_MANUAL",		APPS_FS_INCLUDE_DIR . 'apps_manual.php');

// common CRON job script, not available directly from web
define("APPS_FS_APPS_CRON_SCRIPT",	APPS_FS_CLI_DIR . 'apps_cron.sh');
define("APPS_WS_APPS_CRON_SCRIPT",	APPS_WS_CLI_DIR . 'apps_cron.sh');
define("APPS_FS_APPS_CRON_PHP",		APPS_FS_CLI_DIR . 'apps_cron.php');
define("APPS_WS_APPS_CRON_PHP",		APPS_WS_CLI_DIR . 'apps_cron.php');

// set no data base login creds
define("CMS_DEFAULT_ADMIN",		'admin');
define("CMS_DEFAULT_PASSWORD",	md5('password'));

// cookies
define("CMS_LOGIN_COOKIE_NAME", preg_replace('/[\/.,\\ ]?/', '_', DOCROOT_WS_BASE_DIR) . '_CMS_Login_id');

// standard non accessed filename and directories
define("CMS_DONT_ACCESS_PATH_PATTERN",	'/\.svn$|\.git$|\.cvs$|^\.|^_|^\.\.$/i');	// this is used with preg_match() as the pattern

// AppsCMS logo
define("CMS_IMAGE_LOGO",			CMS_WS_IMAGES_DIR . 'AppsCMS_logo.gif');

// sitemap files
define('CMS_SITEMAP_HTML_FILE', "sitemap.html");
define('CMS_SITEMAP_XML_FILE', "sitemap.xml");

