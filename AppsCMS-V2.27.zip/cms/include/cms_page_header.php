<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_page_header.php 2008 2021-03-02 09:51:18Z robert0609 $
 */

if(INI_HEADER_BOOL) {
	if((CMS_C_CUSTOM_HEADER) && (is_readable(PAGE_HEADER_FS_INC))) {
		Ccms::page_start_comment(PAGE_HEADER_INC);
		echo '<div id="cms_header">' . PHP_EOL;
		include PAGE_HEADER_FS_INC;
		$atxt = Ccms::get_header_admin_tools_pdb_text();
		if(!empty($atxt)) echo '<br>' . $atxt . PHP_EOL;
		echo '</div>';
		Ccms::page_end_comment(PAGE_HEADER_INC);
		} // if
	else {
		Ccms::page_start_comment(__FILE__);
?>
<div id="cms_header">
	<table class="page_top">
		<caption>Page header</caption>
		<tr class="page_top">
			<td>&nbsp;</td>
			<td class="page_top" style="text-align: left;">
				<a href="<?php echo (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL); ?>index.php"
					onclick="Ccms_cursor.setWait();"
					title="Home Page">
<?php		if(strlen(CMS_C_LOGO_IMAGE) > 4) {
				if(is_readable(CMS_C_LOGO_IMAGE)) $img = CMS_C_LOGO_IMAGE;
				else $img = ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE;
				echo '<img class="logo" src="' . $img. '" alt="Home">';
				} // if
			else echo '<strong>Home</strong>';
?>
				</a>
			</td>
<?php
		$atxt = Ccms::get_header_admin_tools_pdb_text();
		if(!empty($atxt)) echo '<td class="page_top" style="text-align: left;">' . $atxt . '</td>' . PHP_EOL;
		$smtxt = Ccms::get_social_media('header_left');
		if(!empty($smtxt)) echo '<td class="page_top no_print" style="text-align: left;">' . $smtxt . '</td>' . PHP_EOL;
?>
			<td class="page_top" style="text-align: center;">
<?php
		echo Ccms::get_header_bar_title();
?>
			</td>
<?php
		// sort where the login and social media sit
		$smtxt = Ccms::get_social_media('header_right');
		$txt = '';
		if(!INI_NAV_BAR_BOOL) {	// do a simple simple
			if(!Ccms_auth::is_user_logged_in()) {
				if((CMS_C_SHOW_LOGIN_LINK) &&	// login shown (otherwise use direct URL)
					(Ccms_auth::is_login_allowed())) {	// can login
					// do a simple simple
					// $txt = '<div class="cms_sticky_right">' . '<a href="login.php">User: Login</a>' . '</div>';
					$txt = '<div class="cms_sticky_right">' . Ccms_auth::get_login_logout() . '</div>';
					} // else
				} // if
			else {	// in nav bar ??
				$nav_bar_grid = Ccms::get_navbar_grid();
				unset($nav_bar_grid['apps']);
				$in_nb = false;
				$out_nb = false;
				for($i = 0; $i < count($nav_bar_grid); $i++) {
					$g = &$nav_bar_grid[$i];
					if(preg_match('/login.php|action=.*login/i',$g[0]))
						$in_nb = true;
					if(preg_match('/logout.php|action=.*logout/i',$g[0]))
						$out_nb = true;
					} // for
				if((!$in_nb) && (!Ccms_auth::is_user_logged_in())) {
					// $txt = '<a href="login.php">User: Login</a>';
					$txt = Ccms_auth::get_login_logout();
					} // if
				else if((!$out_nb) && (Ccms_auth::is_user_logged_in())) {
					$txt = Ccms_auth::get_login_logout();
					} // else
				// else it's in the nav bar
				} // else
			} // if
		if(!empty($txt)) {
			if(!empty($smtxt)) echo '<td class="page_top no_print" style="text-align: right;">' . $smtxt . '</td>' . PHP_EOL;
			echo '<td class="page_top no_print" style="text-align: right; width: 25%; font-size: smaller;">' . $txt . '</td>';
			} // if
		else if(!empty($smtxt)) echo '<td class="page_top no_print" style="text-align: right; width: 25%;">' . $smtxt . '</td>' . PHP_EOL;
		else echo '<td class="page_top no_print" style="text-align: right; width: 25%;">' . '&nbsp;' . '</td>' . PHP_EOL;
?>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<?php
		Ccms::page_end_comment(__FILE__);
		} // else
} // if
