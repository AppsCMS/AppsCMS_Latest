<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_options.php 2033 2021-04-05 09:31:30Z robert0609 $
 */

/**
 * Description of Ccms_options
 *
 * Provides the setup and config options available.
 *
 * @author robert0609
 */

class Ccms_options extends Ccms_html {

	private static $std_colours = false;
	private static $lc_std_colours = false;	// lowercase, searchable version and cache it
	private static $contrast_text_colours = false;	// cache it
	private static $image_lists = false;	// cache it

	private static $font_families = array(
		"inherit",
		"'Courier New', Courier, monospace",
		"Verdana, Arial, Helvetica, sans-serif",
		"Verdana, Geneva, sans-serif",
		"helvetica, Arial, sans-serif",
		"'Lucida Grande', Helvetica, Arial",
		"'Lucida Calligraphy Italic', 'URW Chancery L', Arial",
		"'Lucida Handwriting Italic', 'URW Chancery L', Arial",
		"'Comic Sans MS', Arial",
		"Arial, Helvetica, sans-serif",
		"'Times New Roman', Times, serif",
		"Techno, Impact, sans-serif",
		"Helvetica, Arial",
		"'Trebuchet MS', sans-serif",
		"Terminal, monospace",
		"VT-100, monospace",
		"Textile, cursive",
		"Arial Black",
		"Impact",
		"sans-serif",
		);

	private static $font_styles = array(
		'inherit',
		'normal',
		'italic',
		'oblique',
		);

	private static $font_weights = array(
		'inherit',
		'normal',
		'bold',
		'bolder',
		'lighter',
		'100',
		'200',
		'300',
		'400',
		'500',
		'600',
		'700',
		'800',
		'900',
		);

	protected static $dyn_cntl = false;
	protected static $dyn_cntl_cl_plugins = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function is_dyn_init() {
		self::$dyn_cntl = INI_DYNAMIC_CONTROL_APP_BOOL;
		if(!self::$dyn_cntl) {
			self::$dyn_cntl_cl_plugins = false;
			return false;
			} // if
		return true;
		} // is_dyn_init()

	protected static function get_dyn_cl_methods() {
		if(!self::is_dyn_init()) return false;
		if(strlen(INI_DYNAMIC_CONTROL_APP_PLUGINS) < 4) {
			self::$dyn_cntl_cl_plugins = false;
			return false;
			} // if
		if(self::$dyn_cntl_cl_plugins) return self::$dyn_cntl_cl_plugins;
		self::$dyn_cntl_cl_plugins = explode(':',INI_DYNAMIC_CONTROL_APP_PLUGINS);
		return self::$dyn_cntl_cl_plugins;
		} // get_dyn_cl_methods()

	protected static function get_dyn_ctl_method($key) {
		if(!self::$dyn_cntl_cl_plugins) return false;
		foreach(self::$dyn_cntl_cl_plugins as $pl) {
			if(!Ccms_autoloader::find_plugin($pl)) continue;
			$func = (method_exists($pl,'get_dyn_method_by_key') ? $pl::get_dyn_method_by_key($key):false);
			if($func === false) continue; // next $pl
			$macro = self::MACRO_DELIM . $func . self::MACRO_DELIM;
			$text = (method_exists($pl,'get_title_by_key') ? $pl::get_title_by_key($key):$func);
			$dyn_ctl = array(
				'func' => $func,
				'macro' => $macro,
				'text' => $text,
				);
			if(!$dyn_ctl['func']) continue;
			return $dyn_ctl;
			} // foreach
		return false;
		} // get_dyn_ctl_method()

	protected static function make_image_list($path_type = '') {
		if(empty($path_type)) $path_type = CMS_WS_IMAGES_DIR . '';
		$ops_dir_list = Ccms_autoloader::get_ops_dirs_list();
		if(preg_match('/background/',$path_type)) {
			$idx = 'backgrounds';
			$paths = &$ops_dir_list['backgrounds'];
			} // if
		else if(preg_match('/icons/',$path_type)) {
			$idx = 'icons';
			$paths = &$ops_dir_list['icons'];
			} // else if
		else {
			$idx = 'images';
			$paths = &$ops_dir_list['images'];
			} // else

		if(!isset(self::$image_lists[$idx])) {	// cache it
			$image_list = array();
			foreach($paths as $path) {
				$base_path = DOCROOT_FS_BASE_DIR . $path;
				if(!is_dir($base_path)) continue;
				if(($dh = opendir($base_path)) &&
					(!is_null($dh))) {
					while (($file = readdir($dh)) !== false) {
						if(preg_match('/\.png$|\.jpg$|\.jpeg$|\.gif$/',$file))
							$image_list[] = self::clean_path ($path . '/' . $file);
						} // while
					closedir($dh);
					} // if
				} // foreach
			sort($image_list);
			self::$image_lists[$idx] = $image_list;
			} // if
		return self::$image_lists[$idx];
	} // make_image_list()

	protected static function make_ws_image_select_options() {
		$paths = array(
			ETC_WS_IMAGES_DIR,
			ETC_WS_BACKGROUNDS_DIR,
			ETC_WS_ICONS_DIR,
			);
		$img_list = array();
		foreach($paths as $path) {
			if($dh = opendir(DOCROOT_FS_BASE_DIR . $path)) {
				while (($file = readdir($dh)) !== false) {
					if(preg_match('/\.png|\.jpg|\.jpeg|\.gif/',$file)) $img_list[] = $path . $file;
					} // while
				closedir($dh);
				} // if
			} // foreach
		sort($img_list);
		return self::add_svalues_options(array_merge(array('-- Select Image URI to Copy --'),$img_list),'-1');
	} // make_ws_image_select_options()

	public static function get_ws_image_uri_selection() {
		$text = '<select id="ws_image_list_id" name="ws_image_list" size="1" onchange="javascript:cms_get_selected_ws_image();">' . self::make_ws_image_select_options() . '</select>';
		return $text;
		} // get_ws_image_uri_selection()

	protected static function make_image_select_options($path,$value,$icon_flg = false) {
		$img_path = Ccms_config::get_img_path($value,$path,$icon_flg);
		$img_list = self::make_image_list($path);

		$text = PHP_EOL . '<option value=""' . (($value == '') ? ' SELECTED' : '') . '>&nbsp;' . ($icon_flg ? '(No Icon)':'(No Image)') . (($value == '') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
		// $text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
		foreach ($img_list as $img) {
			// put it together
			$text .= PHP_EOL . '<option value="' . htmlentities($img) . '"' . (($img_path == $img) ? ' SELECTED' : '') . '>';
			if($value == $img) $text .= '&nbsp;' . $img . ' **';
			else $text .= '&nbsp;' . $img . '&nbsp;';
			$text .= '</option>' . PHP_EOL;
			} // foreach
		return $text;
		} // make_image_select_options()

	public static function make_uploaded_image_select_options($value) {
		$path = ETC_WS_IMAGES_DIR;
		if(!self::chkdir(DOCROOT_FS_BASE_DIR . $path)) return false;
		return self::make_image_select_options($path,$value);
	} // make_uploaded_image_select_options()

	public static function make_bkgnd_image_select_options($value) {
		$path = ETC_WS_BACKGROUNDS_DIR;
		if(!self::chkdir(DOCROOT_FS_BASE_DIR . $path)) return false;
		return self::make_image_select_options($path,$value);
	} // make_bkgnd_image_select_options()

	public static function make_icon_select_options($value) {
		$path = ETC_WS_ICONS_DIR;
		if(!self::chkdir(DOCROOT_FS_BASE_DIR . $path)) return false;
		return self::make_image_select_options($path,$value,true);
	} // make_icon_select_options()

	public static function get_row_bkgnd_colour($even, $bk, $chg = 0.15) {
		self::make_colours();
		$chg = (float)$chg;
		if(is_numeric($bk)) $v = (int)$bk;
		if(is_string($bk)) {
			if((strlen($bk) == 7) &&
				(substr($bk, 0,1) == '#')) {	// hex value
				$v = hexdec(substr($bk,1));
				$r = (($v >> 16) & 0xff);
				$g = (($v >> 8) & 0xff);
				$b = ($v & 0xff);
				} // if
			else if((strlen($bk) == 4) &&
				(substr($bk, 0,1) == '#')) {	// hex value
				$v = hexdec(substr($bk,1));
				$r = (($v >> 4) & 0xf0);
				$g = ($v & 0xf0);
				$b = (($v << 4) & 0xf0);
				} // if
			else {
				$bk = strtolower($bk);
				if(key_exists($bk, self::$lc_std_colours)) {
					$v = hexdec(substr(self::$lc_std_colours[$bk],1));
					$r = (($v >> 16) & 0xff);
					$g = (($v >> 8) & 0xff);
					$b = ($v & 0xff);
					} // if
				else return $bk;	// a colour string, @TODO loolup colour
				} // else
			} // if

		$intensity = $r + $g + $b;

		if($even) { // make brighter
			$gain = 1.00 + (float)$chg;
			$offset = (255.00 - (float)$intensity) * (float)$chg / 3.0;
			} // if
		else {	// make darker
			$gain = 1.00 - (float)$chg;
			$offset = (255.00 - (float)$intensity) * (float)$chg / -3.0;
			} // else

		$rr = ((float)$r * $gain) + $offset;
		if($rr > 255.00) $r = 255;
		else if($rr < 0.00) $r = 0;
		else $r = (int)$rr;

		$gg = ((float)$g * $gain) + $offset;
		if($gg > 255.00) $g = 255;
		else if($gg < 0.00) $g = 0;
		else $g = (int)$gg;

		$bb = ((float)$b * $gain) + $offset;
		if($bb > 255.00) $b = 255;
		else if($bb < 0.00) $b = 0;
		else $b = (int)$bb;

		$new_bk = sprintf('#%02X%02X%02X',$r,$g,$b);

		return $new_bk;
		} // get_row_bkgnd_colour()

	private static function make_colours($add_rgb = true) {
		if(empty(self::$std_colours)) self::$std_colours = parse_ini_file(CMS_FS_CMS_STD_COLOURS);
		if(empty(self::$contrast_text_colours)) { // work out text colours and cache them
			self::$contrast_text_colours = array();
			self::$lc_std_colours = array();
			$cc_ary = array('CMS_C_CUSTOM_COLOURS','INI_CUSTOM_COLOURS');
			foreach($cc_ary as $ccc) {
				if((defined($ccc)) && (strlen(constant($ccc)) > 6)) {
					if($cc = self::unserialize_string2arry(constant($ccc),':','=')) {
						foreach($cc as $c) {
							if(!is_array($c)) continue;	// bad entry
							if(!$add_rgb) $n = trim($c[0]);
							else $n = 'cc:  #' . strtoupper(trim($c[1]," \t\n\r\0\x0B#")) . ' ' . trim($c[0]);
							$v = '#' . trim($c[1]," \t\n\r\0\x0B#");
							if((isset(self::$lc_std_colours[$n])) && (self::$lc_std_colours[$n] = $v)) continue;	// dont double up
							self::$lc_std_colours[$n] = $v;
							} // foreach
						} // if
					} // if
				} // foreach
			foreach (self::$std_colours as $r => $v) {
				if(!$add_rgb) $n = trim($r);
				else $n = 'std: ' . strtoupper($v) . ' ' . trim($r);
				self::$lc_std_colours[$n] = $v;
				} // foreach
			ksort(self::$lc_std_colours);
			foreach (self::$lc_std_colours as $n => $v) {
				$h = substr($v,1);	// $h from self::$std_colours
				if(!preg_match('/^[ # ]*[0-9a-f]{6,6}$/i',$h)) {
					// typically get a string like "[#]red" or "[#]black" from custom colours
					$s = preg_replace('/^[ # ]*/','',$h);
					// now lookup $s in self::$lc_std_colours
					$sf = false;	// flg
					foreach(self::$std_colours as $sn => $sh) {
						if(!strcasecmp($s,$sn)) { // found
							$h = $sh;
							$sf = true;
							break;
							} // if
						} // foreach
					if(!$sf) continue;	// no good
					} // if
				$h = hexdec(preg_replace('/^[ # ]*/','',$h));
				$i = (($h >> 16) & 0xff) + (($h >> 8) & 0xff) + ($h & 0xff);	// intensity
				if($i > (3 * 96)) $c = 'black';	// contrast !!
				else $c = 'white';
				// self::$contrast_text_colours[$n] = $c;
				self::$contrast_text_colours[$n] = $c;
				} // foreach
			} // if
		} // make_colours()

	protected static function make_colour_select_options($value,$excluded_array = '') {
		//@TODO see "https://support.mozilla.org/en-US/questions/1141257" about option colour problems
		self::make_colours();
		if((empty($excluded_array))) $excluded_array = array();
		$value = strtolower($value);
		if(!in_array('default', $excluded_array)) {
			$text = PHP_EOL . '<option value="">  (Use Default) </option>' . PHP_EOL;	// special case
			} // if
		if(!in_array('inherit',$excluded_array)) {
			$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			} // if
		$pat = '/[\"\s]{1,}' . addcslashes($value,':/.()') . '[\s\"]{1,}/i';
		foreach (self::$lc_std_colours as $n => $v) {
			if(in_array($v, $excluded_array)) continue;
			if(isset(self::$contrast_text_colours[$n])) {
				$c = self::$contrast_text_colours[$n];
				if(in_array($c, $excluded_array)) continue;
				} // if
			else $c = 'black';

			// put it together
			$selected = '';
			if(preg_match($pat,'"' . $n . '"'))	// add quotes to make it work anywhere and not match grey to darkgrey
				$selected = ' SELECTED';
			else if(preg_match($pat,'"' . $v . '"'))
				$selected = ' SELECTED';

			$text .= PHP_EOL . '<option value="' . htmlentities($v) . '"' . $selected;
			$text .= ' style="background-color: ' . $v . '; color: ' . $c . '; display: list-item;">';
			if((stripos($n,$value) !== false) || (!strcasecmp($value,$v))) $text .= '&nbsp;' . $n . ' **';
			else $text .= '&nbsp;' . $n . '&nbsp;';
			$text .= '</option>' . PHP_EOL;
			} // foreach
		return $text;
	} // make_colour_select_options()

	public static function count_sel_opts(&$options, $exclude = -1) {
		// return count of options less any excluded values
		$cnt = 0;
		foreach($options as $n => &$v) {
			if(is_array($exclude)) {
				if(in_array($v,$exclude)) continue;
				} // if
			else if((int)$v == $exclude) continue;
			$cnt++;
			} // for
		return $cnt;
		} // count_selectable_options_count()

	public static function get_select_option_filter($id_select, $title = false, $drop_size = 0, $opts_cnt = -1, $class = '') {
		if(empty($id_select)) return '';
		if($drop_size < Ccms_edit::SEARCH_FILTER_DROP_SIZE_MIN) $drop_size = Ccms_edit::SEARCH_FILTER_DROP_SIZE_MIN;
		if(($opts_cnt > 0) && ($opts_cnt <= $drop_size)) return '';
		if(!empty($class)) $class = ' class="' . $class . '"';	// else ok
		else $class = ' class="std"';
		$text = PHP_EOL;
		$text .= '<div' . $class . ' style="display: inline-block;">' . PHP_EOL;
		$text .= '<label' . $class . '><input' . $class . ' type="text" id="id_filter_' . $id_select . '"' .
			//	' oninput="javascript:cms_filter_select_options(\'id_filter_' . $id_select . '\',\'' . $id_select . '\',\'id_filter_cnt_' . $id_select . '\');"' .
				' oninput="javascript:cms_filter_select_options(\'id_filter_' . $id_select . '\',\'' . $id_select . '\',\'id_filter_cnt_' . $id_select . '\');"' .
				' name="filters[' . $id_select . ']"' .
				' size="10"' .
				' placeholder="Filter"' .
				' value=""' .
				' data-dropsize="' . $drop_size . '"' .// html5 attribute, flag (-1 = match select width
				' title="' . (!empty($title) ? $title:'Enter select filter search keywords.') . '"/></label>' . PHP_EOL;
		$text .= '<span style="display: none; border: 1px solid lightgrey; margin: 2px; padding: 2px;" id="id_filter_cnt_' . $id_select . '" title="Found"></span>';
//		$text .= '<script type="text/javascript">' . PHP_EOL .
//				'	window.addEventListener("load", function() {' . PHP_EOL .
//				'		cms_filter_select_options(\'id_filter_' . $id_select . '\',\'' . $id_select . '\',\'id_filter_cnt_' . $id_select . '\');' . PHP_EOL .
//				'	});' . PHP_EOL .
//				'</script>' . PHP_EOL;
		$text .= '</div>' . PHP_EOL;
		// $text .= '<br>' . PHP_EOL;
		return $text;
		} // get_select_option_filter()

	private static function get_grid_headings(&$col_heads, $val_sep = ':') {
		// returns an array of numerically indexed heading data
		if(empty($col_heads)) return false;
		if(!is_array($col_heads)) $col_hds_raw = explode($val_sep,$col_heads);	// self::unserialize_string2arry($col_heads,$val_sep,false);
		else $col_hds_raw = $col_heads;

		$col_hds_cntl = array();
		$idx = 0;
		foreach($col_hds_raw as $k => $v) {
			if(!is_numeric($k))	continue;	// only the LTR sequence
			if(is_string($v)) {
				$col_hds_cntl[$idx]['hd_text'] = $v;
				$col_hds_cntl[$idx]['name'] = $idx;
				$col_hds_cntl[$idx]['type'] = 'text';	// text input
				$col_hds_cntl[$idx]['inp_params'] = ' style="width: 95%;"';
				} // if
			else {
				if(isset($v['hd_text'])) $col_hds_cntl[$idx]['hd_text'] = $v['hd_text'];
				else if(isset($v['text'])) $col_hds_cntl[$idx]['hd_text'] = $v['text'];
				if((isset($v['name'])) && (!empty($v['name']))) $col_hds_cntl[$idx]['name'] = $v['name'];
				else $col_hds_cntl[$idx]['name'] = $idx;
				if(isset($v['type'])) $col_hds_cntl[$idx]['type'] = $v['type'];
				else $col_hds_cntl[$idx]['type'] = 'text';
				if(isset($v['options'])) $col_hds_cntl[$idx]['options'] = $v['options'];
				if(isset($v['title'])) $col_hds_cntl[$idx]['title'] = $v['title'];
				else $col_hds_cntl[$idx]['title'] = '';
				if(isset($v['inp_params'])) $col_hds_cntl[$idx]['inp_params'] = $v['inp_params'];
				else if(isset($v['params'])) $col_hds_cntl[$idx]['inp_params'] = $v['params'];
				else $col_hds_cntl[$idx]['inp_params'] = ' style="width: 95%;"';
				}
			if(preg_match('/URI|URL/i', $col_hds_cntl[$idx]['hd_text'])) $uris = Ccms::get_ws_links(' -- Select -- ',false);
			else $uris = '';
			$col_hds_cntl[$idx]['uris'] = $uris;

			$idx++;
			} // foreach

		return $col_hds_cntl;
		} // get_grid_headings()

	public static function multi_row_input_get_form_elems(&$data_rows,&$name,$value,$col_heads,$class=false) {
		if(empty($class)) $class = 'page_config';
		$text = '';
		$col_cntl = self::get_grid_headings($col_heads);
		$text .= '<table class="' . $class . '">' . PHP_EOL;
		$text .= '<tr class="' . $class . '">';
		for($i = 0; $i < count($col_cntl); $i++) $text .= '<th class="' . $class . '">' . $col_cntl[$i]['hd_text'] . '</th>';
		$text .= '</tr>' . PHP_EOL;
		$row = 0;
		foreach($data_rows as &$p) {
			$text .= '<tr class="' . (($row++ & 1) ? 'page_config_even':'page_config_odd') . '">';
			$text .= '<td class="' . $class . '" valign="top" title="Type: ' . $p['name'] . '">' . $p['title'] . '</td>';
			$text .= '<td class="' . $class . '" valign="top" style="text-align: center;" title="Check to enable."><input type="checkbox" name="' . $name . '[' . $p['name'] . ']"' . (($p['enabled']) ? ' CHECKED':'') . '/></td>';
			$text .= '<td class="' . $class . '" valign="top">' . $p['description'] . '</td>';
			$text .= '</tr>' . PHP_EOL;
			} // foreach
		$text .= '</table>' . PHP_EOL;
		return $text;
		} // multi_row_input_get_form_elems()

	public static function multi_row_get_form_elems($name,$value,$avail,$val_sep) {
		$text = '';
		if((isset($_POST[$name])) && (!empty($_POST[$name])) && (is_array($_POST[$name]))) {
			$text_a = $_POST[$name];
			$text_p = array();
			foreach($text_a as $p => &$e) {
				if($e == 'on') {
					if(empty($avail)) $text_p[] = $p;
					else if(isset($avail[$p])) $text_p[] = $p;	// stop rubbish getting thru
					} // if
				} // foreach
			$text = implode($val_sep,$text_p);
			} // if
		else if(!empty($value)) {	// analyse the data
			if(is_array($value)) {
				$text = '';
				foreach($value as $k => $v) {
					if(strlen($text) > 0) $text .= $val_sep;
					if($v == 'on') $text .= $k;	// checkbox return
					else $text .= $v;	// a list return
					} // foreach
				} // if
			else $text = $value;
			} // else if
		return $text;
		} // multi_row_get_form_elems()

	protected static function get_ini_cms_input_ctl($ini_key) {
		$grid_inputs = array(
			'CUSTOM_COLOURS' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Name:Hex RGB Colour',
				'val_sep' => ':',
				'data_sep' => '=',
				),
			'CUSTOM_FONTS' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Font Name',
				'val_sep' => ':',
				'data_sep' => '',
				),
			'ALLOWED_LOGIN_IPS' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'CIDRs Allowed to Login',
				'val_sep' => ',',
				'data_sep' => '',
				),
			'CAN_TEST_APPS_CIDR' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Network or IP Address',
				'val_sep' => ',',
				'data_sep' => '',
				),
			'LDAP_SERVER_URI' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Host or IP Address',
				'val_sep' => ',',
				'data_sep' => '',
				),
			'ONLINE_MSGS_LEVEL' => array(	// ini_key to match
				'type' => 'multi_select',
				'col_heads' => 'Type:Show:Description',
				'val_sep' => ':',
				'data_sep' => '',
				'options_func' => 'self::get_online_msgs_options',
				),
			// the numbers
			'CONTENT_CACHE_TTL' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="300" step="10" max="7776000"',
				),
			'SESSIONS_DATA_TIMEOUT_DAYS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="7" step="1" max="720"',
				),
			'SESSIONS_USER_TIMEOUT_SECS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="300" step="10" max="7776000"',
				),
			'SESSIONS_COOKIE_TIMEOUT_SECS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="7200" step="100" max="31104000"',
				),
			);
		if(empty($ini_key)) return $grid_inputs;
		if(isset($grid_inputs[$ini_key])) return $grid_inputs[$ini_key];
		return false;	// not found
		} // get_ini_cms_input_ctl()

	public static function convert_ini_cms_form_input(&$ini_ary) {
		foreach($ini_ary as $sect_name => &$s2c) {
			foreach($s2c as $k => &$v) {
				$val = $v;
				if($c = self::get_ini_cms_input_ctl($k)) {
					switch($c['type']) {
					case 'multi_select':
						$v = self::multi_row_get_form_elems($k,$v,'',$c['val_sep']);
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					case 'multi_input':
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					case 'number':
						$val = $v;
						break;
					default:
						break;
						} // switch
					} // if
				else if(is_array($v)) {
					if(in_array('',$v)) $val = '';	// use default
					else $val = implode(' ',$v);
					} // if
				$s2c[$k] = $val;	// ?? stripslashes($val);
				} // foreach
			} // foreach
		return $ini_ary;
		} // convert_ini_cms_form_input()

	public static function grid_show($value,&$col_heads,$val_sep,$data_sep,$class=false) {
		if(empty($class)) $class = 'page_config';
		$col_cntl = self::get_grid_headings($col_heads);
		if((empty($col_cntl)) || (count($col_cntl) < 1)) return '(empty)';

		$text = array();
		$text[] = '<table class="' . $class . '">';
		$h_c = count($col_cntl);
		$text[] = '	<tr class="' . $class . '">';
		for($c = 0; $c < $h_c; $c++) {
			$text[] = '		<th class="' . $class . '">' . $col_cntl[$c]['hd_text'] . '</th>';
			} // for
		$text[] = '	</tr>';
		$grid = self::unserialize_string2arry($value,$val_sep,$data_sep);
		if($grid){
			for($r = 0; $r < count($grid); $r++) {
				$text[] = '	<tr class="' . (($r & 1) ? 'page_config_odd':'page_config_even') . '">';
				for($c = 0; $c < $h_c; $c++) {
					$text[] = '		<td class="' . $class . '" valign="top">' . (isset($grid[$r][$c]) ? $grid[$r][$c]:'') . '</td>';
					} // for
				$text[] = '	</tr>';
				} // for
			} // if
		else $text[] = '<tr class="' . $class . '"><td class="' . $class . '" colspan="'. $h_c . '">(No values set)</td></tr>';
		$text[] = '</table>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // grid_show()

	public static function grid_input_form_elems(&$name,$value,&$col_heads,$val_sep,$data_sep,$class=false) {
		$col_cntl = self::get_grid_headings($col_heads);
		if((empty($col_cntl)) || (count($col_cntl) < 1)) return '';
		if(empty($class)) $class = 'page_config';

		$grid = array();
		if(!empty($value)) {
			if(!is_array($value)) $grid = self::unserialize_string2arry($value,$val_sep,$data_sep);
			else $grid = $value;
			} // if
		if((!$grid) || (!is_array($grid))) $grid = array();	// empty
		else $grid = self::clean_array($grid,false);	// clean out dead rows

		$new_entries = 1;
		$h_c = count($col_cntl);
		$r_c = (count($grid) + $new_entries);
		$img_arrow_params = ' width="15" height="15"';

		$text = array();
		$text[] = '';
		static $sent_gr_elem_tw_functions = false;
		if(!$sent_gr_elem_tw_functions) {
			$sent_gr_elem_tw_functions = true;
			$images_dir = CMS_WS_IMAGES_DIR;
			$debug = (Ccms::is_debug() ? 'true':'false');
			$text[] =<<< EOTGIFEJS

			<script type="text/javascript">

				Ccms_gife.debug = function() { return {$debug}; };
				Ccms_gife.up_arrow_url = function() { return '<img alt="up arrrow" src="{$images_dir}arrow-up.gif"{$img_arrow_params}/>'; };
				Ccms_gife.down_arrow_url = function() { return '<img alt="down arrrow" src="{$images_dir}arrow-down.gif"{$img_arrow_params}/>'; };

			</script>

EOTGIFEJS;
			} // if

		$text[] = '<table class="' . $class . '" id="' . $name . '_table">';
		$text[] = '	<tr class="' . $class . '">';
		$text[] = '		<th class="' . $class . '"' .
				' title="Order of entries.\n' .
				'Empty cell will delete the row.\n'.
				'New rows are added as required."' .
				'>' . '*' . '</th>';	// @TODO need a small circle I icon here
		for($c = 0; $c < $h_c; $c++) {
			if(!isset($col_cntl[$c])) continue;
			$text[] = '		<th class="' . $class . '"' .
				(!empty($col_cntl[$c]['title']) ? ' title="' . $col_cntl[$c]['title'] . '"':'') .
				'>' .
				$col_cntl[$c]['hd_text'] .
				'</th>';
			} // for
		$text[] = '		<td class="' . $class . '" title="Move up">' . '&nbsp;' . '</td>';
		$text[] = '		<td class="' . $class . '" title="Move down">' . '&nbsp;' . '</td>';
		$text[] = '	</tr>';

		for($r = 0; $r < $r_c; $r++) {
			$text[] = '	<tr class="' . $class . '" id="' . $name . '_table_row[' . $r . ']">';
			$text[] = '		<th class="' . $class . '" id="' . $name . '_table_cell[' . $r . '][' . 0 . ']">' . ($r + 1) . '</th>';
			for($c = 0; $c < $h_c; $c++) {
				if(!isset($col_cntl[$c])) continue;
				$text[] = '		<td class="' . $class . '" id="' . $name . '_table_cell[' . ($r + 0) . '][' . ($c + 1) . ']">';
				if(!empty($col_cntl[$c]['uris'])) {
					$text[] = '			<select id="' . $name . '[' . $r . '][' . $c . ']"' .
						' name="' . $name . '[' . $r . '][' . ((isset($col_cntl[$c]['name']) && !empty($col_cntl[$c]['name'])) ? $col_cntl[$c]['name']:$c) . ']"' .
						' onchange="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($col_cntl[$c]['inp_params']) ? $col_cntl[$c]['inp_params']:' style="width: 95%;"') .
						'>';
					$text[] = Ccms::add_svalues_options($col_cntl[$c]['uris'],(isset($grid[$r][$c]) ? $grid[$r][$c]:''));
					$text[] = '</select>';
					} // if
				else if($col_cntl[$c]['type'] == 'select') {
					$name_suf = ((isset($col_cntl[$c]['name']) && !empty($col_cntl[$c]['name'])) ? $col_cntl[$c]['name']:$c);
					$text[] = '			<select id="' . $name . '[' . $r . '][' . $c . ']"' .
						' name="' . $name . '[' . $r . '][' . $name_suf . ']"' .
						' onchange="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($col_cntl[$c]['inp_params']) ? $col_cntl[$c]['inp_params']:' style="width: 95%;"') .
						'>';
					$text[] = Ccms::add_svalues_options($col_cntl[$c]['options'],(isset($grid[$r][$name_suf]) ? $grid[$r][$name_suf]:''));
					$text[] = '</select>';
					} // else if
				else if($col_cntl[$c]['type'] == 'checkbox') {
					$name_suf = ((isset($col_cntl[$c]['name']) && !empty($col_cntl[$c]['name'])) ? $col_cntl[$c]['name']:$c);
					$text[] = '			<input id="' . $name . '[' . $r . '][' . $c . ']"' .
						' type="' . $col_cntl[$c]['type'] . '"' .
						' name="' . $name . '[' . $r . '][' . $name_suf . ']"' .
						' oninput="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($col_cntl[$c]['inp_params']) ? $col_cntl[$c]['inp_params']:' style="width: 95%;"') .
						(isset($grid[$r][$name_suf]) ? ' CHECKED':'') .
						'/>';
					} // else if
				else {
					$name_suf = ((isset($col_cntl[$c]['name']) && !empty($col_cntl[$c]['name'])) ? $col_cntl[$c]['name']:$c);
					$text[] = '			<input id="' . $name . '[' . $r . '][' . $c . ']"' .
						' type="' . $col_cntl[$c]['type'] . '"' .
						' name="' . $name . '[' . $r . '][' . $name_suf . ']"' .
						' value="' . (isset($grid[$r][$name_suf]) ? $grid[$r][$name_suf]:'') . '" autocapitalize="off"' .
						' oninput="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($col_cntl[$c]['inp_params']) ? $col_cntl[$c]['inp_params']:' style="width: 95%;"') .
						'/>';
					} // else
				$text[] = '		</td>';
				} // for
			$text[] = '		<td class="' . $class . '" id="' . $name . '_table_cell[' . $r . '][' . ($h_c + 1) . ']">';
			if(($r >= 1) && ($r < (count($grid) + $new_entries - 0))) {
				$text[] = '			<a onclick="Ccms_gife.move_up_tabrow(\'' . $name . '\',' . $r . ',' . $r_c . ',' . $h_c . ');" title="Move row up to ' . ($r - 1 + 1) . '">';
				$text[] = '				<img alt="up arrrow" src="' . CMS_WS_IMAGES_DIR . 'arrow-up.gif"' . $img_arrow_params . '/>';
				$text[] = '			</a>';
				} // if
			$text[] = '		</td>';
			$text[] = '		<td class="' . $class . '" id="' . $name . '_table_cell[' . $r . '][' . ($h_c + 2) . ']">';
			if(($r >= 0) && ($r < (count($grid) + $new_entries - 1))) {
				$text[] = '			<a onclick="Ccms_gife.move_down_tabrow(\'' . $name . '\',' . $r . ',' . $r_c . ',' . $h_c . ');" title="Move row down to ' . ($r + 1 + 1) . '">';
				$text[] = '				<img alt="down arrrow" src="' . CMS_WS_IMAGES_DIR . 'arrow-down.gif"' . $img_arrow_params . '/>';
				$text[] = '			</a>';
				} // if
			$text[] = '		</td>';
			$text[] = '	</tr>';
			} // for
		$text[] = '</table>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // grid_input_form_elems()

	public static function grid_multi_select_form_elems(&$name,$value,&$col_heads,$val_sep,$data_sep,$options_func) {
		$options = call_user_func($options_func,$value);
		$list = array();
		foreach($options as &$l) {	// convert
			$list[($l['value'])] = array(
				'class' => '',
				'name' => $l['value'],
				'title' => $l['value'],
				'enabled' => $l['selected'],
				'description' => $l['text'],
				);
			} // foreach
		ksort($list);
		return self::multi_row_input_get_form_elems($list,$name,$value,$col_heads);
		} // grid_multi_select_form_elems()

	public static function grid_get_form_elems($name,$value,$val_sep,$data_sep) {
		// return $value;	// test
		$text = '';
		$dotted = preg_replace('/\]\[/','.',$name);
		$dotted = preg_replace('/[\[]/','.',$dotted);
		$dotted = preg_replace('/[\]]/','',$dotted);
		$text_n = self::getDottedKeys2Var($_POST, $dotted);
		if(!is_null($text_n)) {
			$text_a = array();
			for($r = 0; $r < count($text_n); $r++) {	// clean out empty entries
				$mt = false;
				if(empty($text_n[$r][0])) continue;
				for($c = 0; $c < count($text_n[$r]); $c++) {
					if((!isset($text_n[$r][$c])) || ($text_n[$r][$c] == ' -- Select -- ')) $mt = true;	// ignore row
					} // for
				if(!$mt) $text_a[] = $text_n[$r];
				} // for
			if(count($text_a) > 0) $text = serialize($text_a);
			} // if
		else if(!empty($value)) $text = $value;
		return $text;
		} // grid_get_form_elems()

	protected static function add_increment_vw_series(&$svalues,$strt = 0.10,$size = 25,$factor = 1.15) {
		// add an incremental veiwport series
		$st = $strt;
		if($size < 0) $size = abs($size);
		if($size > 100) $size = 100;
		for($i = 1; $i <= $size; $i++) {	// do an incremental increase
			$svalues[] = sprintf("%0.2f",$st) . 'vw';
			$st *= $factor;	// inc factor
			} // for
		} // add_increment_vw_series()

	protected static function get_incrd_options($min,$max,$step,$suffix = '', $preload = array()) {
		$svalues = (is_array($preload) ? $preload:array());
		if($step == 0) return $svalues;
		for($i = $min; $i < $max; $i += $step) {
			$svalues[] = $i . $suffix;
			} // for
		if($i >= $max) {
			$svalues[] = $max . $suffix;
			} // if
		return $svalues;
		} // get_incrd_options()

	protected static function get_expon_options($min,$max,$expon,$prec,$suffix = '', $preload = array()) {
		$svalues = (is_array($preload) ? $preload:array());
		if(($min == 0.0000000) || ($expon == 1.000000))
			return self::get_incrd_options($min,$max,$expon,$suffix,$preload);

		if($expon < 1.0000000) $expon += 1.0000000;
		$value = $min;
		while($value < $max) {
			if(is_float($value)) $svalues[] = round($value,$prec) . $suffix;
			else $svalues[] = $value . $suffix;
			$value *= $expon;
			} // while
		if($value >= $max) {
			if(is_float($max)) $svalues[] = round($max,$prec) . $suffix;
			else $svalues[] = $max . $suffix;
			} // if
		return $svalues;
		} // get_expon_options()

	public static function make_type_input_selr($name,$ini_key,$value,$size = 30,$just_list = false,$readonly = false, $use_typedef_as_default = false, $required = false) {
		$text = PHP_EOL;
		$id = 'id_' . $name;
		if(($required) && ($readonly)) $required = false;	// stop a lock up

		// do the grid layout type first
		if(($c = self::get_ini_cms_input_ctl($ini_key)) ||
			($c = Ccms_apps::get_ini_apps_input_ctl($ini_key))) {
			switch($c['type']) {
			case 'multi_select':
				$options_func = (!empty($c['class']) ? $c['class'] . '::':'') . $c['options_func'];
				$text .= self::grid_multi_select_form_elems($name, $value, $c['col_heads'], $c['val_sep'], $c['data_sep'],$options_func);
				break;
			case 'multi_input':
				$text .= self::grid_input_form_elems($name, $value, $c['col_heads'], $c['val_sep'], $c['data_sep']);
				break;
			case 'number':
				$text .= '<input type="number" name="' . $name . '" value="' . $value . '" ' . $c['params'] . '>' . PHP_EOL;
				break;
			default:
				break;
				} // switch
			if($just_list) return '';	// anything
			return $text;
			} // if

		// now the standard (obvious) types
		if(substr($ini_key,-11) == 'FONT_FAMILY') {	// multiple box for font family
			if($just_list) return false;
			if((defined('INI_CUSTOM_FONTS')) && (strlen(INI_CUSTOM_FONTS) > 4)) {
				$cf = explode(':', INI_CUSTOM_FONTS);
				foreach($cf as $f) {
					// $f = str_replace("''", "'",("'" . $f . "'"));
					$f = str_replace("''", "'",$f);
					$f = stripslashes($f);
					if(in_array($f,self::$font_families)) continue;	// dont double up
					self::$font_families[] = $f;
					} // foreach
				// sort(self::$font_families);
				} // if
			natsort(self::$font_families);

			$text .= self::get_select_option_filter($id, 'Use to find font families.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" class="std" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value=""' . (empty($ff) ? ' SELECTED':'') . '> -- default -- </option>';
			//$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case

			foreach(self::$font_families as $ff) {
				$text .= PHP_EOL . '<option value="' . rawurldecode($ff) . '"' . ((!strcasecmp($value,$ff)) ? ' SELECTED':'') . '>' . $ff. ((!strcasecmp($value,$ff)) ? ' **':'') . '</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key,-10) == 'FONT_STYLE') {	// multiple box for font style
			if($just_list) return false;
			$text .= self::get_select_option_filter($id, 'Use to find font style.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value=""' . (empty($ff) ? ' SELECTED':'') . '> -- default -- </option>';
			//$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			foreach(self::$font_styles as $ff) {
				$text .= PHP_EOL . '<option value="' . rawurldecode($ff) . '"' . ((!strcasecmp($value,$ff)) ? ' SELECTED':'') . '>' . $ff. ((!strcasecmp($value,$ff)) ? ' **':'') . '</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key,-11) == 'FONT_WEIGHT') {	// multiple box for font weight
			if($just_list) return false;
			$text .= self::get_select_option_filter($id, 'Use to find font weight.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value=""' . (empty($ff) ? ' SELECTED':'') . '> -- default -- </option>';
			//$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			foreach(self::$font_weights as $ff) {
				$text .= PHP_EOL . '<option value="' . rawurldecode($ff) . '"' . ((!strcasecmp($value,$ff)) ? ' SELECTED':'') . '>' . $ff. ((!strcasecmp($value,$ff)) ? ' **':'') . '</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key,-4) == 'BOOL') {	// a true / false box
			if($just_list) return array ('type' => 'BOOL','allowed' => array('true','false'));
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="false"'. (($value != 'true') ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;false&nbsp;&nbsp;&nbsp;&nbsp;</option>';
			$text .= PHP_EOL . '<option value="true"'. (($value == 'true') ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;true&nbsp;&nbsp;&nbsp;&nbsp;</option>';
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -2) == 'TZ') { // a time zone box
			$tzs = self::get_time_zones();
			if($just_list) return array ('type' => 'TZ','allowed' => $tzs);
			$text .= self::get_select_option_filter($id, 'Use to find time zones.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			foreach($tzs as $tz) {
				$text .= PHP_EOL . '<option value="' . htmlentities($tz) . '"' . (($value == $tz) ? ' SELECTED' : '') . ($required ? ' REQUIRED':'') . '>&nbsp;' . $tz . '&nbsp;</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -13) == 'LANGUAGE_CODE') { // a language code box
			$lcs = self::get_language_codes();
			if($just_list) return array ('type' => 'LANGUAGE_CODE','allowed' => $lcs);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			foreach($lcs as $lc) {
				$text .= PHP_EOL . '<option value="' . htmlentities($lc) . '"' . (($value == $lc) ? ' SELECTED' : '') . '>&nbsp;' . $lc . '&nbsp;</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -8) == 'CHAR_SET') { // a charset box
			$css = self::get_charsets();
			if($just_list) return array ('type' => 'CHAR_SET','allowed' => $css);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			foreach($css as $cs) {
				$text .= PHP_EOL . '<option value="' . htmlentities($cs) . '"' . (($value == $cs) ? ' SELECTED' : '') . '>&nbsp;' . $cs . '&nbsp;</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == 'COLOUR') { // a colour box
			if($just_list) return false;
			$text .= self::get_select_option_filter($id, 'Use to find colours.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . self::set_JS_colour_picker_onclick('id_' . $name) . '' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= self::make_colour_select_options($value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -10) == 'BKGD_IMAGE') { // a background image box
			if($just_list) return false;
			$cCMS_C = new Ccms_config();
			$text .= PHP_EOL . $cCMS_C->input_image($ini_key, $value, ETC_WS_BACKGROUNDS_DIR);
			} // if
		else if (substr($ini_key, -10) == 'LEFT_WIDTH') { // a width box
			if($just_list) return false;
			$svalues = self::get_incrd_options(50,300,5,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -11) == 'MODAL_WIDTH') { // width modal
			if($just_list) return false;
			$svalues = self::get_incrd_options(200,3000,50,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Modal Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == '_WIDTH') { // general width
			if($just_list) return false;
			$svalues = self::get_expon_options(50,3000,0.25,0,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -12) == 'MODAL_HEIGHT') { // width modal
			if($just_list) return false;
			$svalues = self::get_incrd_options(200,3000,50,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Modal Height</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
//		else if (substr($ini_key, -7) == '_HEIGHT') { // general height
//			if($just_list) return false;
//			$svalues = self::get_expon_options(50,3000,0.25,0,'px');
//			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
//			$text .= PHP_EOL . '<option value="" selected disabled>Height</option>';
//			$text .= self::add_svalues_options($svalues, $value);
//			$text .= PHP_EOL . '</select>' . PHP_EOL;
//			} // if
		else if (substr($ini_key, -7) == '_HEIGHT') { // a height box
			if($just_list) return false;
			$preload = self::get_expon_options(0.8,3.5,0.1,1,'em');
			$svalues = self::get_incrd_options(15,300,5,'px',$preload);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Height</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL . PHP_EOL;
			} // if
		else if ($ini_key == 'TOOLS_SEARCH_DEPTH_MAX') { // a width box
			if($just_list) return false;
			$svalues = self::get_incrd_options(1,5,1);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Depth</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL . PHP_EOL;
			} // if
		else if (substr($ini_key, -14) == 'LINKS_POSITION') { // nav bar link width specials
			if($just_list) return false;
			$preload = array('left','right','even','spread',);
			$preload2 = self::get_expon_options(8, 100, 1.25,0 , '%',$preload);
			$svalues = self::get_incrd_options(15,200,5,'px',$preload2);
			$text .= self::get_select_option_filter($id, 'Use to find nav bar options.');
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			// $text .= PHP_EOL . '<option value="" disabled selected hidden>Link Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == 'RADIUS') { // a radius box
			if($just_list) return false;
			$preload = self::get_expon_options(1,25,1.5,0,'px',array('0px'));
			$svalues = self::get_expon_options(0.5, 2.0, 1.15, 2, 'em', $preload);
			$text .= self::get_select_option_filter($id, 'Use to find radii.');
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Radius</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -9) == 'FONT_SIZE') { // a size box
			if($just_list) return false;
			$svalues = self::get_incrd_options(8,48,2,'px');
			self::add_increment_vw_series($svalues);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			//$text .= PHP_EOL . '<option value="" selected disabled>Size</option>';
			$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == 'LENGTH') { // a length box
			if($just_list) return false;
			$svalues = self::get_incrd_options(3,20,1);
			$text .= self::get_select_option_filter($id, 'Use to find radii.');
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			//$text .= PHP_EOL . '<option value="" disabled selected hidden>Size</option>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Length</option>' . PHP_EOL;	// special case
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key, -8) == '_PADDING') {
			if($just_list) return false;
			$svalues = self::get_incrd_options(0,25,1,'px');
			self::add_increment_vw_series($svalues);
			$text .= self::get_select_option_filter($id, 'Use to find radii.');
			$text .= PHP_EOL . '<select id="' . $id . '1" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Padding</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if(substr($ini_key, -7) == '_BORDER') { // a width, style, colour box
			if($just_list) return false;
			$vs = preg_split('/\s/',$value);
			if((empty($vs)) || (count($vs) != 3)) {	// should not happen
				$vs = array(
					'1px',
					'none',
					(preg_match('/^#[0-9a-f]{6,6}$/i',$value) ? $value:'black'),
					);
				} // if
			while(count($vs) < 3) $vs[] = '';
			$svalues = self::get_incrd_options(1,25,1,'px');
			self::add_increment_vw_series($svalues);
			$text .= '<div style="overflow-wrap: break-word;">' . PHP_EOL;
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= PHP_EOL . '<select id="' . $id . '1" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border width.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Width</option>';
			$text .= self::add_svalues_options($svalues, $vs[0]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;

			$svalues = array(
				'none', 'hidden', 'dotted', 'dashed', 'solid', 'double', 'groove', 'ridge', 'inset', 'outset',
				);
			$text .= PHP_EOL . '<select id="' . $id . '2" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border style.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Style</option>';
			$text .= self::add_svalues_options($svalues, $vs[1]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= 'Border width, style and colour.' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			// $text .= '<br>' . PHP_EOL;
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= self::get_select_option_filter($id . '3', 'Use to find border colours.');
			$text .= PHP_EOL . '<select id="' . $id . '3" onclick="javascript:cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border colour.">';
			$text .= self::make_colour_select_options($vs[2],array('inherit'));	// inherit causes a CSS warning
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			} // if
//		else if (substr($ini_key, -17) == 'ONLINE_MSGS_LEVEL') { // messages level selection
//			if($just_list) return false;
//			$options = self::get_online_msgs_options($value);
//			$text .= self::gen_selection_list($name . '[]', $options, 'size="' . count($options) . '" multiple' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '');
//			} // else if
		else if (substr($ini_key, -12) == '_APP_PLUGINS') { // looks in the APPS_FS_PLUGINS_DIR for dynamic control plugins
			if($just_list) return false;
			$dyn_pls = Ccms_apps::get_dyn_cntl_plugin_names();
			if(count($dyn_pls) > 0) {
				$options = array();
				$options[] = array(
						'value' => -1,
						'selected' => (empty($value) ? true:false),
						'params' => ' disabled selected hidden',
						'text' => '-- Select Dynamic Controller --',
						);
				$options[] = array(
						'value' => 0,
						'selected' => (empty($value) ? true:false),
						'text' => 'No Dynamic Controller',
						);
				$svalues = explode(',',$value);
				foreach($dyn_pls as $c) {
					$options[] = array(
							'value' => $c,
							'selected' => (in_array($c,$svalues) ? true:false),
							'text' => $c,
							);
					} // foreach
				$text = self::gen_selection_list($name . '[]',$options,'size="10" multiple' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '');
				} // if
			}//if
		else if ($ini_key == 'PASSWORD_REQUIRED_REGEX') { // get password check level
			if($just_list) return false;
			$options = array(
				array(
					'value' => -1,
					'selected' => (empty($value) ? true:false),
					'params' => ' disabled selected hidden',
					'text' => '-- Select Password Check --',
					),
				array(
					'value' => 'feeble',
					'selected' => (($value == 'feeble') ? true:false),
					'text' => 'Feeble',
					),
				array(
					'value' => 'weak',
					'selected' => (($value == 'weak') ? true:false),
					'text' => 'Weak',
					),
				array(
					'value' => 'medium',
					'selected' => (($value == 'medium') ? true:false),
					'text' => 'Medium',
					),
				array(
					'value' => 'strong',
					'selected' => (($value == 'strong') ? true:false),
					'text' => 'Strong',
					),
				);
			$text = self::gen_selection_list($name,$options,($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '');
			} // else if
		else if (substr($ini_key, -13) == 'SESSION_TYPE') { // session types box
			if($just_list) return false;
			$svalues = Ccms_sessions::get_session_types();
			if(defined('INI_LOCAL_SESSIONS_BOOL')) {	// early version settings
				$value = (INI_LOCAL_SESSIONS_BOOL ? 'PHP_FILE':'APACHE_FILE');
				self::addMsg("Upgrading LOCAL_SESSIONS_BOOL to SESSION_TYPE",'info');
				} // if
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if (substr($ini_key, -8) == '_EXT_INC') { // external code includde files
			if($just_list) return false;
			$text .= self::get_ext_code_dir_selection($name,$value);
			} // else if
		else if (substr($ini_key, -8) == '_SSL_INC') { // external SSL files
			if($just_list) return false;
			$text .= self::get_ssl_dir_selection($name,$value);
			} // else if
		else {
			if(is_array($value)) {
				$text .= '(Sub-Array)<input type="hidden" id="' . $id . '" name="' . $name . '" value="__SUB_ARRAY__"/>';
				} // if
			else if(($slen = strlen($value)) > $size) {	// a text area
				$text .= '<textarea id="' . $id . '" name="' . $name . '" cols="' . ($size + 2) . '" rows="' . (($slen / $size) + 2) . '"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>' . $value . '</textarea>';
				} // else if
			else if($use_typedef_as_default) {	// use the type of $value to set the default
				switch(strtolower($value)) {
				case 'false':
					$value = false;
					break;
				case 'true':
					$value = true;
					break;
				default:
					break;
					} // switch
				if(is_bool($value)) {
					if($just_list) return array ('type' => 'BOOL','allowed' => array('true','false'));
					$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
					$text .= PHP_EOL . '<option value="false"'. (($value != true) ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;false&nbsp;&nbsp;&nbsp;&nbsp;</option>';
					$text .= PHP_EOL . '<option value="true"'. (($value == true) ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;true&nbsp;&nbsp;&nbsp;&nbsp;</option>';
					$text .= PHP_EOL . '</select>' . PHP_EOL;
					} // if
				else if(is_numeric($value)) {
					$text .= '<input type="number" id="' . $id . '" name="' . $name . '"' .
						' style="width: 98%;" ' .
						' value="' . $value . '"' .
						($readonly ? ' READONLY':'') .
						($required ? ' REQUIRED':'') .
						'/>';
					} // else if
				else {	// a text input box
					$text .= '<input type="text" id="' . $id . '" name="' . $name . '"' .
						' style="width: 98%;" ' .
						' value="' . $value . '"' .
						($readonly ? ' READONLY':'') .
						($required ? ' REQUIRED':'') .
						' autocapitalize="off"/>';
					} // else
				} // else if
			else {	// an input box
				$text .= '<input type="text" id="' . $id . '" name="' . $name . '"' .
//					' size="' . $size . '"' .
					' style="width: 98%;" ' .
					' value="' . $value . '"' .
					($readonly ? ' READONLY':'') .
					($required ? ' REQUIRED':'') .
					' autocapitalize="off"/>';
				} // else
			} // else
		if($just_list) return '';	// anything
		return $text;
	} // make_type_input_selr()

	public static function make_type_input($name,$sect_name,$ini_key,$value,$size = false, $readonly = false, $use_typedef_as_default = false, $required = false) {
		// $allowed = self::make_type_input_selr('', $ini_key, '', 0,true);
		if(!$size) $size = 30;
		if(($required) && ($readonly)) $required = false;	// stop a lock up
		if((self::$dyn_cntl) &&
			(($dn_text = self::get_dyn_ctl_method($ini_key)) !== false)) {
			$text ='';
			$id = 'id_' . $name;
			$is_macro = self::is_macro_lookup($sect_name,$value);
			$selr_text = self::make_type_input_selr($name . '[val]',$ini_key,$value,$size);
			$text .= '<div>' . PHP_EOL .
				'<div id="id_' . $name .'[dyn]" class="std">' . PHP_EOL .
				'<input type="checkbox" ' .
				' id="' . $id . '[chkbox]"' .
				' onchange="switchover_dyn_ctl(\'' . $id . '[chkbox]\',\'' . $id . '[norm]\');"' .
				' id="' . $id . '[chkbox]" name="' . $name . '[chkbox]"' .
				' title="Use: ' . $dn_text['text'] . '"' .
				($is_macro ? ' CHECKED':'') .
				($readonly ? ' READONLY':'') .
				($required ? ' REQUIRED':'') .
				'/>' . PHP_EOL .
				'</div>' . PHP_EOL .
				'<div id="' . $id .'[norm]" style=" display: ' . ($is_macro ? 'none':'inline-block') . ';">' .
					$selr_text .
				'</div>' . PHP_EOL .
				'</div>' .
				'<input type="hidden" id="' . $id . '[macro]" name="' . $name . '[macro]" value="' . htmlentities($dn_text['macro']) . '">' . PHP_EOL .
				PHP_EOL;
			} // if
		else {
			$text = self::make_type_input_selr($name,$ini_key,$value,$size,false,$readonly,$use_typedef_as_default,$required);
			} // else
		return $text;
	} // make_type_input()

// dynamic methods


	} // Ccms_options
