<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_generate_Vmenu.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

class Ccms_generate_Vmenu extends Ccms_base {
	// put up a single column menu table (the old fashioned way)
	// this would be a whole lot better using W3 WAI-ARIA (too many browsers dragging their feet)

	protected $row = false;
	protected $id = false;
	protected $use_js = false;
	protected $search_mode = true;
	protected $search_min_req_entries = 12;
	public $style_class = false;

	function __construct($id_txt,$style_class, &$table, $use_js = true, $search_mode = true,$search_min_req_entries = false) {
		$this->row = 0;
		$this->id = 'id_' . $id_txt . '_';
		$this->use_js = $use_js;
		$this->search_mode = $search_mode;
		if($search_min_req_entries)
			$this->search_min_req_entries = $search_min_req_entries;
		$this->style_class = $style_class;
		parent::__construct();
		$this->gen_Vmenu($table);
		} // __construct()

	function  __destruct() {
		parent::__destruct();
		} // __destruct()
// static

// methods

	protected function gen_tr_th(&$th) {
		echo '	<tr class="' . $this->style_class . '">';
		echo '<th class="' . $this->style_class . '"' .
			(isset($th['title']) ? ' title="' . $th['title'] . '"':'') .
			' id="' . $this->id . 'th"' .
			'>' . $th['text'] . '</th>';
		echo '</tr>' . PHP_EOL;
		} // gen_tr_th()

	protected function gen_tr_td(&$td) {
		if(empty($td['text'])) return;
		$this->row++;
		if((!empty($_SERVER['REQUEST_URI'])) &&
			(stripos($_SERVER['REQUEST_URI'],$td['url']) !== false) &&
			(stripos($td['url'],$_SERVER['QUERY_STRING']))) {
			$td_class = $this->style_class . ' ' . $this->style_class . '_selected';
			} // if
		else $td_class = $this->style_class;
		if(($this->use_js) && (empty($td['new']))) {
			echo '	<tr class="' . $this->style_class . (!empty($td['url']) ? (($this->row & 1) ? '_odd':'_even') . ' href_linked':'') . '"' .
				' id="' . $this->id . 'tr' . $this->row . '"' .
				(!empty($td['url']) ? ' onclick="' .
				(!empty($td['confirm']) ? 'if(confirm(\'' . $td['confirm'] . '\')) ':'Ccms_cursor.setWait();') .
				'window.location.href = \'' . $td['url'] . '\';"':'') .
				(!empty($td['params']) ? ' ' . $td['params']:'') .
				(!empty($td['title']) ? ' title="' . $td['title'] . '"':'') .
				'>';
			echo '<td class="' . $td_class . '"' .
				' id="' . $this->id . 'td' . $this->row . '"' .
				'>' . $td['text'] . '</td>';
			echo '</tr>' . PHP_EOL;
			return;
			} // if
		echo '	<tr class="' . $this->style_class . (!empty($td['url']) ? (($this->row & 1) ? '_odd':'_even'):'') . '"' .
			' id="' . $this->id . 'tr' . $this->row . '"' .
			'>';
		if(!empty($td['url'])) {
			echo '<td class="' . $td_class . '"' .
				' id="' . $this->id . 'td' . $this->row . '"' .
				'>';
			echo '<a href="' . $td['url'] . '"' .
				' id="' . $this->id . 'a' . $this->row . '"' .
				((!empty($td['new']) && $td['new']) ? ' target="_blank"':'') .
				(!empty($td['confirm']) ? ' onclick="return confirm(\'' . $td['confirm'] . '\');"':' onclick=\'Ccms_cursor.setWait();\'') .
				(!empty($td['params']) ? ' ' . $td['params']:'') .
				(!empty($td['title']) ? ' title="' . $td['title'] . '"':'') .
				'>' .
				$td['text'] .
				'</a>';
			echo '</td>';
			} // if
		else {	// just text (probably a submenu)
			echo '<td class="' . $this->style_class . '"' .
				' id="' . $this->id . 'td' . $this->row . '"' .
				'>';
			echo $td['text'];
			echo '</td>';
			} // else
		echo '</tr>' . PHP_EOL;
		} // gen_tr_td()

	protected function gen_tr_td_search(&$table) {
		if(!$this->search_mode) return;
		if(count($table['td']) < $this->search_min_req_entries) return;
		// add search input
		echo '	<tr class="' . $this->style_class . '">';
		echo '<td class="' . $this->style_class . '">';
		echo '<input type="text"' .
			' id="' . $this->id . 'inp"' .
			' oninput="Cfilter_PDBs.on_filter(this,\'' . $this->id . '\');"' .
			' onchange="Cfilter_PDBs.on_filter(this,\'' . $this->id . '\');"' .
			' placeholder="Filter Menu"' .
			' title="Enter keywords to filter menu.">';
		echo '</td>';
		echo '</tr>' . PHP_EOL;
		} // gen_tr_td_search()

	protected function gen_Vmenu(&$table) {
		echo  PHP_EOL . '<table class="' . $this->style_class . '" id="' . $this->id . 'tb">' . PHP_EOL;
		if(isset($table['th'])) $this->gen_tr_th ($table['th']);
		$this->gen_tr_td_search($table);	// add search input
		if(isset($table['td'])) {
			foreach($table['td'] as &$td) {
				$this->gen_tr_td($td);
				} // foreach
			} // if
		// $this->gen_tr_td_search($table);	// add search input
		echo '</table>' . PHP_EOL;
		} // gen_Vmenu()

} // Ccms_generate_Vmenu

