<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_lm_filter.php 1961 2021-01-25 10:09:54Z robert0609 $
 */


/**
 *
 *  * Description of lm_filter
 *	* static class to provide text filter in user data
 *
 * @author robert0609
 */
class Ccms_lm_filter extends Ccms_general {

	protected static $filter_keywords = false;
//	protected static $sect_sql_filter = '';
//	protected static $link_sql_filter = '';

	protected static $linkkeys = array('lm_link_name','lm_link_title','lm_link_description');	// ,'lm_link_url','lm_link_image_url','lm_link_icon_url'
	protected static $sectkeys = array('lm_section_name', 'lm_section_description', 'lm_section_title');	// ,'lm_section_image_url', 'lm_section_icon_url'

	protected static $layout_ids = false;

			function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function help() {
		$text = "Enter text keywords, separated by spaces, to find and filter Sections, Links, Titles, Desciptions and Names.";
		$text .= '\n' . (LMC_FILTER_ANDED ? 'Must have all keywords.':'Can have any keyword.');
		return $text;
		} // help()

	protected static function is_filtering() {
		if(!LMC_FILTER_OUTPUT) return false;
		if(self::$filter_keywords) return true;
		if((Ccms::is_get_or_post('keywords')) &&
			($keywords = Ccms::get_or_post('keywords'))) {
			self::$filter_keywords = $keywords;
			return true;
			} // if
//		else if((Ccms::is_get_or_post('filter')) &&
//			($keywords = Ccms::get_or_post('filter'))) {
//			self::$filter_keywords = $keywords;
//			return true;
//			} // if
		return false;
		} // is_filtering()

	protected static function check_ored_keywords($data,$keys) {
		$words = explode(' ',self::$filter_keywords);
		$txt = '';
		foreach($keys as $k) {
			if(!isset($data[$k])) continue;
			$txt .= ' ' . $data[$k];	// make a long str
			} // foreach
		foreach($words as $w) {
			if(empty($w)) continue;
			if(preg_match('/' . $w . '/i', $txt)) return true;
			} // foreach
		return false;
		} // check_ored_keywords()

	protected static function check_anded_keywords($data,$keys) {
		$words = explode(' ',self::$filter_keywords);
		$txt = '';
		foreach($keys as $k) {
			if(!isset($data[$k])) continue;
			$txt .= ' ' . $data[$k];	// make a long str
			} // foreach
		$found = true;
		foreach($words as $w) {
			if(empty($w)) continue;
			if(!preg_match('/' . $w . '/i', $txt)) {
				$found = false;
				break;
				} // if
			} // foreach
		return $found;
		} // check_anded_keywords()

	protected static function check_keywords($data,$keys) {
		if(!self::is_filtering()) return true;	// allow every thing
		if(LMC_FILTER_ANDED) return self::check_anded_keywords ($data, $keys);
		return self::check_ored_keywords($data, $keys);
		} // check_keywords()

	protected static function check_section_keywords($section) {
		if(!LMC_FILT_INC_SECT) return false;
		$keys = self::$sectkeys;
		return self::check_keywords($section,$keys);
		} // check_section_keywords();

	protected static function check_link_keywords($link) {
		$keys = self::$linkkeys;
		return self::check_keywords($link,$keys);
		} // check_link_keywords()

	private static function find_sections_links_layout_recurs(&$layout_ids, $section_id = false,$lev = 0) {
		$section_found = false;
		if(empty($section_id)) $section_id = 0;
		$sql_section_query = "SELECT *" .
			" FROM  lm_sections" .
			" WHERE  lm_section_enabled > 0" .
			(((int)$section_id > 0) ? ' AND lm_section_id = ' . (int)$section_id :' AND (lm_section_parent_id = 0 OR lm_section_parent_id = \'null\' OR lm_section_parent_id = \'\')') .
			" ORDER BY lm_section_order,lm_section_name;";
		if($result_section = Ccms::$cDBcms->query_unbuffered($sql_section_query)) {
			while($section = Ccms::$cDBcms->fetch_array_unbuffered($result_section)) {
				if(!Ccms_auth::check_user_group_ids($section['lm_section_group_ids'])) continue;
				if(((int)$section['lm_section_parent_id'] > 0) &&
					((int)$section_id != (int)$section['lm_section_id']))
					continue;	// it's a child
				$section_found = self::check_section_keywords($section);

				// check for children
				$sql_section_child_query = "SELECT lm_section_id" .
					" FROM  lm_sections" .
					" WHERE  lm_section_enabled > 0" .
					' AND lm_section_parent_id = ' . (int)$section['lm_section_id'] .
					" ORDER BY lm_section_order,lm_section_name;";
				if($result_section_child = Ccms::$cDBcms->query_unbuffered($sql_section_child_query)) {
					while($section_child = Ccms::$cDBcms->fetch_array_unbuffered($result_section_child)) {
						$lm_section_child_id = $section_child['lm_section_id'];
						if(((int)$lm_section_child_id > 0) &&
							((int)$lm_section_child_id != (int)$section_id)) {
							// if(!isset($layout_ids['sections'][($section['lm_section_id'])]['data'])) $layout_ids['sections'][($section['lm_section_id'])]['data'] = $section;
							$sub_section_found = self::find_sections_links_layout_recurs(	// recurse it
								$layout_ids['sections'][($section['lm_section_id'])],
								$lm_section_child_id,
								($lev + 1));
//							if($sub_section_found) {
//								if(!isset($layout_ids['sections'][($section['lm_section_id'])]['data']))
//									$layout_ids['sections'][($section['lm_section_id'])]['data'] = $section;
//								// $section_found = true;
//								} // if
							} // if
						} // while
					} // if

				if($section_found)
					$layout_ids['sections'][($section['lm_section_id'])]['data'] = $section;
				$sql_link_query = "SELECT" .
					" lm_link_id,lm_link_name,lm_link_title,lm_link_description" .
					", lm_link_url, lm_link_image_url, lm_link_icon_url, lm_link_new_page" .
					", lm_link_ssl, lm_link_add_name2url, lm_link_comments" .
					" FROM  lm_links" .
					" WHERE  lm_link_enabled > 0 AND lm_link_section_id = " . (int)$section['lm_section_id'] .
					" ORDER BY lm_link_order,lm_link_name;";
				if($result_link = Ccms::$cDBcms->query_unbuffered($sql_link_query)) {
					while($link = Ccms::$cDBcms->fetch_array_unbuffered($result_link)) {
						if($section_found)
							$layout_ids['sections'][($section['lm_section_id'])]['links'][($link['lm_link_id'])]['data'] = $link;	// put all links if section matches
						else {
							if(self::check_link_keywords($link)) {
								if(!isset($layout_ids['sections'][($section['lm_section_id'])]['data']))
									$layout_ids['sections'][($section['lm_section_id'])]['data'] = $section; // time saver
								$layout_ids['sections'][($section['lm_section_id'])]['links'][($link['lm_link_id'])]['data'] = $link;	// put in if link matches
								} // if
							} // else
						} // while
					} // if
				if($section_found) {
					$layout_ids['sections'][($section['lm_section_id'])]['level'] = $lev;
					$layout_ids['sections'][($section['lm_section_id'])]['found'] = $section_found;
					} // if
				} // while
			}//if
		return $section_found;
		} // find_sections_links_layout_recurs()

	public static function find_sections_links_layout() {
		if(self::$layout_ids) return self::$layout_ids;
		self::$layout_ids = array();
		self::find_sections_links_layout_recurs(self::$layout_ids);
		if(self::is_debug())
			self::save_json (VAR_FS_TEMP_DIR . 'sections_links.json', self::$layout_ids,false,true,true);
		return self::$layout_ids;
		} // find_sections_links_layout()

//	protected static function get_keywords_sql($cols) {
//		if(!self::is_filtering()) return '';
//		$sql = '';
//		$words = explode(' ',self::$filter_keywords);
//		foreach($cols as $c) {
//			foreach($words as $w) {
//				$sql .= ' OR ' . $c . " LIKE '%" . $w . "%'";
//				} // foreach
//			} // foreach
//		if(!empty($sql)) return ' AND (' . substr($sql,4) . ')';
//		return '';
//		} // get_keywords_sql()
//
//	public static function get_section_keywords_sql() {
//		$cols = self::$sectkeys;
//		return self::get_keywords_sql($cols);
//		} // get_section_keywords_sql();
//
//	public static function get_link_keywords_sql() {
//		$cols = self::$linkkeys;
//		return self::get_keywords_sql($cols);
//		} // get_link_keywords_sql()

} // Ccms_lm_filter
