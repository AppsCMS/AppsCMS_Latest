<?php
/*
 * Applications Management System Library Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_DB_edit.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Ccms_DB_edit
 *
 * Provides common methods for generation for editing database table row based arrays.
 *
 * @author robert0609
 */

//	//	DataBase editor
// Typical $install_scripts (MySQL syntax)
//		$install_scripts = array(	// multi tables, REMEMBER SQLITE DOES NOT HAVE THE SAME SQL SUITE AS MYSQL
//									//	(use $this->convertSyntaxSQLite2MySQL() and $this->convertSyntaxMySQL2SQLite())
//			'accounts' => array(	// table name
//				'drop' => 'false', // dont drop on table reload
//				'id' => 'account_id',	// row id column (optional)
//				'asc' => 'account_name',	// ASC sort column (optional)
//				'columns' => array(
//					"account_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
//					"account_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
//					"account_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
//					"account_name" => "VARCHAR(128) NOT NULL UNIQUE",	// the account name
//					"account_type" => "ENUM('cash','savings','cheque','credit','loan','super','tax') DEFAULT 'cash'",	// type of account
//					"account_interest" => "FLOAT(16) DEFAULT 0.00",	// interest rate of account
//					"account_opened" => "TIMESTAMP DEFAULT 0",	// date and time the account was closed
//					"account_closed" => "TIMESTAMP DEFAULT 0",	// date and time the account was opened
//					"account_description" => "TEXT DEFAULT ''",		// description
//					"account_enabled" => "BOOLEAN DEFAULT 1",		// the enabled or disabled
//					"account_institution_name" => "VARCHAR(128) NOT NULL",	// institution name
//					"account_currency_id" => "INTEGER DEFAULT 1",
//					"account_bsb" => "VARCHAR(16) NOT NULL",		// BSB
//					"account_number" => "VARCHAR(32) NOT NULL",		// account number
//					"account_manager" => "VARCHAR(64) DEFAULT ''",	// at institution
//					"account_phone" => "VARCHAR(32) DEFAULT ''",	// for institution
//					"account_email" => "VARCHAR(64) DEFAULT ''",	// for institution
//					"account_url" => "VARCHAR(64) DEFAULT ''",		// for institution
//					"PRIMARY KEY(account_id, account_name)",
//					),
//				'key_column' => '',	// used with update_row_data()
//				'updateable_columns' => '',	// used with update_row_data(), comma seperate list, nil
//				'functions' => array(
//					// nil for now
//					),
//				'extras' => '',	// nil for now
//				'data' => array(	// in the same order as the columns
//					// nil for now
//					),
//				'edit' => array(
//					'text' => 'Accounts',
//					'title' => 'Accounts are usually updated from imports or the ledger page."
//					'row_id_name' => 'account_id',
//					'order_by' => 'account_name ASC',
//					'columns' => array(
//						"account_name" => array('type' => 'text','head' => "Account Name", 'required' => true,),
//						"account_description" => array('type' => 'text','head' => 'Description', 'required' => false,),
//						"account_type" => array(
//							'type' => 'enum',	// could use radio but this uses less space
//							'head' => 'Type',
//							'multiple' => true,	// multiple select drop box, value is a comma seperated list (use params to set size)
//							'enum' => array('Cash','Savings','Cheque','Credit','Loan','Super','Tax'),	// options same order as table column values
//							'inp_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
//							'save_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
//							'required' => true,
//							),
//						"account_enabled" => array('type' => 'checkbox','head' => "Enabled",),
//						"account_institution_name" => array('type' => 'text','head' => "Institution Name", 'required' => true,),
//						"account_currency_id" => array(
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Currency",
//							'required' => true,
//							'relation' => array(	// always a select
//								'table' => 'currencies',
//								'id' => 'currency_id',
//								'name' => 'currency_code',
//								'title' => 'currency_name',
//								),
//							),
//						"account_interest" => array('type' => 'float','head' => "Interest Percent", 'params' => 'style="width: 5em;" step="0.001"',),
//						"account_bsb" => array('type' => 'number','head' => "Account BSB", 'params' => 'min="10000" step="1" max="999999" style="width: 6em;"',),
//						"account_number" => array('type' => 'number','head' => "Account Number", 'params' => 'style="width: 9em;"',),
//						"account_manager" => array('type' => 'text','head' => "Account Manager",),
//						"account_phone" => array('type' => 'phone','head' => "Instituion Phone Number", 'params' => 'style="width: 10em;"',),
//						"account_email" => array('type' => 'email','head' => "Instituition Email Address", 'params' => 'style="width: 12em;"',),
//						"account_url" => array('type' => 'url','head' => "Instituition Web Address", 'params' => 'style="width: 12em;"',),
//						// all other columns not shown
//						),
//					),
//				),
//			'transactions' => array(	// table name
//				'drop' => 'false', // dont drop on table reload
//				'id' => 'transaction_id',	// row id column (optional)
//				'asc' => 'transaction_date',	// ASC sort column (optional)
//				'columns' => array(
//					"transaction_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
//					"transaction_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
//					"transaction_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
//					"account_id" => "INTEGER NOT NULL",
//					'payee_id' => 'INTEGER NOT NULL',
//					"currency_id" => "INTEGER DEFAULT 1",
//					"category_id" => "INTEGER NOT NULL",
//					"receipt_id" => "INTEGER NOT NULL",
//					"project_id" => "INTEGER NOT NULL",
//					"transaction_type" => "VARCHAR(16) DEFAULT ''",
//					"transaction_date" => "TIMESTAMP DEFAULT 0",
//					"transaction_memo" => "TEXT DEFAULT ''",
//					"transaction_amount" => "DOUBLE NOT NULL",
//					"transaction_status" => "ENUM('ENTERED','CLEARED','RECONCILED') DEFAULT 'ENTERED'",
//					"PRIMARY KEY(transaction_id, transaction_date)",
//					),
//				'edit' => array(
//					'text' => 'Transactions',
//					'row_id_name' => 'transaction_id',
//					'order_by' => 'transaction_date DESC',
//					'columns' => array(
//						"transaction_id" => array('type' => 'show','head' => "ID", 'readonly' => true,),			// the row id
//						"transaction_added" => array('type' => 'show','head' => "Added", 'readonly' => true,),	// date and time the row was added
//						"transaction_updated" => array('type' => 'show','head' => "Updated", 'readonly' => true,),	// date and time the row was updated
//						"transaction_type" => array('type' => 'text','head' => "Type", 'required' => false,),
//						"transaction_date" => array('type' => 'date','head' => "Date", 'required' => true,),
//						"transaction_memo" => array('type' => 'text','head' => "Memo", 'required' => false,),
//						"transaction_amount" => array('type' => 'float','head' => "Amount", 'required' => true, 'params' => 'step="0.01"',),
//						"account_id" => array(	// column edited
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Account",
//							'required' => true,
//							'inp_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
//							'save_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
//							'relation' => array(	// always a select
//								'joined' => false,	// false is the default, if true joins the where sql to the relational tables (CAUTION: the result will not include loose/empty relationships)
//								'table' => 'accounts',
//								'id' => 'account_id',
//								'name' => 'account_name',
//								),
//							),
//						"payee_id" => array(
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Payee",
//							'required' => true,
//							'multiple' => false,	// multiple select drop box, value is a comma seperated list (use params to set size)
//							'inp_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
//							'save_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
//							'relation' => array(	// always a select
//								'joined' => false,	// false is the default, if true joins the where sql to the relational tables (CAUTION: the result will not include loose/empty relationships)
//								'table' => 'payees',
//								'id' => 'payee_id',
//								'name' => 'payee_name',
//								),
//							),
//						"currency_id" => array(
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Currency",
//							'relation' => array(	// always a select
//								'joined' => true,	// false is the default, if true joins the where sql to the relational tables (CAUTION: the result will not include loose/empty relationships)
//								'table' => 'currencies',
//								'id' => 'currency_id',
//								'name' => 'currency_code',
//								'title' => 'currency_name',
//								),
//							),
//						"category_id" => array(
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Category",
//							'required' => true,
//							'relation' => array(	// always a select
//								'joined' => false,	// false is the default, if true joins the where sql to the relational tables (CAUTION: the result will not include loose/empty relationships)
//								'table' => 'categories',
//								'id' => 'category_id',
//								'name' => 'category_name',
//								),
//							),
//						"receipt_id" => array(
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Receipt",
//							'relation' => array(	// always a select
//								'table' => 'receipts',
//								'id' => 'receipt_id',
//								'name' => 'receipt_name',
//								),
//							),
//						"project_id" => array(
//							'type' => 'select',	// this type of select is always an ajax driven select
//							'head' => "Project",
//							'relation' => array(	// always a select
//								'table' => 'projects',
//								'id' => 'project_id',
//								'name' => 'project_name',
//								),
//							),
//						// all other columns not shown
//						),
//					),
//				),
//			);

class Ccms_DB_edit extends Ccms_DB_edit_sql {

	function __construct(&$cEditDB,$form_name,$install_scripts,$class = '',$max_rows_per_page = 0, $max_DB_select_rows = self::AJAX_SELECT_MAX_DEF, $read_only = false) {
		parent::__construct();
		$this->cEditDB = $cEditDB;
		if($this->cEditDB) {
			$this->db_name_id = $this->cEditDB->get_DB_signat();
			if(isset($_SESSION[$this->db_name_id]['edit_DB_info']))
				$this->edit_DB_info = $_SESSION[$this->db_name_id]['edit_DB_info'];	// recover data
			} // if

		$this->edit_DB_info['install_scripts'] = $install_scripts;
		$this->edit_DB_info['form_name'] = $form_name;
		$this->edit_DB_info['read_only'] = $read_only;
		$this->edit_DB_info['columns_heads'] = false;
		if(self::$ajax) return;

		if(empty($class)) {
			$this->class = ' class="page_database"';
			$this->class_odd = ' class="page_database page_database_odd"';
			$this->class_even = ' class="page_database page_database_even"';
			$this->class_text = ' class="page_database page_database_text"';	// for text column (<td>) only
			$this->class_number = ' class="page_database page_database_number"';	// for number column (<td>) only
			} // if
		else {
			$this->class = ' class="' . $class . '"';
			$this->class_odd = ' class="' . $class . ' ' . $class . '_odd"';
			$this->class_even = ' class="' . $class . ' ' . $class . '_even"';
			$this->class_text = ' class="page_database page_database_text"';	// for text column (<td>) only
			$this->class_number = ' class="' . $class . ' ' . $class . '_number"';	// for number column (<td>) only
			} // else
		$this->get_DB_form_controls($max_rows_per_page,$max_DB_select_rows);
		$this->get_DB_form_data();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		unset($this->edit_DB_info['install_scripts']);
		unset($this->edit_DB_info['sql']);
		$_SESSION[$this->db_name_id]['edit_DB_info'] = $this->edit_DB_info;	// save data
		} // __destruct()

// static methods

// dynamic methods
	public function get_DB_editor_table(&$action_uri) {
		$table_details = &$this->edit_DB_info['install_scripts'][($this->edit_DB_info['table'])];

		echo '		<br><br><h3 class="page_config" title="DB: ' . $this->cEditDB->get_name() . '">Edit Database - ' . ucwords($this->edit_DB_info['table']) . ' Table</h3>' . PHP_EOL;
//		if(self::is_debug()) echo ' (' . $this->cEditDB->get_name() . ')';
		echo '<br>' . PHP_EOL;
//		if(self::getMsgsCount() > 0)
//			echo self::getMsgsTable();
		echo self::getMsgsStack();
		echo '	' . $this->get_DB_table_editor_forms($action_uri,$table_details);
		return $this->prn_or_buffer_text();
		} // get_DB_editor_table()

	public function edit_database_pre($h2,$action_uri,$ajax_uri,$ajax_DB_column_uri,$title = '') {

		echo '		<h2' . (!empty($title) ? ' title="' . $title . '"':'') . '>' . $h2 . '</h2>' . PHP_EOL;
		echo $this->get_DB_form_JS($action_uri,$ajax_uri,$ajax_DB_column_uri);
		return $this->prn_or_buffer_text();
		} // edit_database_pre()

	public function edit_database($h2,$action_uri,$ajax_uri,$ajax_DB_column_uri,$title = '') {

//		if(!isset($this->edit_DB_info['install_scripts'][($this->edit_DB_info['table'])]['edit'])) {
//			self::log_msg('No editable DB columns in "' . __CLASS__. '::' . __METHOD__ . '" install scripts.');
//			return 'No editable DB columns.';
//			} // if

		echo '		<h2' . (!empty($title) ? ' title="' . $title . '"':'') . '>' . $h2 . '</h2>' . '<br>' . PHP_EOL;
		echo $this->get_DB_form_JS($action_uri,$ajax_uri,$ajax_DB_column_uri);
		echo $this->get_DB_select_table($action_uri);	// allow for inheritance
		if($this->edit_DB_info['table']) {
			echo $this->get_DB_editor_table($action_uri);	// allow for inheritance
			} // else

		return $this->prn_or_buffer_text();
		} // edit_database()

} // Ccms_DB_edit
