<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_base.php 2052 2021-04-08 07:46:40Z robert0609 $
 */

/**
 * Description of cms_base
 *
 * @author robert0609
 */

require_once 'cms_base_sm.php';	// speed up for proxy (no autoloader needed)

class Ccms_base extends Ccms_base_sm {

	private static $apps_extend_class = null;

	const DEF_VAR_KEY = 'def_var_key';

	function __construct() {
		parent::__construct();
		$parent = get_class($this);	// wait for DB to open
		if($parent == 'Ccms') self::init_apps_extend_cms_base();
		} // __construct()

	function __destruct() {
		if(self::$refd_false !== false) {	// DO NOT CHANGE, used as reference &false
			self::addDebugMsg('CODE ERROR: $refd_false has been aletered from false value.');
			} // if
		parent::__destruct();
		} // __destruct()

	public function __call($name, $args) {	// a PHP magic method
		if(preg_match('/[ !?@]+/',$name)) return null;	// not legal
		if((!is_null($apps_extend_class = self::init_apps_extend_cms_base())) &&
			(method_exists($apps_extend_class, $name))) {	// check extension
			return call_user_func_array(array($apps_extend_class,$name),$args);
			} // if
		else if(method_exists($this, $name)) {	// use local
			return call_user_func($name,$args);
			} // if
		self::addDebugMsg ('Unknown function "' . $name . '" from ' . self::get_backtrace(2) . '"');
		return null;
		} // __call()

	public static function __callStatic($name, $args) {	// a PHP magic method
		if(preg_match('/[ !?@]+/',$name)) return null;	// not legal
		if((!is_null($apps_extend_class = self::init_apps_extend_cms_base())) &&
			(method_exists($apps_extend_class, $name))) {	// check extension
			return call_user_func_array(array($apps_extend_class,$name),$args);
			} // if
		else if(function_exists($name)) {	// use local
			return call_user_func(self::$name,$args);
			} // if
		self::addDebugMsg ('Unknown static function "' . $name . '" from ' . self::get_backtrace(2) .'"');
		return null;
		} // __callStatic()

// static methods
	private static function init_apps_extend_cms_base() {
		if(is_null(self::$apps_extend_class)) {
			self::$apps_extend_class = false;	// once only
			$ext_pl = (defined('CMS_C_APPS_EXTEND_PLUGIN') ? CMS_C_APPS_EXTEND_PLUGIN:Ccms::get_cms_ini_value('CMS_C_APPS_EXTEND_PLUGIN'));
			if(($ext_pl) && (strlen($ext_pl) >= 4)) {
				$class = 'C' . CMS_C_APPS_EXTEND_PLUGIN . '_plugin';
				if(Ccms_autoloader::find_plugin($class)) {
					self::$apps_extend_class = $class;
					new $class();	// run the constructor
					} // if
				} // if
			} // if
		return (self::$apps_extend_class ? self::$apps_extend_class:null);
		} // init_apps_extend_cms_base()

	public static function is_apps_extend_static_func($name) {
		if((preg_match('/[ !?@]+/',$name)) ||
			(is_null($apps_extend_class = self::init_apps_extend_cms_base()) ||
			(!method_exists($apps_extend_class,$name))))
			return false;
		return true;
		} // is_apps_extend_static_func()

	public static function get_apps_extend_static_func($name,$args = array()) {
		if(!self::is_apps_extend_static_func($name)) return null;
		$callback = self::$apps_extend_class . '::' . $name;
		return call_user_func_array($callback,array(&$args));
		} // get_apps_extend_static_func()

	protected static function get_version_str() {
		if(Ccms::is_get_or_post('ajax')) return '';	// not done for ajax, speed it up
		$v_str = '';	// wrong CMS_C_TITLE;

		if (Ccms_auth::is_group_manager()) {
			$v_str .= '' .strip_tags(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION);
			$v_str .= ', DB V' . self::$cDBcms->m_sVersion;
			$v_str .= (self::is_debug() ? ', (Debug)' : '');
			$v_str .= (self::can_test() ? ', (Testing)' : '');
			$v_str .= (self::is_production() ? ', (Production)' : ', (Develop)');
			} // if

		if(!self::is_rebuild()) {
			if (is_dir(DOCROOT_FS_BASE_DIR . '.svn')) {
				// PHP function 'svn_status' used to work	// get svn stats
				$sver = array(); $sretv = array();
				// eg Last Changed Rev: 535
				exec("/usr/bin/svn info -R " . DOCROOT_FS_BASE_DIR . " | grep -i 'Last Changed Rev: ' | sort -u " ,$sver,$sretv);
				if(($sretv == 0) && (!empty($sver))) {	// ok
					$sdate = array(); $sdretv = array();
					// eg Last Changed Date: 2016-10-14 01:05:42 +1100 (Fri, 14 Oct 2016)
					exec("/usr/bin/svn info  -R | grep -i 'Last Changed Date: ' | sort -u ",$sdate,$sdretv);
					if(($sdretv == 0) && (!empty($sdate))) { // ok
						$sver = max(preg_replace('/^.*rev: /i','',$sver));
						$sdate = preg_replace('/^.*date: /i','', $sdate);
						$sdate = max(preg_replace('/ \(.*\)$/i','', $sdate));
						$v_str .= ', SVN: ' . $sver . ' ' . date('d/m/Y H:i:s', strtotime($sdate));
						} // if
					} // if
				} // if

			if((is_dir(DOCROOT_FS_BASE_DIR . '.git')) &&
				(is_readable(DOCROOT_FS_BASE_DIR . '.git/config'))) {
				$branch = array(); $bretv = array();
				// eg # On branch develop
				exec("/usr/bin/git status | grep -i 'on branch'",$branch,$bretv);
				if(($bretv == 0) && (!empty($branch))) {	// ok
					$cdate = array(); $cdretv = array();
					// eg 2017-07-31 14:57:26 +1000
					exec("/usr/bin/git show --format=%ai | head -n 1",$cdate,$cdretv);
					if(($cdretv == 0) && (!empty($cdate))) { // ok
						$branch = preg_replace('/^.*on branch /i','',$branch[0]);
						$v_str .= ', GIT: ' . $branch . ' ' . date('d/m/Y H:i:s', strtotime($cdate[0]));
						} // if
					} // if
				} // if
			} // if
		return $v_str;
		} //get_version_str()

	protected static function ipCIDRCheck($IP, $CIDR) { // from "http://php.net/manual/en/ref.network.php" after the maths was sorted
		$nips = explode('/',$CIDR);
		if(count(explode('.',$IP)) < 4) return false;
		$net = $nips[0];
		if(!isset($nips[1])) $ip_mask = -1;
		else $ip_mask = ~((1 << (32 - $nips[1])) - 1);
		$ip_net = ip2long ($net);
		$ip_ip = ip2long ($IP);
		if(($ip_ip == 0) && ($ip_net == 0)) return false;
		$ip_ip_net = $ip_ip & $ip_mask;
		return ($ip_ip_net == $ip_net);
		} // ipCIDRCheck()

	protected static function is_intranet($domain) {
		// see "https://en.wikipedia.org/wiki/Private_network"
		static $int_ip_ranges = false;
		if(!$int_ip_ranges) {
			$int_ip_ranges = array(
				array('hi' => ip2long('10.255.255.255'), 'lo' => ip2long('10.0.0.0')),
				array('hi' => ip2long('192.168.255.255'), 'lo' => ip2long('192.168.0.0')),
				array('hi' => ip2long('172.31.255.255'), 'lo' => ip2long('172.16.0.0')),
				);
			} // if
		$hosts = gethostbynamel($domain);
		if(empty($hosts)) return false;
		$found = false;
		foreach($hosts as $host) {
			$h_ipl = ip2long($host);
			foreach($int_ip_ranges as $ip_r) {
				if(($h_ipl > $ip_r['lo']) && ($h_ipl < $ip_r['hi'])) {
					$found = true;
					break;
					} // if
				} // foreach
			if($found) break;
			} // foreach
		return $found;
		} // is_intranet()

	protected static function is_internet($domain) {
		$hosts = gethostbynamel($domain);
		if($empty($hosts)) return false;
		return !self::is_intranet($domain);
		} // is_internet()

	public static function array_trimCallback(&$str,$key) { $str = trim($str); } // array_trimCallback()
	public static function array_trim(&$array) { return array_walk_recursive($array,'self::array_trimCallback'); } // array_trim()

	public static function issetDottedKeys2Var($data, $dotted_keys, $dot = '.') {
		$sections = explode($dot, $dotted_keys);
		for ($i = 0; $i < count($sections);$i++) {
			$sect = &$sections[$i];
			if ($sect == '*') {	// check descenders
				$k = key($data);	// skip over this index
				$ds = array_splice($sections,($i + 1));	// extract remaining keys
				$dk = implode($dot,$ds);	// make keys array
				$da = $data[$k];
				$ret = self::issetDottedKeys2Var($da, $dk, $dot);
				if($ret) return true;
				} // if
			if (!is_array($data) || !array_key_exists($sect, $data)) {
				// not there
				return false;
				} // if
			$data = $data[$sect];
			} // for
		return true;	// is there
		} // issetDottedKeys2Var()

	public static function getDottedKeys2Var($data, $dotted_keys, $dot = '.', $err_ret = null) {
		$sections = explode($dot, $dotted_keys);
		for ($i = 0; $i < count($sections);$i++) {
			$sect = &$sections[$i];
			if ($sect == '*') {	// check descenders
				$k = key($data);	// skip over this index
				$ds = array_splice($sections,($i + 1));	// extract remaining keys
				$dk = implode($dot,$ds);	// make keys array
				$da = $data[$k];
				$data = self::getDottedKeys2Var($da, $dk, $dot);
				if(!empty($data)) return $data;
				} // if
			if (!is_array($data) || !array_key_exists($sect, $data)) {
				// error occurred
				return $err_ret;
				} // if
			$data = $data[$sect];
			} // for
		return $data;	// done
		} // getDottedKeys2Var()

	public static function setVar2DottedKeys(&$data, $dotted_keys,$value, $dot = '.') {
		if(!is_array($data)) $data = array();
		$sections = explode($dot, $dotted_keys);
		foreach ($sections as $sect) {
			//	if(empty($sect)) return false; // .. ??
			if(!isset($data[$sect])) $data[$sect] = array();
			if(!array_key_exists($sect, $data)) $data[$sect] = null;
			$data = &$data[$sect];
			} // foreach
		$data = $value;
		return true;	// done
		} // setVar2DottedKeys()

	public static function fmt_number2type($val, $allow_bool = true) {
		if((is_null($val)) || (is_array($val))) return $val;
		$val = trim($val);
		if(preg_match('/^true$/i',$val)) return ($allow_bool ? true:'true');
		if(preg_match('/^false$/i',$val)) return ($allow_bool ? false:'false');
		if(preg_match('/^[-+]{0,1}[0-9]+$/',$val)) return (int)$val;
		if(preg_match('/^[-+]{0,1}[0-9]+\.[0-9]+$/',$val)) return (float)$val;
		return $val;
		} // fmt_number2type()

	public static function get_or_post_str($name, $allow_bool = true, $def = false) {
		// refer: https://www.php.net/manual/en/wrappers.php.php
		// NOTE: In php.ini; set always_populate_raw_post_data = true to use $_POST.
		// php://input is not available with enctype="multipart/form-data".
		// Using php://input is read only and does not allow push-back into the POSTed values.
		// To have push-back use "self::set_chk_php_value('always_populate_raw_post_data',1)" in config PHP code or
		// "php_flag always_populate_raw_post_data on" in the (DOCROOT) .htaccess
		// to enable full $_POST access per application.;
		$val = $def;
		if(isset($_POST[$name]))
			$val = $_POST[$name];
		else if(isset($_GET[$name]))
			$val = $_GET[$name];
		else if((!isset($_COOKIE[$name])) && (isset($_REQUEST[$name])))
			// try for $_GET, $_POST (but !$_COOKIE)
			// $_REQUEST decoded already
			$val = $_REQUEST[$name];
		// if all configs/setups are correct, should never get here
		else if((!empty(self::$client_headers['Content-Type'])) &&
			($val_str = file_get_contents('php://input')) &&
			(!empty($val_str))) {
			switch(self::$client_headers['Content-Type']['type']) {
			case 'application/json':
				$val_ary = @json_decode($val_str,true);
				if((!empty($val_ary)) && (isset($val_ary[$name]))) {
					$val = $val_ary[$name];
					} // if
				break;
			case 'application/x-www-form-urlencoded':
				$val_dec = urldecode($val_str);
				if(($val_ary = @json_decode($val_dec,true)) &&
					(!empty($val_ary)) && (isset($val_ary[$name]))) {
					$val = $val_ary[$name];
					} // if
				else if(($var_ary = @unserialize($val_dec)) &&
					(!empty($val_ary)) && (isset($val_ary[$name]))) {
					$val = $val_ary[$name];
					} // if
				// no name !!!!	else $val = $val_dec;
				break;
			default:
				break;
				} // switch
			} // if
		return $val;
		} // get_or_post_str()

	public static function get_or_post($name, $allow_bool = true, $def = false) {
		$val = self::get_or_post_str($name, $allow_bool, $def);
		return self::fmt_number2type($val,$allow_bool);
		} // get_or_post()

	public static function get_or_post_app_session($name, $app_key = false, $allow_bool = true) {
		// use session if not available
		$val = self::get_or_post_str($name, $allow_bool, null);
		$val = self::fmt_number2type($val,$allow_bool);
		if(!empty($_SESSION)) {	// have a session
			if((empty($app_key)) && (!empty(self::$app_key))) $app_key = self::$app_key;
			if(!empty($app_key)) {
				if(!is_null($val)) $_SESSION['apps'][$app_key][$name] = $val;
				else if(isset($_SESSION['apps'][$app_key][$name])) {
					$val = $_SESSION['apps'][$app_key][$name];
					} // else
				} // if
			} // if
		return $val;
		} // get_or_post_app_session()

	public static function get_or_post_keyed_session_var($name, $var_key = false, $allow_bool = true) {
		// use session if not available
		$val = self::get_or_post_str($name, $allow_bool, null);
		$val = self::fmt_number2type($val,$allow_bool);
		if(!empty($_SESSION)) {	// have a session
			if(empty($var_key)) $var_key = self::DEF_VAR_KEY;
			if(!is_null($val)) $_SESSION[$var_key][$name] = $val;
			else if(isset($_SESSION[$var_key][$name])) {
				$val = $_SESSION[$var_key][$name];
				} // else
			} // if
		return $val;
		} // get_or_post_keyed_session_var()

	public static function get_or_post_checkbox_keyed_session_var($name, $var_key = false, $allow_bool = true) {
		// use session if not available
		$val = self::get_or_post_checkbox($name);
		if(!empty($_SESSION)) {	// have a session
			if(empty($var_key)) $var_key = self::DEF_VAR_KEY;
			if(!is_null($val)) $_SESSION[$var_key][$name] = $val;
			else if(isset($_SESSION[$var_key][$name])) {
				$val = $_SESSION[$var_key][$name];
				} // else
			} // if
		return $val;
		} // get_or_post_checkbox_keyed_session_var()

	public static function is_get_or_post($name) {
		if(isset($_POST[$name])) return true;
		if(isset($_GET[$name])) return true;
		return false;
		} // is_get_or_post()

	public static function unset_get_or_post($name) {
		unset($_POST[$name]);
		unset($_GET[$name]);
		return true;
		} // unset_get_or_post()

	public static function get_or_post_checkbox($name) {
		if(self::get_or_post($name) == 'on') return 1;
		return 0;
		} // get_or_post_checkbox()

	public static function chk_get_or_post($name,&$val) {
		if(self::is_get_or_post($name)) {
			$i = self::get_or_post($name);
			$val = $i; // save it back to reference
			} // if
		return $val;
		} // chk_get_or_post()

	public static function chk_get_or_post_chgd($name,&$val) {
		$i = self::get_or_post($name);
		if($i) {
			if($i == $val) return false;	// no change
			$val = $i; // save it back to reference
			return true;	// it changed
			} // if
		return false;	// assume no change
		} // chk_get_or_post_chgd()

	public static function chk_get_or_post_str_chgd($name,&$val) {
		$i = self::get_or_post_str($name);
		if($i) {
			if($i == $val) return false;	// no change
			$val = $i; // save it back to reference
			return true;	// it changed
			} // if
		return false;	// assume no change
		} // chk_get_or_post_str_chgd()

	public static function checkdate($date) {	// check the date is mysql std fmt 'yyyy-mm-dd'
		// for sake of convienience this function is repeatly dynamically in Ccms_MySQL.php
		if(preg_match('/[0-9]{4,4}-[0-9]{2,2}-[0-9]{2,2}/', $date)) return true;
		return false;
		} // checkdate()

	public static function get_chk_date($name,$time_part = '') {
		$d = self::get_or_post($name);
		if($d === false) return false;
		if(!empty($time_part)) {	// change the time part, is actually a substitute string
			$d = substr($d,0,10); // just the date part
			$d .= ' ' . trim($time_part);	// add time_part, trim first in case
			} // if
		if(!self::checkdate($d)) return false;
		return $d;
		} // get_chk_date()

	public static function int2hstring($val) {	// reverse of hstring2int()
		$val = (int)trim($val);
		$num_brks = array(
			'T' => (1024 * 1024 * 1024 * 1024),
			'G' => (1024 * 1024 * 1024),
			'M' => (1024 * 1024),
			'K' => (1024),
			);
		$text = '';
		foreach ($num_brks as $t => $v) {
			if($val > (int)((float)$v * 0.75)) {
				$text = number_format(($val / $v)) . $t;
				break;
				} // if
			} // foreach
		if(empty($text)) $text = $val;
		return $text;
		} // int2hstring()

	public static function hstring2int($val) {	// convert a linux type human string (e.g. 12K, 25M or 2G from a typical -h cmd option) to an integer, case insensitive
		$val = trim($val);
		$last = strtolower($val[strlen($val)-1]);
		$val = (int)substr($val,0,-1);
		switch($last) {
		// The 'G' modifier is available since PHP 5.1.0, 'T' ???
		// case 't': $val *= 1024;
		case 'g': $val *= 1024;
		case 'm': $val *= 1024;
		case 'k': $val *= 1024;
		default:
			break;
			} // switch
		return $val;
		} // hstring2int()

	protected static function get_random_str($length = 29) {
		$rnd_str = '';
		if($fh = @fopen('/dev/urandom', 'r')) {
			while(strlen($rnd_str) < $length) {
				if(($ch = fgetc($fh)) !== false) {
					if(!preg_match('/[[:alnum:]]/',$ch)) continue;	// eventually, aaf generation (???)
					$rnd_str .= $ch;
					} // if
				} // while
			fclose($fh);
			return $rnd_str;
			} // if
		return false;
		} // get_secret_str()

	protected static function bld_form2post($url,$data_n_v_ary,$form_id = false,$inc_JS_submitor = true) {
		// builds a form to from a users browser
		$u_p = explode('?',$url);
		$f_url = $u_p[0];	// form action url
		$u_vs = explode('&',$u_p[1]);	// split name=value parts
		if(empty($form_id)) $form_id = 'id_' . self::get_random_str();
		$text = array();
		$text[] = '';
		$text[] = '<form id="' . $form_id . '" action="' . $f_url . '" method="post" enctype="multipart/form-data">';
		// add the url name=values from url
		foreach($u_vs as $vs) {
			$n_v = explode('=',$vs);
			$text[] = '<input type="hidden" name="'.htmlentities($n_v[0]).'" value="'.htmlentities($n_v[1]).'">';
			} // foreach
		// add the data
		foreach ($data_n_v_ary as $a => $b) {
			$text[] = '<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
			} // foreach
		$text[] = '</form>';
		$text[] = '';
		if($inc_JS_submitor) {
			$text[] = '<script type="text/javascript">';
			$text[] = '	document.getElementById("' . $form_id . '").submit();';
			$text[] = '</script>';
			$text[] = '';
			} // if

		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // bld_form2post()

	public static function chk_web_host_up($enc_url, $timeout_mS = false, $port = false, $ret_code = false) {
		$url = rawurldecode($enc_url);
		if(preg_match('/^file:\/\/\/.+/i',$url)) {	// file URL
			$filename = preg_replace('/^file:\/\//i','',$url);
			if(file_exists($filename)) {
				self::log_msg('URL: "' . $url . '" OK.','success');
				return $url;
				} // if
			self::log_msg('URL: "' . $url . '" does not exist.','info');
			return false;
			} // if
		// web URL
		if($ret_code) {
			$u_vals = @parse_url($url);
			$host = (!empty($u_vals['host']) ? $u_vals['host']:$u_vals['path']);	// a quirk in parse_url()
			//if(!empty($u_vals['port'])) $port = $u_vals['port'];
			if(empty($host)) return false;
			if(!checkdnsrr($host,'A')) {
				self::log_msg('URL: "' . $url . '" does not have a DNS A record.','info');
				return 404;
				} // if
			} // if

		$ch = curl_init($url);
		if(preg_match('/^http:\/\/.+/i',$url)) {
			curl_setopt($ch, CURLPROTO_HTTP, true);
			} // if
		else if(preg_match('/^https:\/\/.+/i',$url)) {
			curl_setopt($ch, CURLPROTO_HTTPS, true);
			} // else if
		else {
			curl_close($ch);	// don't run out of memory with orphans
			return false;	// what ???
			} // else
		curl_setopt($ch, CURLOPT_NOBODY, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
		curl_setopt($ch, CURLOPT_POSTREDIR, 7);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if(empty($timeout_mS)) $timeout_mS = 1000;
		if($timeout_mS) {
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout_mS);
			curl_setopt($ch, CURLOPT_TIMEOUT_MS, ($timeout_mS * 2));
			} // if
		if((int)$port > 10) curl_setopt ($ch, CURLOPT_PORT, (int)$port);
		$result = curl_exec($ch);
		$info = curl_getinfo($ch);
		curl_close($ch);	// don't run out of memory with orphans
		if($result === false) {
			self::log_msg('URL: "' . $url . '" failed to respond.','warn');
			return false;
			} // if
		$new_url = $info['url'];
		$stat = self::get_url_response_str($info['http_code']);
		if(200 == $info['http_code']) {
			self::log_msg('URL: "' . $url . '" ok response "' . $stat . '".','success');
			return $new_url;	// ok
			} // if
		else if(301 == $info['http_code']) {
			self::log_msg('URL: "' . $url . '" redirect response "' . $stat . '".','warning');
			return $new_url;	// ok
			} // else if
		else if(302 == $info['http_code']) {
			self::log_msg('URL: "' . $url . '" redirect response "' . $stat . '".','warning');
			return $new_url;	// ok
			} // else if
		self::log_msg('URL: "' . $url . '" response "' . $stat . '".','info');
		if(($ret_code) && (!empty($info['http_code'])) && (is_numeric($info['http_code']))) return $info['http_code'];
		return false; // ???
		} // chk_web_host_up()

	public static function host_check($addr, $port = -1, $timeout = 2) {
		$u_vals = @parse_url($addr);
		$host = (!empty($u_vals['host']) ? $u_vals['host']:$u_vals['path']);	// a quirk in parse_url()
		if(empty($host)) return false;
		if(!empty($u_vals['port'])) $port = $u_vals['port'];
		else if(($port == -1) && (!empty($u_vals['scheme']))) {
			switch(strtolower($u_vals['scheme'])) {
			case 'ssh': $port = 22; break;
			case 'rsync': $port = 873; break;
			case 'ldap': $port = 389; break;
			case 'sftp': $port = 22; break;
			case 'ftp': $port = 21; break;
			case 'http': $port = 80; break;
			case 'https': $port = 443; break;
			case 'pop3': $port = 110; break;
			case 'imap': $port = 143; break;
			case 'smb': $port = 445; break;
			case 'nfs': $port = 2049; break;
			case 'rdp': $port = 3389; break;
			case 'svn': $port = 3690; break;
			case 'mysql': $port = 3306; break;
			case 'postgresql': $port = 5432; break;
			case 'postgre': $port = 5432; break;
			default: break;
				} // switch
			} // else if
		// else a unix::// socket
		$fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
		if (!$fp) return false;
		fclose($fp);
		return true;
		} // host_check()

	public static function sanitiseText4Html($sStr,$cleanTail = true,$lf2br = true) {	// sanitise sStr to html compatibility
		$unknown = '';
		$sStr = str_replace(chr(0x0d),'',$sStr);	// windows !!
		$sStr = stripslashes($sStr);
		//$sStr = html_entity_decode($sStr,ENT_COMPAT,INI_CHAR_SET);
		//$sStr = html_entity_decode($sStr,ENT_COMPAT,INI_CHAR_SET);
		//$sStr = html_entity_decode($sStr,ENT_COMPAT,INI_CHAR_SET);	// make sure all pre-encoding is gone
		$sStr = str_replace('&nbsp;',' ',$sStr);	// this seems to bring a bug in php/server language settings !!
		// return $sStr;

		$sSane = "";
		$idx = 0;
		while($idx < strlen($sStr)) {
			$cChr = ord(substr($sStr,$idx++,1));
			switch($cChr) {
			case 0xef:	// ef df db -> unknown glyph or UTF leader; could be 'tm',apostrophe, grave accent, or ...
				// remove it
				$idx++;
				$idx++;
				break;

			case 0x9:	// tab
				$sSane .= chr($cChr);
				break;
			// case 0xd:	// carriage retuen
			case 0xa:	// line feed
				if($lf2br) $sSane .= '<br>' . chr($cChr); // need to clean up later
				break;

			// the html entities used
			case '&': $sSane .= '&amp;'; break;
			case '<': $sSane .= '&lt;'; break;
			case '>': $sSane .= '&gt;'; break;
			case '"': $sSane .= '&quot;'; break;
			case 0x96: $sSane .= '&#96;'; break;
			case 0x27: $sSane .= '&rsquo;'; break;

			// language specials
			case 0xa2: $sSane .= "&cent;"; break;
			case 0xa3: $sSane .= "&pound;"; break;
			case 0xa4: $sSane .= "&curren;"; break;
			case 0xa5: $sSane .= "&yen;"; break;
			case 0xa6: $sSane .= "&brvbar;"; break;
			case 0xa7: $sSane .= "&sect;"; break;
			case 0xa9: $sSane .= "&copy;"; break;
			case 0xab: $sSane .= "&laquo;"; break;
			case 0xae: $sSane .= "&reg;"; break;
			case 0xb0: $sSane .= "&deg;"; break;
			case 0xb1: $sSane .= "&plusmn;"; break;
			case 0xb2: $sSane .= "&sup2;"; break;
			case 0xb3: $sSane .= "&sup3;"; break;
			case 0xb5: $sSane .= "&micro;"; break;
			case 0xb9: $sSane .= "&sup1;"; break;
			case 0xbb: $sSane .= "&raquo;"; break;
			case 0xbc: $sSane .= "&frac14;"; break;
			case 0xbd: $sSane .= "&frac12;"; break;
			case 0xbe: $sSane .= "&frac34;"; break;
			case 0xd7: $sSane .= "&times;"; break;
			case 0xe2: $sSane .= "&trade;"; break;	// an anomaly in some charset conversions
			case 0xf7: $sSane .= "&divide;"; break;

			// MS Word cockups
			case 0x92: $sSane .= "&rsquo;"; break;	// '&#39;'

			default:
				if(($cChr >= ' ') && ($cChr < 0x7f)) {
					$sSane .= chr($cChr);
					} // if
	//			else {	// language char
	//				$sSane .= self:convert_language_char2html($cChr);
	//				} // else
				break;
				} // switch
			} // while

	// not good enough for the rubbish we get		$sSane = htmlentities($sStr,ENT_QUOTES);

		// remove some of silly things people do
		$sSane = str_replace("''", '&quot;', $sSane);
		$sSane = str_replace("&#039;&#039;", '&quot;', $sSane);
		$sSane = str_replace('&rsquo;&rsquo;', '&quot;', $sSane);
		$sSane = str_replace('&quot;&quot;', '&quot;', $sSane);
		$sSane = str_replace('&rsquo;', '&#039;', $sSane);
		// $sSane = str_replace('&amp;nbsp;', '&nbsp;', $sSane);

		if($cleanTail) {
			$chkOK = false;
			while(!$chkOK) {
				$chkOK = true;
				while(substr($sSane, -1, 1) == PHP_EOL) { $chkOK = false; $sSane = substr($sSane, 0, -1); }	// remove trailing \n
				while(substr($sSane, -4, 4) == "<br>") { $chkOK = false; $sSane = substr($sSane, 0, -4); }	// remove trailing <br>
				while(substr($sSane, -1, 1) == ' ') { $chkOK = false; $sSane = substr($sSane, 0, -1); }	// remove trailing spaces
				} // while
			} // if

		// $sSane = htmlentities($sSane,ENT_COMPAT,INI_CHAR_SET);
		// $sSane = self::output_string_protected($sSane);
		// $sSane = nl2br($sSane);
		// $sSane = str_replace('&lt;br /&gt;','<br />',$sSane);
		$sSane = str_replace('<br />','<br>',$sSane);
		$sSane = str_replace('<br><br>','<br>',$sSane);
		$sSane = str_replace('><br>' . PHP_EOL,'>' . PHP_EOL,$sSane);
		$sSane = str_replace('><br>' . PHP_EOL,'>' . PHP_EOL,$sSane);

		return $sSane;
	} // sanitiseText4Html()

	public static function nl2br($str) {
		// a replacement for the PHP nl2br() function
		// which doesn't do as expected on '\n', only on PHP_EOL etc.
		$tmp = nl2br($str);	// do the "normal" replaces
		$pat = '/\\\\r\\\\n|\\\\n\\\\r|\\\\n|\\\\r/';
		$html = preg_replace($pat,'<br>',$tmp);
		return str_replace('\\','',$html);
		} // nl2br()

	public static function get_current_body_uri($params = array()) {
		if(self::is_cli()) return ''; // @TODO why are we here in CLI
		if(self::$body_id) $body_id = self::$body_id;
		// else $body_id = self::get_or_post('body');
		if(empty($body_id)) {
			if(isset($_SESSION['last_url'])) {
				$u_vals = parse_url($_SESSION['last_url']);
				if(isset($u_vals['query'])) {
					if(preg_match('/body=([0-9a-zA-Z]+)/',html_entity_decode($u_vals['query']))) {
						$body_id = preg_replace('/^.*body=([0-9a-zA-Z]+)&.+$/','$1',html_entity_decode($u_vals['query']));
						$uri = Ccms::get_body_uri($body_id);
						} // if
					} // if
				} // if
			if(empty($body_id)) $uri = $_SERVER['PHP_SELF'];	// @TODO BAD a guess
			} // if
		else $uri = Ccms::get_body_uri($body_id);
		if(!empty($params)) {
			if(strpos($uri,'?')) $uri .= '&';
			else $uri .= '?';
			$uri .= (is_array($params) ? implode('&', $params):$params);
			} // if
		return $uri; // don't overcook	urlencode($uri);
		} // get_current_body_uri()

	public static function chk_geo_location() {
		$latitude = self::get_or_post('geo_latitude');
		$longitude = self::get_or_post('geo_longitude');
		$accuracy = self::get_or_post('geo_accuracy');
		$loc_time = time();
		if((!empty($latitude)) && (!empty($longitude))) {	// save from form
			$_SESSION['geo_location']['latitude'] = $latitude;
			$_SESSION['geo_location']['longitude'] = $longitude;
			$_SESSION['geo_location']['accuracy'] = $accuracy;
			$_SESSION['geo_location']['loc_time'] = $loc_time;
			} // if
		else if((isset($_SESSION['geo_location']['latitude'])) &&
			(isset($_SESSION['geo_location']['longitude'])) &&
			(isset($_SESSION['geo_location']['loc_time'])) &&
			(isset($_SESSION['geo_location']['accuracy']))) {
			$latitude = $_SESSION['geo_location']['latitude'];
			$longitude = $_SESSION['geo_location']['longitude'];
			$accuracy = $_SESSION['geo_location']['accuracy'];
			$loc_time = $_SESSION['geo_location']['loc_time'];
			} // else if
		else return false;
		self::$geo_location_latitude = $latitude;
		self::$geo_location_longitude = $longitude;
		self::$geo_location_accuracy = $accuracy;
		self::$geo_location_loc_time = $loc_time;
		return true;	// got it
		} // chk_geo_location()

	public static function get_preferred_user_language() {
		// e.g. $_SERVER['HTTP_ACCEPT_LANGUAGE'] = "en-AU,en-US;q=0.7,en;q=0.3";
		if((!isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) ||
			(empty($_SERVER['HTTP_ACCEPT_LANGUAGE']))) {
			return (defined('INI_LANGUAGE_CODE') ? INI_LANGUAGE_CODE:Ccms::get_cms_ini_value('INI_LANGUAGE_CODE'));
			} // if
		$lang_qs = explode(',',$_SERVER['HTTP_ACCEPT_LANGUAGE']);
		$langs = array();
		foreach($lang_qs as $lq) {
			$l_q = explode(';',$lq);
			if(isset($l_q[1])) $langs[($l_q[0])] = (int)substr($l_q[1],2);
			else $langs[($l_q[0])] = (int)1;
			} // foreach
		krsort($langs);
		reset($langs);
		$hk = ''; $hq = 0.0;
		foreach ($langs as $key => $val) {	// this should not be necessary !!!!
			if($val > $hq) { $hq = $val; $hk = $key; }	// pick highest Q
			} // foreach
		return $hk;
		} // get_preferred_user_language()

	public static function get_user_locale() {
		if(self::is_cli()) {
			return (defined('INI_LANGUAGE_CODE') ? INI_LANGUAGE_CODE:Ccms::get_cms_config_value('INI_LANGUAGE_CODE'));
			} // if
		if(!function_exists('locale_accept_from_http')) {	// uninstalled pkg
			$lang = (!empty($_SESSION['clientMetadata']['user_lang']) ? $_SESSION['clientMetadata']['user_lang']:false);	// from horse's mouth
			if(!$lang) $lang = self::get_preferred_user_language();	// browser ?!?!
			return $lang;
			} // if
		// use a bit more sophification
		if((empty($lang)) && (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) &&
			(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE']))) {
			$locale = locale_accept_from_http($_SERVER['HTTP_ACCEPT_LANGUAGE']);
			} // if
		else if(!empty($lang)) $locale = locale_accept_from_http($lang);
		else $locale = false;
		if(empty($locale)) {
			$lang = self::get_preferred_user_language();	// browser ?!?!
			$locale = locale_accept_from_http($lang);
			} // if
		return $locale;
		} // get_user_locale()

	public static function can_connect2host($host, $port, $tval = 15, $logit = true) {
		// set the error val to null so there is no confusion
		$error = null;
		$errstr = null;
		if((int)$tval < 1) $tval = 1;

		$h_p = parse_url($host);
		if(empty($port)) {
			if(!isset($h_p['port'])) {
				switch($h_p['scheme']) {
				case 'http':
					$port = 80;
					break;
				case 'https':
					$port = 443;
					break;
				case 'ssh':
					$port = 22;
					break;
				// and other possibilities
				default:
					return false;
					} // switch
				} // if
			else $port = $h_p['port'];
			} // if
		else if((isset($h_p['port'])) && ((int)$port != (int)$h_p['port'])) {
			// conflicted
			if($logit) {
				self::log_msg('Host "' . $host . '" has conflicting ports: ' . $port . ' and ' . $h_p['port']);
				} // if
			return false;
			} // else if
		if(isset($h_p['host'])) $host = $h_p['host'];
		else if(isset($h_p['path'])) $host = $h_p['path'];	// this appears to be a bug in PHP 7.2.14 if the host is numeric.
		else if(count($h_p) > 1) $host = false;
		if(empty($host)) return false;

		// connect to the server
		$conn = @fsockopen(
			$host,    // the host of the server
			$port,    // the port to use
			$errno,   // error number if any
			$errstr,  // error message if any
			$tval);   // give up after ? secs

		// verify we connected properly
		if(empty($conn)) {
			if($logit) {
				self::log_msg('Host: ' . $host . ':' . $port . ', failed to connect. ' . 'Err#' . $errno . ': ' . $errstr,'warn');
				} //if
			return false;
			} // if
		fclose($conn);
		return true;
		} // can_connect2host()

	private static function is_url_headers_ok(&$headers) {
		if(!$headers) {	// ssl self signed ???
			return false;
			} // if
		if(isset($headers[0])) {
			if($headers[0] == "HTTP/1.1 200 OK") return true;
			} // if
		return false;
		} // is_url_headers_ok()

	protected static function get_chk_url($uri) {	// find the uri source
		if(empty($uri)) return false;
		if(preg_match('/http:|https/i',$uri)) {	// a remote host
			$headers = @get_headers($uri);
			if(self::is_url_headers_ok($headers)) return $uri;
			return false;
			} // if

		// check local
		// local on this web site
		$headers = @get_headers($uri);
		if(self::is_url_headers_ok($headers)) return $uri;

		// local on this host
		$url = ((self::$ssl_in_use || self::$ssl_required) ? CMS_SSL_URL:CMS_WWW_URL) . $uri;
		$headers = @get_headers($url);
		if(self::is_url_headers_ok($headers)) return $url;

		return false;
		} // get_chk_url()

// dynamic methods
	protected function log_http_access($type = 'access') {
		if(self::is_cli()) return false;	// not logged in CLI mode
		if((!CMS_C_LOG_ACCESS_ENABLE) && (!CMS_C_LOG_AJAX_ENABLE)) return false;
		if(self::$access_logged) return false;
		self::$access_logged = true;	// once only
		$access = 'ClientIP=' . Ccms_auth::get_client_ip_address();
		if(!empty($_SERVER['HTTPS']))
			$access .= ',https=' . $_SERVER['HTTPS'];
		if(!empty(self::$ajax)) {
			if(CMS_C_LOG_AJAX_ENABLE) {
				$access .= ',AJAX=' . self::$ajax;
				} // if
			else return false;
			} // if
		else {
			$access .= ',Device=' . (self::$tiny_flg ? 'tiny':(self::$tablet_flg ? 'tablet':'desktop'));
			if(!empty($_SERVER['REQUEST_URI']))
				$access .= ',Request_URI="' . $_SERVER['REQUEST_URI'] . '"';
			if(!empty(self::$visitor_cnt))
				$access .= ',Visitor=' . self::$visitor_cnt;
			} // else
		if(self::is_debug()) {
			if(!empty($_POST)) {
				$access .= ',POST="' . rawurldecode(http_build_query($_POST)) . '"';
				} // if
			if(!empty($_FILES)) {
				$access .= ',FILES="' . rawurldecode(http_build_query($_FILES)) . '"';
				} // if
			} // if
		return self::log_msg ($access, $type);
		} // log_http_access()

	public static function get_pretty_html_doc($text,$enclose = true) {
		// see "https://www.php.net/manual/en/tidy.examples.basic.php"
		if(!class_exists('tidy')) return $text;	// tidy not installed

		if(($enclose) && (!preg_match('/<html|<head|<body/im',$text))) {
			// just basic html text
			$tmp = '<!DOCTYPE><html><head></head><body>' . PHP_EOL . $text . PHP_EOL . '</body></html>';
			$text = $tmp;
			} // if
		// Specify configuration
		$config = array(
			'indent'         => true,
			'output-xhtml'   => true,
			'wrap'           => 200);

		// Tidy
		$tidy = new tidy;
		$tidy->parseString($text, $config, 'utf8');
		$tidy->cleanRepair();

		// Output
		if($enclose) {
			$body = $tidy->body();
			$html = preg_replace('/<body>|<\/body>/im','',$body->value);
			return $html;
			} // if
		else $html = $tidy->html();
		return $html->value;
		} // get_pretty_html_doc()

} // Ccms_base
