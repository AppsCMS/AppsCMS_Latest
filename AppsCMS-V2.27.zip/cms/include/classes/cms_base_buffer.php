<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_base_buffer.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of cms_base_buffer
 *
 * @author robert0609
 */

require_once 'cms_msgs.php';	// speed up for proxy (no autoloader needed)

class Ccms_base_buffer extends Ccms_msgs {

	public $prn_flg = true; // true = print $this->text direct (false = buffer it for a $this->get_buffered_text() call)
	protected $text = array();	// an accumlative text buffer array, call $this->prn_or_buffer_text() to print intermediate buffing (and put in html debug markers)

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function is_debug() {
		if(is_null(self::$is_debug)) {
			if(defined('INI_DEBUG_BOOL')) self::$is_debug = INI_DEBUG_BOOL;
			else return true;
			} // if
		return self::$is_debug;
		} // is_debug()

	public static function is_production() {
		if(is_null(self::$is_production)) {
			$production = (!defined('CMS_C_WEB_SITE_ADDRESS') ? Ccms::get_cms_config_value('CMS_C_WEB_SITE_ADDRESS'):CMS_C_WEB_SITE_ADDRESS);
			$production = preg_replace('/^http[s]*:\/\//', '', $production);
			$production = preg_replace('/\/.*$/', '', $production);

			$current = CMS_DOMAIN;
			self::$is_production = (($production == $current) ? true:false);
			} // if
		return self::$is_production;
		} // is_production()

	public static function flush_out_msg($msg) {	// output an iterative on a single line using line refresh
		if(!self::is_cli()) {
			if(!empty($msg))
				echo '<p>' . nl2br($msg) . '</p>' . PHP_EOL;
			ob_flush();
			flush();
			} // if
		else if(!empty($msg)) {
			system('echo -en \'                     \r\'; echo -n "' . $msg . '"');
			} // else if
		} // flush_out_msg()

	protected static function ipCIDRCheck($IP, $CIDR) { // virtual
		return true;
		} // ipCIDRCheck()

	public static function can_test() {
		if(!is_null(self::$can_test)) return self::$can_test;
		if(!self::is_cli()) {
			self::$can_test = false;
			return self::$can_test;
			} // if
		$can_test_ips = '';
		if(!defined('INI_CAN_TEST_APPS_CIDR'))
			$can_test_ips = self::get_cms_ini_value ('CAN_TEST_APPS_CIDR','AppsControlSettings');	//
		else $can_test_ips = INI_CAN_TEST_APPS_CIDR;
		if(strlen($can_test_ips) < 4) {
			self::$can_test = false;
			return self::$can_test;
			} // if
		$nets = explode(',',$can_test_ips);
		foreach($nets as $net) {
			if($net == '!0.0.0.0') {
				self::$can_test = false;
				break;
				} // if
			if($net == '0.0.0.0') {
				self::$can_test = true;
				break;
				} // if
			if(self::ipCIDRCheck(self::$client_ip,$net)) {
				self::$can_test = true;	// on test network
				break;
				} // if
			} // foreach
		return self::$can_test;
		} // can_test()

	protected static function get_backtrace($levels = 1) {
		if($levels < 1) $level = 1;
		// not $levels++;	// one for me
		$l_idx = $levels - 1;
		$dbt = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,$levels);
		$caller = '';
		if(isset($dbt[$l_idx]['class'])) {
			$caller .= $dbt[$l_idx]['class'];
			if(isset($dbt[$l_idx]['type'])) {
				$caller .= $dbt[$l_idx]['type'];
				} // if
			else $caller .= '::';
			} // if
		if(isset($dbt[$l_idx]['function'])) {
			$caller .= $dbt[$l_idx]['function'];
			} // if
		if(isset($dbt[$l_idx]['line'])) {
			$caller .= ', line=' . $dbt[$l_idx]['line'];
			} // if
		return $caller;
		} // get_backtrace()

// dynamic methods
	protected function prn_or_buffer_text($text = false) {
		if(self::is_debug()) {
			$caller = '<!-- Caller="' . self::get_backtrace(2) . '" -->';
			$this->text[] = $caller;
			} // if
		if(is_string($text)) $this->text[] = $text;	// using $text here is the slow way, add to the $this->text array directly
		if($this->prn_flg) {
			echo PHP_EOL . implode(PHP_EOL,$this->text) . PHP_EOL;
			$this->text = array();	// clear it
			} // if
		return '';	// do nothing
		} // prn_or_buffer_text()

	protected function get_buffered_text() {
		$text = PHP_EOL . implode(PHP_EOL,$this->text) . PHP_EOL; // wasteful
		$this->text = '';	// but !!
		return $text;
		} // get_buffered_text()

	public static function set_chk_php_value($name,$val,$chk = false) {
		if($chk) {
			$cur = ini_get($name);
			if($cur != $val) {
				self::log_msg('Require PHP "' . $name . '" = "' . $val . '", have "' . $cur .'".','warn');
				return false;
				} // if
			return true;
			} // if
		$old = ini_set($name,$val);
		$chk = ini_get($name);
		if($chk != $val) {
			self::log_msg('Cannot set PHP "' . $name . '" to "' . $val . '", have "' . $chk .'".');
			return false;
			} // if
		return true;
		} // set_chk_php_value()

} // Ccms_base_buffer
