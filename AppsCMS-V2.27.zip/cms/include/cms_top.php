<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_top.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

// Set the level of error reporting
error_reporting(E_ALL | E_STRICT);

if(file_exists('cms/include/cms_configure.php')) require_once 'cms/include/cms_configure.php';
elseif(file_exists('include/cms_configure.php')) require_once 'include/cms_configure.php';
elseif (file_exists('../../cms/include/cms_configure.php')) require_once '../../cms/include/cms_configure.php'; // for apps to run in (APP_DIR)
else die('ERROR: Failed to find AppsCMS configuration.');

require_once CMS_FS_INCLUDES_DIR . 'cms_auto_class_loader.php';

if(Ccms::$ajax) return;

if(!empty(Ccms::$page_info['redirect_url'])) {
	$url = Ccms::$page_info['redirect_url'];
	Ccms::$page_info['redirect_url'] = false;
	header('Location: ' . $url,true,301);
	exit(0);
	} // if

if((Ccms::$page_info['closed']) &&
	(!Ccms_auth::is_admin_user())) {	// don't squash admin already logged in
	if(Ccms::$cms_action == 'cms_login')
		$_SESSION['cms_action'] = 'cms_login';	// remember its a login sequence
	if(((!isset($_SESSION['cms_action'])) || ($_SESSION['cms_action'] != 'cms_login')) &&
		(Ccms::$cms_action != 'cms_login')) {
		include(CMS_FS_OPS_DIR . "cms_closed.php");
		require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';
		exit(0);
		} // if
	} // if

