<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_bodies_menu.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

	if((!INI_PAGE_DB_MENU_BOOL) ||
		(Ccms::get_body_cnt() <= 0))
		return;

	$bodies = Ccms::get_bodies();
	$mm_row = 0;
	Ccms::page_start_comment(__FILE__);

	$body_menu = array(
		'th' => array(
			'text' => (INI_NAV_BAR_BOOL ? 'Sub Menu:':'Main Menu:'),
			'title' => (INI_NAV_BAR_BOOL ? 'More':'Menu') . " items. Click to select.",
			),
		'td' => array(),
		);
	// add 'td's in display order
	foreach($bodies as &$body) {
		if((int)$body['login_page'] > 0) continue;
		$body_menu['td'][] = array(
			'url' => $body['url'],
			'title' => $body['title'],
			'text' => $body['name'],
			);
		} // foreach
	if(Ccms::is_links_manager_inuse()) {
		$body_menu['td'][] = array(
			'url' => 'index.php?cms_action=lm_show_links',
			'title' => "Goto Links Manager page",
			'text' => 'Links',
			);
		} // if

	if(self::$tiny_flg) {
		$text = Ccms::get_header_tools_pdb_text(false);
		if(!empty($text)) {
			$body_menu['td'][] = array(
				'url' => '',
				'title' => "",
				'text' => $text,
				);
			} // if
		} //if
	new Ccms_generate_Vmenu('bmenu','bodies_pdb_container',$body_menu);
	Ccms::page_end_comment(__FILE__);

