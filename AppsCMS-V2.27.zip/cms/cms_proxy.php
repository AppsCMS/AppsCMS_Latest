<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_proxy.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

	// the proxy operation needs to be as fast as possible

require_once 'include/cms_configure.php';
require_once 'include/classes/cms_proxy.php';

if(Ccms_proxy::is_get_or_post('proxy')) { // from client either side of the firewall
	Ccms_proxy::output_proxy_file();
	exit;
	} // if

require_once 'include/classes/cms_reverse_proxy.php';
$revproxy = new Ccms_reverse_proxy();

// EOF
