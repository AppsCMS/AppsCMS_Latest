/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_title_tooltips.js 1961 2021-01-25 10:09:54Z robert0609 $
 */

// tooltip js code
	
var cms_titletipOps = [];	// place to save Ccms_title2tooltip iterations
var Ccms_title2tooltip = function(el,type,tablet_flg) {
	var elem = el;
	var titletip = false;
	var h_margin = 25;
	var v_margin = 15;
	var tag = type;
	var tablet = tablet_flg;
	var title_text = elem.getAttribute("title");

	this.titletipShow = function (evt) {
		if(!titletip) return;
		if(this.disabled) {
			// this.titletipHide(evt);
			return;
			} // if

		// get window client are
		var w = window.innerWidth;
		var h = window.innerHeight;

		// get the position of the hover element
		var evtBox = evt.target.getBoundingClientRect();
		var ttBox = titletip.getBoundingClientRect();

		// adjust titletip position
		var h_offset;
		if (evtBox.left < (w / 2)) {	// left half of window
			h_offset = evtBox.left + (evtBox.width / 2) + h_margin;
		} // if
		else {	// right half of window
			h_offset = evtBox.left + (evtBox.width / 2) - ttBox.width - h_margin;
		} // else
		titletip.style.left = h_offset.toString() + "px";

		var v_offset;
		if (evtBox.top < (h / 2)) {	// top half of window
			v_offset = evtBox.top + evtBox.height + v_margin;
		} // if
		else {	// bottom half of window
			v_offset = evtBox.top - ttBox.height - v_margin;
		} // else
		titletip.style.top = v_offset.toString() + "px";

		// make titletip VISIBLE
		titletip.style.visibility = "visible";
		titletip.style.opacity=1;
		} // titletipShow()

	this.titletipHide = function(evt) {
		if(!titletip) return;
		titletip.style.visibility="hidden";
		titletip.style.opacity=0;
		} // titletipHide()

	this.titletipRestore = function() {
		if(!titletip) return;
		titletip.style.visibility="hidden";
		titletip.style.opacity=0;
		if (title_text != null) {
			elem.setAttribute('title',title_text);	// turn on old title
			if(!tablet) {
				// assign handler
				elem.removeEventListener("mouseover", this.titletipShow , false);
				elem.removeEventListener("mouseout", this.titletipHide , false);
				} // if
			else { // a tablet, ipad, etc
				elem.removeEventListener("onclick", this.titletipShow , false);
				} // else
		   } // if
		titletip.parentNode.removeChild(titletip);
		} // titletipRestore()

	if ((title_text != null) && (title_text.length > 0)) {
		// create balloon element to display info
		titletip = document.createElement("div");
//		if(tag == 'OPTION') {
//			// debug test
//			console.log(titletip);
//			} // if
		if(!titletip) return;

		// add titletip content now to get sizes
		titletip.innerHTML = '<span class="cms_title_tooltip" ' + (tablet ? ' onclick="this.style.visibility=\'hidden\'; this.style.opacity=0;";':'') + '>' + title_text.replace(/\\n|&#10;/gi,'<br>') + '</span>';

		// set class
		titletip.className="cms_title_tooltip";

		// set style
		titletip.style.visibility="hidden";
		titletip.style.opacity=0;
		titletip.style.position="fixed";
		titletip.style.top="1ex";
		titletip.style.left="1ex";
		titletip.style.zIndex="10000";

		// insert into DOM
		var txt_node = document.createTextNode('');
		titletip.appendChild(txt_node);
		document.body.insertBefore(titletip, document.body.firstChild);

		if(!tablet) {
			// assign handler
			elem.addEventListener("mouseover", this.titletipShow , false);
			elem.addEventListener("mouseout", this.titletipHide , false);
			} // if
		else { // a tablet, ipad, etc
			elem.addEventListener("onclick", this.titletipShow , false);
			} // else

		// alert(title_text);
		elem.setAttribute('title','');	// turn off old title
		} // if
	};	// Ccms_title2tooltip

var is_tablet = false;
function cms_titles2tooltips(tablet_flg) {
	is_tablet = tablet_flg;
	var idx = 0;
	var elems = document.getElementsByTagName("*");
	for (var i=0; i< elems.length; i++) {
		var elem = elems[i];
		var tag_name = elem.tagName;
		if(tag_name == 'OPTION') continue;	// let browser do options @TODO fix
		var title_text = elem.getAttribute("title");
		if ((title_text != null) && (title_text.length > 0)) {
			cms_titletipOps[idx++] = new Ccms_title2tooltip(elem,tag_name,is_tablet);  // stick it
			} // if
		} // for
	} // cms_titles2tooltips()

function cms_addElem_title2tooltip(elem) {
	var idx = cms_titletipOps.length;
	var tag_name = elem.tagName;
	if(tag_name != 'OPTION') {	// let browser do options @TODO fix
		var title_text = elem.getAttribute("title");
		if ((title_text != null) && (title_text.length > 0)) {
			cms_titletipOps[idx++] = new Ccms_title2tooltip(elem,tag_name,is_tablet);  // stick it
			} // if
		} // if
	// check children
	var chldn = elem.childNodes;
	for (var i = 0 ; i < chldn.length; i++) {
		var elem = chldn[i];
		var tag_name = elem.tagName;
		if(tag_name == 'OPTION') continue;	// let browser do options @TODO fix
		var title_text = elem.getAttribute("title");
		if ((title_text != null) && (title_text.length > 0)) {
			cms_titletipOps[idx++] = new Ccms_title2tooltip(elem,tag_name,is_tablet);  // stick it
			} // if
		} // for
	} // cms_addElem_title2tooltip()

function cms_tooltips2titles() {
	for (var i = (cms_titletipOps.length - 1); i >= 0; i--) {
		cms_titletipOps[i].titletipRestore();	// restore titel it
		delete cms_titletipOps[i];
		cms_titletipOps[i] = false;
		} // for
	cms_titletipOps = [];
	} // cms_tooltips2titles()

