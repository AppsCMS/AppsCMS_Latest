#!/bin/bash
# see Licence in cms/LICENCE.txt
# SVN Build: $Id: cms_DB_create.sh 1961 2021-01-25 10:09:54Z robert0609 $
# create AppsCMS MySQL database

FVERSION="V2.15"

USAGE="USAGE: $(basename "$0") ADMIN_USER ADMIN_PASSWORD\n
	for the configured MySQL HOST admin to create the credentials bokk keeper.\n"

echo "Create AppsCMS DataBase ($FVERSION)."
if [ -z "$1" -o -z "$2" ]; then
	echo -e "$USAGE"
	exit 1
fi
A_USER="$1"
A_PASSWD="$2"

php cms_DB_create.php "$A_USER" "$A_PASSWD"

echo "Done ($FVERSION)"

exit 0

