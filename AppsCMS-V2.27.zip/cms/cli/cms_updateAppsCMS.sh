#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_updateAppsCMS.sh 2016 2021-03-22 07:43:00Z robert0609 $
# set -x
# Update AppsCMS from internet

FVERSION=V2.27
PROG="$(basename "$0")"
echo "$PROG $FVERSION"

CUR_DIR="$(pwd)"	# make dirs relative to this script
cd "$CUR_DIR"
DO_UPD=0
SET_PERMS=0	# default to not set permisions (needs sudo)
SUZOO="$(sudo -l -U $USER | grep '(ALL)' | grep 'NOPASSWD')"
if [ ! -z "$SUZOO" ]; then SET_PERMS=1; echo "Using sudo ALL"; fi	# in the sudo zoo

USE_JSON=''	# default to not to use cms.sqlite.json to rebuild
USAGE="USAGE: $(basename $0) [--help] [--update [--use-json]]"
INFO="Refer to Technical Manual for more information."

while [ ! -z "$1" ]
do
	case "$1" in
		--update)
			DO_UPD=1
			;;
		--use-json)
			USE_JSON='--use-json'
			;;
		* )
			echo $USAGE
			echo $INFO
			exit 1
			;;
	esac
	shift
done
if [ $DO_UPD -ne 1 ]; then
	echo "No operation requested, exiting."
	echo $USAGE
	echo $INFO
	exit 0
fi

DT="$(date '+%Y%m%d-%H%M%S')"
LOG="var/logs/CLI_cms-$(date '+%Y%m%d').log"

if [ ! -f "etc/ini/cms.ini" ];	then # check if remote update is setup
	echo "Remote update URLs not setup (1)."
	exit 3
fi
ALLOW="$(cat "etc/ini/cms.ini" | grep 'CMS_UPDATER_ALLOW_BOOL = "true"')"
if [ -z "$ALLOW" ]; then
	echo "Online update not enabled."
	exit 3
fi

# update scr
BASE_URI="$(cat "etc/ini/cms.ini" | grep 'CMS_UPDATER_BASE_URI' | awk '{ print $3 }' | sed 's|"||g')"	# typically "https://github.com/AppsCMS/AppsCMS_Latest/raw/master/"
echo "BASE_URI=$BASE_URI"	# test
ALT_BASE_URI="$(cat "etc/ini/cms.ini" | grep 'CMS_UPDATER_ALT_BASE_URI' | awk '{ print $3 }' | sed 's|"||g')"	# typically "http://www.appscms.org/dist-src/"
echo "ALT_BASE_URI=$ALT_BASE_URI"	# test

LATEST="AppsCMS-latest.zip"
if [ -f "$LATEST" ]; then	# clean up
	mv -f "$LATEST" var/temp/
fi
#not used INSTALLERLATEST="AppsCMS-Installer-latest.sh"
# if [ -f "$INSTALLERLATEST" ]; then	# clean up
#	mv -f "$INSTALLERLATEST" var/temp/
# fi

DEBUG=0
if [ -f "dist-src/${LATEST}" ];	then # check if debug
	DG="$(cat "etc/ini/cms.ini" | grep 'DEBUG_BOOL = "true"')"
	# echo "DG=$DG"	# test
	if [ ! -z "$DG" ]; then
		DEBUG=1
		echo "Debug mode (using dist-src/${LATEST})" | tee -a "${LOG}"
		LATEST="dist-src/AppsCMS-latest.zip"
		# INSTALLERLATEST="dist-src/AppsCMS-Installer-latest.sh"
	fi
fi

if [ $DEBUG -eq 0 ]; then	# download zip
	wget --no-check-certificate -O "${CUR_DIR}/${LATEST}" "${BASE_URI}${LATEST}"
	if [ $? -ne 0 ]; then
		wget --no-check-certificate -O "${CUR_DIR}/${LATEST}" "${ALT_BASE_URI}${LATEST}"
		if [ $? -ne 0 ]; then
			echo "Failed to retrieve update."
			exit 1
		fi
	fi
fi

echo ""
if [ ! -d "cms" ]; then
	echo "cms/ does not exist."
	exit 1
fi
# exit 10	# test

echo "Starting update on \"$(pwd)\" at $DT." | tee -a "${LOG}"

OV=""
if [ -f "cms/include/cms_configure.php" ];	then # lookup version
	V=$(cat "cms/include/cms_configure.php" | grep CMS_PROJECT_VERSION)
	# echo "V=$V"	# test
	if [ ! -z "$V" ]; then
		F=${V##*\"V}
		OV="V${F%%\"*}"
		echo "$(pwd) old version is $OV" | tee -a "${LOG}"
	fi
fi
zip "var/backups/cms-backup-${OV}-$DT.zip" "cms/" | tee -a "${LOG}"
echo "Backup \"cms/\" to \"var/backups/cms-backup-${OV}-$DT.zip\"." | tee -a "${LOG}"
# exit	# test

unzip -o "${CUR_DIR}/${LATEST}" 'cms/*' -d "$WC" > /dev/null
RET=$?
if [ $RET -ne 0 ]; then
	echo "FAILED to update \"$(pwd)\" to $FVERSION." | tee -a "${LOG}"
	exit 2
fi

# echo "$cms/include/cms_configure.php"	# test
if [ -f "$cms/include/cms_configure.php" ];	then # lookup version
	V=$(cat "$cms/include/cms_configure.php" | grep CMS_PROJECT_VERSION)
	# echo "V=$V"	# test
	if [ ! -z "$V" ]; then
		F=${V##*\"V}
		NV="V${F%%\"*}"
		echo "$(pwd) new version is $NV" | tee -a "${LOG}"
	fi
fi

for F in .htaccess index.php login.php logout.php
do
	if [ ! -f "${F}" ]; then
		# user may have changed these files so only install initial copy
		unzip "$LATEST" "$F" -d .
	fi
	RET=$?
	if [ $RET -ne 0 ]; then
		echo "FAILED to add \"${F}\" to $FVERSION." | tee -a "${LOG}"
		continue
	fi
done

# delete no longer required
RM_FILES=" \
	cms/include/classes/cms_box_tool_tips.php \
	cms/include/cms_sqlite3.php \
	cms/images/manual/cms_admin_empty.gif \
	cms/images/manual/cms_first_login.gif \
	cms/images/manual/cms_first_run.gif \
	cms/examples/AppsCMS_Local_Tool_Terminal_V0.02.zip \
	cms/examples/AppCMS_*.zip
	"
for F in $RM_FILES
do
	if [ ! -f "$F" ]; then continue; fi
	echo "Delete old file \"$F\"." | tee -a "${LOG}"
	rm "$F" 2>&1 | tee -a "${LOG}"
done

if [ $SET_PERMS -eq 1 ]; then
	sudo cms/cli/cms_set_permissions.sh | tee -a "${LOG}"	# run to have the correct permissions.
fi

cms/cli/cms_backup_settings.sh
php cms/cli/cms_rebuild.php "$USE_JSON" | tee -a "${LOG}"

if [ $SET_PERMS -eq 1 ]; then
	sudo cms/cli/cms_set_permissions.sh | tee -a "${LOG}"	# run a second time to ensure new paths have the correct permissions.
fi

if [ -f "$LATEST" ]; then	# clean up
	mv -f "$LATEST" var/temp/
fi
# if [ -f "$INSTALLERLATEST" ]; then	# clean up
#	mv -f "$INSTALLERLATEST" var/temp/
# fi

echo "Finished update on \"$(pwd)\" $OV to $NV at $DT." | tee -a "${LOG}"
echo "" | tee -a "${LOG}"
echo "" | tee -a "${LOG}"

# EOF

