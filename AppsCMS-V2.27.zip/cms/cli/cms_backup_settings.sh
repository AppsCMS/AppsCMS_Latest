#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_backup_settings.sh 1961 2021-01-25 10:09:54Z robert0609 $

# backup sqlite DB and INI files for Applications Management System Library for PHP (AppsCMS)
# run from web root directory

DT="$(date '+%Y%m%d-%H%M%S')"
FVERSION="V2.27"
BAKDIR="var/backups"
BAK_TGZ="${BAKDIR}/AppsCMS-Backup-${HOSTNAME}-${DT}"
EXCLUDE_TYPES=" \
	--exclude *.svn \
	--exclude *.git/* \
	--exclude *.svn/* \
"

PROG="$(basename "$0")"
BASE_DIR="$(pwd | sed 's/cms\/cli\///g' )"
pushd "$BASE_DIR" > /dev/null

echo "Backing up settings and configurations to \"$BAK_TGZ\" ($FVERSION)."

CONF_DB="etc/sqlite/cms.sqlite"
CONF_DB_TMP="${BAKDIR}/dump-${DT}.sql"

CONF_INI_DIR="etc/ini/"
if [ ! -d "$CONF_INI_DIR" ]; then    # setup not found
    echo "WARNING: No setup found."	# probably installing
	exit 2
fi
CONF_DB_DIR="etc/sqlite/"
if [ ! -d "$CONF_DB_DIR" ]; then    # DB not found
    echo "WARNING: No DB found."	# probably installing
	exit 2
fi

if [ ! -d "$BAKDIR" ]; then
    mkdir -p "$BAKDIR"
    if [ ! -d "$BAKDIR" ]; then
        echo "ERROR: Failed to make \"$BAKDIR\" directory."
        exit 1
    fi
fi

# make backup file
zip $EXCLUDE_TYPES -r "${BAK_TGZ}.zip" "${CONF_INI_DIR}" # always there
zip $EXCLUDE_TYPES -r "${BAK_TGZ}.zip" "${CONF_DB_DIR}" # always there
if [ ! -f "$CONF_DB" ]; then    # db not found
    echo "ERROR: Database file \"$CONF_DB\" no found."
	exit 3
else    # dump the config database
    sqlite3 "$CONF_DB" .dump > "$CONF_DB_TMP"
    if [ $? -ne 0 ]; then
        echo "ERROR: Could not backup \"$CONF_DB\"."
		exit 4
    else
        zip "${BAK_TGZ}.zip" "$CONF_DB" "$CONF_DB_TMP"
        if [ -f "${CONF_DB_TMP}" ]; then rm -f "${CONF_DB_TMP}"; fi
    fi
fi

popd > /dev/null

exit 0	# done

# EOF
