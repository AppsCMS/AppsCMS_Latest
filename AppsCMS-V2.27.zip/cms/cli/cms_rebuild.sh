#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_rebuild.sh 2054 2021-04-09 04:42:32Z robert0609 $

# rebuild setup script for Applications Management System Library for PHP (AppsCMS)
# run from web root directory

FVERSION="V2.27"

BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null

SET_PERMS=0	# default to not set permisions (needs sudo)
SUZOO="$(sudo -l -n -U \$USER 2>&1 | grep ' may run the following commands on')"
if [ ! -z "$SUZOO" ]; then SET_PERMS=1; echo "Using sudo ALL"; fi	# in the sudo zoo

SQSH_D=0
if [ $SET_PERMS -gt 0 -a -f cms_lib_sqsh_sqsh ]; then SQSH_D=1; fi

USE_JSON=''	# default to not to use cms.sqlite.json to rebuild db
while [ ! -z "$1" ]
do

	case "$1" in
		--no-perms)
			SET_PERMS=0
			;;
		--set-perms)
			SET_PERMS=1
			;;
		--use-json)
			USE_JSON='--use-json'
			;;
		*)
			echo "Usage: $(basename "$0") [-h|--help|help] [--set-perms|--no-perms] [--use-json]"
			echo "Where: --set-perms sets permissions (need sudo access, full sudo zoo is auto detected),"
			echo "--no-perms does not set permissions (default),"
			echo "and --use-json to use cms.sqlite.json to rebuild db (if available)."
			exit 0
			;;
	esac
	shift
done


V207_DIRS="\
	apps \
	etc/backgrounds \
	etc/icons \
	etc/images \
	etc/ini \
	etc/css \
	etc/ext \
	etc/sqlite \
	localtools \
	page_bodies \
	var/backups \
	var/cache \
	var/exports \
	var/gotcha \
	var/logs \
	var/sessions \
	var/Trash \
	var/variables \
"
for D in $V207_DIRS
do
	if [ ! -d "$D" ]; then
		mkdir -p "$D"
		if [ $? -ne 0 ]; then
			echo "ERROR: cannot make \"$D\"."
			exit 2
		fi
	fi
done

if [ $SET_PERMS -eq 1 -a $SQSH_D -eq 0 ]; then
	sudo cms/cli/cms_set_permissions.sh	# run to have the correct permissions.
fi

cms/cli/cms_backup_settings.sh > /dev/null
php cms/cli/cms_rebuild.php "$USE_JSON"

if [ $SET_PERMS -eq 1 ]; then
	sudo cms/cli/cms_set_permissions.sh	# run a second time to ensure new paths have the correct permissions.
fi

popd > /dev/null

# EOF

