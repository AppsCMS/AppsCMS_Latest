#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_update_appsV207.sh 2047 2021-04-07 23:15:56Z robert0609 $

# updates apps/ for changes in AppCMS structure.

# At V2.07b5, changes AppsCMS filenames in cms/include/ops/
# prefixes of "app_" to "cms_" as per a number of users requests
# and adds "cms_" prefix to AppsCMS includes, classes and plugins (including DB cms_configs data)
# to stop confusion with filenames, classes and plugins in the apps/ directory.

# Apologies for this script as it is fairly unsophisticated and linear in code form,
# could have had functions, etc. added but expediency was required (RF).

PRE_OLD="app_"
PRE_NEW="cms_"
FBASE="."	# do everything "apps/"	# find base for sed editor.

function edit_from_to() {	# $1=from $2=to $3=file
	# check / add ${PRE_NEW} code references
	local S="$1"
	local D="$2"
	local C="$3"

	# echo "Checking / editing code \"$C\" (\"${S}\" to \"${D}\")."
	# now find and add
	sed -i "/${D}|[_a-zA-Z]${S}/! s/${S}/${D}/g" "$C"

} # edit_from_to()

function edit_add_pre2files() {	# $1=code
	# check / add ${PRE_NEW} code references
	local F="$1"
	local S="${F}"
	local D="${PRE_NEW}${F}"
	local C
	local CNT=0;
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		let "CNT++"
		local S="${F}"
		local D="${PRE_NEW}${F}"
		edit_from_to "$S" "$D" "$C"
	done
	return $CNT
} # edit_add_pre2files()

# AppsCMS cms/ files to $PRE_NEW to
DIR="cms/"
CMS_FILE_SUFFIXES=" \
	ajax.php \
	index.php \
	login.php \
	logout.php \
	phpinfo.php \
	proxy.php \
	client_visit_cntr.js \
	title_tooltips.js \
"
for F in $CMS_FILE_SUFFIXES
do
	S="${DIR}${F}"
	D="${DIR}${PRE_NEW}${F}"

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	edit_add_pre2files "$F"

done
# exit # test

DIR="cms/cli/"
CLI_FILE_SUFFIXES=" \
	backup_settings.cmd \
	backup_settings.sh \
	doxy_run.sh \
	dumpsqlite3.sh \
	generate_sitemap.cmd \
	generate_sitemap.php \
	generate_sitemap.sh \
	rebuild.cmd \
	rebuild.php \
	rebuild.sh \
	set_permissions.sh \
	update_appsV207.sh \
	wrap_submission.sh \
"
# rename "$DIR" files
for F in $CLI_FILE_SUFFIXES
do
	S="${DIR}${F}"
	D="${DIR}${PRE_NEW}${F}"

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	edit_add_pre2files "$F"

done

DIR="cms/include/"
APP_FILE_SUFFIXES=" \
	top.php \
	page_nav_bar.php \
	page_header.php \
	bottom.php \
	msgs.php \
	events_start.php \
	page_left_column.php \
	page_footer.php \
	page_body.php \
"
# Move "$DIR" files
for F in $APP_FILE_SUFFIXES
do
	S="${DIR}${PRE_OLD}${F}"
	D="${DIR}${PRE_NEW}${F}"

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	# check / prefix code to ${PRE_NEW} references
	S="${PRE_OLD}${F}"
	D="${PRE_NEW}${F}"
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		edit_from_to "$S" "$D" "$C"
	done
done

# AppsCMS cms/include/ files to $PRE_NEW to
DIR="cms/include/"
CMS_FILE_SUFFIXES=" \
	auto_class_loader.php \
	bodies_menu.php \
	config_menu.php \
	configure.php \
	sqlite3.php \
	tools_menu.php \
	visitor_cntr.php \
	block_styles.css.php \
	inline_styles.css.php \
	main_styles.css.php \
"
for F in $CMS_FILE_SUFFIXES
do
	S="${DIR}${F}"
	D="${DIR}${PRE_NEW}${F}"

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	edit_add_pre2files "$F"

done

# AppsCMS cms/include/ops/ files to $PRE_NEW to
DIR="cms/include/ops/"
# a little different from the others and these files are used inside the cms/
# should not be necessary check outside the cms/ directory
CMS_OPSFILE_SUFFIXES=" \
	about_cms.php,${PRE_NEW}about.php \
	body.php,${PRE_NEW}body.php \
	closed.php,${PRE_NEW}closed.php \
	disclaimer.tmpl.php,${PRE_NEW}disclaimer.tmpl.php \
	edit_apps.php,${PRE_NEW}edit_apps.php \
	edit_bodies.php,${PRE_NEW}edit_bodies.php \
	edit_config.php,${PRE_NEW}edit_config.php \
	edit_groups.php,${PRE_NEW}edit_group.php \
	edit_header_footer.php,${PRE_NEW}edit_header_footer.php \
	edit_install.php,${PRE_NEW}edit_install.php \
	edit_search.php,${PRE_NEW}edit_search.php \
	edit_theme.php,${PRE_NEW}edit_theme.php \
	edit_tools.php,${PRE_NEW}edit_tools.php \
	edit_users.php,${PRE_NEW}edit_users.php \
	eula_form.php,${PRE_NEW}eula_form.php \
	get_password.php,${PRE_NEW}get_password.php \
	login_local_form.php,${PRE_NEW}login_local_form.php \
	login.php,${PRE_NEW}login.php \
	log_view.php,${PRE_NEW}log_view.php \
	no_cookie.php,${PRE_NEW}no_cookie.php \
	show_sitemap.php,${PRE_NEW}show_sitemap.php \
	text_view.php,${PRE_NEW}text_view.php \
"
for F in $CMS_OPSFILE_SUFFIXES
do
	if [ -z "$F" ]; then continue; fi

	S="${DIR}${F%%,*}"
	D="${DIR}${F##*,}"

	if [ -z "$S" -o -z "$D" ]; then
		echo "Error: $F"
		exit 2
	fi

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	# check / add ${PRE_NEW} code references
	S="${F%%,*}"
	D="${F##*,}"
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		edit_from_to "$S" "$D" "$C"
	done
done
# exit	# test

# AppsCMS cms/include/classes/ files to $PRE_NEW to
DIR="cms/include/classes/"
CMS_CLASS_SUFFIXES=" \
	box_tool_tips \
	database_common \
	database_mysql \
	database_sqlite \
	generate_Vmenu \
	logger \
	msgs \
	plugin_base \
"
for F in $CMS_CLASS_SUFFIXES
do
	S="${DIR}${F}.php"
	D="${DIR}${PRE_NEW}${F}.php"

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	# check / add file ${PRE_NEW} code references
	S="${F}.php"
	D="${PRE_NEW}${F}.php"
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		# echo "Checking / editing code file \"$C\"."
		# now find and add
		sed -i "/${D}|[_a-zA-Z]${S}/! s/${S}/${D}/g" "$C"
	done

	# check / add file ${PRE_NEW} class references
	S="C${F}"
	D="C${PRE_NEW}${F}"
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		edit_from_to "$S" "$D" "$C"
	done
done

# AppsCMS cms/include/plugins/ files to $PRE_NEW to
DIR="cms/include/plugins/"
DB="etc/sqlite/cms.sqlite"
CMS_PLUGIN_SUFFIXES=" \
	auth \
	contactus \
	email \
	gotcha \
	maplatlong \
	media_conv \
	minify \
	socialmedia \
"
for F in $CMS_PLUGIN_SUFFIXES
do
	S="${DIR}${F}.php"
	D="${DIR}${PRE_NEW}${F}.php"

	SD="${DIR}${F}"
	DD="${DIR}${PRE_NEW}${F}"

	echo "Changing from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	# check if dest sub directory is already there
	if [ -d "$SD" ]; then
		if [ -d "$DD" ]; then
			# delete old directory
			rm -rf "$SD";
		fi
		# move directory
		mv "$SD" "$DD"
	fi

	# do the internal configs
	sed -i "s/const PLUGIN = '${F}'/const PLUGIN = '${PRE_NEW}${F}'/g" $D

	# do sqlite DB enabled plugins
	ENPLS="$(sqlite3 "$DB" "select cms_config_value from cms_configs where cms_config_key = \"CMS_C_ENABLED_PLUGINS\";")"
	ENPLSN="$(echo "$ENPLS" | sed "/${PRE_NEW}${F}/! s/${F}/${PRE_NEW}${F}/g")"
	sqlite3 "$DB" "update cms_configs set cms_config_value = \"${ENPLSN}\" where cms_config_key = \"CMS_C_ENABLED_PLUGINS\";"

	# do sqlite update plugin configs keys
	FF="$(echo "PL_${F}_" | tr '[a-z]' '[A-Z]')"	# uppercase
	PNFF="$(echo "PL_${PRE_NEW}${F}_" | tr '[a-z]' '[A-Z]')"	# uppercase
	sqlite3 "$DB" "select cms_config_id, cms_config_key from cms_configs where cms_config_key like \"${FF}%\";" | while read K
	do
		ID="${K%%|*}"
		NKEY="$(echo "${K##*|}" | sed "s/${FF}/${PNFF}/g")"
		BAD="$(sqlite3 "$DB" "select cms_config_id from cms_configs where cms_config_key = \"${NKEY}\";")"
		echo "ID=$ID, NKEY=$NKEY, BAD=$BAD"	# test
		if [ ! -z "$BAD" ]; then
			# don't try to duplicate
			sqlite3 "$DB" "delete from cms_configs where cms_config_id = \"${BAD}\";"
		fi
		sqlite3 "$DB" "update cms_configs set cms_config_key = \"${NKEY}\" where cms_config_id = \"${ID}\";"
	done

	# check / add file ${PRE_NEW} code references
	S="${F}.php"
	D="${PRE_NEW}${F}.php"

	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		# echo "Checking / editing plugin file \"$C\" (\"${S}\" to \"${D}\" and \"${FF}\" to \"${PNFF}\")."
		# now find and add
		sed -i "/${PRE_NEW}|[_a-zA-Z]${S}/! s/${S}/${D}/g" "$C"
		sed -i "/${PNFF}|[_a-zA-Z]${FF}/! s/${FF}/${PNFF}/g" "$C"
	done

	# check / add file ${PRE_NEW} plugin references
	S="C${F}_plugin"
	D="C${PRE_NEW}${F}_plugin"
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		edit_from_to "$S" "$D" "$C"
	done
done

DIR_OLD="cms/"
DIR_NEW="etc/css/"
PRE_NEW="cms_"
CSS_FILES=" \
	block_styles.css \
	inline_styles.css \
	main_styles.css \
"
# Move "$DIR" files
if [ ! -d "$DIR_NEW" ]; then
	mkdir -p "$DIR_NEW"
fi
for F in $CSS_FILES
do
	S="${DIR_OLD}${F}"
	D="${DIR_NEW}${PRE_NEW}${F}"

	echo "Moving from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	# check / replace code ${PRE_OLD} to ${PRE_NEW} references
	S="${PRE_OLD}${F}"
	D="${PRE_NEW}${F}"
	find "$FBASE" -type f | egrep '\.php$|\.inc$' | egrep -v 'var/|lib/' | while read C
	do
		# echo "Checking / editing code \"$C\" (\"${S}\" to \"${D}\")."
		# now find and replace
		sed -i "s/${S}/ETC_WS_CSS_DIR . \'${PRE_NEW}${F}\'/g" "$C"
		sed -i "s/CMS_DIR\s*\.\s*[\'\"]${F}[\'\"]/ETC_WS_CSS_DIR . \'${PRE_NEW}${F}\'/g" "$C"
	done
done

PRE_NEW="cms_"
CSS_CLASSES=" \
	box_outer_tip \
	box_inner_tip \
	nav_bar \
	page_sitemap \
	msg_info \
	msg_debug \
	msg_required \
	msg_success \
	msg_error \
	title_tooltip \
"
# Move "$DIR" files
if [ ! -d "$DIR_NEW" ]; then
	mkdir -p "$DIR_NEW"
fi
for S in $CSS_CLASSES
do
	# check / add prefix ${PRE_NEW} css class references
	N="${PRE_NEW}${S}"
	find "$FBASE" -type f | egrep '\.php$|\.inc$|\.css$|\.js$' | egrep -v 'var/|lib/' | while read C
	do
		edit_from_to "$S" "$N" "$C"
	done
done

echo '
# setup for theme access from AppsCMS V2.07

<Files *>
	Required all granted
</Files>

' > ${DIR_NEW}.htaccess

# move the cms/calendar.* files to cms/lib/calendar/
DIR_OLD="cms/"
DIR_NEW="cms/lib/calendar/"
CAL_FILES=" \
	calendar.js \
	calendar.css \
"
# Move "$DIR" files
if [ ! -d "$DIR_NEW" ]; then
	mkdir -p "$DIR_NEW"
fi
for F in $CAL_FILES
do
	S="${DIR_OLD}${F}"
	D="${DIR_NEW}${F}"

	echo "Moving from \"$S\" to \"$D\"."
	# check dest is already there
	if [ -f "$D" ]; then
		# delete old file
		if [ -f "$S" ]; then rm -f "$S"; fi
	else
		# move file
		mv "$S" "$D"
	fi

	# check / replace code ${DIR_OLD} to ${DIR_NEW} references
	S="${PRE_OLD}${F}"
	D="${PRE_NEW}${F}"
	find "$FBASE" -type f | egrep '\.php$|\.inc$' | egrep -v 'var/|lib/' | while read C
	do
		# echo "Checking / editing code \"$C\"."
		# now find and replace
		sed -i "s/${S}/CMS_WS_LIB_DIR . \'calendar\/${F}\'/g" "$C"
		sed -i "s/CMS_DIR\s*\.\s*[\'\"]${F}[\'\"]/CMS_WS_LIB_DIR . \'calendar\/${F}\'/g" "$C"
	done
done

# one final gotcha sweep
find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
do
	# echo "Checking / editing file \"$C\" (\"${PRE_NEW}${PRE_NEW}\" to \"${PRE_NEW}\")."
	# now find and fix double ${PRE_NEW}
	sed -i "s/${PRE_NEW}${PRE_NEW}/${PRE_NEW}/g" "$C"
	sed -i "s/${PRE_NEW}page_${PRE_NEW}/${PRE_NEW}page_/g" "$C"

	# repeat
	sed -i "s/${PRE_NEW}${PRE_NEW}/${PRE_NEW}/g" "$C"
	sed -i "s/${PRE_NEW}page_${PRE_NEW}/${PRE_NEW}page_/g" "$C"
done

# special cases cleanup
# standard DOCROOT files
ROOT_EXC_FILES=" \
	index.php \
	login.php \
	logout.php \
"
BDIR="./"

find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
do
	for RF in $ROOT_EXC_FILES
	do
		if [ "${BDIR}${RF}" == "$C" ]; then
			echo "Ignore root file \"$C\"."
			break
		fi

		echo "Checking location for \"${RF}\" in file \"$C\" (\"${PRE_NEW}${RF}\" to \"${RF}\")."
		sed -i "s/${PRE_NEW}${RF}/${RF}/g" "$C"

		# repeat
		sed -i "s/${PRE_NEW}${RF}/${RF}/g" "$C"
	done
done

# some one of gotchas
if [ -d "etc/images/upload" ]; then 	# gotcha from old versions
	rm -rf "etc/images/upload/.svn"
	mv "etc/images/upload" "etc/images/uploads"
fi

sed -i "s/\"login.php\"/\"${PRE_NEW}login.php\"/" "cms/include/${PRE_NEW}page_body.php" 	# gotcha from sed complexity

find "$FBASE" -type f | egrep '\.php$|\.inc$|\.js$' | egrep -v 'var/|lib/' | while read C
do 	# gotcha from sed complexity
	sed -i "s/apps_${PRE_NEW}auth.php/apps_auth.php/" "$C"
	sed -i "s/C${PRE_NEW}apps_auth/Capps_auth/" "$C"
done

# rebuild everything
cms/cli/cms_rebuild.sh


# EOF
