#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_doxy_run.sh 2014 2021-03-22 03:57:26Z robert0609 $


FVERSION="V2.17"

# check if Graphviz dot is there
which dot > /dev/null
if [ $? -ne 0 ]; then
	echo "Graphviz dot not installed on system."
	exit 10
fi

# CONF setup using doxywizard
BDIR="$(dirname "$0")"
pushd "$BDIR"
cd ../doxy/

rm -rf cms_html/
doxygen cms-doxy.conf

# leave as examples
# rm -rf apps_html/
# doxygen apps-doxy.conf

# rm -rf html/
# doxygen apps-cms-doxy.conf

popd

sudo cms/cli/cms_set_permissions.sh

# EOF

