#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_update_appsV215.sh 1961 2021-01-25 10:09:54Z robert0609 $

# updates apps/ for changes in AppCMS structure.

# At V2.11, changes to the following database classes methods to remove the
# "db_" prefix from the following;-
DB_METHODS=" \
	query perform input fetch_array get_name free_result connect close \
	output error num_rows query_unbuffered fetch_array_unbuffered data_seek \
	insert_id fetch_fields \
"
#
# this updates the php code.

PRE_OLD="db_"
PRE_NEW=""
PRE_CHK='->'
FBASE="."	# do everything "apps/"	# find base for sed editor.

function edit_from_to() {	# $1=file
	# check / add ${PRE_NEW} code references
	local S
	local D
	local F="$1"
	
	for M in $DB_METHODS
	do
		S="${PRE_CHK}${PRE_OLD}${M}"
		D="${PRE_CHK}${PRE_NEW}${M}"

		echo "Checking / editing code \"$F\" (\"${S}\" to \"${D}\")."
		# now find and add
		sed -i "/${D}|[_a-zA-Z]${S}/! s/${S}/${D}/g" "$F"
	done

} # edit_from_to()

# At AppsCMS V2.14rc7 class Ccms_install was renamed Ccms_install, remove old remnant if new present.
if [ -f "cms/include/classes/cms_DB_install.php" -a -f "cms/include/classes/cms_install.php" ]; then
	rm "cms/include/classes/cms_install.php"
fi

# AppsCMS cms/ files to $PRE_OLD to

find "$FBASE" -type f | egrep '\.php$' | egrep -v 'var/|lib/' | while read F
do 
	edit_from_to "$F"
done

# At V2.15rc3 at number files were deleted
DEL_FILES=" \
	cms/include/cms_visitor_cntr.php \
	cms/cli/cms_update_appsV211.sh 
	cms/cms_client_visit_cntr.js \
	cms/cms_extra_funcs.js \
	cms/cms_security.js \
"
for F in $DEL_FILES
do
	rm "$F"
done

# rebuild everything
cms/cli/cms_rebuild.sh


# EOF
