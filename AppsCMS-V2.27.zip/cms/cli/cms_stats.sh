#!/bin/bash
# see Licence in cms/LICENCE.txt
# SVN Build: $Id: cms_stats.sh 1961 2021-01-25 10:09:54Z robert0609 $
# get source code stats

function get_stats() { # $1=base_dir
	local TYPES="php js css sh html htm ini json"
	for T in $TYPES
	do
		# Print newline, word, and byte counts
		local RES="$((find "$1" -type f | egrep -i -v 'dist-src/|archived/|tmp/|temp/' | egrep ".${T}\$" | xargs cat ) | wc)"
		echo "$(echo "$1($T) $RES" | sed -e 's/\s\+/,/g' )"
		# echo ""
	done
} # get_stats()

DIRS=" \
	apps/ \
	cms/ \
	page_bodies/ \
	etc/ \
	./ \
"
echo "AppsCMS filesystem stats."
echo -e "Source,Lines,Words,Bytes"
for D in $DIRS
do
	get_stats "$D"
done

echo ""

# EOF
