#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_set_permissions.sh 2014 2021-03-22 03:57:26Z robert0609 $

# set special directories for apache access
# need sudo privileges, take care running as root

DT="$(date '+%Y%m%d-%H%M%S')"
FVERSION="V2.27"

SET_PERMS=0	# default to not set permisions (needs sudo)
SUZOO=0
sudo -l -n -U $USER
if [ ! -z "$?" ]; then
	SUZOO=1
	SET_PERMS=1	# in the sudo zoo
	echo "Using sudo ALL"
else
	echo "ERROR: Sudo not available for $USER."
	exit 1
fi


WWW_USER=`ps axo user,group,comm | egrep '(apache|httpd)' | grep -v ^root | cut -d\  -f 1 | uniq`
echo Apache user is: $WWW_USER	# test

PROG="$(basename "$0")"
BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null

SQSH=0
if [ $SET_PERMS -gt 0 -a -f cms_lib_sqsh_sqsh ]; then SQSH=1; fi

BASE_DIR="$(pwd)"
AUSER="$(ps -ef | egrep '(httpd|apache2|apache)' | grep -v `whoami` | grep -v root | head -n1 | awk '{print $1}')"

UGROUP="$1"	# "$(id -g)"
if [ -z "$UGROUP" ]; then
	UGROUP="$(stat -c "%G" .)"
fi

UUSER="$2"	# "$(id -g)"
if [ -z "$UUSER" ]; then
	UUSER="$(stat -c "%U" .)"
fi

USAGE="Usage: sudo $PROG [group_to_use] [user_to_use]"

if [ $USER != root -a $SUZOO -eq 0 ]; then
	echo "ERROR: Must be the root (or sudo) user."
	exit 10
fi
if [ -z "$UGROUP" ]; then
	echo "Could not find user group."
	echo -e "$USAGE"
	exit 11
fi
echo "Using user $UUSER and $UGROUP group."

if [ -z "$AUSER" ]; then
	echo "Cannot find web server process user name. Is web server running ?"
	exit 12
fi

# check $AUSER is in the $UGROUP group
A="$(groups $AUSER)"; B="${A#*:}";
ACHK="$(echo "$B" | grep "$AUSER")"
if [ -z "$ACHK" ]; then
	echo "Adding $AUSER user to $UGROUP group"
	usermod -a -G "$UGROUP" "$AUSER"
	if [ $? -ne 0 ]; then
		echo "ERROR: Failed to add $AUSER to $UGROUP group."
		exit 13
	fi
fi
# else already there

set_perms() { # $1=dir	# set DOCROOT perm's
	chmod -R ug+rw,o+r,o-w "$1"
	if [ $? -ne 0 ]; then
		echo "ERROR: Failed to chmod \"$1\"."
		return 1
	fi

	chown -R ${UUSER}:${UGROUP} "$1"
	if [ $? -ne 0 ]; then
		echo "ERROR: Failed to chown \"$1\"."
		return 1
	fi
	return 0 # ok
} # set_perms()

SNG_S=" \
	. \
	sitemap.xml \
"
for S in $SNG_S
do
	if [ -x "$S" ]; then
		set_perms "$S" # set perm's
	fi
done

if [ -d "localtools" ]; then
	set_perms "localtools" # set perm's
fi

DIRS=" \
    var/logs/ \
    var/sessions/ \
    var/cache/ \
    var/Trash/ \
    var/variables/ \
    var/exports/ \
"

for D in $DIRS
do
	if [ ! -d "$D" ]; then
		mkdir -p "$D"
		if [ $? -ne 0 ]; then
			echo "ERROR: Failed to mkdir \"$D\"."
			exit 1
		fi
	fi

	chmod -R ug+rw,o-rwx "$D"
	if [ $? -ne 0 ]; then
		echo "ERROR: Failed to chmod \"$D\"."
		exit 2
	fi

	chown -R $UUSER:$UGROUP "$D"
	if [ $? -ne 0 ]; then
		echo "ERROR: Failed to chown \"$D\"."
		exit 3
	fi

done

# make var/sessions accessible by server
chown -R "$WWW_USER" var/sessions

if [ $SQSH -ne 0 ]; then
	# make shell scripts executable
	chmod ug+rwx cms/cli/*.sh
fi

# run apps set permissions
if [ -x apps/cli/set_app_permissions.sh ]; then
	apps/cli/set_app_permissions.sh "$UGROUP"
fi

popd > /dev/null

exit 0	# done

# EOF
