Applications Management System Library for PHP (AppsCMS) - README_libs.
=======================================================================
see Licence in cms/LICENCE.txt
<!-- SVN Build: $Id: README_libs.md 1961 2021-01-25 10:09:54Z robert0609 $ -->

3rd Party Libraries.
--------------------

3rd party libraries used by AppsCMS are placed in "cms/lib/" directory.

They are licenced by their respective authors (see the licence files in each library directory).

The libraries have been selected for there ease of use, no required dependencies and simplicity.

In some cases the library requires custom values to be entered into code (e.g. directory locations).

.EOF.
