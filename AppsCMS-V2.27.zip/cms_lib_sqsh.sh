#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_lib_sqsh.sh 2055 2021-04-09 05:04:39Z robert0609 $

# squashfuse mount script for Applications Management System Library for PHP (AppsCMS)
# run from web root directory.
# Requirement: system package squashfuse to be installed.
# NOTE: if the cms_lib_sqsh.sqsh needs to be umount, run 'fusermount -u ./cms'

FVERSION="V2.27"

function restart_httpd() {	#
	fusermount -u cms
	for D in httpd apache apache2 php-fpm
	do
		which $D 2> /dev/null > /dev/null
		if [ $? -eq 0 ]; then
			echo "Stop/start $D."
			sudo service $D stop
			sleep 2
			sudo service $D start
		fi
	done
	return 0
} # restart_httpd()

function mount_cms() { #
	# fusermount -u cms	# test
	if [ ! -f cms/cms_index.php ]; then	# nothing in the cms/ directory
		which fusermount > /dev/null
		if [ $? -ne 0 ]; then
			echo "ERROR: \"fusermount\" not available, cannot mount read only library."
			exit 2
		fi
		which squashfuse > /dev/null
		if [ $? -ne 0 ]; then
			echo "ERROR: \"squashfuse\" not available, cannot mount read only library."
			exit 3
		fi
		if [ ! -d ./cms ]; then 	# make sure the mount point is there
			mkdir ./cms;
		fi
		chmod a=rwx ./cms;

		squashfuse -o allow_other cms_lib_sqsh.sqsh ./cms
		if [ $? -ne 0 ]; then
			echo "ERROR: Failed to mount cms_lib_sqsh.sqsh."
			exit $RET
		fi
		echo "INFO: Mounted cms_lib_sqsh.sqsh."
	fi
	echo "Note 1: to umount user mounted ./cms, run \"./cms_lib_sqsh.sh -u\"."
	echo "Note 2: to umount apache/php-fpm mounted ./cms, run \"./cms_lib_sqsh.sh -s\" (sudo required, stop/start apache[/php-fpm])."
	return 0
} # mount_cms()

function help() { #
	echo 'AppsCMS read only CLI library mounter.'
	echo 'Usage: cms_lib_sqsh.sh [-s|--restart-services (sudo required)] [-r|--rebuild-cms (sudo required)] [-u|--umount-cms] [-m|--mount-cms (default)] [-h|--help]'
} # help()

if [ -z "$1" ]; then
	mount_cms
	exit $?
fi

while [ ! -z "$1" ]
do
	case "$1" in
	-s|--restart-services )
		restart_httpd
		exit $?
		;;
	-r|--rebuild-cms )
		mount_cms
		cms/cli/cms_rebuild.sh --set-perms
		exit $?
		;;
	-m|--mount-cms )
		mount_cms
		exit $?
		;;
	-u|--umount-cms )
		fusermount -u ./cms
		exit $?
		;;
	-h|--help )
		help
		exit 0
		;;
	* )
		if [ ! -z "$1" ]; then help; exit 1; fi	# don't know this option
		;;
	esac
	shift
done

# EOF
