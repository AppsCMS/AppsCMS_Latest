<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_lib_sqsh.php 2054 2021-04-09 04:42:32Z robert0609 $
 */

if((!file_exists('cms/cms_index.php')) ||
	(!is_readable('cms/cms_index.php'))) {	// cms code not there
	// this only be called once in a server host (and php-fpm) are stopped and started.
	if((!file_exists('cms_lib_sqsh.sqsh')) ||
		(!is_readable('cms_lib_sqsh.sqsh'))) {	// no squashfs ??
		echo "ERROR: 'cms_lib_sqsh.sqsh' file not found. Cannot mount read only AppsCMS filesystem.";
		exit(1000);
		} // if
	@mkdir('./cms',0777);	// make sure the mount point is there
	@chmod('./cms',0777);	// and useable perms for web and cli
	$output=null;
	$retval=null;
	exec('squashfuse -o allow_other cms_lib_sqsh.sqsh ./cms', $output, $retval);	// mount simple fs
	if($retval) {	// mount fs
		echo "ERROR: Read only AppsCMS library mount failed, status $retval.<br>" . PHP_EOL;
		// print_r($output);
		exit(1001);
		} // if
	} // if

