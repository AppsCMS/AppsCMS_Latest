<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: ws_server.php 2788 2022-09-04 11:49:25Z robert0609 $
 */

define('WS_DAEMON_CALL',true);	// global for WS server recognition

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_ws_server.php';
