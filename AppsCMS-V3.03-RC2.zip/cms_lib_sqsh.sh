#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_lib_sqsh.sh 2842 2022-10-08 07:44:23Z robert0609 $

# squashfuse mount script for Applications Management System Library for PHP (AppsCMS)
# run from web root directory.
# Requirement: system package squashfuse to be installed.
# NOTE: if the cms_lib_sqsh.sqsh needs to be umount, run 'fusermount -u ./cms'

# set -x

FVERSION="V3.00-RC3"
APPSCMS_PKG_DIR="/usr/local/share/AppsCMS/"
PWD="$(dirname "$0")"
C_D="cms"
A_D="apps"
P_D="${A_D}/bodies"	# for version transitions
_D_MNTS="$C_D $A_D"
MCNT=0
USE_JSON=""
REBUILD=0
REBUILD_ALL=0
SUZOO=0
SUDO_BIN=""
DLOG="var/logs"
if [ ! -d "$DLOG" ]; then mkdir -p "$DLOG"; fi
LOG="${DLOG}/CLI_cms-$(date '+%Y%m%d').log"
if [ ! -d "$DLOG" ]; then mkdir -p "$DLOG"; fi

function out_msg() { # $1=msg [$2="ok|info|warn|err"]
	local CLI_SH_BOLD="\033[1m"
	local CLI_SH_NORM="\033[0m"
	local CLI_SH_RED="\033[1;31m"
	local CLI_SH_GREEN="\033[1;32m"
	local CLI_SH_YELLOW="\033[1;33m"
	local CLI_SH_PURPLE="\033[1;35m"
	local CLI_SH_BLUE="\033[1;34m"
	local CLI_SH_WHITE="\033[1;39m"
	local CLI_SH_DEFCOL="\033[0m"
	local DTI="$(date '+%Y%m%d-%H%M%S')"
	local MSG="$1"
	local TYP="$2"
	local PRE=""

	if [ -z "$MSG" ]; then
		while read -r -s L
		do
			echo "${L}"
			echo "${DTI}: sqsh, ${L}" >> "$LOG"
		done
		return 0
	fi

	case "$TYP" in
		ok)
			PRE="OK: "
			echo -e "${CLI_SH_GREEN}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		info)
			PRE="INFO: "
			echo -e "${CLI_SH_BLUE}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		warn)
			PRE="WARNING: "
			echo -e "${CLI_SH_PURPLE}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		err|error)
			PRE="ERROR: "
			echo -e "${CLI_SH_RED}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		*)
			PRE=""
			echo -e "${PRE}${MSG}"
			;;
	esac

	echo "${DTI}: sqsh, ${MSG}" >> "$LOG"
	return 0
} # out_msg()

function is_sudoer() {	# $1=exit_status	(is user sudoer)
	if [ `whoami` == root ]; then	# already running as sudo (or root)
		SUZOO=1
		SUDO_BIN=""	# already root
		out_msg "Running as root user." warn
		return 0
	fi

	sudo -l -n -U $USER > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		SUZOO=0
		SUDO_BIN=""
		if [ -n "$i" ]; then
			out_msg "User: $USER is not sudoer." err
			exit $1
		fi
		out_msg "Not sudoer." warn
		return 1
	fi
	SUZOO=1
	SUDO_BIN="sudo "
	out_msg "Running $USER as sudoer." info
	return 0	# sudoer
} # is_sudoer()

function is_squashfs_avail() { #
	which fusermount > /dev/null
	if [ $? -ne 0 ]; then
		out_msg "\"fusermount\" not available." err
		exit 2
	fi
	which squashfuse > /dev/null
	if [ $? -ne 0 ]; then
		out_msg "\"squashfuse\" not available." err
		exit 3
	fi
	return 0	# ok
} # is_squashfs_avail()

function mount_readonly_filesystem() { # $1=library $2=mount_point
	is_squashfs_avail	# exits if not available

	local LIB="$1"
	local MNT="$2"
	local SQSH_OPTS=""
	OA="$(grep -E '^user_allow_other' /etc/fuse.conf)"
	if [ -n "$OA" ]; then
		SQSH_OPTS="-o allow_other"
		# SQSH_OPTS="-o allow_root"
	else
		out_msg "Option: user_allow_other missing from /etc/fuse.conf  (and /etc/fuse3.conf)" err
		out_msg "Access to $LIB restricted by system permissions." warn
	fi

	if [ $(ls -1 "$MNT" 2> /dev/null | wc -l) -ne 0 ]; then
		out_msg "${MNT} files already present." info
		return 0
	fi
	if [ ! -f "${PWD}/${LIB}" ]; then		# not used
		out_msg "${PWD}/${LIB} not found." error
		exit 4
	fi
	# fusermount -u "${PWD}/${MNT}"	# test
	if [ -n "$(findmnt "${PWD}/${MNT}" | grep squash)" ]; then
		out_msg "${PWD}/${LIB} already mounted." info
		return 0	# already mounted
	fi
	if [ ! -d "${PWD}/${MNT}" ]; then 	# make sure the mount point is there
		mkdir -m 0775 "${PWD}/${MNT}"
		# # U="$(stat -c %u ./)"	# get parent user id
		# G="$(stat -c %g ./)"	# get parent group id
		# # chown $U:$G "${PWD}/${MNT}"
		# chgrp $G "${PWD}/${MNT}"
		# # out_msg "PG=$G" info	# test
	fi
	chmod 0775 "${PWD}/${MNT}"

	squashfuse $SQSH_OPTS "$SQSF" "${PWD}/${MNT}"
	if [ $? -ne 0 ]; then
		out_msg "Failed to mount $SQSF." err
		exit $RET
	fi
	out_msg "INFO: Mounted $SQSF." ok
	let ' MCNT++ '	# mount count
	return 0
} # mount_readonly_filesystem()

function mount_apps() { #
	local SQSF="apps_fs_sqsh.sqsh"
	if [ ! -d "${A_D}/include" -a $(ls -1 "$A_D" 2> /dev/null | wc -l) -eq 0 ]; then	# nothing in the apps/ directory
		mount_readonly_filesystem "$SQSF" "${A_D}"
	fi
	# check if need to mount old page_bodies/
	local BDSQSF="page_bodies_fs_sqsh.sqsh"
	if [ -f "${BDSQSF}" ]; then
		# version cross over, needs rebuild
		out_msg "Page bodies \"$(pwd)/${BDSQSF}\" present." warn
		if [ $(ls -1 "$P_D" 2> /dev/null | wc -l) -eq 0 ]; then
			# SQFS availabe and mnt empty
			out_msg "Page bodies \"$(pwd)/${BDSQSF}\" mount to \"$P_D\"." warn
			mount_readonly_filesystem "${BDSQSF}" "$P_D"
		fi
	fi
	return 0
} # mount_apps()

function mount_cms() { #
	local SQSF="cms_lib_sqsh.sqsh"
	local SQSF_DIR="./"
	if [ ! -f "${C_D}/cms_index.php" -a $(ls -1 "$C_D" 2> /dev/null | wc -l) -eq 0 ]; then	# nothing in the cms/ directory
		if [ ! -f "${SQSF_DIR}${SQSF}" ]; then
			SQSF_DIR="$APPSCMS_PKG_DIR"
			if [ ! -f "${SQSF_DIR}${SQSF}" ]; then
				out_msg "Cannot find library \"$SQSF\" to mount." err
				exit 10
			fi
		fi
		mount_readonly_filesystem "${SQSF_DIR}${SQSF}" "${C_D}"
	fi
	return 0
} # mount_cms()

function umount_readonlys() {
	local _D
	if [ -n "$(findmnt "$P_D" | grep squash)" ]; then	# do internal mounts first
		fusermount -u "$P_D" 2>&1
		out_msg "Umounted \"$P_D\"." info
	fi
	for _D in $_D_MNTS
	do
		if [ -d "$_D" ]; then
			if [ -n "$(findmnt "$_D" | grep squash)" ]; then
				fusermount -u "$_D" 2>&1
				rmdir "$_D" 2>&1
				out_msg "Umount and remove \"$_D\"." info
			elif [ -f "${_D}_lib_sqsh.sqsh" -a $(ls -1 "$_D" 2> /dev/null | wc -l) -eq 0 ]; then
				rmdir "$_D" 2>&1
				out_msg "Remove \"$_D\"." info
			elif [ -f "${_D}_fs_sqsh.sqsh" -a $(ls -1 "$_D" 2> /dev/null | wc -l) -eq 0 ]; then
				rmdir "$_D" 2>&1
				out_msg "Remove \"$_D\"." info
			else
				out_msg "\"$_D\" not mounted." info
			fi
		else
			out_msg "\"$_D\" not mounted." warn
		fi
	done
	return 0
} # umount_readonlys()

function restart_httpd() {	#
	is_sudoer "1"	# is user sudoer
	umount_readonlys
	for D in httpd apache apache2 php-fpm
	do
		which $D > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			out_msg "Stop/start $D." info
			$SUDO_BIN service $D stop
			sleep 2
			$SUDO_BIN service $D start
			if [ $? -ne 0 ]; then
				out_msg "Failed to start $D." err
			else
				out_msg "Started $D." ok
			fi
		fi
	done
	return 0
} # restart_httpd()

function help() { #
	echo "Help for AppsCMS read only CLI library mounter ($FVERSION)."
	echo "Usage: cms_lib_sqsh.sh [-h|--help]"
	echo "[-r|--rebuild [-uj|--use-json] (sudo required)]"
	echo "[-ra|--rebuild-all [-uj|--use-json] (sudo required)]"
	echo "[-u|--umount] [-m|--mount (default)]"
	echo "[--set-perms (sudo required)] [-s|--restart-services (sudo required)]"
} # help()

if [ -z "$1" ]; then
	# do silent mounts
	is_squashfs_avail
	mount_cms 2>&1
	mount_apps 2>&1
	exit 0
fi

# out_msg "$(basename "$0") $1"	# test
while [ -n "$1" ]
do
	case "$1" in
	-s|--restart-services )
		restart_httpd 2>&1
		exit $?
		;;
	-r|--rebuild )
		REBUILD=1
		;;
	-ra|--rebuild-all )
		REBUILD_ALL=1
		;;
	-uj|--use-json)
		USE_JSON="--use-json"
		;;
	--set-perms)
		is_sudoer "1"	# is user sudoer
		mount_cms 2>&1
		mount_apps 2>&1
		$SUDO_BIN cms/cli/cms_set_permissions.sh
		;;
	-m|--mount )
		mount_cms 2>&1
		mount_apps 2>&1
		;;
	-u|--umount )
		umount_readonlys
		exit $?
		;;
	-h|--help )
		help
		exit 0
		;;
	* )
		if [ -n "$1" ]; then help; exit 1; fi	# don't know this option
		;;
	esac
	shift
done

if [ $REBUILD -ne 0 ]; then
	umount_readonlys	# start clean
	mount_cms 2>&1
	mount_apps 2>&1
	cms/cli/cms_rebuild.sh "$USE_JSON" 2>&1
	umount_readonlys
	exit $?
fi

if [ $REBUILD_ALL -ne 0 ]; then
	umount_readonlys	# start clean
	mount_cms 2>&1
	mount_apps 2>&1
	cms/cli/cms_rebuild.sh --repair-access "$USE_JSON" 2>&1
	umount_readonlys
	exit $?
fi

if [ $MCNT -gt 0 ]; then
	echo "Note 1: to umount read only filesystemss, run \"./cms_lib_sqsh.sh -u\"."
	echo "Note 2: to umount apache/php-fpm mounts, run \"./cms_lib_sqsh.sh -s\" (sudo required, stop/start apache[/php-fpm])."
	echo -e "Note 3: results logged in \"$LOG\"."
	out_msg "Done" ok
else
	out_msg "Nil read only filesystems mounted." info
fi

exit 0

# EOF
