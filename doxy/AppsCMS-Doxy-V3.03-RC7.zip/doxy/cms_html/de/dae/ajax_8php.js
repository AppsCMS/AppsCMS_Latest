var ajax_8php =
[
    [ "AJAX_CALL", "de/dae/ajax_8php.html#a301f2b2eec576204c6584e4f3e3580a2", null ]
];