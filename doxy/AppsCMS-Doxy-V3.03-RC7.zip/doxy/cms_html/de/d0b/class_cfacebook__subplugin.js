var class_cfacebook__subplugin =
[
    [ "__construct", "de/d0b/class_cfacebook__subplugin.html#abf620d4118a3cd9a5d6daf3ce775d771", null ],
    [ "__destruct", "de/d0b/class_cfacebook__subplugin.html#a6b41197e88330d9700e634e2509e192e", null ],
    [ "is_enabled", "de/d0b/class_cfacebook__subplugin.html#ae52b460d79c242e9185887fc0347bf3a", null ],
    [ "init_body_insert", "de/d0b/class_cfacebook__subplugin.html#a4ca5cd73dfe51d7b78c851593c189e95", null ],
    [ "generate", "de/d0b/class_cfacebook__subplugin.html#a151d5c955a45035a2c071295351d971b", null ],
    [ "get_title", "de/d0b/class_cfacebook__subplugin.html#abff518f587205428d3879d258672731b", null ],
    [ "get_description", "de/d0b/class_cfacebook__subplugin.html#a542351f44a5bd34c1332cf43c6d5dcc5", null ],
    [ "get_sql_install_data", "de/d0b/class_cfacebook__subplugin.html#a8ab2b3ef58724ead65df1f7060895a1c", null ],
    [ "PLUGIN", "de/d0b/class_cfacebook__subplugin.html#aef4f0cc051adc732156f17459d00f489", null ]
];