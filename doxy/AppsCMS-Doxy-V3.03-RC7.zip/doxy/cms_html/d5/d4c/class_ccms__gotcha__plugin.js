var class_ccms__gotcha__plugin =
[
    [ "__construct", "d5/d4c/class_ccms__gotcha__plugin.html#ac6af14057545f21aa061f05e4f5b8e87", null ],
    [ "__destruct", "d5/d4c/class_ccms__gotcha__plugin.html#ad120a9a02802927ca8f1c255d604e21f", null ],
    [ "is_enabled", "d5/d4c/class_ccms__gotcha__plugin.html#a9bd5ed542959de614f10aa24422139e9", null ],
    [ "is_this_ajax_plugin", "d5/d4c/class_ccms__gotcha__plugin.html#a311d7c88e576c3c2e83b0a298e3dffdf", null ],
    [ "get_ajax_text", "d5/d4c/class_ccms__gotcha__plugin.html#a932d6a19c734d51aa9a6ab2dc261ec06", null ],
    [ "generate", "d5/d4c/class_ccms__gotcha__plugin.html#ad9ca4f50fc4cce8a616dd6a17ac2f073", null ],
    [ "validate", "d5/d4c/class_ccms__gotcha__plugin.html#a7ecf844edfc882b011fb729cef42e062", null ],
    [ "reset_cache", "d5/d4c/class_ccms__gotcha__plugin.html#a6e9409f5294dbcf67ada9c489d86c417", null ],
    [ "get_title", "d5/d4c/class_ccms__gotcha__plugin.html#ae50b47cd16ef134e1df88e738a88db42", null ],
    [ "get_description", "d5/d4c/class_ccms__gotcha__plugin.html#a66b579c1333a282cdece8bb726b16c7d", null ],
    [ "PLUGIN", "d5/d4c/class_ccms__gotcha__plugin.html#a38b37d9b15526ad22570a192166a5b99", null ]
];