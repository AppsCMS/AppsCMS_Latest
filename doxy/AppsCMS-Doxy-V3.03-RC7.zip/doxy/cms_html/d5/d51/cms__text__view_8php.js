var cms__text__view_8php =
[
    [ "$uri", "d5/d51/cms__text__view_8php.html#a653b5458163d338546c47271b4fb81b7", null ],
    [ "$ret", "d5/d51/cms__text__view_8php.html#affd9e3eb0aad0a7ca42912cd925f148c", null ]
];