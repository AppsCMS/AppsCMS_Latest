var class_ccms__plugin__base =
[
    [ "__construct", "da/df9/class_ccms__plugin__base.html#a22fdc703f634400a906332583bea3d78", null ],
    [ "__destruct", "da/df9/class_ccms__plugin__base.html#aed780ad346d98ae370ece2ce7a633713", null ],
    [ "is_plugin_enabled", "da/df9/class_ccms__plugin__base.html#a4ca92f6cb72d7a3dca16b320c07b3b0d", null ],
    [ "is_this_ajax_plugin", "da/df9/class_ccms__plugin__base.html#a5c7b0c630bb81d9b97530dd6c1657057", null ],
    [ "get_ajax_text", "da/df9/class_ccms__plugin__base.html#a798a33afc4d4d527b6778b5ac4b67578", null ],
    [ "init_body_insert", "da/df9/class_ccms__plugin__base.html#a99ac728029640843c1d669bd45d12a10", null ],
    [ "generate", "da/df9/class_ccms__plugin__base.html#a20e85a639eb26ff32918e20627c5405c", null ],
    [ "validate", "da/df9/class_ccms__plugin__base.html#a2e494e0e38e545b7fcf2bb36a9a4c932", null ],
    [ "execute_form", "da/df9/class_ccms__plugin__base.html#afe628010cf52f7efaffdf0f5f657f116", null ],
    [ "executed_url", "da/df9/class_ccms__plugin__base.html#ac58115788035e09d50f96a6181675fc9", null ],
    [ "get_iframe_engage_uri", "da/df9/class_ccms__plugin__base.html#ae56b6b2f033174810fa96b2ada31c66b", null ],
    [ "get_ajax_engage_uri", "da/df9/class_ccms__plugin__base.html#a4e97d5722a5412e05b8a21cc65f5aab8", null ],
    [ "get_PL_config_keys_values", "da/df9/class_ccms__plugin__base.html#af79f416ca0a7dc5ca0d0e0ef25c326b7", null ],
    [ "install", "da/df9/class_ccms__plugin__base.html#a1b19a7c85e19c664a08a340cfa5d79f6", null ],
    [ "uninstall", "da/df9/class_ccms__plugin__base.html#a776ff23548bb94cb9f00a388be6f63c1", null ],
    [ "install_db_data", "da/df9/class_ccms__plugin__base.html#ab7c6d49290c196583ef8f9d1d944fca1", null ],
    [ "uninstall_db_data", "da/df9/class_ccms__plugin__base.html#a703bbb7ad5d059e6c016af8ed8ef048b", null ],
    [ "get_title", "da/df9/class_ccms__plugin__base.html#a688a0b62a0a896c68aaf232708d07fad", null ],
    [ "get_description", "da/df9/class_ccms__plugin__base.html#a9315aacf7eead49e42d7cea2103307a6", null ],
    [ "$cms_plugins_enabled", "da/df9/class_ccms__plugin__base.html#add3f9d02bb0f6f7b8de95a9ae63cf025", null ]
];