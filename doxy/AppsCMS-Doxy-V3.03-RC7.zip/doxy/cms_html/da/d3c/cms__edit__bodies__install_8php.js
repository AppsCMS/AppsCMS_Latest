var cms__edit__bodies__install_8php =
[
    [ "$package_file", "da/d3c/cms__edit__bodies__install_8php.html#a3121e0303ce6a36ef80fb87e59301f58", null ],
    [ "$cAppInstall", "da/d3c/cms__edit__bodies__install_8php.html#a07748efc9af00a680975f02a849e402e", null ]
];