/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "AppsCMS", "index.html", [
    [ "Applications Management System Library for PHP (AppsCMS) - INSTALLATION NOTES", "d2/dbb/md_cms__installation.html", null ],
    [ "Applications Management System Library for PHP (AppsCMS) - README", "d6/d6b/md_cms__r_e_a_d_m_e.html", null ],
    [ "Applications Management System Library for PHP (AppsCMS) - RELEASE NOTES", "d5/d7f/md_cms__release_notes.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", "globals_vars" ],
        [ "Typedefs", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"d1/d21/class_ccms__lm__bookmarks.html#a8d3b748f09f72e7d1d6163b8f2f8d2ab",
"d1/d7a/class_ccms__database__sqlite.html#a74602722167619481bbcb57a3556e4bd",
"d1/df9/class_ccms__search.html#add55c7490d8bba7873a3e693aa9bf8f8",
"d4/d74/class_ccms__base__sm__gs.html#a0c4b8bc30e1fe4f96f86ccc29edb077c",
"d5/d31/cms__users__stats_8php.html#afc4b79b1a6b7d87d6a2ee3ab69fb24ca",
"d5/d95/class_ccms__generate___vmenu.html#a4e4f116032823da989acb084f7e71a1a",
"d8/d19/cms__sassc_8php.html",
"d9/df3/class_ccms__api__jwt.html#a100cee4b3e776d1506d645490205c04c",
"db/d70/class_ccms__config.html#a67670120314458a3ea954acbaf82d798",
"db/df0/class_ccms__base__file.html#ae591607c76aa2c5c02e20b452b424db8",
"dd/dc9/class_ccms__translate__cache.html#a5089d3d6049d2b74c1bf28bd7d373306",
"df/d9c/cms__configure_8php.html#a366c79e4de65d174a6778077358a8893",
"files.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';