var indexSectionsWithContent =
{
  0: "$_abcdefghijlmnopqrstuvwyz",
  1: "c",
  2: "acdefgilrt",
  3: "_abcdefghijlmnopqrstuvwyz",
  4: "$_abcdefghijlmnopqrstuvwy",
  5: "ct",
  6: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

