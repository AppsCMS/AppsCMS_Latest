var searchData=
[
  ['nl2br',['nl2br',['../d2/d31/class_ccms__base.html#a97b7fcc1f657b2fbeac64e1c84f3bb82',1,'Ccms_base']]],
  ['num_5frows',['num_rows',['../d9/dc4/class_ccms__database__mysql.html#a8afd4836af82e28b3e29cc3d26da327f',1,'Ccms_database_mysql\num_rows()'],['../d1/d7a/class_ccms__database__sqlite.html#a22743d5fe891ae3ce8efa9162177531a',1,'Ccms_database_sqlite\num_rows()']]],
  ['number_5fto_5fcurrency',['number_to_currency',['../d2/d31/class_ccms__base.html#a37c0b8f85e06ee6cc168dad92c4e1376',1,'Ccms_base']]]
];
