var searchData=
[
  ['yandex_5fapi1_5ftrans_5flang_5fline',['yandex_api1_trans_lang_line',['../d0/df6/class_ccms__translate__plugin.html#a518238c10b9c32ad78d835800ba2d067',1,'Ccms_translate_plugin']]],
  ['yandex_5ftrans_5flang_5fline',['yandex_trans_lang_line',['../d0/df6/class_ccms__translate__plugin.html#a144dd1aa5298a7ee66ac03055a29220d',1,'Ccms_translate_plugin']]]
];
