var searchData=
[
  ['gotcha_5fcode_2ephp',['gotcha_code.php',['../d0/dfd/gotcha__code_8php.html',1,'']]]
];
