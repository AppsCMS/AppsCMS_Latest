var searchData=
[
  ['ajax_2ephp',['ajax.php',['../de/dae/ajax_8php.html',1,'']]],
  ['api_2ephp',['api.php',['../dd/d15/api_8php.html',1,'']]]
];
