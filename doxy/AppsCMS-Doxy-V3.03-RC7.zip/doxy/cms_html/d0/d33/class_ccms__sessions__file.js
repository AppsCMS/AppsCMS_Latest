var class_ccms__sessions__file =
[
    [ "__construct", "d0/d33/class_ccms__sessions__file.html#a6b6f1777d9026551730b0b05957943a3", null ],
    [ "__destruct", "d0/d33/class_ccms__sessions__file.html#ab042eee9e1fc46df1465fa87f7e60a53", null ],
    [ "_file_open", "d0/d33/class_ccms__sessions__file.html#a2b5f09da94afc7ca201df3aa8d20bf45", null ],
    [ "_file_close", "d0/d33/class_ccms__sessions__file.html#a9f8fe0471560d44c36d13273a2526fb1", null ],
    [ "_file_read", "d0/d33/class_ccms__sessions__file.html#aa6484802bd529f359a61af75effa2a72", null ],
    [ "_file_write", "d0/d33/class_ccms__sessions__file.html#a3484380c203191fe6f8d396958cfde71", null ],
    [ "_file_destroy", "d0/d33/class_ccms__sessions__file.html#ada7810cb11a94a5164a74ccd459454d3", null ],
    [ "_file_gc", "d0/d33/class_ccms__sessions__file.html#af71c4491939d9dc0c9857bc44c31fa6f", null ],
    [ "_encode_session_data", "d0/d33/class_ccms__sessions__file.html#a0f3a5a4cbb8712a20e71a98d9a28e22a", null ],
    [ "_decode_session_data", "d0/d33/class_ccms__sessions__file.html#aaa7fff2fff1e9b7300c3e4f38093342e", null ],
    [ "init_sessions_file", "d0/d33/class_ccms__sessions__file.html#a7c620d00523fdb661631c64ac8f037ef", null ],
    [ "get_user_sessions", "d0/d33/class_ccms__sessions__file.html#a214777506a32664072b23b5830155878", null ],
    [ "delete_user_session", "d0/d33/class_ccms__sessions__file.html#a297b38891a203b6b2e0e06fd72f6afad", null ],
    [ "$session_path_prefix", "d0/d33/class_ccms__sessions__file.html#a425cc8bf8cc2c982b0e8cf41df64faf2", null ]
];