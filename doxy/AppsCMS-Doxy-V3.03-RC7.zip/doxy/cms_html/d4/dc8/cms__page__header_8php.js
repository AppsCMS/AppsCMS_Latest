var cms__page__header_8php =
[
    [ "$atxt", "d4/dc8/cms__page__header_8php.html#aa5fca2ae9cf48cc0568dbd2d757fc375", null ],
    [ "$smtxt", "d4/dc8/cms__page__header_8php.html#a12840a05c05698f16c6d87144a4923c2", null ],
    [ "$txt", "d4/dc8/cms__page__header_8php.html#aafd3010c1ef87e07032e04966af858bd", null ],
    [ "nbsp", "d4/dc8/cms__page__header_8php.html#aef915316f784c9063d942974538301a6", null ]
];