var class_ccms__detector =
[
    [ "__construct", "d4/dfa/class_ccms__detector.html#ad9f65e8503c057e57cc5ef639556c50b", null ],
    [ "__destruct", "d4/dfa/class_ccms__detector.html#a2b5d865600e0f49719be36e1bb2be259", null ],
    [ "detect_client", "d4/dfa/class_ccms__detector.html#a8521975e50326aa41b92b8e4b0e5b33a", null ],
    [ "use_browscap", "d4/dfa/class_ccms__detector.html#a05a0265cc19d5d83c48c12295e6ce625", null ],
    [ "get_user_agent", "d4/dfa/class_ccms__detector.html#a1f15108846ac0546e0343bb826d58a50", null ],
    [ "is_mobile_device_chk", "d4/dfa/class_ccms__detector.html#a5fd2aa502421644ab2f91a04dc322081", null ],
    [ "is_tiny_device_chk", "d4/dfa/class_ccms__detector.html#a9547cf5d14433816ec3d1a84d594f2bf", null ],
    [ "$det_done", "d4/dfa/class_ccms__detector.html#a3b81129699c6e11cbfb0a7cb335f44cc", null ],
    [ "TINY_WIDTH", "d4/dfa/class_ccms__detector.html#a2ce3bd265278e52021e7b30ab6b9d3a6", null ],
    [ "TINY_HEIGHT", "d4/dfa/class_ccms__detector.html#a146934f86dce9b7c91a3629c511ec7fd", null ],
    [ "TABLET_WIDTH", "d4/dfa/class_ccms__detector.html#a8f6b8c7b2b16a29ecc9b47ec7fda2af5", null ],
    [ "TABLET_HEIGHT", "d4/dfa/class_ccms__detector.html#a01cccfac0cf1923048321a4e300b9081", null ]
];