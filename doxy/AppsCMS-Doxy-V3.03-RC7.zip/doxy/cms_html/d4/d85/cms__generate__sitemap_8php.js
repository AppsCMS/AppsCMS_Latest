var cms__generate__sitemap_8php =
[
    [ "CLI_MODE", "d4/d85/cms__generate__sitemap_8php.html#ac3be5bc25c68177f3e4d9b8ff6e51c7c", null ],
    [ "$msgs", "d4/d85/cms__generate__sitemap_8php.html#acb49e47957a8914fd3b8537ce96a70e4", null ]
];