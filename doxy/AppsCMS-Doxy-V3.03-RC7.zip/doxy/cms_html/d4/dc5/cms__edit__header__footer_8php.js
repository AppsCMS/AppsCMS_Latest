var cms__edit__header__footer_8php =
[
    [ "make_new_hf_text", "d4/dc5/cms__edit__header__footer_8php.html#aed011f2e4bff7c72835056ef3eb80eff", null ],
    [ "$cCMS_C", "d4/dc5/cms__edit__header__footer_8php.html#ab4b9aa0a0c36a434874e4d1dc9d59041", null ],
    [ "$cms_hf_op", "d4/dc5/cms__edit__header__footer_8php.html#a51d791cf60c18cfb7624acc93ee82854", null ],
    [ "$row", "d4/dc5/cms__edit__header__footer_8php.html#ad83097470e9839c86af296c0d2692b33", null ]
];