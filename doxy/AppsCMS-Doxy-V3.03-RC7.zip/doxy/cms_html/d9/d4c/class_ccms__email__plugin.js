var class_ccms__email__plugin =
[
    [ "__construct", "d9/d4c/class_ccms__email__plugin.html#a803b3d7594a6f3a26998b9b9f2e61eed", null ],
    [ "__destruct", "d9/d4c/class_ccms__email__plugin.html#aa56844bd3bce5c08000dc26d00ba8b7f", null ],
    [ "is_enabled", "d9/d4c/class_ccms__email__plugin.html#ac40c1a40730c8aa6d2a425b56bc6077f", null ],
    [ "has_been_sent", "d9/d4c/class_ccms__email__plugin.html#a5c1e579fe729501b66e7127b9639720e", null ],
    [ "send", "d9/d4c/class_ccms__email__plugin.html#a0cd22691068e9d173a423240035da792", null ],
    [ "send_out_mail", "d9/d4c/class_ccms__email__plugin.html#a3b9d405fda44564534244310bf784ade", null ],
    [ "get_title", "d9/d4c/class_ccms__email__plugin.html#a5f095246946d27091dc55511f9af4747", null ],
    [ "get_description", "d9/d4c/class_ccms__email__plugin.html#aa2c7b8445e909094a30253b15bc4268f", null ],
    [ "get_sql_install_data", "d9/d4c/class_ccms__email__plugin.html#abff577dd0e73d2702349d77640bd9283", null ],
    [ "install", "d9/d4c/class_ccms__email__plugin.html#aef48ae105cd502c7330eaad5e4c7ae81", null ],
    [ "uninstall", "d9/d4c/class_ccms__email__plugin.html#a7f510b031a1b8471526186415eb16209", null ],
    [ "PLUGIN", "d9/d4c/class_ccms__email__plugin.html#a2bd81a7c88d0a2ef02fe9ba09da2e1ba", null ]
];