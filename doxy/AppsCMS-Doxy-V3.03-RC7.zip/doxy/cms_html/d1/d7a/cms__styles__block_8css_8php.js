var cms__styles__block_8css_8php =
[
    [ "$pad", "d1/d7a/cms__styles__block_8css_8php.html#ad37a5856e5759bc93cbd14f9174edb34", null ],
    [ "$margin", "d1/d7a/cms__styles__block_8css_8php.html#a3bcbb0dc2ef6299e52d39c45188f6bbc", null ],
    [ "$lay_bound", "d1/d7a/cms__styles__block_8css_8php.html#a4611a131594b14887139784f46de4050", null ],
    [ "$sects", "d1/d7a/cms__styles__block_8css_8php.html#aaa4e38570f07ef205033543d7370fcf7", null ],
    [ "$header_height", "d1/d7a/cms__styles__block_8css_8php.html#aed8f49e34af67440000264714860e5cc", null ],
    [ "$nav_bar_height", "d1/d7a/cms__styles__block_8css_8php.html#af34126aaed2d489029056bb321130245", null ],
    [ "$footer_height", "d1/d7a/cms__styles__block_8css_8php.html#a52ad5d8ab3fa0e8f8ea2f77dee7a5b5d", null ],
    [ "$left_column_width", "d1/d7a/cms__styles__block_8css_8php.html#a7046da0f9447d31332ddb0ddc04ad673", null ],
    [ "$right_column_width", "d1/d7a/cms__styles__block_8css_8php.html#a092bb3cb52ed1a25c819b65fbb628315", null ],
    [ "$sect_gap", "d1/d7a/cms__styles__block_8css_8php.html#a27d79c901bbf5f35b872d9b0169cbd1a", null ],
    [ "$hnf", "d1/d7a/cms__styles__block_8css_8php.html#a05bbd671e4234b9ccdd89d804d08b101", null ],
    [ "border", "d1/d7a/cms__styles__block_8css_8php.html#a656483d4392b22ed85b2b391feadd159", null ],
    [ "__pad0__", "d1/d7a/cms__styles__block_8css_8php.html#a82281c80e5a34da73d7f831c14a3514a", null ],
    [ "__pad1__", "d1/d7a/cms__styles__block_8css_8php.html#acec86c27cb982cab47d6871047a91238", null ],
    [ "__pad2__", "d1/d7a/cms__styles__block_8css_8php.html#a7f14693d32b08d0a42e925c5768411bb", null ],
    [ "__pad3__", "d1/d7a/cms__styles__block_8css_8php.html#a1261c7b57ba7e6c3bef7742b36005742", null ],
    [ "__pad4__", "d1/d7a/cms__styles__block_8css_8php.html#a3ae3a52bd970a3b56a108210f02a3b42", null ],
    [ "__pad5__", "d1/d7a/cms__styles__block_8css_8php.html#afa346bbdf87d6d64cf88409886ddf7f5", null ],
    [ "align", "d1/d7a/cms__styles__block_8css_8php.html#a024818509e9cff11892e2e8927cfc5df", null ],
    [ "__pad6__", "d1/d7a/cms__styles__block_8css_8php.html#aa01c16f688f9a989980580c23f1058ac", null ],
    [ "__pad7__", "d1/d7a/cms__styles__block_8css_8php.html#acddcd7033da39a540ed87e120df1db6a", null ]
];