<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: ws_server.php 2316 2021-10-04 03:14:03Z robert0609 $
 */

// define basic environment for CLI server

define('WS_DAEMON_CALL',true);	// global for ws server recognition
define('CLI_MODE',		true);	// tell configure

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// do configs and settings
require_once 'cms/cms_ws_server.php';

