<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_lib_sqsh.php 2411 2021-11-26 00:32:45Z robert0609 $
 */

function _mount_read_only_filesystem($lib,$moutpnt) {	// this is global
	if((!file_exists($lib)) ||
		(!is_readable($lib))) {	// no squashfs ??
		echo "ERROR: '" . $lib . "' file not found. Cannot mount read only filesystem.";
		false;
		} // if
	@mkdir($moutpnt,0777);	// make sure the mount point is there
	@chmod($moutpnt,0777);	// and useable perms for web and cli
	$g = filegroup('./');
	@chgrp($moutpnt, $g);
	$output=null;
	$retval=null;
	$opts = "-o allow_root";	// -o allow_other -o allow_root
	exec('squashfuse ' .  $opts . ' ' . $lib . ' ' . $moutpnt, $output, $retval);	// mount simple fs
	if($retval) {	// mount fs
		echo "ERROR: Read only " . $lib . " mount failed, status $retval.<br>" . PHP_EOL;
		// print_r($output);
		return false;
		} // if
	return true;
} // _mount_read_only_filesystem()

// mount AppsCMS library (if requied)
if((!file_exists('cms/cms_index.php')) ||
	(!is_readable('cms/cms_index.php'))) {	// cms code not there
	$cms_lib = 'cms_lib_sqsh.sqsh';
	$lib_dir = "./";
	if((!file_exists($lib_dir . $cms_lib)) || (!is_readable($lib_dir . $cms_lib))) {
		$lib_dir = "/usr/local/share/AppsCMS/";	// installed package location of library
		if((!file_exists($lib_dir . $cms_lib)) || (!is_readable($lib_dir . $cms_lib))) {
			echo "ERROR: Cannot find: " . $cms_lib . ", System failure.";
			exit(1001);
			} // if
		} // if

	if(!_mount_read_only_filesystem('cms_lib_sqsh.sqsh','cms')) {
		echo "ERROR: System failure.";
		exit(1001);
		} // if
	} // if

// mount applications filesystem (if requied)
if((!is_dir('apps/include')) ||
	(!is_readable('apps/include'))) {	// apps code not there
	if(!_mount_read_only_filesystem('apps_fs_sqsh.sqsh','apps')) {
		echo "ERROR: System failure.";
		exit(1002);
		} // if
	} // if

// check mount old page_bodies filesystem (if requied)
if(file_exists('page_bodies_fs_sqsh.sqsh')) {
	$files = scandir('apps/bodies');
	if((empty($files)) &&	// empty dir
		(!_mount_read_only_filesystem('page_bodies_fs_sqsh.sqsh', 'apps/bodies'))) {
		echo "ERROR: System failure.";
		exit(1003);
		} // if
	} // if

// eof
