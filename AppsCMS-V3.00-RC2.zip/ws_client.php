<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: ws_client.php 2299 2021-09-29 08:29:12Z robert0609 $
 */

define('WS_CLIENT_CALL',true);	// global for API recognition

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_ws_client.php';

