<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_logout.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

	require_once 'include/cms_top.php';

	if(Ccms_auth::is_a_cookie_login()) {
		// setcookie(CMS_LOGIN_COOKIE_NAME, "", time() - 3600);	// expire cookie
		setcookie(CMS_LOGIN_COOKIE_NAME, 0, time() - 3600,'/');	// expire cookie
		} // else if

	Ccms_auth::logout_user();

	if(INI_ALWAYS_LOGIN_BOOL) {
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'login.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
	header('Location: ' . $url);
	exit (0);
