<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: index.php 2012 2021-03-19 00:19:03Z robert0609 $
 */

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_index.php';

