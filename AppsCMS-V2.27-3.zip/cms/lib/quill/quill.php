<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: quill.php 2036 2021-04-06 06:48:53Z robert0609 $
 */

/**
 * Description
 * cms_wysiwyg functions
 *
 * @author robert0609
 */

echo 'Cquill';	// the class name

class Cquill extends Ccms_wysiwyg {

	function __construct() {
		parent::__construct();
	} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// methods

// static methods
	public function output_edit_text($body_text) {
		$this->body_text = $body_text;

		$text = PHP_EOL;
		$text .= $this->get_wysiwyg_engage();

		return $text;
		} // output_edit_text()

} // Cquill
