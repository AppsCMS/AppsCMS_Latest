/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * Engage system installed tinyMCE WYSIWYG
 * SVN Build: $Id: tinyMCE_system_engage.php 2014 2021-03-22 03:57:26Z robert0609 $
 */

tinymce.init({
	selector: "#ws_text_area",
	height: "960",
	width: "100%",
	plugins : "advlist autolink link image colorpicker lists charmap table hr legacyoutput pagebreak tabfocus textcolor media code searchreplace fullscreen"
	});

// EOF

