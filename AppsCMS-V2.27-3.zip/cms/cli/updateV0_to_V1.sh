#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: updateV0_to_V1.sh 2022 2021-04-02 01:48:01Z robert0609 $

# Update old V0 files to V1 files and file structure.
# does not update file contents, this should be updated with the latest distribution zip

# make dirs relative to this script
BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
cd "$BASE_DIR"

USAGE="USAGE: cms/cli/$(basename $0) [root directory to update]"
DT="$(date '+%Y%m%d-%H%M%S')"

if [ -z "$1" ]; then
	WC="$(pwd)"
else
	WC="$1"
fi

# lookup version
# lookup version, V0 location and V1 location
CONF_LOCS="\
	${WC}/includes/configure.php \
	${WC}/cms/includes/configure.php \
	${WC}/cms/include/configure.php \
"
V=""
for CL in $CONF_LOCS
do
	if [ -f "$CL" ]; then
		V="$(cat "$CL" | grep CMS_PROJECT_VERSION)"
		break;
	fi
done
if [ -z "$V" ]; then
	echo "ERROR: Cannot find \"$WC\" release VERSION"
	exit 1
fi

F=${V##*\"V}
FVERSION=V${F%%\"*}
# should it's version ?? maybe !
if [ "$FVERSION" \> "V1.03" ]; then
	echo "Found $FVERSION, no code update required."
	exit 0
fi
echo "Found $FVERSION, updating directories."

# make new cms directory
V102_DIRS="\
	apps \
	cms \
	etc/images/backgrounds \
	etc/images/icons \
	etc/images/upload \
	etc/ini \
	etc/ext \
	etc/sqlite \
	localtools \
	page_bodies \
	var/backups \
	var/cache \
	var/exports \
	var/gotcha \
	var/logs \
	var/sessions \
	var/Trash \
	var/variables \
"
for D in $V102_DIRS
do
	WCD="${WC}/${D}"
	if [ ! -d "$WCD" ]; then
		mkdir -p "$WCD"
		if [ $? -ne 0 ]; then
			echo "ERROR: cannot make \"$WCD\"."
			exit 2
		fi
		svn add "$WCD" 2> /dev/null
		git add "$WCD" 2> /dev/null
	fi
done

function git_svn_mv() { # $1=F $2=FN
	local F="$1"
	local FN="$2"
	local RET=0

	echo "Move \"$F\" to \"$FN\"."
	TMP="$(which git | grep 'no git in')"
	git ls-files --error-unmatch "$F" 1>/dev/null 2>&1
	if [ $? -eq 0 -a -z "$TMP" ]; then
		echo "Renaming \"$F\" with git."
		git mv -f -v "F$" "FN"
		RET=$?
	else
		TMP="$(which svn | grep 'no svn in')"
		svn info "$F" 1>/dev/null 2>&1
		if [ $? -eq 0 -a -z "$TMP" ]; then
			echo "Renaming \"$F\" with svn."
			svn mv --force "$F" "$FN"
			RET=$?
		else
			echo "Renaming \"$F\" with mv."
			mv -f -v "$F" "$FN"
			RET=$?
		fi
	fi
	if [ $RET -ne 0 ]; then
		echo "Move failed."
	fi
	return $RET
} # git_svn_mv()

if [ ! -d "$WC" ]; then
	echo "$WC does not exist."
	exit 1
fi

# remove unused language files
find "$WC" -name "*.js" | grep lang | pcregrep -v "en.*\.js" | while read F
do
	echo "Removing $F"
	rm -f "$F"
done

# early version files to cleanup
DEL_FILES="\
	ini/cms.comments.ini \
	ini/cms.defaults.ini \
	include/title_tooltips.js.php \
	images/backgrounds/bw_logo.gif \
	images/backgrounds/gadgeteer_logo.gif \
	images/upload/bw_logo.gif \
"

for DF in $DEL_FILES
do
	echo "Checking for \"${WC}/${DF}\"."	# test
	if [ -f "${WC}/${DF}" ]; then
		rm -f "${WC}/${DF}"
		echo "File \"$DF\" removed. No longer required."
		if [ $? -eq 0 ]; then
			echo "File \"$DF\" removed. No longer required."
		fi
	fi
done

# Rename/move files in WCs, the order is important.
REN_FILES="\
	ajax.php,cms/ \
	applocal,apps \
	backups,cms/ \
	block_styles.css,cms/ \
	cli,cms/ \
	client_visit_cntr.js,cms/ \
	cms_body_funcs.js,cms/ \
	cms_extra_funcs.js,cms/ \
	cms_funcs.js,cms/ \
	exports,cms/ \
	images,cms/ \
	includes,cms/ \
	inline_styles.css,cms/ \
	installation.txt,cms/ \
	login.php,cms/ \
	logout.php,cms/ \
	main_styles.css,cms/ \
	phpinfo.php,cms/ \
	releasenotes.txt,cms/ \
	sessions,cms/ \
	title_tooltips.js,cms/ \
	variables,cms/ \
	wysiwyg,cms/ \
	plugins,cms/include/ \
	cms/include/cms,cms/include/ops \
	cms/include/ini/cms.ini,etc/ini/ \
	cms/include/ini/cms.json,etc/ini/ \
	cms/include/sqlite,etc/ \
	cms/ext,etc/ \
	cms/cli/update2V1.sh,cms/cli/updateV0_to_V1.sh \
	cms/images/backgrounds,etc/backgrounds/ \
	cms/images/upload,etc/images/ \
	cms/images/icons,etc/icons/ \
	cms/images/gotcha,var/ \
	cms/sessions,var/ \
	cms/exports,var/ \
	cms/backups,var/ \
	cms/variables,var/ \
	cms/cache,var/ \
	cms/images/gotcha,var/ \
	logs,var/ \
	apps/plugins,apps/include/ \
	cms/includes,cms/include \
"

pushd "$WC" > /dev/null
for RF in $REN_FILES
do
	SRC="${RF%,*}"
	DST="${RF#*,}"
	echo "Checking \"${SRC}\"."
	# pwd # test
	if [ -f "${SRC}" -o -d "${SRC}" ]; then
		git_svn_mv "${SRC}" "${DST}"
		# mv -f "${SRC}" "${DST}"
		if [ $? -eq 0 ]; then
			echo "Renamed or moved \"$SRC\" to \"$DST\"."
		else
			echo "FAILED: to rename or move \"$SRC\" to \"$DST\"."
		fi
	fi
done
popd > /dev/null

if [ "$FVERSION" \> "V1.01" ]; then
	echo "Found $FVERSION, no code update required."
	exit 0
fi
echo "Found $FVERSION, updating code."

# find 'applocal' names and change to 'apps'
echo "Find applocal files in \"$WC\" and rename to apps"
find "$WC" -type f -name '*applocal*' | egrep -v '.svn/|.git/' | while read F
do
	FN="$(echo "$F" | sed 's/applocal/apps/g')"
	git_svn_mv "$F" "$FN"
done

# inline edit files from V0 to V1
echo "Find patterns in text and replace in files in \"${WC}/apps\"."
# FIND_REPLACE_PATS used with sed
FIND_REPLACE_PATS="\
	applocal,apps   \
	Applocal,Apps   \
	AppLocal,Apps   \
	APPLOCAL,APPS   \
	APP_LOCAL,APPS   \
"
FR_IGNORE_PAT="'\.zip$|\.log$|_orig$|\.orig$|\.svn\/|\.git\/'"
BK_EXT="_${DT}_orig"
# echo $FR_IGNORE_PAT; exit   # test
for FR in $FIND_REPLACE_PATS
do
	FD="${FR%,*}"   # find pattern
	RP="${FR#*,}"   # replace
	# echo "$FD => $RP"; continue	# test
	egrep -rl "$FD" apps/ | while read F
	do
		TMP=$(echo "$F" | egrep -e $FR_IGNORE_PAT)
		# echo "TMP = $TMP"   # test
		if [ ! -z "$TMP" ]; then continue; fi
		echo "Filename: \"$F\"."	# test
		echo "$(cat "$F" | egrep "$FD")"	# test
		sed -i$BK_EXT "s/$FD/$RP/g" "$F"
	done
done

exit 0

# EOF
