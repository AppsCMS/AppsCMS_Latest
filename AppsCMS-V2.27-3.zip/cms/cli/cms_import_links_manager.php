<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_import_links_manager.php 2004 2021-02-28 08:53:00Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('REBUILD_MODE',	true);	// tell configure i am rebuilding (same as rebuild from web)

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

function show_help() {
	echo "ERROR: Need at least a command and value." . PHP_EOL;
	echo "Commands:" . PHP_EOL;
	echo "	--lm-import-dir	path_to_links_manager.sqlite" . PHP_EOL;
	echo "" . PHP_EOL;
	} // show_help

if($argc < 3) {
	show_help();
	exit(1);
	} // if

class Cimport_lm_data extends Ccms_base {

	const LM_INI_FILE = 'includes/ini/lm.ini';
	const INI_EXCLUDE_SECTIONS = 'CRONsettings,SessionSettings,DataBaseAccess,AppsControlSettings';
	const LM_DB_FILE = 'includes/sqlite/links_manager.sqlite';
	const CMS_DB_EXCLUDE_KEYS = 'CMS_C_VERSION';
	const LM_BAKGRD_IMGS_DIR = 'images/backgrounds/';
	const LM_IMGS_DIR = 'images/upload/';

	public $cDB_lm = false;
	protected static $lm2cms_tables = array(
		// NOTE: That colsumns not imported are left at there default values
		'lm_links' => array(	// sorc table
			'cms_table' => 'lm_links',
			'match_cols' => array(	// columns to match for row update
				// 'lm_unique_col'	=> 'cms_unique_col'
				'lm_link_id'	=> 'lm_link_id',
				),
			'import_cols' => array(	// columns to import
				'lm_link_id'	=> 'lm_link_id',
				'lm_link_name'	=> 'lm_link_name',
				'lm_link_url' => 'lm_link_url',
				'lm_link_description' => 'lm_link_description',
				'lm_link_order' => 'lm_link_order',
				'lm_link_enabled' => 'lm_link_enabled',
				'lm_link_title' => 'lm_link_title',
				'lm_link_section_id' => 'lm_link_section_id',
				'lm_link_image_url' => 'lm_link_image_url',
				"lm_link_new_page" => "lm_link_new_page",
				"lm_link_ssl" => "lm_link_ssl",
				"lm_link_add_name2url" => "lm_link_add_name2url",
				),
			),
		'lm_sections' => array(	// sorc table
			'cms_table' => 'lm_sections',
			'match_cols' => array(	// columns to match for row update
				// 'lm_unique_col'	=> 'cms_unique_col'
				'lm_section_id'	=> 'lm_section_id',
				),
			'import_cols' => array(	// columns to import
				'lm_section_id'	=> 'lm_section_id',
				'lm_section_name' => 'lm_section_name',
				'lm_section_description' => 'lm_section_description',
				'lm_section_order' => 'lm_section_order',
				'lm_section_enabled' => 'lm_section_enabled',
				'lm_section_columns' => 'lm_section_columns',
				'lm_section_title' => 'lm_section_title',
				'lm_section_image_url' => 'lm_section_image_url',
				),
			),
		'lm_users' => array(	// sorc table
			'cms_table' => 'cms_users',
			'match_cols' => array(	// columns to match for row update
				// 'lm_unique_col'	=> 'cms_unique_col'
				'lm_user_name'	=> 'cms_user_name',
				),
			'import_cols' => array(	// columns to import
				"lm_user_name" => "cms_user_name",						// the user name
				"lm_user_password_md5" => "cms_user_password_md5",				// the md5ed password
				"lm_user_admin" => "cms_user_admin",			// the administrator rights enabled or disabled
				"lm_user_enabled" => "cms_user_enabled",		// the user enabled or disabled
				),
			),
		'lm_groups' => array(	// sorc table
			'cms_table' => 'cms_groups',
			'match_cols' => array(	// columns to match for row update
				// 'lm_unique_col'	=> 'cms_unique_col'
				'lm_group_name'	=> 'cms_group_name',
				),
			'import_cols' => array(	// columns to import
				"lm_group_name" => "cms_group_name",	// the group name
				"lm_group_description" => "cms_group_description",
				"lm_group_admin" => "cms_group_admin",	// the administrator right enabled or disabled
				"lm_group_order" => "cms_group_order",	// sort order
				"lm_group_enabled" => "cms_group_enabled",		// the group enabled or disabled
				),
			),
		'lm_tools' => array(	// sorc table
			'cms_table' => 'cms_tools',
			'match_cols' => array(	// columns to match for row update
				// 'lm_unique_col'	=> 'cms_unique_col'
				'lm_tool_name'	=> 'cms_tool_name',
				),
			'import_cols' => array(	// columns to import
				"lm_tool_name" => "cms_tool_name",
				"lm_tool_group_ids" => "cms_tool_group_ids",	// display group ids
				"lm_tool_order" => "cms_tool_order",	// sort order
				"lm_tool_enabled" => "cms_tool_enabled",
				"lm_tool_url" => "cms_tool_url",
				"lm_tool_description" => "cms_tool_description",
				"lm_tool_title" => "cms_tool_title",
				"lm_tool_new_page" => "cms_tool_new_page",
				"lm_tool_ssl" => "cms_tool_ssl",
				"lm_tool_add_name2url" => "cms_tool_add_name2url",
				),
			),
		);

	function __construct($lm_base_dir) {
		parent::__construct();
		Ccms_SQLite::$cmsDBreconstructDone = true;	// stop reconstruction save from here
		$cd = getcwd();	// test
		if(!is_dir($lm_base_dir)) {
			self::addMsg('Failed to open LM base dir "' . $lm_base_dir . '".');
			return;
			}
		$this->copy_lm_installs($lm_base_dir);
		$this->import_lm_DB($lm_base_dir);
		$this->copy_lm_images($lm_base_dir);
		$this->copy_lm_configs($lm_base_dir);
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

//dynamic methods
	protected function import_lm_DB($lm_base_dir) {
		$lm_db_path = self::clean_path($lm_base_dir . '/' . self::LM_DB_FILE);
		if(!file_exists($lm_db_path)) {
			echo '"' . $lm_db_path . '" Link_Manager DB does not exist.' . PHP_EOL;
			self::$cDBcms->logEvent('"' . $lm_db_path . '" Link_Manager DB does not exist.');
			return false;;
			} // if
		$ok = true;
		$this->cDB_lm = new Ccms_database_sqlite($lm_db_path);
		if($this->cDB_lm->is_ok()) {
			echo 'Starting -> data import from "' . $lm_db_path . '".' . PHP_EOL;
			self::$cDBcms->logEvent('Starting -> data import from "' . $lm_db_path . '".');
			foreach(self::$lm2cms_tables as $lm_t => &$ops) {
				if($cnt = $this->convert_DB_table($lm_t, $ops)) {
					echo 'Imported ' . $cnt . ' entries to table "' . $lm_t . '".' . PHP_EOL;
					self::$cDBcms->logEvent('Imported table "' . $lm_t . '".');
					} // if
				else {
					echo 'Failed to import table "' . $lm_t . '".' . PHP_EOL;
					self::$cDBcms->logEvent('Failed to import table "' . $lm_t . '".');
					$ok = false;
					} // else
				} // foreach
			echo 'Finished -> importing data from "' . $lm_db_path . '".' . PHP_EOL;
			self::$cDBcms->logEvent('Finished -> importing data from "' . $lm_db_path . '".');

			echo 'IMPORTANT NOTE: User and Group permissions need to be checked and/or reassigned after running this script.' . PHP_EOL;
			self::$cDBcms->logEvent('Important Note: User and Group permissions need to be checked and/or reassigned after running this script.');

			if($this->cDB_lm) $this->cDB_lm->close ();
			$this->cDB_lm = false;
			} // if
		else {
			echo 'Failed to open "' . $lm_db_path . '".' . PHP_EOL;
			self::$cDBcms->logEvent('Failed to open "' . $lm_db_path . '".');
			$ok = false;
			} // else
		return $ok;
		} // import_lm_DB()

	protected function convert_DB_table($lm_t,&$ops) {
		$ok = true;
		$cnt = 0;
		$cms_t = $ops['cms_table'];
		$lm_order = key($ops['match_cols']);
		$cms_key = $ops['match_cols'][$lm_order];
		if(!$lm_result = $this->cDB_lm->query('select * from ' . $lm_t . ' order by ' . $lm_order . ';')) return false;
		while($row = $this->cDB_lm->fetch_array($lm_result)) {
			$fields = array();
			foreach ($ops['import_cols'] as $from => $to) {
				if(empty($row[$from])) continue;	// don't over write with empty values
				$fields[$to] = $row[$from];
				} // foreach
			if(Ccms::$cDBcms->is_data_in_table($cms_t,$cms_key,$row[$lm_order])) {	// do update
				if(!Ccms::$cDBcms->perform($cms_t,$fields,'update',$cms_key . " = '" . $row[$lm_order] . "'")) {
					$ok = false;
					break;
					} // if
				$cnt++;
				} // if
			else { // do insert
				if(!Ccms::$cDBcms->perform($cms_t,$fields,'insert')) {
					$ok = false;
					break;
					} // if
				$cnt++;
				} // else
			} // while
		return ($ok ? $cnt:false);
		} // convert_DB_table()

	protected function copy_lm_images($lm_base_dir){
		// copy background images
		$lm_bk_imgs_path = self::clean_path($lm_base_dir . '/' . self::LM_BAKGRD_IMGS_DIR);
		$cms_bk_imgs_path = ETC_FS_BACKGROUNDS_DIR;
		$b_cnt = $this->copy_images($lm_bk_imgs_path, $cms_bk_imgs_path);
		echo 'Copied ' . $b_cnt . ' background images.' . PHP_EOL;
		self::$cDBcms->logEvent('Copied ' . $b_cnt . ' background images.');

		// copy upload images
		$lm_up_imgs_path = self::clean_path($lm_base_dir . '/' . self::LM_IMGS_DIR);
		$cms_up_imgs_path = ETC_FS_IMAGES_DIR;
		$u_cnt = $this->copy_images($lm_up_imgs_path, $cms_up_imgs_path);
		echo 'Copied ' . $u_cnt . ' upload images.' . PHP_EOL;
		self::$cDBcms->logEvent('Copied ' . $u_cnt . ' upload images.');

		} // copy_lm_images()

	protected function copy_images($sorc,$dest, $mime_type = false) {
		if(!is_dir($sorc)) return 0;
		$sorc_list = scandir($sorc);
		$cnt = 0;
		if(!$sorc_list) {
			echo 'No images found in "' . $sorc . '".' . PHP_EOL;
			self::$cDBcms->logEvent('No images found in "' . $sorc . '".');
			return $cnt;
			} // if
		foreach($sorc_list as $file) {
			$sorc_file = self::clean_path($sorc . '/' . $file);
			if(is_dir($sorc_file)) continue;	// a directory (recurse ???)
			if(!self::is_file_usable($sorc_file)) continue;	// not for me
			$mime = mime_content_type($sorc_file);
			if(!preg_match('/image/i',$mime)) continue;	// not an image
			$dest_file = self::clean_path($dest . '/' . $file);
			if(!copy($sorc_file,$dest_file)) {
				echo 'Failed to copy image "' . $file . '".' . PHP_EOL;
				self::$cDBcms->logEvent('Failed to copy image "' . $file . '".');
				} // if
			else $cnt++;
			} // foreach
		return $cnt;
		} // copy_images()

	protected function copy_lm_configs($lm_base_dir) {
		$lm_db_path = self::clean_path($lm_base_dir . '/' . self::LM_DB_FILE);
		if(!file_exists($lm_db_path)) {
			echo '"' . $lm_db_path . '" Link_Manager DB does not exist.' . PHP_EOL;
			self::$cDBcms->logEvent('"' . $lm_db_path . '" Link_Manager DB does not exist.');
			return false;;
			} // if
		echo 'Starting -> configs import from "' . $lm_db_path . '".' . PHP_EOL;
		$ok = true;
		$this->cDB_lm = new Ccms_database_sqlite($lm_db_path);

		$cCMSi = new Ccms_DB_install();
		$cCMSi_configs = $cCMSi->get_installDBscriptsSQLite();
		$cCMSi_configs_table = &$cCMSi_configs['cms_configs'];
		$cCMS_keys2def = array();
		foreach($cCMSi_configs_table['data'] as &$c) $cCMS_keys2def[($c[3])] = $c[4];	// make default list

		$lm_pre = 'LMC_';
		$cms_pre = 'CMS_C_';
		$cms_exclude_keys = explode(',',self::CMS_DB_EXCLUDE_KEYS);
		if(((self::$cDBcms->is_ok())) && ($this->cDB_lm->is_ok())) {
			$cnt = 0;
			$conf_sql = 'SELECT cms_config_key,cms_config_value FROM cms_configs ORDER BY cms_config_id;';
			if($conf_result = self::$cDBcms->query($conf_sql)) {
				while($conf = self::$cDBcms->fetch_array($conf_result)) {
					// exchange prefixes and see whats available.
					$cms_config_key = $conf['cms_config_key'];
					if(in_array($cms_config_key, $cms_exclude_keys)) continue;
					$cms_config_value = $conf['cms_config_value'];
					if(!empty($cms_config_value)) {	// filter cms values
						if((!preg_match('/^my|default/i',$cms_config_value)) &&
							(isset($cCMS_keys2def[$cms_config_key])) &&
							($cms_config_value != $cCMS_keys2def[$cms_config_key])) continue;	// not default value
						} // if
					$lm_config_key = str_replace($cms_pre,$lm_pre, $cms_config_key);	// make corresponding lm key
					$lm_sql = 'SELECT lm_config_key,lm_config_value FROM lm_configs WHERE lm_config_key = \'' . $lm_config_key . '\';';
					if(($lm_result = $this->cDB_lm->query($lm_sql)) &&
						($lm_vals = $this->cDB_lm->fetch_array($lm_result))) {	// key match
						$lm_val = $lm_vals['lm_config_value'];
						if(!empty($lm_val)) {	// save value
							$up_sql = 'UPDATE cms_configs SET cms_config_value = \'' . $lm_val . '\' WHERE cms_config_key = \'' . $cms_config_key . '\';';
							if($up_result = self::$cDBcms->query($up_sql)) {
								echo 'IMPORT: updated "' . $cms_config_key . '" to "' . $lm_val . '".' . PHP_EOL;
								$cnt++;
								} // if
							} // if
						} // if
					} // while
				} // if
			} // if
		if($this->cDB_lm) $this->cDB_lm->close ();
		$this->cDB_lm = false;

		self::addMsg('Copied ' . $cnt . ' configs from LM to ' . CMS_PROJECT_SHORTNAME . '.','info');
		echo 'Finished -> configs import from "' . $lm_db_path . '".' . PHP_EOL;
		return $cnt;
		} // copy_lm_configs()

	protected function copy_lm_installs($lm_base_dir) {
		$lm_ini_path = self::clean_path($lm_base_dir . '/' . self::LM_INI_FILE);
		if(!file_exists($lm_ini_path)) {
			echo '"' . $lm_ini_path . '" Link_Manager install settings INI file does not exist.' . PHP_EOL;
			self::$cDBcms->logEvent('"' . $lm_ini_path . '" Link_Manager install settings INI file does not exist.');
			return false;;
			} // if
		echo 'Starting -> installation settings import from "' . $lm_ini_path . '".' . PHP_EOL;
		$cms_inst_conf = Ccms::read_cms_ini_settings();
		$lm_inst_conf = parse_ini_file($lm_ini_path, true);
		$ok = true;
		$cnt = 0;
		$exclude_sections = explode(',',self::INI_EXCLUDE_SECTIONS);

		foreach($cms_inst_conf as $sect_name => &$sect) {
			if(in_array($sect_name,$exclude_sections)) continue;
			foreach($sect as $key => &$v) {
				$lm_key = preg_replace('/_PDB_/','_DB_',$key);	// change in DB key
				if((isset($lm_inst_conf[$sect_name][$lm_key])) &&
					($cms_inst_conf[$sect_name][$key] != $lm_inst_conf[$sect_name][$lm_key])) {
					$cms_inst_conf[$sect_name][$key] = $lm_inst_conf[$sect_name][$lm_key];
					$cnt++;
					} // if
				} // foreach
			} // foreach

		Ccms::save_cms_ini_settings($cms_inst_conf,true);
		self::addMsg('Copied ' . $cnt . ' installation settings from LM to ' . CMS_PROJECT_SHORTNAME . '.','info');
		echo 'Finished -> installation settings from "' . $lm_ini_path . '".' . PHP_EOL;
		return $cnt;
		} // copy_lm_installs()

} // Cimport_lm_data()

switch($argv[1]) {	// get comman
case '--lm-import-dir':
	new Cimport_lm_data($argv[2]);
	break;
default:
	show_help();
	exit(2);
	} // switch

exit(0);	// done

// eof
