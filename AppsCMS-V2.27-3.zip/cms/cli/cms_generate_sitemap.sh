#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_generate_sitemap.sh 1961 2021-01-25 10:09:54Z robert0609 $

# generate sitemap script for Applications Management System Library for PHP (AppsCMS)

BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null

php cms/cli/cms_generate_sitemap.php

popd > /dev/null

# EOF

