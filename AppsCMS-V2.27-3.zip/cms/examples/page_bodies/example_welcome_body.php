<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_welcome_body.php 2004 2021-02-28 08:53:00Z robert0609 $
 */

?>
<style>
/*	Could be a CSS file.*/
/*	Because these are last styles loaded you should able to over ride any style */
body {
	background-color: lightblue;
}
.welcome {
	background-color: inherit;
	border: 2px none white;
}

.welcome_header {
	position: absolute;
	background-color: lightgreen;
	height: 100px;
	width: 100%;
	top: 0;
}

.welcome_navbar {
	position: absolute;
	background-color: crimson;
	float: left;
	margin: 0 auto;
	height: 30px;
	top: 100px;
	width: 100%;
}
.welcome_main {
	position: absolute;
	background-color: pink;
	vertical-align: middle;
	text-align: center;
	width: 100%;
	top: 130px;
	bottom: 25px;
	margin: 0 auto;
}

.welcome_footer {
	background-color: lightyellow;
	position: absolute;
	height: 25px;
	width: 100%;
	bottom: 0;

}
</style>
<div class="welcome">
<div class="welcome_header">
	<table class="welcome_header">
		<caption>Welcome Page header</caption>
		<tr class="welcome_header">
			<td>&nbsp;</td>
			<td class="welcome_header" style="text-align: left;">
				<a href="<?php echo (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL); ?>index.php"
					onclick="Ccms_cursor.setWait();"
					title="Welcome Page">
<?php		if(strlen(CMS_C_LOGO_IMAGE) > 4) {
				echo '<img class="logo" src="' . ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE . '" alt="Home">';
				}
			else echo '<strong>Home</strong>';
?>
				</a>
			</td>
<?php
//		// with these secondary level function, the AppsCMS will match a normal header.
//		$atxt = Ccms::get_header_admin_tools_db_text();
//		if(!empty($atxt)) echo '<td class="welcome_header" style="text-align: left;">' . $atxt . '</td>' . PHP_EOL;
//		$smtxt = Ccms::get_social_media('header_left');
//		if(!empty($smtxt)) echo '<td class="welcome_header" style="text-align: left;">' . $smtxt . '</td>' . PHP_EOL;
?>
			<td class="welcome_header" style="text-align: center;">
<?php
		echo Ccms::get_header_bar_title();
?>
			</td>
<?php
//		// sort where the login and social media sit
//		$smtxt = Ccms::get_social_media('header_right');
//		$txt = (!INI_NAV_BAR_BOOL ? Ccms_auth::get_login_logout():'');
//		if(!empty($txt)) {
//			if(!empty($smtxt)) echo '<td class="welcome_header" style="text-align: right;">' . $smtxt . '</td>' . PHP_EOL;
//			echo '<td class="welcome_header" style="text-align: right; width: 25%; font-size: smaller;">' . $txt . '</td>';
//			} // if
//		else if(!empty($smtxt)) echo '<td class="welcome_header" style="text-align: right; width: 25%;">' . $smtxt . '</td>' . PHP_EOL;
//		else echo '<td class="welcome_header" style="text-align: right; width: 25%;">' . '&nbsp;' . '</td>' . PHP_EOL;
?>
				<td>&nbsp;</td>
			</tr>
		</table>
	</div>

	<div class="welcome_navbar">
		<?php include(CMS_FS_INCLUDES_DIR . 'cms_page_nav_bar.php'); ?>
	</div>

	<div class="welcome_main">
		<p class="welcome_main">
			I am the main bit.
		</p>
		<p>
			Where is the LOGO !!!
		</p>
	</div>

	<div class="welcome_footer">
		<p class="welcome_footer">
			I am the footer.
		</p>
		<div class="welcome_footer">

		</div>
	</div>
	<div class="welcome_footer">
		<?php
			$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
			echo $tla['html'];
		?>
	</div>

</div>

