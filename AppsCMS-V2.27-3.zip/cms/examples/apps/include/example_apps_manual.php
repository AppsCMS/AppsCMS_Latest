<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_apps_manual.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

// This example file is the head code file for the applications technical manual.
// The manual sections for each application may be written here or included from apps/ subdirectories.
// the theme control is the same as cms_manual.php <?php echo CMS_PROJECT_SHORTNAME; ?> manual.
// which means that all html elements should use the class="page_body" to maintain theme setability and consistancy when the thems changes.
// copy this file to apps_manual.php and edit as required.
// a typicall content starting point template is shown in this example
?>

<?php Ccms::page_start_comment(__FILE__); ?>

<table class="page_body" style="color: black; background-color: white;">
	<caption>Technical Manual for <?php echo CMS_C_CO_NAME; ?> page</caption>
	<tr class="page_body">
		<th class="page_body">
			<?php echo Ccms::get_admin_scroll2pageTop(); ?>
			<h1>Technical Manual for <?php echo CMS_C_CO_NAME; ?> Web Applications.</h1>
		</th>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="Contents"></a>
			Contents
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<ul>
				<li class="page_body">
					<a href="index.php?action=apps_manual#Introduction">Introduction</a>
				</li>
				<li class="page_body">
					<a href="index.php?action=apps_manual#web_apps_server"><?php echo CMS_C_CO_NAME; ?> Web Apps Server</a>
				</li>

<?php // set links application manuals links or incudes here


?>
				<li class="page_body">
					<a href="index.php?action=apps_manual#Licence">Licence</a>
				</li>
				<li class="page_body">
					<a href="index.php?action=apps_manual#MoreInfo">More Information and Feedback</a>
				</li>
<?php if(file_exists("doxy/html/index.html")) { ?>
				<li class="page_body">
					<a href="doxy/html/index.html">Apps Code Documentation</a>.
				</li>
<?php	} // if ?>
			</ul>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="Introduction"></a>
			Introduction
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				This technical manual is for <?php echo CMS_C_CO_NAME; ?> web apps.
				For the <?php echo CMS_PROJECT_SHORTNAME; ?>refer to the <a href="index.php?cms_action=cms_manual"><?php echo CMS_PROJECT_SHORTNAME; ?> Technical Manual</a>.<br>
				This manual contains technical information on the applications used on the <?php echo CMS_C_CO_NAME; ?> wed applications server.
				It is not intended as a user manual.
				See the <a href="README.md">README.md</a> file and the <a href="ABOUT.md">ABOUT.md</a> file also.
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="web_apps_server"></a>
			<?php echo CMS_C_CO_NAME; ?> Web Apps Server
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				@TODO
			</p>
	<tr class="page_body">
		<th class="page_body">
			<a name="VersionControl"></a>
			File Version Control
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				The file version control is ...
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="Licence"></a>
			Licence
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				<?php echo CMS_C_CO_NAME; ?> is a &copy; { entity name } product and <b>is all rights reserved</b>.
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="MoreInfo"></a>
			More Information and Feedback
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				etc. ...
			</p>
			<p class="page_body">
				Hints, corrections and suggestions are always welcome.
				Email <A mailto:="<?php echo CMS_C_EMAIL_ADDRESS; ?>?Subject=<?php echo rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION); ?>">Feedback</A>.
			</p>
		</td>
	</tr>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>
