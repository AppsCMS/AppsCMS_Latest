<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_apps_auth.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Cexample_apps_auth
 * This is a very simple class to show how to authenticate login application based login
 * Refer to manual for more information.
 * the auto class loader finds me in apps/include/classes/ directory
 *
 * @author robert0609
 */

class Cexample_apps_auth extends Ccms_app_base {

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function is_page_allowed($name) {
		return true;
		} // is_page_allowed()

	public static function is_navbar_element_allowed($name) {
		return true;
		} // is_navbar_element_allowed()

	public static function is_login_current() {
		// checks to see if apps user is still current, used with dual authentication
		return null;	// don't know or not used, false = no, true = logged in still
		} // is_login_current()

	public static function login($user = false, $password = false) {
		// do the credential checks, logging in code and return true for logged in,
		//  the AppsCMS will save user name and cms settings for user in the $_SESSION global
		//
		// or return false if denied, cms will return to the home page
		if(!Ccms_auth::is_login_allowed()) return false;	// not allowed
		// do login code
		return true;
	} // login()

	public static function init($user) {
		// initialize code
		// $user is user name of logged in user or false if not logged in,
		// return true for ok or
		// return false if denied, cms will logout and return to the home page
		return true;	// ok (for example)
	} // init()

	public static function init_remote() {
		// initialize remote code
		// return true for ok or
		// return false if denied, cms will disable app auth

		return true;	// ok (for example)
		} // init_remote()

	public static function logout() {
		// do the logout code
		// log the user out of apps
		return true;	// was logged in
		} // logout()

	public static function get_short_name() {	// get a short name for auth type
		return 'Example';
		} // get_short_name()

	public static function get_title() {	// get a title for auth type
		return 'Example authentication class';
		} // get_short_name()

	public static function get_JS() {	// get javascript for  auth type
		return '';
		} // get_JS()

	public static function get_html() {	// get the filename of the login html for auth type
		return false;	// false = no file (uses another means)
		} // get_html()

	public static function do_apps_warnings($chk_flg = false) {
		if((!$chk_flg) && (!INI_INSTALLATION_WARNINGS_BOOL)) return true;

		self::log_msg((Ccms_auth::is_admin_user () ? 'Admin ':'') . 'Installation Check.','info');

		$ok = true;

		// add apps installation check code here
		
		if($chk_flg) {
			if($ok) self::log_msg('No apps install issues detected.','info');
			} // if
		if (self::is_cli()) return true;	//ok for CLI
		return $ok;
		} // do_apps_warnings()

} // Cexample_apps_auth
