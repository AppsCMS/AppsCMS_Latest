<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_dyn_cntl_base.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Cexample_dyn_cntl_base
 *
 * Contains the base class methods for the dynamic control plugin to return dynamic values for the session
 * N.B. This class is in a class directory, not in a plugin directory (will be found)
 * Basically a declutter class.
 *
 * @author robert0609
 */

class Cexample_dyn_cntl_base extends Ccms_plugin_base {

	const DYN_CTL_TITLE = "Example Dynamic Control";	// for humans
	const DYN_CTL_CLASS = 'Cexample_dyn_cntl_app_plugin';	// name of the top class (or the class to use)

	protected static $dyn_keys2funcs = array(
		'LANGUAGE_CODE' => array(
			'func' => 'get_language',
			'text' => 'Get Language',
			'allowed' => array(	// an extension of AppsCMS allowed values
				'Zulu',	// as an example
				),
			),
		'CHAR_SET' => array(
			'func' => 'get_char_set',
			'text' => 'Get Character Set',
			'allowed' => array(
				'iqoqo lezinhlamvusimo',	// as an example
				),
			),
		'DEBUG_BOOL' => array(
			'func' => 'get_debug',
			'text' => 'Get Debug',
			'allowed' => array(
				'true',	// as an example
				'false',
				),
			),

		);

	protected static $user = false;

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

// general static methods
	public static function is_enabled() {	// required function, virtual function
		return false;
		} // is_enabled()

	public static function get_title() {	// get the plugin title, virtual function
		return false;
		} // get_title()

	protected static function is_key_used($key) {
		if(!self::is_debug()) return false;	// I'm only an example
		if((empty($key)) ||
			(!isset(self::$dyn_keys2funcs[$key]))) return false;
		return true;
		} // is_key_used()

	public static function get_dyn_method_by_key($key) {	// part of the settings code
		if(!self::is_key_used($key)) return false;	// I'm only an example
		// as an example, a simple lookup key
		$func = self::$dyn_keys2funcs[$key]['func'];
		if(!method_exists(__CLASS__, $func)) { // tell someone it failed
			$msg = 'Dynamic control class ' . __CLASS__ . ': Failed to find function - ' . $func;
			self::addDebugMsg($msg);
			return false;	// a check
			} // if
		self::$user = Ccms_auth::get_logged_in_username();
		return self::DYN_CTL_CLASS . '::' . $func;	// its here in self::
		} // get_dyn_method_by_key()

	public static function get_title_by_key($key) {	// part of the settings code
		if(!self::is_enabled()) return false;
		if(!self::is_key_used($key)) return false;	// I'm only an example
		// as an example, a simple lookup key
		$title = (isset(self::$dyn_keys2funcs[$key]['text']) ? self::$dyn_keys2funcs[$key]['text']:self::$dyn_keys2funcs[$key]['func']);
		return self::DYN_CTL_TITLE . '::' . $title;	// its here in self::
		} // get_title_by_key()

	private static function is_allowed_value($type) {
		if((!isset($type['allowed'])) &&
			(!isset(self::$dyn_keys2funcs[$key]['allowed']))) return true;	// not controlled values
		if((!isset($type['allowed'])) && (in_array($value,$type['allowed']))) return true;
		if((!isset($dyn_keys2funcs[$key]['allowed'])) && (in_array($value,$dyn_keys2funcs[$key]['allowed']))) return true;
		return false;	// not allowed
		} // is_allowed_value()

	public static function get_dyn_value_by_key($key,$type) {	// run at the beginning of the session (each session)
		if(($func = self::get_dyn_method_by_key($key)) === false) return false;	// not here
		if(isset(self::$dyn_keys2funcs[$key]['val'])) return self::$dyn_keys2funcs[$key]['val'];	// cached
		$value = self::$func();
		if(!self::is_allowed_value($key,$type)) {	// make sure that it conforms
			// tell someone it failed
			$msg = self::DYN_CTL_TITLE . __CLASS__ . ': Failed allowed type match for key - ' . $key;
			self::addDebugMsg($msg);
			$value = false;
			} // if
		// save the value for next call is this session
		self::$dyn_keys2funcs[$key]['val'] = $value;
		return $value;	// got it
		} // get_dyn_value_by_key()

// static methods that return the required value
// the ideal being that returned values change dependant on the user.or role or purpose (only selecting user here)
// returned values are often returned from some external source.

	protected static function get_language() {
		if(self::$user == 'bob') return 'en-GB';
		return 'en-AU';
		} // get_language()

	protected static function get_char_set() {
		if(self::$user == 'bob') return 'ASCII';
		return 'UTF-8';
		} // get_char_set()

	protected static function get_debug() {
		if(self::$user) return 'true';	// not boolean true
		return 'false';	// not boolean false
		} // get_debug()

} // Cexample_dyn_cntl_base
