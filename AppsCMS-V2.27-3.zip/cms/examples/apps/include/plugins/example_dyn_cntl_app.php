<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_dyn_cntl_app.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Cexample_dyn_cntl_app_plugin
 *
 * Provides an example plugin for dynamic control of settings
 *
 * @author robert0609
 */

class Cexample_dyn_cntl_app_plugin extends Cexample_dyn_cntl_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'example_dyn_cntl_app';

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		return self::is_plugin_enabled(self::PLUGIN);
		} // is_enabled()

	public static function get_title() {	// get the plugin title
		return 'Example Local App Dynamic Control Plugin.';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The plugin (' . self::PLUGIN . ') description. An example plugin for dynamic control control and configuration.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "EXAMPLE_APP_DYN_CNTL_PLUGIN",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Use Example App Dynamic Control Local Plugin.",
				'cms_config_description' => "True = use plugin. False = not used.",
				),	// row data
			);
		} // get_sql_install_data()

	// functions for dynamic control plugins
	public static function is_dynamic_controller() {	// this must be in the top class
		if(!self::is_enabled()) return false;
		if(self::is_debug()) return true;	// I am a dynamic control plugin
		return false;	// I'm only an example
		} // is_dynamic_controller()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Cexample_dyn_cntl_app_plugin
