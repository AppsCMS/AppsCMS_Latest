<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_app_extend.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Cexample_app_extend_plugin
 *
 * Provides an example plugin for extend applications control
 *
 * @author robert0609
 */

class Cexample_app_extend_plugin extends Ccms_plugin_base {

	const PLUGIN = 'example_app_extend';
	const APP_NAME = 'exmple_app';

	function __construct() {
		self::is_enabled();
		parent::__construct();
		self::apps_ext_init();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(!self::is_plugin_enabled(self::PLUGIN)) {
			if(Ccms_auth::is_admin_user()) self::addMsg(self::PLUGIN . ' plugin is disabled.','warning');
			return false;
			} // if
		return true;	// parent::is_enabled();
		} // is_enabled()

// static methods
	// apps extension methods
	private static function apps_ext_init() {	// just for uniformity
		// setup app extension data
		// nothing todo, just return
		} // apps_ext_init()

	protected static function read_apps_extend_settings_ini() {
		// the return value is mainly used for config searchs
		self::apps_ext_init();
		return array(	// must be in the same order as the idx= param
			self::$config_ext,
			self::$config_ext2,
			);
		} // read_apps_extend_settings_ini()

	protected static function read_apps_extend_comments_ini() {
		// the return value is mainly used for config searchs
		self::apps_ext_init();
		return array(	// must be in the same order as the idx= param
			self::$config_ext_control,
			self::$config_ext2_control,
			);
		} // read_apps_extend_comments_ini()

	public static function get_admin_uris() {	// refer to index.php?cms_action=cms_manual#AppsExtendPlugin
		return array(
			0 => array(
				'text' => 'Apps Presets',
				'uri' => 'Cexample_app_extend_plugin::get_apps_extend_settings()',
				'title' => 'Setup application presets on example.',
				'app_name' => self::APP_NAME,
				'no_body' => true,	// optional, set true if the uri does not provide its own page body.
			)
		);
		} // get_admin_uris()

	public static function get_apps_extend_settings() {
		// typically uses the Ccms_edit class
		return true;
		} // get_apps_extend_settings()

	public static function get_title() {	// get the plugin title
		return 'Example Apps Extend';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The Example Application Extension plugin (' . self::PLUGIN . ') is used to add code to Admin menus and Ccms_base class method replacements.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			 array(
			 	'cms_config_key' => "example_CONTROL",	// gets prefixed with the PL_PluginName_ in uppercase
			 	'cms_config_value' => "true",
			 	'cms_config_allowed_values' => "true:false",
			 	'cms_config_name' => "Use example Control.",
			 	'cms_config_description' => "True = use example control plugin. False = turn off control.",
			 	),	// row data
			);
		} // get_sql_install_data()

// dynamic methods

} // Cexample_app_extend_plugin
