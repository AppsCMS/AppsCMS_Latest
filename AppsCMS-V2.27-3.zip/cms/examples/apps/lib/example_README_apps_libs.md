Applications Management System Library for PHP (AppsCMS) - Example README_apps_libs.
=======================================================================
see Licence in cms/LICENCE.txt
<!-- SVN Build: $Id: example_README_apps_libs.md 1961 2021-01-25 10:09:54Z robert0609 $ -->

3rd Party Libraries used by Applications.
-----------------------------------------

"apps/lib/" is a convienient directory to place the 3rd party libraries used by the applications.


.EOF.
