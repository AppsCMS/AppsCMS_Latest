<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: example_apps_cron.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure (recomended)
define('CRON_MODE',		true);	// tell configure (recomended)

// include the AppsCMS configuration.
if(file_exists('cms/include/cms_configure.php')) require_once 'cms/include/cms_configure.php';
else if(file_exists('../../../cms/include/cms_configure.php')) require_once '../../../cms/include/cms_configure.php';
else {
	echo "ERROR: Cannot find cms/include/cms_configure.php";
	exit(-1);
	} // else

require_once CMS_FS_INCLUDES_DIR . 'cms_auto_class_loader.php';
// add CRON PHP code.

// direct print out not recommended
echo 'Howdy !!' . PHP_EOL;	// direct print out will not be displayed (maybe emailed to user)

// e.g. logging results
$msg = 'CRON done.';
$level = 'info';	// optional, could be any level (e.g. info, success, debug, warn, error (default) )
Ccms::log_msg($msg,$level);	// saves to log

exit(0);

// eof
