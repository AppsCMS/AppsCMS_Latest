<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_index.php 2039 2021-04-07 01:49:53Z robert0609 $
 */

require_once 'include/cms_top.php';

switch(Ccms::$cms_action) {
case 'cms_login':
	if($submit = Ccms::get_or_post('submit')) {
		if($submit == 'cancel') {
			Ccms::$action = '';
			if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
			header('Location: ' . (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL));
			exit(0);
			} // if
		} // if
	Ccms_auth::login_user();
	if ((INI_LOGIN_VIA_HOMEPAGE_BOOL) && (!Ccms_auth::is_user_logged_in())) {
		// special case see login CAUTION in install settings
		header('Location: ' . (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL));
		exit(0);
		} // if
	if((Ccms_auth::is_login_allowed()) && (!Ccms_auth::is_user_logged_in())) {
		$cms_body_id = Ccms::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_login_page > 0 AND cms_body_enabled > 0");
		if((int)$cms_body_id > 0) {	// have a login page
			$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . Ccms::get_body_uri($cms_body_id);
			header('Location: ' . $url);
			exit(0);
			} // if
		} // if
	if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
	break;
case 'cms_eula':
	if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
	Ccms_auth::check_eula_form();	// will logout if dont agree
	break;
case 'set_password':
	if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
	Ccms_auth::set_password();
	break;
case 'cms_about':
	if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
	break;
case 'cms_manual':
	if(INI_ALLOW_ABOUT_MANUAL_LINKS_BOOL) break;
	if(!Ccms_auth::is_user_logged_in()) {
		if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	break;
case 'cms_rebuild_setup':
	if(Ccms_auth::is_admin_user()) {
		define('REBUILD_MODE',true);
		Ccms::backup_settings_configs();
		if((Ccms::do_cms_warnings(true)) &&
			(Ccms::do_cms_cli_warnings(true)) &&
			(Ccms::$cDBcms->checkDBversion(true))) { // rebuild setup
			Ccms::backupOnSave();
			Ccms::addMsg('Setup rebuild complete.','success');
			} // if
		else Ccms::addMsg('Failed to rebuild setup.','error');
		} // if
	else Ccms::addMsg('Must be an administrator to rebuild setup.','error');
	if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
	$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
	if(!headers_sent()) {
		Ccms::saveMsgs();
		header('Location: ' . $url);
		} // if
	else {
		echo Ccms::getMsgs();
		echo PHP_EOL . '<br><a href="' . $url . '"><b>Click to return.</b>  </a>';
		} // else
	exit (0);
	break;
case 'cms_log_view':
	if(!Ccms_auth::is_admin_user()) {
		Ccms::addMsg('Must be an administrator to view logs.','error');
		Ccms::saveMsgs();
		if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	break;
case 'cms_browse_sessions':
	if(!Ccms_auth::is_admin_user()) {
		Ccms::addMsg('Must be an administrator to browse sessions.','error');
		Ccms::saveMsgs();
		if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	break;
case 'cms_users_stats':
	if(!Ccms_auth::is_admin_user()) {
		Ccms::addMsg('Must be an administrator to browse user statics.','error');
		Ccms::saveMsgs();
		if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	break;
case 'apps_extend':
	$idx = Ccms::get_or_post('idx');
	if(($idx !== false) && (is_numeric($idx))) {
		$app_admin_uris = Ccms::get_apps_extend_static_func('get_admin_uris');
		$i = (int)$idx - 1;
		if((!is_null($app_admin_uris)) &&
			(isset($app_admin_uris[$i]['uri']))) {
			if((isset($app_admin_uris[$i]['no_body'])) &&
				($app_admin_uris[$i]['no_body'])) {
				Ccms::$action = false;	// has no body
				unset($_SESSION['cms_action']);
				$uri = $app_admin_uris[$i]['uri'];
				if($callback = Ccms::get_inc_method_callback ($uri)) {
					call_user_func($callback);	// may not return if successful
					} // if
				$url = (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER']:(Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php');
				header('Location: ' . $url);
				exit (0);
				} // if
			} // if
		} // if
	break;
case 'app_extend':
	$idx = Ccms::get_or_post('idx');
	$app_name = Ccms::get_or_post('app_name');
	if((!empty($app_name)) && ($idx !== false) && (is_numeric($idx))) {
		$class = 'C' . $app_name . '_app_extend_plugin';
		if(!$pl_a_e = Ccms_autoloader::find_plugin($class)) break;
		if(!method_exists($class,'get_admin_uris')) break;
		$aC = new $class();
		$app_admin_uris = $class::get_admin_uris();
		unset($aC);	// clean up
		if(empty($app_admin_uris)) break;
		$i = (int)$idx - 1;
		if((isset($app_admin_uris[$i]['no_body'])) &&
			($app_admin_uris[$i]['no_body'])) {
			Ccms::$action = false;	// has no body
			unset($_SESSION['cms_action']);
			$uri = $app_admin_uris[$i]['uri'];
			if($callback = Ccms::get_inc_method_callback ($uri)) {
				call_user_func($callback);	// may not return if successful
				} // if
			$url = (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER']:(Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php');
			header('Location: ' . $url);
			exit (0);
			} // if
		} // if
	break;
default:
	break;
	} // switch

switch(Ccms::$action) {
case 'login':
	if((!INI_LOGIN_TRANSLATE2CMS_BOOL) &&
		(!empty(Ccms::$body_id))) {
		break;	// an app takes care of it
		} // if
	if($submit = Ccms::get_or_post('submit')) {
		if($submit == 'cancel') {
			Ccms::$action = '';
			if(isset($_SESSION['action'])) unset($_SESSION['action']);
			header('Location: ' . (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL));
			exit(0);
			} // if
		} // if
	if(isset($_SESSION['action'])) unset($_SESSION['action']);
	Ccms_auth::login_user();
	if ((INI_LOGIN_VIA_HOMEPAGE_BOOL) && (!Ccms_auth::is_user_logged_in())) {
		// special case see login CAUTION in install settings
		header('Location: ' . (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL));
		exit(0);
		} // if
	if((Ccms_auth::is_login_allowed()) && (!Ccms_auth::is_user_logged_in())) {
		$cms_body_id = Ccms::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_login_page > 0 AND cms_body_enabled > 0");
		if((int)$cms_body_id > 0) {	// have a login page
			$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . Ccms::get_body_uri($cms_body_id);
			header('Location: ' . $url);
			exit(0);
			} // if
		} // if
	break;
case 'eula':
	if((!INI_EULA_TRANSLATE2CMS_BOOL) &&
		(!empty(Ccms::$body_id))) {
		break;	// an app takes care of it
		} // if
	if(isset($_SESSION['action'])) unset($_SESSION['action']);
	Ccms_auth::check_eula_form();	// will logout if dont agree
	break;
//case 'set_password':
//	if(isset($_SESSION['action'])) unset($_SESSION['action']);
//	Ccms_auth::set_password();
//	break;
case 'apps_manual':
	if(INI_ALLOW_ABOUT_MANUAL_LINKS_BOOL) break;
	if(!Ccms_auth::is_user_logged_in()) {
		if(isset($_SESSION['action'])) unset($_SESSION['action']);
		$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
		header('Location: ' . $url);
		exit (0);
		} // if
	break;
default:
	break;
	} // switch

Ccms::output_page_headers();
echo '<html dir="ltr"' . (preg_match('/^UTF/i',INI_CHAR_SET) ? ' lang="' . INI_LANGUAGE_CODE . '"':'') . '>' . PHP_EOL;
Ccms::page_start_comment(__FILE__);
Ccms::output_head();
if(Ccms::is_drag_drop_used()) {
	echo '	<body ondragover="javascript:cms_drag_over(event);" ondrop="javascript:cms_drop(event);">' . PHP_EOL;
	} // if
else echo '	<body>' . PHP_EOL;

?>
		<div id="preloaded"></div>
<?php
	if((Ccms::$body_full_view) ||
		(isset(Ccms::$page_info['body']['body_full_view']) && (Ccms::$page_info['body']['body_full_view'] > 0))) {
		include CMS_FS_INCLUDES_DIR . 'cms_page_body.php';
		}// if
	else { // normal view
?>

<?php if(Ccms::$block_html) { ?>
		<!--Block Mode-->
		<div id="cms_container">
<?php		Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_header.php',true,CMS_C_CUSTOM_HEADER_CACHED); ?>
<?php		Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_left_column.php'); ?>
<?php		Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_nav_bar.php'); ?>
			<script type="text/javascript">
				function cms_onloadIframe(event,obj) { // here when loads initially and on every iframe reload in block style
					var link_frame = document.getElementById('<?php echo Ccms::get_link_frame_id(); ?>');
					if(link_frame)
						obj.style.height = link_frame.offsetHeight;
					} // cms_onloadIframe()
			</script>

<?php		include (CMS_FS_INCLUDES_DIR . 'cms_page_body.php'); ?>
<?php		Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_right_column.php'); ?>
<?php		Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_footer.php',true,CMS_C_CUSTOM_FOOTER_CACHED); ?>
		</div>

<?php	} else { // inline ?>
		<!--Inline Mode-->

		<table>
			<caption>The web page</caption>

<?php if(INI_HEADER_BOOL) { ?>
			<tr>
				<td>
					<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_header.php',true,CMS_C_CUSTOM_HEADER_CACHED); ?>
				</td>
			</tr>
<?php	} // if ?>
<?php if(INI_NAV_BAR_BOOL) { ?>
			<tr>
				<td>
					<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_nav_bar.php'); ?>
				</td>
			</tr>
<?php	} // if ?>
			<tr class="cms_main_body">
				<td>
					<table>
						<caption>Page body</caption>

						<tr>
<?php	if(Ccms::show_left_column()) { ?>
							<td width="<?php echo INI_LEFT_WIDTH; ?>" valign="top">
								<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_left_column.php'); ?>
							</td>
<?php		} // if ?>
							<td valign="top">
								<?php include CMS_FS_INCLUDES_DIR . 'cms_page_body.php'; ?>
							</td>
<?php	if(Ccms::show_right_column()) { ?>
							<td width="<?php echo INI_RIGHT_WIDTH; ?>" valign="top">
								<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_right_column.php'); ?>
							</td>
<?php		} // if ?>
						</tr>
					</table>
				</td>
			</tr>
<?php		if(INI_FOOTER_BOOL) { ?>
			<tr>
				<td>
				<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_footer.php',true,CMS_C_CUSTOM_FOOTER_CACHED); ?>
				</td>
			</tr>
<?php			} // if ?>
		</table>

<?php		} // else ?>

<?php	} // else (!Ccms::$body_full_view) ?>

<?php include(CMS_FS_INCLUDES_DIR . 'cms_events_start.php'); ?>

<?php Ccms::page_end_comment(__FILE__); ?>

	</body>
</html>
<?php
require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';

