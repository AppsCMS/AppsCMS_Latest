<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_auth.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of Ccms_auth_plugin
 *
 * Description of top level Authentication plugin
 * primary access file to Authentication plugins
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */

class Ccms_auth_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_auth';

	protected static $plugin_class = false;

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

	public static function auth($username,$password) {
		if(!self::is_enabled()) return false;
		$class = self::$plugin_class;
		if(!Ccms_autoloader::find_plugin($class)) return false;
		return $class::auth($username,$password);
		} // auth()

	public static function is_enabled() {	// required function, check plugin enabled
		if(self::$plugin_class !== false) return true;	// already checked

		// check it is available
		if((!self::is_plugin_enabled(self::PLUGIN)) ||
			(!defined('PL_CMS_AUTH_AUTH_ENABLE')) ||
			(!PL_CMS_AUTH_AUTH_ENABLE) ||
			(!defined('PL_CMS_AUTH_AUTH_CLASS')) ||
			(!strlen(PL_CMS_AUTH_AUTH_CLASS))) return false;

		$class = 'C' . PL_CMS_AUTH_AUTH_CLASS . '_plugin';
		if(!Ccms_autoloader::find_plugin($class)) return false;
		self::$plugin_class = $class;
		return true;
		} // is_enabled()

	public static function get_title() {	// get the plugin title
		return 'Auth';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The Auth plugin (' . self::PLUGIN . ') is an assistive plugin for external user authentication.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "AUTH_ENABLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Use External Authentication.",
				'cms_config_description' => "True = use external authentication. False = no external authentication.",
				),	// row data
			array(
				'cms_config_key' => "AUTH_CLASS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc auths
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Authentication Name.",
				'cms_config_description' => "The authentication name used for authication.<br>" .
											"This is the plugin name in the " . APPS_FS_DIR . 'plugins' . " directory.<br>" .
											'See the <a href="index.php?cms_action=cms_manual">Manual</a> for more information.',
				"cms_config_save_func" => "",
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_auth_plugin
