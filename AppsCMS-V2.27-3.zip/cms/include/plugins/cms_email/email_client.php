<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: email_client.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of email_client
 * The connector class to lib/PHPmailer
 *
 * @author robert0609
 */

// include the classes
require_once(CMS_FS_LIB_DIR . 'PHPMailer_5.2.4/class.phpmailer.php');

class Cemail_client extends Ccms_base {
	protected $html = false;
	protected $mail_id_str = '';
	protected $to = '';
	protected $to_name = '';
	protected $from = '';
	protected $from_name = '';
	protected $subject = '';
	protected $message = '';
	protected $attachments = '';

	protected $mailer = false;

	function __construct($mail_id_str = '') {
		parent::__construct();
		$this->add_headers = array();
		$this->add_params = array();
		if(!empty($mail_id_str)) $this->mail_id_str = $mail_id_str;
		else $this->mail_id_str = 'X-Mailer: PHP v' . phpversion();

//		mb_language("en");
//		mb_internal_encoding(INI_CHAR_SET);	//"ISO-8859-1");	// "UTF-8");
//		mb_detect_order("ASCII," . INI_CHAR_SET . ",UTF-8");
//		mb_http_output(INI_CHAR_SET);	//"ISO-8859-1");	// "UTF-8");
//		mb_substitute_character("none");

		$this->mailer = new PHPMailer;

		// load language
		$code = strtolower(INI_LANGUAGE_CODE);
		$this->mailer->SetLanguage($code);

		$this->mailer->XMailer = $this->mail_id_str;	// set id
		$this->mailer->IsSMTP();			// Set mailer to use SMTP
		$this->mailer->Host = 'localhost';  // Specify main and backup server
		$this->mailer->SMTPAuth = false;	// disable SMTP authentication
		$this->mailer->WordWrap = 50;		// Set word wrap to 50 characters
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	protected function stripCR($text) {	// text \n \r
		$text = str_replace("\r\n", PHP_EOL, $text);
		$text = str_replace("\n\r", PHP_EOL, $text);
		$text = str_replace(PHP_EOL, " ", $text);
		return trim($text);
		} // stripCR()

	protected function setTo($to_name,$to_email_address) {
		$this->to = $this->stripCR($to_email_address);
		$this->to_name = $this->stripCR($to_name);
		$this->mailer->AddAddress($this->to,$this->to_name);

		return true;
		} // setTo()

	protected function setFrom($from_name,$from_email_address) {
		if(empty($from_name)) $from_name = trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME));
		if(empty($from_email_address)) $from_email_address = STORE_OWNER_EMAIL_ADDRESS;

		$this->from = $this->stripCR($from_email_address);
		$this->from_name = $this->stripCR($from_name);
		$this->mailer->From = $this->from;
		$this->mailer->FromName = $this->from_name;
		return true;
		} // setFrom()

	protected function setSubject($email_subject) {
		if(strlen($email_subject) > 250) $email_subject = substr($email_subject, 0, 250);
		if ((defined('BW_DRAFT')) && (BW_DRAFT == BW_YES)) {
			$email_subject .= BW_URL_STATUS; // indicate test emails
			} // if
		$this->subject = $this->stripCR($email_subject);	// clean and copy
		$this->mailer->Subject = $this->subject;
		return true;
		} // setSubject()

	protected function setMessage($email_text) {	// must be done to set the header in the correct order

		$this->message = nl2br($email_text);
		if((PL_CMS_EMAIL_USE_HTML) && (preg_match('/<.+>/', $this->message))) {	// assume html
			$this->html = true;
			$this->mailer->Body = $this->message;
			$this->mailer->AltBody = strip_tags(preg_replace('/<style.+<\/style>/is', '',$this->message));	// plain text
			} // if
		else {
			$this->html = false;
			$this->mailer->Body = strip_tags(preg_replace('/<style.+<\/style>/is', '',$this->message));	// plain text
			} // else

		$this->mailer->IsHTML($this->html);

		return true;
		} // setMessage()

	protected function setAttachments($attached_filenames) {
		if(empty($attached_filenames)) return true;	// no attachments

		if(is_array($attached_filenames)) {
			$res = true;
			foreach($attached_filenames as $attached_filename) {
				$res &= $this->setAttachments($attached_filename);	// recurse
				} // foreach
			return $res;
			} // if

		// one filename
		if(!is_readable($attached_filenames)) return false;
		$this->mailer->AddAttachment($attached_filenames);
		return true;
		} // setAttachments()

	public function send(
			$to_name,
			$to_email_address,
			$email_subject,
			$email_text,
			$from_email_name = '',
			$from_email_address = '',
			$attached_filenames = ''
			) {

		if(!PL_CMS_EMAIL_SEND_EMAILS) return true;

		if (empty($to_email_address) || empty($email_subject) || empty($email_text)) {
			self::$cDBcms->logEvent(__CLASS__ . '->' . __FUNCTION__ . '; not all parameters provided.');
		    return false;
			} // if

		if((!$this->setMessage($email_text)) ||	// must be done to set the header in the correct order
			(!$this->setTo($to_name,$to_email_address)) ||
			(!$this->setFrom($from_email_name,$from_email_address)) ||
			(!$this->setSubject($email_subject)) ||
			(!$this->setAttachments($attached_filenames))) {
			// failed to set up
			self::$cDBcms->logEvent('Failed to setup email message.');
			self::addMsg ('Failed to setup email message.','warn');
			return false;
			} // id

		$ok = $this->mailer->Send();
		if(!empty($this->mailer->ErrorInfo)) {
			self::$cDBcms->logEvent($this->mailer->ErrorInfo);
			self::addMsg ($email_subject . ' - ' . $this->mailer->ErrorInfo,'warn');
			} // if
		return $ok;
		} // send()

} // Cemail_client


