<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: linkedin.php 2004 2021-02-28 08:53:00Z robert0609 $
 */

/**
 * Description of Linkedin sub-plugin used by the Social Media plugin
 * primary access file to this subplugin
 * access to subplugins is always via classes
 * subplugin name is the name of this file (without the extension)
 *
 * @author robert0609
 *
 * the fundamentals of this sub-plugin come from
 * "https://developer.linkedin.com/plugins"
 *
 *
 */

class Clinkedin_subplugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'linkedin';

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(!defined('PL_CMS_SOCIALMEDIA_LINKEDIN_ENABLE')) return false;
		if(!PL_CMS_SOCIALMEDIA_LINKEDIN_ENABLE) return false;
		if(strlen(PL_CMS_SOCIALMEDIA_LINKEDIN_URL) < 8) return false;
		if(Ccms::$tablet_flg) return false;
		return true;
		} // is_enabled()

	public static function generate($id,$suffix = '') {	// assume it is in an iframe
		if(!self::is_enabled()) return '';
		$text = array();
		switch(PL_CMS_SOCIALMEDIA_LINKEDIN_TYPE) {
		default:
			return '';	// nill
		case 'link':	// direct link to face book page
			if((strlen(PL_CMS_SOCIALMEDIA_LINKEDIN_LOGO_IMAGE) < 6) ||
				(!is_readable(ETC_WS_IMAGES_DIR . PL_CMS_SOCIALMEDIA_LINKEDIN_LOGO_IMAGE))) {
				if(Ccms_auth::is_group_manager()) self::addMsg ('No Linkedin logo setup.', 'warning');
				return '';
				} // if
			$text = '<a id="' . $id . $suffix . '" href="' . PL_CMS_SOCIALMEDIA_LINKEDIN_URL . '" alt="Linkedin" target="_blank">' . '<img src="' . ETC_WS_IMAGES_DIR . PL_CMS_SOCIALMEDIA_LINKEDIN_LOGO_IMAGE . '"></img>' . '</a>' . PHP_EOL;
			return $text;
			break;
		case 'share':
			$ty = ' type="IN/Share"';
			$url = ' data-url="' . PL_CMS_SOCIALMEDIA_LINKEDIN_URL . '"';
			break;
		case 'follow_company':
			$ty = ' type="IN/FollowCompany"';
			$url = ' data-url="' . PL_CMS_SOCIALMEDIA_LINKEDIN_URL . '"';
			break;
		case 'member_profile':
			$ty = ' type="IN/MemberProfile"';
			$url = ' data-url="' . PL_CMS_SOCIALMEDIA_LINKEDIN_URL . '"';
			break;
		case 'company_profile':
			$ty = ' type="IN/CompanyProfile"';
			$url = ' data-url="' . PL_CMS_SOCIALMEDIA_LINKEDIN_URL . '"';
			break;
			} // switch

		$dc = '';
		switch(PL_CMS_SOCIALMEDIA_LINKEDIN_COUNT) {
		case 'vertical':
			$dc = ' data-counter="top"';
			break;
		case 'horizontal':
			$dc = ' data-counter="right"';
			break;
		default:
			break;
			} // switch

		// Copy and paste the code below into your website
		$text[] = '<script src="//platform.linkedin.com/in.js" type="text/javascript"> lang: en-GB</script>';
		$text[] = '<script' . $ty . $url . $dc . '></script>';

		return (!empty($text) ? implode(PHP_EOL,$text) . PHP_EOL:'');
		} // generate()

	public static function get_title() {	// get the plugin title
		return 'Linkedin';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		$text = 'Linkedin - Social Media sub-plugin (' . self::PLUGIN . ') is used to provide link to Linkedin.';
		return $text;
		} // get_description()

	public static function get_sql_install_data() {
		$cfg = array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "LINKEDIN_ENABLE",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "false",	//
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Linkedin Enable.",
				'cms_config_description' => "Set true to enable Linkedin +1 operation, false to disable.<br>" .
											"NOTE: Need a Linkedin account to use this sub plugin.",
				),	// row data
			array(
				'cms_config_key' => "LINKEDIN_TYPE",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "link",	//
				'cms_config_allowed_values' => "link:share:follow_company:member_profile:company_profile",
				'cms_config_name' => "Linkedin Type.",
				'cms_config_description' => "Set the type of link you want for Linkedin.<br>" .
						"Link - a direct link to the Linkedin page. The Linkedin URL and the Linkedin Logo Image are used (Link shown in new tab/window),<br>" .
						"Share - share/post comments on your Linkedin account,<br>" .
						"Follow Company - select to follow companys Linkedin account,<br>".
						"Member Profile - select to view a members Linkedin account,<br>" .
						"Company Profile - select to view a companys Linkedin account.",
				),	// row data
			array(
				'cms_config_key' => "LINKEDIN_URL",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "",	//
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Linkedin URL.",
				'cms_config_description' => "The Linkedin URL to your Linkedin account.<br>" .
											"NOTE: This URL is used for all types. If the type is changed, ensure the URL is correct.",
				),	// row data
			array(
				'cms_config_key' => "LINKEDIN_COUNT",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "nocount",	//
				'cms_config_allowed_values' => "nocount:vertical:horizontal",
				'cms_config_name' => "Linkedin Count Mode.",
				'cms_config_description' => "nocount - no counts displayed,<br>" .
											"vertical - counts displayed above the button,<br>" .
											"horizontal - counts displayed next to the button.",
				),	// row data
			array(
				'cms_config_key' => "LINKEDIN_LOGO_IMAGE",	//
				'cms_config_value' => "",	//
				'cms_config_allowed_values' => "",	//
				'cms_config_name' => "Linkedin Logo Image.",
				'cms_config_description' => "Select the Linkedin logo image filename (stored in " . ETC_WS_IMAGES_DIR . " directory).",
				'cms_config_show_func' => "show_image",	//
				'cms_config_input_func' => "input_image",	//
				'cms_config_save_func' => "get_image",	//
				),	// row data
			);
		return $cfg;
		} // get_sql_install_data()

} // Clinkedin_subplugin

