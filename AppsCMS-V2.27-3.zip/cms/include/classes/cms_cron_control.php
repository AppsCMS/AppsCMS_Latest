<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_cron_control.php 2016 2021-03-22 07:43:00Z robert0609 $
 */

/**
 * Description of Ccms_cron_control
 *
 * @author robert0609
 */

class Ccms_crontab extends Ccms_base {	// utility class for Ccms_cron_control to access the user CRON tab
	
	protected $crontab = false;

	function __construct() {
		parent::__construct();
		$this->get_current_crontab();
		} // __construct()

	function __destruct() {
		// clean before I go home
		parent::__destruct();
		} // __destruct()

	// methods
	protected function get_current_crontab() {
		$ret = false;
		$output = false;
		$this->crontab = false;
		@exec('crontab -l 2>&1', $output, $ret);
		if($ret != 0) return false;	// nothing there
		// returned array is ok
		$this->crontab = $output;
		return true;
		} // get_current_crontab()
		
	protected function set_current_crontab() {
		$output = false; $ret = false;
		if((!INI_ALLOW_APP_CRON_JOBS_BOOL) ||
			(empty($this->crontab))) {
			exec('echo -e `crontab -r`' . PHP_EOL, $output , $ret);
			return false;
			} // if
		
		// replace current LIVE crontab for this user ONLY.
		$command = '# ' . CMS_PROJECT_SHORTNAME . ' (' . CMS_PROJECT_VERSION . ') crontab for user ' . Ccms_posix::get_current_username() . '.' . PHP_EOL;
		if(strlen(INI_CRON_SHELL) > 2) $command .= 'SHELL=' . INI_CRON_SHELL . PHP_EOL;
		if(strlen(INI_CRON_PATH) > 8) $command .= 'PATH="' . INI_CRON_PATH . '"' . PHP_EOL;
		if(strlen(INI_CRON_MAIL) > 4) $command .= 'MAILTO="' . INI_CRON_MAIL . '"' . PHP_EOL;
		$command .= implode(PHP_EOL,$this->crontab) . PHP_EOL;
		
		exec('echo -e "`crontab -r`' . PHP_EOL . $command.'" | crontab -', $output , $ret);
		if($ret != 0) return false;	// error
		return true;
		} // set_current_crontab()
		
	protected function has_cronjob($cronjob){
		if(($this->crontab) && (is_array($this->crontab))) {
			if(in_array($cronjob,$this->crontab)){
				return true;	// don't double up
				} // if
			} // if
		return false;
		} // has_cronjob()
		
	protected function delete_crontab() {
		$this->crontab = array();
		} // delete_crontab()

	protected function stop_current_crontab() {
		$output = false; $ret = false;
		exec('echo -e "`crontab -r`' . PHP_EOL, $output , $ret);
		if($ret != 0) return false;	// error / empty
		return true;
		} // stop_current_crontab()
		
	protected function append_cronjob($cronjob, $msg = false) {
		if(!Ccms_posix::is_linux()) {	// @TDOD maybe more later ??
			self::addDebugMsg('Only Linix CRON functions available.');
			return false;
			} // if
		if(fileowner(__FILE__) != Ccms_posix::posix_geteuid()) {
			self::addDebugMsg('Attempt to run user CRON functions outside shell scope (see tech manual).');
			return false;
			} // if
		if((is_string($cronjob)) && 
			(!empty($cronjob)) && 
			(!$this->has_cronjob($cronjob))) {
			if(!empty($msg)) $this->crontab[] = PHP_EOL . '# ' . $msg;
			$this->crontab[] = $cronjob;	//add job to crontab
			return true;
			} // if
		return false;
		} // append_cronjob()
		
	protected function term_crontab_jobs($timeout = 60) {
		$this->stop_current_crontab();
		$user_id = Ccms_posix::posix_geteuid();
		$force_time = time() + $timeout;
		do {
			$output = false; $ret = false;
			exec('ps -u ' . $user_id . ' | grep cron' . PHP_EOL, $output, $ret);
			$running (!empty($output) ? true:false);
			if($ret != 0) return false;	// error / empty
			if(($running) && (time() > $force_time)) {
				for($i = 0; $i < count($output); $i++) {
					list($pid,$run_run,$command) = explode($output[$i]);
					$response = false; $ret = false;
					exec('kill -TERM ' . $pid . PHP_EOL, $response, $ret);	// terminate process
					if($ret != 0) {	// wont go peacefully so really kill it
						exec('kill -SIGKILL ' . $pid . PHP_EOL, $response, $ret);
						} // if
					} // if
				} // if
			} while($running);
		return true;
		} // term_crontab_jobs()
		
	} // Ccms_crontab

class Ccms_cron_control extends Ccms_crontab {

	public static $running = false;
	
	function __construct($argv,$argc) {
 		parent::__construct();
		$arg1 = (isset($argv[1]) ? $argv[1]:false);
		switch($arg1) {
		default:
			echo "ERROR: Unknown operation." . PHP_EOL;
		case '--help':
		case '-h':
			echo $this->show_help($argv);
			break;
		case '--start':
			$this->start_cron_jobs();
			break;
		case '--stop':
			$this->stop_cron_jobs();
			break;
			} // switch
		} // __construct()

	function __destruct() {
		// clean before I go home
		parent::__destruct();
		} // __destruct()

	// methods
	protected function show_help($argv) {
		$prg = basename($argv[0]);
		$prg_exec = (preg_match('/\.php$/',$prg) ? INI_CRON_PHP_CMD . ' ':INI_CRON_SHELL_CMD . ' ') . CMS_WS_CLI_DIR . $prg;

		$text = <<< EOT

USAGE Cron Master:

  cms/cli/cms_cron_control.sh [option]
  or
  php cms/cli/cms_cron_control.php [option]

  where options are;-
    --start         start the CRON jobs,
    --stop          stop the CRON jobs (including termination of zombies).

See the technical manual for more details.
		
EOT;
		return $text . PHP_EOL;
		} // show_help()
		
	private function set_job_crontab($times,$exec, $msg = false) {
		if(!file_exists(DOCROOT_FS_BASE_DIR . $exec))
			return false;
		if(preg_match('/.*\.php$/i',$exec))	// add php in front of script
			$crontab = $times . ' cd ' . DOCROOT_FS_BASE_DIR . '; ' . INI_CRON_PHP_CMD . ' ' . $exec;
		else $crontab = $times . ' cd ' . DOCROOT_FS_BASE_DIR . '; ' . INI_CRON_SHELL_CMD . ' ' . $exec;
		if(!$this->append_cronjob($crontab,$msg)) return false;
		return true;
		} // set_job_crontab()

	protected function build_cron_run_table() {
		$this->delete_crontab();
		$jobs_cnt = 0;
		if(!INI_ALLOW_APP_CRON_JOBS_BOOL) {
			return $this->set_current_crontab();	// set empty tab
			} // if
		if(CMS_C_CRON_MASTER_ENABLED) {
			if(!$this->set_job_crontab(CMS_C_CRON_MASTER_TIMES, APPS_WS_APPS_CRON_SCRIPT, 'APPS Simple Shell CRON Job.')) {
				$this->set_job_crontab(CMS_C_CRON_MASTER_TIMES, APPS_WS_APPS_CRON_PHP, 'APPS Simple PHP CRON Job.');				
				} // if
			} // if
		// add page bodies
		$sql_query = "SELECT cms_body_id, cms_body_name, cms_body_dir, cms_body_type" .
			", cms_body_debug_only,cms_body_enabled, cms_body_crontab_enable, cms_body_crontab_time, cms_body_crontab_job" .
			" FROM  cms_bodies" .
			" WHERE cms_body_enabled > 0" .
			" AND cms_body_crontab_enable > 0" .
			(!self::is_debug() ? ', cms_body_debug_only = 0':'');
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$app_types = Ccms_DB_checks::get_apps_types_configs();
			while($body = Ccms::$cDBcms->fetch_array($result)) {
				foreach($body as $k => &$v) $$k = $v;
				if(empty($cms_body_crontab_job)) continue;
				if(empty($cms_body_crontab_time)) continue;
				if((!isset($app_types[$cms_body_type]['cron'])) ||
					(!$app_types[$cms_body_type]['cron'])) continue;
				$this->set_job_crontab($cms_body_crontab_time, APPS_WS_DIR . $cms_body_dir . '/cli/' . $cms_body_crontab_job, $cms_body_name . ' CRON Job');
				} // while
			Ccms::$cDBcms->free_result($result);
			} // if
		
		return $this->set_current_crontab();	// set tabs
		} // build_cron_run_table()
		
	protected function start_cron_jobs() {
		self::addMsg('Starting -> CRON job setup and start.','info');
		$this->build_cron_run_table();
		if(!$this->set_current_crontab()) {
			self::addMsg('Finished -> CRON job not found, not started.','warn');
			return;
			} // if
		$this->cron_run_table['status'] = 'running';
		self::addMsg('Finished -> CRON job setup and start.','success');
		} // start_cron_jobs()
		
	protected function stop_cron_jobs() {
		self::addMsg('Starting -> CRON job stop.','info');
		$this->term_crontab_jobs();
		$this->cron_run_table['status'] = 'stopped';
		self::addMsg('Finished -> CRON job stop.','success');
		} // stop_cron_jobs()
		
} // Ccms_cron_control
