<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_logger.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of logger
 *
 * @author robert0609
 */

require_once CMS_FS_CLASSES_DIR . 'cms_msgs.php';

class Ccms_logger {

	private static $m_csLogFilename = '';
	private static $m_csErrorLogFilename = '';
	private static $m_bsInUse = false;
	private static $m_ssBuffr = array();

	private static $use_microtime = true;
	public static $record_time_times = false;
	private static $last_record_time = false;

	private static $logs_done = false;

	public static $version_str = false;
	public static $is_production = null;
	public static $can_test = null;
	public static $is_debug = null;

	function __construct($log = '') {
		self::log_init($log);
		} // __construct()

	function  __destruct() {
		} // __destruct()

    public function __call($name, $arguments) {
        // Note: value of $name is case sensitive.
        if((is_array($arguments)) || (is_object($arguments))) {
			self::log_msg("Calling object method " . $name . " (" . print_r($arguments,true) . ")");
			} // if
        else self::log_msg("Calling object method " . $name . " (" . implode(', ', $arguments) . ")");
	    } // __call()

    public static function __callStatic($name, $arguments) {
        // Note: value of $name is case sensitive.
        if((is_array($arguments)) || (is_object($arguments))) {
			self::log_msg("Calling static method " . $name . " (" . print_r($arguments,true) . ")");
			} // if
        else self::log_msg("Calling static method " . $name . " (" . implode(', ', $arguments) . ")");
		} // __callStatic()

// static methods
	public static function record_event_time($msg) {
		if(!self::$record_time_times) return false;
		$diff = 0.0;
		$usecs = microtime(true);
		if(self::$last_record_time) $diff = $usecs - self::$last_record_time;
		self::$last_record_time = $usecs;
		return self::log_msg('EV (' . sprintf("%+0.4f: ",$diff) . '): ' . $msg);
		} // record_event_time()

	public static function addMsg($msg, $type = 'error') { // virtual method
		return false;
		} // addMsg()

	protected static function zip_a_file($file, $delete_orig = true) {
		if(!class_exists('ZipArchive',false)) return false;
		$zip = new ZipArchive();
		if(!$zip) return false;
		$logZip = $file . '.zip';
		if(file_exists($logZip)) {
			$zip->open($logZip);
			$zip->addFromString($file, file_get_contents($file));
			// $zip->addFile($file);
			} // if
		else {
			$zip->open($logZip, ZipArchive::CREATE);
			$zip->addFile($file);
			} // else
		$zip->close();
		Ccms_base::chmod_chown($logZip);
		if($delete_orig) @unlink($file);
		return true;
		} // zip_a_file()

	protected static function log_file_maintanence() {	// usually only called after sysadmin login
		if(self::$logs_done) return true;
		self::$logs_done = true;	// stop repeats
		// if(!Ccms_auth::is_admin_user()) return false;	//
		$path = VAR_FS_LOGS_DIR;
		$npatt = '/' . date('Ymd') . '.log' . '$/';	// todays log files
		if((defined('CMS_C_MAX_LOG_FILES')) &&
			((int)CMS_C_MAX_LOG_FILES > 0)) {
			$files = array();
			foreach(glob($path . '*.*') as $lf) {
				if(preg_match($npatt, $lf)) continue;
				if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN,$lf)) continue;
				if(!preg_match('/\.(log|log\.zip)$/', $lf)) continue;
				$ftime = filemtime($lf);
				$files[$ftime] = $lf;
				} // foreach
			krsort($files);
			$skip = 0; $cnt = 0;
			foreach($files as $ft => $lf) {
				if($skip++ < (int)CMS_C_MAX_LOG_FILES) continue;
				@unlink($lf);
				$cnt++;
				} // foreach
			if($cnt > 0) self::log_msg ('Removed ' . $cnt . ' log files.', 'info');
			} // if
		if((defined('CMS_C_COMPRESS_LOGS_ENABLE')) &&
			(CMS_C_COMPRESS_LOGS_ENABLE)) {
			$cnt = 0;
			foreach(glob($path . '*.log') as $lf) {
				if(preg_match($npatt, $lf)) continue;
				if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN,$lf)) continue;
				if(self::zip_a_file($lf)) $cnt++;	// ok zip it
				} // foreach
			if($cnt > 0) self::log_msg ('Zipped ' . $cnt . ' log files.', 'info');
			} // if
		return true;
		} // log_file_maintanence()

	private static function init_log_file($log) {
		if(!is_readable($log)) {	// create it
			$fh = Ccms_base::file_safe_wopen($log, 'w');
			if($fh) {
				Ccms_base::file_safe_wclose($fh,$log);
				if($user = Ccms_auth::get_logged_in_username())
					self::addMsg('Started new "' . basename($log) . '" by user: ' . $user . '.','info');
				} // if
			else self::addMsg('Failed to create "' . basename($log) . '".','warn');
			} // if
		} // init_log_file()

	protected static function log_init($log) {
		if(!empty($log) && (self::$m_csLogFilename == $log)) return;	// once only
		if(!empty($log)) {
			self::$m_csLogFilename = $log;
			} // if
		if(empty(self::$m_csLogFilename)) {
			Ccms_base::chkdir(VAR_FS_LOGS_DIR);
			self::$m_csLogFilename = VAR_LOG_FILE;
			self::$m_csErrorLogFilename = VAR_ERROR_LOG_FILE;
			} // if
		self::init_log_file(self::$m_csLogFilename);
		self::init_log_file(self::$m_csErrorLogFilename);
		} // log_init()

	public static function log_dump($data) {
		self::log_msg(print_r($data,true),'debug');
		}

	public static function log_exception($e) {
		self::log_msg($e->getMessage(), 'error');
		self::log_msg($e->getTraceAsString(), 'error');
		}

	protected static function get_msg_type_label($type) {
		if($type) {
			if(is_array($type)) {
				if(isset($type['type'])) {
					$label = $type['type'];
					$label = strtolower($label) . ': ';
				} // if}
				else $label = '';
				} //if
			// assume a string
			else $label = strtolower($type) . ': ';
			} // if
		else $label = '';
		return $label;
		} // get_msg_type_label()

	public static function log_msg($msg, $type = false) {
		if(empty(self::$m_csLogFilename)) return false;
		if(empty($msg)) return false;
		if (self::is_cli()) $prefix = 'CLI: ';
		else $prefix = '';
		if(self::$use_microtime) {
			$secs = microtime(true);
			$prefix .= date('Ymd-His',$secs) . sprintf(".%06d: ",($secs - floor($secs)) * 1000000);
			} // if
		else $prefix .= date('Ymd-His: ');
		$user = Ccms_auth::get_logged_in_username();
		$label = self::get_msg_type_label($type);
		$log_msg = $prefix . $user . ' - ' . $label . $msg . PHP_EOL;
		if(self::$m_bsInUse) {
			self::$m_ssBuffr[] = $log_msg;
			} // if
		else {
			self::$m_bsInUse = true;
			error_log($log_msg,3,self::$m_csLogFilename);
			$i = 0;
			while($i < count(self::$m_ssBuffr)) {
				if(strlen(self::$m_ssBuffr[$i])) {
					error_log(self::$m_ssBuffr[$i],3,self::$m_csLogFilename);
					self::$m_ssBuffr[$i] = '';
					} // if
				$i++;
				} // while
			self::$m_ssBuffr = array();	//?? multithreading
			self::$m_bsInUse = false;
			} // else
		return true;
		} // log_msg()

	public static function log_ajax_request($debug = true) {	// this method is to help debug ajax ops
		if(($debug) && (!INI_LOG_AJAX_DEBUG_BOOL)) return true;
		$text = PHP_EOL;
		if(!empty($_REQUEST)) {
			$text .= 'AJAX _REQUEST START = ' . PHP_EOL;
			foreach($_REQUEST as $k => &$v) {
				$text .= $k . ' => ' . (is_array($v) ? implode(', ', $v):$v) . PHP_EOL;
				} // foreach
			$text .= 'AJAX _REQUEST END.' . PHP_EOL;
			} // if
		if(isset($_SERVER['REQUEST_URI'])) {
			$text .= '_SERVER[REQUEST_URI] = ' . $_SERVER['REQUEST_URI'] . PHP_EOL;
			} // if
		return self::log_msg(PHP_EOL . 'AJAX RESQUEST START::: ' . PHP_EOL . $text . PHP_EOL . ':::AJAX REQUEST END' . PHP_EOL, 'debug');
		} // log_ajax_request()

	public static function log_ajax_response(&$text, $debug = true) {	// this method is to help debug ajax ops
		if(($debug) && (!INI_LOG_AJAX_DEBUG_BOOL)) return true;
		return self::log_msg(PHP_EOL . 'AJAX RESPONSE START::: ' . PHP_EOL . $text . PHP_EOL . ':::AJAX RESPONSE END' . PHP_EOL, 'debug');
		} // log_ajax_response()

	protected static function is_rebuild() {
		if((defined('REBUILD_MODE')) && (REBUILD_MODE)) return true;
		return false;
		} // is_rebuild()

	protected static function is_cli() {
		if((defined('CLI_MODE')) && (CLI_MODE)) return true;
		return false;
		} // is_cli()

// dynamic methods
	public function logEvent($msg) {	// connector method
		return self::log_msg($msg);
		} // logEvent()

} // Ccms_logger

