<?php
/*
 * Applications Management System Library Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_DB_install.php 2070 2021-04-29 03:57:55Z robert0609 $
 */

/**
 * Description of Ccms_DB_install
 *
 * @author robert0609
 *
 * @TODO add FRIEND pragma toSQLite initialization.
 *
 */

class Ccms_DB_install extends Ccms_base {

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		// clean before I go home
		parent::__destruct();
		} // __destruct()

	protected static function upgrade_config_to_v102() {
		// so far nothing to do.
		} // upgrade_config_to_v102()

	public static function clean_DB() {
		// put version updates here
		$cms_c_key_errs = array(	// cms_configs cms_config_key code errors
			'CMS_META_OWNER' => 'CMS_C_META_OWNER',
			'CMS_META_COPYRIGHT' => 'CMS_C_META_COPYRIGHT',
			'CMS_META_AUTHOR' => 'CMS_C_META_AUTHOR',
			'CMS_C_LICENSE_LINK' => 'CMS_C_LICENCE_LINK',
			);
		foreach($cms_c_key_errs as $o => $n) {
			if(($result = self::$cDBcms->query("select cms_config_id from cms_configs where cms_config_key = '" . $o ."'")) &&
				($config_chk = self::$cDBcms->fetch_array($result))) {
				if(!self::$cDBcms->query("UPDATE cms_configs SET cms_config_key = '" . $n . "' WHERE cms_config_id = " . $config_chk['cms_config_id'] . ";")) {
					self::addMsg('ERROR: Failed to update config key ' . $o . ' to ' . $n . '.');
					self::$cDBcms->logEvent('ERROR: Failed to update config key ' . $o . ' to ' . $n . '.');
					} // if
				} // if
			} // foreach

		$cms_c_keys2delete = array(
			'CMS_C_SHOW_HEADER',	// now part of INI theme
			'CMS_C_SHOW_LEFT_COLUMN',	// now part of INI theme
			'CMS_C_NAVBAR',	// now part of INI theme
			'CMS_C_SHOW_FOOTER',	// now part of INI theme
			'CMS_C_BLOCK_STYLE',	// now part of INI theme
			'PL_WYSIWYG_WYSIWYG',	// no longer used
			'CMS_C_NAVBAR_LINK_WIDTH',	// now part of INI theme
			);
		foreach($cms_c_keys2delete as $o) {
			if(self::$cDBcms->is_data_in_table('cms_configs','cms_config_key',$o)) {
				$sql_query = "DELETE FROM  cms_configs WHERE  cms_config_key = '" . $o . "'";
				self::$cDBcms->query($sql_query);
				} // if
			} // foreach

		$cms_columns2drop = array(
			'cms_users' => array('cms_user_inline_html'),
			);
		foreach($cms_columns2drop as $t => &$cols) {
			foreach($cols as $c) {
				self::$cDBcms->checkDropDBcolumn($t, $c);
				} // foreach
			} // foreach
		// exit(1);	// test
		self::upgrade_config_to_v102();
		} // clean_DB()

	public static function do_version_dir_changes() {
		self::addMsg('Updating version directory changes.','info');
		$ok = true;
		// some tidy ups from changes at V2.26-6
		$old_new_dirs = array(	// the order matters
			ETC_WS_IMAGES_DIR . 'backgrounds/' => ETC_WS_BACKGROUNDS_DIR,
			ETC_WS_IMAGES_DIR . 'icons/' => ETC_WS_ICONS_DIR,
			ETC_WS_IMAGES_DIR . 'uploads/' => ETC_WS_IMAGES_DIR,
			);
		foreach($old_new_dirs as $s => $d) {	// fix directories
			self::recurse_move(DOCROOT_FS_BASE_DIR . $s, DOCROOT_FS_BASE_DIR . $d);
			$sql = 'UPDATE cms_configs SET ' .
				'cms_config_value = REPLACE(cms_config_value,\'' . $s . '\',\'' . $d . '\');';
			$result = self::$cDBcms->query($sql);
			if(!$result) $ok = false;
			} // foreach
		// clean up extraneous double slashes - @TODO remove later
		$sql = 'UPDATE cms_configs SET ' .
			'cms_config_value = REPLACE(cms_config_value,\'' . ETC_WS_IMAGES_DIR . '/\',\'' . ETC_WS_IMAGES_DIR . '\');';
		$result = self::$cDBcms->query($sql);

		// now fix DB entries
		$db_tab_cols = array(
			'cms_bodies' => array("cms_body_icon_url", "cms_body_image_url"),
			'cms_tools' => array("cms_tool_icon_url", "cms_tool_image_url"),
			'lm_sections' => array("lm_section_image_url", "lm_section_icon_url"),
			'lm_links' => array("lm_link_image_url", "lm_link_icon_url"),
			);
		foreach($db_tab_cols as $tab => &$cols) {
			foreach($cols as $col) {
				foreach($old_new_dirs as $s => $d) {	// fix directories in DB
					$sql = 'UPDATE ' . $tab . ' SET ' .
						$col . ' = REPLACE(' . $col . ',\'' . $s . '\',\'' . $d . '\');';
					$result = self::$cDBcms->query($sql);
					if(!$result) $ok = false;
					} // foreach
				// clean up extraneous double slashes - @TODO remove later
				$sql = 'UPDATE ' . $tab . ' SET ' .
					$col . ' = REPLACE(' . $col . ',\'' . ETC_WS_IMAGES_DIR . '/\',\'' . ETC_WS_IMAGES_DIR . '\');';
				$result = self::$cDBcms->query($sql);
				} // foreach
			} // foreach
		return $ok;
		} // do_version_dir_changes()

	public static function rebuild_from_settings() {
		self::addMsg('Checking installation settings.','info');

		self::do_version_dir_changes();

		$settings = Ccms::read_cms_ini_settings();
		Ccms::save_cms_ini_settings($settings,true);

		$app_settings = Ccms_apps::read_apps_ini_settings();
		Ccms_apps::save_apps_ini_settings($app_settings,true);

		// define any new values
		Ccms::define_install_settings(true);
		Ccms_apps::get_settings(true);

		// redo plugins
		$plugins = Ccms::get_cms_config_value('CMS_C_ENABLED_PLUGINS');
		Ccms::do_plugin_installs($plugins, true);

		self::addMsg('Rebuild theme.','info');

		Ccms::build_css_stylesheets();
		Ccms_content_cache::reset_caches();
		Ccms_gotcha_plugin::reset_cache();
		Ccms_proxy::clear_signats();
		Ccms_minify_plugin::reset_cache();

		return true;
		} // rebuild_from_settings()

	public function &get_installDBscriptsSQLite() {
		$uid = 1;$gid = 1;$cid = 1;$pid = 1;
		$install_scripts = array(	// multi tables, REMEMBER SQLITE DOES NOT HAVE THE SAME SQL SUITE AS MYSQL
									//	(use $this->convertSyntaxSQLite2MySQL() and $this->convertSyntaxMySQL2SQLite())
			'cms_users' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'id' => 'cms_user_id',	// row id column (optional)
				'asc' => 'cms_user_name',	// ASC sort column (optional)
				'columns' => array(
					"cms_user_id" => "INTEGER PRIMARY KEY",			// the row id
					"cms_user_added" => "DATETIME",	// date and time the row was added
					"cms_user_updated" => "DATETIME DEFAULT 0",	// date and time the row was updated
					"cms_user_name" => "VARCHAR(128) NOT NULL ON CONFLICT FAIL",						// the user name
					"cms_user_password_md5" => "VARCHAR(40) NOT NULL",				// the md5ed password
					"cms_user_admin" => "BOOLEAN DEFAULT 0",			// the administrator rights enabled or disabled
					"cms_user_group_ids" => "VARCHAR(128) DEFAULT '0'",		// the user groups
					"cms_user_enabled" => "BOOLEAN DEFAULT 1",		// the user enabled or disabled
					"cms_user_auth_ldap" => "BOOLEAN DEFAULT 0",	// false = local auth, true = try remote by ldap (needs ldap setup)
					"cms_user_email" => "TEXT DEFAULT ''",			// the user email
					"cms_user_mobile" => "TEXT DEFAULT ''",			// the user mobile phone number
					"cms_user_comments" => "TEXT DEFAULT ''",		// the comments
					),
				'data' => array(	// in the same order as the columns
					array($uid++,
						"DATETIME('NOW')",
						"DATETIME('NOW')",
						"'" . CMS_DEFAULT_ADMIN . "'",
						"'" . CMS_DEFAULT_PASSWORD . "'",
						"1", "0", "1", "0", "''", "''","''"),	// row data
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_cms_users" => "CREATE TRIGGER InsertTrigger_cms_users AFTER INSERT ON cms_users" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_users SET cms_user_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_cms_users" => "CREATE TRIGGER UpdateTrigger_cms_users AFTER UPDATE ON cms_users" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_users SET cms_user_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				'delete_columns' => array(
					"cms_user_eula_time","cms_user_cookie_time",
					"cms_user_login_count","cms_user_last_login","cms_user_last_logoff",
					),
				),

			'cms_groups' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'id' => 'cms_group_id',	// row id column (optional)
				'asc' => 'cms_group_order,cms_group_name',	// ASC sort column (optional)
				'columns' => array(
					"cms_group_id" => "INTEGER PRIMARY KEY AUTOINCREMENT",	// the row id
					"cms_group_added" => "DATETIME",		// date and time the row was added
					"cms_group_updated" => "DATETIME DEFAULT 0",		// date and time the row was updated
					"cms_group_name" => "VARCHAR(128) NOT NULL ON CONFLICT FAIL",		// the group name
					"cms_group_description" => "TEXT DEFAULT ''",
					"cms_group_admin" => "BOOLEAN DEFAULT 0",			// the administrator right enabled or disabled
					"cms_group_user_ids" => "VARCHAR(128) DEFAULT '0'",		// the group user ids in a comma separated string (0 = everyone)
					"cms_group_admin_ids" => "VARCHAR(128) DEFAULT '0'",	// the group admin ids in a comma separated string (0 = none)
					"cms_group_order" => "INTEGER DEFAULT 0",	// sort order
					"cms_group_enabled" => "BOOLEAN DEFAULT 1",		// the group enabled or disabled
					"cms_group_comments" => "TEXT DEFAULT ''",		// the comments
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_cms_groups" => "CREATE TRIGGER InsertTrigger_cms_groups AFTER INSERT ON cms_groups" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_groups SET cms_group_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_cms_groups" => "CREATE TRIGGER UpdateTrigger_cms_groups AFTER UPDATE ON cms_groups" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_groups SET cms_group_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				'data' => array(	// in the same order as the columns
					array( $gid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'Admin'",	// cms_group_name
						"'Administrators to view and manage all pages.'",	// cms_group_description
						"'1'",	// cms_group_admin
						"'1'",	// cms_group_user_ids
						"'0'",	// cms_group_admin_ids
						"'100'",	// cms_group_order
						"'1'",	// cms_group_enabled
						"''",	// the comments
						),
					array( $gid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'Private'",	// cms_group_name
						"'Private pages viewed by selected logged in users only.'",	// cms_group_description
						"'0'",	// cms_group_admin
						"'1'",	// cms_group_user_ids
						"'0'",	// cms_group_admin_ids
						"'200'",	// cms_group_order
						"'1'",	// cms_group_enabled
						"''",	// the comments
						),
					array( $gid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'Public'",	// cms_group_name
						"'Public pages viewed by all.'",	// cms_group_description
						"'0'",	// cms_group_admin
						"'0'",	// cms_group_user_ids
						"'0'",	// cms_group_admin_ids
						"'300'",	// cms_group_order
						"'1'",	// cms_group_enabled
						"''",	// the comments
						),
					),
				),

			'cms_bodies' => array(	// table name
				'drop' => 'false',	// dont redo on table reload
				'id' => 'cms_body_id',	// row id column (optional)
				'asc' => 'cms_body_order,cms_body_name',	// ASC sort column (optional)
				'columns' => array(
					"cms_body_id" => "INTEGER PRIMARY KEY AUTOINCREMENT",	// the row id
					"cms_body_added" => "DATETIME",	// date and time the row was added
					"cms_body_updated" => "DATETIME DEFAULT 0",	// date and time the row was updated
					"cms_body_group_ids" => "VARCHAR(128) DEFAULT '0'",	// display group ids
					"cms_body_order" => "INTEGER DEFAULT 0",	// sort order
					"cms_body_default" => "BOOLEAN DEFAULT 0",
					"cms_body_enabled" => "BOOLEAN DEFAULT 1",
					"cms_body_file" => "VARCHAR(128) DEFAULT ''",	// body filename
					"cms_body_name" => "VARCHAR(128) DEFAULT ''",
					"cms_body_title" => "VARCHAR(128) DEFAULT ''",
					"cms_body_meta_description" => "TEXT DEFAULT ''",
					"cms_body_meta_keywords" => "TEXT DEFAULT ''",
					"cms_body_cached" => "BOOLEAN DEFAULT 0",
					"cms_body_ssl" => "BOOLEAN DEFAULT 0",
					"cms_body_full_view" => "BOOLEAN DEFAULT 0",
					"cms_body_icon_url" => "TEXT DEFAULT ''",	// an icon or small logo usually on the navbar
					"cms_body_image_url" => "TEXT DEFAULT ''",	// an image for this body
					"cms_body_terms_url" => "TEXT DEFAULT ''",	// a terms and conditions URL or include filename
					"cms_body_acknowledgment_url" => "TEXT DEFAULT ''",	// a acknowledge URL or include filename
					"cms_body_licence_url" => "TEXT DEFAULT ''",	// a licence URL or include filename
					"cms_body_debug_only" => "BOOLEAN DEFAULT 0",	// true  = only shown in debug mode
					"cms_body_default_msgs" => "BOOLEAN DEFAULT 1",	// true  = show messages normally, false = don't show messages (page code does it)
					"cms_body_login_page" => "BOOLEAN DEFAULT 0",	// true  = use this page for login form, false = uses standard login page
					"cms_body_login_required" => "BOOLEAN DEFAULT 0",	// true  = must be logged in to use this page, false = login not required
					"cms_body_description" => "TEXT DEFAULT ''",	// a page/app description, can be short text description (Note: newlines are used to encapsulate paragraphs), an include file or a method (e.g. class::method called as class::method(body_id,name)
					"cms_body_type" => "INT DEFAULT 0",				// the appication type
					"cms_body_dir" => "VARCHAR(128) DEFAULT ''",	// the appication directory name under the apps/ directory
					"cms_body_release_notes_url" => "TEXT DEFAULT ''",	// a release notes URL or include filename
					"cms_body_readme_url" => "TEXT DEFAULT ''",	// a readme URL or include filename
					"cms_body_installed" => "BOOLEAN DEFAULT 0",	// true = an installed application, should not changed/edited
					"cms_body_crontab_enable" => "BOOLEAN DEFAULT 0",	// the cronjob enable
					"cms_body_crontab_time" => "VARCHAR(32) DEFAULT ''",	// the crontab time string
					"cms_body_crontab_job" => "VARCHAR(256) DEFAULT ''",	// the cronjob command
					"cms_body_version" => "VARCHAR(32) DEFAULT ''",	// the app version
					"cms_body_H1" => "TEXT DEFAULT ''",
					"cms_body_H1_title" => "TEXT DEFAULT ''",
					"cms_body_purpose" => "TEXT DEFAULT ''",	// the app purpose
					"cms_body_info1" => "TEXT DEFAULT ''",	// the app info 1
					"cms_body_info2" => "TEXT DEFAULT ''",	// the app info 2
					"cms_body_terms_upfirst" => "BOOLEAN DEFAULT 0",	// show the app license of first use (usually with an agree button)
					"cms_body_comments" => "TEXT DEFAULT ''",		// the comments
					"cms_body_package_excludes" => "TEXT DEFAULT ''",		// package exclusions
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_cms_bodies" => "CREATE TRIGGER InsertTrigger_cms_bodies AFTER INSERT ON cms_bodies" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_bodies SET cms_body_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_cms_bodies" => "CREATE TRIGGER UpdateTrigger_cms_bodies AFTER UPDATE ON cms_bodies" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_bodies SET cms_body_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				),

			'lm_sections' => array(	// table name
				'drop' => 'false',	// dont redo on table reload
				'id' => 'lm_section_id',	// row id column (optional)
				'asc' => 'lm_section_order,lm_section_name',	// ASC sort column (optional)
				'columns' => array(
					"lm_section_id" => "INTEGER PRIMARY KEY",	// the row id
					"lm_section_added" => "DATETIME",	// date and time the row was added
					"lm_section_updated" => "DATETIME DEFAULT 0",	// date and time the row was updated
					"lm_section_group_ids" => "VARCHAR(128) DEFAULT '0'",	// display group ids
					"lm_section_order" => "INTEGER DEFAULT 0",	// sort order
					"lm_section_parent_id" => "INTEGER DEFAULT 0",	// section parent section id
					"lm_section_enabled" => "BOOLEAN DEFAULT 1",
					"lm_section_name" => "VARCHAR(128) DEFAULT ''",
					"lm_section_description" => "TEXT DEFAULT ''",
					"lm_section_title" => "VARCHAR(128) DEFAULT ''",
					"lm_section_image_url" => "TEXT DEFAULT ''",
					"lm_section_icon_url" => "TEXT DEFAULT ''",
					"lm_section_columns" => "INTEGER DEFAULT 6",	// columns acroos the page
					"lm_section_comments" => "TEXT DEFAULT ''",		// the comments
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_lm_sections" => "CREATE TRIGGER InsertTrigger_lm_sections AFTER INSERT ON lm_sections" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE lm_sections SET lm_section_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_lm_sections" => "CREATE TRIGGER UpdateTrigger_lm_sections AFTER UPDATE ON lm_sections" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE lm_sections SET lm_section_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				),

			'lm_links' => array(	// table name
				'drop' => 'false',	// dont redo on table reload
				'id' => 'lm_link_id',	// row id column (optional)
				'asc' => 'lm_link_order,lm_link_name',	// ASC sort column (optional)
				'columns' => array(
					"lm_link_id" => "INTEGER PRIMARY KEY",
					"lm_link_added" => "DATETIME",	// date and time the row was added
					"lm_link_updated" => "DATETIME DEFAULT 0",	// date and time the row was updated
					"lm_link_name" => "VARCHAR(128)  DEFAULT ''",
					"lm_link_section_id" => "INTEGER DEFAULT 0",	// display section ids
					"lm_link_order" => "INTEGER DEFAULT 0",	// sort order
					"lm_link_enabled" => "BOOLEAN DEFAULT 1",
					"lm_link_url" => "VARCHAR(128) NOT NULL ON CONFLICT FAIL",
					"lm_link_description" => "TEXT",
					"lm_link_title" => "TEXT DEFAULT ''",
					"lm_link_image_url" => "TEXT DEFAULT ''",
					"lm_link_icon_url" => "TEXT DEFAULT ''",
					"lm_link_new_page" => "BOOLEAN DEFAULT 1",
					"lm_link_ssl" => "BOOLEAN DEFAULT 0",
					"lm_link_add_name2url" => "BOOLEAN DEFAULT 1",
					"lm_link_comments" => "TEXT DEFAULT ''",		// the comments
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_lm_links" => "CREATE TRIGGER InsertTrigger_lm_links AFTER INSERT ON lm_links" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE lm_links SET lm_link_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_lm_links" => "CREATE TRIGGER UpdateTrigger_lm_links AFTER UPDATE ON lm_links" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE lm_links SET lm_link_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				),

			'cms_tools' => array(	// table name
				'drop' => 'false',	// dont redo on table reload
				'id' => 'cms_tool_id',	// row id column (optional)
				'asc' => 'cms_tool_order,cms_tool_name',	// ASC sort column (optional)
				'columns' => array(
					"cms_tool_id" => "INTEGER PRIMARY KEY AUTOINCREMENT",
					"cms_tool_added" => "DATETIME",	// date and time the row was added
					"cms_tool_updated" => "DATETIME DEFAULT 0",	// date and time the row was updated
					"cms_tool_name" => "VARCHAR(128)  DEFAULT ''",
					"cms_tool_group_ids" => "VARCHAR(128) DEFAULT '0'",	// display group ids
					"cms_tool_order" => "INTEGER DEFAULT 0",	// sort order
					"cms_tool_enabled" => "BOOLEAN DEFAULT 1",
					"cms_tool_url" => "VARCHAR(128) NOT NULL ON CONFLICT FAIL",
					"cms_tool_description" => "TEXT",
					"cms_tool_title" => "TEXT DEFAULT ''",
					"cms_tool_new_page" => "BOOLEAN DEFAULT 0",
					"cms_tool_ssl" => "BOOLEAN DEFAULT 0",
					"cms_tool_login_required" => "BOOLEAN DEFAULT 0",	// true  = must be logged in to use this page, false = login not required
					"cms_tool_add_name2url" => "BOOLEAN DEFAULT 1",
					"cms_tool_include" => "BOOLEAN DEFAULT 0",
					"cms_tool_icon_url" => "TEXT DEFAULT ''",	// an icon or small logo usually on the navbar
					"cms_tool_image_url" => "TEXT DEFAULT ''",	// an image for this body
					"cms_tool_terms_url" => "TEXT DEFAULT ''",	// a terms and conditions URL or include filename
					"cms_tool_acknowledgment_url" => "TEXT DEFAULT ''",	// a acknowledge URL or include filename
					"cms_tool_licence_url" => "TEXT DEFAULT ''",	// a licence URL or include filename
					"cms_tool_release_notes_url" => "TEXT DEFAULT ''",	// a release notes URL or include filename
					"cms_tool_readme_url" => "TEXT DEFAULT ''",	// a readme URL or include filename
					"cms_tool_debug_only" => "BOOLEAN DEFAULT 0",	// true  = only shown in debug mode
					"cms_tool_installed" => "BOOLEAN DEFAULT 0",	// true = an installed tool, should not changed/edited
					"cms_tool_version" => "TEXT DEFAULT ''",	// tool version
					"cms_tool_terms_upfirst" => "BOOLEAN DEFAULT 0",	// show the tool license of first use (usually with an agree button)
					"cms_tool_comments" => "TEXT DEFAULT ''",		// the comments
					"cms_tool_package_excludes" => "TEXT DEFAULT ''",		// package exclusions
					),
				'functions' => array(
					"InsertTrigger_cms_tools" => "CREATE TRIGGER InsertTrigger_cms_tools AFTER INSERT ON cms_tools" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_tools SET cms_tool_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_cms_tools" => "CREATE TRIGGER UpdateTrigger_cms_tools AFTER UPDATE ON cms_tools" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_tools SET cms_tool_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				),

			'cms_configs' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'id' => 'cms_config_id',	// row id column (optional)
				'asc' => 'cms_config_key',	// ASC sort column (optional)
				'columns' => array(
					"cms_config_id" => "INTEGER PRIMARY KEY AUTOINCREMENT",	// the row id
					"cms_config_added" => "DATETIME",	// date and time the row was added
					"cms_config_updated" => "DATETIME DEFAULT 0",	// date and time the row was updated
					"cms_config_key" => "VARCHAR(128) UNIQUE ON CONFLICT FAIL",		// the config key translated into a define()
					"cms_config_value" => "TEXT DEFAULT ''",			// the config value translated into a define()
					"cms_config_allowed_values" => "TEXT DEFAULT ''",	// allowed values for cms_config_value separated by a colon, or empty for unrestricted
					"cms_config_name" => "TEXT DEFAULT ''",			// the config name
					"cms_config_description" => "TEXT DEFAULT ''",	// the config description
					"cms_config_show_func" => "VARCHAR(32) DEFAULT ''",	// the config Ccms_config function to show the entry, displays data
					"cms_config_input_func" => "VARCHAR(32) DEFAULT ''",	// the config Ccms_config function to input the entry, outputs form html
					"cms_config_save_func" => "VARCHAR(32) DEFAULT ''",	// the config Ccms_config function to save the entry, save the data from the posted form
					"cms_config_comments" => "TEXT DEFAULT ''",		// the comments
					),	// used in code by using define('cms_config_name', 'cms_config_value');
				'key_column' => 'cms_config_key',	// used with update_row_data()
				'updateable_columns' => 'cms_config_name,cms_config_description,cms_config_allowed_values,cms_config_show_func,cms_config_input_func,cms_config_save_func',	// used with update_row_data(), comma separate list
				'functions' => array(
					"InsertTrigger_cms_configs" => "CREATE TRIGGER InsertTrigger_cms_configs AFTER INSERT ON cms_configs" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_configs SET cms_config_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_cms_configs" => "CREATE TRIGGER UpdateTrigger_cms_configs AFTER UPDATE ON cms_configs" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE cms_configs SET cms_config_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				'data' => array(	// in the same order as the columns
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_VERSION'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"''",	// invisible
						"'Invisible, DB entry for " . CMS_PROJECT_SHORTNAME . " version tracking.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CO_NAME'",	// cms_config_key
						"'My Company'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Company / Entity Name.'",
						"'Enter the company or entitity name used on the " . CMS_PROJECT_SHORTNAME . " pages.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_TITLE'",	// cms_config_key
						"'Default Settings for " . CMS_PROJECT_SHORTNAME . "'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Title.'",
						"'Enter the title used for this web site.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_FOOTER_LINK'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Custom Link'",
						"'Enter the URI link to the a customer link.<br>" .
							"Link appears on the left side of the footer, and is displayed in an iframe.<br>" .
							"An empty value defaults to include/cms/cms_disclaimer.tmpl.php.<br>" .
							"This link can be one of the page bodies.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_FOOTER_LINK_NAME'",	// cms_config_key
						"'Disclaimer'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Custom Link Name'",
						"'Enter the name for the Custom Link. An empty value turns off the Custom Link.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_FOOTER_LINK_TITLE'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Custom Link Title'",
						"'Enter the title for the Custom Link (optional).'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_WEB_SITE_ADDRESS'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Main Web Site URL'",
						"'Enter the primary web site URL for " . CMS_PROJECT_SHORTNAME . " content. Include the protocol (e.g. http://www.example.com).<br>" .
								"<span class=\"cms_msg_warning\">NOTE: This URL is also used for sitemaps links.</span>'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SUPPORT_EMAIL'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Support Email Address'",
						"'Enter the support email address for " . CMS_PROJECT_SHORTNAME . " content.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_email'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOW_LOGIN_LINK'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Login Link'",
						"'true = show login link in header, false = not shown (<b>NOTE:</b> Use URL ./login.php?user=username to login).'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SITE_STATUS'",	// cms_config_key
						"'(Draft)'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Status.'",
						"'Enter the site status. Used as a sub-text. Leave blank if not used.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EXT_URL_NEW_PAGE'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'External URLs on New Page.'",
						"'true = set external links to new page (stops possible click jacking), false = dont automatically set to new page.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOW_VISITOR_COUNTER'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Visitor Count.'",
						"'true = show " . CMS_PROJECT_SHORTNAME . " visitor count in footer, false = turn off counter.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOW_STATS'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Web Stats.'",
						"'true = show " . CMS_PROJECT_SHORTNAME . " page stats in footer, false = turn off stats.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOW_COOKIE_COUNTER'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Personal Visit Count.'",
						"'true = show personal " . CMS_PROJECT_SHORTNAME . " visit count in footer, false = turn off counter.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LOGO_IMAGE'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Logo Image.'",
						"'Select the header logo image filename (stored in " .ETC_WS_IMAGES_DIR. " directory).'",
						"'show_image'",	// cms_config_show_func
						"'input_image'",	// cms_config_input_func
						"'get_image'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SMALL_IMAGE_HEIGHT'",	// cms_config_key
						"'25'",	// cms_config_value
						"'min=10:max=50'",	// cms_config_allowed_values
						"'Small Image Height.'",
						"'Enter the height of small images and icons in pixels.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LARGE_IMAGE_HEIGHT'",	// cms_config_key
						"'150'",	// cms_config_value
						"'min=10:max=1250'",	// cms_config_allowed_values
						"'Large Image Height.'",
						"'Enter the height of large images in pixels.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_INLINE_ICONS_IMAGES_ALLOW'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Store Images and Icons Inline.'",
						"'true = save image data as inline b64 text (must have an alt value), false = turn off inline." .
							"<b>NOTE:</b> If data size exceeds the maximum inline setting, the " . CMS_PROJECT_SHORTNAME . " will attempt to save the image to a file.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_INLINE_ICONS_IMAGES_MAXSIZE'",	// cms_config_key
						"'1000'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Maximum Images and Icons Size to Save Inline.'",
						"'Sets the maximum size of the data or text to save inline (not save if larger)." .
							"<br><b>NOTE:</b> A length less than 100 is unuseable (default 1000).'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_DESCRIPTION'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Description.'",
						"'Enter a default description of the site. Used in the page head meta data. Can be overridden by page body configs.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_KEYWORDS'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Keywords.'",
						"'Enter the default keywords or short phrases separated by commas, used by search engines. Used in the page head meta data. Can be overridden by page body configs.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_OWNER'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Owner.'",
						"'Enter the web site owner. Used in the page head meta data.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_COPYRIGHT'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Copyright.'",
						"'Enter the web site copyright owner. Used in the page head meta data.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_AUTHOR'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Web Site Author.'",
						"'Enter the web site author. Used in the page head meta data.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_CONTACT'",	// cms_config_key
						"''",	// cms_config_value
						"'Meta Name:Meta Contact'",	// cms_config_allowed_values
						"'Meta Contact.'",
						"'Enter the meta contact.<br>" .
								"The value is place in the head element name and content.<br>" .
								"NOTE: These are always included. Also these are additional to meta keywords amd descriptions.'",
						"'show_grid'",	// cms_config_show_func
						"'input_grid'",	// cms_config_input_func
						"'save_grid'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_META_DEFAULT_EXTRAS'",	// cms_config_key
						"''",	// cms_config_value
						"'Meta Name:Meta Content'",	// cms_config_allowed_values
						"'Meta Default Extras.'",
						"'Enter the extra page head meta content.<br>" .
								"The values are place in the head element name and content.<br>" .
								"NOTE: These are always included. Also these are additional to meta keywords amd descriptions.'",
						"'show_grid'",	// cms_config_show_func
						"'input_grid'",	// cms_config_input_func
						"'save_grid'",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_WYSIWYG_EDITOR'",	// cms_config_key
						"'None'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'WYSIWYG HTML Editor.'",
						"'" .	// sql encapsulation
							"Select the What You See Is What You Get (WYSIWYG) editor to use.<br>" .
							"&quot;None&quot; defaults web browser text area input editor." .
						"'",	// sql encapsulation
						"''",	// cms_config_show_func
						"'input_wysiwyg'",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ENABLED_PLUGINS'",	// cms_config_key
						"'cms_contactus:cms_gotcha:cms_email:cms_media_conv:cms_minify'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Enabled Plugins.'",
						"'Select the plugins to enable. Each plugin has a separate php class file in the plugins/ directory.<br>" .
							"Standard plugins Auth, Contact Us, Email, Gotcha, Google Maps LL and Social Media plugins are part of the " . CMS_PROJECT_SHORTNAME . ".<br>" .
							"Disabled plugins remove their functionality.'",
						"'show_plugins'",	// cms_config_show_func
						"'input_plugins'",	// cms_config_input_func
						"'save_plugins'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EMAIL_ADDRESS'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Company / Entity Email Address.'",
						"'Enter the general email address for web site.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_email'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOW_CMS_ABOUT_LINK'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show " . CMS_PROJECT_SHORTNAME . " About Link.'",
						"'true = show about the " . CMS_PROJECT_SHORTNAME . " link, false = turn off " . CMS_PROJECT_SHORTNAME . " about link in footer.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USE_TITLE_TOOLTIPS'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Title Tooltips.'",
						"'true = show title attributes as tooltip bubbles, false = use the standard browser title bubble.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_HEADER'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Custom Header.'",
						"'true = use custom page header in header.html.inc, false = use standard " . CMS_PROJECT_SHORTNAME . " page header.<br>" .
								"NOTE 1: Page header is not used if page header is disabled.<br>" .
								"NOTE 2: Where a custom page header is used, the page layout defaults to inline.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_FOOTER'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Custom Footer.'",
						"'true = use custom page footer in " . PAGE_FOOTER_WS_INC . ", false = use standard " . CMS_PROJECT_SHORTNAME . " page footer.<br>" .
								"NOTE 1: Page footer is not used if page footer is disabled.<br>" .
								"NOTE 2: Where a custom page footer is used, the page layout defaults to inline.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_NAVBAR_LINKS'",	// cms_config_key
						"''",	// cms_config_value
						"'Link URI:Link Text:Link Title'",	// cms_config_allowed_values
						"'Navigation Bar Links.'",
						"'Enter the link URI and the link text into the table.<br>" .
								"The title is optional.<br>" .
								"To delete a link, leave the URI unselected.'",
						"'show_grid'",	// cms_config_show_func
						"'input_grid'",	// cms_config_input_func
						"'save_grid'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_COLOURS'",	// cms_config_key
						"''",	// cms_config_value
						"'Custom Name:Custom RGB Colour (#hex, e.g. #FFFFFF is white)'",	// cms_config_allowed_values
						"'Custom Colours.'",
						"'Enter custom colours in RGB #hex format (e.g. #ffffff is white).'",
						"'show_grid'",	// cms_config_show_func
						"'input_grid'",	// cms_config_input_func
						"'save_grid'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_RETURN2SEARCH'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Return to Search.'",
						"'true = show the return to search link at the top of the setup page, false = removes return link.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOWINNEWTAB'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Link In a New Tab.'",
						"'true = show In a New Tab in link titles and tooltips, false = turn off In a New Tab.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MAX2INC2MAIN_MENU'",	// cms_config_key
						"'4'",	// cms_config_value
						"'min=1:max=100'",	// cms_config_allowed_values
						"'Body count maximum to include Tools and Admin in left column Main Menu.'",
						"'If the left column is used and the number page bodies in the left column main menu is greater than this value," .
							" then the Tools and Admin menus are included in Main Menu as drop downs." .
							" Else the Tools and Admin menus are shown seperaely.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ALLOW_CSV_EXPORT_IMPORT'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow CSV Export and Import.'",
						"'true = Allows CSV export and import, false = no CSV operations.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_HEADER_CACHED'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Content Cache on Custom Header.'",
						"'true = cache contents of custom page header in header.html.inc, false = not cached.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CUSTOM_FOOTER_CACHED'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Content Cache on Custom Footer.'",
						"'true = cache contents of custom page footer in " . PAGE_FOOTER_WS_INC . ", false = not cached.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USER_EMAIL_REQUIRED'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'User Email Address Required.'",
						"'true = users required to provide email address, false = email address optional.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USER_MOBILE_REQUIRED'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'User Mobile Phone Number Required.'",
						"'true = users required to mobile phone number, false = mobile number optional.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ALLOW_EMAIL_LOGIN'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Email Login.'",
						"'true = allow users to login with email address instead of username (or phone number), false = login with username (or phone number) only.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_DEFAULT_CLIENT_NAME'",	// cms_config_key
						"'IP'",	// cms_config_value
						"'IP:SID'",	// cms_config_allowed_values
						"'Default Client Name.'",
						"'IP = use the client IP address (changes with client location), SID = use browser session ID (more reliable but changes frequently)." .
							"<br>NOTE: The default name is use to provide a tempory name when a user is not logged in.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_GEOLOCATE_ALLOW'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Geolocation Records.'",
						"'true = allow the location (latitude and longitude) recorded for the session (requires SSL connection), false = disables geolocation.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_GEOLOCATE_TTL'",	// cms_config_key
						"'600'",	// cms_config_value
						"'min=60:max=7200'",	// cms_config_allowed_values
						"'Geolocation Time to Live.'",
						"'Sets the number of seconds before the Geo location is refreshed. Stops repeated Share Location pop ups from browser.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MENU_ICONS_ALLOW'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Icons in Navbar and Menus.'",
						"'true = allow icons in the nav bar and menus, false = disables icons.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ADMIN_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Admin Icon.'",
						"'Select the Admin icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_TOOLS_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Tools Icon.'",
						"'Select the Tools icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LOGIN_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Login Icon.'",
						"'Select the Login icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LOGOUT_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Logout Icon.'",
						"'Select the Logout icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CHG_PASSWD_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Change Password Icon.'",
						"'Select the Change Password icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EULA_ENABLE'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'EULA Enable'",
						"'true = enable the End User Licence Agreement (EULA), false = disable.<br>" .
							"Enabled, EULA is present to the user after successfully logging in (or application first use).<br>" .
							"<b>NOTE:</b> This setting is a global setting for all EULA forms. '",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EULA_HAS_FORM'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'EULA URI Includes Form'",
						"'true = the EULA URI includes the form to save agreement. false = the EULA URI uses the " . CMS_PROJECT_SHORTNAME . " form.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EULA_LINK'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'EULA URI'",
						"'Enter the End User Licence Agreement (EULA) URI.<br>" .
							"This link contents are shown with an agree checkbox" .
							" which the user must checks before they can proceed after successfully logging in.<br>" .
							"In the &quot;" . ETC_WS_EXT_INCLUDES_DIR . "&quot; directory'",
						"''",	// cms_config_show_func
						"'input_ext_file'",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EULA_TTL'",	// cms_config_key
						"'365'",	// cms_config_value
						"'min=1:max=1000'",	// cms_config_allowed_values
						"'EULA Time to Live'",
						"'Enter the End User Licence Agreement (EULA) Time to Live (TTL) in days. This value is used to control when the user is presented with the EULA again to agree to.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_EULA_ALL'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'EULA Challenge All'",
						"'true = enable the End User Licence Agreement (EULA) to be presented to all users (logged in or not), false = disable.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_APPS_EXTEND_PLUGIN'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Apps Extend Plugin.'",
						"'Select common applications extension plugin to use. " .
											"This plugin can add an entry or entries to the Admin menu to use for use in setting all application configuration/s.<br>" .
											"and provide method substitution to the Ccms_base class.<br>" .
											"See the <a href=\"index.php?cms_action=cms_manual#AppsExtendPlugin\" target=\"_blank\">Manual Local Applications Extension Plug In</a> for more information.'",
						"''",	// cms_config_show_func
						"'input_apps_ext_plugin'",	// cms_config_input_func
						"'save_apps_ext_plugin'",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LOG_ACCESS_ENABLE'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Enable Log HTTP Access Logging'",
						"'true = log user HTTP access (similar to Apache logs), false = no access logs.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LOG_AJAX_ENABLE'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Enable Log HTTP AJAX Logging'",
						"'true = log user AJAX access (similar to Apache logs), false = no AJAX logs.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_COMPRESS_LOGS_ENABLE'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Enable Log File Compression'",
						"'true = compress previous logs, false = log compression disabled.<br>" .
							"When enabled, log compression is done automatically when a system admin logs in.<br>" .
							"ZIP is used to compress each log file.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MAX_LOG_FILES'",	// cms_config_key
						"'10'",	// cms_config_value
						"'min=1:max=1000'",	// cms_config_allowed_values
						"'Maximum Log Files'",
						"'Enter the maximum number of recent log files to keep. Entering 0 keeps all log files.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_COOKIE_POLICY_LINK'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Cookie Policy URI'",
						"'Enter the Cookie Policy URI.<br>" .
							"The file (usually HTML) shown with the other legal notices.<br>" .
							"If empty, no cookie policy is shown.<br>" .
							"The cookie policy documents are placed in the " . ETC_WS_EXT_INCLUDES_DIR . ".'",
						"''",	// cms_config_show_func
						"'input_ext_file'",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_COOKIE_POLICY_TTL'",	// cms_config_key
						"'365'",	// cms_config_value
						"'min=1:max=1000'",	// cms_config_allowed_values
						"'Cookie Policy Time to Live'",
						"'Enter the cookie policy time to live (TTL) in days. This value is used to control when the user is presented with the cookie policy again.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LOGS_DB_OPS'",	// cms_config_key
						"'none'",	// cms_config_value
						"'all:debug:none'",	// cms_config_allowed_values
						"'Enable DB Query Logging'",
						"'all = log all DB queries, debug = only log DB queries in debug mode, none = no DB query logging.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_OK_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Ok Icon.'",
						"'Select the message ok or tick icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_WRONG_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Wrong Icon.'",
						"'Select the message wrong or cross icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_REQUIRED_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Required Icon.'",
						"'Select the message required icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_WARNING_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Warning Icon.'",
						"'Select the message warning icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_SUCCESS_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Success Icon.'",
						"'Select the message success icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_INFO_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Info Icon.'",
						"'Select the message info icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_WORKING_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Working Icon.'",
						"'Select the message working icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_ERROR_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Error Icon.'",
						"'Select the message error icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_MSG_DEBUG_ICON'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Message Debug Icon.'",
						"'Select the message debug icon filename (stored in " .ETC_WS_ICONS_DIR. " directory).'",
						"'show_icon'",	// cms_config_show_func
						"'input_icon'",	// cms_config_input_func
						"'get_icon'",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ALLOW_TEXT_EDITORS'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow " . CMS_PROJECT_SHORTNAME . " pages / apps HTML/TEXT editors.'",
						"'true = allow WYSIWYGs, TEXT and HTML editing in pages / apps configuration, false = disable inbuilt HTML/TEXT editing.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_LINKS_MANAGER_ENABLE'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Links Manager on " . CMS_PROJECT_SHORTNAME . ".'",
						"'true = allow Links Manager, false = disable.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_SHOW_LINK_DESCRIPTION'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Link Description.'",
						"'true = to show descriptions, false = to NOT show.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"'get_sanitized_text'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_SHOWINNEWTAB'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Link In a New Tab.'",
						"'true = show In a New Tab in link titles and tooltips, false = turn off In a New Tab.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_FILTER_OUTPUT'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Find.'",
						"'true = Show filter dialog to filter output by finding keywords in titles, descriptions and links, false = turn off filter dialog.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_FILTER_ANDED'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Filter Logic.'",
						"'true = Find filter uses ANDed logic to find keyswords, false = Find filter uses ORed logic to find keyswords.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_FILTER_STAT'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Find.'",
						"'true = Show filter find stats at the bottom of the page, false = turn off filter stats.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_RECENT_CHANGES_ENABLED'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Enable Most Recent Changes.'",
						"'true = Enable most recent change to be displayed, false = disbale most recent chsanges.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_RECENT_CHANGES_MAX'",	// cms_config_key
						"'10'",	// cms_config_value
						"'10:20:50:100:200:500'",	// cms_config_allowed_values
						"'Maximum Recent Changes.'",
						"'Enter the maximum number of most recent changes to show.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_RECENT_CHANGES_DAYS'",	// cms_config_key
						"'14'",	// cms_config_value
						"'7:14:30:90:180:365'",	// cms_config_allowed_values
						"'Days Most Recent Change.'",
						"'Enter the number of days to show recent changes for.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_MIN_PASSWD_LEN'",	// cms_config_key
						"'4'",	// cms_config_value
						"'4:5:6:7:8:9:10'",	// cms_config_allowed_values
						"'Minimum Password Length.'",
						"'Enter the minimum length for new passwords.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_MIN_NAME_LEN'",	// cms_config_key
						"'4'",	// cms_config_value
						"'4:5:6:7:8:9:10'",	// cms_config_allowed_values
						"'Minimum Name Length.'",
						"'Enter the minimum length for new names.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_USE_LM_AS_HOME'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Links Page as Home.'",
						"'true = use the links page as the home page, false = use CMS home page.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_FILT_INC_SECT'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Include Sections in Links Filter.'",
						"'true = include section data in links filter, false = dont include.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_SHOW_SECT_CHILD_2ND'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Child Section Last.'",
						"'true = show child sections second (last) after parent links, false = show child first.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_SHOW_CONF_LINKS'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Link and Section Configure Links.'",
						"'true = show link and sections admin configure URLs, false = no configure links.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ALLOW_APPS_DIR_SHARE'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Apps Dir Share.'",
						"'true = allow bodies / applications to share a directory in " . APPS_WS_DIR . ", false = disable directory sharing.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_TERMS_LINK'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Terms and Condition URI'",
						"'Enter the Terms and Conditions URI.<br>" .
							"The file (usually HTML) shown with the other legal notices.<br>" .
							"If empty, no Terms and Conditions link is shown.<br>" .
							"The documents are usually is placed in the " . ETC_WS_EXT_INCLUDES_DIR . ".'",
						"''",	// cms_config_show_func
						"'input_ext_file'",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_LICENCE_LINK'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Licence URI'",
						"'Select the Licence URI.<br>" .
							"The file (usually HTML) shown with the other legal notices.<br>" .
							"If empty, no Licence link is shown.<br>" .
							"The documents are usually is placed in the " . ETC_WS_EXT_INCLUDES_DIR . ".'",
						"''",	// cms_config_show_func
						"'input_ext_file'",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CRON_MASTER_ENABLED'",	// cms_config_key
						"'false'",	// cms_config_value
						"'false:true'",	// cms_config_allowed_values
						"'Enable Cron Master'",
						"'true = enable the " . CMS_PROJECT_SHORTNAME . " CRON job master for engaging" .
							" the " . APPS_WS_APPS_CRON_SCRIPT .
							" or php " . APPS_WS_APPS_CRON_PHP . "<br>" .
							"See technical manual for more information.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CRON_MASTER_TIMES'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Cron Master Timing'",
						"'Enter the common applications CRON initator times for " . CMS_PROJECT_SHORTNAME . ".<br>" .
							"This timing controls the engagement of " . APPS_WS_APPS_CRON_SCRIPT . "<br>" .
							"or php " . APPS_WS_APPS_CRON_PHP . "<br>" .
							"Standard and Coupled applications have there own CRON job timing<br>" .
							" and the initiator script, settings are in the Admin -&gt; Pages / Apps configuration.<br>" .
							"See technical manual for more information.'",
						"''",	// cms_config_show_func
						"'inp_cron_times'",	// cms_config_input_func
						"'get_cron_times'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USE_METAPHONE_SEARCH'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Metaphone Search Algorithm.'",
						"'true = allow, false = disable.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USE_LEVENSHTEIN_SEARCH'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Levenshtein Search Algorithm.'",
						"'true = allow, false = disable.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USE_SIMILAR_SEARCH'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Use Similarity Search Algorithm.'",
						"'true = allow, false = disable.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_SHOW_SEARCH_METADATA'",	// cms_config_key
						"'debug'",	// cms_config_value
						"'true:debug:false'",	// cms_config_allowed_values
						"'Show Search Match Metadata.'",
						"'true = always allow, debug = only in debug mode, false = no metadata,disabled.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_APPS_MAJOR_VERSION'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Applications Major Version'",
						"'A general applcations major version. Can be used to reflect to top level version of the web applications.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_COOKIE_BANNER_POSITION'",	// cms_config_key
						"'off'",	// cms_config_value
						"'off:top:bottom'",	// cms_config_allowed_values
						"'Cookie Banner Position'",
						"'Select the cookie banner position.<br>The cookie banner is different from the cookie policy.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_COOKIE_BANNER_LINK'",	// cms_config_key
						"''",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Cookie Banner URI'",
						"'Select the Cookie Banner URI.<br>" .
							"The file (usually HTML) shown as a banner. It is usually short and usually contains a link to a further explanation.<br>" .
							"The cookie banner documents are placed in the " . ETC_WS_EXT_INCLUDES_DIR . ".'",
						"''",	// cms_config_show_func
						"'input_ext_file'",	// cms_config_input_func
						"'get_url'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_COOKIE_BANNER_TTL'",	// cms_config_key
						"'365'",	// cms_config_value
						"'min=1:max=1000'",	// cms_config_allowed_values
						"'Cookie Banner Time to Live'",
						"'Enter the cookie banner time to live (TTL) in days before the banner is shown again. This value is used to control when the user is presented with the cookie banner again.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_ALLOW_PHONE_LOGIN'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Phone Number Login.'",
						"'true = allow users to login with telephone number instead of username (or email address), false = login with username (or email address) only.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CLIENTMETA_ALLOW'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Client Metadata.'",
						"'true = allow client metadata (screen and window metrics) to sent to the session (requires SSL connection), false = disables client metadata.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_CLIENTMETA_MIN_MS'",	// cms_config_key
						"'1000'",	// cms_config_value
						"'200:500:1000:2000:5000:10000'",	// cms_config_allowed_values
						"'Client Metadata Min Update Interval.'",
						"'Select minimum interval in milliseconds between client metadata updates.<br>The client metadata updates initially and on screen resize and scroll changes.<br>This value acts a debounce and stops the server being unduely loaded.'",
						"'show_number'",	// cms_config_show_func
						"'input_number'",	// cms_config_input_func
						"'save_number'",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_BROWSCAP_ALLOW'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Allow Client Browscap Detection.'",
						"'true = allow client browscap device and browser detectors (more accurate but slower), false = disables browscap.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_BROWSCAP_URL'",	// cms_config_key
						"'http://browscap.org/stream?q=Lite_PHP_BrowsCapINI'",	// cms_config_value
						"''",	// cms_config_allowed_values
						"'Browscap INI Source URL.'",
						"'Enter the URL to download the browscap.ini from (default: http://browscap.org/stream?q=Lite_PHP_BrowsCapINI).<br><B>NOTE:</b> Using the full version will use considerable memory and slow down client browser, etc. detection.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USER2APACHE'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Pass Username to Apache.'",
						"'true = passes logged in user name to the Apache web server." .
							"false = does not pass user name to web server.<br>".
							"<b>NOTE:</b> On the Apache web server logs include <b>%{username}n</b> in the LogFormat string" .
							"in the Apache configuration file (e.g. LogFormat &quot;%h %l %{username}n %t \&quot;%r\&quot; %>s %b&quot; common).'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'CMS_C_USER2APACHE_AJAX'",	// cms_config_key
						"'false'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Pass Username to Apache on AJAX.'",
						"'true = passes logged in user name to the Apache web server for AJAX calls." .
							"false = does not pass user name to web server.<br>".
							"<b>NOTE:</b> On the Apache web server logs include <b>%{username}n</b> in the LogFormat string" .
							"in the Apache configuration file (e.g. LogFormat &quot;%h %l %{username}n %t \&quot;%r\&quot; %>s %b&quot; common).'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_SHOW_SECT_COLL_EXP_BUTTON'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Collapse and Expand Section Button.'",
						"'true = show collapse and expand section button, false = dont show.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data
					array( $cid++, "DATETIME('NOW')", "DATETIME('NOW')",
						"'LMC_SHOW_SECT_OPEN_ALL_BUTTON'",	// cms_config_key
						"'true'",	// cms_config_value
						"'true:false'",	// cms_config_allowed_values
						"'Show Open All Links in Section Button.'",
						"'true = show open all links in each section button, false = dont show.'",
						"''",	// cms_config_show_func
						"''",	// cms_config_input_func
						"''",	// cms_config_save_func
						"''",	// the comments
						),	// row data

					),
				),
			);
		return $install_scripts;
		} // get_installDBscriptsSQLite()

	public function &get_installDBscriptsMySQL() {

		$install_scripts_sqlite = $this->get_installDBscriptsSQLite();
		// now convert SQLite syntax to MySQL syntax
		$install_scripts_mysql = array();
		foreach($install_scripts_sqlite as $table => &$tab_data) {
			foreach($tab_data as $k => &$v) {
				switch($k) {
				case 'columns':
					foreach($v as $name => $def) {
						$val = $this->convertSyntaxSQLite2MySQL($def);
						if(!empty($val))
							$install_scripts_mysql[$table][$k][$name] = $val;
						} // foreach
					break;
				case 'data':
					foreach($v as $ridx => &$cols) {
						foreach($cols as $cidx => $data) {
							$val = $this->convertSyntaxSQLite2MySQL($data);
							if($val === false) {
								self::addMsg('Failed to convert SQLite: "' . $data . '".');
								exit(2);
								} // if
							$install_scripts_mysql[$table][$k][$ridx][$cidx] = $val;
							} // foreach
						} // foreach
					break;
				case 'functions':
					// not converted at the moment
					break;
				default:
					$install_scripts_mysql[$table][$k] = $v;
					break;
					} // switch
				} // foreach
			} // foreach
		return $install_scripts_mysql;
		} // get_installDBscriptsMySQL()

} // Ccms_DB_install
