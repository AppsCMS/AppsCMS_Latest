<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_reverse_proxy.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

include_once 'cms_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_reverse_proxy extends Ccms_base {

	protected $http_pro = false;
	protected $http_code = false;
	protected $http_status = false;

	protected static $parts = false;

	const PROXY_DB = "revProx.sqlite";
	const PROXY_TABLE = "uri_list";
	const PROXY_ENCD = 'revpr';
	const PROXY_ID = 'revid';
	const PROXY_SEP = 'PRL';
	private static $prDB = false;

	function __construct() {
		$mwas = ini_set('memory_limit','2048M');
		parent::__construct();
		self::$parts = self::decode_url();	// get it back
		if(empty(self::$parts)) return;
		$parts = &self::$parts;	// easier to debug
		$ch = curl_init($parts['base'] . $parts['path']);
		if(!empty($_SERVER['HTTP_USER_AGENT']))
			curl_setopt( $ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt( $ch, CURLOPT_HTTPHEADER, $this->getRequestHeaders() );
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true ); // follow redirects
		curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
		curl_setopt( $ch, CURLOPT_HEADER, true ); // include the headers in the output
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); // return output as string

		if ( strtolower($_SERVER['REQUEST_METHOD']) == 'post' ) {
			curl_setopt( $ch, CURLOPT_POST, true );
			$post_data = file_get_contents("php://input");

			if (preg_match("/^multipart/", strtolower($_SERVER['CONTENT_TYPE']))) {
				$delimiter = '-------------' . uniqid();
				$post_data = $this->build_multipart_data_files($delimiter, $_POST, $_FILES);
				curl_setopt( $ch, CURLOPT_HTTPHEADER, $this->getRequestHeaders($delimiter) );
				} // if

			curl_setopt( $ch, CURLOPT_POSTFIELDS, $post_data );
			} // if

		if(!$response = curl_exec( $ch )) {	// reverse proxy. the actual request to the backend server.
			$error = curl_error($ch);
			} //if
		$ch_info = curl_getinfo($ch);
		$header_size = $ch_info['header_size'];
		$header_text = substr($response, 0, $header_size);
		if($ch_info['size_download'] > 0)
			$html = substr($response, $header_size);	// Reminder: $html will be compressed text.
		else $html = '';
		curl_close( $ch ); // curl is done now

		$headers_arr = preg_split( '/[\r\n]{1,2}/', $header_text );
		$content_location = false;
		$compress_type = false;

		// Propagate headers to response.
		$backend_info = parse_url($parts['url']);
		$host = $_SERVER['HTTP_HOST'];
		$redir = false;
		foreach ( $headers_arr as $header ) {
			if(preg_match('/^HTTP\/[0-9]+.* /i',$header)) {	// look for status code from source
				list($this->http_pro,$this->http_code,$this->http_status) = preg_split('/[ ]+/',$header,3);
				} // if
			switch($this->http_code) {
			case '200':	// ok
				break;
			case '301':
			case '302':
			case '307':
			case '308':
				$redir = true;
				if(preg_match('/^Location:/i',$header)) {
					$location = preg_replace('/^Location:[ ]*/i','',$header);
					if(headers_sent()) {
						$html = 'Proxy has been redirected from "' . $parts['base'] . $parts['path'] . '" to "' . $location . '".';
						echo $html; // return the proxied result to the browser
						exit();
						} // if
					$src = self::get_reverse_proxy_src($location);
					header('Location: ' . $src);
					exit();
					} // if
				break;
			case '304':	// ok, nonsense code, no html
				break;
			default:
				$code_msg = self::get_url_response_str($this->http_code);
				$html = 'Proxy HTTP CODE: ' . ($code_msg ? $code_msg:'Unknown: ' . $this->http_code) . ': ' . $this->http_code;
				echo $html; // return the proxied result to the browser
				exit();
				break;
				} // switch
			if($redir) continue;

			if ( !preg_match( '/^Transfer-Encoding:/i', $header ) ) {
				if ( preg_match( '/^Location:/i', $header ) ) {
					# rewrite absolute local redirects to relative ones
					$header = str_replace($parts['url'], "/", $header);
				}
				else if ( preg_match( '/^set-cookie:/i', $header ) ) {
					# replace original domain name in Set-Cookie headers with our server's domain
					$domain_regex = $this->build_domain_regex($backend_info['host']);
					$header = preg_replace('/Domain='.$domain_regex.'/', 'Domain='.$host, $header);
					} // else if
				else if ((!$content_location) && (preg_match('/^Content-Location:/i',$header))) {
					$content_location = true;
					$header = 'Content-Location: ' . $parts['clnt_base'];
					} // else if
				else if (preg_match('/^Content-Encoding:/i',$header)) {
					$compress_type = preg_replace('/^Content-Encoding:([ ]*)/i','\1',$header);
					} // else if
				header( $header );
				} // if
			} // foreach
		if (!$content_location) {
			$content_location = true;
			$header = 'Content-Location: ' . $parts['clnt_base'];
			header( $header );
			} // if
		$this->amend_base($html,$compress_type,$parts);	// change or add base
		echo $html; // return the proxied result to the browser
		exit();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		self::close_rev_proxy_db();
		} // __destruct()

	private static function open_rev_proxy_db() {
		// return false;	// test hex type proxy url
		self::close_rev_proxy_db();
		if(empty($_SERVER['DOCUMENT_ROOT'])) return false;
		// $db_file = $_SERVER['DOCUMENT_ROOT'] . '/var/variables/' . self::PROXY_DB;
		$db_file = VAR_FS_VARIABLES_DIR . self::PROXY_DB;
		if(!self::$prDB = new SQLite3($db_file)) return false;
		// check table here
		$tab_fnd = false;
		$query = "SELECT name FROM sqlite_master WHERE type='table';";
		if($result = self::$prDB->query($query)) {
			while ($table = $result->fetchArray(SQLITE3_ASSOC)) {
				if($table['name'] == self::PROXY_TABLE) {
					$tab_fnd = true;
					break;
					} // if
				} // while
			} // if
		if(!$tab_fnd) {	// insert table
			$query = "CREATE TABLE IF NOT EXISTS " . self::PROXY_TABLE .
				"( " .
					" id INTEGER PRIMARY KEY AUTOINCREMENT," .	// proxy dest URL id
					" dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP," .	// last used
					" user VARCHAR(128) NOT NULL," .	// the client user name, seperates two users on same proxied url
					" base TEXT NOT NULL," .// dest URL
					" path TEXT DEFAULT ''," .// path/variables part of URL
					" curl_headers TEXT DEFAULT ''" .// path/variables part of URL
				" );";
			if(!self::$prDB->query($query)) return false;
			} // if
		return true;
		} // open_rev_proxy_db()

	private static function close_rev_proxy_db() {
		if(self::$prDB) {
			self::$prDB->close();
			self::$prDB = false;
			} // if
		} // close_rev_proxy_db()

	private static function encode_url($proxy_host, $url, $user, $curl_headers = false, $base_only = false) {
		$url_parts = parse_url($url);
		$base = $url_parts['scheme'] . '://' . $url_parts['host'] . (!empty($url_parts['port']) ? ':' . $url_parts['port']:'');	// . (!empty($url_parts['path']) ? $url_parts['path']:''));
		if((empty($user)) || (!self::open_rev_proxy_db())) {	// do it old way
			$gz = gzcompress($base);
			$hex = bin2hex($gz);
			return $proxy_host . 'cms/cms_proxy.php/' . self::PROXY_ENCD  .'/' . $hex . self::PROXY_SEP . '/'. ($base_only ? '':preg_replace('/^\//','',$url_parts['path']));
			} // if
		// else
		$id = 0;	// to start
		if(empty($curl_headers)) $curl_headers = '';	// make string
		else $curl_headers = serialize($curl_headers);
		$query = 'SELECT * FROM ' . self::PROXY_TABLE . ' WHERE base = \'' . rawurlencode($base) . '\' AND user = \'' . $user . '\';';
		if(($result = self::$prDB->query($query)) &&
			($entry = $result->fetchArray(SQLITE3_ASSOC))) {
			$id = $entry['id'];
			// now update db
			$query = "UPDATE " . self::PROXY_TABLE . " SET" .
				" dt = CURRENT_TIMESTAMP," .
				" base = '" . rawurlencode($base) . "'," .
				" user = '" . $user . "'," .
				" path = '" . rawurlencode($url_parts['path']) . "'," .
				" curl_headers = '" . $curl_headers . "'" .
				" WHERE id = " . (int)$id . ';';
			if(!self::$prDB->query($query)) return false;
			} // if
		else {	// new db entry
			$query = "INSERT INTO  " . self::PROXY_TABLE .
				" (dt,base,user,path,curl_headers)" .
				" VALUES" .
				"(CURRENT_TIMESTAMP,'" . rawurlencode($base) . "','" . $user . "','" . rawurlencode($url_parts['path']) . "','" . $curl_headers . "');";
			if(!self::$prDB->query($query)) return false;
			$id = self::$prDB->lastInsertRowID();
			if(!self::$prDB->query($query)) return false;
			} // else
		self::close_rev_proxy_db();
		return $proxy_host . 'cms/cms_proxy.php/' . self::PROXY_ID  .'/' . $id . self::PROXY_SEP . '/'. ($base_only ? '':preg_replace('/^[\/]+/','',$url_parts['path']));
		} // encode_url()

	private static function decode_url() {
		$parts = array( 'proxy' => '', 'path' => '', 'base' => '', 'user' => '', 'clnt_base' => '', 'curl_headers' => '');
		if(!empty($_SERVER['HTTP_REFERER'])) {
			$referer_uri = $_SERVER['HTTP_REFERER'];	// need it to become self sustaining
			$referer = parse_url($referer_uri);
			$parts['proxy'] .= $referer['scheme'] . '://' . $referer['host'] . (!empty($referer['port']) ? ':' . $referer['port']:'');
			} // if
		$request_uri = $_SERVER['REQUEST_URI'];	// need it to become self sustaining
		if(preg_match('/\/' . self::PROXY_ENCD . '\/[0-9a-fA-F]+' . self::PROXY_SEP . '\//',$request_uri)) { // redirect back to parent
			$backend_hex = preg_replace('/^.*\/' . self::PROXY_ENCD . '\/([0-9a-f]+)' . self::PROXY_SEP . '\/.*$/i','\1',$request_uri);	// got it back
			$parts['proxy'] .= preg_replace('/^(.*\/' . self::PROXY_ENCD . '\/[0-9a-f]+' . self::PROXY_SEP . '\/).*$/i','\1',$request_uri);	// got it back
			$parts['path'] = preg_replace('/^.*\/' . self::PROXY_ENCD . '\/[0-9a-f]+' . self::PROXY_SEP . '(\/.*?)$/i','\1',$request_uri);	// got it back
			if(!self::open_rev_proxy_db()) {	// do it old way
				$gz = hex2bin($backend_hex);
				$parts['base'] = gzuncompress($gz);
				$parts['clnt_base'] = preg_replace('/' . self::PROXY_SEP . '[\/]*/',self::PROXY_SEP . '/',$parts['proxy'] . $parts['path']); // entry point to this URL;
				return $parts;
				} // if
			} // if
		else if((preg_match('/' . self::PROXY_ID . '\/[0-9]+' . self::PROXY_SEP . '/',$request_uri)) && // redirect back to parent
			(self::open_rev_proxy_db())) {	// do it old way
			$id = preg_replace('/^.*' . self::PROXY_ID . '\/([0-9]+)' . self::PROXY_SEP . '.*$/','\1',$request_uri);	// got it back
			$query = 'SELECT * FROM ' . self::PROXY_TABLE . ' WHERE id = ' . (int)$id . ' LIMIT 1;';
			if(($result = self::$prDB->query($query)) &&
				($entry = $result->fetchArray(SQLITE3_ASSOC))) {
				$parts['user'] = rawurldecode($entry['user']);
				$parts['proxy'] .= preg_replace('/^(.*\/' . self::PROXY_ID . '\/' . $id . self::PROXY_SEP . '\/).*$/i','\1',$request_uri);	// got it back
				$parts['path'] = preg_replace('/^.*\/' . self::PROXY_ID . '\/' . $id . self::PROXY_SEP . '(\/.*)$/','\1',$request_uri);	// got it back
				$parts['base'] = rawurldecode($entry['base']);
				$parts['curl_headers'] = unserialize($entry['curl_headers']);
				$query = "UPDATE " . self::PROXY_TABLE . " SET path = '" . rawurlencode($parts['path']) . "' WHERE id = " . (int)$id . ';';
				self::$prDB->query($query);
				self::close_rev_proxy_db();
				$parts['clnt_base'] = preg_replace('/' . self::PROXY_SEP . '[\/]*/',self::PROXY_SEP . '/',$parts['proxy']);	// . $parts['path']); // entry point to this URL;
				return $parts;
				} // if
			} // if
		// else broken	start again
		return false;
		} // dccode_url()

	public static function get_reverse_proxy_src($sorc,$curl_headers = false, $base_only = false) {	// get forward proxy insert
		if(defined('CMS_WWW_URL')) {	// first call
			$proxy_host = ((!empty($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on')) ? CMS_SSL_URL:CMS_WWW_URL);
			} // if
		else {	// remake @TODO
			$proxy_host = '';
			} // else
		if(!empty(self::$parts['user'])) $user = self::$parts['user'];
		else {
			try {
				$user = Ccms_auth::get_user_json_name();
				}
			catch (Exception $e) {
				$user = '';
				};
			} // else
		$src = self::encode_url($proxy_host, $sorc, $user, $curl_headers, $base_only);
		return $src;
		} // get_reverse_proxy_src()

	protected function amend_base(&$html_gz,$compress_type,$parts,$conv2rel = true) {
		if(empty($html_gz)) return true;
		// e.g.
		// <head>
		//	<base href="$parts['clnt_base']">	// base href
		//	<base id="some_id" href="$parts['clnt_base']">	// alternate style
		// </head>

		// see "https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Encoding"
		switch(strtolower($compress_type)) {
		case 'gzip':
			$html = gzdecode($html_gz);
			break;
		case 'deflate':
			$html = gzinflate($html_gz);
			break;
		case 'identity':
			$html = $html_gz;
			break;
		case 'compress':
			$html = gzuncompress($html_gz);
			break;
		case 'br':	//	needs php-brotli package
			if(!function_exists('brotli_uncompress')) {
				return false;
				} // if
			$html = brotli_uncompress($html_gz);
			break;
		default:	// unknown
			$html = $html_gz;	// no compression
			} // switch
		if(!preg_match('/^\<\!DOCTYPE HTML/i',$html_gz)) {	// look for '<!DOCTYPE HTML' first line
			try {
				$html_json = json_decode($html_gz,true);
				if(!empty($html_json)) {
					if(!empty($html_json['page'])) {
						$html_json['page']['base'] = $parts['clnt_base'];
						} // if
					foreach($html_json as &$v) {

						} // foreach
					$html = json_encode($html_json);
					} // if
				}
			catch (Exception $ex) {
				file_put_contents(VAR_FS_TEMP_DIR . 'test.html',$html_gz);
				return true;
				}
			} // if
//		$dom = new DOMDocument();
//		$dom->loadHTML($html);
//		$hdx = $dom->getElementsByTagName('head');
//		$head = $hdx->item(0);

		$html_parts = preg_split('/(<head>|<\/head>)/i',$html,3);
		if(count($html_parts) == 3) {
			$head_arr = preg_split('/[\r\n]/i',$html_parts[1]);
			$new_head = PHP_EOL . '	<base href="' . $parts['clnt_base'] . '">';
			for($i = 0; $i < count($head_arr); $i++) {	// remove any existing base
				if(preg_match('/<base[ ]+(href|id)/i',$head_arr[$i])) {
					$head_arr[$i] = '';
					} // if
				if(!empty($head_arr[$i]))
					$new_head .= PHP_EOL . '	' . $head_arr[$i];
				} // for
			$new_head .= PHP_EOL;

			// clean body links
			if($conv2rel)
				$body = preg_replace('/(href|src)="\//im','\1="' . $parts['clnt_base'],$html_parts[2]);
			else
				$body = &$html_parts[2];

			// put it back together
			$html = $html_parts[0] . PHP_EOL .
				'<head>' . PHP_EOL .
					$new_head . PHP_EOL .
				'</head>' . PHP_EOL .
				$body . PHP_EOL;
			} // if

		switch(strtolower($compress_type)) {
		case 'gzip':
			$html_gz = gzencode($html);
			break;
		case 'deflate':
			$html_gz = gzdeflate($html);
			break;
		case 'identity':
			$html_gz = $html;
			break;
		case 'compress':
			$html_gz = gzcompress($html);
			break;
		case 'br':	//	needs php-brotli package
			if(!function_exists('brotli_compress')) {
				return false;
				} // if
			$html_gz = brotli_uncompress($html);
			break;
		default:	// straight text
			$html_gz = $html;
			break;
			} // switch
		return true;
		} // amend_base()

	protected function getRequestHeaders($multipart_delimiter=NULL) {
		$headers = array();
		foreach($_SERVER as $key => $value) {
			if(preg_match("/^HTTP/", $key)) { // only keep HTTP headers
				if(preg_match("/^HTTP_HOST/", $key) == 0 && // let curl set the actual host/proxy
				preg_match("/^HTTP_ORIGIN/", $key) == 0 &&
				preg_match("/^HTTP_CONTENT_LEN/", $key) == 0 && // let curl set the actual content length
				preg_match("/^HTTPS/", $key) == 0
				) {
					$key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
					if ($key)
						array_push($headers, "$key: $value");
				}
			} elseif (preg_match("/^CONTENT_TYPE/", $key)) {
				if(preg_match("/^multipart/", strtolower($value)) && $multipart_delimiter) {
					$key = "Content-Type";
					$value = "multipart/form-data; boundary=" . $multipart_delimiter;
					if ($key)
						array_push($headers, "$key: $value");
					} // if
				} // if
			} // foreach
		if((empty($multipart_delimiter)) &&
			(!empty(self::$parts['curl_headers']))) {
			if(is_array(self::$parts['curl_headers'])) $extras = self::$parts['curl_headers'];
			else {
				$extras = preg_split( '/[\r\n]{1,2}/', self::$parts['curl_headers']);
				} // else

			$headers = array_merge($headers,$extras);
			} // if
		return $headers;
		} // getRequestHeaders()

	protected function build_domain_regex($hostname) {
		$names = explode('.', $hostname); //assumes main domain is the TLD
		$regex = "";
		for ($i= 0; $i < count ($names)-2; $i++) {
			$regex .= '['.$names[$i].'.]?';
			} // for
		$main_domain = $names[count($names)-2] .".". $names[count($names)-1];
		$regex .= $main_domain;
		return $regex;
		} // build_domain_regex()

	protected function build_multipart_data_files($delimiter, $fields, $files) {
		$data = '';
		foreach ($fields as $name => $content) {
			$data .= "--" . $delimiter . PHP_EOL
				. 'Content-Disposition: form-data; name="' . $name . "\"".PHP_EOL.PHP_EOL
				. $content . PHP_EOL;
			} // foreach

		foreach ($files as $name => $content) {
			$data .= "--" . $delimiter . PHP_EOL
				. 'Content-Disposition: form-data; name="' . $name . '"; filename="' . $name . '"' . PHP_EOL
				. 'Content-Transfer-Encoding: binary'.PHP_EOL
				;
			$data .= PHP_EOL;
			$data .= $content . PHP_EOL;
			} // foreach
		$data .= "--" . $delimiter . "--".PHP_EOL;
		return $data;
		} // build_multipart_data_files()

	public static function init_reverse_proxy_frame($sorc,$id_frame) {	// get forward proxy insert

		$src = self::get_reverse_proxy_src($sorc);

		$text = <<< EOT

			<script type="text/javascript">
				document.addEventListener("DOMContentLoaded", function() {
					document.getElementById('{$id_frame}').src = '{$src}';
					});
			</script>

EOT;

		return $text;
		} // init_reverse_proxy_frame()

	} // Ccms_reverse_proxy


