<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_show_sitemap.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

if(!Ccms_xml_sitemap::get_html_sitemap_file()) {
	unset($_SESSION['action']);
	$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
	header('Location: ' . $url);
	exit (0);
	} // if
?>
<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<table class="page_body">
	<caption>Log in page</caption>
	<tr class="page_body">
		<th class="page_body">
			<h1 class="page_config" title="Sitemap of all the URLs available.">Site Map</h1>
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<?php Ccms_xml_sitemap::show_html_sitemap(); ?>
		</td>
	</tr>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>

