<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_eula_form.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
$link = CMS_C_EULA_LINK;	// default
$has_form = CMS_C_EULA_HAS_FORM;	// default
$info = true;	// default
$show_save = false;
if((((int)$tla['body_id'] > 0) || ((int)$tla['tool_id'] > 0)) &&	// app or tool stuff
	(!empty($tla['terms']))) {
	$link = $tla['terms'];
	$info = !$tla['terms_show'];	// show form
	$show_save = ($tla['terms_show'] && $tla['terms_upfirst']);	// show save button
	$user_name = Ccms::getDottedKeys2Var($_SESSION, 'user.name');
	$user_id = Ccms::getDottedKeys2Var($_SESSION, 'user.id');
	$user_auth = Ccms::getDottedKeys2Var($_SESSION, 'user.type');
	$has_form = false;
	} // if
else if(!Ccms_auth::is_eula_enabled()) {
	unset($_SESSION['action']);
	$url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php';
	header('Location: ' . $url);
	exit (0);
	} // if
else if(!$has_form) {	// default whole site eula
	if(Ccms_auth::is_user_logged_in()) $info = false;	// live user can show form
	else $info = Ccms::get_or_post('info');	// just show eula, no form
	$show_save = ($tla['eula_show'] && $tla['eula_upfirst']);
	if(isset($_SESSION['action'])) unset($_SESSION['action']);
	if(isset($_SESSION['cms_action'])) unset($_SESSION['cms_action']);
	if(!$info) {
		$user_name = Ccms::getDottedKeys2Var($_SESSION, 'user.name');
		$user_id = Ccms::getDottedKeys2Var($_SESSION, 'user.id');
		$user_auth = Ccms::getDottedKeys2Var($_SESSION, 'user.type');
		if((!$user_name) || (!$user_id) || (!$user_auth)) {
			if(!CMS_C_EULA_ALL) $info = true;	// don't show form
			else {
				$user_name = Ccms_auth::get_user_json_name();
				$user_id = 0;
				$user_auth = 'open_eula';
				} // else
			} // if
		} // if
	} // if

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php if((!$has_form) && (!$info)) { ?>
<form name="set_user_eula" action="index.php" method="post" enctype="multipart/form-data" autocomplete="off">
<input type="hidden" name="action" value="eula"/>
<input type="hidden" name="user_id" value="<?php echo $user_id; ?>"/>
<input type="hidden" name="user_name" value="<?php echo htmlentities($user_name); ?>"/>
<input type="hidden" name="user_auth" value="<?php echo htmlentities($user_auth); ?>"/>
<?php	} //if ?>
<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<table class="page_body">
	<tr class="page_body">
		<td class="page_body">
			<?php
			// local file or remote
			if(file_exists(ETC_FS_EXT_INCLUDES_DIR . $link)) {	// local file
				include(ETC_FS_EXT_INCLUDES_DIR . $link);
				} // if
			else if(file_exists(DOCROOT_FS_BASE_DIR . $link)) {	// local file
				if(preg_match('/\.html$|\.htm$/i',$link)) {
					readfile(DOCROOT_FS_BASE_DIR . $link);
					} // if
				else {
					include(DOCROOT_FS_BASE_DIR . $link);
					} // else
				} // if
			else {	// remote link
				Ccms::output_link_or_tool_text($link);
				} // else
			?>
			<input type="hidden" name="body_id" value="<?php echo $tla['body_id']; ?>"/>
			<input type="hidden" name="tool_id" value="<?php echo $tla['tool_id']; ?>"/>
		</td>
	</tr>
<?php if(!$has_form) { ?>
	<tr class="page_body">
		<td class="page_body" style="float: right;">
<?php	if(!$info) { ?>
			<label style="font-size: 1.2em;">I agree </label>
			<?php if($show_save) { ?>
			<input id="id_eula_chk" name="eula" value="agreed" type="checkbox" onclick="chk_eula_agreed(this);"<?php echo (!$show_save ? ' CHECKED':''); ?>/>
			&nbsp;&nbsp;
			<button id="id_eula_submit" name="eula_submit" value="eula_save" type="submit" onclick="Ccms_cursor.setWait();" DISABLED>Save</button>
			<?php	} else { ?>
			<input name="eula" value="agreed" type="checkbox"<?php echo (!$show_save ? ' CHECKED':''); ?>/>
			<?php	} // else ?>
<?php		}
		else { ?>
			<label style="font-size: 1.2em;">I agreed </label>
			<input type="checkbox" CHECKED DISABLED/>
<?php		} // else ?>
		</td>
	</tr>
<?php	} //if ?>
</table>
<?php if((!$has_form) && (!$info)) { ?>
</form>
<script type="text/javascript">
	function chk_eula_agreed(chk) {
		var btn = document.getElementById('id_eula_submit');
		if(chk.checked) btn.disabled = false;
		else btn.disabled = true;
		} // chk_eula_agreed()
</script>
<?php	} //if ?>

<?php Ccms::page_end_comment(__FILE__); ?>
