<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_edit_config.php 2029 2021-04-05 00:40:24Z robert0609 $
 */

$cCMS_C = new Ccms_config();

$cms_config_id = 0;
$cms_config_op = '';
Ccms_export::export_table('cms_configs');
if(Ccms::$cms_action == 'cms_edit_config') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	if(((Ccms::is_get_or_post('edit')) && (Ccms::is_get_or_post('config_edit_id'))) ||
		((Ccms::is_get_or_post('config_edit_id')) && ((int)Ccms::get_or_post('config_edit_id') > 0))) {
		$cms_config_op = 'edit';
		if(Ccms::is_get_or_post('config_edit_id')) $cms_config_id = (int)Ccms::get_or_post('config_edit_id');
		else if(Ccms::is_get_or_post('config_edit_id')) $cms_config_id = (int)Ccms::get_or_post('config_edit_id');
		else { // what??
			$cms_config_op = '';
			$cms_config_id = 0;
			} // else

		$sql_query = "SELECT  cms_config_name, cms_config_value,cms_config_description, cms_config_key, cms_config_allowed_values" .
			", cms_config_show_func, cms_config_input_func, cms_config_save_func,cms_config_comments" .
			", DATETIME(cms_config_added, 'LocalTime') as  cms_config_added" .
			", DATETIME(cms_config_updated, 'LocalTime') as  cms_config_updated" .
			" FROM  cms_configs WHERE length('cms_config_name') > 0 AND cms_config_id = '" . (int)$cms_config_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($config = Ccms::$cDBcms->fetch_array($result))) {
			foreach($config as $c => $v) $$c = $v;
			Ccms::$cDBcms->free_result($result);
			} // if
		} // if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('cms_config_id'))) {
		$cms_config_op = 'save';
		$cms_config_id = (int)Ccms::get_or_post('cms_config_id');
		$cms_config_name = html_entity_decode(Ccms::get_or_post('cms_config_name'));
		$method = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_save_func',"cms_config_id = '" . (int)$cms_config_id . "'");
		if((!empty($method)) &&
			(method_exists($cCMS_C,$method))) {
			// $cms_config_old_value = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_value',"cms_config_id = '" . (int)$cms_config_id . "'");
			$cms_config_value = $cCMS_C->$method('cms_config_value',false);
			} // if
		else if((!empty($method)) &&
			(is_callable($method))) {
			// $cms_config_old_value = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_value',"cms_config_id = '" . (int)$cms_config_id . "'");
			$cms_config_value = call_user_func('cms_config_value',false);
			} // if
		else $cms_config_value = html_entity_decode(Ccms::get_or_post('cms_config_value',false));

		$cms_config_key = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_key',"cms_config_id = '" . (int)$cms_config_id . "'");
		if($cms_config_key == 'CMS_C_WYSIWYG_EDITOR') { // special case
			if($wigs = Ccms::get_or_post('wigs')) {	// have configs
				if(Ccms_wysiwyg::save_wysiwyg_configs($wigs)) {
					Ccms::addMsg('Saved WYSIWYG configs.','success');
					} // if
				else {
					Ccms::addMsg('Failed to save WYSIWYG configs.');
					} //
				} // if
			if(!Ccms_wysiwyg::is_wysiwyg_available($cms_config_value)) {
				Ccms::addMsg('WYSIWYG disabled (using ' . $cms_config_value . ').','warn');
				$cms_config_value = 'None';
				} // if
			} // if
		$cms_config_comments = Ccms::get_or_post('cms_config_comments');

		if(($method != 'save_grid') && // special case
			(!$cCMS_C->is_config_value_ok($cms_config_id,$cms_config_value))) {
			Ccms::addMsg('Value not allowed in ' . $cms_config_key);
			// reget values
			$sql_query = "SELECT  cms_config_name, cms_config_description, cms_config_key" .
				", cms_config_allowed_values, cms_config_show_func, cms_config_input_func,cms_config_comments" .
				", DATETIME(cms_config_added, 'LocalTime') as  cms_config_added" .
				", DATETIME(cms_config_updated, 'LocalTime') as  cms_config_updated" .
				" FROM  cms_configs WHERE  cms_config_id = '" . (int)$cms_config_id . "'";
			if(($result = Ccms::$cDBcms->query($sql_query)) &&
				(Ccms::$cDBcms->num_rows($result) > 0) &&
				($config = Ccms::$cDBcms->fetch_array($result))) {
				foreach($config as $c => $v) $$c = $v;
				Ccms::$cDBcms->free_result($result);
				} // if
			} // if
		else {	// update it
			$fields = array();
			$fields['cms_config_value'] = $cms_config_value;
			$fields['cms_config_comments'] = $cms_config_comments;
			if(!Ccms::$cDBcms->perform('cms_configs',$fields,'update',"cms_config_id = '" . (int)$cms_config_id . "'")) {
				Ccms::addMsg('Config update, ' . $cms_config_name . " failed");
				Ccms::$cDBcms->logEvent('ERROR: config update, ' . $cms_config_name);
				} // if
			else {
				unset($_SESSION['cms_config_id']);
				Ccms_export::export_table('cms_configs');
				Ccms::backupOnSave();
				Ccms::addMsg('Saved configuration values in ' . CMS_PROJECT_SHORTNAME . ' database.','success');
				} // else
			$cms_config_op = '';
			} // if
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('export'))) {
		$cms_user_op = 'export';
		$cms_user_id = 0;
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('import'))) {
		$cms_user_op = 'import';
		$cms_user_id = 0;
		Ccms_export::import_table('cms_configs');
		} // else if
	else if((Ccms_auth::is_admin_user()) && (INI_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$cms_config_op = 'reloadDB';
		$cms_config_id = 0;
		} // else if
	else if((Ccms_auth::is_admin_user()) && (Ccms::is_get_or_post('checkDB'))) {
		$cms_config_op = 'checkDB';
		$cms_config_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_config_op = 'cancel';
		$cms_config_id = 0;
		} // else if
	} // if

	Ccms_search::chk_search_redirect(array('save','cancel'));	// check if return to search

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config" style="text-align: left">
			<h1 class="page_config">Configuration Values</h1>
		</th>
	</tr>
	<?php if($cms_config_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Reloading Configuration Table in Database
			<?php Ccms::$cDBcms->installDatabase('cms_configs',true ,true); ?>
		</td>
	</tr>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<?php } // if ?>
	<?php if($cms_config_op == 'checkDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Checking Configuration Table in Database
			<?php Ccms::$cDBcms->installDatabase('cms_configs',false ,false); ?>
		</td>
	</tr>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<?php } // if ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<form name="cms_edit_config" action="<?php echo $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_config'; ?>" method="post" enctype="multipart/form-data">
			Select config name:&nbsp;
			<?php echo Ccms_search::get_form_search_hidden_inputs(); ?>
			<input type="hidden" name="cms_config_id" value="<?php echo $cms_config_id; ?>"/>
			<?php echo Ccms_edit::get_select_option_filter('prim_id', '',-1); ?>
			<select name="config_edit_id" id="prim_id" size="1"
				style="max-width: unset;"
				onchange="javascript:setConfigButtons(this);">
				<option value="0"> -- Select Config Option -- </option>
				<?php
					$sql_query = "SELECT cms_config_id,cms_config_name,cms_config_value,cms_config_comments" .
								" FROM  cms_configs" .
								" WHERE length('cms_config_name') > 0" .
								" ORDER BY cms_config_name";
					$cnt = 0;
					if(($result = Ccms::$cDBcms->query($sql_query)) &&
						(($cnt = Ccms::$cDBcms->num_rows($result)) > 0)) {
						while($config = Ccms::$cDBcms->fetch_array($result)) {
							if(empty($config['cms_config_name'])) continue;	// invisibles
							echo '<option value="' . $config['cms_config_id'] .'"'.
								((int)$config['cms_config_id'] == $cms_config_id ? ' SELECTED':'') . '>' .
								strip_tags($config['cms_config_name']) .
								((int)$config['cms_config_id'] == $cms_config_id ? ' **':'') .
								'</option>' . PHP_EOL;
							} // while
						} // if
					else echo '<option value="0">(No configs setup)</option>' . PHP_EOL;
				?>
			</select>
<!--			&nbsp;&nbsp;
			<button id="b_edit_id" name="edit" value="edit" type="submit" onclick="Ccms_cursor.setWait();">Edit</button>-->
			<?php if(Ccms_auth::is_admin_user()) { ?>
			&nbsp;&nbsp;
			<button name="checkDB" value="checkDB" type="submit" title="Check configuration table in database for missing entries." onClick="if(var ret = confirm_check('Check and refresh configuration table in database?')) Ccms_cursor.setWait(); return ret;">Check</button>
			<?php	} // if ?>
			<?php if((Ccms_auth::is_admin_user()) && (INI_ALLOW_TABLE_RELOAD_BOOL)) { ?>
			&nbsp;&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise configuration table in database." onClick="return confirm_check('Clear and re-initialise configuration table in database?')">Reload</button>
			<?php	} // if ?>
			<?php echo Ccms_export::get_table_form_text('cms_configs'); ?>
			<?php // Ccms::get_return2search_link(); ?>
			</form>
			<span id="working_id">&nbsp;</span>
			<script type="text/javascript">

				function confirm_check(txt) {
					if(confirm(txt)) {
						document.getElementById('working_id').innerHTML = '<?php echo Ccms_msgs::make_message_text('submiting input.', 'working'); ?>';
						Ccms_cursor.setWait();
						cms_sleep(2000);	// allow img to load
						return true;
						} // if
					return false;
					} // confirm_check()

				function setConfigButtons(elem) {
					var sel = document.getElementById('prim_id');
					if(!sel) return;
					if(sel.selectedIndex > 0) {
						// document.getElementById('b_edit_id').disabled = false;
						if(elem) elem.form.submit();
					} else {
						// document.getElementById('b_edit_id').disabled = true;
					} // else
					} // setBodyConfigButtons()
				setConfigButtons(false);	// initial
			</script>
		</td>
	</tr>
<!--	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>-->

	<?php
	if((($cms_config_op == 'edit') || ($cms_config_op == 'save')) &&
		(isset($cms_config_id)) && ($cms_config_id > 0)) {
	?>
	<tr class="page_config">
		<th class="page_config">
			Edit Configuration Value - <?php echo (!empty($cms_config_name) ? $cms_config_name:'(Invisible, ReadOnly)'); ?>
			&nbsp;&nbsp;
			<span class="page_config">(
				Added:&nbsp;<?php echo $cms_config_added;?>
				&nbsp;&nbsp;
				Updated:&nbsp;<?php echo $cms_config_updated;?>
			)</span>
<?php
			if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_config_key))
				Ccms::get_return2search_link(true);
?>
		</th>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form name="cms_edit_config" action="<?php echo $_SERVER['PHP_SELF'] . '?cms_action=cms_edit_config'; ?>" method="post" enctype="multipart/form-data">
			<input type="hidden" name="cms_config_id" value="<?php echo $cms_config_id; ?>"/>
			<input type="hidden" name="cms_config_name" value="<?php echo $cms_config_name; ?>"/>
			<?php echo Ccms_search::get_form_search_hidden_inputs(); ?>
			<table class="page_config">
<?php if (!empty($cms_config_name)) { ?>
				<tr class="page_config">
					<td class="page_config" colspan="2" style="text-align: left;">
							<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
							&nbsp;&nbsp;
							<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="page_config">
					<th width="150px" class="page_config" style="text-align: left">Description:</th>
					<td class="page_config" style="text-align: left">
						<i><?php echo Ccms::sanitiseText4Html($cms_config_description); ?></i>
					</td>
				</tr>
				<tr class="page_config">
					<th class="page_config" style="text-align: left">Value:</th>
					<td class="page_config" style="text-align: left"><?php echo (!empty($cms_config_name) ? $cCMS_C->show_value($cms_config_value,$cms_config_allowed_values,$cms_config_input_func,$cms_config_description):$cms_config_value); ?></td>
				</tr>
<?php			if(Ccms::is_debug()) { ?>
<?php 		if($cms_config_key == 'CMS_C_WYSIWYG_EDITOR') { // special case ?>
				<tr class="page_config">
					<th class="page_config" style="text-align: left">Available WYSIWYGs:</th>
					<td class="page_config" style="text-align: left">
						<?php echo Ccms_wysiwyg::get_wysiwyg_descriptions(); ?>
					</td>
				</tr>
				<tr class="page_config">
					<th class="page_config" style="text-align: left">Config WYSIWYGs:</th>
					<td class="page_config" colspan="2" style="text-align: left">
						<?php echo Ccms_wysiwyg::config_wysiwygs($cms_config_value); ?>
					</td>
				</tr>
<?php			} // if ?>
				<tr class="page_config">
					<th class="page_config" style="text-align: left">Code Key:</th>
					<td class="page_config" style="text-align: left"><i><?php echo $cms_config_key; ?></i></td>
				</tr>
<?php				} // if ?>
<?php if (!empty($cms_config_name)) { ?>
				<tr class="page_config">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<textarea name="cms_config_comments" autocapitalize="off"/><?php echo $cms_config_comments; ?></textarea>
					</td>
					<td class="page_config">
						Enter administration comments (not seen by user).
					</td>
				</tr>
				<tr class="page_config">
					<td class="page_config" style="text-align: right">
						<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
						&nbsp;&nbsp;
						<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
					</td>
				</tr>
<?php	} // if ?>
			</table>
		</form>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<h2 class="page_config">More configurations.</h2>
		</td>
	</tr>
	<?php } // if  ?>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<table class="page_config">
				<tr class="page_config">
					<th width="200x" class="page_config">Name</th>
					<!--<th width="200px" class="page_config" title="Constant value used in php code">Code Key</th>-->
					<th width="250px" class="page_config">Value</th>
					<th class="page_config">Description</th>
				</tr>
	<?php
		$sql_query = "SELECT  cms_config_id,cms_config_name,cms_config_value,cms_config_allowed_values,cms_config_description,cms_config_key,cms_config_show_func" .
			" FROM  cms_configs" .
			" WHERE length(cms_config_name) > 0" .
			" ORDER BY  cms_config_name,cms_config_id";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$row = 0;
			while($config = Ccms::$cDBcms->fetch_array($result)) {
				echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left" valign="top">';
				if(Ccms::is_debug()) echo 'ID: ' . $config['cms_config_id'] . ', ';
				echo '<a href="index.php?cms_action=cms_edit_config&config_edit_id=' . $config['cms_config_id'] . '">' . $config['cms_config_name'] . '</a>';
				echo '</td>' . PHP_EOL;
				echo '<!--<td class="page_config" style="text-align: left">' . $config['cms_config_key'] . '</td>-->';
				echo '<td class="page_config" style="text-align: left">';
					if((!empty($config['cms_config_show_func'])) &&
						(method_exists($cCMS_C,$config['cms_config_show_func']))) {
						$method = $config['cms_config_show_func'];
						echo $cCMS_C->$method($config['cms_config_value'],$config['cms_config_allowed_values'],'page_config');
						} // if
					else if((!empty($config['cms_config_show_func'])) &&
						(is_callable($config['cms_config_show_func']))) {
						// left over from V5
						$method = $config['cms_config_show_func'];
						echo call_user_func($config['cms_config_value'],$config['cms_config_allowed_values'],'page_config');
						} // if
					else if(!empty($config['cms_config_allowed_values'])) echo Ccms::make_nice_name ($config['cms_config_value']);
					else echo (!empty($config['cms_config_value']) ? $config['cms_config_value']:'(empty)');
				echo '</td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left">' . $config['cms_config_description'] . '</td>' . PHP_EOL;
				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			Ccms::$cDBcms->free_result($result);
			} // if
		else echo '<tr class="page_config"><td class="page_config" style="text-align: left">(No configs setup)</td></tr>' . PHP_EOL;
		?>
			</table>
		</td>
	</tr>
</table>


<?php Ccms::page_end_comment(__FILE__); ?>
