<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_closed.php 2085 2021-07-06 16:24:36Z robert0609 $
 */

$reason_closed = '';
if(strlen(INI_WEBSITE_CLOSED_REASON) >= LMC_MIN_NAME_LEN) $reason_closed = INI_WEBSITE_CLOSED_REASON;
else $reason_closed = 'Web Site Not Available.';

?>
<!DOCTYPE html>
<html dir="ltr"<?php echo (preg_match('/^UTF/i',INI_CHAR_SET) ? ' lang="' . INI_LANGUAGE_CODE . '"':''); ?>>
	<head>
		<meta charset="<?php echo INI_CHAR_SET; ?>">
		<title><?php echo CMS_C_CO_NAME; ?> Closed</title>
		<META NAME="GENERATOR" CONTENT="<?php echo CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION; ?>">
		<meta http-equiv="refresh" content="600">
	</head>
	<body>
<?php	Ccms::page_start_comment(__FILE__); ?>
		<p style="text-align: center; font-weight: bolder;"><?php echo ((strlen(CMS_C_CO_NAME) > 4) ? CMS_C_CO_NAME:CMS_WWW_URL); ?></p>
		<p style="text-align: center; font-weight: bolder;">
<?php
	if(file_exists(DOCROOT_FS_BASE_DIR . $reason_closed)) {
		include(DOCROOT_WS_BASE_DIR . $reason_closed);
		} // if
	else echo $reason_closed;


?>
		</p>
<?php	Ccms::page_end_comment(__FILE__); ?>
<?php	Ccms::do_analytics_include(); ?>
	</body>
</html>

