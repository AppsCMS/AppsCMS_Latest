<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_lm.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

$chgs = Ccms_recents_links::get_recent_changes();
?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php if((LMC_FILTER_OUTPUT) ||
	((LMC_RECENT_CHANGES_ENABLED) && ($chgs)) ||
	(LMC_SHOW_SECT_COLL_EXP_BUTTON)) { ?>
<form method="post" name="filter" action="<?php echo $_SERVER['PHP_SELF'] . '?action=filter'; ?>">
<table class="page_body">
	<caption>Links manager body</caption>
	<tr class="page_body">
		<td class="page_body" style="text-align: left">
			<div style="">
<?php if(LMC_FILTER_OUTPUT) { ?>
				<label style="display: inline-block; margin: 2px;">
					Filters:
					<input type="text" name="keywords" size="40"
						value="<?php echo Ccms::get_or_post ('keywords'); ?>"
						title="Enter filter keywords, <?php echo (LMC_FILTER_ANDED ? 'all words must appear':'any word may appear'); ?>."
						oninput="javascript:get_lm_filtered_links_page();"
						autofocus autocapitalize="off" autocomplete="off"/>
					<img alt="loading" id="ajax-loader" src="cms/images/ajax-loader.gif" style="display: none"/>
					<button id="find_button" name="filter" value="filter" type="submit" title="Start find filter.">Find</button>
				</label>
<?php	} // if ?>
<?php if(LMC_SHOW_SECT_COLL_EXP_BUTTON) { ?>
				<label style="display: inline-block; margin: 2px;">
					<button id="collapse_all_button" name="collapse_all" type="button" onclick="collapse_lm_sect_all();" title="Collapse all sections.">Collapse</button>
				</label>
				<label style="display: inline-block; margin: 2px;">
					<button id="expand_all_button" name="expand_all" type="button" onclick="expand_lm_sect_all();" title="Expand all sections.">Expand</button>
				</label>
<?php	} // if ?>
<?php if((LMC_RECENT_CHANGES_ENABLED) && ($chgs)) { ?>
				<label style="display: inline-block; margin: 2px;">
					Recent Changes:
					<?php echo $chgs; ?>
				</label>
<?php	} // if ?>
			</div>
		</td>
	</tr>
</table>
</form>
<?php	} // if ?>
<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<div id="page_contents_ajax">
<?php	include(CMS_FS_INCLUDES_DIR . "cms_filtered_links.php"); ?>
</div>

<script type="text/javascript">

	var last_get_lm_filtered_links_call = null;	// speed limiter

	function get_lm_filtered_links_page() {
		if(last_get_lm_filtered_links_call != null) {	// clear it
			window.clearTimeout(last_get_lm_filtered_links_call);
			last_get_lm_filtered_links_call = null;
			} // if
		// restart if
		last_get_lm_filtered_links_call = window.setTimeout(
			function () {
				var keywords = document.forms["filter"]["keywords"].value;
				keywords = encodeURI(keywords);
				var body_url = 'cms_get_filtered_links_page&keywords=' + keywords;
				cms_ajax_body_page(body_url, 'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
				}, 600);
		} // get_lm_filtered_links_page()

	function send_lm_section_states() {
		if(!lm_section_ids) return false;	// no ids
		// lm_section_ids should have the state of the sections
		var xmlhttp = false;
		if (window.XMLHttpRequest) {
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp = new XMLHttpRequest();
			} // if
		else {	// code for IE6, IE5
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} // else
		if(!xmlhttp) return false;
		var url = 'cms/cms_ajax.php?ajax=lm_save_filtered_sections_state';
		xmlhttp.open("POST",url);
		xmlhttp.setRequestHeader("Content-Type", "application/json");
		var states = {
			lm_section_states: lm_section_ids,
			};
		var post = JSON.stringify(states);
		xmlhttp.send(post);
		return true;
		} // send_lm_section_states()

	function set_lm_open_links_button(open,id) {
		var id_btn = 'id_btn_lm_open_tabs_sect_links_' + id;	// open all btn
		var btn = document.getElementById(id_btn);
		if(!btn) return false;
		if(open) btn.style.display = '';
		else btn.style.display = 'none';
		return true;
		} // set_lm_open_links_button()

<?php if(LMC_SHOW_SECT_COLL_EXP_BUTTON) { ?>
	function lm_roll_down_sect_link(dv,sect_ids_tree) {
		dv.setAttribute('data-sect-state','down');
		//dv.style.maxHeight = '100vh';
		dv.style.display = 'block';
// don't play, looks like a compound error in FF
//		var height = dv.offsetHeight;
//		dv.style.height = (height + 0) + 'px';
//		var par = dv.parentElement;
//		if(par) {
//			var sp = par.getElementsByTagName('SPAN')[0];
//			if(sp) {
//				height = sp.offsetHeight;
//				sp.style.height = (height + 0) + 'px';
//				} // if
//			} // if
		} // lm_roll_down_sect_link()

	var open_lm_lks_last_op = false;	// used to stop double event trigger
	function toggle_lm_roll_sect_links(event,obj,id,sect_ids_tree) {
		if(open_lm_lks_last_op) {
			open_lm_lks_last_op = false;
			return false;
			} // if
		var id_dv = 'id_div_sect_links_' + id;	// toggle links div
		var dv = document.getElementById(id_dv);
		if(!dv) return false;

		event.stopPropagation();
		var btn = obj;
		if(obj.tagName != 'BUTTON') {
			var ch_id = 'id_btn_lm_roll_sect_links_' + id;
			var btns = obj.getElementsByTagName("BUTTON");
			for(var btnIdx in btns) {
				if(btns[btnIdx].id == ch_id) {
					btn = btns[btnIdx];
					break;
					} // if
				} // for
			} // if

		if(dv.getAttribute('data-sect-state') == 'up') {	// open if
			lm_roll_down_sect_link(dv,sect_ids_tree);
			btn.innerHTML = '<img src="cms/images/DbChevUp.gif" style="height: 12px;">';
			set_lm_open_links_button(true,id);
			} // if
		else {	// open it
			dv.setAttribute('data-sect-state','up');
			//dv.style.maxHeight = '0px';
			dv.style.display = 'none';
			btn.innerHTML = '<img src="cms/images/DbChevDn.gif" style="height: 12px;">';
			set_lm_open_links_button(false,id);
			} // else
		if(lm_section_ids) // keep track
			lm_section_ids[id]['state'] = dv.getAttribute('data-sect-state');
		return send_lm_section_states();
		} // toggle_lm_roll_sect_links()

	function collapse_lm_sect_all() {
		if(!lm_section_ids) return;
		for (const [i,v] of Object.entries(lm_section_ids)) {
			var id = i;
			var id_dv = 'id_div_sect_links_' + id;
			var dv = document.getElementById(id_dv);
			if(!dv) continue;
			dv.setAttribute('data-sect-state','up');
			// dv.style.maxHeight = '0px';
			dv.style.display = 'none';
			var id_btn = 'id_btn_lm_roll_sect_links_' + id;
			var btn = document.getElementById(id_btn);
			btn.innerHTML = '<img src="cms/images/DbChevDn.gif" style="height: 12px;">';	// plus sign
			lm_section_ids[id]['state'] = dv.getAttribute('data-sect-state');
			set_lm_open_links_button(false,id);
			} // for
		return send_lm_section_states();
		} // collapse_lm_sect_all()

	function expand_lm_sect_all() {
		if(!lm_section_ids) return;
		for (const [i,v] of Object.entries(lm_section_ids)) {
			var id = i;
			var id_dv = 'id_div_sect_links_' + id;
			var dv = document.getElementById(id_dv);
			if(!dv) continue;
			lm_roll_down_sect_link(dv);
			var id_btn = 'id_btn_lm_roll_sect_links_' + id;
			var btn = document.getElementById(id_btn);
			btn.innerHTML = '<img src="cms/images/DbChevUp.gif" style="height: 12px;">';
			lm_section_ids[id]['state'] = dv.getAttribute('data-sect-state');
			set_lm_open_links_button(true,id);
			} // for
		return send_lm_section_states();
		} // expand_lm_sect_all()
<?php	} // if ?>

	function open_lm_tabs_sect_links(event,obj,sect_id) {
		event.stopPropagation();
		open_lm_lks_last_op = true;
		if(!lm_section_links_urls) return false;
		if(lm_section_links_urls.length <= 0) return false;
		if(!lm_section_links_urls[sect_id]['links']) return false;
		var links = lm_section_links_urls[sect_id]['links'];
		var sect_name = lm_section_links_urls[sect_id]['name'];
		if(!links) return false;
		var lk_cnt = 0;
		for(const link_id in links) lk_cnt++;	//must be !!!
		if(!confirm('Section: ' + sect_name + "\n" + 'Open all ' + lk_cnt + ' URL links in tabs?')) return false
		for(const link_id in links) {
			var link = links[link_id];
			window.open(link['url']);
			} // for
		return true;
		} // open_lm_tabs_sect_links()

</script>
<noscript> </noscript>
<?php Ccms::page_end_comment(__FILE__); ?>
