<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_session_browser.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of session_browser
 * general AppsCMS session browser
 *
 * @author robert0609
 */

$filter = Ccms_search::get_form_search_input_keywords_ary();
$exact = Ccms::get_or_post_checkbox('exact');
$show_expired = Ccms::get_or_post_checkbox('show_expired');
if(!$filter) $filter = array();

function help() {
	$text = "Enter search keywords, separated by spaces, to search dates, names, etc. in a session.";
	return $text;
	} // help()

$log_path = VAR_FS_LOGS_DIR;
if((Ccms::is_get_or_post('delete_log_file')) && (!empty(Ccms::get_or_post('delete_log_file')))) {
	$log_file = Ccms::get_or_post('delete_log_file');
	Ccms::trash_path($log_path . $log_file,true);
	Ccms::unset_get_or_post('cms_browse_sessions');
	} // if
else if((Ccms::is_get_or_post('selected')) &&
	(Ccms::is_get_or_post('deleteSelected')) &&
	(Ccms::get_or_post('deleteSelected') == 'delete')) {
	$selected = Ccms::get_or_post('selected');
	foreach($selected as $log_file) {
		Ccms::trash_path($log_path . $log_file,true);
		} // if
	Ccms::unset_get_or_post('selected');
	} // if

// Ccms::get_or_post('download_log_file') done in cms_top.php

$cms_browse_sessions = Ccms::get_or_post('cms_browse_sessions');

$lines_max = Ccms::get_or_post('lines_max');
if((!$lines_max) || ($lines_max > 100)) $lines_max = 100;
if($lines_max > 1000) $lines_max = 1000;

$line_start = 1;
if(Ccms::is_get_or_post('next')) $line_start += $lines_max;
else if(Ccms::is_get_or_post('prev')) $line_start -= $lines_max;
if($line_start < 1) $line_start = 1;
$line_end = $line_start + $lines_max - 1;

$user_sessions = Ccms_sessions::get_user_sessions();
$last_line_num = count($user_sessions);
$my_session_id = CMS_SESSION_NAME . session_id();

?>

<?php if(!Ccms::is_get_or_post('ajax')) { ?>
<?php Ccms::page_start_comment(__FILE__); ?>
<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<script type="text/javascript">
	var last_ajax_run_call = null;
	var ajax_running = false;
	var ajax_deb = 1200;
	function ajax_run(id) {
		if(ajax_running) return;
		if(last_ajax_run_call != null) {	// clear it
			window.clearTimeout(last_ajax_run_call);
			last_ajax_run_call = null;
			} // if
		// restart if
		last_ajax_run_call = window.setTimeout(function(id) {
			// return;	// test
			ajax_running = true;
			var min_l = 2;
			var keywords = document.getElementById(id).value.toString();
			if((keywords.length < min_l) ||
				(keywords.length == 0)) {
				document.getElementById('page_contents_ajax').innerHTML = "Minimum of " + min_l + " characters required.";
				ajax_running = false;
				return;
				} // if
			var fb = document.getElementById('id_form_keywords');	// save in the form too
			if(fb) fb.value = keywords;
			keywords = encodeURI(keywords);
			var exact = document.getElementById(id + '_exact').checked;
			var show_expired = document.getElementById(id + '_show_expired').checked;
			var body_url = 'cms_browse_sessions&search=' + keywords + (exact ? '&exact=on':'') + (show_expired ? '&show_expired=on':'');
			cms_ajax_body_page(body_url,'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
			ajax_running = false;
			return;
			},
		ajax_deb, id);
		} // ajax_run()
</script>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config" style="text-align: left">
			<h1 class="page_config">User Sessions Browser</h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form method="post" name="cms_browse_sessions" action="index.php?cms_action=cms_browse_sessions">
				<?php echo Ccms_search::get_form_search_hidden_inputs(); ?>
				<input type="text"
					id="keywords_inp"
					name="keywords_inp" size="40"
					oninput="javascript:ajax_run('keywords_inp');"
					value="<?php echo implode(' ',$filter); ?>"
					style="width: unset;"
					title="<?php echo help(); ?>" autofocus autocapitalize="off"/>
				<button name="search" value="search" type="submit" onclick="Ccms_cursor.setWait();" title="Start the search.">Search</button>
				<label>Exact:
					<input type="checkbox"  id="keywords_inp_exact" name="exact"
						onchange="this.form.submit();"
						title="Check for exact match." <?php echo (Ccms::get_or_post_checkbox('exact') ? ' CHECKED':''); ?>
						/>
				</label>
				<label>Expired:
					<input type="checkbox"  id="keywords_inp_show_expired" name="show_expired"
						onchange="this.form.submit();"
						title="Show expired sessions." <?php echo (Ccms::get_or_post_checkbox('show_expired') ? ' CHECKED':''); ?>
						/>
				</label>
			</form>
		</td>
	</tr>
</table>
<span id="page_contents_ajax">
<?php	} // if ?>
	<table class="page_config">
<?php if(!empty($user_sessions)) { ?>
		<form name="cms_browse_sessions" action="index.php?cms_action=cms_browse_sessions" method="post" enctype="multipart/form-data">
		<input type="hidden" name="cms_browse_sessions" value="<?php echo urlencode($cms_browse_sessions); ?>"/>
		<input type="hidden" name="start_line" value="<?php echo $line_start; ?>"/>
		<tr class="page_config">
			<td class="page_config">
				<select name="lines_max" onchange="this.form.submit()" style="width: 50px;" title="Sessions per page.">
<?php
		$lines_max_tab = array(10,20,50,100,200,500,1000);
		foreach($lines_max_tab as $ml) {
			echo '					<option value="' . $ml . '"' . (($ml == $lines_max) ? ' SELECTED':'') . '>' . $ml . '</option>';
			if($ml > $last_line_num) break;
			} // foreach
?>
				</select> sessions.
<?php	if($line_start > 1) { ?>
				<button type="submit" onclick="Ccms_cursor.setWait();" name="prev" value="prev" title="Click for previous page.">Previous</button>
<?php		} // if ?>
<?php	if((int)$last_line_num > $line_end) { ?>
				<button type="submit" onclick="Ccms_cursor.setWait();" name="next" value="next" title="Click for next page.">Next</button>
<?php		} // if ?>
				</td>
			</tr>
			<tr class="page_config">
				<td class="page_config">
					<table class="page_config">
						<tr class="page_config" title="From log directory: <?php echo $log_path. ' (' . $lines_max . ' lines maximum)'; ?>">
							<th class="page_config" style="text-align: center;">Index</th>
							<th class="page_config" style="text-align: left;">Session Data</th>
						</tr>
<?php

				$row = 0; $line_num = 0;
				for($i = 0; $i < count($user_sessions); $i++) {
					$user_session = &$user_sessions[$i];
					$line_num++;
					if($line_start > $line_num) continue;	// find start line
					if($line_num > $line_end) continue;	// thats it, keep counting
					if(($meta = Ccms_sessions::filter_session($filter,$user_session,$exact,$show_expired)) === false) continue;
?>
					<tr class="<?php echo (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
						<td class="page_config" style="text-align: center;">
							<?php echo $line_num; ?>
							<?php echo Ccms_search::make_meta_search_text($meta);?>
						</td>
						<td class="page_config" style="text-align: left;">

<?php
//if(!empty($filter)) {
//
//				 $line = json_encode($user_session,JSON_PRETTY_PRINT);
//				echo '<pre>' . PHP_EOL .
//					$line . PHP_EOL .
//					'</pre>' . PHP_EOL;
//	} // if
//else {
					if((!empty($user_session['file'])) &&
						($user_session['file'] == $my_session_id))
						echo '<b style="color: blue;" title="This browsers session data.">This session.</b>';
					$line = Ccms::get_tree_view($i, $user_session,$filter);
					echo $line;
//	} // else
?>
						</td>
					</tr>
<?php
					} // for
				if($row <= 0) {
?>
					<tr class="page_config">
						<td class="page_config" style="text-align: center; font-weight: bold;" colspan="2">
							No results found.
						</td>
					</tr>

<?php
					} // if
?>
				</table>
			</td>
		</tr>
		<input type="hidden" name="last_line_num" value="<?php echo $line_num; ?>"/>
		<tr class="page_config">
			<td class="page_config">
<?php	if($line_start > 1) { ?>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="prev" value="prev" title="Click for previous page.">Previous</button>
<?php		} // if ?>
<?php	if($line_num > $line_end) { ?>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="next" value="next" title="Click for next page.">Next</button>
<?php		} // if ?>
			</td>
		</tr>
		</form>
<?php	} // if ?>
	</table>

<?php if(!Ccms::is_get_or_post('ajax')) { ?>
</span>
<?php Ccms::page_end_comment(__FILE__); ?>
<?php	} // if

