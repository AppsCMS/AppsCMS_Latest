<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_doxy.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

$doxy_uri = Ccms::get_or_post('doxy');
if(!$doxy_uri) {	// what ??
	Ccms::$action = false;
	$url = (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER']:(Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php');
	header('Location: ' . $url);
	exit(0);
	} // if

// doxy index.html needs a full url in an iframe to work.
if(preg_match('/^(https|http):/i',$doxy_uri)) $doxy_url = $doxy_uri;
else $doxy_url = (Ccms::$ssl_required ? CMS_SSL_URL:CMS_WWW_URL) . rawurldecode($doxy_uri);

?>

<?php Ccms::page_start_comment(__FILE__); ?>
<table class="page_config">
	<caption>Browse source code documentation for <?php echo strip_tags(CMS_PROJECT_SHORTNAME); ?> page</caption>
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Doxy Page</h1> <a href="index.php?cms_action=cms_manual" target="_blank">Refer to technical manual for more info.</a>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left; height: calc(100vh - 120px);">
			<?php Ccms::output_link_or_tool_text($doxy_url); ?>
		</td>
	</tr>
</table>
<?php Ccms::page_end_comment(__FILE__); ?>

