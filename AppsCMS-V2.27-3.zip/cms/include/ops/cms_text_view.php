<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_text_view.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

/**
 * Description of text_view
 * general text file viewer
 *
 * @author robert0609
 */

$uri = Ccms::get_or_post('uri');
$ret = Ccms::get_or_post('ret');

?>

<?php Ccms::page_start_comment(__FILE__); ?>

<?php echo Ccms::get_admin_scroll2pageTop(); ?>
<table class="page_config">
	<tr class="page_config">
		<td class="page_config">
			<?php Ccms_media_conv_plugin::prn_text_file2html($uri); 	?>
		</td>
	</tr>
<?php if(!empty($ret)) { ?>
	<tr class="page_config">
		<td class="page_config" style="text-align: left;">
			<form action="<?php echo $ret; ?>" method="POST">
				<button type="submit" title="Return to previous page.">Go Back</button>
			</form>
		</td>
	</tr>
<?php	} //if ?>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>

