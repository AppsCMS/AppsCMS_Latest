<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_login.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

if(Ccms_auth::is_login_allowed()) {	// not possible
?>
<?php Ccms::page_start_comment(__FILE__); ?>
<table class="page_body">
	<caption>Log in page</caption>
	<tr class="page_body">
		<td class="page_body">
			<table class="page_body login_extra">
				<tr class="page_body">
					<td class="page_body">&nbsp;</td>
					<td class="page_body login_extra">
						<div class="login_extra">
							<h1 class="page_config">Login</h1>
<?php
						// require(CMS_FS_OPS_DIR . 'cms_login_local_form.php');
						Ccms::$action = false;
						$text = Ccms_auth::get_signin_signout('',false);
						echo $text;
?>
						</div>
					</td>
					<td class="page_body">&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<?php Ccms::page_end_comment(__FILE__); ?>
<?php
	} // if
else {
	$url = CMS_WWW_URL . 'index.php?action=home';
	header('Location: ' . $url);
	exit(0);
	} // else
