<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_config_menu.php 2081 2021-07-04 10:29:50Z robert0609 $
 */

if(Ccms_auth::is_config_user()) {
	Ccms::page_start_comment(__FILE__);
	$config_menu = array(
		'th' => array(
			'text' => Ccms_html::get_menu_icon_text(Ccms_auth::is_admin_user() ? 'Admin':'Manage'),
			'title' => "Config and edit " . strip_tags(CMS_PROJECT_NAME . ' ' . CMS_PROJECT_VERSION) . " settings.",
			),
		'td' => array(),
		);
	// add 'td's in display order
	if(Ccms_auth::is_admin_user()) {
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_search",
			'title' => "Search install, theme, config, page bodies and custom headers / footers.",
			'text' => 'Search',
			);
		if((!INI_HEADER_BOOL) || (CMS_C_CUSTOM_HEADER)) {
			$config_menu['td'][] = array(
				'url' => "index.php",
				'title' => "Home Page",
				'text' => 'Home',
				);
			} // if

		if(Ccms_apps::is_ini_congurable()) {
			$config_menu['td'][] = array(
				'url' => "index.php?cms_action=cms_edit_apps",
				'title' => "Edit local applications configuration settings",
				'text' => 'Apps Config',
				);
			Ccms_apps::get_app_extend_menus($config_menu);
			} // if
		$app_admin_uris = Ccms::get_apps_extend_static_func('get_admin_uris');
		if((!is_null($app_admin_uris)) && (is_array($app_admin_uris))) {
			for($i = 0; $i < count($app_admin_uris); $i++) {
				$uri = &$app_admin_uris[$i];
				$config_menu['td'][] = array(
					'url' => "index.php?cms_action=apps_extend&idx=" . ($i + 1),	// +1 for more appropiate index (0 looks wrong)
					'title' => $uri['title'],
					'text' => $uri['text'],
					);
				} // for
			} // if

	$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_header_footer",
			'title' => "Edit applications custom header and footer contents.",
			'text' => 'Header / Footer',
			);
		} // if
	$config_menu['td'][] = array(
		'url' => "index.php?cms_action=cms_edit_bodies",
		'title' => "Edit applications page body contents and applications control.",
		'text' => 'Pages / Apps',
		);
	if(Ccms_auth::is_admin_user()) {
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_tools",
			'title' => "Edit and change local tools.",
			'text' => 'Tools',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_users",
			'title' => "Edit and change " . CMS_PROJECT_SHORTNAME . " local users",
			'text' => 'Users',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_groups",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " user local groups",
			'text' => 'Groups',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_sections",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " sections on links page",
			'text' => 'Sections',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_links",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " links and URLs on links page",
			'text' => 'Links',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_config",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " configuration settings",
			'text' => 'Config',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_theme",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " theme settings",
			'text' => 'Theme',
			);
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_edit_install",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " installation settings",
			'text' => 'Install',
			);
		if((defined('INI_SITEMAPS_BOOL')) && (INI_SITEMAPS_BOOL)) {
			$config_menu['td'][] = array(
			'url' => "index.php?cms_action=update_sitemap",
			'title' => "Update XML sitemap and show HTML sitemap.",
			'text' => 'Show Map',
			);
			if((file_exists(CMS_SITEMAP_XML_FILE)) && (is_readable(CMS_SITEMAP_XML_FILE))) {
				$config_menu['td'][] = array(
					'url' => CMS_SITEMAP_XML_FILE,
					'new' => true,
					'title' => "Show the Google XML sitemap on new tab/window",
					'text' => 'Show XML Map',
					);
				} // if
			} // if
		$lo_inv = false;
		if(INI_NAV_BAR_BOOL) {
			$grid_chk = Ccms::get_navbar_grid();
			unset($grid_chk['apps']);
			foreach($grid_chk as $g) {
				if(preg_Match('/logout/i',$g[0])) {
					$lo_inv = true;
					break;
					} // if
				} // foreach
			} // if
		if((!INI_HEADER_BOOL) || (CMS_C_CUSTOM_HEADER) || (!$lo_inv)) {
			// make sure there is a logout link
			$config_menu['td'][] = array(
				'url' => "logout.php",
				'title' => "Logout: " . Ccms_auth::get_logged_in_username(),
				'text' => 'Logout',
				);
			} // if
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_log_view",
			'title' => "View and manage " . CMS_PROJECT_SHORTNAME . " log files.",
			'text' => 'Logs',
			);
		if(Ccms_sessions::is_session_browsing_available()) {
			$config_menu['td'][] = array(
				'url' => "index.php?cms_action=cms_browse_sessions",
				'title' => "Browse user sessions.",
				'text' => 'Sessions',
				);
			} // if
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_users_stats",
			'title' => "Browse user statics.",
			'text' => 'User Stats',
			);
// on CLI only
//		$config_menu['td'][] = array(
//			'url' => "index.php?cms_action=cms_rebuild_setup",
//			'confirm' => 'Check installation.\nRebuild may take several minutes.',
//			'title' => "Check " . CMS_PROJECT_SHORTNAME . " installation and back up.\nRebuild installation, theme and configuration settings.\nNOTE: May take several minutes. See the manual.",
//			'text' => 'Rebuild',
//			);
		} // if
	if((file_exists(APPS_FS_APPS_MANUAL)) && (is_readable(APPS_FS_APPS_MANUAL))) {
		$config_menu['td'][] = array(
			'url' => "index.php?action=apps_manual",
			'title' => CMS_C_CO_NAME . " Applications Technical Manual",
			'text' => "Apps Manual",
			);
		} // if
	$config_menu['td'][] = array(
		'url' => "index.php?cms_action=cms_about",
		'title' => "About " . Ccms::$version_str,
		'text' => "About",
		);
	$config_menu['td'][] = array(
		'url' => "index.php?cms_action=cms_manual",
		'title' => strip_tags(CMS_PROJECT_NAME . ' ' . CMS_PROJECT_VERSION) . " technical manual.",
		'text' => 'Manual',
		);
	if(Ccms::is_debug()) {
		$config_menu['td'][] = array(
			'url' => "index.php?cms_action=cms_debug",
			'title' => "Debug: show " . CMS_PROJECT_SHORTNAME . " values.",
			'text' => 'Debug',
			);
		if(file_exists(CMS_FS_CMS_DOXY_DIR . 'index.html')) {
			$config_menu['td'][] = array(
				'url' => "index.php?cms_action=cms_doxy&doxy=" . rawurlencode(CMS_WS_CMS_DOXY_DIR . 'index.html'),
				'title' => "Debug: Explore " . CMS_PROJECT_SHORTNAME . " doxygen documents.",
				'text' => 'Doxy CMS',
				);
			} // if
		if(file_exists(CMS_FS_APPS_DOXY_DIR . 'index.html')) {
			$config_menu['td'][] = array(
				'url' => "index.php?cms_action=cms_doxy&doxy=" . rawurlencode(CMS_WS_APPS_DOXY_DIR . 'index.html'),
				'title' => "Debug: Explore Apps doxygen documents.",
				'text' => 'Doxy Apps',
				);
			} // if
		if(file_exists(CMS_FS_CMS_APPS_DOXY_DIR . 'index.html')) {
			$config_menu['td'][] = array(
				'url' => "index.php?cms_action=cms_doxy&doxy=" . rawurlencode(CMS_WS_CMS_APPS_DOXY_DIR . 'index.html'),
				'title' => "Debug: Explore Apps and " . CMS_PROJECT_SHORTNAME . " doxygen documents.",
				'text' => 'Doxy Apps &amp; CMS',
				);
			} // if
		} // if

	new Ccms_generate_Vmenu('amenu','admin_pdb_container',$config_menu,true,true,32);
	Ccms::$admin_menu_output = true;
	Ccms::page_end_comment(__FILE__);
	} // if

