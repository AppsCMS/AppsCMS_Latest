/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_inline_styles.css.php 2008 2021-03-02 09:51:18Z robert0609 $
 */

/*
	Document   : inline_styles
	Description:
		Purpose of the stylesheet follows.
		Inline styles, the header, body and footer are sequential top to bottom overflowing the browser window.
		<?php echo $gen_note; ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

<?php
$pad = 0;
$body_top_px = ((int)preg_replace('/[a-z]*$/i', '',  $theme['ThemeSettings']['HEADER_HEIGHT']) + $pad +
		($cms_nav_bar ? (int)preg_replace('/[a-z]*$/i', '', $theme['ThemeSettings']['NAV_BAR_HEIGHT']) + (3 * $pad):0));

$hnf_px = $body_top_px + (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['FOOTER_HEIGHT']);

$body_top = $body_top_px . 'px';
$hnf = ($hnf_px + 8) . 'px';

?>

/* cms_container contents positioning */
#cms_container {
	z-index:	1;
	}

#cms_header {
<?php if ($theme['ThemeSettings']['NAV_BAR_BESIDE_LOGO_BOOL'] == 'true') { ?>
	height: 0 !important;
<?php } else { ?>
	height:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?> !important;   /* Height of the header */
<?php } ?>
	z-index:	60;
	}

#cms_left_column {
	z-index:	50;
	overflow:	visible;
<?php if($theme['ThemeSettings']['LEFT_STICKY_BOOL'] == 'true') { ?>
	position:	sticky;
	top:		0px;
<?php	} // if ?>
	}

#cms_right_column {
	z-index:	50;
	overflow:	visible;
<?php if($theme['ThemeSettings']['RIGHT_STICKY_BOOL'] == 'true') { ?>
	position:	sticky;
	top:		0px;
<?php	} // if ?>
	}

#cms_navbar_wlc {	/* with left column */
<?php if($theme['ThemeSettings']['NAV_BAR_STICKY_BOOL'] == 'true') { ?>
	/*position: -webkit-sticky;*/
	/*position: sticky;*/
	/*top:	5px;*/
<?php	} // if ?>
	z-index:	100;
	}

#cms_navbar_wlrc {	/* with left column and right column */
<?php if($theme['ThemeSettings']['NAV_BAR_STICKY_BOOL'] == 'true') { ?>
	/*position: -webkit-sticky;*/
	/*position: sticky;*/
	/*top:	5px;*/
<?php	} // if ?>
	z-index:	100;
	}

#cms_navbar_nolc {	/* with no left column */
<?php if($theme['ThemeSettings']['NAV_BAR_STICKY_BOOL'] == 'true') { ?>
	/*position: -webkit-sticky;*/
	/*position: sticky;*/
	/*top:	5px;*/
<?php	} // if ?>
	z-index:	100;
	}

#cms_link_frame {	/* inside an absolute page body */
	z-index:	3;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	width:		100%;
	}

#cms_link_frame_nolc {	/* with no left column */
	z-index:	3;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

#cms_link_frame_wlc {	/* with left column */
	padding:	3px 0px 0px 0px;
	z-index:	3;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

#cms_link_frame_wlrc {	/* with left column and right column */
	padding:	3px 0px 0px 0px;
	z-index:	3;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

#cms_page_body_wlc {	/* with left column */
	padding:	0px;
	z-index:	2;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

#cms_page_body_wlrc {	/* with left column and right column */
	padding:	0px;
	z-index:	2;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

#cms_page_body_nolc {	/* with no left column */
	padding:	0px;
	z-index:	2;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

#cms_footer {
/*	min-height:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?> !important; */   /* Height of the footer */
	z-index:	50;
	}

.link_frame_moz {
	height:100%;
	}
.link_frame_tablet {
	height:100%;
	}

.iframe_tablet {
	max-width:		100%;
	border-width: 0;
/*	min-height: calc(100vh - <?php echo $hnf; ?>); */
	}
.iframe_moz {
	max-width: calc(100% - 5px);
	border-width: 0;
/*	min-height: calc(100vh - <?php echo $hnf; ?>); */
	}

/* eof */

