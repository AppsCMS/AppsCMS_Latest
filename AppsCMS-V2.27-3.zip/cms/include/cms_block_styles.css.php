/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_block_styles.css.php 2008 2021-03-02 09:51:18Z robert0609 $
 */

/*
	Document   : main_styles
    Description:
        Purpose of the stylesheet follows.
		Block styles, keep the header and footer at top and bottom of the browser window.
		<?php echo $gen_note; ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/
<?php
$pad = 0;
$body_top_px = ((int)preg_replace('/[a-z]*$/i', '',  $theme['ThemeSettings']['HEADER_HEIGHT']) + $pad +
		($cms_nav_bar ? (int)preg_replace('/[a-z]*$/i', '', $theme['ThemeSettings']['NAV_BAR_HEIGHT']) + (3 * $pad):0));

$hnf_px = $body_top_px + (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['FOOTER_HEIGHT']);

$body_top = $body_top_px . 'px';
$hnf = $hnf_px . 'px';

?>

/* cms_container contents positioning */
#cms_container {
	position:	absolute;
	top:		0px;
	left:		0px;
	right:		0px;
	bottom:		0px;
	overflow:	hidden;
	z-index:	1;
	}

#cms_header {
	position:	absolute;
	top:		0px;
	left:		0px;
	right:		0px;
	padding:	0px;
	margin:		0px;
<?php if ($theme['ThemeSettings']['NAV_BAR_BESIDE_LOGO_BOOL'] == 'true') { ?>
	height: 0 !important;
<?php } else { ?>
	height:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?> !important;   /* Height of the header */
<?php } ?>
	overflow:	visible;	/* visible for drop downs from page header */
	z-index:	60;
	}

#cms_left_column {
	position:	absolute;
	top:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?>;
	left:		0px;
	width:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	overflow-y: auto;
	overflow-x: hidden;
	padding:	0px;
	margin:		0px;
	z-index:	50;
	overflow:	visible;
	}

#cms_right_column {
	position:	absolute;
	top:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?>;
	right:		0px;
	width:		<?php echo $theme['ThemeSettings']['RIGHT_WIDTH']; ?>;
	overflow-y: auto;
	overflow-x: hidden;
	padding:	0px;
	margin:		0px;
	z-index:	50;
	overflow:	visible;
	}

#cms_navbar_wlc {	/* with left column */
	position:	absolute;
	top:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?>;
	left:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	right:		0px;
	height:		<?php echo ($cms_nav_bar ? $theme['ThemeSettings']['NAV_BAR_HEIGHT']:'0px'); ?>;
	overflow:	visible;
	padding:	0px;
	margin:		0px;
	z-index:	100;
	}

#cms_navbar_nolc {	/* with no left (and no right) column */
	position:	absolute;
	top:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?>;
	left:		0px;
	right:		0px;
	min-height:		<?php echo ($cms_nav_bar ? $theme['ThemeSettings']['NAV_BAR_HEIGHT']:'0px'); ?>;
	overflow:	visible;
	padding:	<?php echo $pad; ?>px;
	margin:		0px;
	z-index:	100;
	}

#cms_navbar_wlrc {	/* with left and right column */
	position:	absolute;
	top:		<?php echo $theme['ThemeSettings']['HEADER_HEIGHT']; ?>;
	left:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	right:		<?php echo $theme['ThemeSettings']['RIGHT_WIDTH']; ?>;
	height:		<?php echo ($cms_nav_bar ? $theme['ThemeSettings']['NAV_BAR_HEIGHT']:'0px'); ?>;
	overflow:	visible;
	padding:	0px;
	margin:		0px;
	z-index:	100;
	}

#cms_link_frame {	/* inside an absolute page body */
	z-index:	3;
	width:		100%;
	}

#cms_link_frame_wlc {	/* with left column */
	position:	absolute;
	top:		<?php echo $body_top; ?>;
	left:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	right:		0px;
	padding:	<?php echo $pad; ?>px;
	bottom:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?>;
/*	bottom:		<?php echo $pad; ?>px; */
	z-index:	3;
	}

#cms_link_frame_wlrc {	/* with left and right column */
	position:	absolute;
	top:		<?php echo $body_top; ?>;
	left:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	right:		<?php echo $theme['ThemeSettings']['RIGHT_WIDTH']; ?>;
	padding:	<?php echo $pad; ?>px;
	bottom:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?>;
/*	bottom:		<?php echo $pad; ?>px; */
	z-index:	3;
	}

#cms_link_frame_nolc {	/* with no left (and no right) column */
	position:	absolute;
	top:		<?php echo $body_top; ?>;
	left:		0px;
	right:		0px;
	padding:	<?php echo $pad; ?>px;
	bottom:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?>;
/*	bottom:		<?php echo $pad; ?>px; */
	z-index:	3;
	}

#cms_page_body_wlc {	/* with left column */
	position:	absolute;
	top:		<?php echo $body_top; ?>;
	left:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	right:		0px;
	padding:	0px;
	margin:		0px;
	/* bottom:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?>; */
	max-height: calc(100vh - <?php echo $hnf; ?>);
	overflow:	auto;
	z-index:	2;
	}

#cms_page_body_wlrc {	/* with left and right column */
	position:	absolute;
	top:		<?php echo $body_top; ?>;
	left:		<?php echo $theme['ThemeSettings']['LEFT_WIDTH']; ?>;
	right:		<?php echo $theme['ThemeSettings']['RIGHT_WIDTH']; ?>;
	padding:	0px;
	margin:		0px;
	/* bottom:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?>; */
	max-height: calc(100vh - <?php echo $hnf; ?>);
	overflow:	auto;
	z-index:	2;
	}

#cms_page_body_nolc {	/* with no left (and no right) column */
	position:	absolute;
	top:		<?php echo $body_top; ?>;
	left:		0px;
	right:		0px;
	padding:	<?php echo $pad; ?>px;
	margin:		0px;
	/* bottom:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?>; */
	max-height: calc(100vh - <?php echo $hnf; ?>);
	overflow:	auto;
	z-index:	2;
	}

#cms_footer {
	position:	absolute;
	height:		<?php echo $theme['ThemeSettings']['FOOTER_HEIGHT']; ?> !important;
	left:		0px;
	right:		0px;
	bottom:		0px;
	overflow:	hidden;
	z-index:	50;
	}

.link_frame_moz {
	}

.link_frame_tablet {
	-webkit-overflow-scrolling: touch;
	}

.iframe_tablet {
	max-width:		100%;
	border-width: 0;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

.iframe_moz {
	max-width: calc(100% - 5px);
	border-width: 0;
	min-height: calc(100vh - <?php echo $hnf; ?>);
	}

/* eof */

