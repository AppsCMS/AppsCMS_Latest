<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: cms_msgs.php 1961 2021-01-25 10:09:54Z robert0609 $
 */

?>
<?php if((Ccms::$body_default_msgs) && (Ccms::getMsgsCount())) { ?>
<?php Ccms::page_start_comment(__FILE__); ?>
	<?php echo Ccms::getMsgsStack(); ?>
<?php Ccms::page_end_comment(__FILE__); ?>
<?php	} // if ?>

