Applications Management System Library for PHP (AppsCMS) - READ ONLY LIBRARY NOTES
==================================================================================
see Licence in cms/LICENCE.txt
<!-- SVN Build: $Id: cms_lib_sqsh.md 2054 2021-04-09 04:42:32Z robert0609 $ -->

Extract from the (DOCROOT)/cms/Installation.md file.

Read Only AppsCMS Library:
==========================

The AppsCMS library comes with a read only installation option.
To run the read only option the fuse and squashfuse system packages need to be install to provide the fusermount and squashfuse commands.

The presence of (DOCROOT)/cms/cms_index.php is used as a semaphore to indicate that the AppsCMS library is available as read/write.
 If (DOCROOT)/cms/cms_index.php is not present,
 and if the "fusermount" and "squashfuse" utilities are available,
 the AppsCMS is installed as a read only filesystem using (DOCROOT)/cms_lib_sqsh.sqsh
 is mounted at (DOCROOT)/cms/ directory (using the squashfuse utility) and remains persistent for further web calls.
 This makes the AppsCMS code library in (DOCROOT)/cms/ read only and tamper proof.

The mounting and access to the read only (DOCROOT)/cms/ code directory is done by first access to the AppsCMS via the (DOCROOT)/index.php.
If the (DOCROOT)/index.php is customised (usually the case), the read only library engagement can initiated by
adding "include('cms_lib_sqsh.php');" as the first executed line in (DOCROOT)/index.php. Depending on the web application
it maybe necessary to add the first line executed code to login.php, logout.php and any web accessible php code (e.g. ajax code).
Noting that if the (DOCROOT)/index.php is always called first in a session, this will mount the read only AppsCMS library for all further calls until the web server is restarted.

Notes:

*	If (DOCROOT)/index.php is present, it is not overwritten by updates and must be manually edited
to engage the read only (DOCROOT)/cms/ directory (as above).
*	If the AppsCMS zip file is used (not the .sh installer) the cms_lib_sqsh.sqsh file is not used,
the cms_lib.sqsh.sh, cms_lib_sqsh.php and cms_lib_sqsh.sqsh files (and engagement code) can be removed.
*	If the AppsCMS was previously using a read/write filesystem (not squashed, indicated by the presence of (DOCROOT)/cms/cms_index.php),
the read only library is not used. If the read only library is required, move (or delete) (DOCROOT)/cms/ directory
and reinstall/update the AppsCMS (using the .sh installer then noting the engagement requirements above).
*	The first web call mounts the read only library in the web server user space and will not be available to (nor seen by) normal users.
 The read only library mount done by the web server can be umounted by restarting the web server.
*	If the CLI scripts in the (DOCROOT)/cms/cli/ directory are required, run the (DOCROOT)/cms_lib_sqsh.sh script to mount the
 (DOCROOT)/cms/ directory with the AppsCMS library as the normal (non web server) user.
 To umount a user mounted read only filesystem run "fusermount -u cms"
*	If AppsCMS read only library is required for debugging, run the (DOCROOT)/cms_lib_sqsh.sh script to mount the
 (DOCROOT)/cms/ directory with the AppsCMS library as the normal user.
 The is will allow the IDE and debugger access to the read only AppsCMS library.
 Otherwise copy the cms directory in the AppsCMS zip file to the (DOCROOT)/cms/ directory (giving read/write access).
*	The user_allow_other is required in /etc/fuse.conf to allow sharing of cms_lib_sqsh.sqsh library mount between command line and web server.

The cms_rebuild.sh and cms_set_permissions.sh scripts in the (DOCROOT) are to make it easier for common command line rebuilds.

Important Note:

The Apache web server will needed to be stopped and started after a read only install or update.
The server will need to be totally disengaged (i.e. a full stop, e.g. service httpd stop).
The normal restart only reloads the web server configuration files and will not release the previous squashfs mounts.
Also, if php-fpm is install, php-fpm needs to be stopped and started to release previous php to bytecode caches.

.EOF.

