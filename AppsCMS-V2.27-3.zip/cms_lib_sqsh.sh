#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	SVN Build: $Id: cms_lib_sqsh.sh 2085 2021-07-06 16:24:36Z robert0609 $

# squashfuse mount script for Applications Management System Library for PHP (AppsCMS)
# run from web root directory.
# Requirement: system package squashfuse to be installed.
# NOTE: if the cms_lib_sqsh.sqsh needs to be umount, run 'fusermount -u ./cms'

# set -x

FVERSION="V2.27-2"
DT="$(date '+%Y%m%d')"
DLOG="./var/logs"
LOG="${DLOG}/CLI_cms-${DT}.log"
C_D="./cms"
if [ ! -d "$DLOG" ]; then mkdir -p "$DLOG"; fi

function out_msg() { # $1=msg
	local DTI="$(date '+%Y%m%d-%H%M%S')"
	if [ ${#} -eq 0 ]; then
		while read -r L
		do
			echo "${L}"
			echo "${DTI}: sqsh, ${L}" >> "$LOG"
		done
	else
		echo "${1}"
		echo "${DTI}: sqsh, ${1}" >> "$LOG"
	fi
	return $?
} # out_msg()

function restart_httpd() {	#
	fusermount -u cms
	for D in httpd apache apache2 php-fpm
	do
		which $D 2> /dev/null > /dev/null
		if [ $? -eq 0 ]; then
			echo "Stop/start $D."
			sudo service $D stop
			sleep 2
			sudo service $D start
		fi
	done
	return 0
} # restart_httpd()

function mount_cms() { #
	# fusermount -u cms	# test
	if [ -n "$(findmnt ./cms | grep squash)" ]; then
		return 0	# already mounted
	fi
	if [ ! -f cms/cms_index.php ]; then	# nothing in the cms/ directory
		which fusermount > /dev/null
		if [ $? -ne 0 ]; then
			echo "ERROR: \"fusermount\" not available, cannot mount read only library."
			exit 2
		fi
		which squashfuse > /dev/null
		if [ $? -ne 0 ]; then
			echo "ERROR: \"squashfuse\" not available, cannot mount read only library."
			exit 3
		fi
		if [ ! -d "$C_D" ]; then 	# make sure the mount point is there
			mkdir -m 0777 "$C_D"
			# # U="$(stat -c %u ./)"	# get parent user id
			# G="$(stat -c %g ./)"	# get parent group id
			# # chown $U:$G "$C_D"
			# chgrp $G "$C_D"
			# # echo "PG=$G"	# test
		fi
		chmod 0777 "$C_D"

		squashfuse -o allow_other cms_lib_sqsh.sqsh "$C_D"
		if [ $? -ne 0 ]; then
			echo "ERROR: Failed to mount cms_lib_sqsh.sqsh."
			exit $RET
		fi
		echo "INFO: Mounted cms_lib_sqsh.sqsh."
	fi
	echo "Note 1: to umount user mounted "$C_D", run \"./cms_lib_sqsh.sh -u\"."
	echo "Note 2: to umount apache/php-fpm mounted "$C_D", run \"./cms_lib_sqsh.sh -s\" (sudo required, stop/start apache[/php-fpm])."
	echo -e "Note 3: results logged in \"$LOG\"."
	return 0
} # mount_cms()

function help() { #
	echo "Help for AppsCMS read only CLI library mounter ($FVERSION)."
	echo "Usage: cms_lib_sqsh.sh [-s|--restart-services (sudo required)] [-r|--rebuild-cms (sudo required)] [-u|--umount-cms] [-m|--mount-cms (default)] [-h|--help]"
} # help()

if [ -z "$1" ]; then
	mount_cms 2>&1 | out_msg
	exit $?
fi

# out_msg "$(basename "$0") $1"	# test
while [ ! -z "$1" ]
do
	case "$1" in
	-s|--restart-services )
		restart_httpd 2>&1 | out_msg
		exit $?
		;;
	-r|--rebuild-cms )
		mount_cms 2>&1 | out_msg
		cms/cli/cms_rebuild.sh --set-perms 2>&1 | out_msg
			if [ -n "$(findmnt "$C_D" | grep squash)" ]; then
				fusermount -u "$C_D" 2>&1 | out_msg
				rmdir "$C_D" 2>&1 | out_msg
			fi
		exit $?
		;;
	-m|--mount-cms )
		mount_cms 2>&1 | out_msg
		exit $?
		;;
	-u|--umount-cms )
		if [ -d "$C_D" ]; then
			if [ -n "$(findmnt "$C_D" | grep squash)" ]; then
				fusermount -u "$C_D" 2>&1 | out_msg
			fi
			rmdir "$C_D" 2>&1 | out_msg
			exit $?
		fi
		exit 0
		;;
	-h|--help )
		help | out_msg
		exit 0
		;;
	* )
		if [ ! -z "$1" ]; then help; exit 1; fi	# don't know this option
		;;
	esac
	shift
done

# EOF
