<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_lm.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

$chgs = Ccms_recents_links::get_recent_changes();
?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php if((LM_C_FILTER_OUTPUT) ||
	((LM_C_RECENT_CHANGES_ENABLED) && ($chgs)) ||
	(LM_C_SHOW_SECT_COLL_EXP_BUTTON)) { ?>
<form method="post" name="filter" action="<?= Ccms_base::get_base_url() ?>">
<input type="hidden" name="cms_action" value="lm_show_links">
<table class="page_body">
	<caption>Links manager body</caption>
	<tr class="page_body">
		<td class="page_body" style="text-align: left">
			<div style="">
<?php if(LM_C_FILTER_OUTPUT) { ?>
				<label style="display: inline-block; margin: 2px;">
					Filters:
					<input type="text" name="keywords" size="40"
						value="<?= Ccms::get_or_post ('keywords') ?>"
						title="Enter filter keywords, <?= (LM_C_FILTER_ANDED ? 'all words must appear':'any word may appear') ?>."
						oninput="javascript:get_lm_filtered_links_page();"
						autofocus autocapitalize="off" autocomplete="off"/>
					<img alt="loading" id="ajax-loader" src="cms/images/ajax-loader.gif" style="display: none"/>
					<button id="find_button" name="filter" value="filter" type="submit" title="Start find filter.">Find</button>
				</label>
<?php	} // if ?>
<?php if(LM_C_SHOW_SECT_COLL_EXP_BUTTON) { ?>
				<label style="display: inline-block; margin: 2px;">
					<button id="collapse_all_button" name="collapse_all" type="button" onclick="collapse_lm_sect_all();" title="Collapse all sections.">Collapse</button>
				</label>
				<label style="display: inline-block; margin: 2px;">
					<button id="expand_all_button" name="expand_all" type="button" onclick="expand_lm_sect_all();" title="Expand all sections.">Expand</button>
				</label>
<?php	} // if ?>
<?php if((LM_C_RECENT_CHANGES_ENABLED) && ($chgs)) { ?>
				<label style="display: inline-block; margin: 2px;">
					Recent Changes:
					<?= $chgs ?>
				</label>
<?php	} // if ?>
			</div>
		</td>
	</tr>
</table>
</form>
<?php	} // if ?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<div id="page_contents_ajax">
<?php	include_once(CMS_FS_INCLUDES_DIR . "cms_filtered_links.php") ?>
</div>

<?php
Ccms::page_end_comment(__FILE__);
