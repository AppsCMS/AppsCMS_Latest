<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_links.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

$cCMS_C = new Ccms_config_funcs();

$lm_link_id = 0;
$lm_link_op = '';
$lm_group_id = 0;
$lm_link_id = 0;
$lm_link_clone = false;
$lm_link_clone_from_id = Ccms::get_or_post("lm_link_clone_from_id");
$lm_link_clone_insert = ((Ccms::get_or_post("lm_link_clone") == 'true') ? true:false);

Ccms_export::export_table('lm_links');
if(Ccms::get_cms_action() == 'cms_edit_links') { // a bit of caution
	if((Ccms::is_get_or_post('delete')) &&
		((Ccms::is_get_or_post('link_edit_id')) || (Ccms::is_get_or_post('lm_link_id')))) {
		$lm_link_op = 'delete';
		$lm_link_id = (int)(Ccms::is_get_or_post('lm_link_id') ? Ccms::get_or_post('lm_link_id'):Ccms::get_or_post('link_edit_id'));

		$sql_query = "SELECT  lm_link_name,lm_link_enabled" .
					" FROM  lm_links WHERE  lm_link_id = '" . (int)$lm_link_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($link = Ccms::$cDBcms->fetch_array($result))) {
			$lm_link_name = $link['lm_link_name'];
			$lm_link_enabled = $link['lm_link_enabled'];
			} // if
		} // else if
	else if((Ccms::is_get_or_post('confirm_delete')) && (Ccms::is_get_or_post('lm_link_id'))) {
		$lm_link_op = 'confirm_delete';
		$lm_link_id = (int)Ccms::get_or_post('lm_link_id');

		$sql_query = "DELETE FROM  lm_links WHERE  lm_link_id = '" . (int)$lm_link_id . "'";
		Ccms::$cDBcms->query($sql_query);
		new Ccms_xml_sitemap();	// do sitemap
		$lm_link_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('add')) {
		$cols = Ccms::$cDBcms->get_columns_list('lm_links',true);
		foreach($cols as $c => $v) $$c = $v;
		$lm_link_enabled = 1;
		$lm_link_add_name2url = 0;

		$sql_query = "SELECT MAX(lm_link_order) AS max_lm_link_order FROM  lm_links";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			($row = Ccms::$cDBcms->fetch_array($result))) {
			$lm_link_order = $row['max_lm_link_order'] + 100;	// next app
			} // if
		else Ccms::$cDBcms->free_result($result);

		$lm_link_op = 'add';
		$lm_link_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('insert')) && (Ccms::is_get_or_post('lm_link_id'))) {
		$lm_link_op = 'insert';
		} // else if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('lm_link_id'))) {
		$lm_link_op = 'save';
		} // else if
	else if((Ccms::is_get_or_post('clone')) && (Ccms::is_get_or_post('lm_link_id'))) {
		$lm_link_op = 'clone';
		$lm_link_clone = true;
		} // else if
	else if((CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$lm_link_op = 'reloadDB';
		$lm_link_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$lm_link_op = 'cancel';
		$lm_link_id = 0;
		Ccms::do_cms_return_action();
		} // else if
	else if(Ccms::is_get_or_post('import')) {
		$lm_link_op = 'import';
		$lm_link_id = 0;
		if(Ccms_export::import_table('lm_links')) {
			// nothing yet
			} // if
		} // else if
	else if(Ccms::is_get_or_post('import_bookmarks')) {
		$lm_link_op = 'import_bookmarks';
		$lm_link_id = 0;
		if(Ccms_export::import_bookmarks()) {
			// nothing yet
			} // if
		} // else if
	else if(Ccms::is_get_or_post('lm_link_qk_op')) {
		$qk_op = Ccms::get_or_post('lm_link_qk_op');
		$lm_link_qk_id = Ccms::get_or_post('lm_link_qk_id');
		switch($qk_op) {
		case 'edit_link_qk_section':
			$lm_link_qk_section_id = Ccms::get_or_post('lm_link_qk_section_id');
			$sql = 'UPDATE lm_links SET lm_link_section_id = ' . $lm_link_qk_section_id . ' WHERE lm_link_id = ' . $lm_link_qk_id;
			if(!Ccms::$cDBcms->query($sql)) {
				Ccms::addAdminMsg('Failed to update lm_link_section_id in lm_links.');
				} // if		
			break;
		default: break;
			} // switch
		$lm_link_id = 0;
		$lm_link_op = '';
		} // else if
	else if(Ccms::is_get_or_post('import_bookmarks_selected')) {
		$lm_link_op = 'import_bookmarks_selected';
		$lm_link_id = 0;
		} // else if
	else if(($lm_link_id = (int)Ccms::get_or_post('link_edit_id')) > 0) {
		$lm_link_op = 'edit';

		$sql_query = "SELECT  lm_link_name,lm_link_section_id, lm_link_url, lm_link_order" .
			", lm_link_name , lm_link_description, lm_link_title" .
			", lm_link_image_url, lm_link_icon_url, lm_link_new_page" .
			", lm_link_ssl, lm_link_enabled, lm_link_add_name2url" .
			", lm_link_comments" .
			", " . Ccms::$cDBcms->get_db_sql_localtime('lm_link_added','lm_link_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('lm_link_updated','lm_link_updated') .
			" FROM  lm_links WHERE  lm_link_id = '" . (int)$lm_link_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($link = Ccms::$cDBcms->fetch_array($result))) {
			foreach($link as $k => &$v) $$k = $v;
			Ccms::$cDBcms->free_result($result);
			} // if
		else { // not found
			$lm_link_id = 0;
			$lm_link_op = '';
			$lm_link_added = '';
			$lm_link_updated = '';
			$lm_group_id = 0;
			$lm_link_id = 0;
			} // else
		} // if

	if(($lm_link_op == 'save') || ($lm_link_op == 'clone') || ($lm_link_op == 'insert')) {
		// do it once
		$lm_link_id = (int)Ccms::get_or_post('lm_link_id');
		$lm_link_url = $cCMS_C->get_url('lm_link_url',Ccms::$cDBcms->get_data_in_table('lm_links','lm_link_url','lm_link_id = ' . (int)$lm_link_id));
		$lm_link_name = html_entity_decode(Ccms::get_or_post('lm_link_name'));
		$lm_link_description = html_entity_decode(Ccms::get_or_post('lm_link_description'));
		$lm_link_title = html_entity_decode(Ccms::get_or_post('lm_link_title'));
		$lm_link_order = (int)Ccms::get_or_post('lm_link_order');
		$lm_link_section_id = (int)Ccms::get_or_post('lm_link_section_id');
		$lm_link_ssl = Ccms::get_or_post_checkbox('lm_link_ssl');
		$lm_link_enabled = Ccms::get_or_post_checkbox('lm_link_enabled');
		$lm_link_new_page = Ccms::get_or_post_checkbox('lm_link_new_page');
		$lm_link_add_name2url = Ccms::get_or_post_checkbox('lm_link_add_name2url');
		$lm_link_added = html_entity_decode(Ccms::get_or_post('lm_link_added'));
		$lm_link_updated = html_entity_decode(Ccms::get_or_post('lm_link_updated'));
		$lm_link_image_url = $cCMS_C->get_image('lm_link_image_url',Ccms::$cDBcms->get_data_in_table('lm_links','lm_link_image_url','lm_link_id = ' . (int)$lm_link_id),ETC_WS_IMAGES_DIR);
		$lm_link_icon_url = $cCMS_C->get_image('lm_link_icon_url',Ccms::$cDBcms->get_data_in_table('lm_links','lm_link_icon_url','lm_link_id = ' . (int)$lm_link_id),ETC_WS_ICONS_DIR);
		$lm_link_comments = Ccms::get_or_post('lm_link_comments');

		if($lm_link_op != 'clone') {
			if($lm_link_section_id == 0) {
				Ccms::addMsg('Select a section.');
				} // if
			Ccms_DB_checks::is_link_name_ok($lm_link_name,$lm_link_op,"lm_link_id != " . (int)$lm_link_id);
			if((!$lm_link_new_page) && (!Ccms::is_iframeable_url($lm_link_url))) {
				if(CMS_C_EXT_URL_NEW_PAGE) {
					$lm_link_new_page = 1;
					Ccms::addMsg ('URL has been changed to new tab/window.','info');
					} // if
				} // if

			if(!Ccms::getMsgsCount('error')) {	// update it
				$fields = array();
				$fields['lm_link_name'] = $lm_link_name;
				$fields['lm_link_url'] = $lm_link_url;
				$fields['lm_link_description'] = $lm_link_description;
				$fields['lm_link_title'] = $lm_link_title;
				$fields['lm_link_image_url'] = $lm_link_image_url;
				$fields['lm_link_icon_url'] = $lm_link_icon_url;
				$fields['lm_link_order'] = $lm_link_order;
				$fields['lm_link_section_id'] = $lm_link_section_id;
				$fields['lm_link_ssl'] = $lm_link_ssl;
				$fields['lm_link_enabled'] = $lm_link_enabled;
				$fields['lm_link_new_page'] = $lm_link_new_page;
				$fields['lm_link_add_name2url'] = $lm_link_add_name2url;
				$fields['lm_link_comments'] = $lm_link_comments;

				if(($lm_link_op == 'insert') &&
					(!Ccms::$cDBcms->perform('lm_links',$fields,'insert',''))) {
					Ccms::addMsg('Link insert, ' . $lm_link_name . " failed");
					} // if
				else if(($lm_link_op == 'save') &&
					(!Ccms::$cDBcms->perform('lm_links',$fields,'update',"lm_link_id = " . (int)$lm_link_id . ""))) {
					Ccms::addMsg('Link update, ' . $lm_link_name . " failed");
					} // if
				else {
					// Ccms_base::unset_cms_sess_var('lm_link_id');
					Ccms_export::export_table('lm_links');
					Ccms::addMsg('Saved link config.','success');
					Ccms::do_cms_return_action();
					} // else
				new Ccms_xml_sitemap();	// do sitemap
				$lm_link_id = 0;
				$lm_link_op = '';
				$lm_link_clone_insert = false;
				$lm_link_clone = false;
				} // if
			} // if
		if((($lm_link_op == 'clone') || ($lm_link_clone_insert)) &&
			(((int)$lm_link_clone_from_id > 0) || ((int)$lm_link_id > 0))) {
			$lm_link_clone_from_id = (((int)$lm_link_clone_from_id > 0) ? $lm_link_clone_from_id:$lm_link_id);
			$lm_link_clone = true;	// retry !!
			$lm_link_op = 'insert';
			$lm_link_id = 0;
			Ccms::addMsg('Cloning user "' . $lm_link_name . '".','info');
			} // if
		} // if
	} // if
$cnt = Ccms::$cDBcms->get_row_count_in_table('lm_links');
if(!($lm_link_cnt = Ccms::$cDBcms->get_row_count_in_table('lm_links'))) {
	Ccms::addMsg('No sections setup','warning');
	} // if

if($lm_link_op == 'import_bookmarks_selected') {
	include(CMS_FS_OPS_DIR . 'cms_edit_links_import_bm.php');
	Ccms::unset_get_or_post('import_bookmarks_selected');
	return;
	} // else if
?>

<?php Ccms::page_start_comment(__FILE__) ?>

<style>
	.long_input {
		width: 250px;
		}
</style>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Links Config</h1>
		</th>
	</tr>
	<?php if($lm_link_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php Ccms::$cDBcms->installDatabase('lm_links',true ,true) ?>
		</td>
	</tr>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<?php } // if ?>
	<form method="post" name="edit_link" action="index.php" enctype="multipart/form-data">
	<input type="hidden" name="cms_action" value="cms_edit_links">
	<?= Ccms_search::get_form_search_hidden_inputs() ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Select link name:&nbsp;
			<?=  Ccms::gen_link_selection_list('link_edit_id',$lm_link_id,'size="1"') ?>
			<?php if($cnt > 0) { ?>
			&nbsp;&nbsp;
<!--			<button name="edit" value="edit" type="submit">Edit</button>
			&nbsp;&nbsp;-->
			<button name="delete" value="delete" type="submit">Delete</button>
			<?php	} //if ?>
			&nbsp;&nbsp;
			<button name="add" value="add" type="submit">Add</button>
			<?php Ccms::get_return2search_link() ?>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php if(CMS_S_ALLOW_TABLE_RELOAD_BOOL) { ?>
			Link table operations:&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" title="Clear and re-initialise links table in database." onClick="return confirm('Clear and re-initialise links table in database?')">Reload</button>
			<?php	} // if ?>
			<?= Ccms_export::get_table_form_text('lm_links') ?>
		</td>
	</tr>

	<?php
	if((($lm_link_op == 'edit') || ($lm_link_op == 'save') ||
		($lm_link_op == 'add') || ($lm_link_op == 'insert')) &&
		(isset($lm_link_id))) {
		$row = 0;
	?>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<tr class="page_config">
		<th class="page_config">
			<?php if($lm_link_id == 0) {
				echo 'Add Link';
				} // if
			else {
				echo 'Edit Link' .
					'&nbsp;&nbsp;<span class="page_config">(Added:&nbsp;' . $lm_link_added .
					'&nbsp;&nbsp;Updated:&nbsp;' . $lm_link_updated . ')</span>';
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $lm_link_name))
					Ccms::get_return2search_link(true);
				} // else
			?>
		</th>
	</tr>
	<input type="hidden" name="lm_link_id" value="<?= $lm_link_id ?>"/>
	<input type="hidden" name="lm_link_name_old" value="<?= htmlentities($lm_link_name) ?>"/>
	<input type="hidden" name="lm_link_added" value="<?= htmlentities($lm_link_added) ?>"/>
	<input type="hidden" name="lm_link_updated" value="<?= htmlentities($lm_link_updated) ?>"/>
<?php if ($lm_link_clone) { ?>
	<input type="hidden" name="lm_link_clone" value="true"/>
	<input type="hidden" name="lm_link_clone_from_id" value="<?= $lm_link_clone_from_id ?>"/>
<?php	} // if ?>
	<?php Ccms::set_form_cms_return_action() ?>
	<tr class="page_config page_config_sticky">
		<td class="page_config">
			<div class="cms_sticky_left">
				<?php if($lm_link_id == 0) { ?>
				<button name="insert" value="insert" type="submit">Add</button>
				<?php } else { ?>
				<button name="save" value="save" type="submit">Save</button>
				&nbsp;&nbsp;
				<button name="clone" value="clone" type="submit">Clone</button>
				<?php	} // else ?>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
			</div>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<table class="page_config page_config_edit">
<?php if($lm_link_clone) { ?>
				<tr class="page_config">
					<th class="page_config">Cloning Link:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Make changes to the cloned link of "' . $lm_link_name . '" to ensure uniqueness.','info') ?>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Link Name:</th>
					<td class="page_config">
						<input type="text" class="long_input" name="lm_link_name" size="40" value="<?= $lm_link_name ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Unique link name. Appears on page as a link heading. Minimum of <?= LM_C_MIN_NAME_LEN ?> characters
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Link URL:</th>
					<td class="page_config">
						<input type="text" class="long_input" name="lm_link_url" size="60" value="<?= $lm_link_url ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						 Link URL. The clickable link the new web page. Minimum of 8 characters, if not on this server needs to be a full URI including the protocol (e.g. http:// , etc).
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Description:</th>
					<td class="page_config">
						<input type="text" class="long_input" name="lm_link_description" size="80" value="<?= $lm_link_description ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						 Link description (optional), appears next to the name.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Title:</th>
					<td class="page_config">
						<input type="text" class="long_input" name="lm_link_title" size="80" value="<?= $lm_link_title ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						 Link title (optional), appears when mouse is hovered over link name or image.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<?php echo Ccms_html::get_textarea_input('lm_link_comments',$lm_link_comments,false,' rows="2" autocapitalize="off"'); ?>>
					</td>
					<td class="page_config">
						<?= Ccms::getAdminCommentHint('edit_links',$lm_link_name) ?>
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Image URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('lm_link_image_url', $lm_link_image_url, ETC_WS_IMAGES_DIR) ?>
					</td>
					<td class="page_config">
						Link image (optional). Images are stored in the <?= ETC_WS_IMAGES_DIR ?> directory.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Icon URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('lm_link_icon_url', $lm_link_icon_url, ETC_WS_ICONS_DIR) ?>
					</td>
					<td class="page_config">
						Link icon (optional). Icons are stored in the <?= ETC_WS_ICONS_DIR ?> directory.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th  class="page_config">Section:</th>
					<td class="page_config">
						<?=  Ccms::gen_section_selection_list('lm_link_section_id', $lm_link_section_id, 'size="1"', false, false, false) ?>
					</td>
					<td class="page_config">
						Select section the link appears in.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Display Order:</th>
					<td class="page_config">
						<input type="number" name="lm_link_order" size="5" value="<?= $lm_link_order ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						 Sorting order of link. Used to control the order of the link in the section. Low numbers at the top of the page, ascending down the page.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">SSL:</th>
					<td class="page_config">
						<input type="checkbox" name="lm_link_ssl"<?= ($lm_link_ssl == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						 Check to open URL using SSL encryption, uncheck to use the default.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">New Tab:</th>
					<td class="page_config">
						<input type="checkbox" name="lm_link_new_page"<?= ($lm_link_new_page == 1 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						 Check to open URL in a new browser tab or window, uncheck to show in the body as an iframe.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Add Name to URL:</th>
					<td class="page_config">
						<input type="checkbox" name="lm_link_add_name2url"<?= ($lm_link_add_name2url == 1 ? ' CHECKED':'');?> autocapitalize="off"/>
					</td>
					<td class="page_config">
						 Check to add link name to URL.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Enabled:</th>
					<td class="page_config">
						<input type="checkbox" name="lm_link_enabled"<?= ($lm_link_enabled > 0 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						 Check to enable link, uncheck to disable link.
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: right;">
			<?php if($lm_link_id == 0) { ?>
			<button name="insert" value="insert" type="submit">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit">Save</button>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
		</td>
	</tr>

	<?php }
		else if(($lm_link_op == 'delete') && (isset($lm_link_id)) && ($lm_link_id > 0)) { ?>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<tr class="page_config"><th class="page_config">Delete Link - <?= $lm_link_name ?></th></tr>
	<input type="hidden" name="lm_link_id" value="<?= $lm_link_id ?>"/>
	<input type="hidden" name="lm_link_name" value="<?= htmlentities($lm_link_name) ?>"/>
	<tr class="page_config">
		<td class="page_config">
			Please confirm.
			&nbsp;&nbsp;
			<button name="confirm_delete" value="confirm_delete" type="submit">Confirm Delete</button>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" >Cancel</button>
		</td>
	</tr>
	<?php	} else { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?= Ccms_lm_bookmarks::get_bookmark_form_text() ?>
		</td>
	</tr>
	<?php	} // else ?>
	</form>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
<?php	include(CMS_FS_OPS_DIR . 'cms_edit_links_list.php') ?>
		</td>
	</tr>
</table>

<?php Ccms::page_end_comment(__FILE__) ?>
