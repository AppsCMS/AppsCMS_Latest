<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_log_view.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

/**
 * Description of cms_log_view
 * general AppsCMS log file viewer and manager
 *
 * @author robert0609
 */

$filter = Ccms_search::get_form_search_input_keywords_ary();
$exact = Ccms::get_or_post_checkbox('exact');
if(!$filter) $filter = array();

function help() {
	$text = "Enter search keywords, separated by spaces, to search Dates, Names.";
	return $text;
	} // help()

function filter_log(&$filter,&$log_file,$exact) {
	if(empty($filter)) return true;	// show all
	$found = true;
	$str = strtolower(implode(' ',$log_file));
	return Ccms_search::search_cmp($filter, $str,$exact);
} // filter_log()

$log_path = VAR_FS_LOGS_DIR;
if((Ccms::is_get_or_post('delete_log_file')) && (!empty(Ccms::get_or_post('delete_log_file')))) {
	$log_file = Ccms::get_or_post('delete_log_file');
	Ccms::trash_path($log_path . $log_file,true);
	Ccms::unset_get_or_post('view_log_file');
	} // if
else if((Ccms::is_get_or_post('selected')) &&
	(Ccms::is_get_or_post('deleteSelected')) &&
	(Ccms::get_or_post('deleteSelected') == 'delete')) {
	$selected = Ccms::get_or_post('selected');
	foreach($selected as $log_file) {
		Ccms::trash_path($log_path . $log_file,true);
		} // if
	Ccms::unset_get_or_post('selected');
	} // if

// Ccms::get_or_post('download_log_file') done in cms_top.php

$view_log_file = Ccms::get_or_post('view_log_file');

$lines_max = Ccms::get_or_post('lines_max');
if(!$lines_max) $lines_max = 100;
//if($lines_max > 1000) $lines_max = 1000;
$last_line_num = (int)Ccms::get_or_post('last_line_num');
if($last_line_num < $lines_max) $lines_max = 100;

$line_start = 1;
if(Ccms::is_get_or_post('next')) $line_start += $lines_max;
else if(Ccms::is_get_or_post('prev')) $line_start -= $lines_max;
if($line_start < 1) $line_start = 1;
$line_end = $line_start + $lines_max - 1;

$log_files = array();
if($dh = opendir($log_path)) { // check log file location
	while (($file = readdir($dh)) !== false) {
		if(!Ccms::is_dir_usable($file)) continue;
		if(is_dir($log_path . $file)) continue;
		if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $file)) continue;
		if(!$fd = @fopen($log_path . $file, 'r')) continue;
		$stat = fstat($fd);
		$groupinfo = Ccms_posix::posix_getgrgid($stat['gid']);	// needs php-posix or php-process installed
		$userinfo = Ccms_posix::posix_getpwuid($stat['uid']);	// needs php-posix or php-process installed

		// make mode string
		$mode = '';
		// msb (left) side first
		$mode .= (($stat['mode'] & 512) ? 'S':' ');
		$mode .= (($stat['mode'] & 256) ? 'r':'-');
		$mode .= (($stat['mode'] & 128) ? 'w':'-');
		$mode .= (($stat['mode'] & 64) ? 'x':'-');
		$mode .= (($stat['mode'] & 32) ? 'r':'-');
		$mode .= (($stat['mode'] & 16) ? 'w':'-');
		$mode .= (($stat['mode'] & 8) ? 'x':'-');
		$mode .= (($stat['mode'] & 4) ? 'r':'-');
		$mode .= (($stat['mode'] & 2) ? 'w':'-');
		$mode .= (($stat['mode'] & 1) ? 'x':'-');
		// lsb (right) side last

		$log_file = array(
			'name' => $file,
			'size' => $stat['size'],
			'mtime' => date(DATE_RSS, $stat['mtime']),
			'mode' => $mode,	// sprintf('%0o',$stat['mode']),
			'uid' => $stat['uid'],
			'gid' => $stat['gid'],
			'user' => (isset($userinfo['name']) ? $userinfo['name']:$stat['uid']),
			'group' => (isset($groupinfo['name']) ? $groupinfo['name']:$stat['gid']),
			);
		fclose($fd);

		if($meta = filter_log($filter,$log_file,$exact)) {
			$log_file['meta'] = Ccms_search::make_meta_search_text($meta);
			$log_files[$file] = $log_file;
			} // if
		} // while
	closedir($dh);
	ksort($log_files);
	} // if

Ccms_base::set_download_dir(VAR_FS_LOGS_DIR);	// setup directory to download from
?>

<?php if(!Ccms::is_get_or_post('ajax')) { ?>
<?php Ccms::page_start_comment(__FILE__) ?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<script type="text/javascript">
	var last_ajax_run_call = null;
	var ajax_running = false;
	var ajax_deb = 1200;
	function ajax_run(id) {
		if(ajax_running) return;
		if(last_ajax_run_call != null) {	// clear it
			window.clearTimeout(last_ajax_run_call);
			last_ajax_run_call = null;
			} // if
		// restart if
		last_ajax_run_call = window.setTimeout(function(id) {
			// return;	// test
			ajax_running = true;
			var min_l = 2;
			var keywords = document.getElementById(id).value.toString();
			if((keywords.length < min_l) ||
				(keywords.length == 0)) {
				document.getElementById('page_contents_ajax').innerHTML = "Minimum of " + min_l + " characters required.";
				ajax_running = false;
				return;
				} // if
			var fb = document.getElementById('id_form_keywords');	// save in the form too
			if(fb) fb.value = keywords;
			keywords = encodeURI(keywords);
			var exact = document.getElementById(id + '_exact').checked;
			var body_url = 'cms_log_view&search=' + keywords + (exact ? '&exact=on':'');
			cms_ajax_body_page(body_url,'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
			ajax_running = false;
			return;
			},
		ajax_deb, id);
		} // ajax_run()
</script>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config" style="text-align: left">
			<h1 class="page_config">View Logs</h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form method="post" name="cms_log_view" action="index.php">
				<input type="hidden" name="cms_action" value="cms_log_view">
				<?= Ccms_search::get_form_search_hidden_inputs() ?>
				<input type="text"
					id="keywords_inp"
					name="keywords_inp" size="40"
					oninput="javascript:ajax_run('keywords_inp');"
					value="<?= implode(' ',$filter) ?>"
					style="width: unset;"
					title="<?= help() ?>" autofocus autocapitalize="off"/>
				<button name="search" value="search" type="submit" onclick="Ccms_cursor.setWait();" title="Start the search.">Search</button>
				<label>Exact:
					<input type="checkbox"  id="keywords_inp_exact" name="exact"
						onchange="this.form.submit();"
						title="Check for exact match." <?= (Ccms::get_or_post_checkbox('exact') ? ' CHECKED':'') ?>
						/>
				</label>
			</form>
		</td>
	</tr>
</table>
<span id="page_contents_ajax">
<?php	} // if ?>
	<table class="page_config">
<?php if((!empty($view_log_file)) && (is_readable($log_path . $view_log_file))) { ?>
		<form name="view_log_file" action="index.php" method="post" enctype="multipart/form-data">
		<input type="hidden" name="cms_action" value="cms_log_view">
		<input type="hidden" name="view_log_file" value="<?= urlencode($view_log_file) ?>"/>
		<input type="hidden" name="start_line" value="<?= $line_start ?>"/>
		<tr class="page_config">
			<td class="page_config">
				<select name="lines_max" onchange="this.form.submit()" style="width: 50px;" title="Log lines per page.">
<?php
		$lines_max_tab = array(10,20,50,100,200,500,1000);
		foreach($lines_max_tab as $ml) {
//			if((!empty($last_line_num)) && ($ml > $last_line_num)) break;
			echo '					<option value="' . $ml . '"' . (($ml == $lines_max) ? ' SELECTED':'') . '>' . $ml . '</option>';
			} // foreach
?>
				</select> lines.
				<?php	if($line_start > 1) { ?>
				<button type="submit" onclick="Ccms_cursor.setWait();" name="prev" value="prev" title="Click for previous page.">Previous</button>
<?php		} // if ?>
<?php	if($last_line_num > $line_end) { ?>
				<button type="submit" onclick="Ccms_cursor.setWait();" name="next" value="next" title="Click for next page.">Next</button>
<?php		} // if ?>
				</td>
			</tr>
			<tr class="page_config">
				<td class="page_config">
					<table class="page_config">
						<tr class="page_config" title="From log directory: <?= $log_path. ' (' . $lines_max . ' lines maximum)' ?>">
							<th class="page_config" style="text-align: center;">Line</th>
							<th class="page_config" style="text-align: left;"><?= $view_log_file ?></th>
						</tr>
<?php
			$fh = 0;
			if(preg_match('/\.zip$/i',$view_log_file)) {
				if(!class_exists('ZipArchive',false)) return;
				$log_file = preg_replace('/\.zip$/i','',$view_log_file);
				$zip = new ZipArchive;
				if($zip->open($log_path . $view_log_file) === true) {
					// $zip->extractTo(VAR_FS_TEMP_DIR,$log_file);
					for($i = 0; $i < $zip->numFiles; $i++) {
						$filename = $zip->getNameIndex($i);
						$fileinfo = pathinfo($filename);
						copy("zip://" . $log_path . $view_log_file ."#".$filename, VAR_FS_TEMP_DIR.$fileinfo['basename']);
						} // for
					$zip->close();
					$log_path = VAR_FS_TEMP_DIR;
					$view_log_file = $log_file;
					Ccms::chmod_chown($log_path . $log_file);
					} // if
				else echo '<tr><td>&nbsp;</td><td>Cannot unzip file.</td></tr>';
				} // if
			$fh = @fopen($log_path . $view_log_file, "r");
			$line_num = 0;
			if($fh) {
				$row = 0;
				while (($line = fgets($fh, 4096)) !== false) {
					$line_num++;
					if($line_start > $line_num) continue;	// find start line
					if($line_num > $line_end) continue;	// thats it, keep counting lines
?>
					<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
						<td class="page_config" style="text-align: center;"><?= $line_num ?></td>
						<td class="page_config" style="text-align: left;"><?= htmlentities($line) ?></td>
					</tr>
<?php
					} // while
				fclose($fh);
				if($line_num == 0) {
?>
					<tr class="page_config">
						<td class="page_config" style="text-align: center;"><?= $line_num ?></td>
						<td class="page_config" style="text-align: left;">File is empty.</td>
					</tr>
<?php
					} // if
				} // if
?>
				</table>
			</td>
		</tr>
		<input type="hidden" name="last_line_num" value="<?= $line_num ?>"/>
		<tr class="page_config">
			<td class="page_config">
<?php	if($line_start > 1) { ?>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="prev" value="prev" title="Click for previous page.">Previous</button>
<?php		} // if ?>
<?php	if($line_num > $line_end) { ?>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="next" value="next" title="Click for next page.">Next</button>
<?php		} // if ?>
			Total lines: <?= $line_num ?>
			</td>
		</tr>
		</form>
<?php	} // if ?>
		<tr class="page_config">
			<td class="page_config" style="text-align: left;">
<?php
		if(!empty($log_files)) {
?>
				<form name="view_log_file" action="index.php" method="post" enctype="multipart/form-data">
				<input type="hidden" name="cms_action" value="cms_log_view">
				<input type="hidden" name="view_log_file" value="<?= urlencode($view_log_file) ?>"/>
				<input type="hidden" name="start_line" value="<?= $line_start ?>"/>
				<input type="hidden" id="id_form_keywords" name="search" value="<?= implode(' ',$filter) ?>"/>

				<table class="page_config">
					<tr class="page_config">
						<th class="page_config" style="text-align: left;">&nbsp;</th>
						<th class="page_config" style="text-align: left;" title="The file read, write , execute modes for user, group and others.">Mode</th>
						<th class="page_config" style="text-align: left;" title="The user associated with the file.">User</th>
						<th class="page_config" style="text-align: left;" title="The group associated with the file.">Group</th>
						<th class="page_config" style="text-align: left;" title="Size of file in bytes.">Size</th>
						<th class="page_config" style="text-align: left;" title="Last time the file was modified.">Modified</th>
						<th class="page_config" style="text-align: left;" title="Log filename.\nNames starting with CLI are generated by comman line operations (CLI),\nothers start with the domain name used.">Name</th>
						<th class="page_config" style="text-align: center;" title="Actions on files.">Actions</th>
					</tr>
<?php
				$row = 0;
				foreach($log_files as $f => $d) {
?>
					<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
						<td class="page_config" style="text-align: left;">
							<input type="checkbox"
								   id="id_selected[<?= $row ?>]"
								   name="selected[<?= $row ?>]"
								   value="<?= rawurldecode($d['name']) ?>"
								   title="Select file."
								   >
						</td>
						<td class="page_config" style="text-align: left;"><?= $d['mode'] ?></td>
						<td class="page_config" style="text-align: left;"><?= $d['user'] ?></td>
						<td class="page_config" style="text-align: left;"><?= $d['group'] ?></td>
						<td class="page_config" style="text-align: left;"><?= $d['size'] ?></td>
						<td class="page_config" style="text-align: left;"><?= $d['mtime'] ?></td>
						<td class="page_config" style="text-align: left;"><?= $d['name'] . $d['meta'] ?></td>
						<td class="page_config" style="text-align: right;">
							<button type="submit" onclick="Ccms_cursor.setWait();" name="view_log_file" value="<?= urlencode($d['name']) ?>" title="Click to view file &quot;<?= urlencode($d['name']) ?>&quot;.">View</button>
							&nbsp;
							<button type="submit" onclick="Ccms_cursor.setWait();" name="download_file" value="<?= urlencode($d['name']) ?>" title="Click to download file &quot;<?= urlencode($d['name']) ?>&quot.">Download</button>
							&nbsp;
							<button type="submit" name="delete_log_file" value="<?= urlencode($d['name']) ?>" onclick="return confirm('Move file &quot;<?= urlencode($d['name']) ?>&quot; to Trash.');" title="Click to move file &quot;<?= urlencode($d['name']) ?>&quot; to Trash.">Delete</button>
						</td>
					</tr>
<?php
				} // foreach
?>
				</table>
				<label><button type="button" onclick="selectAll(this)">Select All</button></label>
				<label><button type="button" onclick="invertAll(this)">Invert All</button></label>
				<label><button type="submit" name="deleteSelected" value="delete" title="Move selected to trash.">Delete</button></label>
				</form>

				<script type="text/javascript">

					var rows = <?= $row ?>;

					function selectAll(obj) {

						for ( var i = 1; i <= rows; i++) {
							var elm = document.getElementById('id_selected[' + i + ']');
							if (!elm.checked) elm.click();
							} // for
						} // selectAll()

					function invertAll(obj) {
						for ( var i = 1; i <= rows; i++) {
							document.getElementById('id_selected[' + i + ']').click();
							} // for
						} // invertAll()

				</script>

<?php
			} // if
		else echo 'No log file found.'
?>
			</td>
		</tr>
	</table>

<?php
if(!Ccms::is_get_or_post('ajax')) {
	echo '</span>';
	Ccms::page_end_comment(__FILE__);
	} // if

