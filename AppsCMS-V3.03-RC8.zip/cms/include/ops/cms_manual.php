<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_manual.php 3117 2023-02-10 02:43:47Z robert0609 $
 */

define("CMS_WS_INCLUDE_MANUAL_DIR",		CMS_WS_DIR . 'include/manual/');
define("CMS_FS_INCLUDE_MANUAL_DIR",		CMS_FS_DIR . 'include/manual/');

define("APPS_MAN_DOCS_DIR",				APPS_WS_DIR . "docs/");	// for manual
define("APPS_MAN_INCLUDE_DIR",			APPS_WS_DIR . "include/");	// for manual
define("APPS_MAN_INI_DIR",				APPS_MAN_INCLUDE_DIR . "ini/");	// for manual
define("APPS_MAN_CLASSES_DIR",			APPS_MAN_INCLUDE_DIR . 'classes/');	// for manual
define("APPS_MAN_PLUGINS_DIR",			APPS_MAN_INCLUDE_DIR . 'plugins/');	// for manual
define("CMS_MAN_CLI_DIR",				CMS_WS_DIR . "cli/");	// for manual
define("CMS_MAN_INI_DIR",				CMS_WS_DIR . "include/ini/");	// for manual
define("ETC_MAN_WS_DIR",				ETC_DIR);	// for manual
define("ETC_MAN_INI_DIR",				ETC_DIR . "ini/");	// for manual
define("ETC_MAN_APPS_CONFIG",			ETC_DIR . 'ini/apps.ini');
define("ETC_MAN_EXT_INCLUDES_DIR",		ETC_DIR . 'ext/');	// for manual
define('ETC_MAN_SQLITE_DIR',			ETC_DIR . 'sqlite/');
define("CMS_MAN_EXAMPLE_BODIES_DIR",	CMS_WS_EXAMPLES_DIR . APPS_BODIES_WS_DIR);	// for manual
define('CMS_MAN_EXAMPLES_ZIP',			CMS_WS_EXAMPLES_DIR . CMS_PROJECT_SHORTNAME . '-Examples-' . CMS_PROJECT_VERSION . '.zip');	// for manual
define("VAR_WS_USERS_DIR",				VAR_WS_DIR . "variables/users/");

function insert_man_drop_box($h_typ,$h_title,$inc_file) {
	static $idx = 0;

	if(!file_exists($inc_file)) return false;

	echo <<< EOTXT

				<{$h_typ} class="page_config"
					onclick="man_sect_toggle(this, 'id_blk_{$idx}','id_blk_updown_img{$idx}');"
					>{$h_title}
					<img id="id_blk_updown_img{$idx}" class="api" src="cms/images/DbChevDn.gif">
				</{$h_typ}>
				<div id="id_blk_{$idx}" style="display: none;">

EOTXT;

				include($inc_file);

	echo '				</div>';

	$idx++;
	return true;
	} // insert_man_drop_box()

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<style>
	ul.cols {
		column-width: 220px;
		}
	img.api {
		height: 10px;
		background-color: lightgreen;
		}
	div.diagram {
		width: 100%;
		margin: auto;
		text-align: center;
		}
	img.diagram {
		max-width: 90%;
		padding: 5px;
		border-radius: 5px;
		border: 2px solid lightgreen;
		}
</style>

<script type="text/javascript">
	function man_sect_toggle(obj, id, img) {
		var x = document.getElementById(id);
		var i = document.getElementById(img);
		if (x.style.display === "none") {
			x.style.display = "block";
			i.src = "<?= CMS_WS_DIR ?>images/DbChevUp.gif"
		} // if
		else {
			x.style.display = "none";
			i.src = "<?= CMS_WS_DIR ?>images/DbChevDn.gif"
		} // else
	} // man_sect_toggle()
</script>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<caption>Manual for <?= strip_tags(CMS_PROJECT_SHORTNAME) ?> page</caption>
	<tr class="page_config">
		<th class="page_config">
			<img height="150px" src="<?= CMS_IMAGE_LOGO ?>" alt="<?= CMS_PROJECT_SHORTNAME ?> Logo">
			<h1 class="page_config" style="white-space: normal;">Technical Manual</h1>
			<br>
			<h2 class="page_config" style="white-space: normal;"><?php Ccms::prn_AppsCMS_title() ?></h2>
		</th>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Features"></a>
			Features
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> is a multiple application management library written in PHP for web applications and web worker sites.
				It provides base line functionality to improve security and provide most of the web server side configuration and operation code.
				Although the <?= CMS_PROJECT_SHORTNAME ?> is a PHP programmers tool (hence it is called a library), it is easy to
				learn and understand. Providing a good foundation library for web applications.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> can run on an isolated network requiring no internet access.
			</p>
			<p class="page_config">
				Being a code library and relatively small, it can easily be version controlled by Git or SVN as a whole.
			</p>
			<p class="page_config">
				<?= CMS_PROJECT_SHORTNAME ?> provides theme / brand control of maintain basic theme appearance.
			</p>
			<p class="page_config">
				It is not intended to emulate or replace larger and more complex Content Management Systems (CMS).
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a focus on web applications
				(e.g. data storage, processing and control, results compilation, machine interfacing, control/configuration interfacing,
				status display, etc).
			</p>
			<p class="page_config">
				A recommended way to see what the <?= CMS_PROJECT_SHORTNAME ?> has is to login as an administrator to the
				<?= CMS_PROJECT_SHORTNAME ?>, turn on debug (if not already on), goto to
				<a href="index.php?cms_action=cms_debug_vars">&quot;Admin-&gt;Debug Values&quot;</a> and
				<a href="index.php?cms_action=cms_edit_search">&quot;Search&quot;</a> to check out whats there.
				A good PHP coding Integrated Development Enviroment (IDE) should allow more understanding of the <?= CMS_PROJECT_SHORTNAME ?> library.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> library can function as an initial web site
				to allow setup and configuration.
				And get a feel for the library.
			</p>
			<p class="page_config">
				Also, if doxygen is installed, running &quot;<?= CMS_MAN_CLI_DIR ?>cms_doxy_run.sh&quot; from the bash shell command line generate reasonable source documentation.
				Extra &quot;Admin&quot; entries will appear in debug mode to view the generated documentation.
			</p>
			<p class="page_config">
				There are a large number of configuration and coding features built in to the <?= CMS_PROJECT_SHORTNAME ?> library.
				It is recommended to read this manual and explore the code library with a PHP IDE.
			</p>
			<p class="page_config">
				To harden the <?= CMS_PROJECT_SHORTNAME ?> and applications against virus ingress,
				the &quot;<?= CMS_DIR ?>&quot; and &quot;<?= APPS_DIR ?>&quot; directories can be installed as read only directories via squashfs filesystems.
				Users cannot change code in the read only filesystems from external sources.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Contents"></a>
			Contents
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<ul class="page_config cols">
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Introduction">Introduction</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Terminology">Terminology</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Cookies">Cookies</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Licence">Licence</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#TechnicalInformation">Technical Information</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#SecurityPrivelegs">Security and User Privileges</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ReadOnlyCode">Using Read Only Installed Code</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ServerSystemRequirement">Minimum Server System Requirements</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ServerSystemConfigs">Typical Server System Configurations</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Installation"> <?= CMS_PROJECT_SHORTNAME ?> Installation and Update</a>
				</li>
				<li class="page_config">
						<a href="index.php?cms_action=cms_manual#GitSVNinstall">SVN and Git <?= CMS_PROJECT_SHORTNAME ?> and Applications Install and Update</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#WindowLayout">Browser Window Layout</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#SetupConfiguration">Static Setup and Configuration</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#RunTime">Applying Run Time Settings and Configurations</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#DynamicConfiguration">Dynamic Configuration</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Apps">Applications</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppTypes">Types of Applications</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppClass">Primary Application Class</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Languages">Languages</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#APIops">API Operation</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#APIauth">API Authentication and Authorization</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#WebSocks">Web Sockets</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#htaccess">Access (DOCROOT)/.htaccess File</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Plugins">Plugins</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#PluginExtends">Plugin Extensions</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#AppsAuth">Applications Authentication</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Localtools">Local Tools</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#WYSIWYGs">WYSIWYGs</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#Sitemap">Sitemap</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#special_code">Special Code</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#coding_shortcuts">Coding Shortcuts and Builtin Features</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#cron_jobs">Chronological Timing (CRON Jobs)</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#TroubleShooting">Trouble Shooting</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#VersionControl">File Version Control</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#UtilityScripts">Utility Scripts</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#ExampleCode">Code Examples</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#MoreInfo">More Information</a>
				</li>
				<li class="page_config">
					<a href="index.php?cms_action=cms_manual#DirectoryStructure">Directory Structure</a>
				</li>
<?php if(file_exists("doxy/cms_html/index.html")) { ?>
				<li class="page_config">
					<a href="doxy/cms_html/index.html" target="_blank"><?= CMS_PROJECT_SHORTNAME ?> Code Documentation</a>.
				</li>
<?php	} // if ?>
<?php if(file_exists("doxy/apps_html/index.html")) { ?>
				<li class="page_config">
					<a href="doxy/apps_html/index.html" target="_blank">Applications Code Documentation</a>.
				</li>
<?php	} // if ?>
<?php if(file_exists("doxy/apps_cms_html/index.html")) { ?>
				<li class="page_config">
					<a href="doxy/apps_cms_html/index.html" target="_blank">Combined <?= CMS_PROJECT_SHORTNAME ?> and Applications Code Documentation</a>.
				</li>
<?php	} // if ?>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Introduction"></a>
			Introduction
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				This technical manual is to aid administrators, managers and web developers using the <?= CMS_PROJECT_SHORTNAME ?>.<br>
				Supplementary to this manual is the <?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#Introduction') ?>.
				The <?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes',false,'#Introduction') ?> list the <?= CMS_PROJECT_SHORTNAME ?> change history.
				General information is available in the <a href="index.php?cms_action=cms_about">About <?= CMS_PROJECT_SHORTNAME ?></a> page.
			</p>
			<p class="page_config">
				The web site has a search function to aid finding configuration and setup values.
			</p>
			<p class="page_config">
				This manual uses dynamic generation to represent this <?= CMS_PROJECT_SHORTNAME ?> installation and location.
			</p>
			<p class="page_config">
				<strong>NOTE:</strong> The <?= CMS_PROJECT_SHORTNAME ?> is <b>NOT</b> designed to operate inside a frame or iframe.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Terminology"></a>
			Terminology
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> and it&rsquo;s technical manual uses some terminology that is unique to the <?= CMS_PROJECT_SHORTNAME ?>.
				This terminology is described as;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;(DOCROOT)&quot; - the location in the file system on the Apache server of the <?= CMS_PROJECT_SHORTNAME ?> installation.
					For this installation it is the &quot;<?= DOCROOT_FS_BASE_DIR ?>&quot; directory.
					The location of &quot;(DOCROOT)/&quot; is automatically found by the <?= CMS_PROJECT_SHORTNAME ?>
					and defined in the &quot;DOCROOT_FS_BASE_DIR&quot; global constant,
					from which all file system location defines are derived.
					<br>NOTE: If in debug mode, the <a href="index.php?cms_action=cms_debug_vars">&quot;Admin-&gt;Debug Values&quot;</a> page will show all the globally defined constants.
				</li>
				<li class="page_config">
					&quot;(APP_DIR)&quot; - is the application as described the
					<a href="index.php?cms_action=cms_edit_bodies">&quot;Admin-&gt;Apps / Bodies menu&quot;</a>.
					The actual location of the application is in &quot;<?= APPS_WS_DIR ?>(APP_DIR)/&quot; directory.
					<br>NOTE: Applications which share an application directory in &quot;<?= APPS_WS_DIR;?>&quot;
					(allowed by <a href="index.php?cms_action=cms_edit_config&name=CMS_C_ALLOW_APPS_DIR_SHARE">&quot;Admin-&gt;Config-&gt;CMS_C_ALLOW_APPS_DIR_SHARE&quot;</a>),
					also share the same (APP_DIR).
				</li>
				<li class="page_config">
					&quot;(APP_NAME)&quot; - is the application name used by the <?= CMS_PROJECT_SHORTNAME ?>, for indexing.
					The (APP_NAME) has the  non alphanumeric characters replaced by underscores.
					<br>For example: &quot;My App1&quot; directory would have an  (APP_NAME) of &quot;My_App1&quot;.
				</li>
				<li class="page_config">
					&quot;(APP_KEY)&quot; -  is the unique uppercase alphanumerical representation
					of the application&rsquo;s key.
					<br>NOTE: Applications which share an application directory in &quot;<?= APPS_WS_DIR;?>&quot;
					(allowed by <a href="index.php?cms_action=cms_edit_config&name=CMS_C_ALLOW_APPS_DIR_SHARE">&quot;Admin-&gt;Config-&gt;CMS_C_ALLOW_APPS_DIR_SHARE&quot;</a>),
					also share the same (APP_KEY).
				</li>
			</ul>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> uses &quot;Pages&quot; and &quot;Applications/Apps&quot; references.
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;Pages&quot; - refers to a simple, usually basic/static informational web pages, having only a body page often written in HTML as &lt;div&gt; body html code &lt;/div&gt;.
					&quot;Pages&quot; do not have code their &quot;(APP_DIR)&quot;, a single code file in &quot;<?= APPS_BODIES_DIR ?>&quot; directory and are also referred to simple applications.
				</li>
				<li class="page_config">
					&quot;Application&quot; - refers to dynamic application web pages, having much of the application code in the &quot;(APP_DIR)&quot;.
					&quot;Applications&quot; have code files &quot;<?= APPS_BODIES_DIR ?>&quot; directory also, but is used as the code hook the code in the &quot;(APP_DIR)&quot;.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Cookies"></a>
			Cookies
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> uses session cookies (i.e. not third party cookies) to
				allow the browser to provide the user&rsquo;s session identity.
				The session identity is the unique key (generated by the user&rsquo;s browser) used to identify
				the user uniquely to that one web browser and is provided to the <?= CMS_PROJECT_SHORTNAME ?> server via a session cookie.
				The identity connects only with that one browser on that particular user&rsquo;s machine.
				The session identity is stored in a cookie on the user&rsquo;s computer.
				Without the session cookie, the user would not be able to log in.
			</p>
			<p class="page_config">
				The non cookie method of having the session identity (or SID) in every URL (or some browser side script to do the same thing)
				is not used on the <?= CMS_PROJECT_SHORTNAME ?>.
				The session identity is passed back to the server on every page load as a query parameter.
				The non session cookie method is very insecure as the browser URL shown in the address bar exposes the session identity
				and the URL can be easily copied to any another browser,
				the rights and privileges of the original user will also follow (because the server has no way to tell the difference).
				It is also not secure as the session identity will be stored in the browser history even when the browser is reopened at a later date
				(where a session cookie would be deleted when the user closed the browser).
				This non session cookie method is not recommended.
			</p>
			<p class="page_config">
				The recommended method for session identity is by the browser&rsquo;s session cookie.
				If no session cookie, no login should be allowed.
			</p>
			<p class="page_config">
				The browser session identity is used as a unique key to save and retrieve a user&rsquo;s state on the server.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> provides a client metadata cookie
				in &quot;_cms_clientMeta&quot; (as an encoded JSON).
				This cookie expires in 1 hour from last use.
				It provides metadata feedback for applications that need to know the dimensions (e.g. depth, width, height, timezone, language, etc.) of the
				client&rsquo;s browser window.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Licence"></a>
			Licence
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> is under &quot;BSD-3-Clause&quot; and has the
				<a href="https://opensource.org/licenses/BSD-3-Clause">&quot;https://opensource.org/licenses/BSD-3-Clause&quot;</a>.
			</p>
			<p class="page_config">
				The licence apply&rsquo;s as follows;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					With the exception of library files in the &quot;<?= CMS_WS_LIB_DIR ?>&quot; directory,
					the <?= CMS_PROJECT_SHORTNAME ?> licence applies to all other files in the &quot;<?= CMS_WS_DIR ?>&quot; directory.
				</li>
				<li class="page_config">
					And applies to &quot;index.php&quot;, &quot;ajax.php&quot;, &quot;api.php&quot;, &quot;login.php&quot; and  &quot;logout.php&quot; files (in the web &quot;(DOCROOT)/&quot; directory),
				</li>
			</ul>
			<p class="page_config">
				Which is the extent of <?= CMS_PROJECT_SHORTNAME ?> files licenced.
			</p>
			<p class="page_config">
				Files in the &quot;<?= CMS_WS_LIB_DIR ?>&quot; directory are covered by there own respective licences.
				And are not licenced by the <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
			<p class="page_config">
				The applications and user web pages files are not licenced by the <?= CMS_PROJECT_SHORTNAME ?> author.
				And belong to the licensing respective application authors.
				<b>The Licence for the Applications are the user&rsquo;s responsibility and are licenced separately.</b>
			</p>
			<p class="page_config">
				The author of <?= CMS_PROJECT_SHORTNAME ?> is open to submissions from the user community for changes
				in the &quot;<?= CMS_WS_DIR ?>&quot; directory to be included in the next release.
				Submissions can be emailed to
				<a HREF="mailto:feedback@<?= CMS_PROJECT_DOMAIN ?>?Subject=<?= rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ' Changes.') ?>">
					<?= CMS_PROJECT_SHORTNAME ?>
				</a>.
				A submission script is available at &quot;<?= CMS_MAN_CLI_DIR ?>cms_wrap_submission.sh&quot; is available to produce a
				ZIP archive of the &quot;<?= CMS_WS_DIR ?>&quot; directory.
				<br>
				<b>Important Note on Submissions:</b> It is usual for submissions to be credited to the submission author.
				The submission author needs to provide permission for an acknowledgment (in the release notes) to be added.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="TechnicalInformation"></a>
			Technical Information
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?= CMS_PROJECT_SHORTNAME ?> is based around standard technology.
				Some effort was made to make the code compatible for browsers with CSS3 and HTML5.
				PHP coding is used to generate html web pages.
				The PHP code is written in &quot;Object Oriented Programming&quot; (OOP).
				The <?= CMS_PROJECT_SHORTNAME ?> PHP code is written in the default namespace (&quot;/&quot;) to simplified user page and application code creation.
				To further aid programmers and IDE auto complete lookups, the <?= CMS_PROJECT_SHORTNAME ?> prefixes it&rsquo;s functions and classes with &quot;cms_&quot;.
				This also aids the application programmer in writing applications that sit on top of (extends) <?= CMS_PROJECT_SHORTNAME ?> objects (e.g. a class).
			</p>
			<p class="page_config">
				Installation setup is stored in INI files.
				Theme customization is also stored in INI files, and is used to generate CSS style sheets.
				Accompanying installation and theme setting pages are included to make changes.
				The default settings provide an operational <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
			<p class="page_config">
				The setup and configuration files are saved in the &quot;<?= ETC_DIR ?>&quot; for setting JSON, INI and sqlite (e.g. cms.ini, <?= CMS_S_DB_SQLITE_DATABASE ?>, etc.) files.
				Setup control JSON and INI (e.g. cms.comment.ini, cms.default.ini, etc) files remain in &quot;<?= CMS_MAN_INI_DIR ?>&quot; or &quot;<?= APPS_MAN_INI_DIR ?>&quot; respectively as part of the code base.
				Execution data is saved the &quot;<?= VAR_WS_DIR ?>&quot; directory (counts, exports,logs, sessions, etc.).
				This is to make updating and developing &quot;<?= APPS_WS_DIR ?>&quot; code easier,
				separating critical site only files from unwanted alteration.
				Refer to <?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes',false,'#TechnicalInformation') ?>.
			</p>
			<p class="page_config">
				Data for users, administrators, managers, groups, page bodies, tools and configuration are stored in an SQLite3 database.
				SQLite was chosen due to its easy installation (no database setup required) and it is very suitable for small projects.
				Automatic database installation code is provided.
				The SQLite database is initialized when the first web page is generated after installation.
				Providing an empty initialized database with the default configuration settings.
			</p>
			<p class="page_config">
				A basic description of the configuration database tables used;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Configuration Table - stores company name, web titles, image control, etc.,
					used in the web pages.
				</li>

				<li class="page_config">
					Users Table - stores username, encrypted password, group memberships,
					sort order/priority, enable/disable and administrator enabling.
					<br>
					NOTE: That when the AD/LDAP authentication is used and no local password is supplied,
					a default local password of the date in YYYYMMDD format is used.
				</li>

				<li class="page_config">
					Groups Table - stores group, enable/disable, administrator and managers.
				</li>

				<li class="page_config">
					Page Bodies Table - stores the page body / application primary control values.
					The actual page content is stored in the &quot;<?= APPS_BODIES_WS_DIR ?>&quot; directory using the filename configured.
					The body file is often used as a connector or control file for local application
					and often includes files in the &quot;<?= APPS_WS_DIR ?>&quot; directory.
					<br>
					<b>NOTE:</b> The applications may have further configuration settings in the applications.
				</li>

				<li class="page_config">
					Tools Table - stores the tools information.
					A special directory, &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot;, has been set aside inside the <?= CMS_PROJECT_SHORTNAME ?>
					file structure for handy tools, local "hacks" and try outs.
					Tools have sort order/priority, new page and enable/disable.
					Stores tool links , group memberships, sort order/priority and enable/disable.
					The tools appear in left column (or right column) in a drop down from the header or on the nav bar,
					and are displayed according to the group settings.
				</li>

				<li class="page_config">
					Links Table - stores the URL links information.
					This table contains values and controls are for the &quot;Links&quot; page (i.e. a type of bookmarks and documents index page.
					Bookmarks from Firefox and Chrome web browsers can be imported into the sections (folders) table and links (URLs) table.
				</li>

				<li class="page_config">
					Sections Table - controls the links page layout so that links are sectioned/grouped
					together for display and access control.
				</li>

			</ul>
			<p class="page_config">
				When the <a href="index.php?cms_action=cms_edit_config&name=CMS_C_ALLOW_CSV_EXPORT_IMPORT">&quot;Admin-&gt;Config-&gt;Allow CSV Export and Import</a> = True,
				the corresponding database table is exported to the exports/ directory on each save.
				The CSV can be downloaded from the relevant <?= CMS_PROJECT_SHORTNAME ?> setup editor page.
				The CSV can be altered as the commentary included in the CSV file and uploaded back to the <?= CMS_PROJECT_SHORTNAME ?> database.
				The CSV format uses the standard comma delimiter and double quotes for the enclosure (as required) to separate column data.
				<br>
				The <?= CMS_PROJECT_SHORTNAME ?> setup editor page has a file browse button and an upload button
				to upload and import a CSV table file from your local computer.
				Before an uploaded file is imported, the <?= CMS_PROJECT_SHORTNAME ?> backups up the database
				to the backups/ directory.
				<br>
				To restore a backup on LINUX, in the web root directory run:
				<br>
				&quot;zcat <?= VAR_WS_DIR ?>backups/<?= CMS_PROJECT_SHORTNAME ?>-Backup-<?= CMS_S_DB_SQLITE_DATABASE ?>-YYYYMMDD-HHMMSS.gz | sqlite3 <?= ETC_DIR ?>sqlite/<?= CMS_S_DB_SQLITE_DATABASE ?>&quot;
				<br>
				Substitute your filenames as needed.

			</p>
			<p class="page_config">
				Setup and operational features should be self evident.
				All install, setup and configuration settings have accompanying information builtin describing each particular setting.
				The idea was to keep it simple.
				Remove anything that wasn&rsquo;t useful or looked too complicated (i.e. make it easy to customize),
				by providing just the basics.
				The result has been to make use of CSS to remove as much code as possible.
				As a result the code has minimal javascript.
			</p>
			<p class="page_config">
				 <?= CMS_PROJECT_SHORTNAME ?> theme settings are numerous and should be self evident.
				 <?= CMS_PROJECT_SHORTNAME ?> is intended for general small web sites required for the generation of user/owner managed web sites.
				 <?= CMS_PROJECT_SHORTNAME ?> can be set to be easily identifiable (due to page headers and footers) so that users know the web site entity.
			</p>
			<p class="page_config">
				The web site can use these methods to authenticate users (in authentication order);-
			</p>
			<ol class="page_config">
				<li class="page_config">
					General global (all users) PAM authentication can be used by enabling the PAM authentication option in the install page.
					If PAM authentication is available,
					PAM is used to authenticate <?= CMS_PROJECT_SHORTNAME ?> users against host system credentials.
					Where the <?= CMS_PROJECT_SHORTNAME ?> username is also available on the host server system.
					If authentication fails, the <?= CMS_PROJECT_SHORTNAME ?> defaults to attempting next authentication method.
					<br>
					The PAM authentication requires the system PECL PAM package to be installation along with some extra configuration.
					Talk to your server administrator.
				</li>
				<li class="page_config">
					Individual users can be selected to use host server PAM authentication by enabling the PAM authentication option in the user&rsquo;s configuration.
					The user authenticates using the same methods as the the general global PAM authentication.
				</li>
				<li class="page_config">
					The username and password can be authenticated against a LDAP/AD server by setting a user&rsquo;s auth preferences to LDAP.
					If authentication fails, the <?= CMS_PROJECT_SHORTNAME ?> defaults to attempting next authentication method.
					<br>
					The LDAP/AD server is usually part of a larger organisation&rsquo;s centralized authentication systems,
					and will require install settings from your server administrator.
				</li>
				<li class="page_config">
					The username and password can be authenticated against <?= CMS_PROJECT_SHORTNAME ?> user settings.
					If authentication fails, the <?= CMS_PROJECT_SHORTNAME ?>, login has failed.
				</li>
				<li class="page_config">
					Applications can have their own authentication systems.
					See <a href="index.php?cms_action=cms_manual#AppsAuth">Applications Authentication</a>.
				</li>
			</ol>
			<p class="page_config">
				The web site has an <a href="index.php?cms_action=cms_edit_search">&quot;Admin-&gt;Search&quot;</a> function to aid finding configuration, setup and page contents.
				Search (and filters) can be by exact match (of anded keywords), phonetic (sounds like) or levenshtein (similar match).
				The phonetic and levenshtein have enable/disable options.
				When the user is not sure of the exact words, these extra filters help find the required link,
				although they do produce more results.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> requires session cookies (also know as transient cookies) to be enabled to allow login.
				The session cookie locks your browser to the server session and provides additional security information about the identity of the session end to end.
				If the session cookie is disabled, a warning is shown on screen.
				Third party cookies are not used by the <?= CMS_PROJECT_SHORTNAME ?>, so third party cookies can be disabled.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a content cache functionality to speed up deliver of content that does not change
				between successive requests to the web server.
				The content cache provides a 80% to 95% time reduction in the background <?= CMS_PROJECT_SHORTNAME ?> operation on
				sections like nav bar, header and menus that require a large amount of processing each time they are displayed but do not change.
				The page bodies, custom header and custom footer can also be cached selectively.
				The content cache is cleared at login, logout, saving settings and configuration rebuild.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has many defined constants, class objects, methods / functions and variables
				available to the web programmer. The use of an autocompleting IDE is recommended. The <?= CMS_PROJECT_SHORTNAME ?> is
				in debug mode there is a debug selection in the &quot;Admin&quot; menu which will the global defines and various other other information.
			</p>
			<p class="page_config">
				A secondary data mine type database (i.e. filesystem based) in the &quot;<?= VAR_WS_USERS_DIR ?>&quot; directory is used to hold transitory user data
				(e.g. login count, login timeout, etc.).
				This saves having to manage database changes in the sqlite database from transitory data when using Git or SVN document version control systems.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="SecurityPrivelegs"></a>
			Security and User Privileges
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?= CMS_PROJECT_SHORTNAME ?> has in inbuilt security and privileges scheme to allow or restrict access.
			</p>
			<p class="page_config">
				Here is a simplified logic diagram, &quot;User Privileges Diagram&quot;;-
				<br>
				<div class="diagram">
					<img class="diagram" src="<?= CMS_WS_IMAGES_DIR ?>UserPrivileges.png" alt="UserPrivileges"/>
				</div>
			</p>
			<p class="page_config">
				In the &quot;User Privileges Diagram&quot;, the logic elements are centered around the &quotCMS Groups Table&quot;,
				with the exception of the &quot;CMS Users Table&quot; providing an enable for each user to be an &quot;Admin&quot;.
			</p>
			<p class="page_config">
				To make interfacing to privileges code, status methods are included in the &quot;Ccms_base&quot; class hierachy.
				If the applications / body code follows the recommended use of extend classes, the these mothods will be available under the &quot;self::&quot; static calls.
				Here is the privileges status calls;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;is_cms_guest();&quot; - returns true if the user is guest (not a logged in user).</li>
				<li class="page_config">&quot;is_cms_user();&quot; - returns true if the user is a logged in user (including addmins and managers).</li>
				<li class="page_config">&quot;is_cms_admin();&quot; - returns true if the user is a logged in user with admin privileges (either as an admin user or through an admin group).</li>
				<li class="page_config">&quot;is_cms_group_manager();&quot; - returns true if the user is logged in and the user is a manager for the application / body group or links manager group.</li>
				<li class="page_config">
					&quot;is_cms_apps_manager($user = []);&quot; - returns true if the user is an application / body manager.
					<br>
					This method has two methods of logic to determine the user&rsaquo;s privileges;
					<ul class="page_config">
						<li class="page_config">
							If the $user[] parameter is empty, the logic uses the logged user&rsaquo;s details, returns true if the logged in user is the current applications / body manager.
						</li>						
						<li class="page_config">
							If the associative array &quot;$user[]&quot; parameter is not empty, the logic uses the user[] parameters to determine if the user is in the &quot;cms_users&quot; table,
							if so, it uses that users credentials to determine if this user (the user may not be a logged in) is the current applications / body manager to return true.
							This allows a user&rsaquo;s identity to be used to provide privilege information about a user on another functionality. 
							An example of this is the &quot;Ccms_appointments_plugin&quot; which uses a separate user database for booking appointments, allowing privileged management of the appointments.
							<br>
							The values in the associative array &quot;$user[]&quot; parameters are keyed like;-
							<ul class="page_config">
								<li class="page_config">&quot; *id &quot; - matches to the &quot;cms_user_id&quot; column in the &quot;cms_users&quot; table. The id value takes priority and no other column is needed (but the is not usually available).</li>
								<li class="page_config">&quot; *email &quot; - matches to the &quot;cms_user_email&quot; column in the &quot;cms_users&quot; table.</li>
								<li class="page_config">&quot; *email_confirmed &quot; - if email confirmation enabled (default), &quot;cms_user_email_confirmed&quot; column must be &quot;true&quot; in the &quot;cms_users&quot; table.</li> 
								<li class="page_config">&quot; *mobile &quot; - matches to the &quot;cms_user_mobile&quot; column in the &quot;cms_users&quot; table.</li>
								<li class="page_config">&quot; *mobile_confirmed &quot; - if mobile confirmation enabled (default), &quot;cms_user_mobile_confirmed&quot; column must be &quot;true&quot; in the &quot;cms_users&quot; table.</li> 
								
								<li class="page_config">&quot; *name &quot; - matches to the &quot;cms_user_name&quot; column in the &quot;cms_users&quot; table.</li>
							</ul>
						</li>						
					</ul>
				</li>
			</ul>
			<p class="page_config">
				From the authentication methods it is possible to determine the active privileges of the user.
			</p>
			<p class="page_config">
				<b>Confirmation Notes:</b>
			</p>
			<ol class="page_config">
				<li class="page_config">If email confirmation is enabled (default), email confirmation is done in two ways.
					<ol class="page_config">
						<li class="page_config">
							When the admin creates the user account, a confirmation email is sent to the user providing a code to enter to verify the email address.
							The admin can skip this step if required and the confirmation is done another way.
						</li>
						<li class="page_config">
							When the user logs in, a confirmation email is sent to the user providing a code to enter to verify the email address.
						</li>
					</ol
				<li>
				<li class="page_config">If mobile confirmation is enabled (default), SMS messaging is enabled, mobile confirmation is done in two ways.
					<ol class="page_config">
						<li class="page_config">
							When the admin creates the user account, a confirmation SMS is sent to the user providing a code to enter to verify the mobile number.
							The admin can skip this step if required and the confirmation is done another way.
						</li>
						<li class="page_config">
							When the user logs in, a confirmation SMS message is sent to the user providing a code to enter to verify the mobile number.
						</li>
					</ol
				<li>
			</ol>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="ReadOnlyCode"></a>
			Using Read Only Installed Code
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?= CMS_PROJECT_SHORTNAME ?> can be installed with read only filesystems for the
				&quot;<?= CMS_DIR ?>&quot;, &quot;<?= APPS_DIR ?>&quot; and <?= APPS_BODIES_DIR ?>&quot;
				directories directories via squashfs filesystems.
				The two &quot;(DOCROOT)/&quot; files &quot;cms_lib_sqsh.sh&quot; (for CLI ops) and &quot;cms_lib_sqsh.php&quot;
				(for web code) control the mounting of read only files via <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
			<p class="page_config">
				<b>Important Note:</b> To access non PHP files (e.g images, stylesheets, etc.) in &quot;<?= CMS_WS_DIR ?>&quot; and &quot;<?= APPS_WS_DIR ?>&quot;
					read only directories, the Apache web server needs to run in &quot;perfork&quot; mode (i.e. not running in &quot;MPM&quot; multiprocessing mode).
			</p>
			<ul class="page_config">
				<li class="page_config">
					The <?= CMS_PROJECT_SHORTNAME ?> &quot;<?= CMS_DIR ?>&quot; is provided as part of the <?= CMS_PROJECT_SHORTNAME ?> install.
				</li>
				<li class="page_config">
					To use read only filesystems for the &quot;<?= APPS_DIR ?>&quot; and <?= APPS_BODIES_DIR ?>&quot; directories
					need to follow coding schemas rules.
					The configurations and settings (and some configuration images) are saved in &quot;<?= ETC_DIR ?>&quot; directory.
					And variables (caches, logs, variables, etc.) are saved in the &quot;<?= VAR_WS_DIR ?>&quot; directory.
					The read only filesystems are in a independent format and cannot be written to,
					and also by root and administrator users cannot write to.
				</li>
				<li class="page_config">
					Developers can use the supplied &quot;<?= CMS_WS_CLI_DIR ?>cms_wrap_apps.sh&quot; script to build the
					&quot;apps_fs_sqsh.sqsh&quot; (from the &quot;<?= APPS_DIR ?>&quot; directory) to make
					a read only applications squashfs filesystem.
				</li>
				<li class="page_config">
					Distribution and installation of the &quot;apps_fs_sqsh.sqsh&quot; needs to implemented by the user.
					To allow the read only file systems to be mounted, the &quot;<?= APPS_DIR ?>&quot; directory needs to be removed.
				</li>
				<li class="page_config">
					For users mounting the read only filesystems for CLI use is done by the &quot;./cms_lib_sqsh.sh&quot; script.
					This script has options, check &quot;./cms_lib_sqsh.sh --help&quot;.
					Also mounting the filesystems with the &quot;./cms_lib_sqsh.sh&quot; script allows the filesystems to be viewed
					by the local host user (but not the web user). Ideal for development and debugging sessions.
				</li>
				<li class="page_config">
					Mounting the read only filesystems for web operation use is done by the web code including &quot;./cms_lib_sqsh.php&quot; script.
					Usually the server will hide filesystems the from all users accept the server, so the users (including root) cannot see it.
					Another benefit of this that the PHP-FPM provides faster web access, giving a higher performance web site.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="ServerSystemRequirement"></a>
			Minimum Server System Requirements
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?= CMS_PROJECT_SHORTNAME ?> requires the following server requirements to operate;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Linux operationg system (e.g. RedHat/Centos 7, SUSE/openSUSE 15, Ubuntu 18, or higher versions).
				</li>
				<li class="page_config">
					Apache 2.4.x 64 bit installed on LINUX (tested on CentOS 8.5 and openSUSE 15.2), recommend using &quot;prefork&quot; mode for read only code.
				</li>
				<li class="page_config">
					PHP 7.4 64 bit (recommended, tested on 7.4)<br>
					Installed packages: php php-bcmath php-json php-pecl php-devel
					php-dba php-zlib php-sqlite php-curl php-zip php-dom php-opcache
					php-pear php-ctype php-tokenizer php-openssl php-mbstring,
					<br>Optionally packages: php-mysql php-pdo php-gd php-iconv php-posix/php-intl php-xdebug,
					<br>Plus the web server PHP engagement packages (e.g. apache2-mod_php).
				</li>

				<li class="page_config">
					<?= CMS_PROJECT_SHORTNAME ?> can be setup as an adjunct to an existing web site,
					or as a new web site (If a new web site,
					the Apache web server configuration needs to be setup for the new web site.),
				</li>

				<li class="page_config">
					An SSL certificate, self signed or registered for SSL/https web site encryption,
				</li>

				<li class="page_config">
					http (port 80) for default home/links page and https (port 443) for login and user designated pages,
				</li>
			</ul>
			<p class="page_config">
				During installation and configuration rebuild, a list of required packages is output.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="ServerSystemConfigs"></a>
			Typical Server System Configurations
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<?php insert_man_drop_box('h4','Example Apache 2.4 Vhost Config',CMS_FS_INCLUDE_MANUAL_DIR . 'example_vhost_conf.html') ?>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<?php insert_man_drop_box('h4','Example Apache 2.4 Alias Config',CMS_FS_INCLUDE_MANUAL_DIR . 'example_alias_conf.html') ?>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="Installation"></a>
			<?= CMS_PROJECT_SHORTNAME ?> Installation and Update
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<b>Note 1:</b> The server set up is beyond the scope of this manual. Some general server side setup information is given here. If help is required, contact your system administrator or tech support.<br>
				<b>Note 2:</b> The actual methods used on a particular server may vary from the steps shown here.<br>
				<b>Note 3:</b> The <?= CMS_PROJECT_SHORTNAME ?> zip and installer files do not come with user set files that over writes user settings,
				if required &quot;(DOCROOT)&quot; files outside of &quot;<?= CMS_WS_DIR ?>&quot; don&rsquo;t exist (e.g.  &quot;index.php&quot;, &quot;ajax.php&quot;, &quot;api.php&quot;, &quot;login.php&quot; and  &quot;logout.php&quot;) the <?= CMS_PROJECT_SHORTNAME ?> will generate default files.
				The &quot;ajax.php&quot; is not normally required nor used if the originating code is generated by the <?= CMS_PROJECT_SHORTNAME ?> and calls &quot;<?= CMS_WS_DIR ?>cms_ajax.php&quot; directly.
				For reference (and possible update), a copy of these distribution &quot;(DOCROOT)&quot; files is available in the &quot;<?= CMS_WS_DIR ?>docroot_files/&quot;.
				If changes are made to the default &quot;(DOCROOT)&quot; files,
				the changes can be checked against files in the &quot;<?= CMS_WS_DIR ?>docroot_files/&quot; directory.<br>
				<b>Note 4:</b> The <?= CMS_PROJECT_SHORTNAME ?> installer script file defaults to installing <?= CMS_PROJECT_SHORTNAME ?> library
				in a read only mode (approx 11MB). If a full read/write install is required use the zip (approx 19MB).<br>
				Refer to the <?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#Installation') ?>.
				or to <?= Ccms_media_conv_plugin::get_file_href('cms_lib_sqsh.md','Installation Notes Extract',false,'#Installation') ?>.
			</p>
			<p class="page_config">
				<b>Important Note:</b> The Apache web server will needed to be stopped and started after a read only install or update.
				The server will need to be totally disengaged (i.e. a full stop/start, e.g. service httpd stop &amp;&amp; service httpd start).
				And if in use, the php-fpm service  will need to be totally disengaged (i.e. a full stop/start, e.g. service php-fpm stop &amp;&amp; service php-fpm start).
				The normal restart only reloads the web server configuration files and will not release the previous squashfs mounts.
			</p>
			<p class="page_config">
				The installation comes as a self installing bash script (5.5MB) for LINUX and a ZIP (3.9M) file for general installations.
				Available on the &quot;https://github.com/<?= CMS_PROJECT_SHORTNAME ?>/<?= CMS_PROJECT_SHORTNAME ?>_Latest/blob/master/<?= CMS_PROJECT_SHORTNAME ?>-Installer-latest.sh&quot;.
			</p>
			<p class="page_config">
				For full user and administration experience use a CSS3 and HTML5 compatible browser
				(e.g. Microsoft&reg; Edge, Mozilla Firefox, Google Chrome, etc.).
			</p>
			<p class="page_config">
			    The installation is in the &quot;(DOCROOT)/&quot; directory
				(the server file system directory, accessed/served by Apache, where the <?= CMS_PROJECT_SHORTNAME ?> web apps are installed).
			</p>
			<p class="page_config">
				A guide to installing and updating <?= CMS_PROJECT_SHORTNAME ?> follows;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Login to the web server as the user the web site is setup with (usually the user is the domain e.g. somedomain.com).
					<b>Do not log in as root, administrator or any other privileged user.</b>
				</li>
				<li class="page_config">
					<b>If updating, backup the web site.</b>
				</li>
				<li class="page_config">
					<a href="https://github.com/<?= CMS_PROJECT_SHORTNAME ?>/<?= CMS_PROJECT_SHORTNAME ?>_Latest/blob/master/<?= CMS_PROJECT_SHORTNAME ?>-Installer-latest.sh" target="_blank">Download the <?= CMS_PROJECT_SHORTNAME ?> installer file &quot;<?= CMS_PROJECT_SHORTNAME ?>-Installer-latest.sh&quot;</a>
					to the web site&rsquo;s &quot;(DOCROOT)/&quot; directory on your web server.
					<br>
					Alternatively there is shell script &quot;<?= CMS_MAN_CLI_DIR ?>cms_update<?= CMS_PROJECT_SHORTNAME ?>.sh&quot; to update the
					<?= CMS_PROJECT_SHORTNAME ?> from the online repository using the &quot;<?= CMS_PROJECT_SHORTNAME ?>updater&quot; setup section.
				</li>
				<li class="page_config">
					On Linux, change the &quot;<?= CMS_PROJECT_SHORTNAME ?>-Installer-latest.sh&quot; file attributes so it can be executed<br>
					e.g. chmod u+x &quot;<?= CMS_PROJECT_SHORTNAME ?>-Installer-latest.sh&quot;
				</li>
				<li class="page_config">
					Then execute the &quot;<?= CMS_PROJECT_SHORTNAME ?>-Installer-latest.sh&quot; in the &quot;(DOCROOT)/&quot; directory.<br>
					This will install or update the <?= CMS_PROJECT_SHORTNAME ?> &quot;<?= CMS_WS_DIR ?>&quot; directory and chek that manadatory file are present (replacing if necessary).
					And initialise the web site parameters.
				</li>
				<li class="page_config">
				<?php insert_man_drop_box('h4','Typical CLI Installer Output',CMS_FS_INCLUDE_MANUAL_DIR . 'cli_installer_output.html') ?>
				</li>
				<li class="page_config">
				<?php insert_man_drop_box('h4','Typical CLI Update Output',CMS_FS_INCLUDE_MANUAL_DIR . 'cli_updater_output.html') ?>
				</li>
				<li class="page_config">
					For a <?= CMS_PROJECT_SHORTNAME ?> read/write install or update, unzip the <?= CMS_PROJECT_SHORTNAME ?> zip file.
				</li>
				<ul class="page_config">
					<li class="page_config">
						Use &quot;<b>unzip <?= CMS_PROJECT_SHORTNAME ?>-{VERSION}.zip <?= CMS_WS_DIR ?>* -d (DOCROOT)</b>&quot; to update the <?= CMS_PROJECT_SHORTNAME ?> cms library directory.
					</li>
					<li class="page_config">
						The  &quot;index.php&quot;, &quot;ajax.php&quot;, &quot;api.php&quot;, &quot;login.php&quot; and  &quot;logout.php&quot; files can be extracted as required."
						The read only control file &quot;cms_lib_sqsh.php&quot;, &quot;cms_lib_sqsh.sh&quot; and &quot;cms_lib_sqsh.md&quot; should always be extracted.
					</li>
					<li class="page_config">
						The read only library code file &quot;cms_lib_sqsh.sqsh&quot; is not extracted in a read/write installation
						(i.e. the &quot;<?= CMS_DIR ?>&quot; directory has copy of the <?= CMS_PROJECT_SHORTNAME ?> installed).
					</li>
					<li class="page_config">
						Use &quot;<b>unzip <?= CMS_PROJECT_SHORTNAME ?>-{VERSION}.zip filename2unzip -d (DOCROOT)</b>&quot; to unzip the file.
					</li>
					<li class="page_config">
						<b>NOTE: The unzip utility command overwrites files by default. Do a backup first.</b>
					</li>
				</ul>
				<li class="page_config">
					<b>Additionally</b>, where there is several web sites using <?= CMS_PROJECT_SHORTNAME ?> on the same host server, the <?= CMS_PROJECT_SHORTNAME ?> system RPM package can be installed.
					This will allow the <?= CMS_PROJECT_SHORTNAME ?> read only library to be mounted in the web site (DOCROOT) directory from a common library.
					The <?= CMS_PROJECT_SHORTNAME ?> library package is installed in the &quot;/usr/local/share/<?= CMS_PROJECT_SHORTNAME ?>&quot; directory.
					The <?= CMS_PROJECT_SHORTNAME ?> system RPM package provide utilities;-
				</li>
				<ul class="page_config">
					<li class="page_config">
						&quot;<?= CMS_PROJECT_SHORTNAME ?>-info&quot; to provide information about the install library package.
					</li>
					<li class="page_config">
						&quot;<?= CMS_PROJECT_SHORTNAME ?>-engage&quot; to install/update (DOCROOT) files to engage the <?= CMS_PROJECT_SHORTNAME ?> system library.
					</li>
				</ul>
				<li class="page_config">
					Pointer your browser at	&quot;http://your.web.site/site_alias/index.php&quot; (site_alias/ is part of your server setup, usually empty).
				</li>
				<li class="page_config">
					When the <?= CMS_PROJECT_SHORTNAME ?> is first accessed, it will create an empty SQLite database and rebuild all the CSS stylesheets.<br>
					After approximately 20 to 60 seconds the rebuild will finish displaying status of the rebuild processes.
				</li>
				<li class="page_config">
					Click the &quot;User: Login&quot; link.
					When no users are setup, a default admin user is;-<br>
					Username: admin<br>
					Password: password<br>
					<b>Strongly recommend</b> the default admin username be disabled after you have setup another admin, more secure, user (with admin rights).<br>
					Login to the web site.
					On a fresh install you should see the about page.
					For a update you should your home page.
				</li>
				<li class="page_config">
					Suggest going to the <a href="index.php?cms_action=cms_manual#SetupConfiguration">Setup and Configuration</a> section.
				</li>
			</ul>
			<p class="page_config">
				If failures and non functional issues occur, <a href="index.php?cms_action=cms_manual#TroubleShooting"> see Trouble shooting</a>
			</p>
			<p class="page_config">
				An advanced install can be done using the &quot;https://github.com/<?= CMS_PROJECT_SHORTNAME ?>/<?= CMS_PROJECT_SHORTNAME ?>_Latest/blob/master/<?= CMS_PROJECT_SHORTNAME ?>-latest.zip&quot; zip file.
				From the command line run;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;sudo <?= CMS_WS_CLI_DIR ?>cms_set_permissions.sh&quot; correct any permission problems.
					(If sudo access is not available, you will need to get the a sudoer or root to run it.)
				</li>
				<li class="page_config">
					&quot;<?= CMS_WS_CLI_DIR ?>cms_rebuild.sh&quot; check and update (and rebuild if necessary)
					<?= CMS_PROJECT_SHORTNAME ?> will check and make the directory structure and add missing app directoruies,
					regenerate the stylesheets themes, etc.
				</li>
			</ul>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The settings in the INI files for the <?= CMS_PROJECT_SHORTNAME ?>
				and for applications in the &quot;<?= ETC_MAN_INI_DIR ?>cms.ini&quot; and
				the &quot;<?= ETC_MAN_INI_DIR ?>apps.ini&quot; files are read after the configuration DB
				values, in the Ccms::__construct() method (i.e. in the same code block).
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="GitSVNinstall"></a>
			SVN and Git <?= CMS_PROJECT_SHORTNAME ?> and Applications Install and Update
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Supplementary to installing from a shell install script or update from a zip file or remote  <?= CMS_PROJECT_SHORTNAME ?> repository,
				it is recommended for the <?= CMS_PROJECT_SHORTNAME ?> and application installations and updates
				from SVN and Git repositories to run the web applications, it is recommended to execute the following scripts;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					<b>First</b> run &quot;./cms_lib_sqsh.sh&quot;.
					This will mount any read only filesystems.
				</li>
				<li class="page_config">
					<b>Second</b> run &quot;sudo bash -e <?= CMS_WS_CLI_DIR ?>cms_set_permissions.sh&quot;.
					This will set permissions for shell and web server access.
				</li>
				<li class="page_config">
					<b>Third</b> run &quot;bash -e <?= CMS_WS_CLI_DIR ?>cms_rebuild.sh&quot;.
					This will build the latest settings, configuration DB and directory structure for this <?= CMS_PROJECT_SHORTNAME ?> version.
					Run update scripts effecting constants, variables and locations.
					And finally run a application code check script,
					&quot;<?= CMS_WS_CLI_DIR ?>updaters/cms_upgrade_appsV300.sh&quot;,
					to detect changes required in applications.
				</li>
			</ul>
			<p class="page_config">
				<b>Important</b> please <a href="index.php?cms_action=cms_manual#MoreInfo">more information</a> section.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="WindowLayout"></a>
			Browser Window Layout
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				There is an overall web site style settings (part of the Theme settings);
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;Block Style&quot; - uses absolute positioning in the browser&rsquo;s window. The page body scrolls between fixed positions of the header and the footer. The tool links, admin links and navigation bar also have fixed positions in the browser&rsquo;s window.
					The browser&rsquo;s window is more easily navigable.
				</li>
				<li class="page_config">
					&quot;Inline Style&quot; - uses inline/relative positioning in the browser&rsquo;s window. Scrolls the header, tool links, admin link, navigation bar, page body and footer as one entity. This can make the separate areas of the browser window difficult to navigate to.
					The <?= CMS_PROJECT_SHORTNAME ?> detects the type of device being used to display the web pages,
					and is not designed to be administered from tablets or very small devices.
					Where the browser cannot be identified or compatibility issues are known, the <?= CMS_PROJECT_SHORTNAME ?> will use inline style.
				</li>
			</ul>
			<p class="page_config">
				The general arrangement of the <?= CMS_PROJECT_SHORTNAME ?> window layout sections is;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;Header&quot; - top section of the window.
					This can be the standard web page header from the <?= CMS_PROJECT_SHORTNAME ?> which contains standard features.
					The standard features can be configured by the administer.
					Or the entire header can be replaced with a customer header.
					Or the header can be turned off.
					If the left column is turned off and the navigation bar is turned off, panel drop boxes are used to display tool and administration links.
					The header is identified by the HTML by &lt;div id=&quot;cms_lo_header&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Left Column&quot; -  when enabled and displayed,
					occupies the left side of the window between the header and footer.
					The left column displays tool links and administration links.
					If no tools are setup and no user is logged in, the left column is not displayed.
					The left column can be turned off, then other means are used to display tool administration link, either in the header or in the navigation bar.
					The left column is identified by the HTML by &lt;div id=&quot;cms_lo_left_column&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Right Column&quot; -  when enabled and displayed,
					occupies the right side of the window between the header and footer.
					The right column displays tool links and administration links.
					If no tools are setup and no user is logged in, the right column is not displayed.
					The right column can be turned off, then the tools and adminstration links are displayed in the left column.
					If the left column is turned off the right column is also turned off and other means are used to display tool administration link, either in the header or in the navigation bar.
					The right column is identified by the HTML by &lt;div id=&quot;cms_lo_right_column&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Navigation Bar&quot; (Nav Bar) -  when enabled,
					is a narrow horizontal links bar that occupies the window to the right side of the left column, under the header and above the page body.
					The contents of the nav bar are configured in the Config settings.
					If there are tools enabled and if the nav bar size allows, all the tool links are placed in on the nav bar as single items.
					If the left column is turned off, the tool links and administration links are added to the nav bar.
					The navigation bar is identified by the HTML by &lt;div id=&quot;cms_lo_nav_bar&quot;&gt;...&lt;/div&gt;
				</li>
				<li class="page_config">
					&quot;Page Body&quot; -  occupies the remaining window area,
					written by the web site&rsquo;s author.
					This is the window area that displays the web site&rsquo;s content.
					Although the sections other than the page body have automatically generated default content,
					the page body section has number of extra html code features (including javascript support) to
					simplify code and enhance effects for overlays and ajax data presetation.
					The page body is identified by the HTML by &lt;div id=&quot;cms_page_body&quot;&gt;...&lt;/div&gt;.
					Inside the page body &lt;div&gt; there are sub &quot;&lt;div&gt;s&quot; for HTML page body control and access.
				</li>
				<li class="page_config">
					&quot;Footer&quot; - bottom section of the window.
					This can be the standard web page footer from the <?= CMS_PROJECT_SHORTNAME ?>
					which contains standard features.
					The standard features can be configured by the administer.
					Or the entire footer can be replaced with a customer header.
					Or the footer can be turned off.
					The footer is identified by the HTML by &lt;div id=&quot;cms_lo_footer&quot;&gt;...&lt;/div&gt;
				</li>
			</ul>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config"><b>IMPORTANT NOTES:</b></p>
			<p class="page_config">If the navigation bar is enabled it takes priority over layout options.</p>
			<p class="page_config">
				If no navigation bar, left column or right column layouts are selected,
				the layout generator uses the <b>default layout</b> and
				places the &quot;Menu&quot;, &quot;Tools&quot; and &quot;Admin&quot;
				drop down panels in the header to provide user interaction.
				<br>
				<b>NOTE:</b> If a custom header is provided in this layout configuration,
				the programmer needs to provide for user interaction.
			</p>
			<p class="page_config">For &quot;tiny&quot; devices
				(e.g. small screen devices, mobile phones, etc.)
				the layout uses the <b>default layout</b>.
			</p>
			<p class="page_config">For &quot;tablet&quot; devices use the layout as configured.
				Except <?= CMS_PROJECT_SHORTNAME ?> allows the tablet to treat the first touch on the drop down as an open click.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="SetupConfiguration"></a>
			Static Setup and Configuration
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">Use a recommended administration web browser.</p>
			<p class="page_config">
				After logging into the <?= CMS_PROJECT_SHORTNAME ?>,
				an &quot;Admin&quot; menu in the left column (default),
				in the header (as a drop down) or
				on the Nav Bar (as a drop down),
				depending on any previous settings, will appear.
				The contents of the &quot;Admin&quot; menu are self explanatory, having tooltips (i.e. small pop up boxes with explanatory text) for each link.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> comes with an AD/LDAP authentication and search on login system.
				The authentication provides username and password login function, and optionally a AD/LDAP directory search function.
				The search function is mainly intended for local application and not directly used by the <?= CMS_PROJECT_SHORTNAME ?>.
				There is optional AD/LDAP authentication search parameters available to interrogate the AD/LDAP server.
				The search results are placed in the &#36;_SESSION['ldap'] array for use by application code and is available across sessions.
				The contents of &#36;_SESSION['ldap'] are removed at logout.
				The AD/LDAP operation is controlled by installation settings in the
				<a href="index.php?cms_action=cms_edit_install">&quot;Admin-&gt;Install&quot;</a> in the &quot;Auth Settings&quot; section
				(more information available under &quot;Auth Settings&quot;-&gt;&quot;Comments/Help&quot;).
			</p>
			<p class="page_config">
				After installation or update, the following guide is useful;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Suggest checking out the &quot;Admin&quot; links to get a feel for the available settings.
				</li>
				<li class="page_config">
					If looking for a possible setting, try the <a href="index.php?cms_action=cms_edit_search">&quot;Admin-&gt;Search&quot;</a> link.
				</li>
			</ul>
			<p class="page_config">
				To further the general control and operation of the web site, the following maybe useful;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Web site administrators can redirect the web site to another URL.
					Administrator can still login (using the &quot;https://your.web.site/site_alias/login.php&quot; URI) and administrator the site.
				</li>
				<li class="page_config">
					Web site administrators can close the web site.
					Administrator can still login (using the &quot;https://your.web.site/site_alias/login.php&quot; URI) and administrator the site.
				</li>
			</ul>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> settings are stored &quot;<?= ETC_MAN_INI_DIR ?>cms.ini&quot;.
				The applications settings are stored in &quot;<?= ETC_MAN_INI_DIR ?>apps.ini&quot;.
				The INI files are editable text files that can be changed in case of problems (typically during application development).
				Usually these values are changed through the &quot;Admin&quot; -&gt; menus
				(which requires a <?= CMS_PROJECT_SHORTNAME ?> system administrator to allow changes).
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> configuration is stored in a database (SQLite  by default or MySQL).
				These configuration values are permanent settings (e.g. support email, web site name, contact details, plug-in configs, etc.)
				and can be considered like hard coded values, and only changed through the &quot;Admin&quot; -&gt; menus
				(which requires a <?= CMS_PROJECT_SHORTNAME ?> system administrator to allow changes).
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="RunTime"></a>
			Applying Run Time Settings and Configurations
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> provides the mechanisms for run time definition of constants;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					All settings and configuration values are defined when &quot;https://your.web.site/site_alias/index.php[?optional_parameters]&quot; is engaged.
					As all operations URLs generated by the <?= CMS_PROJECT_SHORTNAME ?> contains the parameters for the required operation.
					And consequently the run time definitions are defined as part of the normal processing.
				</li>
				<li class="page_config">
					When calling AJAX operations through the &quot;https://your.web.site/site_alias/cms/cms_ajax.php?parameters&quot;
					the <?= CMS_PROJECT_SHORTNAME ?> AJAX pre-processor defines the settings and configuration values.
				</li>
				<li class="page_config">
					When calling web sockets operations through the &quot;https://your.web.site/site_alias/cms/cms_ws_client.php?parameters&quot;,
					from &quot;https://your.web.site/site_alias/ws_client.php?parameters&quot;,
					the <?= CMS_PROJECT_SHORTNAME ?> web sockets pre-processor defines the settings and configuration values.
				</li>
				<li class="page_config">
					However, in some cases the standard  &quot;index.php&quot;, &quot;ajax.php&quot;, &quot;api.php&quot;, &quot;login.php&quot; and  &quot;logout.php&quot; URIs
					may not be appropriate (typically CLI code), the best way to get the settings and
					configuration values defined is to;-<br>
					<pre class="page_config">require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );</pre>
					<br>at the top of the opening PHP file.
					This will provide the minimum run code for setting up definitions.
				</li>
			</ul>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> provides the five types of definitions identifiable by the prefixes in order of execution;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;CMS_S_&quot; are the <?= CMS_PROJECT_SHORTNAME ?> settings from the &quot;<?= ETC_MAN_INI_DIR ?>cms.ini&quot; settings file.
					The first definitions to get engaged at run time are in &quot;<?= ETC_MAN_INI_DIR ?>cms.ini&quot;.
					<br>
					<b>Important Note:</b> If the &quot;<?= ETC_MAN_INI_DIR ?>cms.ini&quot; settings file is edit manually
					and the changed values are used in the generation, a rebuild maybe requires to engage the settings. 
					Any theme settings will need a rebuild to engage (run &quot;./cms_lib_sqsh.sh -r&quot; from the command line).
			
				</li>
				<li class="page_config">
					&quot;CMS_C_&quot; are the <?= CMS_PROJECT_SHORTNAME ?> configuration values from the database &quot;cms_configs&quot; table.
					The second definitions to get run time code.
					These are in SQLite (&quot;<?= ETC_MAN_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE ?>&quot; or MySQL) <?= CMS_PROJECT_SHORTNAME ?> database.
				</li>
				<li class="page_config">
					&quot;LM_C_&quot; are the <?= CMS_PROJECT_SHORTNAME ?> &quot;Links Manager&quot; configuration values from the database &quot;cms_configs&quot; table..
					And are not used by applications.
					These are in SQLite (&quot;<?= ETC_MAN_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE ?>&quot; or MySQL) <?= CMS_PROJECT_SHORTNAME ?> database.
				</li>
				<li class="page_config">
					&quot;APPs_(APP_NAME)_&quot; (i.e. lowercase &quot;s&quot;) are the standard applications constant derived
					from the <?= CMS_PROJECT_SHORTNAME ?> database &quot;cms_bodies&quot; table.
					<br>
					<b>NOTE:</b> Changing name and directory values in the
					<a href="index.php?cms_action=cms_edit_bodies">&quot;Admin-&gt;Apps / Bodies&quot;</a>
					menu will require changing definition constants in the code.
				</li>
				<li class="page_config">
					&quot;APPS_&quot; (i.e. uppercase &quot;S&quot;) are the common applications settings.
					These are in &quot;<?= APPS_MAN_INCLUDE_DIR ?>apps_config.php&quot;.
				</li>
				<li class="page_config">
					&quot;
					&quot; are an individual application settings.
					The last definitions to get run time code.
					These are in &quot;<?= APPS_WS_DIR ?>(APP_DIR)/include/app_config.php&quot;.
					<b>Note:</b> only the requested app&rsquo;s &quot;<?= APPS_WS_DIR ?>(APP_DIR)/include/app_config.php&quot; file is executed (providing variability in definition).
				</li>
			</ul>
			<p class="page_config">
				<b>Notes on Recommended Mode Definitions</b>;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					For code running in command line (CLI) mode it is recommened that &quot;CLI_MODE&quot; is defined as &quot;true&quot;.
					This improves CLI operation and reduces the run time over head.
				</li>
			</ul>
			<p class="page_config">
				As a system administrator and with the debug mode enabled,
				the defined values at run time can found (and there definition)
				in the <a href="index.php?cms_action=cms_debug_vars">&quot;Admin-&gt;Debug Values&quot;</a> page.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="DynamicConfiguration"></a>
			Dynamic Configuration
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Subsequently to the static setup configuration, the <?= CMS_PROJECT_SHORTNAME ?> can use dynamic control configuration plugins for INI file values at the time of user engagement.
				The dynamic control plugins needs to be included in the included plugins configuration setting (&quot;CMS_C_ENABLED_PLUGINS&quot; setting).
			</p>
			<p class="page_config">
				Dynamic control uses a macro based on the &quot;<?= Ccms::MACRO_DELIM ?>class::method<?= Ccms::MACRO_DELIM ?>&quot; format, where the &quot;class&quot; is a user supplied plugin class name in
				&quot;<?= APPS_FS_PLUGINS_DIR ?>&quot; directory.
				The &quot;method&quot; is the user supplied static method in the &quot;class&quot;.
				The dynamic control plugin also has a static method to identify it as a dynamic controller, &quot;is_dynamic_controller()&quot; which returns &quot;true&quot; if it is a dynamic control plugin.
				Otherwise it is not present or returns &quot;false&quot;.
				See <a href="index.php?cms_action=cms_manual#Plugins">Plugins</a> for more information on plugins.
			</p>
			<p class="page_config">
				The &quot;KeyName&quot; from the INI file are supplied to the &quot;class::method&quot; as formal function parameters.
				e.g. &quot;class_name::method_name(Keyname);&quot;.
			</p>
			<p class="page_config">This allows dynamic configuration to be implemented (e.g. by user name, by group, etc.) to set <?= CMS_PROJECT_SHORTNAME ?> definitions to dynamic states at web page generation.</p>
			<p class="page_config">NOTE: Dynamic configuration is NOT intended for theme options as the theme is set when the save button is clicked.</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Apps"></a>
			Applications
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a local applications directory at &quot;<?= APPS_WS_DIR ?>&quot;, for the installation of applications and provide greater flexibility.
				The application directory provides somewhere to put local applications.
				This provides scope for larger and/or more free form code.
				The layout of the file structure under the &quot;<?= APPS_WS_DIR ?>&quot; is under the local web programmer's control.
			</p>
			<p class="page_config">
				However, the <?= CMS_PROJECT_SHORTNAME ?> requires some directory structure to allow code integration.
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>&quot; - the application base directory.
					See <a href="index.php?cms_action=cms_manual#DirectoryStructure">Directory Structure</a> for directory information.
				</li>
				<li class="page_config">&quot;<?= APPS_BODIES_DIR ?>&quot; - the application control directory.
					This directory has the initial code files (referred as &quot;body files&quot;) or links for each application.
					For most applications, the code file may contain some configuration code and/or an include statement to code in the &quot;<?= APPS_WS_DIR ?>&quot; directory.
				</li>
				<li class="page_config">&quot;
					<?= APPS_MAN_INCLUDE_DIR ?>&quot; - common application code include directory.
				</li>
				<li class="page_config"> &quot;<?= APPS_MAN_INCLUDE_DIR ?>apps_manual.php&quot; - a common technical manual for all applications.
						There is an example file, &quot;<?= APPS_MAN_INCLUDE_DIR ?>example_apps_manual.php&quot;.
					<?php if((file_exists(APPS_FS_APPS_MANUAL)) && (is_readable(APPS_FS_APPS_MANUAL))) { ?>
						In <a href="index.php?cms_action=apps_manual"><?= CMS_C_CO_NAME ?> Applications Technical Manual</a>.
					<?php	} // if ?>
						Each application with a &quot;(APP_DIR)&quot; directory can have a manual configuration value in the
						application configurations, <a href="index.php?cms_action=cms_edit_bodies">&quot;Admin-&gt;Apps / Bodies&quot;</a>, configuration page.
				</li>
				<li class="page_config">&quot;<?= APPS_MAN_INCLUDE_DIR ?>classes/&quot; - the general applications classes directory (the autoloader looks in here for general apps classes).</li>
				<li class="page_config">&quot;<?= APPS_MAN_INCLUDE_DIR ?>plugins/&quot; - the general applications plugins directory (the autoloader looks in here for general apps plugins).</li>
				<li class="page_config">&quot;<?= APPS_MAN_INCLUDE_DIR ?>apps_config.php&quot; - fixed configuration values for apps runtime (optional).
						There is an example file, &quot;<?= APPS_MAN_INCLUDE_DIR ?>example_apps_config.php&quot;</li>
				<li class="page_config">&quot;<?= APPS_MAN_INCLUDE_DIR ?>apps_rebuild.php&quot; - used to check and rebuild the apps as required (optional).
						There is an example file, &quot;<?= APPS_MAN_INCLUDE_DIR ?>example_apps_config.php&quot;</li>
				<li class="page_config">&quot;<?= APPS_MAN_INI_DIR ?>&quot; - the ini directory (the settings and install pages look in here).</li>
				<li class="page_config">&quot;<?= ETC_MAN_INI_DIR ?>apps.ini&quot; - the combined applications settings (one file to speed normal access).</li>
				<li class="page_config">&quot;<?= APPS_MAN_INI_DIR ?>apps.defaults.ini&quot; - the common default applications related settings.</li>
				<li class="page_config">&quot;<?= APPS_MAN_INI_DIR ?>apps.comments.ini&quot; - the descriptions/help text of common applications related settings.</li>
				<li class="page_config"><b>Important Note:</b> The &quot;<?= ETC_MAN_INI_DIR ?>apps.ini&quot;, &quot;<?= APPS_MAN_INI_DIR ?>apps.defaults.ini&quot; and &quot;<?= APPS_MAN_INI_DIR ?>apps.comments.ini&quot;
						cannot contain values that are defined constants. The global constants are being defined when these files are being executed at runtime.</li>

				<li class="page_config">&quot;<?= APPS_WS_DIR ?>cli/&quot; - common applications command line code.</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>lib/&quot; - common applications library code.</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>icons/&quot; - common applications icons (the icon selector will list icons in this directory).</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>images/&quot; - common applications images (the image selector will list images in this directory).</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>javascript/&quot; - common applications javascript code.</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?= APPS_WS_DIR ?>javascript/apps.js&quot; - common applications javascript
						code, added by application author.
						The <?= CMS_PROJECT_SHORTNAME ?> inserts a javascript link to the
						&quot;<?= APPS_WS_DIR ?>javascript/apps.js&quot; file in the &lthead&gt html,
						loading the javascript file automatically for all applications.
					</li>
				</ul>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>stylesheets/&quot; - common applications stylesheets (.css and .scss code).</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?= APPS_WS_DIR ?>stylesheets/apps.css&quot; - static common applications stylesheet.
						The <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet link,
						using the minify plugin generated link, into the &lthead&gt html,
						loading the stylesheet automatically for all applications.
					</li>
					<li class="page_config">&quot;<?= APPS_WS_DIR ?>stylesheets/apps.scss&quot; - static common applications stylesheet source code (.scss).
						The <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet &quot;.scss&quot; is compiled using the minify plugin (on the fly).
						The minify plugin returns a cached .css file link which is inserted into the &lthead&gt html,
						loading the stylesheet (.css) automatically for all applications.
					</li>
				</ul>
				<li class="page_config">
					&quot;<?= APPS_WS_DIR ?>include/apps_css.php&quot; - application specific theme recipe file.
					If present, is the inputs to theme taken from the &quot;(APP_KEY)_ThemeSettings&quot; section of the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/app.comments.ini&quot; values.
					This is used to generate the &quot;<?= ETC_WS_CSS_DIR ?>(APP_NAME)_app.css&quot; file.
					When the the application is called the <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet link to the
					&quot;<?= ETC_WS_CSS_DIR ?>(APP_NAME)_app.css&quot; file link in the &lthead&gt html,
					loading the stylesheet automatically.
				</li>

			</ul>

			<p class="page_config">
				Applications with an &quot;<?= APPS_WS_DIR ?>(APP_DIR)/&quot; directory have these individual application directories created for it.
				&quot;(APP_DIR)&quot; being the app directory name (or rename) given to the application.
				The &quot;(APP_DIR)&quot; directory provides modularity and separation to applications.
				And to allow automated application install and uninstall.
				<br>
				<b>NOTE:</b> Applications can be allowed to share the same application directory
				(<a href="index.php?cms_action=cms_edit_config&name=CMS_C_ALLOW_APPS_DIR_SHARE">&quot;Admin-&gt;Config-&gt;CMS_C_ALLOW_APPS_DIR_SHARE&quot;</a>).
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;<?= APPS_WS_DIR ?>(APP_DIR)/include/&quot; - application specific include directory.
				</li>
				<ul class="page_config">
					<li class="page_config">
						&quot;<?= APPS_WS_DIR ?>(APP_DIR)/include/app_config.php&quot; - application specific fixed configurations
						(the <?= CMS_PROJECT_SHORTNAME ?> includes this file
						<a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;Apps Config&quot;</a> menu if present).
					</li>
				</ul>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/classes/&quot; - application specific classes directory
									(the autoloader looks in here for app specific classes).</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/plugins/&quot; - application specific plugins directory
									(the autoloader looks in here for app specific plugins).</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/&quot; - application specific configuration.</li>
				<ul class="page_config">
					<li class="page_config">
						&quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/app.comments.ini&quot; - application menu control and help file
						(the <?= CMS_PROJECT_SHORTNAME ?> places these configs in the
						<a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;App Config&quot;</a> menu).
					</li>
					<li class="page_config">
						&quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/app.defaults.ini&quot; - application default values file
						(the <?= CMS_PROJECT_SHORTNAME ?> uses these values as default config values in the
						<a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;App Config&quot;</a> menu if present).</li>
					<li class="page_config">The &quot;app.comments.ini&quot; and &quot;app.defaults.ini&quot; are always used as a pair.
						The configured values are stored in the &quot;<?= ETC_MAN_INI_DIR ?>apps.ini&quot;
						and are defined as global constants prefixed by &quot;APP_(APP_KEY)_&quot;.
						The comments and values appear in the results in the
						<a href="index.php?cms_action=cms_edit_search">&quot;Admin-&gt;Search&quot;</a>.
					</li>
					<li class="page_config">
						The &quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/&quot; may have an applications specific control JSON file here.
						It is not assumed to be configured through the <?= CMS_PROJECT_SHORTNAME ?> menus
						and would be accessed by the applications.</li>
				</ul>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/cli/&quot; - application specific command line code.</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/lib/&quot; - application specific library code.</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/icons/&quot; - application specific icons (the icon selector will list icons in this directory).</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/images/&quot; - application specific images (the image selector will list images in this directory).</li>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/javascript/&quot; - application specific javascript code.</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/javascript/app.js&quot; - application specific javascript
						code, added by application author.
						When the the application is called the <?= CMS_PROJECT_SHORTNAME ?> inserts a javascript link to the
						&quot;<?= APPS_WS_DIR ?>(APP_DIR)/javascript/app.js&quot; file in the &lthead&gt html,
						loading the javascript file automatically.
					</li>
				</ul>
				<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/stylesheets/&quot; - application specific stylesheets (.css and .scss code).</li>
				<ul class="page_config">
					<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/stylesheets/app.css&quot; - static application specific stylesheet.
						When the the application is called the <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet link,
						using the minify plugin generated link, into the &lthead&gt html,
						loading the stylesheet automatically.
					</li>
					<li class="page_config">&quot;<?= APPS_WS_DIR ?>(APP_DIR)/stylesheets/app.scss&quot; - static application specific stylesheet source code (.scss).
						When the the application is called the <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet &quot;.scss&quot; is compiled using the minify plugin (on the fly).
						The minify plugin returns a cached .css file link which is inserted into the &lthead&gt html,
						loading the stylesheet (.css) automatically.
					</li>
				</ul>
				<li class="page_config">
					&quot;<?= APPS_WS_DIR ?>(APP_DIR)/include/app_css.php&quot; - application specific theme recipe file.
					If present, is the inputs to theme taken from the &quot;(APP_KEY)_ThemeSettings&quot; section of the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/app.comments.ini&quot; values.
					This is used to generate the &quot;<?= ETC_WS_CSS_DIR ?>(APP_NAME)_app.css&quot; file.
					When the the application is called the <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet link to the
					&quot;<?= ETC_WS_CSS_DIR ?>(APP_NAME)_app.css&quot; file link in the &lthead&gt html,
					loading the stylesheet automatically.
				</li>
				<li class="page_config">
					&quot;<?= APPS_WS_DIR ?>(APP_DIR)/include/app_scss.php&quot; - application specific theme recipe scss source code file.
					If present, is the inputs to theme taken from the &quot;(APP_KEY)_ThemeSettings&quot; section of the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/ini/app.comments.ini&quot; values.
					This is used to generate the &quot;<?= ETC_WS_CSS_DIR ?>(APP_NAME)_app_sass.css&quot; file.
					When the the application is called the <?= CMS_PROJECT_SHORTNAME ?> inserts a stylesheet link to the
					&quot;<?= ETC_WS_CSS_DIR ?>(APP_NAME)_app.css&quot; file link in the &lthead&gt html,
					loading the stylesheet automatically.
				</li>
			</ul>
			<p class="page_config">
				The <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;App Config&quot;</a> -&gt; checks to see if a &quot;<?= APPS_WS_STYLESHEETS_DIR ?>apps_scss.php&quot; is present.
				If so the save process generates a &quot;<?= ETC_WS_CSS_DIR ?>apps_sass.css&quot; from the &quot;<?= APPS_WS_STYLESHEETS_DIR ?>apps_scss.php&quot; for use in application web pages.
				This can be used to set extra theme or branding settings into the applications style sheet.
				See example_apps_scss.php&quot; in the examples for help.
			</p>
			<p class="page_config">
				The <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;App Config&quot;</a> -&gt; checks to see if a &quot;<?= APPS_WS_STYLESHEETS_DIR ?>apps_css.php&quot; is present.
				If so the save process generates a &quot;<?= ETC_WS_CSS_DIR ?>apps.css&quot; from the &quot;<?= APPS_WS_STYLESHEETS_DIR ?>apps_css.php&quot; for use in application web pages.
				This can be used to set extra theme or branding settings into the applications style sheet.
				See example_apps_css.php&quot; in the examples for help.
			</p>
			<p class="page_config">The application installation check method &quot;public static function do_app_warnings($bld = false)&quot;<br>
				Optional method in the application&rsquo;s top class (e.g. "<?= APPS_FS_DIR ?>(APP_DIR)/classes/(APP_NAME)_app::do_app_warnings()").
				If present the do_app_warnings() method is called when an admin logs in.
				This can be used to check the application has all the system packages, directories, etc. it needs to operate.
				If $bld is true, the method is being called from the rebuild so the app should initialise as required.
				<br>NOTE: The top (or primary) application class needs to conform to &quot;_app&quote; class name suffix.
			</p>
			<p class="page_config">The application post ini settings saved method &quot;public static function do_app_ini_saved()&quot;<br>
				Optional method in the application&rsquo;s top class (e.g. "<?= APPS_FS_DIR ?>(APP_DIR)/classes/(APP_NAME)_app::do_app_ini_saved()").
				If present the do_app_ini_saved() method is called after an admin saves the application config page.
				This can be used to make changes to an applications runtime configuration (e.g. reset caches, generate API URLs, etc.).
				<br>NOTE: The top (or primary) application class needs to conform to &quot;_app&quote; class name suffix.
			</p>
			<p class="page_config">
				The &quot;<?= ETC_MAN_INI_DIR ?>apps.ini&quot;, &quot;<?= APPS_MAN_INI_DIR ?>apps.defaults.ini&quot;
				and &quot;<?= APPS_MAN_INI_DIR ?>apps.comments.ini&quot; global (all applications) configuration files that are
				used together to a connection between help messages, default values and the config values.
				Values in &quot;<?= APPS_MAN_INI_DIR ?>apps.comments.ini&quot; containing defined constants are repleaced with the defined values.

				(Use the &quot;<?= ETC_MAN_INI_DIR ?>cms.ini&quot;, &quot;<?= CMS_MAN_INI_DIR ?>cms.defaults.ini&quot;
				and &quot;<?= CMS_MAN_INI_DIR ?>cms.comments.ini&quot; files as an example.)
				Values in &quot;<?= CMS_MAN_INI_DIR ?>cms.comments.ini&quot; containing defined constants are repleaced with the defined values.

				When present, the settings are managed by <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;App Config&quot;</a> menu,
				are read in and values are defined with a prefix of &quot;APP_&quot; plus the ini file keyname for use in the code.
				There are example in &quot;<?= ETC_MAN_INI_DIR ?>example.apps.ini&quot;, &quot;<?= APPS_MAN_INI_DIR ?>example.apps.defaults.ini&quot;
				and &quot;<?= APPS_MAN_INI_DIR ?>example.apps.comments.ini&quot; to help.
				Values in &quot;<?= APPS_MAN_INI_DIR ?>example.apps.comments.ini&quot; containing defined constants are repleaced with the defined values.
			</p>
			<p class="page_config">
				The access to the local applications is controlled by the <?= CMS_PROJECT_SHORTNAME ?> authentication.
				A <?= CMS_PROJECT_SHORTNAME ?> authenication plugin is provided in the <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
			<p class="page_config">
				By default, direct (authorised or not) access to files in &quot;.<?= APPS_WS_DIR ?>&quot; directory is denied.
				Access should be provided from page body contents pages/code.
				This ensures root document jumps are not possible.
			</p>
			<p class="page_config">
				A note on apps classes; it is recommended that the base class on all apps classes should be Ccms_app_bass
				(e.g Cmy_class extends Ccms_app_base ).
				The Ccms_app_base class provides interface to the main <?= CMS_PROJECT_SHORTNAME ?> and provides general functionality.
			</p>
			<p class="page_config">
				Examples of local applications are;- web page content provided by high level programming, specialized interface displays, just to name a few.
				Example files are available in the &quot;<?= CMS_MAN_EXAMPLES_ZIP ?>&quot; download to help show how to best these features of the <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
			<p class="page_config">
				Applications responding to API application calls can be engaged by the user povided &quot;<?= APPS_WS_DIR ?>api.php&quot; or by &quot;<?= APPS_WS_DIR ?>(APP_DIR)/api.php&quot; files.
				If present these application code files are checked by default after <?= CMS_PROJECT_SHORTNAME ?> calls are checked.
			</p>
			<p class="page_config">
				Applications with API maps provide the summary map array by calling <?= APPS_FS_DIR ?>(APP_DIR)/classes/(APP_NAME)_app::get_api_map();&quot;.
				The format can be Swagger V2.0 or <?= CMS_PROJECT_SHORTNAME ?> format.
				The <?= CMS_PROJECT_SHORTNAME ?> outputs the summary in Swagger V2.0 format, taking into account the role required to request each API call.
				See <a href="index.php?cms_action=cms_manual#APIops">API Operation</a> for more information.
			</p>
<?php if((file_exists(APPS_FS_APPS_MANUAL)) &&
		(is_readable(APPS_FS_APPS_MANUAL))) { ?>
			<p class="page_config">
				See also <a href="index.php?cms_action=apps_manual"><?= CMS_C_CO_NAME ?> Applications Technical Manual</a>.
			</p>
<?php	} // if ?>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="AppTypes"></a>
			Types of Applications
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Application types in <?= CMS_PROJECT_SHORTNAME ?>;-
			</p>
			<?= Ccms_DB_checks::get_apps_types_descriptions() ?>
			<p class="page_config">
				When the app / body is created or edited, the recommended sub-directories for the type of
				application are checked / created when saved. When an application directory is changed
				then the application directory is moved to the new directory.
			</p>
			<p class="page_config">
				When an application is used, the defined constants for the application directories
				are also generated, negating the need to manually create them
				(see <a hret="index.php?cms_action=cms_debug_vars">&quot;Admin-&gt;Debug Values&quot;</a>).
				These auto-generated body / app constants are prefixed with &quot;APPs_&quot; to distinguish them from the fixed/standard constants
				(standard constants/defines are prefixed with &quot;APPS_&quot; or &quot;APP_&quot;)
				(i.e. &quot;APPs_FS_*&quot; for filesystem access and &quot;APPs_WS_*&quot; for web access).
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="AppClass"></a>
			Primary Application Class
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				All applications can have a primary application class.
				For standard applications and close coupled applications the class is located in the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/classes/(APP_NAME)_app.php&quot; PHP source file.
				For other applications the class is located in the &quot;<?= APPS_MAN_CLASSES_DIR ?>(APP_NAME)_app.php&quot;,
				the C(APP_NAME)_app PHP class source file code.
			</p>
			<p class="page_config">
				The C(APP_NAME)_app class, the primary application class provide hierarchical access to the following optional methods;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;public static function get_ajax_text($ajax)&quot;<br>
					Executes the applications AJAX code.
					<br>
					Optional method.
				</li>
				<li class="page_config">&quot;public static function get_ws_text($wsid,$op)&quot;<br>
					Executes the applications WebSockets code.
					<br>
					Optional method.
				</li>
				<li class="page_config">&quot;public static function do_app_warnings()&quot;<br>
					Checks the application requirements when the user logs in.
				</li>
				<li class="page_config">&quot;public static function is_app_setup_key_funcs_used($key)&quot;<br>
					The <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;Apps Config&quot;</a> menu calls this method (function) for every KEY in the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns false;
					Else the method returns true.
					<br>
					<b>Required if</b> &quot;show_app_setup_value()&quot; or &quot;input_app_setup_form_text()&quot; or &quot;get_app_setup_form_value()&quot; is in use.
					Otherwise an optional method.
				</li>
				<li class="page_config">&quot;public static function show_app_setup_value($sect,$key,$name,$value)&quot;<br>
					The <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;Apps Config&quot;</a> menu calls this method (function) for every KEY=VALUE pair in the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns false;
					Else the method generates text to show the $value for $key.
					<br>
					Used as &quot;_show_func&quot; similar to JSON format. Optional method.
				</li>
				<li class="page_config">&quot;public static function input_app_setup_form_text($sect,$key,$name,$value)&quot;<br>
					The <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;Apps Config&quot;</a> menu calls this method (function) for every KEY=VALUE pair in the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns false.
					Else the method generates form input element text to input the $value for $key using $name for the input element.
					<br>
					Used as &quot;_form_input_func&quot; similar to JSON format. Optional method.
				</li>
				<li class="page_config">&quot;public static function get_app_setup_form_value($sect,$key,$name,$value)&quot;<br>
					The <a href="index.php?cms_action=cms_edit_apps">&quot;Admin-&gt;Apps Config&quot</a> menu calls this method (function) for every KEY=VALUE pair in the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/app_comments.ini&quot;
					If not required for this $key, the method returns null (i.e. no input from form)
					Else the method gets the input element under $name from the posted form returns the value text to be saved.
					<br>
					Used as &quot;_form_get_func&quot; similar to JSON format. Optional method.
				</li>
				<li class="page_config">&quot;public static function &get_ini_app_input_ctl()&quot;<br>
					This method provides access to a HTML input generator for the applications INI settings to allow the application to.
					control (possibly generate if 'options_func' is provided) the form input elements.
					An example of the returned control array is;-<br>
					<pre class="page_config">
		protected static $my_ini_ctls = array(
			'MY_CUSTOM_COLOURS' => array(	// ini_key to match
				'type' => 'multi_input',	// input or multi_select
				'col_heads' => 'Name:Hex RGB Colour',	// e.g. "Name" is first column heading : "Hex RGB Colour" is second column heading, etc.
				'val_sep' => ':',	// separator used values
				'data_sep' => '=',	// separator between name and value (e.g. name=>value), optional
				'options_func' => 'get_my_custom_colours_options',	// method name to use in the primary application class, optional.
				),
			// etc,
			);
		return $my_ini_ctls;	// it's a reference (i.e. static)
					</pre>
				</li>
				<li class="page_config">&quot;public static function &amp;get_api_map_summary()&quot; for API mapping. See <a href="index.php?cms_action=cms_manual#APIops">API Operation</a>.</li>
				<li class="page_config">&quot;public static function &amp;get_head_text()&quot;
					returns an array of text (meta values, etc.) to be checked for duplicates and inserted into the &quot;&lt;head&gt;&quot; to &quot;&lt;/head&gt;&quot; section.
					For example;-<br>
					<pre class="page_config">
		protected static $my_head = array(
			// type => data text arrays
			'title' => 'My Page Title',	// a new title to use
			'meta' => array('name="generator" content="From Me"','name="author" content="Me"', ... ),	// an array()
			'link' => array('rel="stylesheet" href="path/to/my/styles.css"', ... ),	// an array()
			'script' => array('type="text/javascript" src="path/my/javascript.js"', ... ),	// an array()
			etc.
			);
		return $my_head;	// it's a reference (i.e. static)
					</pre><br>
					Or a text string (not recommended) to insert into the &quot;&lt;head&gt;&quot; to &quot;&lt;/head&gt;&quot; section.
				</li>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Languages"></a>
			Languages
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> is capable of translating HTML text.
				The language translation can be on an application/s or all applications.
			</p>
			<p class="page_config">
				Administration page for <?= CMS_PROJECT_SHORTNAME ?> are always presented in the <?= CMS_LANG_DEFAULT ?> language,
				so any conflicts can resolved without showing in a language that can be read.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="APIops"></a>
			API Operation
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a basic API front end for processing API requests.
				The <?= CMS_PROJECT_SHORTNAME ?> has internal API calls available for admin and information and documentation.
				Admin requests are protected by a token provided that is generated by the <?= CMS_PROJECT_SHORTNAME ?>.
				Informational API requests for open (non secured) data don&rsquo;t need a token.
			</p>
			<p class="page_config">
				To access the API, <a href="index.php?cms_action=cms_edit_config&name=CMS_C_API_ENABLE">the API interface must be enabled</a>,
				the user must login as an administrator or login as a user with API access enabled.
				<br><b>Important Note:</b> API operation requires the Apache rewrite module to be enabled.
				If not enabled, the <a href="index.php?cms_action=cms_api_test">&quot;Admin-&gt;API Test&quot;</a>
				generates &quot;Failed to load API definition.&quot; error.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> API interfaces use security tokens in the requests header and the response headers,
				and are not exposed through variables in &quot;GET&quot;, &quot;POST&quot;, &quot;PUT&quot;, etc.
				Where the API client sends a session ID, the ID is used as the security token (similar to a web page), via the session cookie.
				This makes the API easier to use via web pages and ancillary network processes tied to a web page.
				If no session ID is available, the <?= CMS_PROJECT_SHORTNAME ?> API will generate a unique security token to use.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> API can be changed by modifying or replacing the &quot;/api.php&quot; code.
			</p>
			<p class="page_config">
				All API requests and responses are by secure protocols (i.e. https/SSL).
			</p>
			<p class="page_config">
				API summary call maps makes the API self documenting.
			</p>
			<p class="page_config">
				An API mapping function, &quot;public static function &get_api_map_summary()&quot;,
				in the <a href="index.php?cms_action=cms_manual#AppClass">Primary Application Class</a> is used by the
				<?= CMS_PROJECT_SHORTNAME ?> to obtain the API summary map from the application.
				The return value is an array that has the following minimum requirements for the API call.
				Here is an example of the return summary map for an application;- <br>
			</p>
			<p class="page_config">
				<?php insert_man_drop_box('h4','Example API Map',CMS_FS_INCLUDE_MANUAL_DIR . 'example_api_map.php') ?>
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> API interface can usually provide the correct defaults for the other details.
				The correct use of headers also will negate the need for details summary maps, as the header Content-Type, etc. will override the summary map.
				For most situations a complete summary/resource map is for the user&rsquo;s API client, so the level of detail for user requirements.
			</p>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The &quot;path&quot; variable will be prefixed with the (APP_NAME) by the
					<?= CMS_PROJECT_SHORTNAME ?> in the global summary map.
				<br>
				When the <?= CMS_PROJECT_SHORTNAME ?> is rebuilt or when installation/configuration is saved,
				the <?= CMS_PROJECT_SHORTNAME ?> requests API summary updates from allowed applications.
			</p>
			<p class="page_config">
				Provided the API is enabled, see functional API client example;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Click <a href="index.php?cms_action=cms_api_test">&quot;Admin-&gt;API Test&quot;</a>.
					This provides a &quot;Swagger UI&quot; from the &quot;Swagger&quot; distribution bundle installed as a library.
				</li>
				<li class="page_config">
					The download &quot;<?= CMS_WS_EXAMPLES_DIR . 'API_client-' . CMS_PROJECT_VERSION . '.zip' ?>&quot;
					file contains a basic command line API client example.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="APIauth"></a>
			API Authentication and Authorization.
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> API can use these API authentication and authorization methods.
				See <a href="index.php?cms_action=cms_edit_config&name=CMS_C_API_AUTH">&quot;Admin-&gt;Config-&gt;CMS_C_API_AUTH&quot;</a> to select.
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;Session Cookie&quot; - Session cookie authentication (always enabled) is for access to a single endpoint/server.
					The session cookie uses a browser session ID (SID) in the session cookie to authenticate access.
					The SID is passed back and forth between the client and server.
					The session cookie authentication is the commonly used by browser &lt;-&gt; server authentication,
					often used with web site authentication.
					With this method, &quot;<?= Ccms_api::API_TOK_KEY ?>&quot; value is in the headers.
				</li>
				<li class="page_config">
					&quot;JSON Web Token&quot; - The JSON web token (JWT) authorization
					can be used and can provide authorisation to a multiple endpoints/servers.
					<ul class="page_config">
						<li class="page_config">
							For JWT, it is recommended that <?= CMS_PROJECT_SHORTNAME ?> only uses SSL algorithms,
							using a private key and public key (OpenSSL) for authorization.
							(see <a href="index.php?cms_action=cms_edit_config&name=CMS_C_JWT_ALG">&quot;Admin-&gt;Config-&gt;CMS_C_JWT_ALG&quot;</a> to configure).
							A new SSL JWT uses new SSL private key and public key pair is generated for each API authenticated user.
							This is highest security available because after the JWT signature is generated, the private key is deleted,
							making it practically impossible to reproduce the same JWT.
							Only the public key is required authorize the API access.
							The user&rsquo;s public key is saved on <?= CMS_PROJECT_SHORTNAME ?> server.
							This means the authenticated user must be available on the <?= CMS_PROJECT_SHORTNAME ?> server,
							has a user&rsquo;s public key and the JWT can be authorised using the users&rsquo;s public key.
						</li>
						<li class="page_config">
							For non OpenSSL JWT signatures are unique for each user.
							But security is much lower than using OpenSSL algorithms.
						</li>
						<li class="page_config">
							The JWT is not perpetual, it currently expires after a <?= CMS_C_JWT_EXPIRE_HRS ?> hours
							(see <a href="index.php?cms_action=cms_edit_config&name=CMS_C_JWT_EXPIRE_HRS">&quot;Admin-&gt;Config-&gt;CMS_C_JWT_EXPIRE_HRS&quot;</a> to configure).
						</li>
						<li class="page_config">
							The JWT is POSTed back the API client under the &quot;<?= Ccms_api::API_JWT_KEY ?>&quot; index, to use for subsequent authorisations.
						</li>
						<li class="page_config">
							To share authorization access to multiple endpoints, only the public key needs to be shared between endpoints.
						</li>
						<li class="page_config">
							If JWT is enabled, an API &quot;/session/open&quot; call returns a JWT in the response.
							All other API calls that contain a JWT in the request are authorised by the JWT.
							The JWT identifies the user on the <?= CMS_PROJECT_SHORTNAME ?> server,
							therefore the user&rsquo;s role and access rights are part of the JWT.
							And the <?= CMS_PROJECT_SHORTNAME ?> server does not need (or use) session storage.
						</li>
						<li class="page_config">
							An optional user signature can be included in the JWT.
							(see <a href="index.php?cms_action=cms_edit_config&name=CMS_C_API_USER_SIG">&quot;Admin-&gt;Config-&gt;CMS_C_API_USER_SIG&quot;</a> to configure, enabled by default).
							Having the user&rsquo;s signature included in the JWT means that the user&rsquo;s information at each API endpoint must be identical and unchanged (including the user&rsquo;s modified timestamp).
						</li>
						<li class="page_config">
							To aid the propagation of a user&rsquo;s public_key and configuration,
							a list of API endpoints can be used.
							(see <a href="index.php?cms_action=cms_edit_config&name=CMS_C_API_ENDPOINTS">&quot;Admin-&gt;Config-&gt;CMS_C_API_ENDPOINTS&quot;</a> to enter endpoints).
							The endpoints are update when a user/client authenticates (new public_key) or when the user&rsquo;s signature (if enabled) changes.
						</li>
					</ul>
					<b>Important Note:</b> Tampering with the JWT will render the JWT useless.
					The JWT will no longer authorise against the public_key on the endpoint.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="WebSocks"></a>
			Web Sockets
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			@TODO rewrite section
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> provides settings and configuration values for websockets redirection to connect the client 
				to the websockets daemon/server running the applications real time code.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="htaccess"></a>
			Access (DOCROOT)/.htaccess File
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				To use the <?= CMS_PROJECT_SHORTNAME ?> API, it is required that some form of rewrite from virtual folder
				(the API path is a virtual folder location) to a PHP file.
				The following insert to the (DOCROOT)/.htaccess file is recommended;-
				<pre class="page_config">
					<?= htmlentities(Ccms::get_rewrite_htaccess_text()) ?>
				</pre>
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Plugins"></a>
			Plugins
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<b>NOTE:</b> Plugins have an important difference to classes (although a plugin is a class),
				in that a plugin has its own set of configuration features.
			</p>
			<p class="page_config">
				Users defined plugins can be placed in &quot;<?= APPS_MAN_INCLUDE_DIR ?>plugins&quot; or in the &quot;<?= APPS_WS_DIR ?>(APP_DIR)/plugins/&quot;.
				The plugin class needs to be extended from the &quot;Ccms_plugin_base&quot; class (e.g. &quot;class Cmy_plugin_class_name extends Ccms_plugin_base&quot;, The &quot;C&quot; prefix is a convention adopted in the &quot;<?= CMS_PROJECT_SHORTNAME ?>&quot; for classes and plugins.).
				And appear in the <a href="index.php?cms_action=cms_edit_config">&quot;Admin-&gt;Config&quot;</a> page prefixed with &quot;Plugin&quot;.
			</p>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The <?= CMS_PROJECT_SHORTNAME ?> class autoloader finds classes and plugins by their PHP filename and the class name being the same (removing any &quot;C&quot; prefix).
				The class file may have hidden classes, not directly loaded by the autoloader, within the autoloaded class file which are included in the primary PHP class map upon reading the autoloaded class file.
			</p>
			<p class="page_config">
				<?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?> provides the following included plugins in the &quot;<?= CMS_WS_PLUGINS_DIR ?>&quot; directory;
			</p>
			<ul class="page_config">
				<li class="page_config">
					Social Media - a plugin to interface a group of social media sub-plugins;
					<ul class="page_config">
						<li class="page_config">
							Facebook - a general Facebook &reg; sub-plugin.<br>
							NOTE: At this time, the &quot;center_right&quot; position, the Facebook generated fly out goes off the right side of the screen and cannot be viewed, it is disabled at this position.
						</li>
						<li class="page_config">
							Linkedin - a general Linkedin &reg; sub-plugin (not displayed on most tablet devices).
						</li>
					</ul>
					Social media links are not displayed on tiny devices (e.g. iPods, iPhones, etc).
				</li>
				<li class="page_config">
					Email - a general server side email plugin for use with other plugins.
				</li>
				<li class="page_config">
					Gotcha - a security plugin for use with the Email plugin, etc.
				</li>
				<li class="page_config">
					Contact Us - a standardized server side contact us web code/page generator plugin.
				</li>
				<li class="page_config">
					Map Latitude Longitude - a standardized server side map code/page generator plugin.
					A basic implementation intended to show location for &quot;contact us&quot; pages is included.
				</li>
				<li class="page_config">
					Authentication - a standardized external authentication that provides a method to authenticate from external sources.
					Takes a local application plugin_name and uses the plugin_name::auth(username,password) method to authenticate users.
				</li>
				<li class="page_config">
					Media Converter - a media converter plugin for converting files (e.g. Markdown .md and text .txt) to html format.
					And to encapsulate images (e.g. mp4, .png, .gif, etc.) for the user&rsquo;s web site.
					Engaged by using &quot;Ccms_media_conv_plugin::get_file_href(URI,NAME)&quot; to generate the link.
					The files are shown are in standard page for the user&rsquo;s web page (i.e. branded to the user&rsquo;s branding).
					The media plugin is primarily intended for documentation purposes.
					<br>
					<b>WARNING:</b> The plugin will not show external information (i.e. from outside this web site scope).
				</li>
				<li class="page_config">
					GeoIP - finds the geographical location of a IP address using a users&rsquo;s Maxmind credentials.
				</li>
				<li class="page_config">
					Translate - a language translation and cache plugin.
				</li>
				<li class="page_config">
					Minify - a javascript (JS) and stylesheet (CSS) minifier/compressor.
				</li>
				<li class="page_config">
					Appointment booking calendar - provides a basic appointment/scheduler with SMS (when enabled) and email notification.
				</li>
				<li class="page_config">
					SMS messaging - provides an SMS messaging interface for SMS notification. Requires configuration values from a provider.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="PluginExtends"></a>
			Plugin Extensions
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Plugins can have extensions used to add entry/s to the &quot;Admin&quot; menu and to the &quot;Main Menu&quot; menu.
				The  &quot;Main Menu&quot; menu items can be selectively added to the navigation bar, left column or right column.
			</p>
			<p class="page_config">
				The plugin can have the following static methods to integrate into the <?= CMS_PROJECT_SHORTNAME ?>;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;public static function get_admin_uris()&quot;<br>
					to add the entry/s to the &quot;Admin&quot; menu.
					The returned values are an array. For example in JSON form;-
					<pre class="page_config">
	{
		"app_name": "(APP_NAME)", (required, can be plugin class name on the common apps extensions).
		"app_dir": "(APP_DIR)", (optional, not present on the common apps extensions).
		"app_uri": "(app_uri)", (optional, e.g."index.php?app=4" where 4 is the app/body ID or (APP_NAME), not present on the common apps extensions).
		"0":{
			"text": "Setup App Config",
			"uri": "index.php?app=(id/(APP_NAME)/(APP_DIR)&admin_params ... ", (URL direct to to page with parameters)
			"func": "someClass::getConfig", (or callable class::method or function, no 'uri' element)
			"title": "Setup App Configuration ..." (optional)
		},
		"1":{
			"text": "Setup App Something",
			"uri": "index.php?app=(id/(APP_NAME)/(APP_DIR)&other_admin_params ... ", (URL direct to to page with parameters)
			"func": "someClass::getOtherConfig", (callable class::method or function, no 'uri' element)
			"title": "Setup App Something ...", (optional)
			"params": "Array of key = value params passed to callable methods/functions (optional)."
			"app_name": "(APP_NAME)", (optional, used by uri, as required)
			"app_dir": "(APP_DIR)", (optional, used by the <?= CMS_PROJECT_SHORTNAME ?> to include the application CSS and JS files)
		},
	}
					</pre>
				</li>
				<li class="page_config">&quot;public static function get_menu_uris()&quot;<br>
					to provide application entries to the left column, right and navigation bar selectively.
					The entries are used as part of the selection lists.
					The returned values are an array. For example in JSON form;-
					<pre class="page_config">
	{
		"app_name": "(APP_NAME)", (required, can be plugin class name on the common apps extensions).
		"app_dir": "(APP_DIR)", (optional, not present on the common apps extensions).
		"app_uri": "(app_uri)", (optional, e.g."index.php?app=4" where 4 is the app/body ID or (APP_NAME), not present on the common apps extensions).
		"always": true	(true = always show, don't filter)
		"0":{
			"role": "admin|manager|user|(empty|public)", (optional, sets level of access to menu item, else follows page settings)
			"text": "Get Transactions",
			"uri": "index.php?app=(id/(APP_NAME)/(APP_DIR)&params ... ", (URL direct to to page with parameters)
			"func": "someClass::getTransactions", (or callable class::method or function, no 'uri' element)
			"title": "By account ..." (optional)
		},
		"1":{
			"role": "admin|manager|user|(empty|public)", (optional, sets level of access to menu item, else follows page settings)
			"text": "Import transactions",
			"uri": "index.php?app=(id/(APP_NAME)/(APP_DIR)&other_params ... ", (URL direct to to page with parameters)
			"func": "someClass::someOtherMethod", (can be a URL or a callable class::method or function, no 'uri' element)
			"title": "Import CSV or XML file", (optional)
			"params": "Array key = value params passed to callable methods/functions (optional)."
			"app_name": "(APP_NAME)", (optional, used by uri, as required)
			"app_dir": "(APP_DIR)", (optional, used by the <?= CMS_PROJECT_SHORTNAME ?> to include the application CSS and JS files)
		},
	}
					</pre>
				</li>
				<li class="page_config"><b>Notes:</b>
					<ul class="page_config">
						<li class="page_config">
							Local URLs are with reference to &lt;base href meta data in the page header.
						</li>
						<li class="page_config">
							There is no limit to the number of admin URIs except for the ability to fitted them on the window.
						</li>
						<li class="page_config">
							The variable name &quot;body&quot; is interchangeable with the variable name &quot;app&quot; in URIs.
						</li>
					</ul>
				</li>
				<li class="page_config">&quot;public static function read_app_comments_ini()&quot;<br>
					Is used retrieve an array of the extended applications control JSON.
					This allows the controls to be searched.
					It is associated with index 0 from the &quot;get_admin_uris()&quot; return;
				</li>
				<li class="page_config">&quot;public static function read_app_settings_ini()&quot;<br>
					Is used to retrieve an array of the extended applications settings JSON.
					This allows the setting to be searched.
					It is associated with index 0 from the &quot;get_admin_uris()&quot; return;
				</li>
				<li class="page_config">&quot;public static function get_apps_extend_settings()&quot;<br>
					Is used generate the setup page from the extended applications settings JSONs and
					read in and save the POSTed data from the browser.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="AppsAuth"></a>
			Applications Authentication
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				In addition to the local applications the <?= CMS_PROJECT_SHORTNAME ?> can use a user provided authentication.
				The &quot;Capps_auth&quot; class is the &quot;<?= APPS_MAN_INCLUDE_DIR ?>classes/apps_auth.php&quot; class file.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> requires the &quot;Capps_auth&quot; to have following public static methods;-
			</p>
			<ul class="page_config">
				<li class="page_config">&quot;public static function is_page_allowed($name_app_name)&quot;<br>
					Returns true if page is allowed.
					Used for fine control of pages.
				</li>
				<li class="page_config">&quot;public static function is_navbar_element_allowed($name)&quot;<br>
					Returns true if nav bar element is allowed.
					Used for fine control of nav bar elements.
				</li>
				<li class="page_config">&quot;public static function login($user, $password)&quot;<br>
					Authenticates the $user (per application requirements).
					If authenticated, executes any application login code
					and returns &quot;true&quot; else return &quot;false&quot; for login denied.
				</li>
				<li class="page_config">&quot;public static function init($user)&quot;<br>
					Called just after the web server session has started and the session  variables are available.
					The user value will be false if no user is logged in or the user name if logged in.
					This is for applications initialization.
					If &quot;init($user)&quot; is ok it returns &quot;true&quot;.
					Else returns &quot;false&quot; for denied
					(and will subsequently log the user out of the <?= CMS_PROJECT_SHORTNAME ?>).
				</li>
				<li class="page_config">&quot;public static function is_login_current()&quot;<br>
					Used to check if apps user is still current with a remote second authenticator, possibly.
					Return null is not used or don't know, false = no, true = logged in still,
				</li>
				<li class="page_config">&quot;public static function logout()&quot;<br>
					Log out current user (per application requirements).
					If logged in it returns &quot;true&quot; else return &quot;false&quot; if not logged in.
				</li>
				<li class="page_config">&quot;public static function get_short_name()&quot;<br>
					Provides a short name (e.g. a well known acronym) that is suitable user selection text (i.e. in a drop down).
				</li>
				<li class="page_config">&quot;public static function get_title()&quot;<br>
					Provides a title for the authentication method (i.e. text for tooltip or bubble).
				</li>
				<li class="page_config">&quot;public static function get_JS()&quot;<br>
					Provides the APP AUTH login javascript, if used (called before get_html).
				</li>
				<li class="page_config">&quot;public static function get_html()&quot;<br>
					Provides the APP AUTH login html, if used.
				</li>
				<li class="page_config">&quot;public static function do_apps_warnings()&quot;<br>
					Optional method. If present the Capps_auth::do_apps_warnings() method is called when an admin logs in.
					The do_apps_warnings() can be used to check that the system requirements are met.
				</li>
			</ul>
			<p class="page_config">
				<b>IMPORTANT NOTE:</b> The &quot;Capps_auth&quot; class provides authentication only for the <?= CMS_PROJECT_SHORTNAME ?>.
				It does not provide the <?= CMS_PROJECT_SHORTNAME ?> login execution code.
				Other application code is engaged by the user supplied code.
			</p>
			<p class="page_config">
				An example at &quot;<?= APPS_MAN_INCLUDE_DIR ?>classes/example_apps_auth.php&quot; file is included.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Localtools"></a>
			Local Tools
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a local tools directory at &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot;, for the installation of web based tools and extras.
				The local tools directory provides somewhere to put web applications / pages (tools).
				Each tool should be given a unique directory to occupy.
				Examples of tools are;- conversion tables, code checkers, procedures, manuals, just to name a few.
			</p>
			<p class="page_config">
				If you have tools installed on the host that are not under the &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot; directory,
				these tools can be accessed by using a symlink.
				This allows these non-local tools to be appear in the Local Tools setup.
				<br><br>
				<b><u>Synlinked Local Tools EXAMPLES:</u></b><br>
				<b>On LINUX</b>, to setup HTdig, make a symlink by going to the &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot; directory,
				and execute &quot;ln -s /usr/share/htdig htdig&quot;,
				where &quot;/usr/share/htdig&quot; is the path to the HTdig web pages.
				This allows HTdig to be used as the Local Tool.
				<br>
				A similar tool setup can used for the Apache Manual.
				Execute &quot;ln -s /var/www/manual Apache Manual&quot; in the &quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot; directory,
				where &quot;/var/www/manual&quot; is the path to the Apache Manual web pages.
			</p>
			<p class="page_config">
				To help separate images and icons for tools, that are not part of the tool files,
				two directories are for tool images and icons used by <?= CMS_PROJECT_SHORTNAME ?>,
				usually for menus, etc.
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;<?= LOCAL_WS_TOOLS_DIR ?>&quot; base directory for local tools.
				</li>
				<li class="page_config">
					&quot;<?= LOCAL_WS_TOOLS_IMAGES_DIR ?>&quot; directory is used for local tool images.
					Images used by the tool are also packaged when building a tool package.
				</li>
				<li class="page_config">
					&quot;<?= LOCAL_WS_TOOLS_ICONS_DIR ?>&quot; directory is used for local tool icons.
					Icons used by the tool are also packaged when building a tool package.
				</li>
			</ul>
			<p class="page_config">
				During tool setup, the &quot;<?= LOCAL_WS_TOOLS_ICONS_DIR ?>&quot; directory is searched for filename extensions of .htm .php .html and .txt
				The tool could be a complete sub-web site.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="WYSIWYGs"></a>
			WYSIWYGs
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> can use WYSIWYG HTML page editors.
				WYSIWYGs are configured by using the <?= CMS_PROJECT_SHORTNAME ?> WYSIWYG configuration editor.
				Use <a href="index.php?cms_action=cms_edit_search&keywords=wysiwyg">&quot;Admin-&gt;Search</a>-&gt;WYSIWYG&quot;</a> to find configuration.
				WYSIWYGs are installed in the &quot;<?= APPS_WS_LIB_DIR ?>&quot; library directory as a third party library.
				There is a simple default configuration in the &quot;<?= ETC_FS_CMS_WYSIWYGS ?>&quot; file.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> WYSIWYG configuration element are;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					<b>title</b> - Title for WYSIWYG (not the name).
				</li>
				<li class="page_config">
					<b>type</b> - Type of WYSIWYG, select from browser, system, library or custom.
				</li>
				<li class="page_config">
					<b>comment</b> - A general comment about the WYSIWYG.
				</li>
				<li class="page_config">
					<b>library_uri</b> - An initialisation URI (typically to javascript, php, etc.) to setup the WYSIWYG (provided by WYSIWYG,optional).
				</li>
				<li class="page_config">
					<b>engage_class</b> - WYSIWYG engagement class. Used to extend the <?= CMS_PROJECT_SHORTNAME ?> base WYSIWYG &quot;Ccms_wysiwyg&quot; class for more customisation.
					Typically, the &quot;engage_class&quot; overrides the &quot;library_uri&quot; and
					&quot;engage_uri&quot;, and the &quot;library_uri&quot; and &quot;engage_uri&quot; are empty.
					However, if the &quot;library_uri&quot; and &quot;engage_uri&quot; have values,
					the <?= CMS_PROJECT_SHORTNAME ?> base &quot;Ccms_wysiwyg&quot; class will still engage these values.
					<br>
					The &quot;engage_class&quot; is used to extend the <?= CMS_PROJECT_SHORTNAME ?> &quot;Ccms_wysiwyg&quot; class.
					The WYSIWYG code execution then uses to &quot;engage_class&quot;.
					The &quot;engage_class&quot; is usually custom code written for the particular WYSIWYG.
					If no &quot;engage_class&quot; is available, the <?= CMS_PROJECT_SHORTNAME ?> falls back
					to using the &quot;library_uri&quot; and &quot;engage_uri&quot; values.
					<br>
					<b>Note:</b> if not overridden by the &quot;engage_class&quot;,
					a &lt;textarea&gt; with a id and name of &quot;ws_text_area&quot; containing the html
					to be edited by the WYSIWYG editor is generated.
				</li>
				<li class="page_config">
					<b>engage_uri</b> - The URI (typically javascript, php, etc.) to engage the WYSIWYG (usually a custom script,optional).
				</li>
				<li class="page_config">
					<b>configurable</b> - Boolean true/false value to indicate the WYSIWYG in configurable.
				</li>
				<li class="page_config">
					<b>enabled</b> - Boolean true/false to indicate whether the WYSIWYG is enabled.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="Sitemap"></a>
			Sitemap
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a search engine compatible XML sitemap generator and a HTML sitemap generator builtin.
				As changes are made to configuration and contents of the web site, the sitemap is automatically updated.
				To manually update the sitemap goto &quot;http://your.web.site/site_alias/index.php?cms_action=update_sitemap&quot;.
				<br>
				NOTE: If the sitemap filename is not setup, no sitemap file is generated.
			</p>
			<p class="page_config">
				The XML sitemap is available at &quot;http://your.web.site/site_alias/<?= CMS_SITEMAP_XML_FILE ?>.xml&quot; (replace &quot;your.web.site/site_alias/&quot; with your domain name and alias, if any, for <?= CMS_PROJECT_SHORTNAME ?> installation).
				<br>
				The HTML sitemap is available at &quot;http://your.web.site/site_alias/<?= CMS_SITEMAP_HTML_FILE ?>.xml&quot; (replace &quot;your.web.site/site_alias/&quot; with your domain name and alias, if any, for <?= CMS_PROJECT_SHORTNAME ?> installation).
				<br>
				NOTE: The name of the sitemap can be configured in the <a href="index.php?cms_action=cms_edit_install">&quot;Admin-&gt;Install</a>-&gt;Xml Sitemap File&quot; setting.
				The primary link URL in the sitemap is the same URL in <a href="index.php?cms_action=cms_edit_config">&quot;Admin-&gt;Config</a>-&gt;Main Web Site URL&quot; setting.
			</p>
			<p class="page_config">
				The sitemap can be generated from the command line.
		`	</p>
`			<ul class="page_config">
				<li class="page_config">On a LINUX server, in a console shell, goto the web site&rsquo;s &quot;<?= CMS_WS_CLI_DIR ?>&quot; directory and run &quot;<?= CMS_MAN_CLI_DIR ?>cms_generate_sitemap.sh&quot;.</li>
			</ul>
				Successful sitemap generation looks like this;-

			<pre class="page_config">
				Starting -&gt; sitemap generator for <?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?>.
				INFO: Created sitemap &quot;/web-site-root-directory/sitemap.xml&quot; (Link=sitemap.xml)
				Finished -&gt; sitemap generator for <?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?>.
			</pre>
			<p class="page_config">
				Where sitemap name is set to &quot;sitemap&quot;.<br>
				If any errors or warnings occurred, these will be printed out.
		`	</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="special_code"></a>
			Special Code
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has a special code directory for PHP code
				(e.g. for Google analytics code and social media code)
				at  &quot;<?= ETC_FS_EXT_INCLUDES_DIR ?>&quot;.
				Any analytics (e.g. from Google) code or special socal media code should be placed in this directory.
				The code (usually PHP, HTML, javascript, etc.) is included at the appropiate point by the <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="coding_shortcuts"></a>
			Coding Shortcuts and Builtin Features
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has many coding shortcuts and builtin features that are accessible to applications.
				These include:-
			</p>
			<ul class="page_config">
				<li class="page_config">
					Global Definitions - The <?= CMS_PROJECT_SHORTNAME ?> works out where it is and presets the coders/programmers definitions with all the &quot;(DOCROOT)/&quot; file structure defined.
					It is important to use these &quot;defined&quot; constants to maintain future proofing your code.
					Login as an administrator (and turn on the debug mode if necessary) and click on <a href="index.php?cms_action=cms_debug_vars">&quot;Admin-&gt;Debug Values&quot;</a>.
					This displays a searchable list of all the <?= CMS_PROJECT_SHORTNAME ?> definitions.
					Code execution type global defines to aid in identifying operation are provided;-
					<ul class="page_config">
						<li class="page_config">
							&quot;WWW_CALL&quot; defined at the start of web execution.
						</li>
						<li class="page_config">
							&quot;AJAX_CALL&quot; defined at the start of AJAX code execution.
						</li>
						<li class="page_config">
							&quot;API_CALL&quot; defined at the start of API code execution.
						</li>
						<li class="page_config">
							<B>Note:</b> The code type defines can be overridden by user provided replacement/hierarchically code.
							If is recommended that this code also provide the global type defines.
						</li>
					</ul>
				</li>
				<li class="page_config">
					A feature allowing snippets of code to be tested in the <?= CMS_PROJECT_SHORTNAME ?>.
					Test code can be engaged (see <a href="index.php?cms_action=cms_edit_install&name=TestDebugSettings_CODE_DEBUG_TEST_URI" target="_blank">Test Debug Settings</a>) in debug mode.
					When test code is set up, the link <a href="index.php?cms_action=cms_debug_code">&quot;Admin-&gt;Debug Code&quot;</a> to appears to engage the test code.
				</li>
				<li class="page_config">
					An optional virtual folders feature in the application configuration can be used to allow direct URL access to an application.
					For example: instead of using &quot;index.php?app=[id]&var_name1=var_val1&var_name2=var-value2&quot; or &quot;index.php?app=[id]&var_name1=var_val1&var_name2=var-value2&quot; etc.,
					the URL can use the &quot;[virtual_name]/?var_name1=var_val1&var_name2=var-value2 etc.&quot; URL,
					this goes direct to the application using [virtual_name] including the GET variables (via the body file). <br>
					Also, if you provide &quot;[virtual_name]/somefile.php?var_name1=var_val1&var_name2=var-value2 etc.&quot; in the request URL,
					<?= CMS_PROJECT_SHORTNAME ?> will direct to the applications somefile.php with the GET variables being set.<br>
					<b>Note:</b> Before a virtual folder is engaged the <?= CMS_PROJECT_SHORTNAME ?> will run the normal initialization.<br>
					<b>Important Note:</b> The virtual folder uses the web server rewrite module via the standard/default (DOCROOT)/.htaccess config.
				</li>
				<li class="page_config">
					Base Classes (Objects) for Apps - The Ccms_app_base() class in intended to link in many <?= CMS_PROJECT_SHORTNAME ?> methods for use in applications.
					The Ccms_app_base() class is actual a methods library/stack to provide common useful methods and provide correct access into the <?= CMS_PROJECT_SHORTNAME ?> code.
				</li>
				<li class="page_config">
					POSIX Class (static methods) for Apps - The Ccms_posix() class contains POSIX and operating system informational functions.
				</li>
				<li class="page_config">
					Applications Configuration INI Settings and CSS Style Sheets - a <?= CMS_PROJECT_SHORTNAME ?> maintained setup and themed stylesheets.
					<br>
					The <?= CMS_PROJECT_SHORTNAME ?> has code to produce annotated columns and headings for settings that contain multiple values or name=value pairs
					in the &quot;<?= ETC_FS_APPS_CONFIG ?>&quot; settings file.

					<br>
					There are examples in the &quot;<?= CMS_MAN_EXAMPLES_ZIP ?>&quot; download, sub-directories.
				</li>
				<li class="page_config">
					Dynamic Configuration - Allows the configuration settings to modified dynamically via another process (local or remotely) by user supplied code.
				</li>
				<li class="page_config">
					LDAP/AD Authentication - Just setting the LDAP settings and enabling users to use LDAP/AD, user authentication can be used.
				</li>
				<li class="page_config">
					Remote Authentication and Data Control Retrieval - This feature allows &quot;glue&quot; logic and application specific code to be implemented.
				</li>
				<li class="page_config">
					Proxies - Two types of proxy types are implemented;-
					<ul class="page_config">
						<li class="page_config">
							A pseudo proxy to access files directly accessible by <?= CMS_PROJECT_SHORTNAME ?>
							but not directly accessible from the client side.
							And to keep private files away from indexing / multiview generated pages.
							These files are usually on storage systems that are not part of the <?= CMS_PROJECT_SHORTNAME ?> server file system.
							<br>
							These are implemented by a URI, for example &quot;<?= CMS_WS_DIR ?>cms_proxy?proxy={object_signature}&quot;.
							Where the &quot;{object_signature}&quot; is genrates by the <?= CMS_PROJECT_SHORTNAME ?>
							and stored in a database against the proxied file, and the file delivered as required on call.
							See the &quot;Ccms_proxy&quot; PHP class for more details.
						</li>
						<li class="page_config">
							HTTP / HTTPS reverse proxy to allow access to web sites/apps behind the the firewall.
							This uses an inbuilt reverse proxy mechanism that not require Apache or Nginx configs to implement.
							The reverse proxy is based on an <?= CMS_PROJECT_SHORTNAME ?> application.
							The application type is set to &quot;Reverse Proxy&quot; and instead on providing an application body filename,
							a proxy destination URL is entered instead.
						</li>
						<li class="page_config">
							<B>Note:</b> There is no websocket proxy in the <?= CMS_PROJECT_SHORTNAME ?>.
							Websockets proxies are best implemented on the web server with application websocket initiators over the
							<?= CMS_PROJECT_SHORTNAME ?> application code.
						</li>
					</ul>
				</li>
				<li class="page_config">
					Geo Location - Geo location can be added to any form by including Ccms_location::add_JS_browser_geolocation_form_text() function.
					The latitude, longitude, accuracy and time are captured by the <?= CMS_PROJECT_SHORTNAME ?> and store in the base classes (and also in the session data).
					The <?= CMS_PROJECT_SHORTNAME ?> Ccontactus plugin and the standard footer uses the Geo location code and can provide detailed application information.
					The Geo location can be enabled/disabled, and the time to live (TTL) of the location can be set.
					Use <a href="index.php?cms_action=cms_edit_search&keywords=contact+us">&quot;Admin-&gt;Search-&gt;contact us&quot;</a> to find the settings.
				</li>
				<li class="page_config">
					INI / JSON File Configurator - The Ccms_edit() code class is used by the <?= CMS_PROJECT_SHORTNAME ?> to configure install, theme and apps settings engine.
					It uses a suffix detection to generate the appropriate input element.
					The configurator uses a three file system,
					one containing the settings in use (e.g. cms.ini, apps.ini),
					one being a default settings file  (e.g. cms.default.ini, apps.default.ini)
					and one file containing and explanation of every setting in the first ini file  (e.g. cms.comment.ini, apps.comment.ini).
					These three files can also be used for JSON file types (e.g. .JSON) because the Ccms_edit() code class is abstracted from reading the files (by the caller providing the arrays) and therefore can be used with remote files.
					At present the depth off the arrays is limited to standard INI format (i.e. [section][name] = value).
					There is html element creation code is in Ccms_edit() code class.
					This can also be used for JSON file type settings also, with some extra features for generating input elements.
					<ul class="page_config">
						<li class="page_config">
							INI files are usually used where it maybe necessary to edit settings manually.
							INI files are used by the <?= CMS_PROJECT_SHORTNAME ?> for this reason.
							However they only have a simple [sect_name]key = &quot;value&quot; scope and cannot given value type nor possible selections.
							To help the Ccms_edit class has the Ccms_options class as a base to key name suffixes to allow a limited number of selections.
							Mainly suitable for theme settings and basic true/false (boolean) settings.
						</li>
						<li class="page_config">
							<?php insert_man_drop_box('h4','Example Control JSON Structure.',CMS_FS_INCLUDE_MANUAL_DIR . 'example_control_json.php') ?>
						</li>
						<li class="page_config">
							The values are in the settings values JSON.
						</li>
						<li class="page_config">
							Where settings values JSON has an array under the key name the value array is not shown.
							The values are maintained in the settings value JSON.
						</li>
					</ul>
				</li>
				<li class="page_config">
					Application information and documents: The default location for these files
					is the &quot;<?= APPS_WS_DOCS_DIR ?>&quot; directory.
					<br>
					The <?= CMS_PROJECT_SHORTNAME ?> has mechanisms for displaying the web site&rsquo;s
					information to the &quot;Admin&quot; Users;-
					<ul class="page_config">
						<li class="page_config">
							<a href="index.php?cms_action=cms_edit_config&name=CMS_C_README_LINK" target="_blank">Select ReadMe file link</a>.
							Suggested readme document file types;-
							<ul class="page_config">
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'README.md' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'README.txt' ?>&quot;
								</li>
							</ul>
							contains the main web site&rsquo;s &quot;README&quot; file for display.
						</li>
						<li class="page_config">
							<a href="index.php?cms_action=cms_edit_config&name=CMS_C_RELEASENOTES_LINK" target="_blank">Select Realease Notes file link</a>.
							Suggested release notes document file types;-
							<ul class="page_config">
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'ReleaseNotes.md' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'ReleaseNotes.txt' ?>&quot;
								</li>
							</ul>
							contains the main web site&rsquo;s &quot;Release Notes&quot; file for display.
						</li>
						<li class="page_config">
							<a href="index.php?cms_action=cms_edit_config&name=CMS_C_TERMS_LINK" target="_blank">Select Terms and Conditions file link</a>.
							Suggested Terms and Conditions document file types;-
							<ul class="page_config">
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Terms.php' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Terms.html' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Terms.md' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Terms.txt' ?>&quot;
								</li>
							</ul>
							contains the main web site&rsquo;s &quot;Terms and Conditions&quot; file for display.
						</li>
						<li class="page_config">
							<a href="index.php?cms_action=cms_edit_config&name=CMS_C_EULA_LINK" target="_blank">Select EULA file link</a>.
							Suggested EULA document file types;-
							<ul class="page_config">
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'EULA.php' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'EULA.html' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'EULA.md' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'EULA.txt' ?>&quot;
								</li>
							</ul>
							contains the main web site&rsquo;s &quot;EULA&quot; file for display.
						</li>
						<li class="page_config">
							<a href="index.php?cms_action=cms_edit_config&name=CMS_C_LICENCE_LINK" target="_blank">Select Licence file link</a>.
							Suggested Licence document file types;-
							<ul class="page_config">
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Licence.php' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Licence.html' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Licence.md' ?>&quot;,
								</li>
								<li class="page_config">
									&quot;<?= APPS_WS_DOCS_DIR . 'Licence.txt' ?>&quot;
								</li>
							</ul>
							contains the main web site&rsquo;s &quot;Licence&quot; file for display.
						</li>
					</ul>
				</li>
				<li class="page_config">
					<?php insert_man_drop_box('h4','Typical Client Metadata Session Structure',CMS_FS_INCLUDE_MANUAL_DIR . 'typical_client_metadata.php') ?>
				</li>
				<li class="page_config">
					Legal requirements information.
					<br>
					The <?= CMS_PROJECT_SHORTNAME ?> has provisions for controlling and
					displaying &quot;required&quot; information.
					The following provisions are available for standard applications and local tools;-
					<ul class="page_config">
						<li class="page_config">
							&quot;readme&quot; (only available to group managers and admins),
						</li>
						<li class="page_config">
							&quot;release_notes&quot; (only available to group managers and admins),
						</li>
						<li class="page_config">
							&quot;terms&quot;,
						</li>
						<li class="page_config">
							&quot;licence&quot;,
						</li>
						<li class="page_config">
							&quot;acknowledgement&quot;,
						</li>
						<li class="page_config">
							&quot;cookies&quot;,
						</li>
					</ul>
					Use <a href="index.php?cms_action=cms_edit_search&keywords=terms+licence">&quot;Admin-&gt;Search-&gt;terms or licence, etc.&quot;</a> to find the settings.
				</li>
				<li class="page_config">
					App SSL Files. The default location for SSL (e.g. cert, key, ca) files
					is the &quot;<?= ETC_WS_SSL_INCLUDES_DIR ?>&quot; directory.
				</li>
<?php if(file_exists("doxy/cms_html/index.html")) { ?>
				<li class="page_config">
					<a href="doxy/cms_html/index.html" target="_blank"><?= CMS_PROJECT_SHORTNAME ?> Code Documentation</a>.
				</li>
<?php	} // if ?>
<?php if(file_exists("doxy/apps_html/index.html")) { ?>
				<li class="page_config">
					<a href="doxy/apps_html/index.html" target="_blank">Applications Code Documentation</a>.
				</li>
<?php	} // if ?>
<?php if(file_exists("doxy/apps_cms_html/index.html")) { ?>
				<li class="page_config">
					<a href="doxy/apps_cms_html/index.html" target="_blank">Combined <?= CMS_PROJECT_SHORTNAME ?> and Applications Code Documentation</a>.
				</li>
<?php	} // if ?>
			</ul>
			<p class="page_config">
				The &lt;body&gt; element requires javascript events to manage drag and drop.
				The &quot;CMS_S_DRAG_DROP_PRELOAD_BOOL&quot; setting controls whether the <?= CMS_PROJECT_SHORTNAME ?> drag and drop javascript is included for application pages
				(the <?= CMS_PROJECT_SHORTNAME ?> drag and drop javascript is always included for admin pages).
				In the &quot;<?= CMS_PROJECT_SHORTNAME ?>&quot;  the drag events are defined initial by;-
			</p>
			<pre class="page_config">
	&lt;div id="cms_page_body_XXX" ondragover="javascript:cms_drag_over(event);" ondrop="javascript:cms_drop(event);"&gt;
			</pre>
			<p class="page_config">
				To allow applications to access these events,
				the JS initialize body event functions can be overridden and replaced;-
			</p>
			<ol class="page_config">
				<li class="page_config">&quot;cms_drag_start(event)&quot; looks for app_ov_drag_start(event) replacement function,</li>
				<li class="page_config">&quot;cms_drop(event)&quot; looks for app_ov_drag(event) replacement function,</li>
				<li class="page_config">&quot;cms_drag_over(event)&quot; looks for app_ov_drag_over(event) replacement function.</li>
				<li class="page_config">&quot;cms_remove_drag_events()&quot; to remove drag and drop events.</li>
			</ol>
			<p class="page_config">
				There are many inbuilt feature and useful classes and methods in the <?= CMS_PROJECT_SHORTNAME ?> intended for end coders and
				code integrators to use. Beware changing the &quot;<?= CMS_PROJECT_SHORTNAME ?>&quot; code in the &quot;<?= CMS_WS_DIR ?>&quot; directory.
				An update will overwrite any changes in the &quot;<?= CMS_WS_DIR ?>&quot;.
			</p>
			<p class="page_config">
				Basic features and hints;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					The &quot;<?= CMS_WS_DIR ?>&quot; is the &quot;<?= CMS_PROJECT_SHORTNAME ?>&quot; code directory.
					This should regarded as a code library and a &quot;<?= CMS_PROJECT_SHORTNAME ?>&quot; update will over write this directory.
				</li>
				<li class="page_config">
					The &quot;<?= APPS_WS_DIR ?>&quot; is intended for free coding.
					Usual each application has its own sub-directory here.
					The installation will setup the basic directory for standard code locations (e.g. includes,classes,plugins,etc.).
					To help start coding there are examples applications and code in the &quot;<?= CMS_MAN_EXAMPLES_ZIP ?>&quot; download.
				</li>
				<li class="page_config">
					The &quot;<?= ETC_DIR ?>&quot; is for settings, images, css (i.e. theme generated stylesheets), etc. that are required for operation.
					Basically the configuration directory (similar to /etc on LINUX).
				</li>
				<li class="page_config">
					The &quot;<?= VAR_WS_DIR ?>&quot; is for transient data (e.g. caches, backups, logs, session data, etc.) and
					would not normally be saved (similar to /var on LINUX).
				</li>
			</ul>
			<p class="page_config">
				There <?= CMS_PROJECT_SHORTNAME ?> has been progressively hardened over time.
				Thanks to the feedback from users and community since V0.01 in 2013, the <?= CMS_PROJECT_SHORTNAME ?> has been growing and it will continue to grow.
				Many things that can go wrong (e.g. missing &quot;<?= VAR_WS_DIR ?>&quot; directories, lost settings, etc) are checked and rebuilt on &quot;Admin&quot; login.
				When this happens the <?= CMS_PROJECT_SHORTNAME ?> will tell you what it has done via the logs files (and on screen optionally).
				The &quot;<?php APPS_WS_DIR;?>&quot; is intended for end coders and code integrators to use.
				Beware changing the &quot;<?= CMS_PROJECT_SHORTNAME ?>&quot; code in the &quot;<?= CMS_WS_DIR ?>&quot; directory.
				An update will overwrite any changes in the &quot;<?= CMS_WS_DIR ?>&quot;.
				The &quot;<?= APPS_WS_DIR ?>&quot; is intended for free coding, but does have example files that will be updated.
				The &quot;<?= ETC_DIR ?>&quot; is for settings, images, etc that are required for operation.
				The &quot;<?= VAR_WS_DIR ?>&quot; is for transient data (e.g. caches, backups, logs, session data, etc.) and would not normally be saved.
				If a change is done to the &quot;<?= CMS_WS_DIR ?>&quot; directory, submit the code using &quot;<?= CMS_MAN_CLI_DIR ?>cms_wrap_submission.sh&quot; script to make a ZIP archive
				and submit in a feedback email.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="cron_jobs"></a>
			Chronological Timing (CRON Jobs)
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has chronological timing interface to setup and run CRON jobs on Linux based operation systems.
				Each CRON job has a crontab entry under the web application home user account (not under the web server).
			</p>
			<p class="page_config">
				Crontab entries can be configured directly for standard and close coupled applications.
				Standard and Coupled applications have there own CRON job timing and initiator scripts (shell or PHP).
				They are configurated in the <a href="index.php?cms_action=cms_edit_bodies">&quot;Admin-&gt;Apps / Bodies&quot;</a> configuration.
				Crontab entries are setup, engaged and deleted by the <?= CMS_PROJECT_SHORTNAME ?> from entries in the page/apps configuration page,
				<a href="index.php?cms_action=cms_edit_bodies">&quot;Admin-&gt;Apps / Bodies&quot;</a>.
				This operation needs to be run as the user who owns the web &quot;(DOCROOT)/&quot; directory
				(not Apache which runs as another user with no shell nor IO privileges).
				Depending on the system configuration,
				Apache may be able to change the effective user negating the need to manually log in to the &quot;(DOCROOT)/&quot;.
				<?= CMS_PROJECT_SHORTNAME ?> will indicate results either way.
			</p>
			<p class="page_config">
				For other applications <?= CMS_PROJECT_SHORTNAME ?> uses a common crontab timing configuration.
				If enabled the <?= CMS_PROJECT_SHORTNAME ?> looks for and
				runs &quot;bash -e <?= APPS_WS_APPS_CRON_SCRIPT ?>&quot;
				(or &quot;php <?= APPS_WS_APPS_CRON_PHP ?>&quot;
				if &quot;<?= APPS_WS_APPS_CRON_SCRIPT ?>&quot; is not available).
			</p>
			<p class="page_config">
				If CRON jobs are enabled (currently <?= (CMS_S_ALLOW_APP_CRON_JOBS_BOOL ? 'enabled':'disabled') ?>.) and
				after configuring the required settings in to CRON job configuration/s,
				<?= CMS_PROJECT_SHORTNAME ?> will attempt to change local user&rsquo;s crontab.
				If the web server does have sufficient permissions, a warning to generated to indicate the failure.
				In this case, login in as the local user
				(i.e. the owner of the &quot;(DOCROOT)/&quot;,
				e.g. &quot;/home/(username)/public_html&quot;,
				which gives direct access to the web code).
				This gives you access to the user crontab entries.
				Goto the &quot;(DOCROOT)/&quot; directory and enter &quot;<?= CMS_WS_CLI_DIR ?>cms_cron_control.sh --start&quot;
				or enter &quot;php <?= CMS_WS_CLI_DIR ?>cms_cron_control.php --start&quot;.
				This will update the user&rsquo;s crontab and engage the crontab cronjobs listed in it.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> takes possession of the local user&rsquo;s crontab.
				Running the commands &quot;<?= CMS_WS_CLI_DIR ?>cms_cron_control.sh --start&quot;
				or &quot;php <?= CMS_WS_CLI_DIR ?>cms_cron_control.php --start&quot; as the home user
				will initialize user crontab.
				<br>
				<b>NOTE:</b> &quot;<?= CMS_WS_CLI_DIR ?>cms_cron_control.sh&quot; is a wrapper for &quot;php <?= CMS_WS_CLI_DIR ?>cms_cron_control.php&quot;.
			</p>
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> commands &quot;<?= CMS_WS_CLI_DIR ?>cms_cron_control.sh&quot;
				and &quot;php <?= CMS_WS_CLI_DIR ?>cms_cron_control.php&quot; have options to --start, --stop, --run, etc.
				Running these scripts with the &quot;--help&quot; shows the available options.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="TroubleShooting"></a>
			Trouble Shooting
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The <?= CMS_PROJECT_SHORTNAME ?> has installation and updating trouble shooting functions built-in.
				<br><b>NOTE:</b> This does not change existing settings, but will remove any code changes made outside of the release.
			</p>
			<p class="page_config">
				If the web site is basically functional,
				logging in as an administrator and
				going to the &quot;http://your.web.site/site_alias/index.php?cms_action=cms_rebuild_setup&quot; link will rebuild the web site settings.
				This can take a minute or so to complete.
			</p>
			<p class="page_config">
				If after an update or other problems, the web site is non functional, there is a recovery command available to help fix this.
			</p>
			<ul class="page_config">
				<li class="page_config">
					On a LINUX server, in a console shell, goto the web site&rsquo;s &quot;<?= CMS_WS_CLI_DIR ?>&quot; directory and run &quot;./cms_rebuild.sh&quot;.
				</li>
			</ul>
			<p class="page_config">
				<?php insert_man_drop_box('h3','Typical Successful Rebuild Output',CMS_FS_INCLUDE_MANUAL_DIR . 'typical_rebuild_output.php') ?>
			</p>
			<p class="page_config">
				<b>CAUTION:</b> The update will use default settings for new features. <b>Take note of the messages (e.g.ERROR, WARNING, and INFO).</b>
				The default settings for new features may need to changed to more appropriate values.
			</p>
			<p class="page_config">
				A basic installation guide is available in the
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#TroubleShooting') ?>.
			</p>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="VersionControl"></a>
			File Version Control
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				When a manager or administrator are logged in, the <?= CMS_PROJECT_SHORTNAME ?> can use &quot;Subversion&quot; (SVN) and Git,
				if available, to aid in administration and checking of the site.
				Hovering the mouse over the &quot;About <?= CMS_PROJECT_SHORTNAME ?>&quot; or manual pages shows the current SVN and Git version status of the website.
				This reports the SVN revision number of the web site.
				The revision numbers can used to identify changes.
			</p>
			<p class="page_config">
				Current version details: <?= Ccms::get_version_str() ?>
			</p>
			<p class="page_config">
				For direct access to <?= CMS_PROJECT_SHORTNAME ?> version information use <a href="index.php?cms_action=cms_version">&quot;index.php?cms_action=cms_version&quot;</a>.
			</p>

		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<a name="UtilityScripts"></a>
			Utility Scripts
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				The &quot;<?= CMS_WS_CLI_DIR ?>&quot; directory contains utility scripts;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					&quot;<?= CMS_WS_CLI_DIR ?>cms_set_permissions.sh&quot; - Linux scripts to restore web server permissions (runs as &quot;sudo <?= CMS_MAN_CLI_DIR ?>cms_set_permissions.sh&quot;).
					This script will check for &quot;<?= APPS_WS_CLI_DIR ?>set_app_permissions.sh&quot; and run it if found.
				</li>
				<li class="page_config">
					&quot;<?= CMS_WS_CLI_DIR ?>cms_rebuild.sh&quot; - Linux version to rebuild configuration.
					Runs &quot;<?= CMS_MAN_CLI_DIR ?>cms_rebuild.php&quot; - is a PHP sub script for rebuild configuration and reset the caches , etc.
					NOTE: Running &quot;<?= CMS_MAN_CLI_DIR ?>cms_rebuild.sh&quot; runs the &quot;<?= CMS_MAN_CLI_DIR ?>cms_backup_settings.sh&quot; before rebuilding.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_backup_settings.sh&quot; - backs up settings to a datetime named file in &quot;<?= VAR_WS_DIR ?>backup/&quot; (e.g. ;<?= VAR_WS_DIR ?>backups/<?= CMS_PROJECT_SHORTNAME ?>-Backup-20170801-163930.zip).
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_access_checks.sh&quot; -
					Scans &quot;<?= APPS_WS_DIR ?>&quot;, &quot;<?= CMS_WS_DIR ?>&quot;, &quot;<?= ETC_MAN_WS_DIR ?>&quot; and &quot;<?= VAR_WS_DIR ?>&quot; web site directories
					check for the presence of &quot;.htaccess&quot; files. And optionally, rebuild/rewrite the &quot;.htaccess&quot; file to the correct &quot;ALLOW&quot; or &quot;DENY&quot;
					access controls.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_include.sh&quot; - A common CLI definitions and functions for inclusion in other scripts.
				</li>

				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_generate_sitemap.sh&quot; - Linux version of CLI sitemap generator.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_generate_sitemap.php&quot; - is a PHP sub script of CLI sitemap generator.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_import_links_manager.sh&quot; - Linux version to import Links_Manager data. <br>
					<b>Important Note:</b> User and Group permissions need to be checked and/or reassigned after running this script.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_import_links_manager.php&quot; - is a PHP sub script to import DB data.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_wrap_submission.sh&quot; - Linux script used to help submit community feedback containing code with requested changes.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_cron_control.sh&quot;
					(executes &quot;php <?= CMS_MAN_CLI_DIR ?>cms_cron_control.php&quot;)
					 - Linux script to control CRON jobs.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_wrap_apps.sh&quot; - Script to wrap the &quot;<?= APPS_WS_DIR ?> directory
					into &quot;apps_fs_sqsh.sqsh&quot; read only squashfs archive.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_dumpsqlite3.sh&quot; - Script to SQLite database.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_stats.sh&quot; - Script to provide code statistic.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_doxy_run.sh&quot; - Script to generate &quot;doxygen&quot; documentation.
					Runs the &quot;doxyen&quot; .conf files in &quot;<?= CMS_WS_DIR ?>doxy/&quot; directory.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_DB_create.sh&quot; - Script to create the <?= CMS_PROJECT_SHORTNAME ?>
					MySQL database. Runs &quot;<?= CMS_MAN_CLI_DIR ?>cms_DB_create.php&quot; script.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_DB_query.sh&quot; - Script to test MySQL databases.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_config.sh&quot; - Script to get/set configuration values from the CLI.
				</li>
				<li class="page_config">
					&quot;<?= CMS_MAN_CLI_DIR ?>cms_doxy_run.sh&quot; - Script to generate Doxygen documentation from source code.
					When the results are available, the document links appear in the &quot;Admin-&gt;Doxy CMS&quot;, &quot;Admin-&gt;Doxy Apps&quot; and &quot;Admin-&gt;Doxy Apps &amp; CMS&quot; (combined).
				</li>
			</ul>
			<p class="page_config">
				The most utility scripts have a help option (e.g. -h|--help) where options are available or they need required option/s.
			</p>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="ExampleCode"></a>
			Code Examples
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				Code examples are available for download in &quot;<?= CMS_MAN_EXAMPLES_ZIP ?>&quot;.
				The appropriate part of the &quot;<?= CMS_MAN_EXAMPLES_ZIP ?>&quot; directory can be unzipped and copied to the appropriate &quot;(DOCROOT)/&quot; directory.
				to engage the examples.
				(e.g. at the &quot;(DOCROOT)/&quot; run &quot;cp -v -r <?= CMS_WS_EXAMPLES_DIR ?> &quot;)
			</p>
			<p class="page_config">
				The examples show basic functionality.
				The explanations given here assume that the example code has been copy to the functional location.
			</p>
			<p class="page_config">
				In &quot;<?= CMS_MAN_EXAMPLES_ZIP ?>&quot; are examples;-
			</p>
			<ul class="page_config">
				<li class="page_config">
					A &quot;<?= CMS_MAN_EXAMPLE_BODIES_DIR ?>example_cms_body.php&quot; is available to help show how to use some plugins and local applications.
					The &quot;_body&quot; suffix in the filename is recommended to avoid filename clashes.
				</li>
				<li class="page_config">
					A &quot;<?= CMS_MAN_EXAMPLE_BODIES_DIR ?>example_welcome_cms_body.php&quot; is available to help show how to use the a &quot;full view&quot; welcome or splash page using the <?= CMS_PROJECT_SHORTNAME ?> facilities.
				</li>
				<li class="page_config">
					A &quot;<?= CMS_MAN_EXAMPLE_BODIES_DIR ?>example_contactus_cms_body.php&quot; is available to help show how to use the Ccms_contactus plugin.
				</li>
				<li class="page_config">
					A &quot;<?= CMS_MAN_EXAMPLE_BODIES_DIR ?>example_login_cms_body.php&quot; is available to help show a custom login page.
				</li>
				<li class="page_config">
					A &quot;<?= CMS_MAN_EXAMPLE_BODIES_DIR ?>example_modal_test.php&quot; is available to help show how to use the Ccms_modal class with the Ccms_contactus plugin.
				</li>
			</ul>
		</td>
	</tr>

	<tr class="page_config">
		<th class="page_config">
			<a name="MoreInfo"></a>
			More Information
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<p class="page_config">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'LICENCE.txt','LICENCE',false,'#MoreInfo') ?>.
			</p>
			<p class="page_config">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'README.md','README',false,'#MoreInfo') ?>.
			</p>
			<p class="page_config">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . CMS_PROJECT_SHORTNAME . '-version.info','Version',false,'#MoreInfo') ?>.
			</p>
			<p class="page_config">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes',false,'#MoreInfo') ?>.
			</p>
			<p class="page_config">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes',false,'#MoreInfo') ?>.
			</p>
			<p class="page_config">
				<a name="DirectoryStructure"></a>
				<?php insert_man_drop_box('h4','Directory Structure',CMS_FS_INCLUDE_MANUAL_DIR . 'directory_structure.php') ?>
			</p>
				<?php if(Ccms_contactus_plugin::is_enabled()) {
					$text = '';
					$open_js = Ccms_contactus_plugin::generate_modal(
						$text,	// text buffer
						false,	// no button
						'',	// form_id
						'_mt',	// suffix
						'page_body',	// class usually 'page_body'
						true,	// geo_flg if available
						false,	// msg_drop_box
						CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ' Feedback', // $subject
						'feedback@a' . CMS_PROJECT_DOMAIN	// rec_email
						);
					echo $text;
				?>
				<br>
				<a onclick="<?= $open_js ?>();">Hints, corrections and suggestions are always welcome. Email Feedback</a>.
				<br>
				<?php	} else { ?>
			<p class="page_body">
				Hints, corrections and suggestions are always welcome.
				<a href="mailto:feedback@<?= CMS_PROJECT_DOMAIN ?>?Subject=<?= rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION) ?>">Email Feedback</a>.
			</p>
				<?php	} // else ?>
		</td>
	</tr>
</table>

<?php
Ccms::page_end_comment(__FILE__);

