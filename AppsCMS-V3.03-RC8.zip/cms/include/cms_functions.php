<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_functions.php 2845 2022-10-08 11:21:04Z robert0609 $
 */

// used to define functions that are not present in older version of PHP (particularly pre 7.3.0)
if(!function_exists('array_key_first')) {
	function  array_key_first($array) {	// int|string|null
		if(!is_array($array)) return null;
		$keys = array_keys($array);
		return $keys[0];
		} // array_key_first()
	} // if

// EOF

