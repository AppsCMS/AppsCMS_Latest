<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_index.php 3007 2022-12-01 01:07:32Z robert0609 $
 */

if(!defined('WWW_CALL')) define('WWW_CALL',true);	// global for WWW recognition

require_once 'include/cms_top.php';

if(!Ccms_ops::do_gen_pre_body()) return;

Ccms_search::chk_search_redirect(array('save','cancel'));	// check if return to search
Ccms::output_page_headers();
echo '<html dir="ltr"' . (preg_match('/^UTF/i',CMS_S_CHAR_SET) ? ' lang="' . CMS_S_LANGUAGE_CODE . '"':'') . '>' . PHP_EOL;
Ccms::page_start_comment(__FILE__);
Ccms::output_head();
?>

	<body>

		<div id="preloaded"></div>
		<div class="cms_main_body">
<?php
	if((Ccms::is_full_body_view()) ||
		(isset(Ccms::$cms_page_info['body']['body_full_view']) && (Ccms::$cms_page_info['body']['body_full_view'] > 0))) {
		include CMS_FS_INCLUDES_DIR . 'cms_page_body.php';
		return;
		}// if
	else { // normal view

	echo Ccms_socialmedia_plugin::init_body_insert();
	
	if(Ccms::use_block_html()) 
		include(CMS_FS_INCLUDES_DIR . 'cms_page_block.php');
	else include(CMS_FS_INCLUDES_DIR . 'cms_page_inline.php');

	include(CMS_FS_INCLUDES_DIR . 'cms_events_start.php');

	Ccms::page_end_comment(__FILE__);
	} // else
?>
		</div>
	</body>
</html>

<?php
	// echo Ccms::chk_ob_buffer();
	require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';

