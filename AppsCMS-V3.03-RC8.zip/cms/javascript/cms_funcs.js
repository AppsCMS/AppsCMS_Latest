/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_funcs.js 3139 2023-02-14 20:38:55Z robert0609 $
 */

class Ccms_cookie {

	static set(cname, cvalue, exdays, path, domain, secure) {
		const d = new Date();
		d.setTime(d.getTime() + (exdays*24*60*60*1000));
		let expires = "expires="+ d.toUTCString();
		let curCookie = cname + "=" + cvalue + ";" + expires;
		curCookie += ";path=" + (path ? path:'/');
		curCookie += ((domain) ? ";domain=" + domain :"");
		curCookie += ((secure) ? ";secure=" + secure :"; SameSite=None; Secure");
		document.cookie = curCookie;
		} // set()

	static get(cname) {
		let name = cname + "=";
		let decodedCookie = decodeURIComponent(document.cookie);
		let ca = decodedCookie.split(';');
		for(let i = 0; i <ca.length; i++) {
			let c = ca[i];
			while (c.charAt(0) == ' ') c = c.substring(1);
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
				}
			} // for
		return "";
		} // get()

	static delete(name, path, domain) {
		var deadCookie = name + "=";
		deadCookie += (path ? ";path=" + path:"");
		deadCookie += ((domain) ? ";domain=" + domain : "");
		deadCookie += ";expires=Thu,01-Jan-70 00:00:00 GMT";
		document.cookie = deadCookie;
		return valRet;
		} // delete()

	static showClientVisitsCntrCookie(sCookieID, sLeader, sTrailer, showFlg) {
		var exDays = 365;
		// check for defaults
		if ((sCookieID == null) || (!sCookieID.length))
			sCookieID = "visits";
		if ((sLeader == null) || (!sLeader.length))
			sLeader = "Visited";
		if ((sTrailer == null) || (!sTrailer.length))
			sTrailer = "times.";

		var visitsCntr = Ccms_cookie.get(sCookieID);
		if (visitsCntr == null) {
			// document.write("New cookie");	// test
			visitsCntr = 1;
			Ccms_cookie.set(sCookieID, visitsCntr, exDays);
			//say nothing may be disabled	document.write("This the first time you have visited this site.");
		} // if
		else {
			// document.write("Old cookie");	// test
			visitsCntr++;
			Ccms_cookie.set(sCookieID, visitsCntr, exDays);
			if (showFlg) {
			// document.write(visitsCntr + sCookieID);	// test
			document.write(sLeader + " " + cms_formatIntNumber(visitsCntr) + " " + sTrailer);
			} // if
			else
			document.write('&nbsp;');
		} // else
	} // showClientVisitsCntrCookie()

	static set_client_meta(clientMeta) {
		var jmeta = JSON.stringify(clientMeta);
		Ccms_cookie.set('_cms_clientMeta', jmeta, 1);
		// console.log(clientMeta);
		// console.log(window.performance.memory);
		} // set_client_meta()

} // Ccms_cookie

function cms_formatIntNumber(num) {
	var text = "";
	var sep = ',';
	var left = 0;
	num = Math.round(num);
	while (num >= 1000) {
	// get left bit
	left = "000" + (num % 1000);	// get remainder, prefix with 000 for 0 to 99
	if (text.length > 0)
		text = left.substr(-3) + sep + text;
	else
		text = left.substr(-3) + text;

	// next 1000
	num /= 1000;
	num = Math.floor(num);
	} // while
	if (num > 0) {
	left = num;
	if (text.length > 0)
		text = left + sep + text;
	else
		text = left + text;
	} // if
	return text;
} // cms_formatIntNumber()

function cms_scroll2Name(name,topOffset) {	// scroll selected item into view
	if((!name) && (topOffset) && (topOffset !== false)) {   // whole window at topOffset
		window.scrollTo({
			behavior: 'smooth',
			left: 0,
			top: topOffset,
			});
		return;
		} // if
	var elem = document.getElementsByName(name);
	if (!elem) return;
	if (!elem[0]) return;
		elem[0].scrollIntoView({
			behavior: 'smooth',
//			block: 'start',
//			alignToTop: true,   // elem top
			block: 'center',
			});
} // cms_scroll2Name()

function cms_scroll2PageTop(bod) {	// scroll to top of page
	if(bod) {
		var bd = document.getElementById(bod);
		if(bd) {
			bd.scrollTo({
				behavior: 'smooth',
				// left: 0,
				top: 0,
				});
			return;
			} // if
		} // if
	// use window
	window.scrollTo({
		behavior: 'smooth',
		// left: 0,
		top: 0,
		});
} // cms_scroll2PageTop()

function cms_showFoundName(name, keywords) {
	// cms_scroll2Name(name);
	if(keywords) {
		document.getElementsByName(name)[0].innerHTML = '<span class="cms_msg_success"><img src="cms/icons/success.gif">Found here</span>' +
			'&nbsp;&nbsp;<a href="index.php?cms_action=cms_edit_search&search=' + keywords + '" title="Search for: ' + decodeURI(keywords) + '" onclick="Ccms_cursor.setWait();">Return to search.</a><br>';
		} // if
	window.setTimeout(cms_scroll2Name,500,name);
} // cms_showFoundName()

function cms_preventDefSelectEvent(id_or_obj) {
	if(!id_or_obj) return;	// let if go
	var select_box = false;
	try {
		var select_box = document.getElementById(id_or_obj);	//
	} catch (e) {
		if(!select_box) {
		if(id_or_obj.tagName != 'SELECT') return;	// let if go normal
			select_box = id_or_obj;
			} // if
	}
	if(!select_box) return;
	select_box.addEventListener('mousedown', function(ev) {
		ev.preventDefault();
		var clicked_option = ev.target.index;
		if(clicked_option !== false)
			select_box.options[clicked_option].selected = !select_box.options[clicked_option].selected
		return false;
		});
	} // cms_preventDefSelectEvent()

var cms_selects_save = [];
function cms_filter_select_options(id_keywords, id_select, id_cnt) {
	var drop_size = 4;
	var need_drop = false;
	var select = document.getElementById(id_select);
	var id_sel_idx = id_select.replace(/[\W_]+/g,'_');	// used for accessing arrays
	if(!(id_sel_idx in cms_selects_save)) cms_selects_save[id_sel_idx] = [];
	var keywords = document.getElementById(id_keywords);
	if (drop_size >= select.length) {
	keywords.style.display = 'none';
	} // if
	var multi = select.multiple;
	if (!cms_selects_save[id_sel_idx]) {
	cms_selects_save[id_sel_idx] = {};	// initialise options selected array
	for (var i = 0; i < select.length; i++) {	// save initial state
		var option = select.options[i];
		cms_selects_save[id_sel_idx][i] = option.selected;
	} // for
	} // if
	if (typeof select.onclick != "function") {	// only do once otherwise it become recursive
	select.addEventListener("click", function () {
		for (var i = 0; i < select.length; i++) {
		var option = select.options[i];
		if (option.hidden)
			continue;
		if (option.style.display == 'none')
			continue;
		cms_selects_save[id_sel_idx][i] = option.selected;
		} // for
	});
	} // if
	if (typeof select.onsubmit != "function") {	// only do once otherwise it become recursive
		select.addEventListener("submit", function () {
			for (var i = 0; i < select.length; i++) {	// put all the selections back
				var option = select.options[i];
				if (option.hidden)
					continue;
				option.style.display = 'block';	//list-item';
				option.selected = cms_selects_save[id_sel_idx][i];
				} // for
			});
		} // if
	keywords.size = keywords.value.length + 4;
	if (keywords.hasAttribute('data-dropsize')) {
		need_drop = true;
		drop_size = keywords.getAttribute('data-dropsize');
		} // if
	var keys = keywords.value.split(' ');	// do an and on keywords
	var opts_cnt = 0;
	for (var i = 0; i < select.length; i++) {
	var option = select.options[i];
	if (option.hidden)
		continue;
	if (option.value == -1111) {
		select.remove(i);
		break;	// should be the last option
	} // if
	if ((keywords.length == 0) || (keys.length == 0)) {	// turn all on
		option.style.display = 'block';	//'list-item';
		option.selected = cms_selects_save[id_sel_idx][i];
		continue;
	} // if
	var txt = option.text;
	var value = option.value;
//		if((txt.length <= 0) || (value == '') || (value == 0)) {
//			cms_selects_save[id_sel_idx][i] = option.selected;
//			option.style.display = 'none';
//			continue;
//			} // if
	var found = true;
	var includes = false;
	for (var j = 0; j < keys.length; j++) {
		includes = txt.toLowerCase().includes(keys[j].toLowerCase());
		if (!includes) {
		found = false;
		break;
		} // if
	} // for
	if (found) {
		opts_cnt++;
		option.style.display = 'block';	//'list-item';
		option.selected = cms_selects_save[id_sel_idx][i];
	} // if
	else {
		cms_selects_save[id_sel_idx][i] = option.selected;
		option.style.display = 'none';
	} // else
	} // for
	select.style.zIndex = 10000;
	if (((multi) || (need_drop)) &&
		(keywords.value.length > 0)) {
	select.size = ((opts_cnt < drop_size) ? (opts_cnt + 1) : drop_size);
	} // if
	if (opts_cnt == 0) {
	var option = document.createElement("option");
	option.text = "(nothing found)";
	option.value = -1111;
	select.add(option);
	var last = select.length - 1;
	select.selectedIndex = last;
	} // if
	if (id_cnt) {
	if (keywords.value.length > 0) {
		document.getElementById(id_cnt).style.display = 'inline-block';
		document.getElementById(id_cnt).innerHTML = opts_cnt;
	} // if
	else {
		document.getElementById(id_cnt).style.display = 'none';
		document.getElementById(id_cnt).innerHTML = '';
	} // else
	} // if
} // cms_filter_select_options()

function cms_filter_select_click(obj) {	// close drop box after filter settings have been clicked in select
	if(!obj) return false;
	if(!obj.size) return false;
	if(obj.multiple) return true;
	if(obj.size > 1) obj.size = 1;  // make a single line again after filter increased size
	return true;
	} // cms_filter_select_click()

function cms_sleep(ms,callback) {
	// console.log('Sleep Start: ' + ms + 'ms, ' + Date.now().toLocaleString('en-GB', { timeZone: 'UTC' }));	// test
	try {
		// SharedArrayBuffer is usually not enabled
		var buf = new SharedArrayBuffer(128);
		var arr = new Int32Array(buf);
		const res = Atomics.wait(arr, 1, 0, ms);
		// console.log('Atomics Sleep End:   ' + Date.now().toLocaleString('en-GB', { timeZone: 'UTC' }));	// test
		if((callback) && (typeof callback === 'function')) return callback();
		return;
		} // try
	catch(e) {
		console.log(e);
		} // catch

	const task = async (ms,callback) => {
		await new Promise(done => setTimeout(() => done(), ms));
		// console.log('Await Sleep End:   ' + Date.now().toLocaleString('en-GB', { timeZone: 'UTC' }));	// test
		if((callback) && (typeof callback === 'function')) return callback();
		}
	task(ms,callback);
	// @TODO does not wait
	// console.log('Async Sleep End:   ' + Date.now().toLocaleString('en-GB', { timeZone: 'UTC' }));	// test
	} // cms_sleep()

class Ccms_cursor {

	static setWait() {
		document.body.classList.add('cms_waiting');
		return true;
		} // setWait()

	static restore() {
		document.body.classList.remove('cms_waiting');
		return true;
		} // restore()

} // Ccms_cursor

function Ccms_ajaxOps(ajax_feedback_id, ajax_result_id, op_data, run_scripts, feedback_txt) {	// class to hold the everything
	// works with java.php
	this.self = this;
	var complain = true;
	var ajax_running = false;
	var feedback_id = ajax_feedback_id;
	var result_id = ajax_result_id;
	var run_code = run_scripts;
	var feedback = 'Accessing ... <img src="cms/images/ajax-loader.gif">';
	if (feedback_txt)
	feedback = feedback_txt;

	this.createRequest = function () {	// added by BF
	var xmlHttp = false;
	var app = navigator.appName;
	var ver = navigator.appVersion;
	if ((app != 'Netscape') && (ver <= 7) && (typeof window.ActiveXObject != 'undefined')) {
		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	} else if (typeof window.XMLHttpRequest != 'undefined') {
		xmlHttp = new XMLHttpRequest();
	} // else

	if ((!xmlHttp) && (this.complain)) {
		alert('AJAX cannot create request.');
		return false;
	} // if
	return xmlHttp;
	} // createRequest()

	this.doAjaxRequest = function (ajax_url_op, op_data, do_result_id,do_func) {
	if (ajax_running)
		return false;
	var xmlHttp = false;
	var url_op = ajax_url_op;
	if((!url_op) || (url_op.legth < 4))
		return false;
	if (!(xmlHttp = this.createRequest()))
		return false;

	ajax_running = true;
	if (typeof Ccms_cursor === 'function')
		Ccms_cursor.setWait();

	if((typeof do_result_id === 'undefined') ||
		(do_result_id.length <= 0)) do_result_id = result_id;

	var bref = document.getElementById('cms_base_ref').href;
	var url = (bref ? bref:'') + "cms/cms_ajax.php?ajax=" + url_op.replace(/^cms\/cms_ajax\.php\?ajax=/i, '');   // clean up code
	if (feedback_id.length > 0) {
		document.getElementById(feedback_id).innerHTML = feedback;
		cms_sleep(3000);	// allows time for any images, etc. in feedback to be retrieved
	} // if
	if (op_data) {
		xmlHttp.open("POST", url, true);
		xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	} // if
	else
		xmlHttp.open("GET", url, true);
		xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState != 4)
		return;
		if (xmlHttp.status == 200) {
		if (feedback_id.length > 0)	// do first in case feedback_id and do_result_id are the same
			document.getElementById(feedback_id).innerHTML = '';
		if (do_result_id.length > 0) {
			var elem = document.getElementById(do_result_id);
			switch(elem.tagName) {
			case 'INPUT':
			elem.value = xmlHttp.responseText;
			break;
			default:
			elem.innerHTML = xmlHttp.responseText;
			break
			} // switch
			if (run_code) {	// now execute any sripts and get sources that came down
			var codes = elem.getElementsByTagName("script");
			for (var i = 0; i < codes.length; i++) {
				if (codes[i].src != "") {
				var tag = document.createElement("script");
				tag.src = codes[i].src;
				document.getElementsByTagName("head")[0].appendChild(tag);
				} // if
				else {
				eval(codes[i].text);
				// eval(codes[i].innerHTML);
				} // else
			} // for
			} // if
		} // if

		if(do_func) do_func();
		ajax_running = false;
		if (typeof Ccms_cursor === 'function')
			Ccms_cursor.restore();
		} // if
	};
	// kick it off
	if (op_data) {
		if((typeof op_data === 'array') || (typeof op_data === 'object')) {	// should be done by caller to set the $_POST['name']
		var post_data = 'data=' + encodeURI(JSON.stringify(op_data));	// use $_POST['data']
		xmlHttp.send(post_data);	// send data
		} // if
		else xmlHttp.send(op_data);	// send data
		} // if
	else
		xmlHttp.send(op_data);	// send null

	// console.log(op_data);
	// ajax set
	return true;
	} // doAjaxRequest()

} // Ccms_ajaxOps()

var cms_ajaxOps = [];	// place to save Ccms_ajaxOps iterations

function cms_maplatlong_init() {
	var obj;
	try {
		obj = document.getElementById('maplatlong');
		if((typeof(obj) != 'undefined') && (obj != null)) {	// do an ajax call
			if(!cms_ajaxOps['maplatlong']) {
				cms_ajaxOps['maplatlong'] = new Ccms_ajaxOps('loadMap&plugin=cms_maplatlong','maplatlong','maplatlong','',false);
				cms_ajaxOps['maplatlong'].doAjaxRequest('');	// only do it once
				// obj.innerHTML = '<span style="color: red">howdy ABC</span>';
				} // if';
			} // if
		} // try
	catch(e) {
		} // catch
	} // cms_maplatlong_init()

function cms_socialMedia_init() {
	var obj;
	try {
		obj = document.getElementById('SMin_page');
		if ((typeof (obj) != 'undefined') && (obj != null)) {	// do an ajax call
			if (!cms_ajaxOps['socialMedia']) {
			cms_ajaxOps['socialMedia'] = new Ccms_ajaxOps('socialMedia&plugin=cms_socialmedia', 'SMin_page', 'SMin_page', '', true);
			cms_ajaxOps['socialMedia'].doAjaxRequest('');	// only do it once
			// obj.innerHTML = '<span style="color: red">howdy ABC</span>';
			} // if';
			} // if
		} // try
	catch (e) {
		} // catch
	} // cms_socialMedia_init()

function cms_get_browser_timestamp_ms() {
	currentTime = new Date();
	time = currentTime.getTime();
	return time;
}	// cms_get_browser_timestamp_ms()

function cms_get_browser_timeszone_minutes() {
	var d = new Date();
	var n = d.getTimezoneOffset();
	return n;
}	// cms_get_browser_timeszone_minutes()

function cms_get_elem_position(elem) {
	var rect = elem.getBoundingClientRect();
	var h = Math.max( elem.scrollHeight, elem.offsetHeight, elem.clientHeight, elem.scrollHeight, elem.offsetHeight );
	var w = Math.max( elem.scrollWidth, elem.offsetWidth, elem.clientWidth, elem.scrollWidth, elem.offsetWidth );
	scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
	scrollTop = window.pageYOffset || document.documentElement.scrollTop;
	return { top: rect.top + scrollTop, left: rect.left + scrollLeft, rect: rect, height: h, width: w }
	} // cms_get_elem_position()

function cms_toggle_childByIndex(event,obj,tagNAME,index) {	// used with Ccms_drop_box::panel_block()
	var children = obj.getElementsByTagName(tagNAME);
	if(children[index]) {
		var child = children[index];
		if(child) {
			var x = event.clientX;
			var y = event.clientY;
			var mouseInChild = document.elementFromPoint(x, y);
			if(!child.contains(mouseInChild)) {
				if((child.style.display == '') ||
					(child.style.display == 'none')) {
					child.style.display = 'block';
					} // if
				else {	// is it click in the child
					child.style.display = 'none';
					} // else
				} // if
			} // if
		}// if
	} // cms_toggle_childByIndex()

function cms_toggle_children(event,obj,tagNAME) {	// used with Ccms_drop_box::panel_block()
	var children = obj.getElementsByTagName(tagNAME);
	if((children) && (children.length > 0)) {
		for( var i = 0; i < children.length; i++) {
			var x = event.clientX;
			var y = event.clientY;
			var mouseInChild = document.elementFromPoint(x, y);
			if(!child.contains(mouseInChild)) {
				if((child.style.display == '') ||
					(child.style.display == 'none')) {
					child.style.display = 'block';
					} // if
				else {	// is it click in the child
					child.style.display = 'none';
					} // else
				} // if
			} // for
		} // if
	} // cms_toggle_children()

function cms_toggle_childByID(event,el_class,id) {	// used with Ccms_drop_box::panel_block()
	var child = document.getElementById(id);
	if(child) {
		var x = event.clientX;
		var y = event.clientY;
		var mouseInChild = document.elementFromPoint(x, y);
		if(!child.contains(mouseInChild)) {
			if((child.style.display == '') ||
				(child.style.display == 'none')) {
				child.style.display = 'block';
				child.style.visibility = 'visible';
				child.style.opacity = 1;
				// child.style.zIndex="10000";
				} // if
			else {	// is it click in the child
				child.style.display = 'none';
				child.style.visibility = 'hidden';
				child.style.opacity = 0;
				} // else
			} // if
		}// if
	} // cms_toggle_childByID()

function cms_toggle_elemsByClass(el_class) {	// used with Ccms_drop_box::panel_block()
	var elems = document.getElementsByClassName(el_class);
	if((elems) && (elems.length > 0)) {
		for(var i = 0; i < elems.length; i++) {
			var elem = elems[i];
			if((elem.style.display == '') ||
				(elem.style.display == 'none')) {
				elem.style.display = 'block';
				} // if
			else {	//
				elem.style.display = 'none';
				} // if
			} // for
		} // if
	} // cms_toggle_elemsByClass)

function cms_turnoff_elemsByClass(el_class) {	// used with Ccms_drop_box::panel_block()
	var elems = document.getElementsByClassName(el_class);
	if((elems) && (elems.length > 0)) {
		for(var i = 0; i < elems.length; i++) {
			var elem = elems[i];
			elem.style.display = 'none';
			} // for
		} // if
	} // cms_turnoff_elemsByClass)

function cms_turnon_elemsByClass(el_class) {	// used with Ccms_drop_box::panel_block()
	var elems = document.getElementsByClassName(el_class);
	if((elems) && (elems.length > 0)) {
		for(var i = 0; i < elems.length; i++) {
			var elem = elems[i];
			if((elem.style.display == '') ||
				(elem.style.display == 'none')) {
				elem.style.display = 'block';
				} // if
			} // for
		} // if
	} // cms_turnon_elemsByClass)

class Ccms_gife {

	// this is a static helper class for Ccms_options::grid_input_form_elems() method
	// (and similar methods)

	static swap_tabrow(name, s_r, d_r, cols) {
	var s_id, s_obj, s_val;
	var d_id, d_obj, d_val;
	for (var c = 0; c < cols; c++) {
		s_id = name + "[" + s_r + "][" + c + "]";
		d_id = name + "[" + d_r + "][" + c + "]";
		s_obj = document.getElementById(s_id);
		if(!s_obj) continue;
		d_obj = document.getElementById(d_id);
		if(!d_obj) continue;
		if (s_obj.nodeName.toLowerCase() == "select") {
		// try select first
			s_val = s_obj.options[s_obj.selectedIndex].value;
			d_val = d_obj.options[d_obj.selectedIndex].value;
			d_obj.value = s_val;
			s_obj.value = d_val;
			} // if
		else if (s_obj.nodeName.toLowerCase() == "input") {
			if(s_obj.type == 'checkbox') {
				s_val = s_obj.checked;
				d_val = d_obj.checked;
				d_obj.checked = s_val;
				s_obj.checked = d_val;
				} // if
			else {
				s_val = s_obj.value;
				d_val = d_obj.value;
				d_obj.value = s_val;
				s_obj.value = d_val;
				} // else
			} // else
		else
			alert("Unknown element " + s_id);
	} // for
	} // swap_tabrow()

	static move_up_tabrow(name, s_r, rows, cols) {
	if (s_r > (0 + 0)) {
		this.swap_tabrow(name, s_r, (s_r - 1), cols);
	} // if
	} // move_up_tabrow()

	static move_down_tabrow(name, s_r, rows, cols) {
	if (s_r < (rows - 1)) {
		this.swap_tabrow(name, s_r, (s_r + 1), cols);
	} // if
	} // move_down_tabrow()

	static get_arrow_text(name, row, rows, cols, dir) {
	rows += 1;	// on a new row
	switch (dir) {
		case 'down':
		var url = ((typeof this.move_down_tabrow === 'function') ? this.down_arrow_url() : '<img src="cms/images/arrow-down.gif" width="15" height="15"/>');
		var link = '<a onclick="Ccms_gife.move_down_tabrow(\'' + name + '\',' + row + ',' + rows + ',' + cols + ');" title="Move row down to ' + (row + 2) + '">' + url + '</a>';
		break;
		default:
		var url = ((typeof this.move_down_tabrow === 'function') ? this.up_arrow_url() : '<img src="cms/images/arrow-up.gif" width="15" height="15"/>');
		var link = '<a onclick="Ccms_gife.move_up_tabrow(\'' + name + '\',' + row + ',' + rows + ',' + cols + ');" title="Move row up to ' + (row - 0) + '">' + url + '</a>';
		break;
	} // switch
	return link;
	} // get_arrow_text()

	static chk_add_tabrow(self,name) {
	// do we need another row added ?
	// table row and col ids are not the same as input element row and col
	// the input element ids needs to follow the requirements of the $_POST array
	// where as the table ids need to follow the table layout
	// the the top row of the table is only a heading row and can be ignored
	// the input element and the corresponding table row have the same row id numbers
	// but the input element column ids start at 0 which is table column id 1

	var form = self.form;
	var table = document.getElementById(name + "_table");
	var rows = table.rows.length - 1;	// same as form
	var cols = table.rows[0].cells.length - 3;	// same as form

	// scan the last row input elements for !empty if !empty add a row
	var id, obj, val;
	var add_row = true;
	var r_last = rows - 1;
	var has_data = false;
	for (var c = 0; c < cols; c++) {	// 0 = th idx
		id = name + "[" + r_last + "][" + c + "]";
		obj = document.getElementById(id);
		if (!obj) {	// why ?
			continue;
			} // if
		if (obj.nodeName.toLowerCase() == "select") {
			// try select first
			// val = obj.options[obj.selectedIndex].value;
			val = obj.selectedIndex;
			} // if
		else if (obj.nodeName.toLowerCase() == "input") {
			if (obj.type == 'checkbox')
				continue;
			val = obj.value;
			} // else
		else
			alert("Unknown element " + id);
		if (!!val) {
			has_data = true;
			break;
			} // if
		} // for
	if (!has_data) {
		add_row = false;
		} // if
	if (add_row) {	// work the layout (actual form has a heading row and extra columns)
		var obj_dst_row = table.rows[(r_last + 1)].cloneNode(true); // +1 for heading row
		var id_dst_row = name + "_table_row[" + (r_last + 1) + "]";
		// copy last row to new row
		var id_scr_row = name + "_table_row[" + r_last + "]";
		obj_dst_row.id = id_dst_row;

		// adjust the ids
		for (var c = 0; c < (cols + 1); c++) {
			var id_dst = name + "_table_cell[" + (r_last + 1) + "][" + c + "]";
			var obj_dst_cell = obj_dst_row.cells[c];
			if (obj_dst_cell.tagName == 'TH') {	// the idx th
				obj_dst_cell.innerHTML = rows + 1;
				obj_dst_cell.id = id_dst;
				continue;
				} // if
			// td
			obj_dst_cell.id = id_dst

			// update the ids
			var find = name + '[' + (r_last + 0) + '][';
			var replace = name + '[' + (r_last + 1) + '][';
			var dst_text = obj_dst_cell.innerHTML;
			while (dst_text.includes(find)) {	// not global
				dst_text = dst_text.replace(find, replace);	// regex ?
				} // while
			obj_dst_cell.innerHTML = dst_text;

			var c_elems = obj_dst_cell.getElementsByTagName("*");
			for(var e = 0; e < c_elems.length; e++) {
				var c_e = c_elems[e];
				var tag = c_e.tagName;
				switch(tag) {
				case 'SELECT':
					c_e.selectedIndex = '';
					// ?? why form.appendChild(c_e);
					break;
				case 'INPUT':
					if(c_e.type != 'CHECKBOX')
						c_e.value = '';
					// ?? why form.appendChild(c_e);
					break;
				default:
					break;
					} // switch
				} // for

			if ((typeof this.debug !== 'function') || (this.debug()))
				console.log(obj_dst_cell);
			} // for

		table.appendChild(obj_dst_row);

		// obj_dst_row.innerHTML = src;
		var id_dst_u = name + "_table_cell[" + (r_last + 1) + "][" + (cols + 1) + "]";
		// var obj_dst_u = obj_dst_row.insertCell(cols + 1);
		var obj_dst_u = obj_dst_row.cells[(cols + 1)];
		obj_dst_u.innerHTML = this.get_arrow_text(name, (r_last + 1), (r_last + 1), (cols + 1), 'up');
		obj_dst_u.id = id_dst_u;
		cms_addElem_title2tooltip(obj_dst_u);

		var id_dst_d = name + "_table_cell[" + (r_last + 1) + "][" + (cols + 2) + "]";
		// var obj_dst_d = obj_dst_row.insertCell(cols + 2);
		var obj_dst_d = obj_dst_row.cells[(cols + 2)];
		obj_dst_d.id = id_dst_d;
		obj_dst_d.innerHTML = '';	// empty down space

		var id_dst_du = name + "_table_cell[" + r_last + "][" + (cols + 2) + "]";
		var obj_dst_du = document.getElementById(id_dst_du);
		obj_dst_du.innerHTML = this.get_arrow_text(name, r_last, (r_last + 1), (cols + 2), 'down');
		cms_addElem_title2tooltip(obj_dst_du);

		if ((typeof this.debug !== 'function') || (this.debug()))
			console.log(obj_dst_row);
		} // if
	} // chk_add_tabrow(this,)

} // Ccms_gife

class Cfilter_PDBs {

	static on_filter(inp,id) {
		var val = inp.value;
		var keys = val.split(' ');	// do an and on keywords

		var tb = document.getElementById(id + 'tb');
		var rows = tb.rows.length;
		for(var i = 0; i < rows; i++) {
			var tr = document.getElementById(id + 'tr' + i);
			if(!tr) continue;
			var td = document.getElementById(id + 'td' + i);
			if(!td) continue;
			var a = document.getElementById(id + 'a' + i);
			var txt = '';
			if(!a) txt = td.innerHTML;	// JS link
			else txt = a.innerHTML;	// anchor

			var found = true;
			var includes = false;
			for (var j = 0; j < keys.length; j++) {
				includes = txt.toLowerCase().includes(keys[j].toLowerCase());
				if (!includes) {
				found = false;
				break;
				} // if
			} // for
			if (found) tr.style.display = '';	// show
			else tr.style.display = 'none';	// hide
			} // for
		return true;
	} // on_filter()

} // Cfilter_PDBs

// EOF

