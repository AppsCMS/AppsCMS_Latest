/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
<?php // * _SVN_build: $Id: cms_styles_inline.css.php 3139 2023-02-14 20:38:55Z robert0609 $ ?>
 */

/*
	Document   : inline_styles
	Description:
		Purpose of the stylesheet follows.
		Inline styles, the header, body and footer are sequential top to bottom overflowing the browser window.
		Recommended for all devices, has floating header and footer.
		<?= $gen_note ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

<?php

$margin = 0;
$body_pad = 0;	// it seems that chrome and firefox have a hyterisis on switching the scrollbars on and off

$lay_bound = 0;
if(CMS_S_DEBUG_BOOL && CMS_S_DEBUG_LAYOUT_BOOL) {
	$lay_bound = 4;	// border width
	
// see "https://www.w3schools.com/tags/ref_colornames.asp" for colour names
	
?>

/* layout boundary debugging on */
div.cms_lo_page_inline { border: <?= $lay_bound ?>px dotted red; }
div.cms_lo_header { border: <?= $lay_bound ?>px dotted yellow; }
div.cms_lo_nav_bar { border: <?= $lay_bound ?>px dotted blue; }
div.cms_lo_middle { border: <?= $lay_bound ?>px dotted cyan; }
div.cms_lo_left_column { border: <?= $lay_bound ?>px dotted green; }
div.cms_lo_body_column { border: <?= $lay_bound ?>px dotted grey; }
div.cms_lo_right_column { border: <?= $lay_bound ?>px dotted brown; }
div.cms_lo_footer { border: <?= $lay_bound ?>px dotted orange; }

<?php	
	} // if

$sects = 0;
$sects++;	// for body

if($theme['ThemeSettings']['HEADER_BOOL'] == 'true') {
	$sects++;
	$header_height = (int)preg_replace('/[a-z]*$/i', '',$theme['ThemeSettings']['HEADER_HEIGHT']);
	} // if
else $header_height = 0;

if($theme['ThemeSettings']['NAV_BAR_BOOL'] == 'true') {
	$sects++;
	$nav_bar_height = (int)preg_replace('/[a-z]*$/i', '',$theme['ThemeSettings']['NAV_BAR_HEIGHT']);
	} // if
else $nav_bar_height = 0;

if($theme['ThemeSettings']['FOOTER_BOOL'] == 'true') {
	$sects++;
	$footer_height = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['FOOTER_HEIGHT']);
	} // if
else $footer_height = 0;

if($theme['ThemeSettings']['LEFT_COLUMN_BOOL'] == 'true')
	$left_column_width = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['LEFT_WIDTH']);
else $left_column_width = 0;

if(($theme['ThemeSettings']['RIGHT_COLUMN_BOOL'] == 'true') && 
	($theme['ThemeSettings']['LEFT_COLUMN_BOOL'] == 'true'))
	$right_column_width = (int)preg_replace('/[a-z]*$/i','',$theme['ThemeSettings']['RIGHT_WIDTH']);
else $right_column_width = 0;

$sect_gap = (0 + $lay_bound + $margin) * 2;
$hnf = ($header_height + $nav_bar_height + $footer_height + ($sect_gap * ($sects + $sects)) + 4);

if(Ccms::is_debug()) {
?>

/* debug */
/* margin = <?= $margin ?> */
/* body_pad = <?= $body_pad ?> */
/* sections = <?= $sects ?> */
/* section gap = <?= $sect_gap ?> */
/* header height = <?= $header_height ?> */
/* nav_bar height = <?= $nav_bar_height ?> */
/* footer_height = <?= $footer_height ?> */
/* height of header + nav_bar + footer height + spacers + gaps = <?= $hnf ?> */

<?php	} // if ?>

/* the inline layout */
div.cms_lo_page_inline {
	}

	div.cms_lo_header {
		min-height: <?= $header_height ?>px;
		/* width: 100%; */
		/*overflow: auto;*/
		}
	div.cms_lo_nav_bar {
		min-height: <?= $nav_bar_height ?>px;
		/* width:	100%; */
		margin: 0px;
		/*overflow: auto;*/
		}
	div.cms_lo_nav_bar:hover {
		overflow: unset;
		z-index: 1000;
		}

	div.cms_lo_middle {
		vertical-align: top;
		/* width: 100%; */
		/* min-height: calc(100vh - <?= $hnf ?>px); */
<?php if($body_pad) { ?>
		padding: <?= $body_pad ?>px;
<?php	} // if ?>
		/*overflow: auto;*/
		}

		div.cms_lo_left_column {
			background-color: <?= $theme['ThemeSettings']['LEFT_BKGD_COLOUR'] ?>;
			color:		<?= $theme['ThemeSettings']['LEFT_FONT_COLOUR'] ?>;
			<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['LEFT_BORDER']) ?>
			vertical-align: top;
			min-width: <?= $left_column_width ?>px;
			/* min-height: calc(100vh - <?= $hnf ?>px); */
			/*overflow: auto;*/
			}
		div.cms_lo_body_column {
<?php if(!empty($theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE'])) { ?>
			background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']) ?>;
			background-repeat: no-repeat;
			background-attachment: local;
			background-size: 100% 100%;
<?php } else { ?>
			background-color: <?= $theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'] ?>;
<?php } // else ?>
			<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_BODY_BORDER']) ?>
			color:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR'] ?>;
			vertical-align: top;
			width: 100%;
			/* min-width: 100%; */
			/* min-height: calc(100vh - <?= $hnf ?>px); */
			/*overflow: auto;*/
			}
		div.cms_lo_right_column {
			background-color: <?= $theme['ThemeSettings']['RIGHT_BKGD_COLOUR'] ?>;
			color:		<?= $theme['ThemeSettings']['RIGHT_FONT_COLOUR'] ?>;
			<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['RIGHT_BORDER']) ?>
			min-width: <?= $right_column_width ?>px;
			/* min-height: calc(100vh - <?= $hnf ?>px); */
			vertical-align: top;
			/*overflow: auto;*/
			}

	div.cms_lo_footer {
		/* width: 100%; */
		min-height: <?= $footer_height ?>px;
		/*overflow: auto;*/
		}

#lm_link_frame {
	z-index:	3;
	width:		100%;
	}

.link_frame_moz {
	/*min-height: calc(100vh - <?= $hnf ?>px);*/
	}
.link_frame_tablet {
	/*min-height: calc(100vh - <?= $hnf ?>px);*/
	}

.iframe_tablet {
	max-width:		100%;
	border-width: 0;
	min-height: calc(100vh - <?= $hnf ?>px);

	}
.iframe_moz {	/* must be inside a relative position container */
	border: 0;
	width: 100%;
	min-height: calc(100vh - <?= $hnf ?>px - 25px);
	}

/* eof */

