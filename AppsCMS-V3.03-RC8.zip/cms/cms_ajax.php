<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_ajax.php 2795 2022-09-10 09:37:50Z robert0609 $
 */

if(!defined('AJAX_CALL')) define('AJAX_CALL',true);	// global for AJAX recognition

require_once 'include/cms_top.php';

if(Ccms::is_ajax()) {	// works with the javascript Ccms_ajax_ops class
	$ajax_ops = new Ccms_ajax_ops();
	} // if

require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';
