<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

if(!defined('API_CALL')) define('API_CALL',true);	// global for API recognition

require_once 'include/cms_top.php';

require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';
