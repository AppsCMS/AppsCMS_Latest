<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_create.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

define('CLI_MODE',		true);	// tell
define('CMS_S_DB_DIE_ON_ERRORS_BOOL', false);

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$admin_user = (isset($argv[1]) ? $argv[1]:'');
$admin_passwd = (isset($argv[2]) ? $argv[2]:'');
$db_host = Ccms_base::get_cms_ini_value('DB_MYSQL_HOST_URL','DataBaseAccess');
$db_name = Ccms_base::get_cms_ini_value('DB_MYSQL_DATABASE','DataBaseAccess');

$box_backtitle = 'Admin for ' . CMS_PROJECT_SHORTNAME . ' DB host: "' . $db_host . '".';	// show at the top of the screen

echo "Checking/installing " . CMS_PROJECT_SHORTNAME . " DB on host: " . $db_host . PHP_EOL;

if((empty($admin_user)) || (empty($admin_passwd))) {
	$vals = Ccms_cli_dialogs_plugin::box_username_password('Enter MySQL admin credentials', $box_backtitle);
	$admin_user = $vals['USERNAME'];
	$admin_passwd = $vals['PASSWORD'];
	} // if

$cDBcms = new Ccms_MySQL(true,$admin_user,$admin_passwd);

exit(0);	// done

// eof
