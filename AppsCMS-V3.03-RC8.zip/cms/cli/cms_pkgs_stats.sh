#!/bin/bash
# see Licence in cms/LICENCE.txt
# _SVN_build: $Id: cms_pkgs_stats.sh 2958 2022-11-05 07:04:06Z robert0609 $
# get package status

# try RPM first
which rpm  > /dev/null 2>&1
if [ $? -eq 0 ]; then	# RPM
	rpm -q AppsCMS  > /dev/null 2>&1
	if [ $? -eq 0 ]; then	# installed
		echo -n "$(rpm -q --qf '%{name}-%{version}-%{release}.%{arch}' AppsCMS).rpm"	# prints package info
		exit 0	# got it
	fi
	echo "AppsCMS rpm not installed."
	exit 1	# not installed
fi


which apt  > /dev/null 2>&1
if [ $? -eq 0 ]; then	# DEB
	# @TODO DEB

fi

echo "ERROR: Packager not found."
exit 10

# EOF
