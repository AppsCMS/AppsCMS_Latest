<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: ajax.php 2143 2021-08-09 05:42:03Z robert0609 $
 */

define('AJAX_CALL',true);	// global for AJAX recognition

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_ajax.php';

