<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * SVN Build: $Id: ws_server.php 2590 2022-03-15 07:33:38Z robert0609 $
 */

define('WS_DAEMON_CALL',true);	// global for WS server recognition
define('CLI_MODE',true);	// tell configure

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_ws_server.php';
