<?php 
Ccms::page_start_comment(__FILE__,false);

include(APPs_FS_APPO_DIR . 'appointments.php');

Ccms::page_end_comment(__FILE__,false);

