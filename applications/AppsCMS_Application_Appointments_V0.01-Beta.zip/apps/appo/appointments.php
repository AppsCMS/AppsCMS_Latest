<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: appointments.php 3251 2023-03-02 12:50:06Z robert0609 $
 */

$cAPPO = new Ccms_appointments_plugin(true);

echo $cAPPO->get_appointment_panel();

