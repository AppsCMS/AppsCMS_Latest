#!/bin/sh
# Generate self signed SSL Certificate Keys
# author: robert0609
#
INC='apps/book_keep/cli/ssl/genSslSelfSignedKeys.inc'
if [ -f ../$INC ]; then
	. ../$INC
elif [ -f $INC ]; then
	. $INC
else
	echo "ERROR: cannot find \"$INC\""
	exit 1
fi

log2file "Started selfsigned SSL key generation ($FVERSION)" "$LOGFILE"

# Generate CA key
ROOT_CA=${KEYROOTFLDR}bookkeepCA.key
echo "Generating root CA $ROOT_CA"
$OPENSSL genrsa -passout pass:$CA_PASS -out $ROOT_CA 2048

genkeys "Book_Keep_MySQL" # generate self signed key

log2file "Finished selfsigned SSL key generation ($FVERSION)" "$LOGFILE"
exit 0

# EOF



