<?php
/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keep_balances.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure not to crash

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$cBK_BAL = new Cbook_keep_balances();

exit(0);	// done

// eof
