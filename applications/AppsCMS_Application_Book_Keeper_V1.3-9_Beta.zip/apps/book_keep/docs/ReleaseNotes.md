AppsCMS Application - Book Keeper Ledger - RELEASE NOTES
========================================================
see Book Keeper Licence in LICENCE.txt
<!-- _SVN_build: $Id: ReleaseNotes.md 2786 2022-08-31 05:40:44Z robert0609 $ -->

![AppsCMS Logo](apps/book_keep/icons/book_keeping.png)

@TODO better transaction entry

Release Notes - V1.3-4 Beta January 2020
-------------------------------------
Revised file headers.
Upgrade for PHP 7.4

Release Notes - V1.3-3 Beta July 2020
-------------------------------------
Bugfixes

Release Notes - V1.3-2 Beta July 2020
-------------------------------------
Bugfixes

Release Notes - V1.3-1 Beta May 2020
-------------------------------------
Bugfixes

Release Notes - V1.3 Beta April 2020
-------------------------------------
First book keep application beta release.
Building ledger interfaces.

.EOF.
