<?php
/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keeper_manual.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

?>
<?= Ccms::get_body_logo_uri('bk_logo') ?>
<h1>Book Keeper Manual (<?= Ccms::get_body_version('book_keep') ?>)</h1>

<p>To be written.</p>

