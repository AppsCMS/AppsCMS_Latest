/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: app_css.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

/*
	Document   : app_css
    Description:
        Purpose of the stylesheet follows.
		Book Keeper styles.
		<?= $gen_note ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

/* looks like app INI comment file */
.plus_number {
	background-color: <?= $theme['ThemeSettings']['FMT_PLUS_NUMBER_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['FMT_PLUS_NUMBER_COLOUR'] ?>;
	font-size: 1.2em;
	padding: 5px;
	}

.neg_number {
	background-color: <?= $theme['ThemeSettings']['FMT_NEG_NUMBER_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['FMT_NEG_NUMBER_COLOUR'] ?>;
	font-size: 1.2em;
	padding: 5px;
	}

/* eof */

