<?php
/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keeper_DB.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

$action_uri = Ccms::get_body_uri();
if(Ccms::is_get_or_post('book_keep_op')) {
	$action_uri .= '&book_keep_op=' . Ccms::get_or_post('book_keep_op');
} // if
echo Ccms::get_admin_scroll2pageTop();

$cDBdlg = new Ccms_DB_modal('book_keep');
echo $cDBdlg->get_DB_edit_modal();	// put dialog triggers in place for ajax calls

$cDB_edit = new Cbook_keep_DB_edit();
if(!$cDB_edit->is_ok()) return false;

$ajax_uri = 'cms/cms_ajax.php?ajax=book_keep_save&app=book_keep';
$ajax_DB_column_uri = 'cms/cms_ajax.php?ajax=get_DB_select_options&app=book_keep';
echo $cDB_edit->edit_database(
	'Edit Data',
	$action_uri,
	$ajax_uri,
	$ajax_DB_column_uri
	);
?>
