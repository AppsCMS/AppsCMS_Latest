<?php
/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keeper.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

if(!defined('APPs_FS_BOOK_KEEP_DIR')) return;

$action_uri = Ccms::get_body_uri();

$book_keep_op = Ccms::get_or_post_app_session('book_keep_op');

?>
<?= Ccms::get_body_logo_uri('bk_logo') ?>
<h1>Book Keeper (<?= Ccms::get_body_version() ?>)</h1>
<span class="no_print">
	&nbsp;&nbsp;
	<form action="<?= $action_uri ?>" method="post" onsubmit="Ccms_cursor.setWait();">
		<button type="submit" name="book_keep_op" value="ledger"
			title="Click to go to ledger.">Ledger</button>
		<button type="submit" name="book_keep_op" value="reports"
			title="Create, download and print reports.">Reports</button>
		<button type="submit" name="book_keep_op" value="summary"
			title="Click to view accounts summary.">Summary</button>
		<button type="submit" name="book_keep_op" value="edit_db"
			title="Click to edit transactions and accounts directly.">Edit Data</button>
	</form>
	<br>
</span>
<?php
switch($book_keep_op) {
case 'edit_db':
	include(APPs_FS_BOOK_KEEP_DIR . 'book_keeper_DB.php');
	break;
case 'reports':
	include(APPs_FS_BOOK_KEEP_DIR . 'book_keeper_reports.php');
	break;
case 'summary':
	include(APPs_FS_BOOK_KEEP_DIR . 'book_keeper_summary.php');
	break;
case 'ledger':
default:
	include(APPs_FS_BOOK_KEEP_DIR . 'book_keeper_ledger.php');
	break;
	} // switch

?>
