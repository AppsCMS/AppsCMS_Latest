<?php
/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keeper_summary.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

$account_ids = Ccms::get_or_post_app_session('account_ids');
$column_ids = Ccms::get_or_post_app_session('column_ids');
$orderby = Ccms::get_or_post_app_session('orderby');
$start_date = Ccms::get_or_post_app_session('start_date');
$end_date = Ccms::get_or_post_app_session('end_date');

$action_uri = Ccms::get_body_uri();
if($op = Ccms::get_or_post_app_session('book_keep_op')) {
	$action_uri .= '&book_keep_op=' . $op;
} // if

echo Ccms::get_admin_scroll2pageTop();
$cDBdlg = new Ccms_DB_modal('book_keep');
echo $cDBdlg->get_DB_edit_modal();	// put dialog triggers in place for ajax calls

$cDB_edit = new Cbook_keep_DB_edit();
if(!$cDB_edit->is_ok()) return false;

$ajax_uri = 'cms/cms_ajax.php?ajax=book_keep_save&app=book_keep';
$ajax_DB_column_uri = 'cms/cms_ajax.php?ajax=get_DB_select_options&app=book_keep';
$cDB_edit->edit_database_pre(
	$h2 = '',
	$action_uri,
	$ajax_uri,
	$ajax_DB_column_uri,
	$title = ''
	);
$dates_min_max = $cDB_edit->get_transaction_dates_range($account_ids);
if(empty($start_date)) $start_date = $dates_min_max['min']['iso'];
if(empty($end_date)) $end_date = $dates_min_max['max']['iso'];
$summary = $cDB_edit->get_accounts_balance_summaries($account_ids,$column_ids,$orderby,$start_date,$end_date);

?>
<script type="text/javascript">
	var last_summary_DB_submit_call = null;
	var summary_DB_submit_deb = 1200;
	function summary_DB_submit_form(obj) {
		if(last_summary_DB_submit_call != null) {	// clear it
			window.clearTimeout(last_summary_DB_submit_call);
			last_summary_DB_submit_call = null;
			} // if
		// restart if
		last_summary_DB_submit_call = window.setTimeout(function(obj) {
			if(obj.form) {
				obj.form.submit();
				} // if
			},
		summary_DB_submit_deb, obj);
		} // summary_DB_submit_form()
</script>
&nbsp;
<div>
	<form action="<?= $action_uri ?>" name="report_cntl" onsubmit="report_DB_submit_form(this);" method="post">
		<div style="display: inline-block; vertical-align: top;">
			<input type="hidden" name="row_cnt" value="<?= $summary['row_cnt'];?>">
			<label style="vertical-align: top;"><h2 title="Transactions summary.">Summary:</h2></label>
		</div>
``		<div style="display: inline-block; vertical-align: top;">
			<label style="vertical-align: top;"><?= $cDB_edit->get_accounts_selection($action_uri,$account_ids,'Select accounts to work with.') ?></label>
		</div>
		<div style="display: inline-block; vertical-align: top;">
			<label style="vertical-align: top;"><?= $cDB_edit->get_columns_selection($action_uri,$column_ids,'Select columns to work with.') ?></label>
		</div>
		<div style="display: inline-block; vertical-align: top;">
			<div>
				<label style="vertical-align: top;"><?= $cDB_edit->get_transaction_orderby_select($action_uri, $orderby,'Select the order of the transactions.') ?></label>
				<label style="vertical-align: top;">
					<input type="date" name="start_date"
						value="<?= $cDB_edit->get_elem_iso_date($start_date) ?>"
						<?= (!empty($dates_min_max['min']) ? ' min="' . $dates_min_max['min']['iso'] . '"':'') ?>
						<?= (!empty($dates_min_max['max']) ? ' max="' . $dates_min_max['max']['iso'] . '"':'') ?>
						title="Transaction first date (min=<?= $dates_min_max['min']['local'] ?>)."/>
				</label>
				<label style="vertical-align: top;">
					<input type="date" name="end_date"
						value="<?= $cDB_edit->get_elem_iso_date($end_date) ?>"
						<?= (!empty($dates_min_max['min']) ? ' min="' . $dates_min_max['min']['iso'] . '"':'') ?>
						<?= (!empty($dates_min_max['max']) ? ' max="' . $dates_min_max['max']['iso'] . '"':'') ?>
						title="Transaction last date (max=<?= $dates_min_max['max']['local'] ?>)."/>
				</label>
				<?php // echo $cDB_edit->get_DB_filter_prev_next_page_form($action_uri) ?>
				<label class="no_print" style="vertical-align: top;">
					<button type="submit" name="report" value="lookup">Lookup</button>
				</label>
			</div>
			<div class="no_print">
				<?= $cDB_edit->get_transactions_page_selector() ?>
			</div>
			<?php if(!empty($summary['balances_not_done'])) { ?>
				<div class="cms_msg_warning no_print" style="padding: 5px;">
					Account balances not updated, using page start as zero.
				</div>
			<?php	} // if ?>
		</div>
	</form>
</div>

<?php

if(empty($account_ids)) {
	Ccms::addMsg('No accounts selected. <b>Select one or more accounts</b> to display.','info');
	// echo '<br><p>No accounts selected. <b>Select one or more accounts</b> to display.</p>';
	return;
	} // if

if((empty($summary['row_cnt'])) || (empty($summary['data']))) {
	echo '<p><b>No transactions in range.</b></p>';
	return;
	} // if
$row_cntr = 0;
?>
<br>
<table id="id_table_id_db_table_heading_form"  class="page_database">
	<tr class="page_database_sticky_heading">
<?php
	foreach($summary['headings'] as $k => &$col_info) {
		if(!in_array($k,$summary['show'])) continue;
?>
		<th class="page_database">
			<div class="page_database col_DB_head">
				<?= $col_info['head'] ?>
			</div>
		</th>
<?php	} // foreach ?>
	</tr>
<?php
	for($i = 0; $i < count($summary['data']); $i++) {
		$data = &$summary['data'][$i];
		$transaction_id = $data['transaction_id'];
?>
	<tr class="page_database<?= (($row_cntr++ & 1) ? ' page_database_odd':' page_database_even') ?>">
<?php
	foreach($summary['headings'] as $k => &$col_info) {
		if(!in_array($k,$summary['show'])) continue;
		$value = (!empty($data[$k]) ? $data[$k]:'');
		$class = &$col_info['class'];
?>
		<td class="page_database <?= $class ?>"><label class="page_database"><?= $value ?></label></td>

<?php	} // foreach ?>
	</tr>
<?php
	} // for
?>
</table>
<p class="page_database"><?= $summary['row_cnt'] ?> rows.</p>
