<?php

/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keep_DB_edit.php 3366 2023-07-20 07:23:55Z robert0609 $
 */

/**
 * Description of book_keep_DB_edit
 * Main app db class.
 *
 * @author robert0609
 */
class Cbook_keep_DB_edit extends Ccms_DB_edit {

	protected $cLS_DBint = false;
	protected $db_user = false;
	protected $db_passwd = false;
	protected $db_name = false;
	protected $db_host = false;
	protected $db_ssl_key = null;
	protected $db_ssl_cert = null;
	protected $db_ssl_ca = null;

	protected static $dates_min_max = false;

	private $running_balance = false;
	private $balances_not_done = false;

	const FORM_NAME = 'book_keep';

	function __construct($class = '',$max_rows = 1000, $read_only = false) {
		$install_scripts = Cbook_keep_install::get_installDBscripts();
		if(!$this->init()) return false;
		parent::__construct($this->cLS_DBint,self::FORM_NAME,$install_scripts,$class,$max_rows, $read_only);
		$this->get_transaction_dates_range(false);	// prep it
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// override methods
	protected function format_DB_data_value($table, $col_name, $col_info, $data) {
		switch($table) {
		case 'transactions':
			if($col_name == 'transaction_amount') {
				return $this->format_number((float)$data);
				} // if
			break;
		default:
			break;
			} // switch
		return $data;
		} // format_DB_data_value()

// static methods

	public static function check_DB_timestamp2show($column_name,&$col_info,$column_value) {	// returns the text to show
		$ts = strtotime($column_value);
		if($ts <= 0) return '-';	// no time
		return $column_value;
		} // check_DB_timestamp2show()

// dynamic methods

	protected function format_number($number) {
		$result = null;
		switch(gettype($number)) {
		case "boolean":
			$result = ($number ? true:false);
			break;
		case "integer":
			$result = (int)$number;
			break;
		case "double":
		case "float":
			if(PL_BOOK_KEEP_CURRENCY_USE_LOCALE_FORMAT)
				$currency = self::number_to_currency($number);
			else $currency = $number;
			if($number >= 0.00000)
				$result = '<span class="plus_number">' . $currency . '</span>';
			else
				$result = '<span class="neg_number">' . $currency . '</span>';
			break;
		case "string":
			$result = $number;
			break;
		default:
			break;
		} // switch
	return $result;
	} // format_number()

	public function &get_DB() {
		return $this->cLS_DBint;
		} // get_DB()

	public function is_ok() {	// link method
		if(empty($this->cLS_DBint)) return false;
		return $this->cLS_DBint->is_ok();
		} // is_ok()

	public function install_db_tables(
		$only_table, $install_scripts, $verbose = false, $drop = false) {
		// link method
		return $this->cLS_DBint->install_db_tables(
		$only_table, $install_scripts, $verbose, $drop);
		} // install_db_tables()

	public function init() {
		if($this->cLS_DBint) {
			$this->cLS_DBint->close();
			$this->cLS_DBint = false;
			} // if
		$ok = true;
		if(!Cbook_keep_plugin::is_enabled()) $ok = false;
		if(!Cbook_keep_plugin::is_enabled()) $ok = false;
		if(!$ok) {
			self::addMsg('Book Keeper plugin not enabled.');
			return false;
			} // if
		if(PL_BOOK_KEEP_MYSQL_USE_SSL_BOOL) {
			$this->db_ssl_key = PL_BOOK_KEEP_MYSQL_SSL_KEY;
			$this->db_ssl_cert = PL_BOOK_KEEP_MYSQL_SSL_CERT;
			$this->db_ssl_ca = PL_BOOK_KEEP_MYSQL_SSL_CA;
			} // if
		set_time_limit(1200);
		self::set_chk_php_value('mysql.connect_timeout','120');
		// this is a global setting

		$this->db_user = PL_BOOK_KEEP_MYSQL_USERNAME;
		$this->db_passwd = PL_BOOK_KEEP_MYSQL_PASSWORD;
		$this->db_host = PL_BOOK_KEEP_MYSQL_HOST;
		if(self::is_production()) {
			$this->db_name = PL_BOOK_KEEP_MYSQL_DATABASE;
			} // if
		else {
			$this->db_name = PL_BOOK_KEEP_MYSQL_DATABASE . '_DEBUG';
			} // else

		$this->cLS_DBint = new Ccms_database_mysql($this->db_user,$this->db_passwd,$this->db_name,$this->db_host,
			$port = 3306, $timeout = 3000,
			$this->db_ssl_key, $this->db_ssl_cert, $this->db_ssl_ca);
		if(!$this->cLS_DBint->is_open()) {
			self::addMsg('Check host and configured credentials in "Book Keep" plugin Admin->Config.');
			return false;
			} // if
		$audit = Cbook_keep_install::get_table2query_audits();
		if(!$this->cLS_DBint->set_query_auditing($audit)) return false;
		return true;
		} // init()

	public function get_DB_ajax_edit_dialog() {
		$cDBajaxDlg = new Ccms_DB_modal('book_keep');

		$action_uri = $_SERVER['HTTP_REFERER'];
		$ajax_uri = false;	// for now
		$class_name = '';	// use default
		$header = '';
		$footer = '';
		$h1 = 'Edit Transaction';
		$name = '';	// use deafult
		if(self::get_or_post('row_id') == self::NO_INDEX_STR) {	// new transaction ??
			$h1 = 'New Transaction';
			$name = 'bk_new_';
			} // if
		// public function get_DB_edit_modal_ajax($cEditDB,$action_uri,$ajax_uri,
		//	$form_name,$install_scripts,
		//	$class_name = '', $h1 = '', $header = '', $footer = '', $name = '') {
		$text = $cDBajaxDlg->get_DB_edit_modal_ajax($this->cLS_DBint,$action_uri,$ajax_uri,
			$this->edit_DB_info['form_name'], $this->edit_DB_info['install_scripts'],
			$class_name, $h1, $header, $footer, $name);
		return $text;
		} // get_DB_ajax_edit_dialog()

	public function get_accounts_list($account_ids = false) {
		if(empty($account_ids)) $account_ids = self::get_or_post ('account_ids');
		if(empty($account_ids)) $account_ids = array();
		$accounts = array();
		$sql = 'SELECT DISTINCT account_id,account_name FROM accounts' .
			' WHERE account_closed = 0 AND account_enabled = 1' .
			' ORDER BY account_name';
		if($sql_res = $this->cEditDB->query($sql)) {
			while($acc = $this->cEditDB->fetch_array_assoc($sql_res)) {
				$accounts[] = $acc;
				} // while
			} // if
		return $accounts;
		} // get_accounts_list()

	public function get_accounts_selection($action_uri,$account_ids = false, $title = false) {
		if(empty($account_ids)) $account_ids = self::get_or_post ('account_ids');
		if(empty($account_ids)) $account_ids = array();
		$text = array();
		$sql = 'SELECT DISTINCT account_id,account_name FROM accounts' .
			' WHERE account_closed = 0 AND account_enabled = 1' .
			' ORDER BY account_name';
		if($sql_res = $this->cEditDB->query($sql)) {
			$acc_total = $this->cEditDB->get_row_cnt($sql_res);
			$id = 'accounts_selection';
//			$text[] = '<form action="' . $action_uri . '" name="accounts_selections_frm" method="post">';
			$text[] = '	<select id="' . $id . '"' .
				' name="account_ids[]"'.
//				' onchange="this.form.submit();"' .
				($title ? ' title="' . $title . '"':'') .
				' multiple' .
				' REQUIRED>';
			$text[] = '		<option value="" selected disabled hidden>' . '- Select Account-' . '</option>';
			while($acc = $this->cEditDB->fetch_array_assoc($sql_res)) {
				$seld = '';
				if(in_array($acc['account_id'],$account_ids))
					$seld = ' SELECTED';
				$text[] = '		<option value="' . $acc['account_id'] . '"' . $seld . '>' . $acc['account_name'] . '</option>';
				} // while
			$text[] = '	</select>';
//			if($acc_total > 10)
//				$text[] = self::get_select_option_filter($id, 'Find account.',-1);
//			$text[] = '</form>';
			} // if
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // get_accounts_selection()

	public function get_columns_selection($action_uri,$column_ids = false, $title = false) {
		if(empty($column_ids)) $column_ids = self::get_or_post ('column_ids');
		if(empty($column_ids)) $column_ids = array();
		$table = 'transactions';
		$table_details = &$this->edit_DB_info['install_scripts'][$table];
		$col_order = $table_details['ledger'];
		$text = array();
		$id = 'columns_selection';
//		$text[] = '<form action="' . $action_uri . '" name="accounts_selections_frm" method="post">';
		$text[] = '	<select id="' . $id . '"' .
			' name="column_ids[]"'.
//			' onchange="this.form.submit();"' .
			($title ? ' title="' . $title . '"':'') .
			' multiple' .
			' REQUIRED>';
		$text[] = '		<option value="" selected disabled hidden>' . '- Select Columns -' . '</option>';
		foreach($col_order as $col) {
			if(empty($table_details['edit']['columns'][$col]['head'])) continue;	// error config
			$col_name = $table_details['edit']['columns'][$col]['head'];	// head for calc signal
			$seld = '';
			if(in_array($col,$column_ids))
				$seld = ' SELECTED';
			$text[] = '		<option value="' . $col . '"' . $seld . '>' . $col_name . '</option>';
			} // foreach
		$text[] = '	</select>';
//			if($acc_total > 10)
//				$text[] = self::get_select_option_filter($id, 'Find account.',-1);
//			$text[] = '</form>';
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // get_columns_selection()

	public function get_elem_iso_date($date) {
		// $date can be;
		// yyyy-mm-dd hh:MM:ss or similar
		// need yyyy-mm-dd for date input
		if(!self::$dates_min_max) return $date;	// code procedural error ???
		$dates_min_max = self::$dates_min_max;
		if(!empty($date['time'])) $time = $date['time'];
		else $time = strtotime((empty($date) ? 'now':$date));	// best way
		if(!empty($dates_min_max)) {
			if($time < $dates_min_max['min']['time']) $time = $dates_min_max['min']['time'];
			else if($time > $dates_min_max['max']['time']) $time = $dates_min_max['max']['time'];
			} // if
		$fmt_d = date('Y-m-d',$time);
		return $fmt_d;
		} // get_elem_iso_date()

	public function &get_transaction_dates_range($account_ids,$order_bys = false) {
		if(self::$dates_min_max) return self::$dates_min_max;	// save time
		if(empty($account_ids)) { // get all account_ids, we are starting a ledger session
			$accounts = $this->get_accounts_list();
			$account_ids = array();
			foreach($accounts as $a) {
				if(empty($a['account_id'])) continue;
				$account_ids[] = $a['account_id'];
				} // foreach
			} // if
		if(empty($order_bys)) {
			$order_bys = array(
				'transaction_date',
				'transaction_added',
				);
			} // if
		else if(!is_array($order_bys)) $order_bys = explode(' ',$order_bys);
		if(!is_array($account_ids)) $account_ids = explode(' ',$account_ids);
		$dates_min_max = array();
		foreach($account_ids as $id) {
			$sql = 'SELECT transaction_id,transaction_date,transaction_added' .
			' FROM transactions' .
			' WHERE account_id = ' . (int)$id;
			foreach($order_bys as $o) {
				$sql_chk = $sql .
					' ORDER BY ' . $o . ' ASC' .
					' LIMIT 1';
				if(($sql_res = $this->cEditDB->query($sql_chk)) &&
					($date = $this->cEditDB->fetch_array_assoc($sql_res))) {
					$dates_min_max[$id]['ASC'][$o] = $date[$o];
					if((empty($dates_min_max['min'])) ||
						($dates_min_max['min']['date'] > $date[$o])) {
						$dates_min_max['min']['date'] = $date[$o];
//						$dates_min_max['min']['iso'] = date('Y-m-d',strtotime($date[$o]));
//						$dates_min_max['min']['time'] = strtotime($date[$o]);
//						$dates_min_max['min']['local'] = cms_strftime('%x',strtotime($date[$o]));
						} // if
					} // if
				$sql_chk = $sql .
					' ORDER BY ' . $o . ' DESC' .
					' LIMIT 1';
				if(($sql_res = $this->cEditDB->query($sql_chk)) &&
					($date = $this->cEditDB->fetch_array_assoc($sql_res))) {
					$dates_min_max[$id]['DESC'][$o] = $date[$o];
					if((empty($dates_min_max['max'])) ||
						($dates_min_max['max']['date'] < $date[$o])) {
						$dates_min_max['max']['date'] = $date[$o];
//						$dates_min_max['max']['iso'] = date('Y-m-d',strtotime($date[$o]));
//						$dates_min_max['max']['time'] = strtotime($date[$o]);
//						$dates_min_max['max']['local'] = cms_strftime('%x',strtotime($date[$o]));
						} // if
					} // if
				} // foreach
			} // foreach
		// heck we have some dates
		if(empty($dates_min_max)) {
			$dates_min_max['min']['date'] = date('Y-m-d',(time() - (365 * 24 * 60 * 60))); // a year ago
			$dates_min_max['max']['date'] = date('Y-m-d');	// today
			} // if
		// do the other ,in formats
		$t = strtotime($dates_min_max['min']['date']);
		$dates_min_max['min']['iso'] = date('Y-m-d',$t);
		$dates_min_max['min']['time'] = $t;
		$dates_min_max['min']['local'] = cms_strftime('%x',$t);

		// do the other max formats
		$t = strtotime($dates_min_max['max']['date']);
		$dates_min_max['max']['iso'] = date('Y-m-d',$t);
		$dates_min_max['max']['time'] = $t;
		$dates_min_max['max']['local'] = cms_strftime('%x',$t);

		self::$dates_min_max = $dates_min_max;
		return $dates_min_max;
		} // get_transaction_dates_range()

	public function get_transactions_page_selector() {
		$this->get_DB_page_limits();
		$text = '';
		$text .= $this->get_DB_page_size_selector();
		$text .= '&nbsp;';
		$text .= $this->get_DB_page_selector();
		$text .= '<label title="Total transactions found.">Transactions: ' . $this->edit_DB_info['row_cnt'] . '.</label>';
		$text .= '<label title="First transaction."> Start: ' . self::$dates_min_max['min']['local'] . '.</label>';
		$text .= '<label title="Last transaction."> Finish: ' . self::$dates_min_max['max']['local'] . '.</label>';
		return $text;
		} // get_transactions_page_selector()

	public function get_transaction_orderby_select($action_uri,$orderby = false, $title = false) {
		if(empty($orderby)) $orderby = self::get_or_post ('orderby');
		if(empty($orderby)) $orderby = 'transaction_date';
		$orderbys = array(
			"transaction_date" => 'Transaction Date',
			"transaction_added" => 'Entry Date',
			);
		$text = array();
		$id = 'trans_orderby';
//		$text[] = '<form action="' . $action_uri . '" name="orderby_sel" method="post">';
		$text[] = '	<select id="' . $id . '"' .
			' name="orderby"' .
//			' onchange="this.form.submit();"' .
			($title ? ' title="' . $title . '"':'') .
			' REQUIRED>';
		$text[] = '		<option value="" selected disabled hidden>' . '- Select Order-' . '</option>';
		foreach($orderbys as $n => $t) {
			$text[] = '		<option value="' . $n . '"' . (($n == $orderby) ? ' SELECTED':'') . '>' . $t . '</option>';
			} // foreach
		$text[] = '	</select>';
//		$text[] = '</form>';
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // get_transaction_orderby_select()

	protected function get_accounts_where_cond($account_ids,$order_by,&$start_date,&$end_date) {
		$where = '';
		if($start_date > $end_date) {	//swap it
			$tmp = $start_date;
			$start_date = $end_date;
			$end_date = $tmp;
			} // if
		$this->get_transaction_dates_range($account_ids,$order_by);
		if(!empty(self::$dates_min_max['min']['date'])) {
			if((empty($start_date)) || ($start_date < self::$dates_min_max['min']['date']))
				$start_date = self::$dates_min_max['min']['date'];
			} // if
		if(!empty(self::$dates_min_max['max']['date'])) {
			if((empty($end_date)) || ($end_date > self::$dates_min_max['max']['date']))
				$end_date = self::$dates_min_max['max']['date'];
			} // if
		if(!empty($account_ids)) {
			if(!is_array($account_ids))
				$where = ' WHERE account_id = ' . (int)$account_ids . "\n";
			else{
				$w_sub = '';
				foreach($account_ids as $id) {
					if(!empty($w_sub)) $w_sub .= ' OR ';
					$w_sub .= ' account_id = ' . (int)$id;
					} // foreach
				$where = ' WHERE (' . $w_sub . ' )' . "\n";
				} // else
			} // if
		if(!empty($start_date)) {
			$ds = $order_by . ' >= "' . $start_date . '"';
			if(empty($where)) $where = ' WHERE ' . $ds . "\n";
			else $where .= ' AND ' . $ds . "\n";
			} // if
		if(!empty($end_date)) {
			$de = $order_by . ' <= "' . $end_date . '"';
			if(empty($where)) $where = ' WHERE ' . $de . "\n";
			else $where .= ' AND ' . $de . "\n";
			} // if
		return $where;
		} // get_accounts_where_cond()

	protected function get_value_class($type) {
		switch($type) {
		case 'number':
		case 'float':
		case 'double':
			$class = 'page_database_number';
			break;
		default:
			$class = 'page_database_text';	// default
			break;
			} //switch
		return $class;
		} // get_value_class()

	protected function get_accounts_sql(&$table, $account_ids, &$col_order, &$head, $order_by, $start_date, $end_date) {
		$head = array();
		$sel_cols = array();
		$limit = $this->get_DB_page_limits();
		$table_details = &$this->edit_DB_info['install_scripts'][$table];
		$signals = array();
		foreach($col_order as $h) {
			if(preg_match('/^_/',$h)) {	// calc signal
				$signals[] = $h;
				$head[$h] = array(
					'head' => $table_details['signals'][$h]['head'],	// head for calc signal
					'type' => '',
					'class' => '',
					);
				continue;
				} // if
			$v = &$table_details['edit']['columns'][$h];
			if(empty($v['head'])) continue;
			$type = $v['type'];
			$sel_cols[] = $h;
			$head[$h] = array(
				'head' => $v['head'],
				'type' => $type,
				'class' => $this->get_value_class($type),
				);
			} // foreach
		$need_cols = array(
			'transaction_id',
			'transaction_added',
			'transaction_updated',
			'transaction_date',
			'account_id',
			);
		foreach($need_cols as $h) {
			if(!in_array($h,$sel_cols))
				$sel_cols[] = $h;
			} // foreach
		$where = $this->get_accounts_where_cond($account_ids, $order_by, $start_date, $end_date);
		$sql = 'SELECT ' . "\n" .
			implode(',',$sel_cols) . "\n" .
			' FROM ' . $table . "\n" .
			$where;	// $table_details['edit']['row_id_name'];
		if($sql_res = $this->cEditDB->query($sql)) {		// get row count
			$this->edit_DB_info['row_cnt'] = $this->cEditDB->get_row_cnt($sql_res);	// copy to base
			} // if
		$sql .= ' ORDER BY ' . $order_by . ' ASC ' . "\n" .
			' ' . $limit;	// $table_details['edit']['row_id_name'];
		return $sql;
		} // get_accounts_sql()

	protected function calc_signal($col,&$row,&$table_details,&$account_ids,&$order_by,&$head) {
		$val = false;
		switch($col) {
		case '_running_balance':
			$amount = 0.00;	// default
			$sql = 'SELECT account_id, account_balance, transaction_id' .
				' FROM balances WHERE transaction_id = ' . $row['transaction_id'];
			if(($sql_res = $this->cEditDB->query($sql)) &&
				($bal = $this->cEditDB->fetch_array_assoc($sql_res)) &&
				(!empty($bal['account_balance']))) {
				$amount = $bal['account_balance'];
				} // if
			else {
				$this->balances_not_done = true;
				$sql = 'SELECT transaction_id, transaction_date' .
					' FROM transactions WHERE transaction_id = ' . $row['transaction_id'];
				if(($sql_res = $this->cEditDB->query($sql)) &&
					($bal = $this->cEditDB->fetch_array_assoc($sql_res)) &&
					(!empty($bal['transaction_id']))) {
					$amount = $bal['transaction_id'];
					} // if
				} // else
			if($this->running_balance === false) $this->running_balance = (float)$amount;
			else $this->running_balance += (float)$amount;
			$val = $this->format_number($this->running_balance);
			$head[$col]['type'] = 'float';
			$head[$col]['class'] = $this->get_value_class('float');
			break;
		default:
			return false;	// should not happen
			} // switch

		return $val;
		} // calc_signal()

	public function &get_accounts_ledgers($account_ids,&$order_by,&$start_date,&$end_date) {	// very similar to CSV export
		static $ledger = array();
		$table = 'transactions';
		$this->edit_DB_info['free_form'] = false;	// view only
		$js_func = '';
		if(empty($order_by)) $order_by = 'transaction_date';
		$table_details = &$this->edit_DB_info['install_scripts'][$table];
		$col_order = $table_details['ledger'];
		$head = false;
		$cnt = 0;
		$sql = $this->get_accounts_sql($table, $account_ids, $col_order, $head, $order_by, $start_date, $end_date);
		if($sql_res = $this->cEditDB->query($sql)) {
			$ledger['headings'] = $head;
			while($row = $this->cEditDB->fetch_array_assoc($sql_res)) {
				$data = array();
				$row_id = $row['transaction_id'];
				$data['transaction_id'] = $row['transaction_id'];
				foreach($col_order as $col) {
					if(preg_match('/^_/',$col)) {	// calc signal
						$data[$col] = $this->calc_signal($col,$row,$table_details,$account_ids,$order_by,$head);
						continue;
						} // if
					if(empty($row[$col])) continue;
					$v = &$table_details['edit']['columns'][$col];
					$data[$col] = $this->get_DB_form_elem($table_details,$col,$row_id,$v,$row,$js_func);
//					$data[$col] = $row[$col];	// save direct
//					if(isset($v['relation'])) {	// save relative
//						$rel = &$v['relation'];
//						if(is_array($rel['name']))
//							$rel_name = $rel['name'][0];
//						else
//							$rel_name = $rel['name'];
//						$data[$rel_name] = $this->cEditDB->get_data_in_table(
//							$rel['table'],$rel_name, $rel['id'] . ' = ' . (int)$row[$col]);
//						} // if
					} // foreach
				$ledger['data'][] = $data;
				$cnt++;
				} // while
			$ledger['table'] = $table;
			} // if
		if(!empty($table_details['ledger']))
			$ledger['show'] = $table_details['ledger'];
		else $ledger['show'] = array();
		$ledger['cnt'] = $cnt;
		$ledger['row_cnt'] = $this->edit_DB_info['row_cnt'];	// copy from base
		$ledger['balances_not_done'] = $this->balances_not_done;
		$this->edit_DB_info['row_cntr'] = $cnt;
		return $ledger;
		} // get_accounts_ledgers()

	public function &get_accounts_reports($account_ids,&$order_by,&$start_date,&$end_date) {	// very similar to CSV export
		static $reports = array();
		$table = 'transactions';
		$this->edit_DB_info['free_form'] = false;	// view only
		$js_func = '';
		if(empty($order_by)) $order_by = 'transaction_date';
		$table_details = &$this->edit_DB_info['install_scripts'][$table];
		$col_order = $table_details['reports'];
		$head = false;
		$cnt = 0;
		$sql = $this->get_accounts_sql($table, $account_ids, $col_order, $head, $order_by, $start_date, $end_date);
		if($sql_res = $this->cEditDB->query($sql)) {
			while($row = $this->cEditDB->fetch_array_assoc($sql_res)) {
				$data = array();
				$row_id = $row['transaction_id'];
				$data['transaction_id'] = $row['transaction_id'];
				foreach($col_order as $col) {
					if(preg_match('/^_/',$col)) {	// calc signal
						$data[$col] = $this->calc_signal($col,$row,$table_details,$account_ids,$order_by,$head);
						continue;
						} // if
					if(empty($row[$col])) continue;
					$v = &$table_details['edit']['columns'][$col];
					$data[$col] = $this->get_DB_form_elem($table_details,$col,$row_id,$v,$row,$js_func);
//					$data[$col] = $row[$col];	// save direct
//					if(isset($v['relation'])) {	// save relative
//						$rel = &$v['relation'];
//						if(is_array($rel['name']))
//							$rel_name = $rel['name'][0];
//						else
//							$rel_name = $rel['name'];
//						$data[$rel_name] = $this->cEditDB->get_data_in_table(
//							$rel['table'],$rel_name, $rel['id'] . ' = ' . (int)$row[$col]);
//						} // if
					} // foreach
				$reports['data'][] = $data;
				$cnt++;
				} // while
			$reports['headings'] = $head;
			$reports['table'] = $table;
			} // if
		if(!empty($table_details['reports']))
			$reports['show'] = $table_details['reports'];
		else $reports['show'] = array();
		$reports['cnt'] = $cnt;
		$reports['row_cnt'] = $this->edit_DB_info['row_cnt'];	// copy from base
		$reports['balances_not_done'] = $this->balances_not_done;
		$this->edit_DB_info['row_cntr'] = $cnt;
		return $reports;
		} // get_accounts_reports()

	protected function do_balances(&$bals_sums,&$data) {
		if(!empty($data['transaction_amount'])) {
			$bals_sums['balance'] += (float)$data['transaction_amount'];
			} // if
		$a_id = $data['account_id'];
		if(empty($bals_sums[$a_id]['balance'])) {
			$bals_sums[$a_id]['balance'] = 0.000;	// init
			} // if
		$bals_sums[$a_id]['balance'] += (float)$data['transaction_amount'];
		$data['running_balance'] = $bals_sums[$a_id]['balance'];
		return true;
		} // do_balances()

	public function &get_accounts_balance_summaries($account_ids,$column_ids,&$order_by,&$start_date,&$end_date) {	// very similar to CSV export
		$bals_sums = array();
		$table = 'transactions';
		if(empty($order_by)) $order_by = 'transaction_date';
		$table_details = &$this->edit_DB_info['install_scripts'][$table];
		if(!empty($column_ids)) $col_order = $column_ids;
		else $col_order = $table_details['summary'];
		$head = false;
		$cnt = 0;
		$sql = $this->get_accounts_sql($table, $account_ids, $col_order, $head, $order_by, $start_date, $end_date);
		if($sql_res = $this->cEditDB->query($sql)) {
			$bals_sums['balance'] = 0.000;
			$bals_sums['row_cnt'] = $this->cEditDB->get_row_cnt($sql_res);
			while($row = $this->cEditDB->fetch_array_assoc($sql_res)) {
				$data = array();
				$row_id = $row['transaction_id'];
				$data['transaction_id'] = $row['transaction_id'];
				$data['account_id'] = $row['account_id'];
				$this->do_balances($bals_sums,$row);	// do before the amounts get converted to fmtd str
				foreach($col_order as $col) {
					if(preg_match('/^_/',$col)) {	// calc signal
						$data[$col] = $this->calc_signal($col,$row,$table_details,$account_ids,$order_by,$head);
						continue;
						} // if
					if(empty($row[$col])) continue;
					$v = &$table_details['edit']['columns'][$col];
					$data[$col] = $this->get_DB_form_elem($table_details,$col,$row_id,$v,$row,$js_func);
					if(isset($v['relation'])) {	// save relative
						$rel = &$v['relation'];
						if(is_array($rel['name']))
							$rel_name = $rel['name'][0];
						else
							$rel_name = $rel['name'];
						$data[$rel_name] = $this->cEditDB->get_data_in_table(
							$rel['table'],$rel_name, $rel['id'] . ' = ' . (int)$row[$col]);
						} // if
					} // foreach
				$bals_sums['data'][] = $data;
				$bals_sums['account'][($data['account_id'])][] = $data;
				$cnt++;
				} // while
			$bals_sums['table'] = $table;
			$bals_sums['headings'] = $head;
			} // if
		if(!empty($table_details['summary']))
			$bals_sums['show'] = $table_details['summary'];
		else $bals_sums['show'] = array();
		$bals_sums['row_cnt'] = $this->edit_DB_info['row_cnt'];	// copy from base
		$bals_sums['fmtd_balance'] = $this->format_number($bals_sums['balance']);
		$bals_sums['balances_not_done'] = $this->balances_not_done;
		$bals_sums['cnt'] = $cnt;
		return $bals_sums;
		} // get_accounts_balance_summaries()

} // Cbook_keep_DB_edit

