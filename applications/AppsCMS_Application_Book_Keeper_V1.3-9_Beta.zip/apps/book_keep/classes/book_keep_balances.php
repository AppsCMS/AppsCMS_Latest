<?php

/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keep_balances.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

/**
 * Description of book_keep_balances
 * Used to run and calculate balances class.
 *
 * Usually run from a CRON job
 *
 * @author robert0609
 */
class Cbook_keep_balances extends Cbook_keep_app {

	protected static $csBK_DB = false;
	protected static $install_scripts = false;

	function __construct() {
		parent::__construct();
		self::$csBK_DB = self::$csBK_DB_edit->get_DB();
		self::$install_scripts = Cbook_keep_install::get_installDBscripts();
		$this->run_balances();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function out_stdio($msg) {
		if((!self::is_debug()) || (!self::is_cli())) return;
		echo $msg;
		} // out_stdio()

// dynamic methods

	protected function get_last_changed_transaction() {
		$trans_sql = 'SELECT' . "\n" .
			' t.transaction_id,t.transaction_date,t.transaction_added,t.transaction_updated' . "\n" .
			', b.balance_id,b.balance_added,b.balance_updated' . "\n" .
			' FROM transactions AS t, balances AS b' . "\n" .
			' WHERE' . "\n" .
					' t.transaction_id = b.transaction_id AND' . "\n" .
					' (' . "\n" .
					' (t.transaction_date < t.transaction_added) OR' ."\n" .
					' ((t.transaction_updated > 0) AND (t.transaction_date < t.transaction_updated))' . "\n" .
					' ) ' . "\n" .
			' ORDER BY t.transaction_added,t.transaction_updated DESC' . "\n" .
			' LIMIT 1;';
		if((!$trans_result = self::$csBK_DB->query($trans_sql)) ||
			(!$tran_last = self::$csBK_DB->fetch_array($trans_result))) {
			// not found
			return false;
			} // if

		$bal_sql = 'SELECT' . "\n" .
			' t.transaction_id,t.transaction_date,t.transaction_added,t.transaction_updated' . "\n" .
			', b.balance_id,b.balance_added,b.balance_updated' . "\n" .
			' FROM balances as b, transactions as t' . "\n" .
			' WHERE b.transaction_id = t.transaction_id ' . "\n" .
					' AND ( ' . "\n" .
					' (t.transaction_date < b.balance_added) OR' ."\n" .
					' ((b.balance_updated > 0) AND (t.transaction_date < b.balance_updated))' . "\n" .
					' )' . "\n" .
			' ORDER BY balance_updated,balance_added DESC' . "\n" .
			' LIMIT 1';
		if((!$bal_result = self::$csBK_DB->query($bal_sql)) ||
			(!$bal_last = self::$csBK_DB->fetch_array($bal_result))) {
			// not found
			return false;
			} // if
		return array('trans_last' => $tran_last, 'bals_last' => $bal_last);
		} // get_last_changed_transaction()

	public function calc_accounts_balances($balance_start_id = 0, $limit = 1000) {
		$bals_sums = array();
		$prev_data = array();
		$trans_tab_dets = &self::$install_scripts['transactions'];

		if(!empty($balance_start_id)) {	// set starting balances
			self::out_stdio(PHP_EOL . 'Getting balances fron balance id ' . $balance_start_id . PHP_EOL);
			$sql_last_bal = 'SELECT DISTINCT a.account_id' . "\n" .
				', b.balance_id,b.account_balance' . "\n" .
				' FROM balances AS b, accounts AS a' . "\n" .
				' WHERE a.account_id = b.account_id' . "\n" .
				' AND b.balance_id <= ' . (int)$balance_start_id . "\n" .
				' ORDER BY b.balance_id ASC';
			if($sql_last_bal_res = self::$csBK_DB->query($sql_last_bal)) {
				while($sql_last_bal_row = self::$csBK_DB->fetch_array_assoc($sql_last_bal_res)) {
					// start running balances
					$acct_id = $sql_last_bal_row['account_id'];
					$acct_balance = $sql_last_bal_row['account_balance'];
					$prev_data['accounts'][$acct_id]['balance'] = $acct_balance;
					} // while
				} // if
			} // if

		$start_time = time();
		self::out_stdio(PHP_EOL . 'Running balances: ' . date('Ymd-His') . PHP_EOL);
		$cnt = 0;
		$trans_sql = 'SELECT DISTINCT *' .
			' FROM transactions' .
			' WHERE transaction_id >= ' . (int)$balance_start_id .
			' ORDER BY transaction_date' .
			' LIMIT ' . $limit;
		if($trans_sql_res = self::$csBK_DB->query($trans_sql)) {
			while($trans_row = self::$csBK_DB->fetch_array_assoc($trans_sql_res)) {
				$trans_id = $trans_row['transaction_id'];
				$acct_id = $trans_row['account_id'];
				$amount = $trans_row['transaction_amount'];
				$bal_sql = 'SELECT DISTINCT *' .
					' FROM balances as b, transactions as t' .
					' WHERE t.transaction_id >= ' . (int)$trans_id . ' AND t.account_id = ' . (int)$acct_id .
					' ORDER BY t.transaction_date DESC' .
					' LIMIT 2';
				if(($bal_sql_res = self::$csBK_DB->query($bal_sql)) &&
					($bal_row = self::$csBK_DB->fetch_array_assoc($bal_sql_res))) {
					// have a balance row to update
					$action = 'update';
					$where = 'balance_id = ' . $bal_row['balance_id'];
					} // if
				else {
					// no balance row, create
					$action = 'insert';
					$where = '';
					} // else
				if(empty($prev_data['accounts'][$acct_id]['balance']))
					$acct_balance = $amount;
				else $acct_balance = $prev_data['accounts'][$acct_id]['balance'] + $amount;
				$fields = array(
					"transaction_id" => $trans_id,
//					"transaction_date" => $trans_row['transaction_date'],
//					"transaction_amount" => $amount,
					"account_id" => $acct_id,
					"account_balance" => $acct_balance,
					"currency_id" => $trans_row['currency_id'],
					);
				if(!self::$csBK_DB->perform('balances',$fields,$action,$where)){
					self::get_error_return_text('Failed to update balances.');
					return false;
					} // else
				// update running balances
				$prev_data['accounts'][$acct_id]['balance'] = $acct_balance;
				$cnt++;
				if(($cnt & 127) == 0) self::out_stdio("\r " . $cnt);
				} // while
			self::out_stdio("\r " . $cnt);	// last cnt
			} // if

		$bals_sums['cnt'] = $cnt;
		$bals_sums['accounts'] = $prev_data['accounts'];
		$end_time = time();
		self::out_stdio(PHP_EOL . 'Done.' . date('Ymd-His') . ', ' . ($end_time - $start_time) . ' seconds.' . PHP_EOL);
		return $bals_sums;
		} // calc_accounts_balances()

	public function run_balances() {
		self::log_msg('Start book keep balance run.','info');
		if(!self::$csBK_DB->is_ok()) {
			self::log_msg('Failed to access DB');
			return false;
			} // if

		$last_chgd = $this->get_last_changed_transaction();
		if(empty($last_chgd)) {	// no balances, start for oldest
			$this->calc_accounts_balances();
			} // if
		else $this->calc_accounts_balances($last_chgd['bals_last']['balance_id']);
		return true;
		} // run_balances()

} // Cbook_keep_balances
