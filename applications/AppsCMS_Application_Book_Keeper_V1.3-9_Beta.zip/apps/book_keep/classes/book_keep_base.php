<?php

/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keep_base.php 3365 2023-07-20 00:54:50Z robert0609 $
 */

/**
 * Description of book_keep_base
 * app base class.
 *
 * @author robert0609
 */
class Cbook_keep_base extends Ccms_app_base {

	protected static $csBK_DB_edit = false;

	private const SESS_BASE = 'BookKeep';

	function __construct() {
		parent::__construct();
		self::init();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

	public static function set_BK_session($value, ...$keys) {	// keep LT session data seperate
		if(empty($_SESSION)) return null;
		return self::setVar2DottedKeys($_SESSION[self::SESS_BASE],$keys,$value);
		} // set_BK_session()
		
	public static function get_BK_session(...$keys) {	// keep LT session data seperate
		if(empty($_SESSION[self::SESS_BASE])) return null;
		return self::getDottedKeys2Var($_SESSION[self::SESS_BASE], $keys);
		} // get_BK_session()
		
		
// dynamic methods

} // Cbook_keep_base
