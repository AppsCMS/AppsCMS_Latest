<?php

/*
 * see Book Keeper Licence in docs/LICENCE.txt
 * _SVN_build: $Id: book_keep_install.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

/**
 * Description of book_keep_install
 * Main app class.
 *
 * @author robert0609
 */
class Cbook_keep_install extends Cbook_keep_app {

	protected static $install_scripts = false;

	function __construct($create = false,$admin_user = '',$admin_passwd = '',$drop_tables = false) {

		if($create) {
			if(empty($admin_user)) {	// may not need a password ??
				self::addMsg('Missing DB admin user for "' . PL_BOOK_KEEP_MYSQL_HOST . '", not creating DB.');
				} // if
			else {
				if(!Ccms_database_mysql::install_user_privileges_database($admin_user,$admin_passwd,
						PL_BOOK_KEEP_MYSQL_USERNAME,PL_BOOK_KEEP_MYSQL_PASSWORD,PL_BOOK_KEEP_MYSQL_HOST,
						PL_BOOK_KEEP_MYSQL_DATABASE)) {
					self::addMsg('Failed to install MySQL database and user.');
					return;
					} // if
				if(!Ccms_database_mysql::install_user_privileges_database($admin_user,$admin_passwd,
						PL_BOOK_KEEP_MYSQL_USERNAME,PL_BOOK_KEEP_MYSQL_PASSWORD,PL_BOOK_KEEP_MYSQL_HOST,
						PL_BOOK_KEEP_MYSQL_DATABASE .Cbook_keep_plugin::get_debug_suffix())) {
					self::addMsg('Failed to install MySQL debug database and user.');
					return;
					} // if
				} // else
			} // if

		parent::__construct();
		if(!self::$csBK_DB_edit->is_ok()) return;
		self::$install_scripts = self::get_installDBscripts();
		self::$csBK_DB_edit->install_db_tables('', self::$install_scripts, true,$drop_tables);
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// dynamic methods

// static methods
	public static function &get_installDBscripts() {
		$install_scripts = array(	// multi tables, REMEMBER SQLITE DOES NOT THE SAME SQL SUITE AS MYSQL
			'accounts' => array(	// table name
				'drop' => 'false', // dont drop on table reload
//				'id' => 'account_id',	// row id column (optional)
//				'asc' => 'account_name',	// ASC sort column (optional)
				'columns' => array(
					"account_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"account_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"account_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"account_name" => "VARCHAR(128) NOT NULL UNIQUE",	// the account name
					"account_type" => "ENUM('cash','savings','cheque','credit','loan','super','tax') DEFAULT 'cash'",	// type of account
					"account_interest" => "FLOAT(16) DEFAULT 0.00",	// interest rate of account
					"account_opened" => "TIMESTAMP DEFAULT 0",	// date and time the account was closed
					"account_closed" => "TIMESTAMP DEFAULT 0",	// date and time the account was opened
					"account_description" => "TEXT DEFAULT ''",		// description
					"account_enabled" => "BOOLEAN DEFAULT 1",		// the enabled or disabled
					"account_institution_name" => "VARCHAR(128) DEFAULT ''",	// institution name
					"account_currency_id" => "INTEGER DEFAULT 1",
					"account_bsb" => "VARCHAR(16) DEFAULT 0",		// BSB
					"account_number" => "VARCHAR(32) DEFAULT 0",		// account number
					"account_manager" => "VARCHAR(64) DEFAULT ''",	// at institution
					"account_phone" => "VARCHAR(32) DEFAULT ''",	// for institution
					"account_email" => "VARCHAR(64) DEFAULT ''",	// for institution
					"account_url" => "VARCHAR(64) DEFAULT ''",		// for institution
					"PRIMARY KEY(account_id, account_name)",
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma seperate list, nil
				'functions' => array(
					// nil for now
					),
				'extras' => '',	// nil for now
				'data' => array(	// in the same order as the columns
					// nil for now
					),
				'edit' => array(
					'text' => 'Accounts',
					'row_id_name' => 'account_id',
					'order_by' => 'account_name ASC',
					'columns' => array(
						"account_name" => array('type' => 'text','head' => "Account Name", 'required' => true,),
						"account_description" => array('type' => 'text','head' => 'Description', 'required' => false,),
						"account_type" => array(
							'type' => 'enum',	// could use radio but this uses less space
							'head' => 'Type',
							'multiple' => true,	// multiple select drop box, value is a comma seperated list (use params to set size)
							'enum' => array('Cash','Savings','Cheque','Credit','Loan','Super','Tax'),	// options same order as table column values
							'inp_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
							'save_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
							'show_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value) returns the text to show
							'required' => true,
							),
						"account_enabled" => array('type' => 'checkbox','head' => "Enabled",),
						"account_institution_name" => array('type' => 'text','head' => "Institution Name", 'required' => true,),
						"account_currency_id" => array(
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Currency",
							'required' => true,
							'relation' => array(	// always a select
								'table' => 'currencies',
								'id' => 'currency_id',
								'name' => 'currency_code',
								'title' => 'currency_name',
								),
							),
						"account_interest" => array('type' => 'float','head' => "Interest Percent", 'params' => 'style="width: 5em;" step="0.001"',),
						"account_bsb" => array('type' => 'number','head' => "Account BSB", 'params' => 'min="10000" step="1" max="999999" style="width: 6em;"',),
						"account_number" => array('type' => 'number','head' => "Account Number", 'params' => 'style="width: 9em;"',),
						"account_manager" => array('type' => 'text','head' => "Account Manager",),
						"account_phone" => array('type' => 'mobile','head' => "Instituion Phone Number", 'params' => 'style="width: 10em;"',),
						"account_email" => array('type' => 'email','head' => "Instituition Email Address", 'params' => 'style="width: 12em;"',),
						"account_url" => array('type' => 'uri','head' => "Instituition Web Address", 'params' => 'style="width: 12em;"',),
						// all other columns not shown
						),
					),
				),
			'balances' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'columns' => array(
					"balance_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"balance_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"balance_updated" => "TIMESTAMP DEFAULT 0",		// date and time the row was updated
					"bal_amount_id" => "INTEGER NOT NULL",			// transaction row id
					"bal_date_id" => "INTEGER NOT NULL",			// transaction row id
					"account_id" => "INTEGER NOT NULL",
					"account_balance" => "DOUBLE NOT NULL",
					"currency_id" => "INTEGER NOT NULL",
					"transaction_id" => "INTEGER NOT NULL",			// @TODO check
					"PRIMARY KEY(balance_id)",
					),
				'edit' => array(
					'text' => 'Balances',
					'title' => 'Balances are updated by a CRON job (read only table).',
					'row_id_name' => 'balance_id',
					'order_by' => 'bal_amount_id DESC',
					'columns' => array(
//						"balance_id" => array('type' => 'show','head' => "Balance ID", 'readonly' => true,),			// the row id
//						"balance_added" => array('type' => 'show','head' => "Added", 'readonly' => true,),	// date and time the row was added
//						"balance_updated" => array('type' => 'show','head' => "Updated", 'readonly' => true,),	// date and time the row was updated
						"bal_amount_id" => array(
							'type' => 'show','head' => "Amount", 'readonly' => true,
							'relation' => array(	// always a select
								'table' => 'transactions',
								'id' => 'transaction_id',
								'name' => 'transaction_amount',
								),
							),			// the row id
						"bal_date_id" => array(
							'type' => 'show','head' => "Amount", 'readonly' => true,
							'relation' => array(	// always a select
								'table' => 'transactions',
								'id' => 'transaction_id',
								'name' => 'transaction_date',
								),
							),			// the row id
						"account_id" => array(	// column edited
							'type' => 'show',	// this type of select is always an ajax driven select
							'head' => "Account",
							'readonly' => true,
							'inp_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
							'save_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
							'show_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value) returns the text to show
							'relation' => array(	// always a select
								'table' => 'accounts',
								'id' => 'account_id',
								'name' => 'account_name',
								),
							),
						"account_balance" => array('type' => 'show','head' => "Account Balance", 'readonly' => true,),
						"currency_id" => array(
							'type' => 'show',	// this type of select is always an ajax driven select
							'head' => "Currency",
							'readonly' => true,
							'relation' => array(	// always a select
								'table' => 'currencies',
								'id' => 'currency_id',
								'name' => 'currency_code',
								'title' => 'currency_name',
								),
							),
						// all other columns not shown
						),
					),
				),
			'currencies' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'columns' => array(
					"currency_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"currency_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"currency_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"currency_name" => "VARCHAR(64) NOT NULL UNIQUE",						// the user name
					"currency_code" => "VARCHAR(16) NOT NULL UNIQUE",		// the code e.g. usd, aud, etc.
					"currency_enabled" => "BOOLEAN DEFAULT 1",		// the user enabled or disabled
					"currency_conversion" => "DOUBLE NOT NULL",		// the conversion factor against the primary currency
					"PRIMARY KEY(currency_id, currency_name)",
					),
				'data' => array(	// in the same order as the columns
					// must be same order as columns
					array(
						1,	// first index
						"CURRENT_TIMESTAMP",
						"CURRENT_TIMESTAMP",
						"'Australian Dollar'",
						"'AUD'",
						1,
						1.00000000000,
						),	// row data
					),
				'edit' => array(
					'text' => 'Currencies',
					'row_id_name' => 'currency_id',
					'order_by' => 'currency_name ASC',
					'columns' => array(
						"currency_name" => array('type' => 'text','head' => "Name", 'required' => true,),
						"currency_code" => array('type' => 'text','head' => 'Code', 'required' => true,),
						"currency_enabled" => array('type' => 'checkbox','head' => "Enabled",),
						"currency_conversion" => array('type' => 'float','head' => "Conversion", 'params' => 'style="width: 5em;" step="0.001"', 'required' => true,),
						// all other columns not shown
						),
					),
				),
			'payees' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'columns' => array(
					"payee_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"payee_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"payee_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"payee_name" => "VARCHAR(128) NOT NULL UNIQUE",						// the user name
					"payee_description" => "TEXT DEFAULT ''",		// description
					"payee_enabled" => "BOOLEAN DEFAULT 1",		// the user enabled or disabled
					"payee_bsb" => "VARCHAR(16) DEFAULT ''",		// BSB
					"payee_number" => "VARCHAR(32) DEFAULT ''",		// payee number
					"payee_contact" => "VARCHAR(64) DEFAULT ''",	// at institution
					"payee_phone" => "VARCHAR(32) DEFAULT ''",	// for institution
					"payee_email" => "VARCHAR(32) DEFAULT ''",	// for institution
					"payee_url" => "VARCHAR(64) DEFAULT ''",		// for institution
					"PRIMARY KEY(payee_id, payee_name)",
					),
				'edit' => array(
					'text' => 'Payees',
					'row_id_name' => 'payee_id',
					'order_by' => 'payee_name ASC',
					'columns' => array(
						"payee_name" => array('type' => 'text','head' => "Name", 'required' => true,),
						"payee_description" => array('type' => 'text','head' => 'Description', 'required' => true,),
						"payee_enabled" => array('type' => 'checkbox','head' => "Enabled",),
						"payee_bsb" => array('type' => 'number','head' => "BSB", 'params' => 'min="10000" step="1" max="999999" style="width: 6em;"',),
						"payee_number" => array('type' => 'number','head' => "Account Number", 'params' => 'style="width: 9em;"',),
						"payee_contact" => array('type' => 'text','head' => "Contact",),
						"payee_phone" => array('type' => 'mobile','head' => "Phone Number", 'params' => 'style="width: 10em;"',),
						"payee_email" => array('type' => 'email','head' => "Email Address", 'params' => 'style="width: 12em;"',),
						"payee_url" => array('type' => 'uri','head' => "Web Address", 'params' => 'style="width: 12em;"',),
						// all other columns not shown
						),
					),
				),
			'categories' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'columns' => array(
					"category_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"category_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"category_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"category_name" => "VARCHAR(128) NOT NULL UNIQUE",						// the user name
					"category_description" => "TEXT DEFAULT ''",		// description
					"category_enabled" => "BOOLEAN DEFAULT 1",		// the user enabled or disabled
					"PRIMARY KEY(category_id, category_name)",
					),
				'edit' => array(
					'text' => 'Categories',
					'row_id_name' => 'category_id',
					'order_by' => 'category_name ASC',
					'multiple' => false,	// multiple select drop box, value is a comma seperated list (use params to set size)
					'columns' => array(
						"category_name" => array('type' => 'text','head' => "Name", 'required' => true,),
						"category_enabled" => array('type' => 'checkbox','head' => "Enabled",),
						"category_description" => array('type' => 'text','head' => "Description",),
						// all other columns not shown
						),
					),
				),
			'receipts' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'columns' => array(
					"receipt_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"receipt_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"receipt_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"receipt_name" => "VARCHAR(128) NOT NULL UNIQUE",						// the user name
					"receipt_description" => "TEXT DEFAULT ''",		// description
					"receipt_enabled" => "BOOLEAN DEFAULT 1",		// the user enabled or disabled
					"PRIMARY KEY(receipt_id, receipt_name)",
					),
				'edit' => array(
					'text' => 'Receipts',
					'row_id_name' => 'receipt_id',
					'order_by' => 'receipt_name ASC',
					'columns' => array(
						"receipt_name" => array('type' => 'text','head' => "Name", 'required' => true,),
						"receipt_enabled" => array('type' => 'checkbox','head' => "Enabled",),
						"receipt_description" => array('type' => 'text','head' => "Description",),
						// all other columns not shown
						),
					),
				),
			'projects' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'columns' => array(
					"project_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"project_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"project_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"project_name" => "VARCHAR(128) NOT NULL UNIQUE",						// the user name
					"project_description" => "TEXT DEFAULT ''",		// description
					"project_enabled" => "BOOLEAN DEFAULT 1",		// the user enabled or disabled
					"PRIMARY KEY(project_id, project_name)",
					),
				'edit' => array(
					'text' => 'Projects',
					'row_id_name' => 'project_id',
					'multiple' => true,	// multiple select drop box, value is a comma seperated list (use params to set size)
					'order_by' => 'project_name ASC',
					'columns' => array(
						"project_name" => array('type' => 'text','head' => "Name", 'required' => true,),
						"project_enabled" => array('type' => 'checkbox','head' => "Enabled",),
						"project_description" => array('type' => 'text','head' => "Description",),
						// all other columns not shown
						),
					),
				),
			'transactions' => array(	// table name
				'drop' => 'false', // dont drop on table reload
//				'id' => 'transaction_id',	// row id column (optional)
//				'asc' => 'transaction_date,transaction_amount',	// ASC sort column (optional)
				'columns' => array(
					"transaction_id" => "INTEGER NOT NULL AUTO_INCREMENT",			// the row id
					"transaction_added" => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",	// date and time the row was added
					"transaction_updated" => "TIMESTAMP DEFAULT 0",	// date and time the row was updated
					"account_id" => "INTEGER NOT NULL",
					'payee_id' => 'INTEGER NOT NULL',
					"currency_id" => "INTEGER DEFAULT 1",
					"category_id" => "INTEGER NOT NULL",
					"receipt_id" => "INTEGER NOT NULL",
					"project_id" => "INTEGER NOT NULL",
					"transaction_type" => "VARCHAR(16) DEFAULT ''",
					"transaction_date" => "TIMESTAMP DEFAULT 0",
					"transaction_memo" => "TEXT DEFAULT ''",
					"transaction_amount" => "DOUBLE NOT NULL",
					"transaction_status" => "ENUM('ENTERED','CLEARED','RECONCILED') DEFAULT 'ENTERED'",
					"PRIMARY KEY(transaction_id, transaction_date)",
					),
				'edit' => array(
					'text' => 'Transactions',
					'row_id_name' => 'transaction_id',
					'order_by' => 'transaction_date DESC',
					'columns' => array(
						"transaction_id" => array('type' => 'show','head' => "ID", 'readonly' => true,),			// the row id
						"transaction_added" => array(
							'type' => 'show',
							'head' => "Added",
							'readonly' => true,
							'show_func' => 'Cbook_keep_DB_edit::check_DB_timestamp2show',	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value) returns the text to show
							),	// date and time the row was added
						"transaction_updated" => array(
							'type' => 'show',
							'head' => "Updated",
							'readonly' => true,
							'show_func' => 'Cbook_keep_DB_edit::check_DB_timestamp2show',	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value) returns the text to show
							),	// date and time the row was updated
						"transaction_type" => array(
							'type' => 'enum','head' => "Type", 'required' => false,
							"keys" => array('cash' => 'Cash', 'eft' => 'EFT', 'cc' => 'CC', 'visa' => 'Visa', 'mc' => 'MC', 'income' => 'Income','transfer' => 'Transfer',),
							'params' => '',),
						"transaction_date" => array('type' => 'date','head' => "Date", 'required' => true,),
						"transaction_memo" => array('type' => 'text','head' => "Memo", 'required' => false,),
						"transaction_amount" => array('type' => 'float','head' => "Amount", 'required' => true, 'params' => 'step="0.01"',),
						"account_id" => array(	// column edited
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Account",
							'required' => true,
							'inp_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
							'save_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
							'show_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value) returns the text to show
							'relation' => array(	// always a select
								'table' => 'accounts',
								'id' => 'account_id',
								'name' => 'account_name',
								),
							),
						"transaction_status" => array(
							'type' => 'enum','head' => "Status", 'required' => false,
							"keys" => array('ENTERED' => '', 'CLEARED' => 'C', 'RECONCILED' => 'R',),
							'params' => '',),
						"payee_id" => array(
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Payee",
							'required' => true,
							'multiple' => false,	// multiple select drop box, value is a comma seperated list (use params to set size)
							'inp_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name,$column_value,$js_func,$extras,$parent_obj) returns text to include the output form
							'save_func' => false,	// overrides 'type' and 'relation', a 'class::method' or a 'global_function', paramters are ($column_name) returns the value from posted form
							'show_func' => false,	// 'class::method' or a 'global_function', paramters are ($column_name,$col_info,$column_value) returns the text to show
							'relation' => array(	// always a select
								'table' => 'payees',
								'id' => 'payee_id',
								'name' => 'payee_name',
								),
							),
						"currency_id" => array(
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Currency",
							'relation' => array(	// always a select
								'table' => 'currencies',
								'id' => 'currency_id',
								'name' => 'currency_code',
								'title' => 'currency_name',
								),
							),
						"category_id" => array(
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Category",
							'required' => true,
							'relation' => array(	// always a select
								'table' => 'categories',
								'id' => 'category_id',
								'name' => 'category_name',
								),
							),
						"receipt_id" => array(
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Receipt",
							'relation' => array(	// always a select
								'table' => 'receipts',
								'id' => 'receipt_id',
								'name' => 'receipt_name',
								),
							),
						"project_id" => array(
							'type' => 'select',	// this type of select is always an ajax driven select
							'head' => "Project",
							'relation' => array(	// always a select
								'table' => 'projects',
								'id' => 'project_id',
								'name' => 'project_name',
								),
							),
						// all other columns not shown
						),
					),
				'ledger' => array(	// an extra for filtering book keeper ledger columns in display order
					"transaction_type",
					"transaction_date",
					"account_id",
					"transaction_amount",
					"currency_id",
					'payee_id',
					"transaction_memo",
					"transaction_status",
					"category_id",
					"receipt_id",
					"project_id",
					),
				'reports' => array(	// an extra for filtering book keeper reports columns in display order
					"transaction_type",
					"transaction_date",
					"account_id",
					"transaction_amount",
					"_running_balance",	// using the underscore prefix as signal
					"currency_id",
					'payee_id',
					"transaction_memo",
					"transaction_status",
					"category_id",
					"receipt_id",
					"project_id",
					),
				'summary' => array(	// an extra for filtering book keeper reports columns in display order
					"transaction_type",
					"transaction_date",
					"account_id",
					"transaction_amount",
					"_running_balance",	// using the underscore prefix as signal
					"currency_id",
					'payee_id',
					"transaction_memo",
					"transaction_status",
					"category_id",
					"receipt_id",
					"project_id",
					),
				'signals' => array(	// using the underscore prefix as signal
					"_running_balance" => array(
						'type' => 'float',
						'head' => "Balance",
						),
					),
				),
			);
		return $install_scripts;
		} // get_installDBscripts()

	public static function get_table2query_audits() {
		return array(
			'accounts' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET account_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				'log_query' => true,
				),
			'currencies' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET currency_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				),
			'payees' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET payee_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				),
			'categories' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET category_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				'log_query' => true,
				),
//			'category_groups' => array(	// table name
//				'update' => array(
//					"sql" => "UPDATE \$table SET category_group_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
//					),
//				),
			'receipts' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET receipt_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				'log_query' => true,
				),
//			'receipt_groups' => array(	// table name
//				'update' => array(
//					"sql" => "UPDATE \$table SET receipt_group_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
//					),
//				),
			'projects' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET project_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				'log_query' => true,
				),
//			'project_groups' => array(	// table name
//				'update' => array(
//					"sql" => "UPDATE \$table SET project_group_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
//					),
//				),
			'transactions' => array(	// table name
				'update' => array(
					"sql" => "UPDATE \$table SET transaction_update = CURRENT_TIMESTAMP WHERE \$where",	// date and time the row was updated
					),
				'log_query' => true,
				),
			);

		} // table2query_audits()

} // Cbook_keep_install
