<?php
/*
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: book_keeper_body.php 3045 2022-12-15 02:08:14Z robert0609 $
 */
if(!defined('APPs_FS_BOOK_KEEP_DIR')) return;

include (APPs_FS_BOOK_KEEP_DIR . 'book_keeper.php');