<?php

/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: book_keep.php 2985 2022-11-14 03:22:23Z robert0609 $
 */

/**
 * Description of book_keep_plugin
 * Main app config / plugin class.
 *
 * @author robert0609
 */
class Cbook_keep_plugin extends Ccms_plugin_base {

	const PLUGIN = 'book_keep';
	const DEBUG_SUFFIX = '_DEBUG';
	const APP_NAME = 'book_keep';

	protected static $admin_uris = false;	// time saver
	protected static $menu_uris = false;	// time saver

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function get_currencies($name,$value) {
		$text = array();
		$text[] = $value;
		return PHP_EOL. implode(PHP_EOL,$text) . PHP_EOL;
		} // get_currencies()

// dynamic methods
	public static function is_enabled() {	// required function, check plugin enabled
		if(!self::is_plugin_enabled(self::PLUGIN)) {
			if(Ccms_auth::is_cms_admin_user()) self::addMsg(self::PLUGIN . ' plugin is disabled.');
			return false;
			} // if
		return true;	// enabled
		} // is_enabled()

	public static function get_title() {	// get the plugin title
		return 'Book Keep Finacial Ledger Plugin.';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The Book Keeper plugin (' . self::PLUGIN . ') description. A financial ledger and book keeping application plugin.';
		} // get_description()

	private static function apps_ext_init() {	// just for uniformity
		// setup app extension data
		// nothing todo, just return
		} // apps_ext_init()

	protected static function read_app_settings_ini() {
		// the return value is mainly used for config searchs
		self::apps_ext_init();
		return array(	// must be in the same order as the idx= param
			);
		} // read_app_settings_ini()

	protected static function read_app_comments_ini() {
		// the return value is mainly used for config searchs
		self::apps_ext_init();
		return array(	// must be in the same order as the idx= param
			);
		} // read_app_comments_ini()

	public static function get_admin_uris() {	// refer to index.php?cms_action=cms_manual#AppsExtendPlugin
		if(self::$admin_uris !== false) return self::$admin_uris;	// already done, time saver
		self::$admin_uris = array(
			'app_name' => self::APP_NAME,
//			'app_dir' => self::lookup_body_dir(self::APP_NAME),
//			'app_uri' => self::lookup_body_url(self::APP_NAME),
			);
		self::$admin_uris[] = array(
			'role' => 'manager',
			'text' => 'Initialize DB',
			'func' => 'Cbook_keep_plugin::init_DB()',
			'title' => 'Initialize or rebuild database.',
			);
		self::$admin_uris[] = array(
			'role' => 'manager',
			'text' => 'Import Data',
			'func' => 'Cbook_keep_plugin::get_import_money_data()',
			'title' => 'Import MS Money data.',
			);
		return self::$admin_uris;
		} // get_admin_uris()

	public static function 	get_menu_uris() {	// refer to index.php?cms_action=cms_manual#AppsExtendPlugin
		if(self::$menu_uris !== false) return self::$menu_uris;	// already done, time saver
		$uri = Ccms::get_body_uri(self::APP_NAME);

		self::$menu_uris = array(
			'app_name' => self::APP_NAME,
//			'app_dir' => self::lookup_body_dir(self::APP_NAME),
//			'app_uri' => self::lookup_body_url(self::APP_NAME),
			);
		self::$menu_uris[] = array(
			'role' => 'manager',
			'text' => 'Ledger',
			'uri' => $uri . '&book_keep_op=ledger',
			'title' => 'Accounts ledger.',
			);
		self::$menu_uris[] = array(
			'role' => 'manager',
			'text' => 'Edit Data',
			'uri' => $uri . '&book_keep_op=edit_db',
			'title' => 'Edit transactions.',
			);
		self::$menu_uris[] = array(
			'role' => 'manager',
			'text' => 'Reports',
			'uri' => $uri . '&book_keep_op=reports',
			'title' => 'Generate reports.',
			);
		self::$menu_uris[] = array(
			'role' => 'manager',
			'text' => 'Ledger',
			'uri' => $uri . '&book_keep_op=summary',
			'title' => 'Accounts summary.',
			);

		return self::$menu_uris;
		} // get_menu_uris()

	public static function get_apps_extend_settings() {
		// typically uses the Ccms_edit class
		return true;
		} // get_apps_extend_settings()

	public static function init_DB() {
		$body = self::lookup_body(self::APP_NAME);
		$action_uri = self::lookup_body_url($body);
		if(!empty($_SERVER['QUERY_STRING']))
			$action_uri .= '&' . $_SERVER['QUERY_STRING'];
		$bid = self::getDottedKeys2Var($body,'cms_body_id');;
		$version = Ccms::get_body_version($body);
		$logo = Ccms::get_body_logo_uri('bk_logo',$body,'BK Logo');
		$host = PL_BOOK_KEEP_MYSQL_HOST;
		$db = PL_BOOK_KEEP_MYSQL_DATABASE;
		$admin_user = self::get_or_post('admin_user');
		$admin_password = self::get_or_post('admin_password');
		$drop_tables = self::get_or_post_checkbox('drop_tables');
		$drop_chkd = ($drop_tables ? ' CHECKED':'');

		Ccms::page_start_comment(__FILE__);
		echo <<< EOFTXT

	<table class="page_body">
		<tr class="page_body">
			<th class="page_body">
				{$logo}
				<h1 style="white-space: normal;">Book Keeper ({$version})</h1>
			</th>
		</tr>
		<tr class="page_body">
			<td class="page_body">
				<h2>Initialize DB: {$db}, on Host: {$host}</h2>
			</td>
		</tr>

EOFTXT;

		if(self::get_or_post('create_db') == 'create_db') {
			echo <<< EOFTXT3

		<tr class="page_body">
			<td class="page_body">
				<div style="border: 2px solid gray; border-radius: 5px; padding: 5px;">
					<p style="font-weight: bold; text-decoration: underline;">Database Results:</p>
					<br>

EOFTXT3;

			if(empty($admin_user)) {
				$cBK_DBi = new Cbook_keep_install(false,'','',$drop_tables);
				} // if
			else $cBK_DBi = new Cbook_keep_install(true,$admin_user,$admin_password,$drop_tables);
			echo <<< EOFTXT4

				</div>
			</td>
		</tr>

EOFTXT4;

			} // if

		echo <<< EOFTXT2

		<tr class="page_body">
			<td class="page_body">
				<form action="{$action_uri}" method="post" onsubmit="if(confirm('Are you sure you to want initalise DB.')) { Ccms_cursor.setWait(); return true; } else return false;">
					<input type="hidden" name="bodyi" value="{$bid}">
					<input type="hidden" value="create_db" name="create_db">
					<div style="border: 2px solid gray; border-radius: 5px; padding: 5px;">
						<p>To add the configured database privileges for the new database, database user, database password:<br>enter database server admin username and admin password. And click Create ...</p>
						<label>Admin User:<input type="text" name="admin_user" value="{$admin_user}" title="Enter admin username to create the database from empty."/></label>
						<label>Admin Password:
							<input type="password" name="admin_password" value="{$admin_password}" id="myPW"
								title="Enter admin password to create the database from empty."/>
							<input type="checkbox" onclick="togPW('myPW')">Show Password
						</label>
						<script type="text/javascript">
							function togPW(id) {
								var x = document.getElementById(id);
								if (x.type === "password") x.type = "text";
								else x.type = "password";
								} // togPW()
						</script>
					</div>
					<br>
					<div style="border: 2px solid gray; border-radius: 5px; padding: 5px;">
						<p style="font-weight: bold; text-decoration: underline;">Database operations.</p>
						<label>Drop Tables:<input type="checkbox" name="drop_tables" title="Drop existing tables."{$drop_chkd}/></label>
						<label><button type="submit" title="Click to create or update existing database.">Build Database</button></label>
					</div>
					<br>
				</form>
			</td>
		</tr>
	</table>

EOFTXT2;
		echo self::getMsgsStack();
		Ccms::page_end_comment(__FILE__);
		} // init_DB()

	public static function get_import_money_data() {

		$body = self::lookup_body(self::APP_NAME);
		$bid = self::getDottedKeys2Var($body,'cms_body_id');;
		$action_uri = self::lookup_body_url($body);
		if(!empty($_SERVER['QUERY_STRING']))
			$action_uri .= '&' . $_SERVER['QUERY_STRING'];
		$version = Ccms::get_body_version($body);
		$logo = Ccms::get_body_logo_uri('bk_logo',$body,'BK Logo');

		Ccms::page_start_comment(__FILE__);
		echo <<< EOFTXT

	<table class="page_body">
		<tr class="page_body">
			<th class="page_body">
				{$logo}
				<h1 style="white-space: normal;">Book Keeper ({$version})</h1>
			</th>
		</tr>
		<tr class="page_body">
			<td class="page_body">
				<h2>Data Import:</h2>
			</td>
		</tr>
EOFTXT;

		if((self::get_or_post('import_mny') == 'import_mny') &&
			(isset($_FILES['mny_file']))) {
			echo <<< EOFTXT3

		<tr class="page_body">
			<td class="page_body">
				<div style="border: 2px solid gray; border-radius: 5px; padding: 5px;">
					<p style="font-weight: bold; text-decoration: underline;">MS Money 2000 Import Results:</p>

EOFTXT3;

			$destpath = VAR_FS_TEMP_DIR;
			if($dest = self::save_uploaded_file($destpath, 'mny_file', true)) {
				$cBK_IMP = new Cbook_keep_import();
				$cBK_IMP->import_MSM2000_txt_file($dest);
				} // if
			echo <<< EOFTXT4

				</div>
			</td>
		</tr>

EOFTXT4;

			} // if

		echo <<< EOFTXT2

		<tr class="page_body">
			<td class="page_body">
				<form action="{$action_uri}" method="post" onsubmit="if(confirm('Are you sure you want import MS Money data.')) { Ccms_cursor.setWait(); return true; } else return false;" enctype="multipart/form-data">
					<input type="hidden" name="body" value="{$bid}">
					<div style="border: 2px solid gray; border-radius: 5px; padding: 5px;">
						<p style="font-weight: bold; text-decoration: underline;">Import MS Money 2000 CSV data:</p>
						<input type="hidden" value="import_mny" name="import_mny">
						<label title="Select the exported money text file containing the transactions.">
							Browse to MNY Export file: <input type="file" name="mny_file" accept=".txt,.csv">
						</label>
						<label>
							<button type="submit">Import Money File</button>
						</label>
					</div>
					<br>
				</form>
			</td>
		</tr>
	</table>

EOFTXT2;
		echo self::getMsgsStack();
		Ccms::page_end_comment(__FILE__);
		} // get_import_money_data()

	public static function get_debug_suffix() { return self::DEBUG_SUFFIX; }

	protected static function get_sql_install_data() {
		if(!defined('APPs_WS_BOOK_KEEP_CLI_DIR')) {	// rebuild or recovering from errors
			$dir = basename(dirname(__DIR__)) . '/cli';
			define('APPs_WS_BOOK_KEEP_CLI_DIR', $dir);
			} // if
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "MYSQL_HOST",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "localhost",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL Host.",
				'cms_config_description' => "Enter the MySQL book keep database hostname.",
				),	// row data
			array(
				'cms_config_key' => "MYSQL_DATABASE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "book_keep_app",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL Database.",
				'cms_config_description' => "Enter the MySQL book keep database name.<br>The debug database name is suffixed by " . self::DEBUG_SUFFIX . ".<br>IMPORTANT NOTE: Use underscore instead of punctuation (e.g. dots, spaces, etc.).",
				),	// row data
			array(
				'cms_config_key' => "MYSQL_USERNAME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "book_keep",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL Username.",
				'cms_config_description' => "Enter the MySQL book keep database username.",
				),	// row data
			array(
				'cms_config_key' => "MYSQL_PASSWORD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "book_keep",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL Password.",
				'cms_config_description' => "Enter the MySQL book keep database password.",
				),	// row data
			array(
				'cms_config_key' => "MYSQL_USE_SSL_BOOL",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "false",
				'cms_config_allowed_values' => "false:true",
				'cms_config_name' => "Book Keep MySQL Use SSL Connection.",
				'cms_config_description' => "true = use SSL MySQL mode, false = SSL disabled.<br>" .
							"NOTE: To allow the SSL to work; edit the " . APPs_WS_BOOK_KEEP_CLI_DIR. "openssl.Book_Keep_MySQL.conf to your DB requirements.<br>" .
							"Then run " . APPs_WS_BOOK_KEEP_CLI_DIR . "genSslSelfSignedKeys.sh script to generate self signed SSL certs.<br>" .
							"If SSL certificates are available, copy then to the " . ETC_WS_SSL_INCLUDES_DIR . " directory.",
				),	// row data
			array(
				'cms_config_key' => "MYSQL_SSL_KEY",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL SSL Private Key.",
				'cms_config_description' => "SSL key pem filepath (relative to (DOCROOT)).",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_ssl_file',
				'cms_config_save_func' => '',
				),	// row data
			array(
				'cms_config_key' => "MYSQL_SSL_CERT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL SSL Certificate.",
				'cms_config_description' => "SSL certificate pem filepath (relative to (DOCROOT)).",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_ssl_file',
				'cms_config_save_func' => '',
				),	// row data
			array(
				'cms_config_key' => "MYSQL_SSL_CA",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Book Keep MySQL SSL CA.",
				'cms_config_description' => "SSL cerfiticate authority filepath (relative to (DOCROOT)).",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_ssl_file',
				'cms_config_save_func' => '',
				),	// row data
			array(
				'cms_config_key' => "PRIMARY_CURRENCY",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "AUD",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Primary Currency.",
				'cms_config_description' => "Enter the code for the primary currency.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'Cbook_keep_plugin::get_currencies',
				'cms_config_save_func' => '',
				),	// row data
			array(
				'cms_config_key' => "CURRENCY_URL",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Currency Rates URL.",
				'cms_config_description' => "Enter the URL for curreny rates.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => 'get_url',
				),	// row data
			array(
				'cms_config_key' => "CURRENCY_URL_BASE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "EUR",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Base Currency Rates for URL.",
				'cms_config_description' => "Enter the base currency for the curreny rates (often not listed).",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => 'get_url',
				),	// row data
			array(
				'cms_config_key' => "CURRENCY_USE_LOCALE_FORMAT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Use Currency Locale Display.",
				'cms_config_description' => "true = format currency display using the international locale (e.g. -AUD10.00), false = use national currency format (e.g. -$10.00).",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Cbook_keep_plugin
