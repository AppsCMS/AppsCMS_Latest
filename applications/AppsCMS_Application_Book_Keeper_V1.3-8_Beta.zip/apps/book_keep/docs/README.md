AppsCMS Application - Book Keeper Ledger - README
=================================================
see Book Keeper Licence in LICENCE.txt
<!-- _SVN_build: $Id: README.md 2786 2022-08-31 05:40:44Z robert0609 $ -->

Book Keeper Ledger is a simple application for AppsCMS.

It is not much more than a basic database manipulation application.

Its original purpose was to be used to check and debug the DB applications database
code provided by the AppsCMS. A financial book keeping application was chosen because it
does not need anything more than a set of transactions and no other external input.

A unique feature is that the application can import MS Money 2000 data from exported text files
with the Cbook_keep_import::import_MSM2000_txt_file() method. This was used as the large data set
to test the application.

Released under the BSD 3-Clause-Clear License.

.EOF.
