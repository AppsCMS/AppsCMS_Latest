<?php
/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: book_keeper_manual.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

?>
<?= Ccms::get_body_logo_uri('bk_logo') ?>
<h1>Book Keeper Manual (<?= Ccms::get_body_version('book_keep') ?>)</h1>

<p>To be written.</p>

