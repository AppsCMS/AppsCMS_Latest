#!/bin/bash
# Book Keeper Application
# see Book Keeper Licence in LICENCE.txt
# _SVN_build: $Id: book_keep_cron.sh 3052 2022-12-16 09:01:07Z robert0609 $
# CRON called for book keeping

FVERSION="V.10"
LOG=var/logs/cron/log
./book_keep_balances.sh >> "$LOG"
exit 0

