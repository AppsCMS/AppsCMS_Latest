#!/bin/bash

FVERSION=V0.1
DB=book_keep_app_DEBUG
HOST=localhost
USER=book_keep
PASSWD=book_keep

if [ -z "$1" ]; then
	echo "USAGE: $(basename $0) sql_query"
	exit 1
fi

echo "$(basename $0) $1 ($FVERSION)"
echo "mysql --host=$HOST --user=$USER --password=$PASSWD --execute \"$1\" $DB"
mysql --host=$HOST --user=$USER --password=$PASSWD \
	--execute "$1" \
	$DB

# EOF
