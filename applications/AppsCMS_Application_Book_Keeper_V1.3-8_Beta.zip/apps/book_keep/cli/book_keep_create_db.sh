#!/bin/bash
# Book Keeper Application
# see Book Keeper Licence in LICENCE.txt
# _SVN_build: $Id: book_keep_create_db.sh 3052 2022-12-16 09:01:07Z robert0609 $
# call by CRON

# Don't output text, save tit in the logs

FVERSION="V.12"

DIR="$(dirname "$0")"
php "${DIR}/book_keep_create_db.php"

exit 0

