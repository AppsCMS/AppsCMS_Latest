<?php
/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: book_keep_create_db.php 2987 2022-11-15 01:51:39Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure not to crash

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$admin_user = (empty($argv[1]) ? false:$argv[1]);
$admin_passwd = (empty($argv[2]) ? false:$argv[2]);
$db_user = PL_BOOK_KEEP_MYSQL_USERNAME;
$db_password = PL_BOOK_KEEP_MYSQL_PASSWORD;
$db_host = PL_BOOK_KEEP_MYSQL_HOST;
$db_name = PL_BOOK_KEEP_MYSQL_DATABASE;
$db_name_debug = PL_BOOK_KEEP_MYSQL_DATABASE . Cbook_keep_plugin::get_debug_suffix();

$box_backtitle = 'Admin for DB host: "' . $db_host . '".';	// show at the top of the screen

function get_help() {
	global $db_host;
	return "Need MySQL server ADMIN_USER and ADMIN_PASSWORD" . PHP_EOL .
		"for the configured MySQL HOST " . $db_host . " to create the credentials book keeper." . PHP_EOL;
	} // get_help

if($argc < 3) {
	Ccms_cli_dialogs_plugin::box_msg('Help', $box_backtitle, get_help(),64);
	// exit(1);	// test
	} // if

echo "Checking/installing book keeper DB on host: " . $db_host . PHP_EOL;

if((empty($admin_user)) || (empty($admin_passwd))) {
	$vals = Ccms_cli_dialogs_plugin::box_username_password('Enter credentials', $box_backtitle);
	$admin_user = $vals['USERNAME'] ?: '';
	$admin_passwd = $vals['PASSWORD'] ?: '';
	} // if

$cBK_DBi = new Cbook_keep_install(true,$admin_user,$admin_passwd);

exit(0);	// done

// eof
