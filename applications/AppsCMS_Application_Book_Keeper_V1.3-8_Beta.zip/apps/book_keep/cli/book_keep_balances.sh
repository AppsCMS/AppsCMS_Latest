#!/bin/bash
# Book Keeper Application
# see Book Keeper Licence in LICENCE.txt
# _SVN_build: $Id: book_keep_balances.sh 3052 2022-12-16 09:01:07Z robert0609 $
# create book keeping database

FVERSION="V.11"

DIR="$(dirname "$0")"
php "${DIR}/book_keep_balances.php"

exit 0

