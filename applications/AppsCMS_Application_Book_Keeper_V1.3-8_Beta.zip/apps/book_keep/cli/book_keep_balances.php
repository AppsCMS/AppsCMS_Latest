<?php
/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: book_keep_balances.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure not to crash

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$cBK_BAL = new Cbook_keep_balances();

exit(0);	// done

// eof
