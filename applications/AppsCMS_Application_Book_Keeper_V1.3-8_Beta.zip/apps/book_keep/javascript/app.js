/*
 * Copyright BRAEWORKS (R) 2019
 * _SVN_build: $Id: app.js 2786 2022-08-31 05:40:44Z robert0609 $
 */

// nothing for Book Keeper for now


// EOF
