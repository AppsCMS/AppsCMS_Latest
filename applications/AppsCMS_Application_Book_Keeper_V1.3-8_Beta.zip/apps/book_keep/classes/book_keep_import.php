<?php

/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: book_keep_import.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of book_keep_import
 * Book keep import class.
 *
 * @author robert0609
 */
class Cbook_keep_import extends Cbook_keep_app {

	protected $MSM2000_txt_file = false;
	protected $MSM2000_type = false;
	protected $MSM2000_accounts = false;
	protected $MSM2000_header = false;

	const MSM_CSV_SEP = "\t";
	const MSM_CSV_ENC = '"';	// empty
	const MSM_FILE_TYPE_ROW = 1;
	const MSM_ACCOUNTS_ROW = 2;
	const MSM_HEADER_ROW = 6;
	const MSM_DATA_START_ROW = 7;
	const MSM_LAST_ROW_MSK = '/^Grand Total.*/i';

	const MSM_MIN_COLS_IN_ROW = 4;
	const MSM_1ST_CHK_COL = 1;
	const MSM_LAST_CHK_COL = 4;

	protected static $csBK_DB = false;

	function __construct() {
		parent::__construct();
		self::$csBK_DB = self::$csBK_DB_edit->get_DB();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function get_import_MSM2000_column_control() {
		return array(
			// csv_col_head, tables, column, conditions ... (including cross index functions)
			'Num' => array(
				'table' => 'transactions',
				'column' => 'transaction_type',
				'allow_empty' => true,
				),
			'Date' => array(
				'table' => 'transactions',
				'column' => 'transaction_date',
				'method' => 'get_transaction_date',
				'allow_empty' => false,
				),

			'Payee' => array(
				'table' => 'transactions',
				'column' => 'payee_id',
				'method' => 'get_payee_id',
				'allow_empty' => false,
				),
			'C' => array(
				'table' => 'transactions',
				'column' => 'transaction_status',
				'method' => 'get_transaction_status',
				'allow_empty' => true,
				),

			'Account' => array(
				'table' => 'transactions',
				'column' => 'account_id',
				'method' => 'get_account_id',
				'allow_empty' => false,
				),

			'Memo' => array(
				'table' => 'transactions',
				'column' => 'transaction_memo',
				'allow_empty' => true,
				),

			'Category' => array(
				'table' => 'transactions',
				'column' => 'category_id',
				'method' => 'get_category_id',
				'allow_empty' => true,
				),

			'Receipts' => array(
				'table' => 'transactions',
				'column' => 'receipt_id',
				'method' => 'get_receipt_id',
				'allow_empty' => true,
				),

			'Projects' => array(
				'table' => 'transactions',
				'column' => 'project_id',
				'method' => 'get_project_id',
				'allow_empty' => true,
				),

			'Amount' => array(
				'table' => 'transactions',
				'column' => 'transaction_amount',
				'allow_empty' => false,
				'method' => 'currency_to_float',
				// 'type' => 'currency',
				),

			);
		} // get_import_MSM2000_column_control()

// dynamic methods
	protected function chk_lookup_table($data,$table,$name,$req_col_name) {
		$sql = 'SELECT ' . $req_col_name . ' FROM ' . $table . ' WHERE ' . $name . ' = \'' . self::$csBK_DB->input($data) . '\';';
		if(($result = self::$csBK_DB->query($sql)) &&
			($val = self::$csBK_DB->fetch_array($result))) {
			// found
			return $val[$req_col_name];
			} // if
		// else new
		$fields = array(
			$name => $data,
			);
		if(!self::$csBK_DB->perform($table,$fields)) {
			self::addMsg('Failed to insert data into table "' . $table . '".');
			return false;
			} // if
		return self::$csBK_DB->get_last_insert_id();
		} // chk_lookup_table()

	protected function get_transaction_date($data) {
		// e.g. 1/07/2005
		$bits = explode('/',$data);
		return date('Y-m-d 00:00:00' , mktime(0,0,0,$bits[1],$bits[0],$bits[2]));
		} // get_transaction_date()

	protected function get_payee_id($data) {
		// e.g. payee name (unique)
		return $this->chk_lookup_table($data,'payees','payee_name','payee_id');
		} // get_payee_id()

	protected function get_transaction_status($data) {
		// e.g (nil), 'C' or 'R'
		switch(strtolower($data)) {
		case 'r':
			return 'RECONCILED';
		case 'c':
			return 'CLEARED';
		default:
			break;
			} // switch
		return 'ENTERED';
		} // get_transaction_status()

	protected function get_account_id($data) {
		return $this->chk_lookup_table($data,'accounts','account_name','account_id');
		} // get_account_id()

	protected function get_category_id($data) {
		return $this->chk_lookup_table($data,'categories','category_name','category_id');
		} // get_category_id()

	protected function get_receipt_id($data) {
		return $this->chk_lookup_table($data,'receipts','receipt_name','receipt_id');
		} // get_receipt_id()

	protected function get_project_id($data) {
		return $this->chk_lookup_table($data,'projects','project_name','project_id');
		} // get_project_id()

	protected function import_MSM2000_row($table,$row) {
		if(!self::$csBK_DB->is_ok()) return false;
		$bad_cnt = 0;
		$col_cntl = self::get_import_MSM2000_column_control();
		$fields = array();
		for($c = 0; $c < count($row); $c++) {
			$name = $this->MSM2000_header['num2nam'][$c];
			$data = $row[$c];
			if(isset($col_cntl[$name])) {
				$op = &$col_cntl[$name];
				if(isset($op['method'])) {
					$method = $op['method'];
					$val = $this->$method($data);
					} // if
				else $val = $data;
				$col_name = $op['column'];
				if($val !== false) {
					$fields[$col_name] = $val;
					} // if
				else $bad_cnt++;
				} // if
			else $bad_cnt++;
			} // for
		if((!$bad_cnt) &&
			(!self::$csBK_DB->perform($table,$fields))) {
			self::addMsg('Failed to insert data into table "' . $table . '".');
			return false;
			} // if
		return true;
		} // import_MSM2000_row()

	public function import_MSM2000_txt_file($filepath) {
		if(!file_exists($filepath)) {
			self::addMsg('File  "' . $filepath . '" does not exist.');
			return false;
			} // if
		$this->MSM2000_txt_file = $filepath;
		$fh = fopen($this->MSM2000_txt_file,'r');
		if(!$fh) {
			self::addMsg('Cannot open "' . $this->MSM2000_txt_file . '".');
			return false;
			} // if

		echo "Importing: " . $this->MSM2000_txt_file . "<br>\n";
		ob_flush();
		flush();

		$row_cnt = 0;
		$table = 'transactions';
		$last_full_row = false;
		while($row = fgetcsv($fh, 0, self::MSM_CSV_SEP, self::MSM_CSV_ENC)) {
			if(preg_match(self::MSM_LAST_ROW_MSK,$row[0])) break;	// that is it

			$row_cnt++;
			// if($row_cnt > 10000) break;	// @TODO testing only

			if(empty($row)) continue;
			switch($row_cnt) {
			case self::MSM_FILE_TYPE_ROW:
				$this->MSM2000_type = $row[0];
				break;
			case self::MSM_ACCOUNTS_ROW:
				$this->MSM2000_accounts = $row[0];
				break;
			case self::MSM_HEADER_ROW:
				$this->MSM2000_header['num2nam'] = $row;
				foreach($row as $nun => $name) {
					$this->MSM2000_header['nam2num'][$name] = $nun;
					} // foreach
				break;
			case self::MSM_DATA_START_ROW:
				// start of data
			default:
				if($row_cnt < self::MSM_DATA_START_ROW) break; // wait for start of data (??)
				if(count($row) < self::MSM_MIN_COLS_IN_ROW) break;
				// fill in the gaps left by MS money
				for($i = (int)self::MSM_1ST_CHK_COL; $i <= (int)self::MSM_LAST_CHK_COL; $i++) {
					if((empty($row[$i])) && (!empty($last_full_row[$i]))) {
						// fill in the missing column data
						$row[$i] = $last_full_row[$i];
						} // if
					} // for
				$last_full_row = $row;
				if(!$this->import_MSM2000_row($table,$row)) {
					fclose($fh);
					self::addMsg('Failed to imported at row ' . $row_cnt . '.');
					echo "<br>\n" . 'Failed to imported at row ' . $row_cnt . '.';
					return false;
					} // if
				break;
				} // switch
			if(($row_cnt % 1000) == 0) {
				echo "<br>\n" . 'Row: ' . $row_cnt;
				ob_flush();
				flush();
				} // if
			} // while
		fclose($fh);
		echo "<br>\n" . 'Imported ' . $row_cnt . ' rows. - success';
		self::addMsg('Imported ' . $row_cnt . ' rows.','success');
		return true;
		} // import_MSM2000_txt_file()

} // Cbook_keep_import
