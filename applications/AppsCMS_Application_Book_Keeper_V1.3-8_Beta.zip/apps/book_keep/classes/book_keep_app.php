<?php

/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: book_keep_app.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of book_keep_app
 * Main app class.
 *
 * @author robert0609
 */
class Cbook_keep_app extends Ccms_app_base {

	protected static $my_ini_ctls = array();
	protected static $my_api_summary = array();
	protected static $my_head = array();

	protected static $csBK_DB_edit = false;
	protected static $ini_func_keys = array(
		'FMT_NUMBER_PREC',
		);

	function __construct() {
		parent::__construct();
		self::init();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// AppsCMS optional methods, see "index.php?cms_action=cms_manual#AppClass"
	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		// return '';	// default return
		$cDB_edit = new Cbook_keep_DB_edit();
		if(!$cDB_edit->is_ok()) return false;
		if ($ajax == 'book_keep_save') {
			$row_id_name = $cDB_edit->get_DB_form_data();
			return $row_id_name;
			} // if
		else if($ajax == 'get_DB_select_options') {	// get select options from DB table
			$text = $cDB_edit->get_DB_ajax_select_options();
			return $text;
			} // else if
		else if($ajax == 'show_DBeditDlg') {
			$text = $cDB_edit->get_DB_ajax_edit_dialog();
			return $text;
			} // else if
		return '';
		} // get_ajax_text()

	public static function get_ws_text($wsid,$op) {	// required function, Executes the applications WebSockets code.
		return '';	// default emtpy return
		} // get_ws_text()

	public static function do_app_warnings($bld = false) {
		$func_class_chk_list = array(
			array(
				'func' => 'mysqli_connect',
				'needs' => 'System pkg php-mysqlnd',
				),
			array(
				'func' => 'gd_info',
				'needs' => 'System pkg php-gd',
				),
//			array(
//				'class' => 'SQLite3',
//				'needs' => 'SQLite 3',
//				),
			);
		$ok = Ccms::do_install_warnings_func_chks($func_class_chk_list);
		if($ok) self::log_msg('No Book Keep install issues detected.','info');
		return $ok;
		} // do_app_warnings()

	public static function is_app_setup_key_funcs_used($key) {
		if(in_array($key,self::$ini_func_keys)) return true;
		return false;
		} // is_app_setup_key_funcs_used()

	public static function show_app_setup_value($sect,$key,$name,$value) {
		switch($key) {
		case 'FMT_NUMBER_PREC':
			echo $value;
			break;
		default:
			return false;	// not me
			} // switch
		return true;	// done
		} // show_app_setup_value()

	public static function input_app_setup_form_text($sect,$key,$name,$value) {
		$text = '';
		switch($key) {
		case 'FMT_NUMBER_PREC':
			$text = '<input type="number" name="' . $name . '" value="' . $value . '" min="0" max="4" step="1">';
			// should be select
			break;
		default:
			return false;	// not me
			} // switch
		return $text;	// done
		} // input_app_setup_form_text()

	public static function get_app_setup_form_value($sect,$key,$name,$value) {
		switch($key) {	// the $name variable is not used, the $value has the new value.
		case 'FMT_NUMBER_PREC':
			$fm_value = $value;	// posted form value
			// be a select later, but need to stop true,false interpretation

			$value = $fm_value;	// same ATM
			break;
		default:
			return null;	// not me
			} // switch
		return $value;	// done
		} // get_app_setup_form_value()

	public static function &get_ini_app_input_ctl() {
		static $grid_inputs = array(
			'TRANS_REPORT_COLUMNS' => array(	// ini_key to match
				'type' => 'multi_select',	// input or multi_select
				'col_heads' => 'Column Name:Show:Head',	// e.g. "Name" is first column heading : "Hex RGB Colour" is second column heading, etc.
				'val_sep' => ':',	// separator used values
				'data_sep' => '=',	// separator between name and value (e.g. name=>value), optional
				'options_func' => 'get_trans_report_options',	// multi_select method name to use in the primary application class.
				),
			);
		return $grid_inputs;	// it's a reference
		} // get_ini_app_input_ctl()

	public static function &get_api_map_summary() {
		return self::$my_api_summary;	// default return (empty)
		} // get_api_map_summary()

	public static function &get_head_text() {
		return self::$my_head;	// default return (empty)
		} // get_head_text()

// static methods
	public static function &get_DB_edit() {
		return self::$csBK_DB_edit;
		} // get_DB_edit()

	public static function get_version() {
		return self::BK_VERSION;
		} // get_version()

	public static function init() {
		if(!self::$csBK_DB_edit) {
			self::$csBK_DB_edit = new Cbook_keep_DB_edit();
			if(!self::$csBK_DB_edit->is_ok()) return false;
			} // if
		return true;
		} // init()

	public static function get_trans_report_options($values) {
		$install_scripts = Cbook_keep_install::get_installDBscripts();
		$trans_table = &$install_scripts['transactions']['edit']['columns'];
		$opts_allowed = array();
		foreach($trans_table as $col => &$v) {
			if(empty($v['head'])) continue;
			$opts_allowed[$col] = $v['head'];
			} // foreach
		$vals = explode(':',$values);
		$options = array();
		foreach($opts_allowed as $k => &$v) {
			$options[] = array(
				'value' => $k,
				'selected' => (in_array($k,$vals) ? true:false),
				// 'text' => $k . ' - ' . $v,
				'text' => $v,
				);
			} // foreach
		return $options;
		} // get_trans_report_options()

// dynamic methods

} // Cbook_keep_app
