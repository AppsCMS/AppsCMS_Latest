<?php

/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: app_config.php 2814 2022-09-21 05:22:48Z robert0609 $
 */

define('DIR_BK_DIR', APPs_FS_BOOK_KEEP_DIR);

define('BOOK_KEEP_DB_JSON', APPs_FS_BOOK_KEEP_INI_DIR . 'book_keep_DB.json');
