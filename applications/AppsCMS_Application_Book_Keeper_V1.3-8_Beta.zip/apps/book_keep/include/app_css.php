/*
 * see Book Keeper Licence in LICENCE.txt
 * _SVN_build: $Id: app_css.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/*
	Document   : app_css
    Description:
        Purpose of the stylesheet follows.
		Book Keeper styles.
		<?= $gen_note ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

/* looks like app INI comment file */
.plus_number {
	background-color: <?= $theme['ThemeSettings']['FMT_PLUS_NUMBER_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['FMT_PLUS_NUMBER_COLOUR'] ?>;
	font-size: 1.2em;
	padding: 5px;
	}

.neg_number {
	background-color: <?= $theme['ThemeSettings']['FMT_NEG_NUMBER_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['FMT_NEG_NUMBER_COLOUR'] ?>;
	font-size: 1.2em;
	padding: 5px;
	}

/* eof */

