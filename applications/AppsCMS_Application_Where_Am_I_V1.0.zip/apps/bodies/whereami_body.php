<?php

include(APPs_FS_WHEREAMI_DIR . 'whereami.php');
