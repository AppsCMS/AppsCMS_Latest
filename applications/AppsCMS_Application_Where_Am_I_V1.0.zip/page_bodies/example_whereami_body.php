<p>Refer: https://wiki.openstreetmap.org/</p>

<style type="text/css">
#wai_Map {
	position: absolute;
	top: calc(<?php echo INI_HEADER_HEIGHT; ?> + 50px);
	width: calc(100vw - 10px - <?php echo (INI_LEFT_COLUMN_BOOL ? INI_LEFT_WIDTH:'0px'); ?> - <?php echo (INI_RIGHT_COLUMN_BOOL ? INI_RIGHT_WIDTH:'0px'); ?>);
	min-height: calc(100vh - 55px - <?php echo INI_HEADER_HEIGHT; ?> - <?php echo INI_FOOTER_HEIGHT; ?>);
	height: 300px;
	margin: 0;
	}
</style>
<div id="lat_lon"></div>
<div id="wai_Map"></div>
<script src="cms/lib/OpenLayers-2.13.1/OpenLayers.js"></script>
<script>
	var Cos_track_map = function(init_lat,init_lon,init_zoom) {
		// refer: https://wiki.openstreetmap.org/wiki/OpenLayers_Simple_Example
		var lat            = (init_lat ? init_lat:0);
		var lon            = (init_lon ? init_lon:0);
		var zoom           = (init_zoom ? init_zoom:18);
		var update_ms = 5000;
		var map = false;	// somewhere for map object
		var position = false;	// somewhere for position
		var int = false;
		var self = this;

		this.init = function(init_lat,init_lon,init_zoom) {
			if(init_lat) lat = init_lat;
			if(init_lon) lon = init_lon;
			if(init_zoom) zoom = init_zoom;
			this.drawMap();
			if(!self) return;
			if((update_ms) && (update_ms > 1000))
				int = setInterval(this.trackMap, update_ms);
			} // init()

		this.drawMap = function() {
			var fromProjection = new OpenLayers.Projection("EPSG:4326");   // Transform from WGS 1984
			var toProjection   = new OpenLayers.Projection("EPSG:900913"); // to Spherical Mercator Projection
			position       = new OpenLayers.LonLat(lon, lat)
				.transform( fromProjection, toProjection);

			map = new OpenLayers.Map("wai_Map");
			var mapnik         = new OpenLayers.Layer.OSM();
			map.addLayer(mapnik);

			var markers = new OpenLayers.Layer.Markers( "Markers" );
			map.addLayer(markers);
			var marker = new OpenLayers.Marker(position);
			marker.icon.imageDiv.title = 'Ta Dah, Its me !!';
			markers.addMarker(marker);

			map.setCenter(position, zoom);
			} // drawMap()

		this.positionMap = function(new_lat,new_lon,acc_m) {
			zoom = map.getZoom();	// get current zoom
			lat = new_lat;	// track it
			lon = new_lon;	// track it
			map.setCenter(
				new OpenLayers.LonLat(lat,lon) // Center of the map
					.transform(
						new OpenLayers.Projection("EPSG:4326"), // transform from new RD
						new OpenLayers.Projection("EPSG:900913") // to Spherical Mercator Projection
					),
				zoom); // Zoom level
			this.showLatLon(acc_m);
			} // positionMap()

		this.trackMap = function() {
			// clearInterval(int);	// test
			if (navigator.geolocation) {	// this only works on https protocol
				navigator.geolocation.getCurrentPosition(self.getGeoLocation);
				} //if
			else {

				} // else
			} // trackMap()

		this.getGeoLocation = function(position) {
			var lat = position.coords.latitude;
			var lon = position.coords.longitude;
			var acc_m = position.coords.accuracy;
			self.positionMap(lat,lon,acc_m);
			} // getGeoLocatio()

		this.showLatLon = function(acc_m) {
			var lat_lon = document.getElementById('lat_lon');
			lat_lon.innerHTML = 'Latitude: ' + lat + '&deg;' +
					', Longitude: ' + lon + '&deg;' +
					', Zoom: ' + zoom +
					(acc_m ? ', (Error: &plusmn;' + acc_m.toFixed(2) + 'm).':'');
			} //  showLatLon()

	} // Cos_track_map

	var cOS_TM = false;

	window.addEventListener("DOMContentLoaded",function() {
		cOS_TM = new Cos_track_map();
//		cOS_TM = new Cos_track_map(<?php echo Ccms::$geo_location_latitude; ?>,<?php echo Ccms::$geo_location_longitude; ?>);
		cOS_TM.init(<?php echo Ccms::$geo_location_latitude; ?>,<?php echo Ccms::$geo_location_longitude; ?>);
//		cOS_TM.init();
	});

</script>