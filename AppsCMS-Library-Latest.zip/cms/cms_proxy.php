<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_proxy.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

// the proxy operation needs to be as fast as possible

if(!defined('WWW_CALL')) define('WWW_CALL',true);	// global for WWW recognition

require_once 'include/cms_configure.php';
require_once 'include/classes/cms_proxy.php';

if(Ccms_proxy::is_get_or_post('proxy')) { // from client either side of the firewall
	Ccms_proxy::output_proxy_file();
	exit;
	} // if

// EOF
