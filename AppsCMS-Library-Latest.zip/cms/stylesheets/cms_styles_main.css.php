/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 <?php // * _SVN_build: $Id: cms_styles_main.css.php 3219 2023-02-20 13:53:05Z robert0609 $ ?>
 */

/*
	Document   : main_styles
	Description:
		Purpose of the stylesheet follows.
		Main styles for common styles.
		<?= $gen_note ?>

	Syntax recommendation http://www.w3.org/TR/REC-CSS2/
*/

@media print {
		#cms_lo_left_column,
		#cms_lo_right_column,
		#cms_lo_nav_bar,
		cms_msg_alert,
		cms_hover_block_outer,
		cms_hover_block_inner,
		cms_sub_hover_block_outer,
		cms_sub_hover_block_inner,
		cms_title_tooltip,
		cms_nav_bar,
		cms_nav_bar_on,
		cms_JS_dialog,
		social_media,
		option:not(:checked),
		no_print {
			display: none !important;
			visibility: hidden;
			width: 0;
		}

	#cms_nav_bar,
	#cms_page_frame,
	#lm_link_frame,
	#cms_page_body {
		z-index:	3;
		width:		100%;
		height: unset;
		}
	pointer-events: none;
	}

@media print {

<?php if(!CMS_S_PRINT_HEADER_FOOTER_BOOL) { ?>

	#cms_lo_header { display:none; }
	#cms_lo_footer { display:none; }
	#cms_lo_left_column { display:none; }
	#cms_lo_right_column { display:none; }

<?php	} // if ?>

	#id_cms_goto_Top_box {
		visibility: hidden;
		display:none;
		}
	}


@media screen {

	}

<?php

	// adjust logo height so it fits header (? + nav bar)
	$hh = (int)preg_replace('/[a-z]*$/i', '',  $theme['ThemeSettings']['HEADER_HEIGHT']);
	$pad = 5;
	$mh = $hh + $pad;
	if($cms_nav_bar)
		$mh += (int)preg_replace('/[a-z]*$/i', '', $theme['ThemeSettings']['NAV_BAR_HEIGHT']);

	$lh = (int)preg_replace('/[a-z]*$/i', '',  $theme['ThemeSettings']['LOGO_HEIGHT']);
	if((($hh - $pad - $pad) > 0) && ($lh > ($hh - $pad - $pad))) {
		$lh = $hh - $pad - $pad;
		Ccms::pushMsg('Logo height reduced to ' . $lh . 'px to fit into header.','warning');
		} // if
	else if(($hh - $pad - $pad) <= 0) {
		$lh = 0;
		Ccms::pushMsg('Logo height too large to fit into header.','error');
		} // else if
	// else ok

if(!function_exists('get_body_copy_css')) {	// sometimes run twice if installing or errors found
	function get_body_copy_css($theme,$allow = true) {
		if(($allow) && ($theme['ThemeSettings']['PAGE_BODY_COPY_BOOL'] == 'true')) {
echo <<<EOTA

		-webkit-user-select: text; /* Chrome, Opera, Safari */
		-moz-user-select: text; /* Firefox 2+ */
		-ms-user-select: text; /* IE 10+ */
		user-select: text; /* Standard syntax */

EOTA;
		} // if
	else {
	echo <<<EOTB

		-webkit-user-select: none; /* Chrome, Opera, Safari */
		-moz-user-select: none; /* Firefox 2+ */
		-ms-user-select: none; /* IE 10+ */
		user-select: none; /* Standard syntax */

EOTB;
		} // else
	} // get_body_copy_css()
} // if

?>

/* preloaded background images */
#preloaded::after {
	content: <?php
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_IMAGES_DIR,CMS_C_LOGO_IMAGE);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['BODY_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['HEADER_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_ELEM_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['FOOTER_BKGD_IMAGE']);
	echo ' ' . Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['SM_BKGD_IMAGE']);
if(is_readable(DOCROOT_FS_BASE_DIR . '/favicon.ico')) {
	echo ' url("favicon.ico")';
	} // if
else if(is_readable(DOCROOT_FS_BASE_DIR . '/favicon.png')) {
	echo ' url("favicon.png")';
	} // if
if(is_readable(DOCROOT_FS_BASE_DIR . '/' . CMS_WS_ICONS_DIR . 'eye_open.png')) {
	echo ' url("' . CMS_WS_ICONS_DIR . 'eye_open.png")';
	} // if
if(is_readable(DOCROOT_FS_BASE_DIR . '/' . CMS_WS_ICONS_DIR . 'eye_closed.png')) {
	echo ' url("' . CMS_WS_ICONS_DIR . 'eye_closed.png")';
	} // if
?>;
	display: none;
	}

/* standard stuff */
@media print {
	.no-print {
		display: none !important;
		}
	}

[draggable=true] {
	cursor: move;
	}

.resizable {
	overflow: scroll;
	resize: both;
	max-width: 300px;
	max-height: 460px;
	}

div.cms_sticky_left,
td.cms_sticky_left {
	position: -webkit-sticky;
	position: sticky;
/*	background-color: <?= $theme['ThemeSettings']['BODY_BKGD_COLOUR'] ?>; */
	top: 5px;
/*	left: 20px; */
	width: auto;
/*	padding: 5px;*/
	margin: 5px 5px 0px 5px;
	float: left;
	z-index: 200;
	}

div.cms_sticky_top {
	position: -webkit-sticky;
	position: sticky;
/*	background-color: <?= $theme['ThemeSettings']['BODY_BKGD_COLOUR'] ?>; */
	top: 5px;
	width: auto;
	margin: 5px 5px 0px 5px;
/*	margin: 5px;*/
	text-align: center;
	z-index: 200;
	}

div.cms_sticky_right {
	position: -webkit-sticky;
	position: sticky;
/*	background-color: <?= $theme['ThemeSettings']['BODY_BKGD_COLOUR'] ?>;*/
/*	top: 5px;*/
	right: 10px;
	width: auto;
/*	padding: 5px;*/
	margin: 5px 5px 0px 5px;
	float: right;
	z-index: 200;
	}

div.cms_sticky_bottom {
	position: -webkit-sticky;
	position: sticky;
/*	background-color: <?= $theme['ThemeSettings']['BODY_BKGD_COLOUR'] ?>; */
	bottom: 5px;
	width: auto;
	padding: 5px;
	margin: 5px 5px 0px 5px;
	text-align: center;
	z-index: 200;
	}

table, tbody, tr, th, td {
	border-spacing: 0; /* new footer looks terrible without this */
	}

/* *** Stretch vertically if necessary in order to get footer at bottom of screen */
html, body {
	height: 100% !important;
	}

tr.cms_main_body {
	height: 100% !important;
	vertical-align: top;
	}
/* *** */

body {
<?php if(!empty($theme['ThemeSettings']['BODY_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['BODY_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-size: cover;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['BODY_BKGD_COLOUR'] ?>;
<?php } // else ?>
	font-family:	<?= $theme['ThemeSettings']['FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['FONT_WEIGHT'] ?>;
	color:			<?= $theme['ThemeSettings']['FONT_COLOUR'] ?>;
	margin:		0px;
	padding:	0px;
	}

body.cms_waiting * {
	cursor: wait;
	}

fieldset {
	border: 0;
	margin: 0;
	padding: 0;
	}

div {
	}

caption {	/* make captions invisible to seeing, but useful to sight impaired */
	height: 0px;
	width: 0px;
	visibility: hidden;
	}

iframe {
	}

iframe.tools {
	background-color:	<?= $theme['ThemeSettings']['TOOLS_FRM_BKGD_COLOUR'] ?>;
	color:			<?= $theme['ThemeSettings']['TOOLS_FRM_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['TOOLS_FRM_FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['TOOLS_FRM_FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['TOOLS_FRM_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['TOOLS_FRM_FONT_WEIGHT'] ?>;
	}

font {
	font-family:	<?= $theme['ThemeSettings']['FONT_FAMILY'] ?>;
	font-style:		<?= $theme['ThemeSettings']['FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FONT_SIZE'] ?>;
	color:			<?= $theme['ThemeSettings']['FONT_COLOUR'] ?>;
	}

form {
	display: inline;
	}

input[type='file'] {
	border:		<?= $theme['ThemeSettings']['PAGE_BODY_BORDER'] ?>;
	border-radius: 0.5em;
	padding: 5px 8px;
	outline: none;
	}

input.page_body, button.page_body, select.page_body, option.page_body, textarea.page_body {
	background-color: <?= $theme['ThemeSettings']['BODY_BKGD_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['FONT_FAMILY'] ?>;
	font-style:		<?= $theme['ThemeSettings']['FONT_STYLE'] ?>;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['FONT_SIZE'] ?>;
	color:			<?= $theme['ThemeSettings']['FONT_COLOUR'] ?>;
	padding:		0px;
	}

input, button, select, textarea {
	background-color: white;
	font-family:	Verdana, Geneva, sans-serif;
	font-style:		normal;
	font-weight:	normal;
	font-size:		1.0em;
	color:			black;
	}

input.std, button.std, select.std, textarea.std {
	padding: 1px 2px;
	display: inline-block;
	max-width: 98%;
	width: unset;
	}

button {
	box-shadow: 2px 2px grey;
	}

button:active {
	box-shadow: 0px 0px grey;
	}

input:disabled, button:disabled, select:disabled, textarea:disabled, option:disabled {
	background-color: lightgrey;
	color:			grey;
	}

<?php if($theme['ThemeSettings']['INPUT_NUMBER_SPINNERS_BOOL'] != 'true') { ?>

/* fix the ugly input number spinners */
/* Standard */
input[type=number] {
	appearance: textfield;
	}

/* Firefox */
input[type=number] {
	-moz-appearance: textfield;
	}

/* Chrome */
input::-webkit-inner-spin-button,
input::-webkit-outer-spin-button {
	-webkit-appearance: none;
	margin:0;
	}

<?php	} // if ?>

<?php if(($theme['ThemeSettings']['INPUT_NUMBER_SPINNERS_HOVER_BOOL'] == 'true') &&
	($theme['ThemeSettings']['INPUT_NUMBER_SPINNERS_BOOL'] != 'true')) { ?>

/* fix the ugly input number spinners */
/* Standard */
/* Show number picker on focus */
input[type=number]:focus,
input[type=number]:hover {
	appearance: number-input;
	}

/* Firefox */
/* Show number picker on focus */
input[type=number]:focus,
input[type=number]:hover {
	-moz-appearance: number-input;
	}

/* Chrome */
/* Show number picker on focus */
input[type=number]:focus::-webkit-inner-spin-button,
input[type=number]:focus::-webkit-outer-spin-button,
input[type=number]:hover::-webkit-inner-spin-button,
input[type=number]:hover::-webkit-outer-spin-button {
	-webkit-appearance: inner-spin-button;
	margin: 0 2px 0 0 ;
	}

<?php	} // if ?>

<?php if($theme['ThemeSettings']['INPUT_SELECT_ARROW_BOOL'] != 'true') { ?>

/* turn off select arrows */
/* Standard */
select {
	appearance: textfield;
	}

/* Firefox */
select {
	-moz-appearance: textfield;
	}

/* Chrome */
select {
	-webkit-appearance: none;
	margin:0;
	}

<?php	} // if ?>

select {
	text-align: center;
	}

option {
	text-align: left;
	}

a, a:active, a:link, a:visited {
	font-family:	inherit;
	font-size:		inherit;
	color:			inherit;
	text-decoration: none;
	}

a:hover, .href_linked:hover {
	font-family:	inherit;
	color:			<?= $theme['ThemeSettings']['ANCHOR_HOVER_COLOUR'] ?>;
	text-decoration: underline;
	cursor:			pointer;
	}

a.href_up {	/* href is on screen */
	font-style: italic;
	font-size: 110%;
/*	font-weight: bold;		*/
	}

p {
	font-family:	<?= $theme['ThemeSettings']['FONT_FAMILY'] ?>;
	font-style:		<?= $theme['ThemeSettings']['FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FONT_SIZE'] ?>;
	color:			inherit;
	text-align: left;
	text-decoration: none;
	padding-bottom: 8px;
	padding-top:	2px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

h1 {
	display:	inline-block !important;
	background-color:	<?= $theme['ThemeSettings']['H1_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['H1_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['H1_FONT_FAMILY'] ?>;
	font-size: <?= $theme['ThemeSettings']['H1_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['H1_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['H1_FONT_WEIGHT'] ?>;
	text-align: left;
	text-decoration: <?= $theme['ThemeSettings']['H1_TEXT_DECORATION'] ?>;
	padding-top: 10px;
	padding-bottom: 4px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	white-space:	nowrap;
	}

h2 {
	display:	inline-block !important;
	background-color:	<?= $theme['ThemeSettings']['H2_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['H2_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['H2_FONT_FAMILY'] ?>;
	font-size: <?= $theme['ThemeSettings']['H2_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['H2_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['H2_FONT_WEIGHT'] ?>;
	text-align: left;
	text-decoration: <?= $theme['ThemeSettings']['H2_TEXT_DECORATION'] ?>;
	padding-top: 7px;
	padding-bottom: 2px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	white-space:	nowrap;
	}

h3 {
	display:	inline-block !important;
	background-color:	<?= $theme['ThemeSettings']['H3_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['H3_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['H3_FONT_FAMILY'] ?>;
	font-size: <?= $theme['ThemeSettings']['H3_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['H3_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['H3_FONT_WEIGHT'] ?>;
	text-align: left;
	text-decoration: <?= $theme['ThemeSettings']['H3_TEXT_DECORATION'] ?>;
	padding-top: 5px;
	padding-bottom: 0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	white-space:	nowrap;
	}

h4 {
	display:	inline-block !important;
	background-color:	<?= $theme['ThemeSettings']['H4_BKGD_COLOUR'] ?>;
	color: <?= $theme['ThemeSettings']['H4_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['H4_FONT_FAMILY'] ?>;
	font-size: <?= $theme['ThemeSettings']['H4_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['H4_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['H4_FONT_WEIGHT'] ?>;
	text-align: left;
	text-decoration: <?= $theme['ThemeSettings']['H4_TEXT_DECORATION'] ?>;
	padding-top: 3px;
	padding-bottom: 0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	white-space:	nowrap;
	}

img {
	border-width: 0px;
	padding: 0px;
	margin: 0px;
	text-decoration: none;
	}

img.logo {
	height: <?= $lh . 'px' ?>;
	vertical-align: middle;
	text-decoration: none;
	}

img.menu_link_icon {
	border:	none;
	padding: 0px;
	margin: 0px 5px 0px 0px;
	height: <?= $theme['ThemeSettings']['MENU_ICON_HEIGHT'] ?>;
	}

img.msg_icon {
	border:	none;
	padding: 0px;
	margin: 0px 5px 0px 0px;
	height: <?= $theme['ThemeSettings']['MSG_ICON_HEIGHT'] ?>;
	}

img.msg_icon_small {
	border:	none;
	padding: 0px;
	margin: 0;
	height: 15px;
	}

img.msg_icon_small:hover,
img.msg_icon:hover {	/* stop config msg icon scaling */
	-ms-transform: unset; /* IE 9 */
	-webkit-transform: unset(1.0); /* Safari 3-8 */
	transform: unset;
	transform-origin: unset;
}

img.lm_cog {
	height: 5px;
	opacity: 0.3;
	}

img.lm_cog:hover {
	height: 10px;
	opacity: 1;
	}

lu {
	background-color: inherit;
	font-family:	<?= $theme['ThemeSettings']['FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['FONT_WEIGHT'] ?>;
	color:			<?= $theme['ThemeSettings']['FONT_COLOUR'] ?>;
	text-align: left;
	text-decoration: none;
	padding-bottom: 0px;
	padding-top:	0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			0px;
	}

li {
	background-color: inherit;
	font-family:	<?= $theme['ThemeSettings']['FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['FONT_WEIGHT'] ?>;
	color:			<?= $theme['ThemeSettings']['FONT_COLOUR'] ?>;
	text-align: left;
	text-decoration: none;
	padding-bottom: 2px;
	padding-top:	0px;
	padding-left:	0px;
	padding-right:	0px;
	margin:			5px;
	}

table {
	background-color: inherit;
	font-family:	inherit;
	font-style:		inherit;
	font-weight:	inherit;
	font-size:		inherit;
	color:		inherit;
	padding:	0px;
	border-width:		0px;
	margin:		0px;
	width:		100%;
	border-width:	0px;
	border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
<?= get_body_copy_css($theme) ?>
	-webkit-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
/*	-moz-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>; */
	}

th {
	font-family:	<?= $theme['ThemeSettings']['TH_FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['TH_FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['TH_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['TH_FONT_WEIGHT'] ?>;
	background-color: inherit;
	color:			inherit;
	text-align:		left;
	vertical-align: top;
	padding-top:	7px;
	border-width:	0px;
	}

tr, td {
	background-color: inherit;
	color:			inherit;	/* show the inherited, try red */
	font-family:	inherit;
	font-weight:	inherit;
	font-size:		inherit;
	}

td {
	padding:		0px;
	border-width:			0px;
	}

ul.page_top {
<?php if(!empty($theme['ThemeSettings']['HEADER_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['HEADER_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['HEADER_BKGD_COLOUR'] ?>;
<?php } // else ?>
	font-family:	<?= $theme['ThemeSettings']['HEADER_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['HEADER_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['HEADER_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['HEADER_FONT_SIZE'] ?>;
	color:		<?= $theme['ThemeSettings']['HEADER_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['HEADER_BORDER']) ?>
	}

li.page_top {
	font-family:	<?= $theme['ThemeSettings']['HEADER_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['HEADER_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['HEADER_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['HEADER_FONT_SIZE'] ?>;
	color:		<?= $theme['ThemeSettings']['HEADER_FONT_COLOUR'] ?>;
	}

ul.page_bottom {
<?php if(!empty($theme['ThemeSettings']['FOOTER_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['FOOTER_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['FOOTER_BKGD_COLOUR'] ?>;
<?php } // else ?>
	color:		<?= $theme['ThemeSettings']['FOOTER_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['FOOTER_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['FOOTER_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['FOOTER_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FOOTER_FONT_SIZE'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['FOOTER_BORDER']) ?>
	}

li.page_bottom {
	color:		<?= $theme['ThemeSettings']['FOOTER_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['FOOTER_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['FOOTER_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['FOOTER_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['FOOTER_FONT_SIZE'] ?>;
	}

ul.page_top,
ul.page_bottom {
	margin:		0px;
	width:		100%;
	/* height:		100%; */
	padding: 0;
	list-style-type: none;
	list-style:	none;
	/*overflow:	visible;*/
	flex-wrap: wrap;
	flex-direction: row;
	justify-content: space-between;
	align-items: center;
	cursor: default;
	display: flex;
/*	display: inline-block;*/
	}

li.page_top,
li.page_bottom {
	list-style:	none;
	padding-left: 7px;
	padding-right: 7px;
	padding-top: 2px;
	padding-bottom: 2px;
	display: inline;
	margin: 2px;
	margin: 0 5px 0 5px;
	}

p.page_top {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	}

.top_title {
	font-family:	<?= $theme['ThemeSettings']['HEADER_TITLE_FONT_FAMILY'] ?>;
	font-style:		<?= $theme['ThemeSettings']['HEADER_TITLE_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['HEADER_TITLE_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['HEADER_TITLE_FONT_SIZE'] ?>;
	color:			<?= $theme['ThemeSettings']['HEADER_TITLE_FONT_COLOUR'] ?>;
	}

.top_auth {
	font-family:	<?= $theme['ThemeSettings']['HEADER_AUTH_FONT_FAMILY'] ?>;
	font-style:		<?= $theme['ThemeSettings']['HEADER_AUTH_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['HEADER_AUTH_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['HEADER_AUTH_FONT_SIZE'] ?>;
	color:			<?= $theme['ThemeSettings']['HEADER_AUTH_FONT_COLOUR'] ?>;
	} 
	
.top_menus {
	font-family:	<?= $theme['ThemeSettings']['HEADER_MENU_FONT_FAMILY'] ?>;
	font-style:		<?= $theme['ThemeSettings']['HEADER_MENU_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['HEADER_MENU_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['HEADER_MENU_FONT_SIZE'] ?>;
	color:			<?= $theme['ThemeSettings']['HEADER_MENU_FONT_COLOUR'] ?>;
	}

div.top_menus {
	position: relative;
	display:	block;
	min-height: <?= $hh ?>px;
	width: 100%;
	list-style:	none;
	z-index: 900;
	}

/*div.top_menus:hover,
ul.top_menus:hover,
li.top_menus:hover { 
	overflow: unset;
	z-index: 10000;
	}*/
ul.top_menus { 
	min-height: <?= $hh ?>px; 
	width: 100%; 
	margin: 0; 
	list-style-type: none; 
	padding: 0; 
	flex-wrap: wrap; 
	flex-direction: row; 
	align-items: center; 
	cursor: default; 
	display: flex; 
	}
li.top_menus {
	list-style: none; 
	text-align: center;
	padding-left: 7px; 
	padding-right: 7px; 
	padding-top: 2px; 
	padding-bottom: 2px; 
	display: inline;
	margin: 2px; 
	}

div.left_container {
	}
	
table.left_container {
	/*background-color: <?= $theme['ThemeSettings']['LEFT_BKGD_COLOUR'] ?>;*/
	/*color:		<?= $theme['ThemeSettings']['LEFT_FONT_COLOUR'] ?>;*/
	/*<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['LEFT_BORDER']) ?>*/
	font-family:	<?= $theme['ThemeSettings']['LEFT_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['LEFT_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['LEFT_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['LEFT_FONT_SIZE'] ?>;
	padding:	0px 0px 0px 0px;
	margin:		0px;
	/*width:		<?= $theme['ThemeSettings']['LEFT_WIDTH'] ?>;*/
	width: 100%;
	}

tr.left_container {
	background-color: inherit;
	}

td.left_container, p.left_container {
	background-color: inherit;
	color:			inherit;
	font-family:	inherit;
	}

td.left_container {
	text-align: left;
	vertical-align: top;
	padding: 1px 1px 1px 1px;
	}

div.right_container {
	}
	
table.right_container {
	/*background-color: <?= $theme['ThemeSettings']['RIGHT_BKGD_COLOUR'] ?>;*/
	/*color:		<?= $theme['ThemeSettings']['RIGHT_FONT_COLOUR'] ?>;*/
	/*<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['RIGHT_BORDER']) ?>*/
	font-family:	<?= $theme['ThemeSettings']['RIGHT_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['RIGHT_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['RIGHT_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['RIGHT_FONT_SIZE'] ?>;
	padding:	0px 0px 0px 0px;
	margin:		0px;
	/*width:		<?= $theme['ThemeSettings']['RIGHT_WIDTH'] ?>;*/
	width: 100%;
	}

tr.right_container {
	background-color: inherit;
	}

td.right_container, p.right_container {
	background-color: inherit;
	color:			inherit;
	font-family:	inherit;
	}

td.right_container {
	text-align: left;
	vertical-align: top;
	padding: 1px 1px 1px 1px;
	}

span.cms_scroll2anchor_box {
	background-color: <?= $theme['ThemeSettings']['SCROLL2ANCHOR_BKGD_COLOUR'] ?>;
	opacity: 0.6;
	color:		<?= $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['SCROLL2ANCHOR_BORDER']) ?>
	font-family:	<?= $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['SCROLL2ANCHOR_FONT_SIZE'] ?>;
	position: fixed;
	left: 180px;
	top: 30%;
	margin: 5px;
	padding: 5px;
	border-radius: 0.5em;
<?= get_body_copy_css($theme,false) ?>
	-webkit-border-radius: 0.5em;
/*	-moz-border-radius: 0.5em; */
	scroll-behavior: smooth;
	z-index: +1000;
	}

span.cms_scroll2anchor_box:hover {
	opacity: 1;
	animation: blinkerTop 0.3s linear infinite;
	color: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_BKGD_COLOUR'] ?>;
	}
@keyframes blinkerTop {
	50% { opacity: 0; }
	}

.blink_red_twice {
	animation-name: blink_2red_bkgd;
	animation-duration: 0.8s;
	}
@keyframes blink_2red_bkgd {
	0%	{	background-color: red; }
	32%	{	background-color: red; }
	33%	{	background-color: inherit; }
	65%	{	background-color: inherit; }
	66%	{	background-color: red;	}
	99%	{	background-color: red;	   }
	100%{	background-color: inherit;  }
	}

table.tools_pdb_container {
	background-color: <?= $theme['ThemeSettings']['TOOLS_PDB_BKGD_COLOUR'] ?>;
	color:		<?= $theme['ThemeSettings']['TOOLS_PDB_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['TOOLS_PDB_BORDER']) ?>
	font-family:	<?= $theme['ThemeSettings']['TOOLS_PDB_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['TOOLS_PDB_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['TOOLS_PDB_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['TOOLS_PDB_FONT_SIZE'] ?>;
	padding:	0px;
	margin:		0px;
	}

tr.tools_pdb_container {
	background-color: inherit;
	}

.tools_pdb_container_odd {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['TOOLS_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.tools_pdb_container_even {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['TOOLS_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.tools_pdb_container_odd:hover,
.tools_pdb_container_even:hover {
	color: <?= $theme['ThemeSettings']['TOOLS_PDB_HOVER_COLOUR'] ?>;
	background-color: <?= $theme['ThemeSettings']['TOOLS_PDB_HOVER_BKGD_COLOUR'] ?>;
	}

th.tools_pdb_container {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	padding:		0px 5px;
	text-align:		left;
	white-space:	<?= (($theme['ThemeSettings']['TOOLS_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal') ?>;
	}

td.tools_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	text-align:		right;
	white-space:	<?= (($theme['ThemeSettings']['TOOLS_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal') ?>;
	}

td.tools_pdb_container_selected {
	font-weight:	bold;
	}

td.tools_pdb_container input {
	width: 80%;
	font-size: 		<?= $theme['ThemeSettings']['TOOLS_PDB_FONT_SIZE'] ?>;
	}

p.tools_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	}

table.bodies_pdb_container {
	background-color: <?= $theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR'] ?>;
	color:		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['BODIES_PDB_BORDER']) ?>
	font-family:	<?= $theme['ThemeSettings']['BODIES_PDB_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['BODIES_PDB_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_SIZE'] ?>;
	padding:	1px;
	margin:		0px;
	}

tr.bodies_pdb_container {
	background-color: inherit;
	}

.bodies_pdb_container_odd {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.bodies_pdb_container_even {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.bodies_pdb_container_odd:hover,
.bodies_pdb_container_even:hover {
	color: <?= $theme['ThemeSettings']['BODIES_PDB_HOVER_COLOUR'] ?>;
	background-color: <?= $theme['ThemeSettings']['BODIES_PDB_HOVER_BKGD_COLOUR'] ?>;
	}

th.bodies_pdb_container:hover {
	font-style: italic;
	white-space:	<?= (($theme['ThemeSettings']['BODIES_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal') ?>;
	}

th.bodies_pdb_container {
	background-color: inherit;
	font-family:	inherit;
	padding:		0px 5px;
	font-weight:	bold;
	text-align:		left;
	white-space:	<?= (($theme['ThemeSettings']['BODIES_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal') ?>;
	}

td.bodies_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	text-align:		right;
	white-space:	<?= (($theme['ThemeSettings']['BODIES_PDB_NOWRAP_BOOL'] == 'true') ? 'nowrap':'normal') ?>;
	}

td.bodies_pdb_container_selected {
	font-weight:	bold;
	}

td.bodies_pdb_container input {
	width: 80%;
	font-size: 		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_SIZE'] ?>;
	}

p.bodies_pdb_container,
li.bodies_pdb_container {
	background-color: inherit;
	color:			inherit;
	padding:		0px 5px;
	font-family:	inherit;
	}

div.page_container {
	background-color: inherit;
	color:		inherit;
	border-width:		0px;
	font-family:	inherit;
/*	padding:	2px;*/
/*	margin:		0px;*/
	width:		100%;
/*	height:		100%; */
	}

table.page_body {
<?php if(!empty($theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE'])) { ?>
	/*background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['PAGE_BODY_BKGD_IMAGE']) ?>;*/
	/*background-repeat: no-repeat;*/
	/*background-attachment: local;*/
	/*background-size: 100% 100%;*/
<?php } else { ?>
	/*background-color: <?= $theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'] ?>;*/
<?php } // else ?>
	/*<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_BODY_BORDER']) ?>*/
	/*color:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR'] ?>;*/
	font-family:	<?= $theme['ThemeSettings']['PAGE_BODY_FONT_FAMILY'] ?>;
	font-size:	<?= $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['PAGE_BODY_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_WEIGHT'] ?>;
	padding:	0px;
	margin:		0px;
	width:		100%;
	}

/*table.page_body tr,*/
tr.page_body {
	background-color: inherit;
	}

.page_body_odd {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.page_body_even {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['PAGE_BODY_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

table.page_body th,
th.page_body {
	font-family:	<?= $theme['ThemeSettings']['TH_FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['TH_FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['TH_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['TH_FONT_WEIGHT'] ?>;
	background-color: inherit;
	text-align:		left;
	padding-top:	7px;
	}

.page_body {	/* used by online html editor */
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE'] ?>;
	padding:		<?= $theme['ThemeSettings']['PAGE_BODY_PADDING'] ?>;
<?= get_body_copy_css($theme) ?>
	}

.page_body_msgs {
	background-color: inherit;
	padding:	0px;
	margin:		0px;
/*	float:		left; */
	}

td.page_body_msgs {
	padding:	5px;
	margin:		3px;
	}

td.page_body, p.page_body, li.page_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE'] ?>;
	padding:		5px;
	}

span.page_body,
a.page_body, a.page_body:active, a.page_body:link, a.page_body:visited {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['PAGE_BODY_FONT_SIZE'] ?>;
	padding:		5px;
	}

pre {
	font-family: monospace, Courier, "Courier New";
	font-size: 10px;
	font-style: italic;
	overflow-x: hidden;
	}

.page_body_pre,
pre.page_body {
/*	width: 95%;*/
/*	overflow-x: auto;*/
/*	scroll-behavior: auto;*/
/*	display: block;*/
	}

.row_inline,
div.row_inline {
	white-space: nowrap;
	vertical-align: top;
	text-align: left;
	}
td.row_inline {
	/*white-space: nowrap;*/
	vertical-align: top;
	text-align: left;
	}

.row_inline div,
.row_inline span,
.row_inline label,
.row_inline select,
.row_inline div,
div.row_inline div,
div.row_inline span,
div.row_inline label,
div.row_inline select,
div.row_inline div,
td.row_inline div,
td.row_inline span,
td.row_inline label,
td.row_inline select,
td.row_inline div {
	display: inline-block;
	}

p.page_database {
	background-color: <?= $theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'] ?>;
	color:		<?= $theme['ThemeSettings']['PAGE_DB_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['PAGE_DB_FONT_FAMILY'] ?>;
	font-size:	<?= $theme['ThemeSettings']['PAGE_DB_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['PAGE_DB_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['PAGE_DB_FONT_WEIGHT'] ?>;
	padding:	0px;
	margin:		0px;
	}
	
table.page_database {
	background-color: <?= $theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_DB_BORDER']) ?>
	color:		<?= $theme['ThemeSettings']['PAGE_DB_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['PAGE_DB_FONT_FAMILY'] ?>;
	font-size:	<?= $theme['ThemeSettings']['PAGE_DB_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['PAGE_DB_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['PAGE_DB_FONT_WEIGHT'] ?>;
	padding:	0px;
	margin:		0px;
	width:		100%;
	}

tr.page_database_sticky_heading {
	position: sticky;
	top: 1px;
	background-color: <?= $theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'] ?>;
	z-index: 200;
	}

tr.page_database {
	background-color: inherit;
	}

.page_database_odd {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.page_database_even {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

.page_database_odd:hover,
.page_database_even:hover {
	background-color: <?= $theme['ThemeSettings']['PAGE_DB_HOVER_BKGD_COLOUR'] ?>;
	}

td.page_database,
td.page_database_odd,
td.page_database_even {
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_DB_CELL_BORDER']) ?>
	vertical-align: middle;
	text-align: center;
	word-wrap: normal;
	padding: 5px 0px;
	}
th.page_database {
	font-family:	<?= $theme['ThemeSettings']['TH_FONT_FAMILY'] ?>;
	font-size:		<?= $theme['ThemeSettings']['TH_FONT_SIZE'] ?>;
	font-style:		<?= $theme['ThemeSettings']['TH_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['TH_FONT_WEIGHT'] ?>;
	background-color: inherit;
	text-align:		center;
	padding-top:	7px;
	}

.page_database {	/* used by online html editor */
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['PAGE_DB_FONT_SIZE'] ?>;
	padding:		<?= $theme['ThemeSettings']['PAGE_DB_PADDING'] ?>;
<?= get_body_copy_css($theme) ?>
	}

.page_database_msgs {
	background-color: inherit;
	padding:	0px;
	margin:		0px;
/*	float:		left; */
	}

td.page_database_msgs {
	background-color: inherit;
	border-radius: 0.5em;
	border:		2px solid grey;
	padding:	3px;
	margin:		3px;
	float:		left;
	}

td.page_database, td.page_database_number, li.page_database {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['PAGE_DB_FONT_SIZE'] ?>;
	padding:		5px;
	}

.page_database_text,
td.page_database_text {
	text-align: left;
	}

.page_database_number,
td.page_database_number {
	text-align: right;
	}

th.page_database {
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_DB_CELL_BORDER']) ?>
	text-align: center;
	}

span.page_database,
a.page_database, a.page_database:active, a.page_database:link, a.page_database:visited {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['PAGE_DB_FONT_SIZE'] ?>;
	padding:		5px;
	}

.page_database_pre,
pre.page_database {
	font-family: monospace, Courier, "Courier New";
	font-size: <?= $theme['ThemeSettings']['PAGE_DB_FONT_SIZE'] ?>;
	font-style: italic;
	}

.page_database select,
.page_database input,
select.page_database,
input.page_database {
	text-align: left;
	}

div.page_database,
span.page_database {
	background-color:	<?= $theme['ThemeSettings']['PAGE_DB_BKGD_COLOUR']; ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_DB_BORDER']) ?>
	border-radius:		<?= $theme['ThemeSettings']['PAGE_DB_BORDER_RADIUS']; ?>;
	color:				<?= $theme['ThemeSettings']['PAGE_DB_FONT_COLOUR']; ?>;
	padding:			<?= $theme['ThemeSettings']['PAGE_DB_PADDING']; ?>;
	}

div.page_database_panel,
span.page_database_panel {
	background-color:	<?= $theme['ThemeSettings']['PAGE_DB_PAN_BKGD_COLOUR']; ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_DB_PAN_BORDER']) ?>
	border-radius:		<?= $theme['ThemeSettings']['PAGE_DB_PAN_BORDER_RADIUS']; ?>;
	color:				<?= $theme['ThemeSettings']['PAGE_DB_PAN_FONT_COLOUR']; ?>;
	padding:			<?= $theme['ThemeSettings']['PAGE_DB_PAN_PADDING']; ?>;
	}

div.col_DB_head {
	white-space: normal;
	}

div.col_DB_head div {
	display: inline-block;
	}

img.col_DB_head {
	height: 10px;
	padding: 0px;
	}

table.section_body {
	background-color: <?= $theme['ThemeSettings']['SECTION_BKGD_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['SECTION_BORDER']) ?>
	color:		<?= $theme['ThemeSettings']['SECTION_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['SECTION_FONT_FAMILY'] ?>;
	font-size:	<?= $theme['ThemeSettings']['SECTION_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['SECTION_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['SECTION_FONT_WEIGHT'] ?>;
	padding:	0px;
	margin:		2px;
	width:		100%;
	}

tr.section_body {
	background-color: inherit;
	}

th.section_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	font-style:		normal;
	font-size:		inherit;
	text-align:		left;
	padding:		0px 5px;
	}

td.section_body, span.section_body,
a.section_body,  a.section_body:active, a.section_body:link, a.section_body:visited,
h1.section_body, h2.section_body, h3.section_body  {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['SECTION_FONT_SIZE'] ?>;
	padding:		0px 2px;
	}

td.section_body > span,
td.section_body > div {
/*	overflow-y: auto;*/
/*	-webkit-transition: all 0.25s ease-in-out;
	-moz-transition: all 0.25s ease-in-out;
	-ms-transition: all 0.25s ease-in-out;
	-o-transition: all 0.25s ease-in-out;
	transition: all 0.25s ease-in-out;*/
/*	max-height: 0;*/
	padding-bottom: 5px;
	}

table.link_body {
	background-color: <?= $theme['ThemeSettings']['LINK_BKGD_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['LINK_BORDER']) ?>
	color:		<?= $theme['ThemeSettings']['LINK_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['LINK_FONT_FAMILY'] ?>;
	font-size:	<?= $theme['ThemeSettings']['LINK_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['LINK_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['LINK_FONT_WEIGHT'] ?>;
	padding:	0px;
	margin:		0px;
	width:		100%;
	}

tr.link_body {
	background-color: inherit;
	}

th.link_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	bold;
	font-style:		normal;
	font-size:		inherit;
	text-align:		left;
	padding:		0px 5px;
	}

td.link_body, span.link_body, div.link_body,
a.link_body, a.link_body:active, a.link_body:link, a.link_body:visited,
h1.link_body, h2.link_body, h3.link_body {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	normal;
	font-size:		<?= $theme['ThemeSettings']['LINK_FONT_SIZE'] ?>;
	padding:		2px 2px;
	}
td.link_body {
	text-align: justify;
	}
span.link_body,
div.link_body {
	display: inline-block;
	border: 1px solid <?php list($w,$s,$c) = explode(' ',$theme['ThemeSettings']['LINK_BORDER']); echo $c; // just colour ?>;
	border-radius: 3px;
	margin: 2px 1px;
	vertical-align: top;
	text-align: center;
	}
span.link_body_mt,
div.link_body_mt {
	display: inline-block;
	margin: 2px 1px;
	}
.link_body_odd {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(false,$theme['ThemeSettings']['LINK_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}
.link_body_even {
	background-color: <?= Ccms_options::get_row_bkgnd_colour(true,$theme['ThemeSettings']['LINK_BKGD_COLOUR'],$theme['ThemeSettings']['ODD_EVEN_ROW_CHG']) ?>;
	}

div.cms_select_filtered {
	display: inline-block;
	}

.cms_page_sitemap {
	background-color: inherit;
	font-family:	inherit;
	font-weight:	inherit;
	font-style:		italic;
	margin: 0px 0px 0px 25px;
	}

div.cms_hilite_selected,
td.cms_hilite_selected {
	border: 3px solid greenyellow;
	padding: 5px;
	border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
<?= get_body_copy_css($theme) ?>
	-webkit-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
/*	-moz-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>; */
	}

.cms_msg_brief {
	font-size:		0.8em;
	}

span.cms_msg_info, div.cms_msg_info, p.cms_msg_info,
span.cms_msg_debug, div.cms_msg_debug, p.cms_msg_debug,
span.cms_msg_required, div.cms_msg_required, p.cms_msg_required,
span.cms_msg_success, div.cms_msg_success,
span.cms_msg_warning, div.cms_msg_warning,
span.cms_msg_error, div.cms_msg_error {
	font-family:	inherit;
	font-style:		italic;
	font-size:		<?= $theme['ThemeSettings']['MSG_FONT_SIZE'] ?>;
	white-space:	normal;
	}

span.cms_msg_debug, div.cms_msg_debug, p.cms_msg_debug {
	background-color: darkgrey;
	font-weight:	normal;
	color:			white;
	}

span.cms_msg_info, div.cms_msg_info, p.cms_msg_info {
	background-color: white;
	font-weight:	normal;
	color:			black;
	}

span.cms_msg_required, p.cms_msg_required,
div.cms_msg_required {
	background-color: ghostwhite;
	font-weight:	normal;
	color:			black;
	}

span.cms_msg_success,
div.cms_msg_success {
	background-color: greenyellow;
	font-weight:	normal;
	color:			black;
	}

span.cms_msg_warning,
div.cms_msg_warning {
	background-color: yellow;
	font-weight:	bold;
	color:			black;
	}

span.cms_msg_error,
div.cms_msg_error {
	background-color: red;
	font-weight:	bold;
	color:			white;
	}

div.cms_msg_stack {
	display: block;
	visibility: visible;
	font-family:	inherit;
	font-style:		inherit;
	font-size:		<?= $theme['ThemeSettings']['MSG_FONT_SIZE'] ?>;
	min-width: 100px !important;
	max-width: 60%;
	white-space: nowrap !important;
	position: fixed;
	right: <?= (!Ccms::show_right_column() ? '0px':$theme['ThemeSettings']['RIGHT_WIDTH']) ?>;
	margin-right: 10px;
	margin-top: 10px;
	top:	<?= $mh . 'px' ?>;   /* Height of the header + navbar + 5 */
	z-index: 10;
	background-color: <?= $theme['ThemeSettings']['MSG_BKGD_COLOUR'] ?>;
	color:		<?= $theme['ThemeSettings']['MSG_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['MSG_BORDER']) ?>
	border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
<?= get_body_copy_css($theme) ?>
	-webkit-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
/*	-moz-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>; */
	overflow-y: auto;
	max-height: 75%;
	}

span.cms_msg_closebtn {
	display: inline-block;
	margin-left: 0px;
	color: black;
	font-weight: bold;
	/*float: right;*/
	font-size: 2.0em;
	line-height: 20px;
	cursor: pointer;
	transition: 0.3s;
	vertical-align: top;
	}

span.cms_msg_closebtn:hover {
	text-decoration: underline;
	}

div.cms_msg_table {
	display: inline-block;
/*	width: calc(100% - 30px);*/	}

div.cms_msg_alert {
	padding: 10px;
	}

.cms_panel_block_outer {
	background-color: inherit;
	color:		inherit;
	font-family: inherit;
	font-size: inherit;
	font-weight: inherit;
	cursor: inherit;
	text-decoration: inherit;
	position: relative;
	margin: 0px 5px;
	}

.cms_panel_block_inner {	/* not a hover block, onclick JS to toggle */
	display: none;
	background-color: <?= $theme['ThemeSettings']['BODIES_PDB_BKGD_COLOUR'] ?>;
	color:		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['BODIES_PDB_BORDER']) ?>
	border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
	font-family:	<?= $theme['ThemeSettings']['BODIES_PDB_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['BODIES_PDB_FONT_STYLE'] ?>;
	font-weight:		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_WEIGHT'] ?>;
	font-size:		<?= $theme['ThemeSettings']['BODIES_PDB_FONT_SIZE'] ?>;
/*	min-width: 500px; */
	width: auto;
	height: auto;
	position: absolute;
	right: -15px;
/*	left: 0px;*/
	top: 20px;
	padding: 3px;
/*	margin-left: 0px;*/
	cursor: default;
/*	outline: none; */
	z-index: 830;
	text-decoration: none;
	float: left;
	}

.cms_hover_block_outer,
.cms_sub_hover_block_outer {
	background-color: inherit;
	color:		inherit;
	font-family: inherit;
	font-size: inherit;
	font-weight: inherit;
	cursor: inherit;
	text-decoration: inherit;
	position: relative;
	margin: 0px 5px;
}

.cms_hover_block_outer > span,
.cms_sub_hover_block_outer > span,
.cms_hover_block_outer > div,
.cms_sub_hover_block_outer > div {
	/*visibility: hidden;*/
	display: none;
	/*opacity: 0;*/
}

.cms_sub_hover_block_outer:hover > span,
.cms_hover_block_outer:hover > span,
.cms_sub_hover_block_outer:hover > div,
.cms_hover_block_outer:hover > div {
	/*visibility: visible;*/
	display: block;
	/*opacity: 1;*/
}

.cms_hover_block_inner,
.cms_sub_hover_block_inner {
	display: block;
/* on tablet devices is assisted by onclick="return true" */
	min-width: <?= (($theme['ThemeSettings']['NAV_BAR_BOOL'] != 'true') ? '130px':'130px') ?>;
	height: auto;
	border-radius: 0.5em;
	position: absolute;
	right: -15px;
/*	left: 0px;*/
	top: 10px;
	padding: 3px;
/*	margin-left: 0px;*/
/*	white-space: normal;*/
	cursor: default;
	color: <?= $theme['ThemeSettings']['PAGE_BODY_FONT_COLOUR'] ?>;
	font-family: inherit;
	font-size: inherit;
	font-weight: normal;
	outline: none;
	z-index: 830;
	text-decoration: none;
	float: left;
	white-space: normal;
	overflow: visible;
}
.cms_sub_hover_block_inner {
	/*position: relative;*/
	<?php
		echo (($theme['ThemeSettings']['NAV_BAR_BOOL'] == 'true') ? 'right: 65px':
		(($theme['ThemeSettings']['RIGHT_COLUMN_BOOL'] == "true") ? 'right: 65px':'left: 65px')) 
	?>;
}

div.cms_title_tooltip {
	transition: opacity 0.3s;
	display:	block;
	background:	<?= $theme['ThemeSettings']['TOOLTIP_BKGD_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['TOOLTIP_BORDER']) ?>
	font-family:	<?= $theme['ThemeSettings']['FOOTER_FONT_FAMILY'] ?>;
	font-style: <?= $theme['ThemeSettings']['TOOLTIP_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['TOOLTIP_FONT_WEIGHT'] ?>;
	font-size:	<?= $theme['ThemeSettings']['TOOLTIP_FONT_SIZE'] ?>;
	color:		<?= $theme['ThemeSettings']['TOOLTIP_FONT_COLOUR'] ?>;
	border-radius: <?= $theme['ThemeSettings']['TOOLTIP_BORDER_RADIUS'] ?>;
<?= get_body_copy_css($theme,false) ?>
	-webkit-border-radius: <?= $theme['ThemeSettings']['TOOLTIP_BORDER_RADIUS'] ?>;
/*	-moz-border-radius: <?= $theme['ThemeSettings']['TOOLTIP_BORDER_RADIUS'] ?>; */
	padding:	5px;
	margin:		0px;
	z-index:	840;
	position:	relative;
	}

span.cms_title_tooltip {
	}

/* navigation bar */
div.cms_nav_bar {
<?php if(!empty($theme['ThemeSettings']['NAV_BAR_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['NAV_BAR_BKGD_COLOUR'] ?>;
<?php } // else ?>
	list-style:	none;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['NAV_BAR_BORDER']) ?>
	border-radius: <?= $theme['ThemeSettings']['NAV_BAR_BORDER_RADIUS'] ?>;
	z-index:	100;
	}

ul.cms_nav_bar {
	min-height:	<?= $theme['ThemeSettings']['NAV_BAR_HEIGHT'] ?>;
	width: 100%;
	margin: 0;
	list-style-type: none;
/*	list-style:	none; */
	padding: 0;
	/*overflow:	visible;*/
	flex-wrap: wrap;
	flex-direction: row;
/*	justify-content: flex-end;*/
	align-items: center;
	cursor: default;
	display: flex;
/*	display: inline-block;*/
}

@media only screen and (max-width: 600px) {
	ul.cms_nav_bar {
		margin: 70px 0 0 0;
	}
}

li.cms_nav_bar, li.cms_nav_bar_on  {
<?php if(!empty($theme['ThemeSettings']['NAV_BAR_ELEM_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_ELEM_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_BKGD_COLOUR'] ?>;
<?php } // else ?>
	list-style:	none;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['NAV_BAR_ELEM_BORDER']) ?>
	border-radius: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_BORDER_RADIUS'] ?>;
<?= get_body_copy_css($theme,false) ?>
	-webkit-border-radius: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_BORDER_RADIUS'] ?>;
/*	-moz-border-radius: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_BORDER_RADIUS'] ?>; */
	color:		<?= $theme['ThemeSettings']['NAV_BAR_ELEM_FONT_COLOUR'] ?>;
	font-family:	<?= $theme['ThemeSettings']['NAV_BAR_ELEM_FONT_FAMILY'] ?>;
	font-size:	<?= $theme['ThemeSettings']['NAV_BAR_ELEM_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_FONT_STYLE'] ?>;
	font-weight:	<?= $theme['ThemeSettings']['NAV_BAR_ELEM_FONT_WEIGHT'] ?>;
	text-align:		center;
/*	float: left; */
	padding-left: 7px;
	padding-right: 7px;
	padding-top: 2px;
	padding-bottom: 2px;
	display: inline;
	margin: 2px;
	margin: 0 5px 0 5px;
}

li.cms_nav_bar {
	text-decoration:	none;
}

li.cms_nav_bar_on,
a.cms_nav_bar_on {
	text-decoration:	underline;
}

li.cms_nav_bar:hover, li.cms_nav_bar_on:hover {
<?php if(!empty($theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_BKGD_COLOUR'] ?>;
<?php } // else ?>
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_BORDER']) ?>
	color:		<?= $theme['ThemeSettings']['NAV_BAR_ELEM_HOVER_FONT_COLOUR'] ?>;
}

a.cms_nav_bar a.cms_nav_bar:active, a.cms_nav_bar:link, a.cms_nav_bar:visited {
	display: inline-block;
	font-family:	inherit;
	font-size:		inherit;
	color:			inherit;
	text-decoration: none;
}

a.cms_nav_bar:hover {
	font-family:	inherit;
	font-size:		inherit;
	color:			inherit;
	/* color:			<?= $theme['ThemeSettings']['ANCHOR_HOVER_COLOUR'] ?>; */
	text-decoration: underline;
	}

div.page_middle {	/* contains left column, application body and right column across the viewport */
	display: flex;
	flex-direction: row;
	width: 100%;
	}

img.cms_nav_bar {
	border:	0;
	padding: 0px;
	margin: 0px 5px 0px 0px;
	height: <?= $theme['ThemeSettings']['NAV_BAR_ELEM_ICON_HEIGHT'] ?>;
	vertical-align: bottom;
	}

/* social media */
span.social_media {
	background:		inherit;
	visibility: visible;
	}

span.social_media_left {
	background:		inherit;
	visibility: visible;
	float:		left;
	}

span.social_media_right {
	background:		inherit;
	visibility: visible;
	float:		right;
	}

span.social_media_center_left {
	background:		inherit;
	visibility: visible;
	opacity:	0.9;
	position:	fixed;
	left:		5px;
	top:		40%;
	}

span.social_media_center_right {
	background:		inherit;
	visibility: visible;
	opacity:	0.9;
	position:	fixed;
	right:		10px;
	top:		40%;
	}

table.social_media {
<?php if(!empty($theme['ThemeSettings']['SM_BKGD_IMAGE'])) { ?>
	background-image: <?= Ccms::locate_image_url4css(ETC_WS_CSS_DIR,ETC_WS_BACKGROUNDS_DIR,$theme['ThemeSettings']['SM_BKGD_IMAGE']) ?>;
	background-repeat: no-repeat;
	background-attachment: local;
	background-size: 100% 100%;
<?php } else { ?>
	background-color: <?= $theme['ThemeSettings']['SM_BKGD_COLOUR'] ?>;
<?php } // else ?>
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['SM_BORDER']) ?>
	border-radius: <?= $theme['ThemeSettings']['SM_BORDER_RADIUS'] ?>;
	font-family:	inherit;
	font-style:		inherit;
	font-weight:	inherit;
	font-size:		inherit;
	color:			inherit;
	padding:		0px;
	margin:			0px;
/*	width:			100%;*/
<?= get_body_copy_css($theme,false) ?>
	-webkit-border-radius: 1em;
/*	-moz-border-radius: 1em; */
	}

tr.social_media {
	background:		inherit;
	padding:		0px;
	margin:			0px;
	border-width:	0px;
	}

th.social_media, td.social_media {
	background:		inherit;
	color:			inherit;	/* show the inherited, try red */
	font-family:	inherit;
	font-weight:	inherit;
	font-size:		inherit;
	padding:		2px;
	margin:			0px;
	border-width:	0px;
	}

.cms_legal {
	background-color: <?= $theme['ThemeSettings']['PAGE_LEGAL_BKGD_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['PAGE_LEGAL_BORDER']) ?>
	color: <?= $theme['ThemeSettings']['PAGE_LEGAL_FONT_COLOUR'] ?>;
	font-family: <?= $theme['ThemeSettings']['PAGE_LEGAL_FONT_FAMILY'] ?>;
	font-size: <?= $theme['ThemeSettings']['PAGE_LEGAL_FONT_SIZE'] ?>;
	font-style: <?= $theme['ThemeSettings']['PAGE_LEGAL_FONT_STYLE'] ?>;
	font-weight: <?= $theme['ThemeSettings']['PAGE_LEGAL_FONT_WEIGHT'] ?>;
	padding: <?= $theme['ThemeSettings']['PAGE_LEGAL_PADDING'] ?>;
	border-radius: <?= $theme['ThemeSettings']['PAGE_LEGAL_BORDER_RADIUS'] ?>;
	margin: 5px;
	}

div.cms_ddwn_outer {
	position: relative;
	display: inline-block;
	}

div.cms_ddwn_inner {
	display: none;
	position: relative;
	background-color: white;
	color: black;
	min-width: 160px;
	box-shadow: 0px 5px 8px 0px rgba(0,0,0,1);
	padding: 5px 7px;
	z-index: 4;
	font-size: 0.75em;
	}

div.cms_ddwn_outer:hover div.cms_ddwn_inner {
	display: block;
	}

img.cms_ddwn_img {
	height: 18px;
	}

img.eye_img {
	height: 20px;
	}

div.cms_box_confirm {
	display: block;
	visibility: visible;
	font-family:	inherit;
	font-style:		inherit;
	font-size:		<?= $theme['ThemeSettings']['MSG_FONT_SIZE'] ?>;
	background-color: <?= $theme['ThemeSettings']['MSG_BKGD_COLOUR'] ?>;
	color:		<?= $theme['ThemeSettings']['MSG_FONT_COLOUR'] ?>;
	<?= Ccms_options::get_border_attribute($theme['ThemeSettings']['MSG_BORDER']) ?>
	border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
<?= get_body_copy_css($theme) ?>
	-webkit-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>;
/*	-moz-border-radius: <?= $theme['ThemeSettings']['BORDER_RADIUS'] ?>; */
	padding: 10px;
	text-align: center;
	min-width: 150px !important;
	/*max-width: 60%;*/
	white-space: nowrap !important;

	position: fixed;
	top: 50%;
	left: 50%;
	margin: 0;
	transform: translate(-50%,-50%);
	}
div.cms_box_confirm button {
	margin: 0 10px;
	}	

/* eof */

