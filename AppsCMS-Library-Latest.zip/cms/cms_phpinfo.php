<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_phpinfo.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

phpinfo();
?>
