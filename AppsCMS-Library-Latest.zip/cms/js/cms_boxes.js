/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_boxes.js 3137 2023-02-14 11:20:25Z robert0609 $
 */

/*
 * Clunky !!!!!
 */

function Ccms_box () {
	
	this._merge_ctls = function(a1,a2) {	// mearge a2 into a1
		for(const key in a2) {
			if(typeof a2[key] === 'object') a1[key] = this._merge_ctls(a1[key],a2[key]);	// recurse
			else a1[key] = a2[key];
			} // for
		return a1;
		} // _merge_ctls()

	this._get_controls = function(def_ctls,controls) {
		if(controls) {
			if(typeof controls !== 'object') { 
				alert('Code Error: Ccms_box.controls are not an object array !');
				return def_ctls;
				}
			ctls = this._merge_ctls(def_ctls,controls);
			} // if
		else ctls = def_ctls;
		return ctls;
		} // _get_parent()

	this._get_parent = function(ctls) {
		var parent_dlg = false;
		if(ctls.dlg_id) parent_dlg = document.getElementById(ctls.dlg_id);
		if(!parent_dlg) parent_dlg = document.body;
		return parent_dlg;
		} // _get_parent()

	this.confirm_dlg = function(controls) {
		const def_ctls = { 
				'message': ' Are you sure ?', 
				'head': '', 
				'id': '', 
				'class': 'cms_box_confirm',
				'ack': { 'text': 'Ok', 'func': null, 'form_elem': null, },
				'nak': { 'text': 'Cancel', 'func': null, },
				'parent_dlg': false,
				};
		var ctls = this._get_controls(def_ctls,controls);
		var parent_dlg = this._get_parent(ctls);
		
		const newDiv = document.createElement("div");
		newDiv.className = ctls.class;
		if(ctls.head.length > 0) {
			const newHead = document.createElement("h3");
			const newHeadContent = document.createTextNode(ctls.head);
			newHead.appendChild(newHeadContent);
			newDiv.insertBefore(newHead,null);
			} // if
		if(ctls.id.length > 0) {
			newDiv.id = ctls.id;
			} // if
		const newP = document.createElement("p");
		const newPContent = document.createTextNode(ctls.message);
		newP.appendChild(newPContent);
		newDiv.insertBefore(newP,null);

		const okButton = document.createElement("button");
		const okButtonContent = document.createTextNode(ctls.ack.text);
		okButton.appendChild(okButtonContent);
		if(typeof ctls.ack.func == 'function')
			okButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); ctls.ack.func(); });
		else if((ctls.ack.form_elem) && (ctls.ack.form_elem == 'FORM'))
			okButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); ctls.ack.form_elem.submit(); });
		else okButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); });
		newDiv.insertBefore(okButton,null);

		const cancelButton = document.createElement("button");
		const cancelButtonContent = document.createTextNode(ctls.nak.text);
		cancelButton.appendChild(cancelButtonContent);
		if(typeof ctls.nak.func == 'function') 
			cancelButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); ctls.nak.func(); });
		else cancelButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); });
		newDiv.insertBefore(cancelButton,null);
		// else it is an alerta box ??

		// put it up
		parent_dlg.insertBefore(newDiv,null);
		} // confirm_dlg
	
	this.prompt_dlg = function(controls) {
		const def_ctls = { 
				'message': ' Are you sure ?', 
				'head': '', 
				'id': '', 
				'class': 'cms_box_confirm',
				'ack': { 'text': 'Ok', 'input_elem': null, },
				'nak': { 'text': 'Cancel', },
				'parent_dlg': false,
				};
		var ctls = this._get_controls(def_ctls,controls);
		var parent_dlg = this._get_parent(ctls);
		
		const newDiv = document.createElement("div");
		newDiv.className = ctls.class;
		if(ctls.head.length > 0) {
			const newHead = document.createElement("h3");
			const newHeadContent = document.createTextNode(ctls.head);
			newHead.appendChild(newHeadContent);
			newDiv.insertBefore(newHead,null);
			} // if
		if(ctls.id.length > 0) {
			newDiv.id = ctls.id;
			} // if
		const newP = document.createElement("p");
		const newPContent = document.createTextNode(ctls.message);
		newP.appendChild(newPContent);
		newDiv.insertBefore(newP,null);

		const newInput = document.createElement("input");
		newDiv.insertBefore(newInput,null);

		const okButton = document.createElement("button");
		const okButtonContent = document.createTextNode(ctls.ack.text);
		okButton.appendChild(okButtonContent);
		if((ctls.ack.form_elem) && (ctls.ack.input_elem == 'INPUT'))
			okButton.addEventListener('click',function() { ctls.ack.input_elem = newInput.value; parent_dlg.removeChild(newDiv); });
		else {
			console.log('Prompt dlg controls does not contain a valid input element.');
			} // else
		newDiv.insertBefore(okButton,null);

		const cancelButton = document.createElement("button");
		const cancelButtonContent = document.createTextNode(ctls.nak.text);
		cancelButton.appendChild(cancelButtonContent);
		cancelButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); });
		newDiv.insertBefore(cancelButton,null);
		// else it is an alerta box ??

		// put it up
		parent_dlg.insertBefore(newDiv,null);
		} // prompt_dlg
	
	this.alert_dlg = function(controls) {
		const def_ctls = { 
				'message': ' Are you sure ?', 
				'head': '', 
				'id': '', 
				'class': 'cms_box_confirm',
				'ack': { 'text': 'Ok', 'func': null, },
				'parent_dlg': false,
				};
		var ctls = this._get_controls(def_ctls,controls);
		var parent_dlg = this._get_parent(ctls);
		
		const newDiv = document.createElement("div");
		newDiv.className = ctls.class;
		if(ctls.head.length > 0) {
			const newHead = document.createElement("h3");
			const newHeadContent = document.createTextNode(ctls.head);
			newHead.appendChild(newHeadContent);
			newDiv.insertBefore(newHead,null);
			} // if
		if(ctls.id.length > 0) {
			newDiv.id = ctls.id;
			} // if
		const newP = document.createElement("p");
		const newPContent = document.createTextNode(ctls.message);
		newP.appendChild(newPContent);
		newDiv.insertBefore(newP,null);

		const okButton = document.createElement("button");
		const okButtonContent = document.createTextNode(ctls.ack.text);
		okButton.appendChild(okButtonContent);
		if(typeof ctls.ack.func == 'function')
			okButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); ctls.ack.func(); });
		else okButton.addEventListener('click',function() { parent_dlg.removeChild(newDiv); });
		newDiv.insertBefore(okButton,null);

		// put it up
		parent_dlg.insertBefore(newDiv,null);
		} // alert_dlg
	
} // Ccms_box()

// EOF

