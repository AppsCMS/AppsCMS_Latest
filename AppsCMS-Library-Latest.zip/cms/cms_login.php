<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_login.php 3049 2022-12-16 02:47:04Z robert0609 $
 */

if(!defined('WWW_CALL')) define('WWW_CALL',true);	// global for WWW recognition

require_once 'include/cms_top.php';

Ccms_auth::logout_user();

if(CMS_S_ALWAYS_LOGIN_BOOL) {
	if(!Ccms_auth::is_login_allowed()) {
		Ccms::addMsg('Possible conflict with login and login not allowed.','warn');
		exit(1);
		} // if
	} // if

if(!Ccms_auth::is_login_allowed()) {
	$url = Ccms_base::get_base_url(true) . Ccms::get_body_uri();

	header('Location: ' . $url);
	exit (0);
	} // if

$url = Ccms_base::get_base_url(true) . 'index.php?cms_action=cms_login';
if((Ccms::is_get_or_post('user')) && (!empty(Ccms::get_or_post('user')))) $url .= '&user=' . Ccms::get_or_post('user');
header('Location: ' . $url);
exit (0);
