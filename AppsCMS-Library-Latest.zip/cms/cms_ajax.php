<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_ajax.php 3248 2023-03-01 06:34:03Z robert0609 $
 */

if(!defined('AJAX_CALL')) define('AJAX_CALL',true);	// global for AJAX recognition

require_once 'include/cms_top.php';

if(Ccms::is_ajax()) {	// works with the js Ccms_ajax_ops class
	$ajax_ops = new Ccms_ajax_ops();
	} // if

require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';
