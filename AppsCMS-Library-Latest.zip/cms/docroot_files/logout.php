<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: logout.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

define('WWW_CALL',true);	// global for WWW recognition

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_logout.php';

