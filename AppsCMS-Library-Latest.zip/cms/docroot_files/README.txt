README.txt for cms/docroot_files/ directory.
============================================

This directory contains a copy of the default (DOCROOT) files.
Refer to technical manual for more information.

.eof.
