<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: index.php 3062 2022-12-26 05:28:55Z robert0609 $
 */

define('WWW_CALL',true);	// global for WWW recognition

// check/engage cms_sqsh.sqsh read only filesystem
require_once 'cms_lib_sqsh.php';

// a hook file
require_once 'cms/cms_index.php';

