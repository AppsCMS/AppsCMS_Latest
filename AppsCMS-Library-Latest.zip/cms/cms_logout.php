<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_logout.php 3049 2022-12-16 02:47:04Z robert0609 $
 */

if(!defined('WWW_CALL')) define('WWW_CALL',true);	// global for WWW recognition

require_once 'include/cms_top.php';

Ccms_auth::logout_user();

if(CMS_S_ALWAYS_LOGIN_BOOL) {
	$url = Ccms_base::get_base_url(true) . 'login.php';
	header('Location: ' . $url);
	exit (0);
	} // if
$url = Ccms_base::get_base_url(true) . 'index.php';
header('Location: ' . $url);
exit (0);
