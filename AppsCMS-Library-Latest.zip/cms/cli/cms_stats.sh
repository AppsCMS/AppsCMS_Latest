#!/bin/bash
# see Licence in cms/LICENCE.txt
# _SVN_build: $Id: cms_stats.sh 3288 2023-03-24 08:41:00Z robert0609 $
# get source code stats

function get_stats() { # $1=base_dir
	local TYPES="php js css sh html htm ini json"
	for T in $TYPES
	do
		# Print newline, word, and byte counts
		local RES="$((find -P "$1" -xdev -type f | egrep -i -v 'archived/|tmp/|temp/' | grep -E "\.${T}\$" | xargs cat ) | wc)"
		echo "$(echo "$1($T) $RES" | sed -e 's/\s\+/,/g' )"
		# echo ""
	done
} # get_stats()

DIRS=" \
	apps/ \
	cms/ \
	etc/ \
	./ \
"
echo "AppsCMS filesystem stats."
echo -e "Source,Lines,Words,Bytes"
for D in $DIRS
do
	get_stats "$D"
done

echo ""

# EOF
