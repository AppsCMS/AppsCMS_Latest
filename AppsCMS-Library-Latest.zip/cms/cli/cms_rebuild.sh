#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_rebuild.sh 3063 2022-12-26 09:10:56Z robert0609 $

# rebuild setup script for Applications Management System Library for PHP (AppsCMS)
# run from web root directory

BASE_DIR="$(pwd | sed 's|cms/cli||' )"
PROG="cms/cli/$(basename "$0")"
source cms/cli/cms_include.sh
# echo $(basename "$0") $@	# test

function help() { #
	echo "Usage: $PROG [-h|--help|help] [--set-perms|--no-perms (default)] [--use-json] [--squash-apps] [--repair-access] [--rebuild-ext-libs]"
	echo "  Where:"
	echo "    --set-perms - sets permissions (need sudo access, full sudo zoo is auto detected),"
	echo "    --no-perms - does not set permissions (default),"
	echo "    --use-json - to use cms.sqlite.json to rebuild db (if available)."
	echo "    --squash-apps - to build apps squash filesystem (used by dev's)."
	echo "    --repair-access - always replace access controls."
	echo "    --rebuild-ext-libs - rebuild external library class lists."
} # help()

pushd "$BASE_DIR" > /dev/null

# test php present
which php > /dev/null 2>&1
if [ $? -ne 0 ]; then
	out_msg "php or php-cli packages not installed." err
	exit 127
fi

# test php-cli present
php -v > /dev/null 2>&1
if [ $? -ne 0 ]; then
	out_msg "php-cli package not installed." err
	exit 127
fi

LOC_GROUP="$(ls -ld . | awk '{ print $4 }')"
HTTPD_USER="$(ps -A  -o user:20,comm | egrep '([a|A]pache|[h|H]ttpd)' | tail -n 1 | awk '{ print $1 }')"
if [ -z "$HTTPD_USER" ]; then
	out_msg "Web server is not running, web server group membership permissions not checked." warn
else
	HTTPD_GROUPS="$(id -G -n $HTTPD_USER)"
	CHK="$(echo "$HTTPD_GROUPS" | grep "$LOC_GROUP")"
	# echo HTTPD_USER=$HTTPD_USER	# test
	# echo HTTPD_GROUPS=$HTTPD_GROUPS	# test
	# echo LOC_GROUP=$LOC_GROUP	# test
	# echo CHK=$CHK	# test

	if [ -z "$CHK" ]; then
		out_msg "Web server is not part of the local group." err
		# exit 10
	fi
	# exit	# test
fi

SET_PERMS=0	# default to not set permisions (needs sudo)
is_sudoer
if [ $? -eq 0 ]; then SET_PERMS=1; fi	# in the sudo zoo

SQSH_D=0
if [ $SET_PERMS -gt 0 -a -f cms_lib_sqsh_sqsh ]; then SQSH_D=1; fi

USE_JSON=''	# default to not to use cms.sqlite.json to rebuild db
MK_APPS=0	# mksquashfs filesystems
REP_ACCESS=0
EXT_LIBS=0

while [ -n "$1" ]
do

	case "$1" in
		--no-perms)
			SET_PERMS=0
			;;
		--set-perms)
			if [ $SUZOO -gt 0 ]; then SET_PERMS=1; fi
			;;
		--use-json)
			USE_JSON='--use-json'
			# echo "Use JSON"	# test
			;;
		--squash-apps)
			MK_APPS=1
			;;
		--repair-access)
			REP_ACCESS=1
			;;
		--rebuild-ext-libs)
			EXT_LIBS=1
			;;
		*)
			help
			exit 0
			;;
	esac
	shift
done


CHK_DIRS="\
	apps \
	apps/bodies \
	etc/backgrounds \
	etc/icons \
	etc/images \
	etc/ini \
	etc/css \
	etc/ext \
	etc/sqlite \
	localtools \
	var/backups \
	var/cache \
	var/exports \
	var/gotcha \
	var/logs \
	var/sessions \
	var/Trash \
	var/variables \
"
for D in $CHK_DIRS
do
	if [ -n "$(findmnt "$D" | grep squash)" ]; then continue; fi	# squashfs mount
	if [ ! -d "$D" ]; then
		mkdir -p "$D"
		if [ $? -ne 0 ]; then
			out_msg "ERROR: cannot make \"$D\"."
			exit 2
		fi
	fi
done

if [ $SET_PERMS -eq 1 -a $SQSH_D -eq 0 ]; then
	cms/cli/cms_set_permissions.sh	# run to have the correct permissions.
	if [ $? -ne 0 ]; then
		out_msg "Failed to set permissions (1)." err
		# exit 2
	fi
fi

# check rewrite module enabled
if [ $SUZOO -gt 0 ]; then
	if [ -z "$($SUDO_BIN apachectl -M | grep rewrite)" ]; then
		out_msg 'Apache rewrite module is not enabled (no API operation). Run: sudo a2enmod rewrite.' 'err'
	fi
else
	out_msg 'Apache rewrite module not checked (not sudo).' 'warn'
fi

# check access control
if [ $REP_ACCESS -eq 0 ]; then
	cms/cli/cms_access_checks.sh
else
	cms/cli/cms_access_checks.sh --repair-access
fi

# backup settings
cms/cli/cms_backup_settings.sh > /dev/null

# update inis to V3.00
out_msg "If updating from a version less than V3.00, recommend running \"php cms/cli/upgraders/cms_upgrade_ini_V300.php\"." info
# php cms/cli/upgraders/cms_upgrade_ini_V300.php

# update apps to V3.00
out_msg "If updating from a version less than V3.00, recommend running \"cms/cli/upgraders/cms_upgrade_appsV300.sh\"." info
# cms/cli/upgraders/cms_upgrade_appsV300.sh	# > /dev/null

# update apps to V3.03
out_msg "If updating from a version less than V3.03, recommend running \"php cms/cli/upgraders/cms_upgrade_cms_configs_V303.php\"." info
# php cms/cli/upgraders/cms_upgrade_cms_configs_V303.php	# > /dev/null

# exit 0	# test

# rebuild
# php cms/cli/cms_rebuild.php $@
if [ $REP_ACCESS -eq 0 ]; then
	php cms/cli/cms_rebuild.php "$USE_JSON" --rebuild-ext-libs
else
	php cms/cli/cms_rebuild.php --repair-access "$USE_JSON" --rebuild-ext-libs
fi

if [ $SUZOO -gt 0 -a $SET_PERMS -eq 1 ]; then
	cms/cli/cms_set_permissions.sh	# run a second time to ensure new paths have the correct permissions.
	if [ $? -ne 0 ]; then
		out_msg "Failed to set permissions (2)." err
		# exit 2
	fi
fi

if [ $MK_APPS -eq 1 ]; then
	cms/cli/cms_wrap_apps.sh	# make apps squashfs filesystems
fi

popd > /dev/null

# EOF

