<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_cron_control.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('CRON_MODE',		true);	// tell configure

require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

require_once CMS_FS_INCLUDES_DIR . 'cms_auto_class_loader.php';
$cCRON = new Ccms_cron_control($argv,$argc);
exit(0);

// eof
