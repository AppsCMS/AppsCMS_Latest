#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_upgrade_appsV300.sh 3288 2023-03-24 08:41:00Z robert0609 $

# updates apps/ for changes in AppCMS State Machine variables. structure.

# At V3.00, following changes occurred.
# Important Changes from V3.00:
# The state monitor variables in Ccms_base_sm are now private static variables and now require getters as follows;
# 	for (Ccms|Ccms_base|self)::$www use (Ccms|Ccms_base|self)::is_www(),
# 	for (Ccms|Ccms_base|self)::$ajax use (Ccms|Ccms_base|self)::get_ajax(),
# 	for (Ccms|Ccms_base|self)::$api use (Ccms|Ccms_base|self)::is_api(),
# 	for (Ccms|Ccms_base|self)::$cli use (Ccms|Ccms_base|self)::is_cli(),
# 	for (Ccms|Ccms_base|self)::$cron use (Ccms|Ccms_base|self)::is_cron(),
# 	for (Ccms|Ccms_base|self)::$is_production use (Ccms|Ccms_base|self)::is_production(),
# 	for (Ccms|Ccms_base|self)::$can_test use (Ccms|Ccms_base|self)::can_test(),
# 	for (Ccms|Ccms_base|self)::$is_debug use (Ccms|Ccms_base|self)::is_debug(),
# 	for (Ccms|Ccms_base|self)::$is_rebuild use (Ccms|Ccms_base|self)::is_rebuild(),
# 	for (Ccms|Ccms_base|self)::$tablet_flg use (Ccms|Ccms_base|self)::is_tablet(),
# 	for (Ccms|Ccms_base|self)::$tiny_flg use (Ccms|Ccms_base|self)::is_tiny(),
# 	for (Ccms|Ccms_base|self)::$have_session use (Ccms|Ccms_base|self)::have_session(),
# 	for (Ccms|Ccms_base|self)::$tooltips_flg use (Ccms|Ccms_base|self)::use_tooltips(),
# 	for (Ccms|Ccms_base|self)::$block_html use (Ccms|Ccms_base|self)::use_block_html(),
# 	for (Ccms|Ccms_base|self)::$moz_4_flg use (Ccms|Ccms_base|self)::is_moz_4(),
# 	for (Ccms|Ccms_base|self)::$fox_flg use (Ccms|Ccms_base|self)::is_firefox(),
# 	for (Ccms|Ccms_base|self)::$chrome_flg use (Ccms|Ccms_base|self)::is_chrome(),
# 	for (Ccms|Ccms_base|self)::$safari_flg use (Ccms|Ccms_base|self)::is_safari(),
# 	for (Ccms|Ccms_base|self)::$edge_flg use (Ccms|Ccms_base|self)::is_ms_edge(),
# 	for (Ccms|Ccms_base|self)::$browser_html5 use (Ccms|Ccms_base|self)::is_html5(),
# 	for (Ccms|Ccms_base|self)::$can_test use (Ccms|Ccms_base|self)::can_test(),
# 	for (Ccms|Ccms_base|self)::$version_str use (Ccms|Ccms_base|self)::get_version_str().
# 	for (Ccms|Ccms_base|self)::$has_ssl_available use (Ccms|Ccms_base|self)::get_version_str(),
# 	for (Ccms|Ccms_base|self)::$ssl_required use (Ccms|Ccms_base|self)::is_ssl_required(),
# 	for (Ccms|Ccms_base|self)::$ssl_in_use use (Ccms|Ccms_base|self)::is_ssl_inuse(),
# These getters are also setters by passing a non null parameter.
# (Ccms|Ccms_base|self)::is_browser_html5() replaced by (Ccms|Ccms_base|self)::is_html5().
# Refer to ReleaseNotes.md for more information.

FVERSION="V3.00-RC4"
DT="$(date '+%Y%m%d-%H%M%S')"	# includes seconds
DLOG="var/logs"
LOG="${DLOG}/CLI_cms-upgrader-$(date '+%Y%m%d').log"
if [ ! -d "$DLOG" ]; then mkdir -p "$DLOG"; fi
REPLACE=0
SCHBASE="./apps"
EXCLUDE=".svn/|.git/|.vscode/|nbproject/|/cms/|/localtools/|/lib/|/var/|/tmp/"
USAGE="
USAGE: $(basename $0) [-d|--directory dir (default scan directory ./) [-r|--replace] [-h|--help]\n \
	Upgrade PHP code to $FVERSION.
	Excluded: \"$EXCLUDE\".
	Note: This upgrader does not upgrade AppsCMS, it assumes that cms/ is updated already.
"

source cms/cli/cms_include.sh

function find_replace_static_code() { # $1=file $2=find $3=replacement
	local F="$1"
	local FND="$2"
	local REP="$3"
	local PRE='::'	# only for class::FND or self::FND
	local DT="$(date '+%Y%m%d-%H%M%S')"
	local PAT="${PRE}\$${FND}"
	# echo "PAT=$PAT"	# test
	local FOUND="$(grep -nH "$PAT" "$F" 2> /dev/null)"
	if [ -z "$FOUND" ]; then
		echo "\"${PRE}\$${FND}\" not found in \"$F\" ($DT)." | tee -a "$LOG"
		return 1
	fi

	if [ $REPLACE -eq 0 ]; then
		echo "Found \"${PRE}\$$FND\" to be replaced \"${PRE}${REP}()\" in \"$F\"." | tee -a "$LOG"
		return 0
	fi

	echo "Starting Code Update from \"${PRE}\$$FND\" to \"${PRE}${REP}()\" in \"$F\" ($DT)." | tee -a "$LOG"

	# replace base
	local SED="s/${PRE}\\\$${FND}/${PRE}${REP}()/mg"
	echo "SED=$SED"	# test
	echo -e "Replace: \"${PRE}\$${FND}\" with \"${PRE}${REP}()\"." | tee -a "$LOG"

	sed -i -E "$SED" "$F"	# do it
	grep -nH "${PRE}${REP}" "$F" | tee -a "$LOG"	# show it
	# cat "$F"	# test

	# move variable
	local SEDV="s/${PRE}${REP}[\(\)]+\s*=\s*(.*);/${PRE}${REP}(\\1);/mg"
	echo "SEDV=$SEDV"	# test
	echo -e "Move variables: \"${PRE}${REP}() = var;\" to \"${PRE}${REP}(var);\"." | tee -a "$LOG"
	sed -i -E "$SEDV" "$F"	# do it
	grep -nH "${PRE}${REP}" "$F" | tee -a "$LOG"	# show it
	# cat "$F"	# test

	DT="$(date '+%Y%m%d-%H%M%S')"
	echo "Finished Code Update from \"${PRE}\$$FND\" to \"${PRE}${REP}([var])\" in \"$F\" ($DT)." | tee -a "$LOG"
	echo "" | tee -a "$LOG"	# new line

	return 0
} # find_replace_static_code()

# lookup version
DT="$(date '+%Y%m%d-%H%M%S')"
PROG="$(basename "$0")"
out_msg "AppsCMS $FVERSION Code Updater: $PROG - $DT" info

while [ -n "$1" ]
do
	case "$1" in
	-r|--replace )
		out_msg "Recommend committing (svn, git, etc.) or backing up this project before applying this upgrade.\n" warn
		read -r -p "Upgrade PHP code [yes|no] ? " KEY
		if [ "$KEY" != "yes" ]; then echo "Aborted"; exit 3; fi
		REPLACE=1
		;;
	-d|--directory )
		if [ -n "$2" -a -d "$2" ]; then
			SCHBASE="$2"
			shift
		else
			out_msg "Missing directory value." err
			out_msg "$USAGE" info
			exit 2
		fi
		;;
	* )
		out_msg "$USAGE" help
		out_msg "Recommend committing (svn, git, etc.) or backing up this project before applying this upgrade.\n" warn
		exit 1
		;;
	esac
	shift
done

if [ -z "$(findmnt "apps" | grep squash)" ]; then	# not is a squashfs
	out_msg "Check/create \"apps/bodies\" directory." info
	if [ ! -d "apps/bodies" ]; then
		mkdir -p "apps/bodies"
		if [ $? -eq 0 ]; then
			out_msg "Created \"apps/bodies/\" directory." info
		else
			out_msg "Failed to create \"apps/bodies/\" directory." error
			exit 126
		fi
	fi

	out_msg "Check/move \"page_bodies/\" to \"apps/bodies\" directory." info
	if [ -d "page_bodies" ]; then
		# check if need expand old page_bodies/ to apps/bodies/
		local BDSQSF="page_bodies_fs_sqsh.sqsh"
		if [ -f "$BDSQSF" -a -z "$(findmnt page_bodies/ | grep squash)" ] ]; then 	# version cross over mount it and copy
			out_msg "Mount $BDSQSF, copy into apps/bodies/, umount and trash." warn
			squashfuse "$BDSQSF" "page_bodies"
			cp -r page_bodies/* apps/bodies/
			fusermount -u page_bodies 2>&1
			mv "$BDSQSF" var/Trash/
		elif [ -n "$(findmnt page_bodies/ | grep squash)" ] ]; then 	# version cross over copy
			out_msg "Copy $BDSQSF into apps/bodies/, umount and trash." warn
			cp -r page_bodies/* apps/bodies/
			fusermount -u page_bodies 2>&1
			mv "$BDSQSF" var/Trash/
		else
			mv page_bodies/* -t apps/bodies/
			if [ $? -eq 0 ]; then
				out_msg "Moved \"page_bodies/\" to \"apps/bodies/\" directory." warn
				rmdir "page_bodies"
			else
				out_msg "Failed to move \"page_bodies/\" to \"apps/bodies/\" directory." error
				exit 127
			fi
		fi
	else
		out_msg "Move of \"page_bodies/\" to \"apps/bodies/\" done already." info
	fi


	# exit 1	# test

	if [ -z "$(findmnt apps | grep squash)" ]; then	# not mounted
		out_msg "Find page_bodies define errors and list in log file." info
		PBCNT=0
		OLDIFS=$IFS
		IFS=$'\n'

		for F in $(find -P apps/ -xdev -type f | grep -ivE '.svn|.git' | grep -iE '.php$|.html$|.ini$|.json$')
		do
			# out_msg "F=$F"	# test
			if [ -n "$(grep 'PAGES_BODIES_' "$F")" ]; then
				sed -i 's/PAGES_BODIES_/APPS_BODIES_/g' "$F"
				out_msg "Changed \"PAGE_BODIES_\" prefix in \"$F\"." info
				let ' PBCNT++ '	# found count
			fi

			if [ -n "$(grep 'page_bodies' "$F")" ]; then
				out_msg "Check \"page_bodies\" in \"$F\"." warn
				let ' PBCNT++ '	# found count
			fi

		done
		# IFS=$OLDIFS
		out_msg "Found $PBCNT files to check for page_bodies variables." info
	fi
fi

# exit 1	# test

# find variable,replace function (new line is the separator)
FIND_REPLACE="
ajax,get_ajax
api,is_api
block_html,use_block_html
browser_html5,is_html5
can_test,can_test
can_test,can_test
chrome_flg,is_chrome
cli,is_cli
cron,is_cron
edge_flg,is_ms_edge
fox_flg,is_firefox
has_ssl_available,has_ssl_available
have_session,have_session
is_debug,is_debug
is_production,is_production
is_rebuild,is_rebuild
moz_4_flg,is_moz_4
safari_flg,is_safari
ssl_in_use,is_ssl_inuse
ssl_required,is_ssl_required
tablet_flg,is_tablet
tiny_flg,is_tiny
tooltips_flg,use_tooltips
version_str,get_version_str
www,is_www
"
FCNT=0
DCNT=0
# OLDIFS=$IFS
# IFS=$'\n'
for F in $(find -P "$SCHBASE" -xdev -type f -name \*.php)
do
	if [ -n "$(echo "$F" | grep -E "$EXCLUDE")" ]; then continue; fi
	let ' FCNT++ '	# found count

	for F_R in $FIND_REPLACE
	do
		FND="${F_R%,*}"	# find
		REP="${F_R#*,}"	# replace
		find_replace_static_code "$F" "$FND" "$REP" > /dev/null	# to much bumffff
		if [ $? -eq 0 ]; then
			let ' DCNT++ '	# done count
		fi
		# echo ""
	done
#	out_msg ""
done

# put it back
IFS=$OLDIFS

out_msg "AppsCMS $FVERSION Code Updater: found $FCNT PHP files, updates $DCNT" info

# EOF
