#!/bin/bash
#   Applications Management System Library for PHP (AppsCMS)
#   see Licence in cms/LICENCE.txt
#   _SVN_build: $Id: cms_upgrade_v305.sh 3312 2023-04-11 04:45:17Z robert0609 $

# upgrades javascript/ directories name to js/ and stylesheets/ directories name to css/,


FFVERSION="V3.07.2"

REPLACE=0
DRY_RUN=1

CHG_DIRS="javascript->js stylesheets->css"
CHG_CODES="JAVASCRIPT->JS STYLESHEETS->CSS javascript->js stylesheets->css"

EXCLUDE=".svn|.git|.vscode|cms/|ReleaseNotes|ReadMe|LICEN|nbproject/|etc/sqlite/|.sqlite|cli/|/upgrade|localtools/|lib/|var/|tmp/|doxy/|dist-pkgs/|dev-tools/"   #
FCNT=0
DCNT=0
USAGE="
USAGE: $(basename $0) [--replace] [--dry-run (deflaut)] [-h|--help]\n \
	Upgrades to $FFVERSION;-
		1. javascript/ directories name to js/
		2. stylesheets/ directories name to css/
	in AppsCMS file structure and in PHP code.
	Excluded: \"$EXCLUDE\".
	Note: This upgrader does not upgrade AppsCMS, it assumes that cms/ is upgraded already.
"

source cms/cli/cms_include.sh

out_msg "AppsCMS $FFVERSION Directory and Code Updater." info

PROG="$(basename "$0")"
out_msg "AppsCMS: $PROG - $FFVERSION upgrades $CHG_CODES" info

while [ -n "$1" ]
do
	case "$1" in
	--replace )
		out_msg "Recommend committing (svn, git, etc.) or backing up this project before applying this upgrade.\n" warn
		read -r -p "Upgrade PHP code [yes|no] ? " KEY
		if [ "$KEY" != "yes" ]; then echo "Aborted"; exit 3; fi
		REPLACE=1
		DRY_RUN=0
		;;
	--dry-run )
		REPLACE=0
		DRY_RUN=1
		;;
	* )
		out_msg "$USAGE" help
		out_msg "Recommend committing (svn, git, etc.) or backing up this project before applying this upgrade.\n" warn
		exit 1
		;;
	esac
	shift
done

if [ $DRY_RUN -ne 0 ]; then
	out_msg "This is DRY RUN." info
elif [ $REPLACE -ne 0 ]; then
	out_msg "This is a LIVE UPGRADE/REPLACE RUN." warn
else
	out_msg "Run type not known." err
	exit 1
fi

out_msg "Find \"$CHG_DIRS\" directories file structure to change." info
for C in $CHG_DIRS
do
	DC="${C%%->*}"
	NC="${C##*->}"
	out_msg "C = $C, DC = $DC, NC = $NC" info # test

	for D in $(find -P . -type d -xdev 2> /dev/null | grep -v -E "\'$EXCLUDE\'")    # | sed -E 's|^\.\/||') #  -maxdepth 1
	do
		DD="$(basename "$D")"
		BD="$(dirname "$D")"
		if [ $DD != $DC ]; then continue; fi
		out_msg "D = \"$D\", .DD = \"$DD\", BD = \"$BD\"." info  # test

		BIN_MV='mv'
		BIN_OPTS='--force'

		# # check type mv
		# svn info "$D" > /dev/null 2>&1
		# if [ $? -eq 0 ]; then
		#	BIN_MV='svn'
		#	BIN_OPTS='mv --force'
		# fi

		if [ $DRY_RUN -ne 0 ]; then
			out_msg "Rename: $BIN_MV $BIN_OPTS \"$D\" to \"${BD}/${NC}\" (DRY RUN)"
		elif [ $REPLACE -ne 0 ]; then
			out_msg "Renaming: $BIN_MV $BIN_OPTS \"$D\" to \"${BD}/${NC}\""
			$BIN_MV $BIN_OPTS "$D" "${BD}/${NC}"
			if [ $? -ne 0 ]; then
				out_msg "Failed to rename \"$D\" to \"${BD}/${NC}\"" err
			fi
		fi
		let ' DCNT += 1 '
	done
done

out_msg "Renamed $DCNT directories." info
out_msg "   "

# exit 0    # test

out_msg "Edit \"$CHG_CODES\" file change." info
for C in $CHG_CODES
do
	FND="${C%%->*}"
	REP="${C##*->}"
	# out_msg "C = $F, FND = $FND, REP = $REP" info # test

	for F in $(grep -rl "$FND" 2> /dev/null | grep -v -E "\'$EXCLUDE\'")
	do

		if [ $DRY_RUN -ne 0 ]; then
			out_msg "Edit: \"$F\" to replace \"${FND}/\" with \"${REP}/\" (DRY RUN)"
		elif [ $REPLACE -ne 0 ]; then
			out_msg "Editing: \"$F\" to replace \"${FND}/\" with \"${REP}/\""
			sed -i -E "s|$FND|$REP|mg" "$F" # do it
			if [ $? -ne 0 ]; then
				out_msg "Failed editing: \"$F\" to replace \"${FND}/\" with \"${REP}/\"" err
			elif [ "$FND" == "javascript" ]; then
				# clean up the under cooked
				sed -i -E "s|text/${REP}|text/${FND}|mg" "$F"   # in js blocks
			fi
		fi
		let ' FCNT += 1 '
	done
done

# IFS=$OLDIFS
out_msg "Edited $FCNT files." info
out_msg "   "

out_msg "AppsCMS $PROG - $FFVERSION Directory and Code Upgraded: found $FCNT files and $DCNT directories." info

# EOF


