<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_upgrade_ini_V300.php 3301 2023-03-26 01:04:41Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('REBUILD_MODE',	true);	// tell configure i am rebuilding (same as rebuild from web)

define('ETC_INI_CMS_CONFIG', dirname(dirname(dirname(__DIR__))) . '/etc/ini/cms.ini');
if(!file_exists(ETC_INI_CMS_CONFIG)) {
	echo 'ERROR: Cannot find: ' . ETC_INI_CMS_CONFIG . PHP_EOL;
	exit(1);
	} // if

function write_ini_file($ini,$new_settings) {
	if(file_exists($ini)) {
		$ini_old = $ini . '-' . date('Ymd-His');
		if(rename($ini,$ini_old))
			echo 'INFO: Backup in "' . $ini_old . '".' . PHP_EOL;
		else {
			echo 'ERROR: Failed to backup "' . $ini . '".' . PHP_EOL;
			return false;
			} // else
		} // if
	$fh = fopen($ini, 'w');
	if((!$fh) || (!fwrite($fh, '; Updated for V3.07.' . PHP_EOL))) {
		echo 'ERROR: Failed to open "' . $ini . '" for save.' . PHP_EOL;
		@fclose($fh);
		return false;
		} // if
	$cnt = 0;
	foreach ($new_settings as $sect_name => &$section) {
		fwrite($fh, '[' . $sect_name . ']' . PHP_EOL);
		foreach ($section as $key => $new_value) {
			$safe_text = html_entity_decode($new_value);
			$safe_text = preg_replace('/\\\\/', '\\', $safe_text);
			$safe_text = addcslashes($safe_text, '"\\');
			fwrite($fh, $key . ' = "' . $safe_text . '"' . PHP_EOL);
			$cnt++;
			} // foreach
		fwrite($fh, PHP_EOL);
		} // foreach
	fwrite($fh, '; eof' . PHP_EOL);
	fclose($fh);
	echo 'INFO: Saved ' . $cnt . ' INI values in "' . $ini . '".' . PHP_EOL;
	return true;
	} // write_ini_file()

function update_ini_V227_5() {	// update/move settings
	$settings = parse_ini_file(ETC_INI_CMS_CONFIG, true);
	if(empty($settings)) {
		echo 'ERROR: Cannot read: ' . ETC_INI_CMS_CONFIG . PHP_EOL;
		return false;
		} // if
	$cnt = 0;
	$cms_moved_src_vals = array(
			'CommonSettings' => array(
				'keys' => array(
					'ALWAYS_USE_SSL_BOOL',
					'HOSTS_URLS_ALLOWED',
					'HOSTS_URLS_ERROR_URL',
					'HOSTS_URLS_CHECKED_BOOL',
					'GROUP_PERMISSIONS',
					'REVEAL_PASSWORD_BOOL',
					'SHOW_PASSWORD_BOOL',
					'TOOLS_LOGIN_REQD_BOOL',
					'VALIDATE_EMAIL_ADDRESS_BOOL',
					'TIMEZONE_TZ',	// moved to LanguageSettings section
					),
				'dst_section' => 'AuthSettings',
				),
			);
	foreach($cms_moved_src_vals as $src_sect => &$sect) {
		if(!isset($settings[($sect['dst_section'])]))
			$settings[($sect['dst_section'])] = array();
		foreach($sect['keys'] as $k) {
			if(isset($settings[$src_sect][$k])) {	// move val
				$settings[($sect['dst_section'])][$k] = $settings[$src_sect][$k];
				unset($settings[$src_sect][$k]);
				$cnt++;
				} // if
			} // foreach
		} // foreach

	$renamed_vals = array(
		// from => to
		'ThemeSettings' => array(
			'NAV_BAR_BKGD_COLOUR' => 'NAV_BAR_ELEM_BKGD_COLOUR',
			'NAV_BAR_BKGD_IMAGE' => 'NAV_BAR_ELEM_BKGD_IMAGE',
			'NAV_BAR_BORDER' => 'NAV_BAR_ELEM_BORDER',
			'NAV_BAR_BORDER_RADIUS' => 'NAV_BAR_ELEM_BORDER_RADIUS',
			'NAV_BAR_FONT_COLOUR' => 'NAV_BAR_ELEM_FONT_COLOUR',
			'NAV_BAR_FONT_FAMILY' => 'NAV_BAR_ELEM_FONT_FAMILY',
			'NAV_BAR_FONT_SIZE' => 'NAV_BAR_ELEM_FONT_SIZE',
			'NAV_BAR_FONT_STYLE' => 'NAV_BAR_ELEM_FONT_STYLE',
			'NAV_BAR_FONT_WEIGHT' => 'NAV_BAR_ELEM_FONT_WEIGHT',
			'NAV_BAR_HOVER_BKGD_COLOUR' => 'NAV_BAR_ELEM_HOVER_BKGD_COLOUR',
			'NAV_BAR_HOVER_BKGD_IMAGE' => 'NAV_BAR_ELEM_HOVER_BKGD_IMAGE',
			'NAV_BAR_HOVER_BORDER' => 'NAV_BAR_ELEM_HOVER_BORDER',
			'NAV_BAR_HOVER_FONT_COLOUR' => 'NAV_BAR_ELEM_HOVER_FONT_COLOUR',
			'NAV_BAR_ICON_HEIGHT' => 'NAV_BAR_ELEM_ICON_HEIGHT',
			'NAV_BAR_SHOW_ICONS_BOOL' => 'NAV_BAR_ELEM_SHOW_ICONS_BOOL',
			),
		);
	foreach($renamed_vals as $src_sect => &$sect) {
		foreach($sect as $o => $n) {	// old => new
			if((isset($settings[$src_sect][$o])) &&	// move val
				(!isset($settings[$src_sect][$n]))) {	// move val
				$settings[$src_sect][$n] = $settings[$src_sect][$o];
				unset($settings[$src_sect][$o]);
				$cnt++;
				} // if
			} // foreach
		} // foreach

	if($cnt > 0) {
		if(!write_ini_file(ETC_INI_CMS_CONFIG,$settings)) {
			echo 'ERROR: Failed to save ' . $cnt . ' updates cms.ini values.' . PHP_EOL;
			return false;
			} // if
		echo 'SUCCESS: Upgrade/move ' . $cnt . ' cms.ini values.' . PHP_EOL;
		} // if
	else {
		echo 'INFO: No V3.00 cms.ini changes required.' . PHP_EOL;
		} // else
	return true;
	} // update_ini_V227_5()

if(!update_ini_V227_5()) exit(2);

exit(0);	// ok

// done
// eof
