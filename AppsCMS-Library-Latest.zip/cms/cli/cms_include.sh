#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_include.sh 3164 2023-02-17 00:15:00Z robert0609 $

# set -x

# AppsCMS shell include file for common functions/

# check if include already in scope
declare -F out_msg > /dev/null
if [ $? -eq 0 ]; then exit; fi	# already done

# php -v	# what is it

shopt -s dotglob	# include dot files

V=$(cat cms/include/cms_configure.php | grep CMS_PROJECT_VERSION)
if [ -z "$V" ]; then
	out_msg "$USAGE" info
	out_msg "Cannot find FVERSION" err
	exit 1
fi
F=${V##*\"V}
INC_VERSION=V${F%%\"*}
SUZOO=0
SUDO_BIN=""
DT="$(date '+%Y%m%d-%H%M%S')"	# includes seconds
DLOG="var/logs"
mkdir -p "$DLOG" > /dev/null 2>&1
LOG="${DLOG}/CLI_cms-$(date '+%Y%m%d').log"
if [ ! -d "$DLOG" ]; then mkdir -p "$DLOG"; fi

function out_msg() { # $1=msg [$2="ok|info|warn|err"]
	local CLI_SH_BOLD="\033[1m"
	local CLI_SH_NORM="\033[0m"
	local CLI_SH_RED="\033[1;31m"
	local CLI_SH_GREEN="\033[1;32m"
	local CLI_SH_YELLOW="\033[1;33m"
	local CLI_SH_BLUE="\033[1;34m"
	local CLI_SH_WHITE="\033[1;39m"
	local CLI_SH_PURPLE="\033[1;35m"
	local CLI_SH_DEFCOL="\033[0m"
	local DTI="$(date '+%Y%m%d-%H%M%S')"
	local MSG="$1"
	local TYP="$2"
	local PRE=""

	if [ -z "$MSG" ]; then
		while read -r -s L
		do
			echo "${L}"
			echo "${DTI}: sqsh, ${L}" >> "$LOG"
		done
		return 0
	fi

	case "$TYP" in
		ok)
			PRE="OK: "
			echo -e "${CLI_SH_GREEN}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		info)
			PRE="INFO: "
			echo -e "${CLI_SH_BLUE}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		help)
			PRE="HELP: "
			echo -e "${CLI_SH_WHITE}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		warn)
			PRE="WARNING: "
			echo -e "${CLI_SH_PURPLE}${PRE}${CLI_SH_DEFCOL}${MSG}"
			;;
		err|error)
			PRE="ERROR: "
			echo ""
			echo -e "${CLI_SH_RED}${PRE}${CLI_SH_DEFCOL}${MSG}"
			echo ""
			;;
		*)
			PRE=""
			echo -e "${PRE}${MSG}"
			;;
	esac

	echo "${DTI}: ${MSG}" >> "$LOG"
	return 0
} # out_msg()

function is_sudoer() {	# $1=exit_status	(is user sudoer)
	if [ `whoami` == root ]; then	# already running as sudo (or root)
		SUZOO=1
		SUDO_BIN=""	# already root
		out_msg "Running as root user." warn
		return 0
	fi

	sudo -l -n -U $USER > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		SUZOO=0
		SUDO_BIN=""
		if [ -n "$i" ]; then
			out_msg "User: $USER is not sudoer." err
			exit $1
		fi
		out_msg "Not sudoer." warn
		return 1
	fi
	SUZOO=1
	SUDO_BIN="sudo -E "
	out_msg "Running $USER as sudoer." info
	return 0	# sudoer
} # is_sudoer()

function is_readonly_avail() { #
	which fusermount > /dev/null
	if [ $? -ne 0 ]; then
		out_msg "\"fusermount\" not available." warn
		return 2
	fi
	which squashfuse > /dev/null
	if [ $? -ne 0 ]; then
		out_msg "\"squashfuse\" not available." warn
		return 3
	fi
	return 0	# ok
} # is_readonly_avail()

function is_readonly_mount() { # $1=dir
	local _D="$1"
	if [ -n "$(findmnt "$_D" | grep squash)" ]; then
		return 0	# it's mounted
	fi
	if [ ! -d "$_D" ]; then
		if [ -f "${_D}_fs_sqsh.sqsh" ];then
			return 0	# it's there but not mounted
		fi
	fi
	return 1	# nope
} # is_readonly_mount()

function restart_httpd() {	#
	is_sudoer
	if [ $? -ne 0 ]; then	# cannot do
		out_msg "Cannot restart httpd services, not sudoer." err
		return 1;
	fi
	for D in httpd apache apache2 php-fpm
	do
		which $D 2> /dev/null > /dev/null
		if [ $? -eq 0 ]; then
			sleep 2
			out_msg "Stop/start $D." info
			sudo service $D stop
			sleep 2
			sudo service $D start
			if [ $? -ne 0 ]; then
				out_msg "Failed to start $D." err
			else
				out_msg "Started $D." ok
			fi
			sleep 2
		fi
	done
	return 0
} # restart_httpd()


# EOF

