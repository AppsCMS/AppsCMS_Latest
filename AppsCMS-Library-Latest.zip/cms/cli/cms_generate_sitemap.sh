#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_generate_sitemap.sh 2786 2022-08-31 05:40:44Z robert0609 $

# generate sitemap script for Applications Management System Library for PHP (AppsCMS)

BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null

php cms/cli/cms_generate_sitemap.php

popd > /dev/null

# EOF

