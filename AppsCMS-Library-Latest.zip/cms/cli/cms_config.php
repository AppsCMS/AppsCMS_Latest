<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_config.php 3051 2022-12-16 07:45:49Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure

// $cms_docroot = preg_replace('/\/(apps|cms)\/.*$/','',__DIR__);	// test
require_once ( preg_replace('/\/(apps|cms)\/.*$/','',__DIR__) . '/cms/cms_init.php' );

$ret=-1;
if(empty($argv[1])) {
	Ccms::addMsg('Missing option or config name.');
	exit(1);
	} // if
switch($argv[1]) {
case '--list':
case '-l':
	$filter = null;
	$exclude = null;
	if(!empty($argv[2])) {
		$filter = $argv[2];
		if(!empty($argv[3])) {
			$exclude = $argv[3];
			} // if
		} // if
	$ret = list_configs($filter,$exclude);
	break;
case '--conf':	// the new way (many name=value sets)
	$n = 2;
	$ret = 0;
	while((isset($argv[$n])) && ($n < count($argv))) {
		$config_name_val = $argv[$n];
		if(strpos($config_name_val,'=') !== false) {
			list($config_name,$new_value) = explode('=',$config_name_val);
			if(!preg_match('/^[a-z_]{8,}/i',$config_name)) {	// check
				Ccms::addMsg('Not a --conf name[=value] config name: ' . $config_name);
				exit(1);
				} // if
			$ret |= get_set_config($config_name,$new_value);
			} // if
		$n++;
		} // while
	break;
default:	// the old way (name value)
	$config_name = $argv[1];
	if(!preg_match('/^[a-z_]{8,}/i',$config_name)) {	// check
		Ccms::addMsg('Not a config name: ' . $config_name);
		exit(1);
		} // if
	$new_value = null;
	if(!empty($argv[2])) $new_value = $argv[2];
	$ret = get_set_config($config_name,$new_value);
	break;
	} // switch
exit($ret);

function list_configs($filter = null,$exclude = null) {

	$defd_consts = get_defined_constants(true);
	$user_consts = &$defd_consts['user'];
	$ctl_reg = [
		'pat' => [ '/[\x0a]/',	'/[\x0d]/',	'/[\x09]/',	'/[\x00-\x1F\x7F]/'		],
		'rep' => [ '--LF--',	'--CR--',	'--TAB--',	'--CNTL--'				],		
		];
	foreach($user_consts as $k => &$v) {
		if(!empty($filter)) {
			if((stripos($k,$filter) === false) && (stripos($v,$filter) === false)) continue;
			} // if
		if(!empty($exclude)) {
			if((stripos($k,$exclude) !== false) || (stripos($v,$exclude) !== false)) continue;
			} // if
		$conf_pre = '';
		if(preg_match('/^CMS_S_/',$k)) $conf_pre = 'CMS Setting: ';
		else if(preg_match('/^CMS_C_/',$k)) $conf_pre = 'CMS Config: ';
		else if(preg_match('/^LM_C_/',$k)) $conf_pre = 'LM Config: ';
		else if(preg_match('/^APPs_/',$k)) $conf_pre = 'Derived Application Constant: ';
		else if(preg_match('/^APPS_/',$k)) $conf_pre = 'All Applications Constant: ';
		else if(preg_match('/^APP_/',$k)) $conf_pre = 'Application setting: ';
		else if(preg_match('/^PL_/',$k)) $conf_pre = 'Plugin Config: ';
		else $conf_pre = 'Constant: ';
		echo $k . ' (' . $conf_pre . ') => "' . preg_replace($ctl_reg['pat'],$ctl_reg['rep'],$v) . '"' . PHP_EOL;
		} // foreach
	return 0;
	} // list_configs()


function get_set_config($config_name,$new_value = null) {
	$old_value = null;
	$config_key = strtoupper($config_name);

	if(defined($config_key)) $old_value = constant($config_key);

	if(preg_match('/^CMS_S_/',$config_key)) {
		if(is_null($old_value)) $old_value = Ccms_base::get_cms_ini_value($config_key);
		if((!empty($new_value)) && ($new_value != $old_value) &&
			(!Ccms_base::set_cms_ini_value(preg_replace('/^CMS_S_/','',$config_key),$new_value))) {
			Ccms::addMsg('Failed to set config name: ' . $config_key . ' to "' . $new_value . '"');
			return 10;
			} // if
		} // if
	else if(preg_match('/^APP_/',$config_key)) {
		if(is_null($old_value)) $old_value = Ccms_apps::get_apps_ini_value($config_key);
		if((!empty($new_value)) && ($new_value != $old_value) &&
			(!Ccms_apps::set_apps_ini_value(preg_replace('/^APP_/','',$config_key),$new_value))) {
			Ccms::addMsg('Failed to set config name: ' . $config_key . ' to "' . $new_value . '"');
			return 11;
			} // if
		} // if
	else if(preg_match('/^CMS_C_|^LM_C_|^PL_/',$config_key)) {
		if(is_null($old_value)) {
			if(!$old_value = Ccms::get_cms_config_value($config_key)) {
				$old_value = null;
				Ccms::addMsg('Failed to get config name: ' . $config_key . ' to "' . $new_value . '"');
				return 12;
				} // if
			} // if
		if((!empty($new_value)) && ($new_value != $old_value)) {
			if(!Ccms::set_cms_config_value($config_key,$new_value)) {
				Ccms::addMsg('Failed to set config name: ' . $config_key . ' to "' . $new_value . '"');
				return 13;
				} // if
			} // if
		} // if
	else {
		Ccms::addMsg('Cannot identify type of config name (i.e. CMS_S_|CMS_C_|LM_C_|PL_|APP_): ' . $config_key);
		return 2;
		} // else

	if(is_null($old_value)) {
		Ccms::addMsg('Config name: ' . $config_key . ' not found.');
		} // if
	else Ccms::addMsg('Config name: ' . $config_key . ' old value = "' . $old_value . '"','info');

	if((!empty($new_value)) && ($new_value != $old_value))
		Ccms::addMsg('Config name: ' . $config_key . ' new value = "' . $new_value . '"','success');
	return 0;
	} // get_set_config()

// eof
