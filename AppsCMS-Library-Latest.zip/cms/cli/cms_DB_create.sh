#!/bin/bash
# see Licence in cms/LICENCE.txt
# _SVN_build: $Id: cms_DB_create.sh 3230 2023-02-24 06:43:21Z robert0609 $
# create AppsCMS MySQL database

FVERSION="V3.06.RC1"

USAGE="USAGE: $(basename "$0") [ADMIN_USER] [ADMIN_PASSWORD]\n
	to create the AppsCMS MySQL Database (instead of SQLite database).\n"

echo "Create AppsCMS DataBase ($FVERSION)."
if [ -z "$1" -o -z "$2" ]; then
	echo -e "$USAGE"
	exit 1
fi
A_USER="$1"
A_PASSWD="$2"

php cms_DB_create.php "$A_USER" "$A_PASSWD"

echo "Done ($FVERSION)"

exit 0

