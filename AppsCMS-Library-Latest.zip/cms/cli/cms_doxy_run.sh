#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_doxy_run.sh 2913 2022-10-25 09:57:50Z robert0609 $

source cms/cli/cms_include.sh

# in the doxy conf files
export CMS_VERSION="$FVERSION"

DATA_DIR="doxy"
CONF_DIR="cms/doxy"

# check if Graphviz dot is there
which dot > /dev/null
if [ $? -ne 0 ]; then
	out_msg "Graphviz dot not installed on system." err
	exit 10
fi

USAGE="USAGE:
    $0 [--clean-all] [-a|--doxy-apps] [-c|--doxy-cms] [-all|--doxy-all]
    Doxy confs setup using doxywizard.
"
DOXY_APPS=0
DOXY_CMS=0
DOXY_CLEAN=0

while [ -n "$1" ]
do
	case "$1" in
	-a|--doxy-apps )
		DOXY_APPS=1
		;;
	-c|--doxy-cms )
		DOXY_CMS=1
		;;
	-all|--doxy-all )
		DOXY_APPS=1
		DOXY_CMS=1
		;;
	--clean-all )
		DOXY_CLEAN=1
		;;
	* )
		out_msg "$USAGE" info
		exit 1
		;;
	esac
	shift
done

if [ ! -d cms ]; then echo "Cannot see cms/ directory."; exit 1; fi
if [ ! -d "${DATA_DIR}" ]; then mkdir "${DATA_DIR}"; fi

ALLOW="\
## ${DATA_DIR}/.htaccess
#	access granted to this directory by $(basename "$0")
	DirectoryIndex index.html index.htm
	IndexOptions FancyIndexing ScanHTMLTitles SuppressColumnSorting NameWidth=40 FoldersFirst
	<Files *>
		Require all granted
	</Files>
# EOF
"
echo "$ALLOW" > "${DATA_DIR}/.htaccess"	# create/replace

# clean out left overs from fails
rm ${DATA_DIR}/*.xml 2> /dev/null
rm ${DATA_DIR}/*.tmp 2> /dev/null
# exit 0	# test

if [ $DOXY_CLEAN -ne 0 ]; then
	rm -rf "${DATA_DIR}/cms_html"
	rm -rf "${DATA_DIR}/apps_html"
	rm -rf "${DATA_DIR}/apps_cms_html"
fi

if [ $DOXY_CMS -ne 0 ]; then
	rm -rf "${DATA_DIR}/cms_html"
	doxygen "${CONF_DIR}/cms-doxy.conf"
fi

if [ $DOXY_APPS -ne 0 ]; then
	rm -rf "${DATA_DIR}/apps_html"
	doxygen "${CONF_DIR}/apps-doxy.conf"
fi

if [ $DOXY_APPS -ne 0 -a $DOXY_CMS -ne 0 ]; then
	rm -rf "${DATA_DIR}/apps_cms_html"
	doxygen "${CONF_DIR}/apps-cms-doxy.conf"
fi

# EOF

