#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_wrap_submission.sh 2786 2022-08-31 05:40:44Z robert0609 $

# pack up file structure for AppsCMS for submission to author for changes

DT="$(date '+%Y%m%d-%H%M%S')"
CMS="cms/"
FVERSION="V2.07"

PROG=$(basename "$0")
ZIPFILE="AppsCMS-Submission-${DT}-${FVERSION}.zip"
ROOT_FILES="index.php login.php logout.php .htaccess"
SQSH_FILES="cms_lib_sqsh.php cms_lib_sqsh.sqsh cms_lib_sqsh.sh cms_lib_sqsh.md"

# where am I
BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null
pwd
if [ -f "$ZIPFILE" ]; then rm -f "$ZIPFILE"; fi
zip -r9 "$ZIPFILE" "${CMS}"  -x *~ *.tmp *.bak *.directory */.DS* */.svn\* *.git\* *orig ${CMS}main_styles.css ${CMS}block_styles.css ${CMS}inline_styles.css

# add the doc root extras
for F in $ROOT_FILES $SQSH_FILES
do
	if [ ! -f "$F" ]; then continue; fi
	zip "$ZIPFILE" "$F"
	if [ $? -ne 0 ]; then
		echo \"ERROR: Failed to zip $F file."
	fi
done

popd > /dev/null

# EOF
