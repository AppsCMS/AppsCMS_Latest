#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_backup_settings.sh 3301 2023-03-26 01:04:41Z robert0609 $

# backup sqlite DB and INI files for Applications Management System Library for PHP (AppsCMS)
# run from web root directory

DT="$(date '+%Y%m%d-%H%M%S')"
FVERSION="V3.07"
BAKDIR="var/backups"
if [ ! -d "$BAKDIR" ]; then mkdir -p "$BAKDIR"; fi
BAK_TGZ="${BAKDIR}/AppsCMS-Backup-${HOSTNAME}-${DT}"
EXCLUDE_TYPES=" \
	--exclude *.svn \
	--exclude *.git/* \
	--exclude *.svn/* \
"

PROG="$(basename "$0")"
source cms/cli/cms_include.sh
BASE_DIR="$(pwd | sed 's/cms\/cli\///g' )"
pushd "$BASE_DIR" > /dev/null

out_msg "Backing up (DOCROOT) settings and configurations to \"$BAK_TGZ\" ($FVERSION)." info

CONF_DB="etc/sqlite/cms.sqlite"
CONF_DB_TMP="${BAKDIR}/dump-${DT}.sql"

CONF_INI_DIR="etc/ini/"
if [ ! -d "$CONF_INI_DIR" ]; then    # setup not found
    out_msg "No setup found." warn	# probably installing
	exit 2
fi
CONF_DB_DIR="etc/sqlite/"
if [ ! -d "$CONF_DB_DIR" ]; then    # DB not found
    echo "No DB found." warn	# probably installing
	exit 2
fi

if [ ! -d "$BAKDIR" ]; then
    mkdir -p "$BAKDIR"
    if [ ! -d "$BAKDIR" ]; then
        out_msg "Failed to make \"$BAKDIR\" directory." err
        exit 1
    fi
fi

# make backup file
out_msg "Backup \"${CONF_INI_DIR}\"." info
zip $EXCLUDE_TYPES -r "${BAK_TGZ}.zip" "${CONF_INI_DIR}" # always there

out_msg "Backup \"${CONF_DB_DIR}\"." info
zip $EXCLUDE_TYPES -r "${BAK_TGZ}.zip" "${CONF_DB_DIR}" # always there

out_msg "Backup \"(DOCROOT)\"." info
DR=".htaccess ajax.php api.php index.php login.php logout.php"
zip "${BAK_TGZ}.zip" $DR # (DOCROOT) always there

if [ ! -f "$CONF_DB" ]; then    # db not found
    out_msg "Database file \"$CONF_DB\" no found." err
	exit 3
else    # dump the config database
    sqlite3 "$CONF_DB" .dump > "$CONF_DB_TMP"
    if [ $? -ne 0 ]; then
        out_msg "Could not backup \"$CONF_DB\"." err
		exit 4
    else
		out_msg "Backup DB data." info
        zip "${BAK_TGZ}.zip" "$CONF_DB" "$CONF_DB_TMP"
        if [ -f "${CONF_DB_TMP}" ]; then rm -f "${CONF_DB_TMP}"; fi
    fi
fi

popd > /dev/null

exit 0	# done

# EOF
