#!/bin/bash
# see Licence in cms/LICENCE.txt
# _SVN_build: $Id: cms_pkgs_stats.sh 3188 2023-02-17 11:26:08Z robert0609 $
# get package status

RET=0
# try RPM first
which rpm  > /dev/null 2>&1
if [ $? -eq 0 ]; then	# RPM
	rpm -q AppsCMS-Docs  > /dev/null 2>&1
	if [ $? -eq 0 ]; then	# installed
		echo -n "$(rpm -q --qf '%{name}-%{version}-%{release}.%{arch}' AppsCMS-Docs).rpm"	# prints package info
		# got it
	else 
		echo "AppsCMS-Docs rpm not installed."
	fi
	rpm -q AppsCMS-Library  > /dev/null 2>&1
	if [ $? -eq 0 ]; then	# installed
		echo -n "$(rpm -q --qf '%{name}-%{version}-%{release}.%{arch}' AppsCMS-Library).rpm"	# prints package info
		# got it
	else
		echo "AppsCMS-Library rpm not installed."
		RET=1
	fi
if


which apt  > /dev/null 2>&1
if [ $? -eq 0 ]; then	# DEB
	# @TODO DEB

fi

if [ $RET -ne 0 ]; then
	echo "ERROR: Packager not found."
	exit 10
fi

exit 0	# ok


# EOF
