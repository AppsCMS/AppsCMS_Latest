#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_config.sh 3444 2024-05-05 06:37:14Z robert0609 $

# get/set config or install setting

FVERSION="V3.07.8"
BASE_DIR="$(pwd | sed 's|cms/cli||' )"
PROG="cms/cli/$(basename "$0")"
source cms/cli/cms_include.sh
# echo $(basename "$0") $@	# test

function help() { #
	echo ""
	echo "Usage: $PROG [-h|--help] | [ -l|--list [ filter [ exclude ]]] | [ --conf config_name1[=new_value1 ] [... config_nameN[=new_valueN ]]]"
	echo "  Where:"
	echo "    -h|--help - is this help message,"
	echo "    -l|--list - list all settings and configuration definitions (including AppsCMS defines),"
	echo "    filter - to filter (i.e. simply word,phrase,key,etc.) the list of user defined configuration definitions (case insensitive,optional),"
	echo "    exclude - to exclude (i.e. simply word,phrase,key,etc.) from the list of user defined configuration definitions (case insensitive,optional),"
	echo "    --conf config_name[=new_value] - is the configuration name (converted uppercase),"
	echo "       new_value - is the new value for the config_name (if not present, prints the current config_name value)."
	echo "  Note: some globally definitions are auto defined and do not have configuration settings."
	echo ""
} # help()

if [ -z "$1" ]; then
	help
	exit 1
fi

pushd "$BASE_DIR" > /dev/null

RET=-1
case "$1" in
	-h|--help)
		help
		exit 0
		;;
	-l|--list)
		FILTER=""
		EXCLUDE=""
		if [ -n "$2" ]; then
			FILTER="$2"
			if [ -n "$3" ]; then
				EXCLUDE="$3"
			fi
		fi
		php cms/cli/cms_config.php --list "$FILTER" "$EXCLUDE" | sort
		RET=$?
		;;
	--conf*)	# new way
		CONF_NAME_VALUES="$@"
		php cms/cli/cms_config.php --conf "$CONF_NAME_VALUE"
		RET=$?
		;;
		*)	# old way
		CONF_NAME="$1"
		VALUE=""
		if [ -n "$2" ]; then
			VALUE="$2"
		fi
		php cms/cli/cms_config.php "$CONF_NAME" "$VALUE"
		RET=$?
		;;
esac

popd > /dev/null

exit $RET

# EOF

