#!/bin/sh
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_import_links_manager.sh 2841 2022-10-08 06:32:13Z robert0609 $

# import lm_links and lm_sections tables from existing Links Manager.

FVERSION="V2.18-2"
DT="$(date '+%Y%m%d-%H%M%S')"

echo "Start LM import ($FVERSION)"

BASE_DIR="$(pwd | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null

BACKUP_DIR="var/backups/"
if [ ! -d "$BAKDIR" ]; then mkdir -p "$BAKDIR"; fi

USAGE="Usage: cms/cli/cms_import_links_manager.sh /path/to/links_manager_base_dir/"

LM_BASE_DIR="$1"
# LM_BASE_DIR="../../Links_Manager/"	#test
if [ -z "$LM_BASE_DIR" ]; then
	echo "$USAGE"
	echo "$FVERSION"
	exit 1
fi

cms/cli/cms_backup_settings.sh
php cms/cli/cms_import_links_manager.php --lm-import-dir "$LM_BASE_DIR"
php cms/cli/cms_rebuild.php

popd > /dev/null

echo "Import LM done ($FVERSION)"

# EOF