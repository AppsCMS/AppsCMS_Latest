#!/bin/bash
# see Licence in cms/LICENCE.txt
# _SVN_build: $Id: cms_DB_query.sh 3385 2023-07-23 09:31:39Z robert0609 $
# MySQL query tester

FVERSION="V3.07.5"
HOST="$1"
DB="$2"
USER="$3"
PASSWD="$4"
QUERY="$5"

if [ -z "$1" ]; then
	echo "USAGE: $(basename $0) HOST DB USER PASWORD sql_query"
	exit 1
fi

echo "$(basename $0) $1 ($FVERSION)"
echo "mysql --host=$HOST --user=$USER --password=$PASSWD --execute \"$QUERY\" $DB"
mysql --host=$HOST --user=$USER --password=$PASSWD \
	--execute "$QUERY" \
	$DB

# EOF
