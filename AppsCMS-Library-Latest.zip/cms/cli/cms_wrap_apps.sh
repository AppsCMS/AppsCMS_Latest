#!/bin/bash
# set -x
#	Applications Management System Library for PHP (AppsCMS) App Filesystem Wrapper
#	===============================================================================
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_wrap_apps.sh 3439 2024-04-28 04:44:57Z robert0609 $

# pack up file structure for Applications Management System Library for PHP
# all the files to be packed are in the cms/ directory (including examples).

FVERSION="V3.07.7"
DT="$(date '+%Y%m%d-%H%M%S')"
PROG="$(basename "$0")"
BDIR="$(dirname "$0")"
echo "$PROG $DT - $FVERSION"
SQSF_DDIRS="apps"
WRAP=1
B2T=0
CR=0
CE=0
SVNSETPROPS=0

source cms/cli/cms_include.sh

function help() { #
	echo ""
	echo "USAGE: $PROG [-h|--help] [-wa|--wrap-apps (default) | -nw|--no-wrap] [-s|--set-svn-props]"
	echo "      [-b2t|--branch2trunk [-cr|--copy-root] [-ce|--copy-etc]] [--conf n=v ...]"
	echo "  Wrap $SQSF_DDIRS application directories into a read only squashfs file."
	echo "  See technical manual for more information."
	echo "  --set-svn-props, set svn keywords properties."
	echo "  --branch2trunk, wrap branch app directories to trunk directory on SVN versions (if the same trunk directory exists)."
	echo "    e.g. wrap \"/some/base/dir/branches/app_dir\" to \"/some/base/dir/trunk/app_dir.sqsf\"."
	echo "  --copy-root, if --branch2trunk is done the files in DOCROOT are  copied from branch to trunk also."
	echo "  --copy-etc, if --branch2trunk is done the files in etc/ are copied from branch to trunk also."
	echo "  --conf n=v ..., if --branch2trunk is done, sets name=value etc (e.g. CMS_S_DEBUG_BOOL=0)."
	echo "    --conf must be the last command option (uses \"cms/cli/cms_config.sh\")."
	echo "      See \"cms/cli/cms_config.sh -h\" for more information."
	echo "  On non other file structures, --branch2trunk is ignored and"
	echo "    places the apps .sqsf files in the source (DOCROOT) directory."
	echo "  Note: The --branch2trunk option helps to reduce clutter in branches to trunk"
	echo "    (i.e. development to published) structures."
	echo ""
} # help()

out_msg "AppsCMS application wrapper: $PROG - $DT - $FVERSION" info

function copy_root() { # $1=src $2=dest
    local SDIR="$1"
    local DDIR="$2"

    if [ $CR -ne 0 ]; then
        out_msg "Copying DOCROOT files from \"${SDIR}\*\" \"${DDIR}\" for option --copy-root." info
        for F in $(find -P "${SDIR}" -xdev maxdepth 1 -type f | egrep -iv 'cms_lib_sqsh|^\.[a-z]+|/\.[a-z]+')
        do
            cp -v -u -p "${F}" "${DDIR}"
            if [ $? -ne 0 ]; then
                    out_msg "Failed to copy \"${F}\" to \"${DDIR}\"." err
                    return 1
            fi
            out_msg "Copied \"${F}\" to \"${DDIR}\"." ok
        done
    else
        out_msg "Copy DOCROOT files \"${SDIR}\" to \"${DDIR}\" not done." info        
    fi
    return 0    # ok
} # copy_root()

function copy_etc() { # $1=src $2=dest
    local SDIR="$1"
    local DDIR="$2"
	local W=$(cat etc/ini/cms.ini | grep CODE_KEEP_ETC_BOOL)
	if [ -z "$W" -o ["*${W}*" != 'true'] ]; then
		out_msg "Copying etc/ directory not allowed." info
		return 0	# ok
	fi

    if [ $CE -ne 0 ]; then
        out_msg "Copying directory \"${SDIR}etc/\" to \"${DDIR}etc\" for option --copy-etc." info
        cp -v -r -f "${SDIR}etc" "${DDIR}"
        if [ $? -ne 0 ]; then
                out_msg "Failed to copy \"${SDIR}etc/\" to \"${DDIR}\"." err
                return 1
        fi
        out_msg "Copied \"${SDIR}etc/\" to \"${DDIR}\"." ok
    else
        out_msg "Copy DOCROOT/etc directory \"${SDIR}etc\" to \"${DDIR}etc\" not done." info        
    fi
} # copy_etc()

function squash_app_dir() { # $1=dir
	local SQSF="${1}_fs_sqsh.sqsh"
	local SDIR="$(realpath "$BDIR" | sed 's|cms/cli||')"
	local DDIR="$SDIR"
	if [ $B2T -ne 0 ]; then
		if [ -n "$(echo "$SDIR" | grep trunk)" ]; then
			out_msg "\"$SDIR\" is trunk. Not wrapping \"$1\"." warn
			return 0	# ok
		fi
		DDIR="$(echo "$SDIR" | sed 's|branches|trunk|')"
		if [ ! -d "$DDIR" ]; then
			out_msg "Destination \"${DDIR}\" not found for option --branch2trunk." warn
			out_msg "Wrap \"${SDIR}${1}\" to \"${DDIR}${SQSF}\" not available." warn
			return 1
		fi

            copy_root "${SDIR}" "${DDIR}" 
            copy_etc "${SDIR}" "${DDIR}" 
	fi

	if [ $WRAP -ne 0 ]; then
		out_msg "Wrap \"${SDIR}${1}\" to \"${DDIR}${SQSF}\"." info

		if [ -n "$(findmnt "${SDIR}${1}")" ]; then
			out_msg "$SQSF is mounted, cannot continue." err
			return 1
		fi
		if [ -f "${SDIR}${SQSF}" ]; then rm -f "${SDIR}${SQSF}" > /dev/null 2>&1; fi	# unclutter
		if [ -f "${DDIR}${SQSF}" ]; then rm -f "${DDIR}${SQSF}" > /dev/null 2>&1; fi	# clean
		mksquashfs "${SDIR}${1}" "${DDIR}${SQSF}" -info -force-uid 0 -force-gid 0 -no-duplicates > /dev/null
		if [ $? -ne 0 ]; then
			out_msg "Failed to wrap $SQSF." err
			return 1
		else
			ls -lh "${DDIR}${SQSF}"
			out_msg "Wrapped $SQSF." ok
		fi
	fi
	return 0
} # squash_app_dir()

while [ -n "$1" ]
do
	case "$1" in
	-wa|--wrap-apps)
		WRAP=1
		;;
	-nw|--no-wrap)
		WRAP=0
		;;
	-s|--set-svn-props)
		SVNSETPROPS=1
		;;
	-b2t|--branch2trunk)
		B2T=1
		;;
	-cr|--copy-root)
		CR=1
		;;
	-ce|--copy-etc)
		CE=1
		;;
	-h|--help)
		help
		exit 0
		;;
	* )
		out_msg "Option $1 unknown." err
		help
		exit 1
		;;
	esac
	shift
done

# set svn Id keywords
if [ $SVNSETPROPS -ne 0 ]; then
	out_msg "PropSet SVN Keywords in \"${SQSF_DDIRS}\"." info
	# everything in ${SQSF_DDIRS} except PEAR
	find -P "${SQSF_DDIRS}" -xdev -type f | egrep -v 'svn|git|/lib' | while read F
	do
		svn propset svn:keywords "Id" "$F" 2&> /dev/null
	done
fi

for D in $SQSF_DDIRS
do
	squash_app_dir "$D"
done

exit 0

# EOF
