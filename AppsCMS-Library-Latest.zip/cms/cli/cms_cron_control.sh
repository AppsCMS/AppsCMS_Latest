#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_cron_control.sh 2786 2022-08-31 05:40:44Z robert0609 $

# cron control script for Applications Management System Library for PHP (AppsCMS)
# run as cms/cli/cms_cron_control.sh from web root directory

FVERSION="2.17"

BASE_DIR="$(dirname $0 | sed 's/cms\/cli//g' )"
pushd "$BASE_DIR" > /dev/null
php "cms/cli/cms_cron_control.php" "$1" "$2"
popd > /dev/null

# EOF

