<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_rebuild.php 3077 2023-01-01 06:34:12Z robert0609 $
 */

error_reporting(E_ALL | E_STRICT);

define('CLI_MODE',		true);	// tell configure
define('REBUILD_MODE',	true);	// tell configure i am rebuilding (same as rebuild from web)
$rebuild_access = false;
if(is_array($argv)) {
	if(in_array('--use-json',$argv)) { define('USE_JSON_REBUILD', true); }
	if(in_array('--repair-access',$argv)) { $rebuild_access = true; }
	if(in_array('--rebuild-ext-libs',$argv)) { define('REBUILD_EXT_LIBS', true); }
	} // if

// check basic requirements first
$funcs2chk = array(
	array(	// to decode existing json files
		'type' => 'func',
		'func' => 'json_decode',
		'reqd' => 'php[n]-json',
		),
	array(	// to access configs
		'type' => 'class',
		'class' => 'SQLite3',
		'reqd' => 'php[n]-sqlite',
		),
	array(	// to access configs
		'type' => 'func',
		'func' => 'mysqli_connect',
		'reqd' => 'php[n]-mysql',
		),
	array(	// to access configs
		'type' => 'func',
		'func' => 'mb_strlen',
		'reqd' => 'php[n]-mbstring',
		),
	array(	// to access configs
		'type' => 'func',
		'func' => 'socket_create',
		'reqd' => 'php[n]-sockets',
		),
	array(	// to access configs
		'type' => 'class',
		'class' => 'ZipArchive',
		'reqd' => 'php[n]-zip',
		),
	array(	// to access configs
		'type' => 'class',
		'class' => 'finfo',
		'reqd' => 'php[n]-fileinfo or pecl install fileinfo',
		),
	array(	// to access configs
		'type' => 'func',
		'func' => 'gd_info',
		'reqd' => 'php[n]-gd',
		),
	array(	// html compression
		'type' => 'func',
		'func' => 'gzdeflate',
		'reqd' => 'php[n]-zlib',
		),
	array(	// remote access checks, APIs, etc.
		'type' => 'func',
		'func' => 'curl_exec',
		'reqd' => 'php[n]-curl',
		),
);
$ok = true;
foreach($funcs2chk as &$chk) {
	switch($chk['type']) {
	case 'func':
		if(!function_exists($chk['func'])) {
			$ok = false;
			echo 'Function not found: ' . $chk['func'] . ', install system package "' . $chk['reqd'] . '".' . PHP_EOL;
			} // if
		break;
	case 'class':
		if(!class_exists($chk['class'])) {
			$ok = false;
			echo 'Class not found: ' . $chk['class'] . ', install system package "' . $chk['reqd'] . '".' . PHP_EOL;
			} // if
		break;
	default:	// ??
		break;
		} // switch
	} // foreach
if(!$ok) die("ERROR: Basic requirements failed.");

// $cd = preg_replace('/\//s','/',__DIR__);
// $cms_docroot = preg_replace('/\/(apps|cms).*$/','',$cd);
$cms_docroot = dirname(dirname(__DIR__));		// windows compatibility
require_once ( $cms_docroot . '/cms/cms_init.php' );

// @unlink(ETC_FS_AUTOLOAD_JSON);	// rebuild autoload json
// @unlink(ETC_FS_EXT_LIB_JSON);	// rebuild extension autoload json

// CLI test
// Ccms::addMsg('Bad');	// test
// Ccms::addMsg('Good','warn');	// test
// Ccms::addMsg('Good','success');	// test
// exit(0);	// test

Ccms::addInfoMsg('Starting -> rebuilding setup for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.');

Ccms_sm::get_bodies_defines();

if(!Ccms::$cDBcms->checkDBversion(true)) {
	Ccms::addMsg('Failed configuration database checks.');
	exit(1);
	} // if

if((Ccms_DB_install::rebuild_from_settings()) &&
	(Ccms::chk_bld_crit_dirs()) &&
	(Ccms::do_cms_warnings(true)) &&
	(Ccms::do_cms_cli_warnings(true)) &&
	(Ccms_apps::do_apps_rebuild(true))) {
	Ccms::clean_orphaned_settings(true);
	Ccms::addMsg('Installation checks ok.','success');
	} // if
else {
	Ccms::addMsg('Failed installation checks.','warn');
	} // else

if(($rebuild_access) && (!Ccms::rebuild_docroot_htaccess())) {
	Ccms::addMsg('Failed to rebuild (DOCROOT)/.htaccess.');
	exit(1);
	} // if

Ccms_content_cache::reset_caches(true,true);
Ccms_gotcha_plugin::reset_cache(true);
Ccms_proxy::clear_signats(true);
Ccms_minify_plugin::reset_cache(true);
Ccms_auth::clear_expired_verification_codes();

Ccms::addInfoMsg('Finished -> rebuilding setup for ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '.');

exit(0);

// eof
