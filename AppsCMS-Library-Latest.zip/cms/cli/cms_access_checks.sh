#!/bin/bash
#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: $Id: cms_access_checks.sh 3301 2023-03-26 01:04:41Z robert0609 $

# check and repair security access
# set -x

FVERSION="V3.07"
BASE_DIR="$(pwd | sed 's|cms/cli||' )"
PROG="cms/cli/$(basename "$0")"
source cms/cli/cms_include.sh
HTA='.htaccess'
REPAIR=0
DRY=0
TMP_DIR="var/temp"
ALLOW_TMP="${TMP_DIR}/allow_test.tmp"
DENY_TMP="${TMP_DIR}/deny_test.tmp"

function help() { #
	echo "Usage: $PROG [-r|--repair-access] [--dry-run]"
	echo "  $PROG checks for $HTA files in directories."
	echo "  Where:"
	echo "    --repair always replace access controls."
	echo "    --dry-run show what will be done (DRY RUN)."
	echo ""
} # help()

cd "$BASE_DIR"

while [ -n "$1" ]
do

	case "$1" in
		--dry-run)
			DRY=1
			;;
		-r|--repair-access)
			REPAIR=1
			;;
		*)
			help
			exit 0
			;;
	esac
	shift
done

out_msg "AppsCMS $FVERSION Access checker: $PROG - $DT" info

DENY="\
## $HTA
#	access denied to this directory by $PROG
#	access provided by includes
	<Files *>
		Require all denied
	</Files>
# EOF
"

ALLOW="\
## $HTA
#	access granted to this directory by $PROG
	<Files *>
		Require all granted
	</Files>
# EOF
"

LIB_ALLOW="\
## lib/.htaccess
#	access granted to files in lib/ directory
	Options -Indexes
	# IndexOptions NameWidth=150

	<Files *>
		Require all granted
	</Files>
# EOF
"

if [ $REPAIR -eq 0 ]; then
	if [ ! -d "$TMP_DIR" ]; then mkdir -p "$TMP_DIR"; fi
	echo "$ALLOW" > "$ALLOW_TMP"	# allow check file
	echo "$DENY" > "$DENY_TMP"	# deny check file
fi

function deny_access() { # $1=dir
	local D="$1"
	local HTF="${D}/${HTA}"
	if [ ! -f "$HTF" ]; then
		if [ $DRY -eq 0 ]; then
			echo "$DENY" > "$HTF"	# create/replace
			out_msg "Created \"$HTF\" to deny access in \"$D\"." ok
		else	# dry
			out_msg "Would create \"$HTF\" to deny access in \"$D\" (DRY RUN)." ok
		fi
		return 0
	fi

	if [ $REPAIR -eq 1 ]; then
		if [ $DRY -eq 0 ]; then
			echo "$DENY" > "$HTF"	# create/replace
			out_msg "Replaced \"$HTF\" to deny access in \"$D\"." ok
		else	# dry
			out_msg "Would replace \"$HTF\" to deny access in \"$D\" (DRY RUN)." ok
		fi
	else
		CHK="$(cmp "$HTF" "$DENY_TMP")"
		if [ $? -ne 0 ]; then
			out_msg "Found \"$HTF\", should deny access in \"$D\"." warn
		fi
	fi
	return 0
} # deny_access()

function allow_access() { # $1=dir
	local D="$1"
	local HTF="${D}/${HTA}"
	local LIB="$(echo "$D" | grep '/lib')"
	if [ ! -f "$HTF" ]; then
		if [ $DRY -eq 0 ]; then
			if [ ! -z "$LIB" ]; then
				echo "$LIB_ALLOW" > "$HTF"	# create/replace
				out_msg "Created \"$HTF\" to allow library access in \"$D\"." ok
			else
				echo "$ALLOW" > "$HTF"	# create/replace
				out_msg "Created \"$HTF\" to allow access in \"$D\"." ok
			fi
		else	# dry
			out_msg "Would create \"$HTF\" to allow access in \"$D\" (DRY RUN)." ok
		fi
		return 0
	fi

	if [ $REPAIR -eq 1 ]; then
		if [ $DRY -eq 0 ]; then
			echo "$ALLOW" > "$HTF"	# create/replace
			out_msg "Replaced \"$HTF\" to allow access in \"$D\"." ok
		else	# dry
			out_msg "Would replace \"$HTF\" to allow access in \"$D\" (DRY RUN)." ok
		fi
	else
		CHK="$(cmp "$HTF" "$ALLOW_TMP")"
		if [ $? -ne 0 ]; then
			out_msg "Found \"$HTF\", should allow access in \"$D\"." warn
		fi
	fi
	return 0
} # allow_access()

# list the directory patterns that allow web access
# (the cms/ directory is part of AppCMS library and already controlled)
ALLOWED_PATTS=" \
	apps/images \
	apps/js \
	apps/lib \
	apps/css \
	/backgrounds \
	/css \
	etc/backgrounds \
	etc/css \
	etc/ext \
	etc/icons \
	etc/images \
	/icons \
	/images \
	/js \
	/lib \
	media \
	localtools/icons \
	localtools/images \
	var/apps \
	var/cache \
	var/exports \
	var/gotcha \
"

function is_ws_allowed() { # $1=dir
	local D="$1"
	local APP_TYPE_BASIC=5		# has the match class Ccms_DB_checks::APP_TYPE_BASIC;
	local TMP=""
	local BDIR=""

	if [[ "$D" == apps/* ]]; then	# check if it is simple app
		TMP="${D##*apps/}"	# remove the apps/ part
		BDIR="${TMP%%/*}"	# remove the (APP_DIR)/* parts after the (APP_DIR)
		# out_msg "D=$D, TMP=$TMP, BDIR=$BDIR" info	# test
		if [ -n "$BDIR" ]; then
			APP_TYPE="$(sqlite3 etc/sqlite/cms.sqlite "SELECT cms_body_type FROM cms_bodies WHERE cms_body_dir = \"$BDIR\" AND cms_body_type = $APP_TYPE_BASIC")"
			if [ -n "$APP_TYPE" ]; then 
				out_msg "Leave alone: $D"	# test
				return -1	# leave alone
			fi
		fi
	fi	# just the top level of dir

	for P in $ALLOWED_PATTS
	do
		CHK="$(echo "$D" | grep "$P" | grep -iv 'trash|temp|tmp')"
		if [ -n "$CHK" ]; then 
			out_msg "Access allowed: $D"	# test
			return 0	# allowed
		fi
	done
	out_msg "Access not allowed: $D"	# test
	return 1	# not allowed
} # is_ws_allowed()

SCR_DIRS="apps etc var media"
for SD in $SCR_DIRS
do
	is_readonly_mount "$SD"
	if [ $? -eq 0 ]; then continue; fi	# not allowed
	find -P "$SD" -xdev -type d | while read D
	do
		# echo "D=$D"	# test
		if [[ "$D" == */Trash/* ]]; then continue; fi	# just the top level of dir
		if [[ "$D" == */lib/* ]]; then continue; fi	# just the top level of dir
		if [[ "$D" == */cache/* ]]; then continue; fi	# just the top level of dir
		
		is_ws_allowed "$D"
		RES=$?	# save result
		if [ $RES -lt 0 ]; then continue; fi	# leave alone
		if [ $RES -eq 0 ]; then	# allow
			allow_access "$D"
		else	# deny
			deny_access "$D"
		fi
	done
done

out_msg "Done Access checks: $PROG - $DT" info

# EOF

