Applications Management System Library for PHP (AppsCMS) - README_libs.
=======================================================================
see Licence in cms/LICENCE.txt
<!-- _SVN_build: $Id: README_libs.md 3087 2023-02-02 01:06:01Z robert0609 $ -->

3rd Party Libraries.
--------------------

1. 3rd party libraries used by AppsCMS are placed in "cms/lib/" directory.
2. They are licenced by their respective authors (see the licence files in each library directory).
3 .The libraries have been selected for there ease of use, no required dependencies and simplicity.
4. In some cases the library requires custom values to be entered into code (e.g. directory locations).

PHP Composer
------------
PHP Composer can be installed/updated by running "bash composer_update.sh" (needs to run in the "cms/lib/" directory).
See also "https://getcomposer.org/download/" for more information

The command "php composer.phar update" is run before each AppsCMS release, so it not usually necessary unless you are writing code for the AppsCMS library.

To check the state of the composer provided packages run "php composer.phar outdated".

Notes
-----

1. cms/include/ini/cms.libs2scan.ini is an index the classes included in AppsCMS index on rebuilds.

.EOF.
