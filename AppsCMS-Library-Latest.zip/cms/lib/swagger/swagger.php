<?php
// work out base ref from docroot
$host = $_SERVER['HTTP_HOST'];
$dir = preg_replace('/\/cms\/lib.*$/','/',$_SERVER['PHP_SELF']);
$proto = (($_SERVER['HTTPS'] == 'on') ? 'https://':'http://');
$base_ref = $proto . $host  . $dir;

// use unminified code if debug
$inc_uri = 'cms/lib/swagger/';

?>
<!-- HTML for static distribution bundle build -->
<!DOCTYPE html>
<html  lang="en">
	<head>
		<meta charset="UTF-8">
		<base href="<?= $base_ref ?>">
		<title>Swagger UI</title>
		<link rel="stylesheet" type="text/css" href="<?= $inc_uri ?>swagger-ui.css" />
		<style>
			html
			{
				box-sizing: border-box;
				overflow: -moz-scrollbars-vertical;
				overflow-y: scroll;
			}

			*,
			*:before,
			*:after
			{
				box-sizing: inherit;
			}

			body
			{
				margin:0;
				background: #fafafa;
			}
		</style>
		<script type="text/javascript" src="<?= $inc_uri ?>swagger-ui-bundle.js" charset="UTF-8"></script>
		<script type="text/javascript" src="<?= $inc_uri ?>swagger-ui-standalone-preset.js" charset="UTF-8"></script>
	</head>

	<body>
		<div id="swagger-ui"></div>

		<script type="text/javascript">
			window.onload = function () {
				// Begin Swagger UI call region
				const ui = SwaggerUIBundle({
					url: "api/resource.json",	// use API to get test json
					dom_id: '#swagger-ui',
					deepLinking: true,
					validatorUrl: null,
					// contentSecurityPolicy: null,
					presets: [
						SwaggerUIBundle.presets.apis,
						SwaggerUIStandalonePreset
					],
					plugins: [
						SwaggerUIBundle.plugins.DownloadUrl
					],
					layout: "StandaloneLayout",
				});
				// End Swagger UI call region

				window.ui = ui;
			};
		</script>
	</body>
</html>
