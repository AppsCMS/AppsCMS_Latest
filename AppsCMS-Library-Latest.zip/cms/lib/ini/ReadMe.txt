AppsCMS Library External Data Alternatives.
===========================================
<!-- _SVN_build: $Id: ReadMe.txt 3007 2022-12-01 01:07:32Z robert0609 $ -->

Browscap INI Alternatives.
--------------------------
These Browscap INI files are available from;-
"https://browscap.org/#google_vignette"

and direct download from;-
"http://browscap.org/stream?q=Full_PHP_BrowsCapINI"		too big (102MB) too slow
"http://browscap.org/stream?q=PHP_BrowsCapINI"			big (21MB) slow
"http://browscap.org/stream?q=Lite_PHP_BrowsCapINI"		ok (900KB) but not complete

.EOF.
