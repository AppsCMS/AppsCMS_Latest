#!/bin/bash

# build (debug)
# TS_VER="0.9.7"
#pushd "$(dirname "$0")/${TS_VER}/" > /dev/null
#TRANS_PROGRAM="translate.awk"
#gawk -f "$TRANS_PROGRAM" - "$@"
#popd > /dev/null
#exit $?

# release build
export TRANS_MANPAGE=trans.man
export TRANS_BUILD=release
TRANS_PROGRAM="trans.awk"
gawk -f <(echo -E "$TRANS_PROGRAM") - "$@"
