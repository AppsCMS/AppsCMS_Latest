<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: maxmind_geoip.php 2909 2022-10-24 07:34:08Z robert0609 $
 */

/**
 * Description of Cmaxmind_geoip
 *
 * Description of GeoIP interface to MAXMIND database
 *
 * @author robert0609
 */

require_once 'vendor/autoload.php';
use GeoIp2\Database\Reader;

class Cmaxmind_geoip extends Ccms_base {

	function __construct() {
		// parent::__construct();
		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

	public static function get_MM_geoip_data($ip,$mmdb) {	// link method
		if((empty($ip)) || (empty($mmdb))) return false;
		// This creates the Reader object, which should be reused across
		// lookups.
		$reader = new Reader($mmdb);
		// Replace "city" with the appropriate method for your database, e.g."country".
		// $record = $reader->city($ip);
		$record = $reader->country($ip);
		if(empty($record)) return false;
		return $record;	// an object
		} // get_MM_geoip_data()

} // Cmaxmind_geoip

