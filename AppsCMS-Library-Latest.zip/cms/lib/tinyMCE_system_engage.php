/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * Engage system installed tinyMCE WYSIWYG
 * _SVN_build: $Id: tinyMCE_system_engage.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

tinymce.init({
	selector: "#ws_text_area",
	height: "960",
	width: "100%",
	plugins : "advlist autolink link image colorpicker lists charmap table hr legacyoutput pagebreak tabfocus textcolor media code searchreplace fullscreen"
	});

// EOF

