<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: ckeditor_engage.php 3020 2022-12-07 10:16:47Z robert0609 $
 *
 * see "https://ckeditor.com/docs/ckeditor4/latest/api/CKEDITOR_editor.html"
 */


?>
<script src="//cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>

<script type="text/javascript">

	CKEDITOR.editorConfig = function( config ) {
		config.autoGrow_onStartup = true;
		config.autoGrow_minHeight = 768;
		};

	CKEDITOR.replace( 'ws_body_text' );

</script>
