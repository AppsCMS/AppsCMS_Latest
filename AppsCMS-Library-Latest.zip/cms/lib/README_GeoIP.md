Applications Management System Library for PHP (AppsCMS) - README_GeoIP.
========================================================================
see Licence in cms/LICENCE.txt
<!-- _SVN_build: $Id: README_GeoIP.md 2795 2022-09-10 09:37:50Z robert0609 $ -->

MAXMIND Code Library.
--------------------

1. From "https://github.com/maxmind/GeoIP2-php".
2. Used by having an account on "https://www.maxmind.com/en/home".
3 .The data for the this GeoIP library is in "DOCROOT)/etc/geoip" directory.
4. The "cms/include/plugins/cms_geoip.php" has the configuration entries for GeoIP.

System Requirements.
====================

Require system packages;
1. GeoIP-data
2. GeoIP
3. geoipupdate

Notes
-----

1. The MAXMIND code is used in lieu of any other geo ip code.
2. A MAXMIND account and license key is required, and these values placed in "/etc/GeoIP.conf".
3. "geoipupdate" needs by run periodically to keep the GeoIP mmdb database up to date.

MAXMIND mmdb Databases
----------------------

Typically, there are these databases downloads'=
/var/lib/GeoIP/GeoLite2-ASN.mmdb
/var/lib/GeoIP/GeoLite2-City.mmdb
/var/lib/GeoIP/GeoLite2-Country.mmdb
Note: Actual directory location may vary betwwen operating systems.

.EOF.
