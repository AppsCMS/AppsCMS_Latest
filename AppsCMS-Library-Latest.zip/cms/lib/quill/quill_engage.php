<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * Engage system installed tinyMCE WYSIWYG
 * from example in "https://quilljs.com/docs/"
 * _SVN_build: $Id: quill_engage.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/*
 * Comments:
 * Quill is very much over cooked (ie trying to use advanced web pack features, bug targets, for the sake of it,
 * too many svg elements for buttons. imgs would have been easier and simpler).
 * And also to the point of shutting out HTML elements (eg tables, etc.) causing quill to be very basic.
 */

global $cWYSIWYG;
if(empty($cWYSIWYG)) return;

include_once(CMS_FS_LIB_DIR . 'quill/quill_init.php');

?>

<style>
	body > #standalone-container {
		margin: 50px auto;
		min-width: 720px;
		padding: 0px 0px 0px 10px;
		}
	#editor-container {
		background-color: white;
		color: black;
		min-height: 640px;
		border: 2px solid gray;
		border-radius: 5px;
		}
	#toolbar-container {
		background-color: ivory;
		border: 2px solid gray;
		border-radius: 5px;
		}
	button.ql-header {
		font-size: 0.7em;
		font-weight: bolder;
		}
</style>

<!--Using the AppsCMS tooltips-->
<div id="standalone-container">
	<div id="toolbar-container">
		<span class="ql-formats">
			<select class="ql-font"></select>
			<select class="ql-size"></select>
		</span>
		<span class="ql-formats">
			<button class="ql-bold" title="Bold (Crtl B)"></button>
			<button class="ql-italic" title="Italic (Crtl I)"></button>
			<button class="ql-underline" title="Underline (Crtl U)"></button>
			<button class="ql-strike" title="Strikeout"></button>
		</span>
		<span class="ql-formats">
			<select class="ql-color" title="Font Colour"></select>
			<select class="ql-background" title="Background Colour"></select>
		</span>
		<span class="ql-formats">
			<button class="ql-script" value="sub" title="Subscript"></button>
			<button class="ql-script" value="super" title="Superscript"></button>
		</span>
		<span class="ql-formats">
			<button class="ql-header" value="1" title="Header H1">H1</button>
			<button class="ql-header" value="2" title="Header H2">H2</button>
			<button class="ql-header" value="3" title="Header H3">H3</button>
			<button class="ql-header" value="4" title="Header H4">H4</button>
			<button class="ql-header" value="5" title="Header H5">H5</button>
			<button class="ql-header" value="6" title="Header H6">H6</button>
			<button class="ql-blockquote" title="Blockquote"></button>
			<button class="ql-code-block" title="Coeblock"></button>
		</span>
		<span class="ql-formats">
			<button class="ql-list" value="ordered" title="Ordered List"></button>
			<button class="ql-list" value="bullet" title="Unordered List"></button>
			<button class="ql-indent" value="-1" title="Unident"></button>
			<button class="ql-indent" value="+1" title="Indent"></button>
		</span>
		<span class="ql-formats">
			<button class="ql-direction" value="rtl" title="Text Direction"></button>
			<select class="ql-align" title="Text Align"></select>
		</span>
		<span class="ql-formats">
			<button class="ql-link" title="Link"></button>
			<button class="ql-image" title="Image"></button>
			<button class="ql-video" title="Video"></button>
			<button class="ql-formula" title="Formuula"></button>
		</span>
		<span class="ql-formats">
			<button class="ql-clean" title="Clean Text"></button>
		</span>
	</div>
	<div id="editor-container"><?= $cWYSIWYG->get_edit_body_text() ?></div>
</div>

<script type="text/javascript">
//	document.addEventListener("DOMContentLoaded", function(event){
		var ws_edit_text_id = "editor-container";	// used by view select button js

		// see "https://quilljs.com/docs/"
		var quill = new Quill('#editor-container', {
			modules: {
				formula: true,
				syntax: true,
				toolbar: {
					container: '#toolbar-container',  // Selector for toolbar container
					// toolbar: toolbarOptions,
					},
				},
			placeholder: 'Add layout here ...',
			theme: 'snow'
			});

//	});

		function get_ws_text_area() {
			// AppsCMS looks for this function to retrieve edited text
			return quill.getText();
			} // get_ws_text_area()
		function get_ws_html_area() {
			// AppsCMS looks for this function to retrieve edited text
			return quill.root.innerHTML;
			} // get_ws_html_area()

</script>

