<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: quill.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description
 * cms_wysiwyg functions
 *
 * @author robert0609
 */

echo 'Cquill';	// the class name

class Cquill extends Ccms_wysiwyg {

	function __construct() {
		parent::__construct();
	} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// methods

// static methods
	public function output_edit_text($body_text) {
		$this->edit_body_text = $body_text;

		$text = PHP_EOL;
		$text .= $this->get_wysiwyg_engage();

		return $text;
		} // output_edit_text()

} // Cquill
