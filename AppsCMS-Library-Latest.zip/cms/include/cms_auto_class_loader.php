<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_auto_class_loader.php 3251 2023-03-02 12:50:06Z robert0609 $
 */

/*
 *
 * class autoloader implementation
 *
 * the autoloader removed many circular includes and requires from the code
 * with the overall result that it runs faster and uses a lot less memory (typically half)
 *
 */

// function __autoload($class) {
//     include 'classes/' . $class . '.class.php';
// }

// the always defined classes
require_once(CMS_FS_CLASSES_DIR . 'cms_base.php');

class Ccms_autoloader extends Ccms_base {

	protected static $cms_al_ops_dirs_list = false;

	function __construct($log = '', $record_time_times = true) {
		parent::__construct($log, $record_time_times);
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	private static function is_cms_library_section_present() {
		if((empty(self::$cms_al_ops_dirs_list['lib'])) ||
			(empty(self::$cms_al_ops_dirs_list['lib']['classes']))) 
			return false;	// rebuild cms/lib/classess/
		return true;
		} // is_cms_library_section_present()
		
	private static function is_ops_dirs_list_valid(&$cms_al_ops_dirs_list) {
		if(empty($cms_al_ops_dirs_list['dir']['classes'][0])) return false;
		if(!@is_dir(DOCROOT_FS_BASE_DIR . $cms_al_ops_dirs_list['dir']['classes'][0])) return false;		// dir exists (not moved)
		if(!@is_dir(DOCROOT_FS_BASE_DIR . $cms_al_ops_dirs_list['dir']['plugins'][0])) return false;		// dir exists (not moved)
		if(!self::is_cms_library_section_present()) return false;
		return true;
		} // is_ops_dirs_list_valid()

	public static function &get_ops_dirs_list($reload = false) {
		if($reload) self::$cms_al_ops_dirs_list = false;
		if(!self::is_ops_dirs_list_valid(self::$cms_al_ops_dirs_list))
			self::init_ops_autoload_list ($reload);
		return self::$cms_al_ops_dirs_list['dir'];
		} // get_ops_dirs_list()

	protected static function init_ops_autoload_list($reload = false) {
		static $rebuilding = false;
		if($rebuilding) return true;	// shoulg enough dirs to basically work
		if((!$reload) && (self::is_ops_dirs_list_valid(self::$cms_al_ops_dirs_list))) return;
		if((!$reload) && (file_exists(ETC_FS_AUTOLOAD_JSON)) && (is_readable(ETC_FS_AUTOLOAD_JSON))) {
			// speed up
			self::$cms_al_ops_dirs_list = self::load_json(ETC_FS_AUTOLOAD_JSON);
			if(self::is_ops_dirs_list_valid(self::$cms_al_ops_dirs_list)) // dir exists (not moved)
				return true;
			} // if
		if((!is_dir(CMS_WS_CLASSES_DIR)) || (!is_dir(CMS_WS_DIR))) {	// catastrophic failure
			echo " ERROR LOCATION FAILURE: cannot verify (DOCROOT).";
			exit(15);
			} // if
		self::$cms_al_ops_dirs_list = array();	// initialize

		$rebuilding = true;
		
		// do the fast ones first
		// classes and plugins with relative paths for autoload
		self::$cms_al_ops_dirs_list['dir']['classes'][] = CMS_WS_CLASSES_DIR;
		self::$cms_al_ops_dirs_list['dir']['classes'][] = APPS_WS_CLASSES_DIR;
		self::$cms_al_ops_dirs_list['dir']['plugins'][] = CMS_WS_PLUGINS_DIR;
		self::$cms_al_ops_dirs_list['dir']['plugins'][] = APPS_WS_PLUGINS_DIR;

		// images and images with docroot relative paths for image selects
		// self::$cms_al_ops_dirs_list['dir']['images'][] = CMS_WS_IMAGES_DIR;	// cms only
		self::$cms_al_ops_dirs_list['dir']['images'][] = ETC_WS_IMAGES_DIR;
		self::$cms_al_ops_dirs_list['dir']['images'][] = APPS_WS_IMAGES_DIR;
		self::$cms_al_ops_dirs_list['dir']['images'][] = LOCAL_WS_TOOLS_IMAGES_DIR;

		// self::$cms_al_ops_dirs_list['dir']['icons'][] = CMS_WS_ICONS_DIR;	// cms only
		self::$cms_al_ops_dirs_list['dir']['icons'][] = ETC_WS_ICONS_DIR;
		self::$cms_al_ops_dirs_list['dir']['icons'][] = APPS_WS_ICONS_DIR;
		self::$cms_al_ops_dirs_list['dir']['icons'][] = LOCAL_WS_TOOLS_ICONS_DIR;

		self::$cms_al_ops_dirs_list['dir']['backgrounds'][] = ETC_WS_BACKGROUNDS_DIR;

		if(is_dir(APPS_FS_DIR)) {	// find app class and plugins
			$dirs = scandir(APPS_FS_DIR);
			$sub_dirs = array('classes','plugins','images','icons','backgrounds');
			foreach($dirs as $d) {
				if(!is_dir(APPS_FS_DIR . $d)) continue;
				if(!self::is_dir_usable($d)) continue;
				if(preg_match('/^\.|include|js|lib|css/', $d)) continue;
				foreach($sub_dirs as $s) {
					switch($s) {
					case 'classes':
					case 'plugins':
						$bd = APPS_WS_DIR;
						break;
					default:
						$bd = APPS_WS_DIR;
						break;
						} // switch
					if(is_dir(DOCROOT_FS_BASE_DIR . $bd . $d . '/' . $s))
						self::$cms_al_ops_dirs_list['dir'][$s][] = $bd . $d . '/' . $s . '/';
					} // foreach
				} // foreach
			} // if
		self::rebuild_cms_library_settings();	
		self::rebuild_ext_library_settings();
		self::save_json(ETC_FS_AUTOLOAD_JSON,self::$cms_al_ops_dirs_list);
		$rebuilding = false;
		return true;
		} // init_ops_autoload_list

	protected static function find_classes_under_dir(&$ops_dirs_list, $section_name,$lib_dir,$verbose = false) {
		$dt = date(DateTime::ISO8601);
		$section = array();
		$section['comment'] = "class/interface = filepath for {$lib_dir} Library scan on {$dt}.";
		$files = Ccms_base::scan_dir_recurs($lib_dir);
		// print_r($files); exit(1);	// test

		for($i = 0, $n = count($files); $i < $n; $i++) {
			$f = $files[$i];
			if(preg_match('/test|example/i',$f)) continue;	// not test nor example files
			if(!preg_match('/\.php$/i',$f)) continue;	// only PHP code
			if($verbose) echo "File = " . $f . PHP_EOL;	// test
			$namespace = false;
			if($fp = fopen($f,'r')) {
				while($line = fgets($fp)) {
					if(preg_match('/^[\s]*namespace[\s]+/',$line)) {
						$namespace = preg_replace('/^[\s]*namespace[\s]+([^\s\n;]+).*$/','$1',$line);
						continue;
						} // if
					if(preg_match('/^[\s]*(class|interface)[\s]+/',$line)) {
						$class = preg_replace('/^[\s]*(class|interface)[\s]+([^\s\n;]+).*$/','$2',$line);
						} // if
					else if(preg_match('/^[\s]*abstract[\s]+class[\s]+/',$line)) {
						$class = preg_replace('/^[\s]*abstract[\s]+class[\s]+([^\s\n;]+).*$/','$1',$line);
						} // if
					else if(preg_match('/^[\s]*final[\s]+class[\s]+/',$line)) {
						$class = preg_replace('/^[\s]*final[\s]+class[\s]+([^\s\n;]+).*$/','$1',$line);
						} // if
					else if(preg_match('/^[\s]*trait[\s]+/',$line)) {	// not quite the same as a class !!, but needs to know where it is
						$class = preg_replace('/^[\s]*trait[\s]+([^\s\n;]+).*$/','$1',$line);
						} // if
					else continue;
					//$cl = preg_replace('/[\n\t]/','',$class);
					//$df = preg_replace('/[\n\t]/','',$f);
					if($namespace) {
						$ns_class = trim($namespace) .'\\' . trim($class);
						$section[trim($ns_class)] = trim($f);
						} // if
					else $section[trim($class)] = trim($f);
					if($verbose) echo "Class: {$row}" . PHP_EOL;
					} // while
				fclose($fp);
				} // if
			} // for
		$ops_dirs_list[$section_name] = $section;	// only replace MY section
		return true;
		} // find_classes_under_dir()

	protected static function rebuild_cms_library_settings() {
		self::addAdminMsg('Rebuilding ' .  CMS_PROJECT_SHORTNAME . ' library settings.','info');
		$sect_dirs = self::parse_ini_file(CMS_FS_CMS_LIBS_DIRS, false, true);
		self::$cms_al_ops_dirs_list['lib']['classes'] = array();
		foreach($sect_dirs as $section_name => $dir) {
			if(preg_match('/^_|comment/i',$section_name)) continue;
			self::find_classes_under_dir(self::$cms_al_ops_dirs_list['lib']['classes'],$section_name,$dir,false);
			} // foreach
		return true;
		} // rebuild_cms_library_settings()
	
	protected static function rebuild_ext_library_settings() {	// this can take time to complete
		if((!defined('CMS_S_EXT_LIB_SCAN_ENABLE_BOOL')) || (!CMS_S_EXT_LIB_SCAN_ENABLE_BOOL) ||
			(!defined('CMS_S_EXT_LIB_DIRS_LIST')) || (empty(CMS_S_EXT_LIB_DIRS_LIST))) return false;
		self::addAdminMsg('Rebuilding external library settings.','info');
		self::$cms_al_ops_dirs_list['ext']['classes'] = array();
		$ext_name_dirs = self::unserialize_string2arry(CMS_S_EXT_LIB_DIRS_LIST, ':', '=');
		foreach($ext_name_dirs as $n_d) {
			$n = self::replace_constants_ini_data($n_d[0]);
			$d = self::replace_constants_ini_data($n_d[1]);
			self::find_classes_under_dir(self::$cms_al_ops_dirs_list['ext']['classes'],$n,$d,false);
			} // foreach
		return true;
		} // rebuild_ext_library_settings()

//	protected static function add_ext_lib_autoload_sect($section_name,&$section) {
//		if(!$conf =self::load_json(ETC_FS_AUTOLOAD_JSON)) $conf = array();
//		if(empty($conf['lib']['classes'])) $conf['lib']['classes'] = array();
//		$classes = &$conf['lib']['classes'];
//		if(!isset($classes[$section_name])) $classes[$section_name] = $section;	// new section
//		else $classes[$section_name] = array_merge($classes[$section_name],$section);	// merge section
//		return self::save_json(ETC_FS_AUTOLOAD_JSON,$conf);
//		} // add_ext_lib_autoload_sect()

	public static function find_class($class, $filter = false) {
		$class_file = preg_replace('/^C/','', $class) . '.php';
		$class_file_l = strtolower($class_file);
		$class_dirs = &self::$cms_al_ops_dirs_list['dir']['classes'];
		foreach($class_dirs as $d) {
			if(($filter) && (strpos($d,$filter) === false)) continue;
			$dir = DOCROOT_FS_BASE_DIR . $d;
			// $f = $d . $class_file;	// debug
			if(file_exists($dir . $class_file)) {	// standard classes
				return $dir . $class_file;
				} // if
			// $f = $d . $class_file_l;	// debug
			if(file_exists($dir . $class_file_l)) {	// lower case classes
				return $dir . $class_file_l;
				} // if
			} // foreach
		return false;
		} // find_class()

	public static function find_plugin($class, $dir_filter = false) {

		$class_file = preg_replace('/^C/','', $class) . '.php';
		if(!preg_match('/_plugin$|_extend$/', $class)) return false;
		// plugin classes
		$cms_plugin_file = preg_replace('/_plugin/', '', $class_file);	// plugin removed
		$cms_plugin_file_l = strtolower($cms_plugin_file);
		$cms_plugin_dirs = &self::$cms_al_ops_dirs_list['dir']['plugins'];
		foreach($cms_plugin_dirs as $d) {
			if(($dir_filter) && (strpos($d,$dir_filter) === false)) continue;
			$dir = DOCROOT_FS_BASE_DIR . $d;
			if(file_exists($dir . $cms_plugin_file)) {
				return $dir . $cms_plugin_file;
				} // if
			if(file_exists($dir . $cms_plugin_file_l)) {
				return $dir . $cms_plugin_file_l;
				} // if
			} // foreach
		return false;
		} // find_plugin()

	protected static function find_cms_lib_class_file($class) {
		self::init_ops_autoload_list();
		if(!empty(self::$cms_al_ops_dirs_list['lib']['classes'])) {
			$lib_classes = &self::$cms_al_ops_dirs_list['lib']['classes'];
			foreach($lib_classes as $lib => &$classes) {
				if((empty($classes)) || (!is_array($classes))) continue;
				if(isset($classes[$class])) {
					$file = $classes[$class];
					if(file_exists(DOCROOT_FS_BASE_DIR . $file)) return DOCROOT_FS_BASE_DIR . $file;
					if(file_exists($file)) return $file;
					} // if
				} // foreach
			} // if
		return false;
		} // find_cms_lib_class_file()

	protected static function find_ext_class_file($class) {
		self::init_ops_autoload_list();
		if(!empty(self::$cms_al_ops_dirs_list['ext']['classes'])) {
			$lib_classes = &self::$cms_al_ops_dirs_list['ext']['classes'];
			foreach($lib_classes as $lib => &$classes) {
				if((empty($classes)) || (!is_array($classes))) continue;
				if(isset($classes[$class])) {
					$file = $classes[$class];
					if(file_exists(DOCROOT_FS_BASE_DIR . $file)) return DOCROOT_FS_BASE_DIR . $file;
					if(file_exists($file)) return $file;
					} // if
				} // foreach
			} // if
		return false;
		} // find_ext_class_file()

	protected static function inc_check_class(&$class,&$class_file) {
		include_once $class_file;
		if((!class_exists($class)) && (!interface_exists($class)) && (!trait_exists($class))) {	// maybe some bug/error in class file
			self::addDebugMsg('Class/Interface: ' . $class . ', not found after including: ' . $class_file);
			return false;
			} // if
		return true;
		} // inc_check_class()

	public static function load_class($class,$reloading = false) {

		self::init_ops_autoload_list($reloading);
		if(preg_match('/[ !?@]+/',$class)) {	// not legal
			Ccms::addMsg('Bad class name "' . $class . '".');
			return;
			} // if
		if($cms_plugin_file = self::find_plugin($class)) { // cms plugin classes
			self::inc_check_class($class,$cms_plugin_file);
			return;
			} // if

		if($class_file = self::find_class($class)) {	// standard cms classes
			self::inc_check_class($class,$class_file);
			return;
			} // if

		if($lib_class_file = self::find_cms_lib_class_file($class)) {
			self::inc_check_class($class,$lib_class_file);
			return;
			} // if

		if($ext_class_file = self::find_ext_class_file($class)) {
			self::inc_check_class($class,$ext_class_file);
			return;
			} // if

		if($reloading) return;	// don't recurse forever

		// special clases
		$ext_def_classes = get_declared_classes();
		// sort($ext_def_classes);
		if(in_array($class,$ext_def_classes)) return;

		// @TODO rename the files of these classes
		switch($class) {
		// extension not loaded	case 'SQLite3':
		case 'ZipArchive':
			return;
		default:
			// for class_exists(), dont make unnecessary logs/alerts
			$bk_trc = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
			$bk_tr_str = serialize($bk_trc);
			// typically: "... s:8:"function";s:12:"class_exists"; ... "
			if(strpos($bk_tr_str,'s:8:"function";s:12:"class_exists";') !== false)
				return;
			break;
			} // switch
		
		$msg = 'Unknown autoloader class: ' . $class . '';
		if((!defined('CMS_S_DEBUG_BOOL')) ||
			(CMS_S_DEBUG_BOOL)) {
			// be nice to coder
			self::load_class($class,true); // go again with rebuild
			if(class_exists($class)) return;	// it will be included at next rebuild
			// else not there
			echo $msg . PHP_EOL;
			} // if

		if(self::is_debug()) self::addMsg ($msg);
		else self::log_msg($msg);
		return;
		} // load_class()

} // Ccms_autoloader

// hook in global autoloader
function cms_auto_class_loader($class) {
	if(class_exists($class,false)) return;
	return Ccms_autoloader::load_class($class);
	} // cms_auto_class_loader()
spl_autoload_register('cms_auto_class_loader');

// set tidy
Ccms_base::start_page_tidy_buffer();

// set global classes
if(Ccms_base::is_api()) {	// API request
	require_once(CMS_FS_CLASSES_DIR . 'cms_api.php');
	global $cAPI;
	$cAPI = new Ccms_api();
	} // if
else {	// normal web site call
	require_once(CMS_FS_CLASSES_DIR . 'cms.php');
	global $cCMS;
	$cCMS = new Ccms();
	} // else
