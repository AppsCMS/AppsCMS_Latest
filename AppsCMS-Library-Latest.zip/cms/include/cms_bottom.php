<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_bottom.php 2996 2022-11-23 02:43:02Z robert0609 $
 */

	Ccms_base::output_page_tidy_buffer();

	Ccms::get_code_errors();
	Ccms::saveMsgs();
	Ccms_ops::do_site_sess_close();

