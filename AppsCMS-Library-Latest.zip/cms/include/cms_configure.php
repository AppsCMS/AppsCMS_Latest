<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_configure.php 3475 2024-08-24 03:36:50Z robert0609 $
 */

// add missing PHP version compatibility functions
include_once('cms_functions.php');

// general program definition constants
define("CMS_PROJECT_NAME",			"Applications Management System Library for PHP");	// Define the project name
define("CMS_PROJECT_SHORTNAME",		"AppsCMS");		// Define the project abreviated name
define("CMS_PROJECT_VERSION",		"V3.07.11");	// Define the project version (system package compatible, no dashes)
define("CMS_PROJECT_DOMAIN",		"appscms.org");	// the web domain
define("CMS_SESSION_NAME",			CMS_PROJECT_SHORTNAME . "id_");	// session id index
define("CMS_PREFIX",				"cms_");		// AppsCMS prefix
define("CMS_CORE_LANG",				"en-AU");		// the language used by AppsCMS
define("CMS_DEFAULT_TIMEZONE", "Australia/Sydney");

// where is everything
define("DOCROOT_FS_BASE_DIR",	str_replace('\\','/',dirname(dirname(dirname(__FILE__)))) . '/');	// the web page file base, must be LINUX and Windows compatible
//echo DOCROOT_FS_BASE_DIR; // test (turn off compression to see)

chdir(DOCROOT_FS_BASE_DIR);	// ensure cms filesystem available from it's document root

//define general stuff

if(!empty($_SERVER['SERVER_NAME'])) {	// running as a web app
	//	site status definition
	// if(!empty($_SERVER['PHP_SELF'])) {
		// $ws_dir = preg_replace('/\/?cms\/?$/','',substr(dirname($_SERVER['PHP_SELF']),1));

		// changes for PHP 7 from rogue URL tests, sometimes the $_SERVER array is not fully populated
		if(!empty($_SERVER['SCRIPT_NAME'])) $ws_uri = $_SERVER['SCRIPT_NAME'];
		else if(!empty($_SERVER['PHP_SELF'])) $ws_uri = $_SERVER['PHP_SELF'];
		else if(!empty($_SERVER['REQUEST_URI'])) $ws_uri = $_SERVER['REQUEST_URI'];
		else $ws_uri = '';	// should not happen !!!!

		if(isset($_SERVER['CONTEXT_PREFIX'])) {	// does not work with sub directories
			$ws_cont_pre = $_SERVER['CONTEXT_PREFIX'];
			} // if
		$ws_uri = substr(dirname($ws_uri),1);
		// $ws_dir = preg_replace('/(\/cms\/.*|\/apps\/.*)$/','',$ws_uri);	(?)
		$ws_dir = preg_replace('/(\/cms.*|\/apps.*)$/','',$ws_uri);

		if(strlen($ws_dir) > 2) {
			define("DOCROOT_WS_BASE_DIR",	$ws_dir . '/');	// directory on server with web pages, usually the web pages alias setting
			} /// if
		// DOCROOT_WS_BASE_DIR should have trailing slash but no leading slash,
		// since paths are constructed like '/' . CMS_URI_ALIAS . 'index.php'.
		// Thus it should be blank if we're installed on /.
		else define("DOCROOT_WS_BASE_DIR",	'');
//		} // if
//	else define("DOCROOT_WS_BASE_DIR",		'');

	define("CMS_DOMAIN",			$_SERVER['SERVER_NAME']);
	define("CMS_DOMAIN_IP",			(!empty($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR']:'127.0.0.1'));
	define("CMS_DOMAIN_PORT",		(!empty($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT']:''));
	define("CMS_SITE_TYPE",			(!empty($_SERVER['HTTPS']) ? 'NO_SSL':'SSL'));
	define("CMS_URI_ALIAS",			DOCROOT_WS_BASE_DIR);

	define('CMS_NL',				"<br>" . PHP_EOL);

	define('CLI_MODE',				false);

	} // if
else if(((defined('CLI_MODE')) && (CLI_MODE)) ||
	(!isset($SERVER))) { // running in CLI
	//	cli status definition

	define("CMS_SITE_TYPE",			'NO_SSL');
	define("CMS_URI_ALIAS",	'');	// directory on server with web pages, usually the web pages alias setting

	define("CMS_DOMAIN",			'CLI');
	define("CMS_DOMAIN_IP",			'10.10.10.10');
	define("CMS_DOMAIN_PORT",		0);

	define('CMS_NL',					PHP_EOL);

	} // else if
else  { // ?? what am I doing ???
	echo "HOST ERROR: Cannot determine set up requirements.\n";
	if(!empty($_SERVER)) {
		echo PHP_EOL . "Server variables " . '($_SERVER)' . ":" . PHP_EOL;
		var_dump($_SERVER);
		} // if
	exit(1);
	} // else

define("CMS_DIR",						'cms/');
define("CMS_WS_DIR",					CMS_DIR);	// to match other define styles
define("CMS_FS_DIR",					DOCROOT_FS_BASE_DIR . CMS_DIR);

// 3rd third library code
define("CMS_WS_LIB_DIR",				CMS_WS_DIR . "lib/");
define("CMS_FS_LIB_DIR",				CMS_FS_DIR . "lib/");

// cli/ never used directly in web code, never directly called
define("CMS_FS_CLI_DIR",				CMS_FS_DIR . "cli/");
define("CMS_WS_CLI_DIR",				CMS_WS_DIR . "cli/");

// absolute dirs(quickies)
define("CMS_FS_INCLUDES_DIR",			CMS_FS_DIR . 'include/');
define("CMS_FS_OPS_DIR",				CMS_FS_INCLUDES_DIR . 'ops/');
define("CMS_FS_CLASSES_DIR",			CMS_FS_INCLUDES_DIR . 'classes/');
define("CMS_FS_PLUGINS_DIR",			CMS_FS_INCLUDES_DIR . 'plugins/');
define("CMS_FS_INI_DIR",				CMS_FS_INCLUDES_DIR . 'ini/');
define("CMS_FS_JS_DIR",					CMS_FS_DIR . 'js/');
define("CMS_FS_CSS_DIR",				CMS_FS_DIR . 'css/');

// for autoload (does not need rebuilding)
define("CMS_WS_INCLUDES_DIR",			CMS_WS_DIR . 'include/');
define("CMS_WS_OPS_DIR",				CMS_WS_INCLUDES_DIR . 'ops/');
define("CMS_WS_CLASSES_DIR",			CMS_WS_INCLUDES_DIR . 'classes/');
define("CMS_WS_PLUGINS_DIR",			CMS_WS_INCLUDES_DIR . 'plugins/');
define("CMS_WS_INI_DIR",				CMS_WS_INCLUDES_DIR . 'ini/');
define("CMS_WS_JS_DIR",					CMS_WS_DIR . 'js/');
define("CMS_WS_CSS_DIR",				CMS_WS_DIR . 'css/');

// AppsCMS fix images
define("CMS_WS_IMAGES_DIR",				CMS_WS_DIR . 'images/');
define("CMS_FS_IMAGES_DIR",				CMS_FS_DIR . 'images/');
define("CMS_WS_ICONS_DIR",				CMS_WS_DIR . 'icons/');
define("CMS_FS_ICONS_DIR",				CMS_FS_DIR . 'icons/');

// examples
define("CMS_WS_EXAMPLES_DIR",			"examples/");
// define("CMS_FS_EXAMPLES_DIR",		DOCROOT_FS_BASE_DIR . "examples/");

// the doxygen documentation dirs (needs to match settings CMS_WS_DOXY_DIR configs)
define("CMS_WS_DOXY_DIR",				CMS_WS_DIR . "doxy/");
define("CMS_FS_DOXY_DIR",				CMS_FS_DIR . "doxy/");
define("DOXY_WS_DOCS_DIR",				"doxy/");
define("DOXY_FS_DOCS_DIR",				DOCROOT_FS_BASE_DIR . "doxy/");
define("DOXY_WS_DOCS_APPS_CMS_DIR",		DOXY_WS_DOCS_DIR . "apps_cms_html/");
define("DOXY_FS_DOCS_APPS_CMS_DIR",		DOXY_FS_DOCS_DIR . "apps_cms_html/");
define("DOXY_WS_DOCS_CMS_DIR",			DOXY_WS_DOCS_DIR . "cms_html/");
define("DOXY_FS_DOCS_CMS_DIR",			DOXY_FS_DOCS_DIR . "cms_html/");
define("DOXY_WS_DOCS_APPS_DIR",			DOXY_WS_DOCS_DIR . "apps_html/");
define("DOXY_FS_DOCS_APPS_DIR",			DOXY_FS_DOCS_DIR . "apps_html/");

define("ETC_DIR",						'etc/');
define("ETC_FS_DIR",					DOCROOT_FS_BASE_DIR . ETC_DIR);

// css files theme files
define('ETC_WS_CSS_DIR',				ETC_DIR . "css/");
define('ETC_FS_CSS_DIR',				ETC_FS_DIR . "css/");

// ini/ never used directly in web code, never directly called
define("ETC_FS_INI_DIR",				ETC_FS_DIR . "ini/");

// sqlite not allowed to WS, never directly called
define("ETC_FS_SQLITE_DIR",				ETC_FS_DIR . 'sqlite/');

define("ETC_WS_EXT_INCLUDES_DIR",		ETC_DIR . 'ext/');
define("ETC_FS_EXT_INCLUDES_DIR",		ETC_FS_DIR . 'ext/');

define("ETC_WS_SSL_INCLUDES_DIR",		ETC_DIR . 'ssl/');
define("ETC_FS_SSL_INCLUDES_DIR",		ETC_FS_DIR . 'ssl/');

define("ETC_WS_IMAGES_DIR",				ETC_DIR . 'images/');
define("ETC_FS_IMAGES_DIR",				ETC_FS_DIR . 'images/');

define("ETC_WS_ICONS_DIR",				ETC_DIR . 'icons/');
define("ETC_FS_ICONS_DIR",				ETC_FS_DIR . 'icons/');

define("ETC_WS_BACKGROUNDS_DIR",		ETC_DIR . 'backgrounds/');
define("ETC_FS_BACKGROUNDS_DIR",		ETC_FS_DIR . 'backgrounds/');

define("APPS_DIR",						'apps/');
define("APPS_WS_DIR",					APPS_DIR);
define("APPS_FS_DIR",					DOCROOT_FS_BASE_DIR . APPS_DIR);
define('APPS_FS_CLI_DIR',				APPS_FS_DIR . 'cli/');
define('APPS_WS_CLI_DIR',				APPS_WS_DIR . 'cli/');
define("APPS_FS_INCLUDE_DIR",			APPS_FS_DIR . 'include/');
define("APPS_WS_INCLUDE_DIR",			APPS_WS_DIR . 'include/');
define("APPS_FS_PLUGINS_DIR",			APPS_FS_INCLUDE_DIR . 'plugins/');
define("APPS_WS_PLUGINS_DIR",			APPS_WS_INCLUDE_DIR . 'plugins/');
define("APPS_FS_CLASSES_DIR",			APPS_FS_INCLUDE_DIR . 'classes/');
define("APPS_WS_CLASSES_DIR",			APPS_WS_INCLUDE_DIR . 'classes/');
define("APPS_FS_DOCS_DIR",				APPS_FS_DIR . 'docs/');
define("APPS_WS_DOCS_DIR",				APPS_WS_DIR . 'docs/');
define('APPS_FS_LIB_DIR',				APPS_FS_DIR . 'lib/');
define('APPS_WS_LIB_DIR',				APPS_WS_DIR . 'lib/');
define('APPS_FS_IMAGES_DIR',			APPS_FS_DIR . 'images/');
define('APPS_WS_IMAGES_DIR',			APPS_WS_DIR . 'images/');
define('APPS_FS_ICONS_DIR',				APPS_FS_DIR . 'icons/');
define('APPS_WS_ICONS_DIR',				APPS_WS_DIR . 'icons/');
define('APPS_FS_JS_DIR',				APPS_FS_DIR . 'js/');
define('APPS_WS_JS_DIR',				APPS_WS_DIR . 'js/');
define('APPS_FS_CSS_DIR',				APPS_FS_DIR . 'css/');
define('APPS_WS_CSS_DIR',				APPS_WS_DIR . 'css/');

// apps config ini
define("APPS_FS_INI_DIR",				APPS_FS_INCLUDE_DIR . 'ini/');
define("ETC_FS_APPS_CONFIG",			ETC_FS_DIR . 'ini/apps.ini');
define("APPS_FS_APPS_CONFIG_DEFAULT",	APPS_FS_INI_DIR . 'apps.defaults.ini');
define("APPS_FS_CONFIG_MSGS",			APPS_FS_INI_DIR . 'apps.comments.ini');
define("ETC_FS_APPS_CONFIG_JSON",		ETC_FS_DIR . 'ini/apps.json');	// default location

define('APPS_BODIES_DIR',				APPS_DIR . 'bodies/');
define('APPS_BODIES_WS_DIR',			APPS_BODIES_DIR);
define('APPS_BODIES_FS_DIR',			DOCROOT_FS_BASE_DIR . APPS_BODIES_DIR);

define('PAGE_HEADER_INC',				'header.html.inc');
define('PAGE_HEADER_WS_INC',			APPS_BODIES_WS_DIR . PAGE_HEADER_INC);
define('PAGE_HEADER_FS_INC',			APPS_BODIES_FS_DIR . PAGE_HEADER_INC);

define('PAGE_FOOTER_INC',				'footer.html.inc');
define('PAGE_FOOTER_WS_INC',			APPS_BODIES_WS_DIR . PAGE_FOOTER_INC);
define('PAGE_FOOTER_FS_INC',			APPS_BODIES_FS_DIR . PAGE_FOOTER_INC);

//
// AppsCMS config ini
define("CMS_FS_CMS_CONFIG_DEFAULT",		CMS_FS_INI_DIR . 'cms.defaults.ini');
define("CMS_FS_CMS_CONFIG_MSGS",		CMS_FS_INI_DIR . 'cms.comments.ini');
define("CMS_FS_CMS_USER_DEFAULT",		CMS_FS_INI_DIR . 'cms.default.user.json');
define("CMS_FS_CMS_RESPONSE_CODES",		CMS_FS_INI_DIR . 'cms.response_codes.ini');
define("CMS_FS_CMS_STD_COLOURS",		CMS_FS_INI_DIR . 'cms.std_colours.ini');
define("CMS_FS_CMS_LIBS_DIRS",			CMS_FS_INI_DIR . 'cms.libs2scan.ini');
define("ETC_FS_CMS_CONFIG",				ETC_FS_INI_DIR . 'cms.ini');
define("ETC_FS_CONFIG_JSON",			ETC_FS_INI_DIR . 'cms.json');
define("ETC_FS_AUTOLOAD_JSON",			ETC_FS_INI_DIR . 'cms_autoload.json');
define("ETC_FS_EXT_LIB_JSON",			ETC_FS_INI_DIR . 'ext_lib_autoload.json');
define("ETC_FS_CMS_WYSIWYGS",			ETC_FS_INI_DIR . 'cms_wysiwyg.json');
define("ETC_FS_CMS_API",				ETC_FS_INI_DIR . 'api.json');

// AppsCMS variables included in file versioning
define("ETC_FS_SITE_DATA_DIR",			ETC_FS_DIR . 'variables/');

define("LOCAL_TOOLS_DIR",					'localtools/');
define("LOCAL_WS_TOOLS_DIR",			LOCAL_TOOLS_DIR);
define("LOCAL_FS_TOOLS_DIR",			DOCROOT_FS_BASE_DIR . LOCAL_TOOLS_DIR);
define("LOCAL_WS_TOOLS_IMAGES_DIR",		LOCAL_TOOLS_DIR . 'images/');
define("LOCAL_WS_TOOLS_ICONS_DIR",		LOCAL_TOOLS_DIR . 'icons/');
define("LOCAL_FS_TOOLS_IMAGES_DIR",		LOCAL_FS_TOOLS_DIR . 'images/');
define("LOCAL_FS_TOOLS_ICONS_DIR",		LOCAL_FS_TOOLS_DIR . 'icons/');

// Apps media directory
define("MEDIA_DIR",						'media/');
define("MEDIA_WS_DIR",					MEDIA_DIR);
define("MEDIA_FS_DIR",					DOCROOT_FS_BASE_DIR . MEDIA_DIR);

define("VAR_DIR",						'var/');
define("VAR_WS_DIR",					VAR_DIR);
define("VAR_FS_DIR",					DOCROOT_FS_BASE_DIR . VAR_DIR);

define("VAR_FS_CACHE_DIR",				VAR_FS_DIR . "cache/");
define("VAR_FS_BACKUP_DIR",				VAR_FS_DIR . "backups/");
define("VAR_FS_EXPORT_DIR",				VAR_FS_DIR . "exports/");
define("VAR_FS_RUN_DIR",				VAR_FS_DIR . "run/");
define("VAR_FS_TEMP_DIR",				VAR_FS_DIR . "temp/");
define("VAR_FS_TRASH_DIR",				VAR_FS_DIR . "Trash/");
define("VAR_FS_VARIABLES_DIR",			VAR_FS_DIR . "variables/");
define("VAR_FS_USERS_DIR",				VAR_FS_VARIABLES_DIR . "users/");
define("VAR_FS_API_KEYS_DIR",			VAR_FS_VARIABLES_DIR . "public_keys/");

define("VAR_WS_APPS_DIR",				VAR_WS_DIR . "apps/");
define("VAR_FS_APPS_DIR",				VAR_FS_DIR . "apps/");

define("VAR_WS_CACHE_APPS_DIR",			VAR_WS_DIR . "cache/apps/");
define("VAR_FS_CACHE_APPS_DIR",			VAR_FS_DIR . "cache/apps/");

define("VAR_WS_CACHE_GOTCHA_DIR",		VAR_WS_DIR . "cache/gotcha/");
define("VAR_FS_CACHE_GOTCHA_DIR",		VAR_FS_DIR . "cache/gotcha/");

define("VAR_WS_CACHE_MINIFY_DIR",		VAR_WS_DIR . "cache/min/");
define("VAR_FS_CACHE_MINIFY_DIR",		VAR_FS_DIR . "cache/min/");

define("VAR_FS_CACHE_UPLOADS_DIR",		VAR_FS_DIR . "cache/_uploads/");

// auth tables
define("VAR_FS_AUTH_DIR",				VAR_FS_VARIABLES_DIR . "auth/");

// proxy control tables
define("VAR_FS_PROXY_DIR",				VAR_FS_VARIABLES_DIR . "proxy/");

// cache/contents is always an include file, never directly called
define("VAR_FS_CACHE_CONTENTS_DIR",		VAR_FS_CACHE_DIR . "contents/");

// language translation cache directory
define('VAR_FS_TRANSLATIONS_DIR',		VAR_FS_CACHE_DIR . 'translations/');

// local session storage directory
define("VAR_FS_SESSION_DIR",			VAR_FS_DIR . 'sessions/');	// session save directory

define("VAR_FS_LOGS_DIR",				VAR_FS_DIR . "logs/");
define('SESSION_RELOADED_MRKER',		VAR_FS_VARIABLES_DIR . 'session_reload_mrkr');

ini_set('log_errors','On');
ini_set('error_log',					VAR_FS_LOGS_DIR . CMS_DOMAIN . '_startup_error.log');

// not available directly from web
define("APPS_FS_APPS_MANUAL",			APPS_FS_DOCS_DIR . 'apps_manual.php');

// common CRON job script, not available directly from web
define("APPS_FS_APPS_CRON_SCRIPT",		APPS_FS_CLI_DIR . 'apps_cron.sh');
define("APPS_WS_APPS_CRON_SCRIPT",		APPS_WS_CLI_DIR . 'apps_cron.sh');
define("APPS_FS_APPS_CRON_PHP",			APPS_FS_CLI_DIR . 'apps_cron.php');
define("APPS_WS_APPS_CRON_PHP",			APPS_WS_CLI_DIR . 'apps_cron.php');

// set no data base login creds
define("CMS_DEFAULT_ADMIN",				'admin');
define("CMS_DEFAULT_PASSWORD",			'password');

// cookies
define("CMS_LOGIN_COOKIE_NAME",			preg_replace('/[\/.,\\ ]+/', '_', CMS_URI_ALIAS) . '_CMS_Login_id');

// standard non accessed filename and directories
define("CMS_DONT_ACCESS_PATH_PATTERN",	'/^\.|^_|\/\.$|\/\.\.$|^\.\.$|^\.$|\.git$|\.svn$|\.hg$/si');	// this is used with preg_*() as the file/dir reject pattern
define("CMS_DONT_ACCESS_PATH_SYSTEM_PATTERN",	'/\/\.$|\/\.\.$|^\.\.$|^\.$|\.git$|\.svn$|\.hg$/si');	// this is used with preg_*() as the system file/dir reject pattern
define("CMS_DONT_ACCESS_PATH_HIDDEN_PATTERN",	'/^\.|^_/si');	// this is used with preg_*() as the hidden file/dir reject pattern
define("CMS_DONT_ZIP_PATH_PATTERN",	'/\/\.$|\/\.\.$|^\.\.$|^\.$|\.git$|\.svn$|\.hg$/si');	// this is used with preg_*() as the file/dir reject pattern

// AppsCMS logo
define("CMS_IMAGE_LOGO",				CMS_WS_IMAGES_DIR . 'AppsCMS_logo.gif');

// sitemap files
define('CMS_SITEMAP_HTML_FILE',			"sitemap.html");
define('CMS_SITEMAP_XML_FILE',			"sitemap.xml");

// language translate HTML section names
define('CMS_LANG_DEFAULT',				'en-AU');
define('CMS_LANG_ORIG_ELEM',			'lang-orig');	// original text, lowercase only, must contain a hyphen
define('CMS_LANG_TRANS_ELEM',			'lang-trans');	// translated text, lowercase only, must contain a hyphen
	
// SQLite based cache databases
define('CMS_TRANSLATED_CACHE_DB',		ETC_FS_SQLITE_DIR . 'cms_translated_cache.sqlite');
define('CMS_VALIDATED_DB',				ETC_FS_SQLITE_DIR . 'cms_validated.sqlite');
define('CMS_VALIDATED_JSON',			ETC_FS_INI_DIR . 'cms_validated.json');

// EOF
