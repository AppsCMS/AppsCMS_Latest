<?php
/*
* Applications Management System Library for PHP (AppsCMS)
* see Licence in cms/LICENCE.txt
* _SVN_build: $Id: directory_structure.php 3251 2023-03-02 12:50:06Z robert0609 $
*/

?>
			<pre class="page_config">
\ (&quot;(DOCROOT)/[alias/]&quot;)		Web site base directory (maybe &quot;(DOCROOT)/&quot; or a directory / alias under &quot;(DOCROOT)/(alias)/&quot;).
│
├── index.php              Primary web site access hook file check/mount readonly filesystems and inlcude &quot;<?= CMS_WS_DIR ?>cms_index.php&quot;.
├── login.php              Web site login hook file to check/mount readonly filesystems and inlcude &quot;<?= CMS_WS_DIR ?>cms_login.php&quot;.
├── logout.php             Web site logout hook file to check/mount readonly filesystems and inlcude &quot;<?= CMS_WS_DIR ?>cms_logout.php&quot;.
├── ajax.php               AJAX hook file to check/mount readonly filesystems and inlcude &quot;<?= CMS_WS_DIR ?>cms_ajax.php&quot;.
├── api.php                API hook file to check/mount readonly filesystems, by default and inlcude &quot;<?= CMS_WS_DIR ?>cms_api.php&quot;.
│
├── <?= APPS_WS_DIR ?>		Base directory for web applications (apps code supplied by user). Contains fixed code.
│   ├── cli                Apps common command line operations.
│   ├── bodies             Web body/apps (initial hooks include files) directory.
│   ├── docs               Apps common documents directory (readmes, release notes, terms, license eula, manuals, etc.
│   ├── include            Apps common include directory.
│   │   ├── classes        Apps common classes directory (autoload classes looks in here).
│   │   └── ini            Apps common fixed INI and JSON hard coded control files directory.
│   ├── js         Apps common js directory.
│   ├── lib                Apps common libraries directory.
│   ├── plugins            Apps commonplugin directory (autoload classes looks in here).
│   ├── css        Apps common stylesheet directory.
│   └── (other)            Other Apps directories as required.
│                          Most applications will have a directory structure under <?= APPS_WS_DIR ?>.
│                          e.g &quot;<?= APPS_WS_DIR ?>(APP_DIR)/&quot; setup through the Admin -> Apps / Bodies menu.
├── apps_fs_sqsh.sqsh      Read only mount of the &quot;<?= APPS_WS_DIR ?>&quot; directory (optional).
│
├── <?= CMS_WS_DIR ?>        Base <?= CMS_PROJECT_SHORTNAME ?> library directory (this directory is overwritten by <?= CMS_PROJECT_SHORTNAME ?> updates).
│   ├── cli                <?= CMS_PROJECT_SHORTNAME ?> command line operations (e.g. rebuild, backup, etc.).
│   ├── dist               The <?= CMS_PROJECT_SHORTNAME ?> installer creates this directory to save install/update files (e.g. <?= CMS_PROJECT_SHORTNAME ?>-Vn.nn.zip).
│   │
│   ├── examples           Example code for user directories (copy the required directory to document root to engage the examples).
│   │   │                       Note: Examples are contained in a ZIP archive
│   │   ├── apps           Example apps/ directory layout.
│   │   │   │
│   │   │   ├── cli                                 Example apps command line operations.
│   │   │   │   ├── example_apps_cron.sh            Example apps common CRON engagement shell script called from crontab.
│   │   │   │   └── example_apps_cron.php           Example apps common CRON engagement PHP script (usually called by the shell script).
│   │   │   │
│   │   │   ├── bodies                              App bodies (or apps links) directory (controlled by Admin -> Apps / Bodies menu).
│   │   │   │   ├── example_cms_body.php            Example body file (may be an app or a standard web page).
│   │   │   │   ├── example_contactus_cms_body.php  Example use of the contactus plugin.
│   │   │   │   ├── example_login_cms_body.php      Example use of a login page.
│   │   │   │   └── example_welcome_cms_body.php    Example of a full view web page (header, body and footer all integrated).
│   │   │   │
│   │   │   ├── docs                                Example apps documents (common applications documents, manual, readme, eula, etc.).
│   │   │   │   ├── README-apps.txt                 Apps README file.
│   │   │   │   ├── example_apps_manual.php         Example apps code / applications manual file.
│   │   │   │   ├── example_cookie_banner.html      Example cookie banner file.
│   │   │   │   └── example_cookie_policy.html      Example cookie policy file.
│   │   │   │
│   │   │   ├── example_app1                        Example app 1 directory (e.g. standard application)
│   │   │   │   ├── backgrounds                     Example app 1 application specific background images.
│   │   │   │   ├── classes                         Example app 1 application specific classes directory (autoload looks in here for app classes).
│   │   │   │   │   └── example_app1_app.php        Example app 1 class (NOTE: _app suffix).
│   │   │   │   ├── cli                             Example app 1 application specific command line code.
│   │   │   │   ├── docs                            Example app 1 application documents directory
│   │   │   │   │                                         (readmes, releasenotes, terms, license, eula, manual, etc.).
│   │   │   │   ├── icons                           Example app 1 application specific fixed icons.
│   │   │   │   ├── include                         Example app 1 application specific include directory.
│   │   │   │   │   ├── app_css.php                 Example app 1 application specific theme style sheet theme recipe to generate app.css (optional).
│   │   │   │   │   ├── app_config.php              Example app 1 application specific configuration (and definitions) file (optional).
│   │   │   │   │   └── app_head_inc.php            Example app 1 application specific &lt;head&gt; include file (optional).
│   │   │   │   ├── images                          Example app 1 application specific fixed images.
│   │   │   │   ├── ini                             Example app 1 application specific configuration control.
│   │   │   │   │   ├── app.comments.ini            Example app 1 application specific configuration comments
│   │   │   │   │   │                                     (for app config control and help text) file (optional).
│   │   │   │   │   └── app.defaults.ini            Example app 1 application specific configuration defaults
│   │   │   │   │                                         (for app config default values) file (optional).
│   │   │   │   ├── js                      Example app 1 application specific js directory.
│   │   │   │   │   └── app.js                      Example app 1 application specific js code file
│   │   │   │   │                                         (automatically linked in to &lthead&gt html section when the application is engaged, optional).
│   │   │   │   ├── lib                             Example app 1 application specific library code.
│   │   │   │   ├── plugins                         Example app 1 plugins directory (autoload looks in here for app plugins).
│   │   │   │   ├── css                     Example app 1 application specific css directory.
│   │   │   │   │   ├── app.css                     Example app 1 application specific stylesheet file
│   │   │   │   │   └── app.scss                    Example app 1 application specific stylesheet source code file
│   │   │   │   │                                         (automatically linked in to &lthead&gt html section when the application is engaged, optional).
│   │   │   │   └── example_app1.php                An example app 1 code file.
│   │   │   │
│   │   │   ├── example_app2                        Example app 2 directory (simple application)
│   │   │   │   └── example_app2.php                An example app 2 code file.
│   │   │   │
│   │   │   ├── images                              Common app images
│   │   │   │
│   │   │   ├── include                             Common app include files.
│   │   │   │   ├── classes                         Common apps class files (autoload looks in here for common apps classes).
│   │   │   │   │   ├── example_apps_auth.php       Example apps authentication class.
│   │   │   │   │   └── example_dyn_cntl_base.php   Example dynamic control base class.
│   │   │   │   ├── example_apps_config.php         Example apps configuration file.
│   │   │   │   ├── example_apps_css.php            Example apps theme generator file.
│   │   │   │   ├── ini                             Example apps ini settings configuration directory.
│   │   │   │   │   ├── example.apps.comments.ini   Example apps configuration comment file.
│   │   │   │   │   └── example.apps.defaults.ini   Example apps default configuration file.
│   │   │   │   └── plugins                         Common apps plugins files (autoload looks in here for common apps plugins).
│   │   │   │       ├── example_app_extend.php      Example apps extended plugin class.
│   │   │   │       ├── example_app.php             Example apps plugin class.
│   │   │   │       └── example_dyn_cntl_app.php    Example apps dynamic control plugin class.
│   │   │   │
│   │   │   ├── js                          Apps common js directory.
│   │   │   │   └── apps.js							Apps common js code file
│   │   │   │
│   │   │   └── css                         Apps common css directory.
│   │   │        ├── apps.css                       Apps common stylesheet file
│   │   │        └── apps.scss                      Apps common stylesheet source code file (compiled on the fly)
│   │   │
│   │   ├── etc                                     Etc directory examples.
│   │   │   ├── ext                                 External code and extra code directory examples for include
│   │   │   │   └── example_google_analytics.php    Example Google analytics file.
│   │   │   └── ini                                 INI directory examples
│   │   │       └── example_cms_wysiwyg.json                Example WYSIWYG configuration file.
│   │   │
│   │   ├── Test code                           Useful test code.
│   │   │
│   │   └── Example application and tool installation packages.
│   │
│   ├── images             <?= CMS_PROJECT_SHORTNAME ?> images directory (used by the <?= CMS_PROJECT_SHORTNAME ?>).
│   │   └── manual         Images for the <?= CMS_PROJECT_SHORTNAME ?> manual.
│   ├── includes           <?= CMS_PROJECT_SHORTNAME ?> includes (not include like apps) directory.
│   │   ├── classes        <?= CMS_PROJECT_SHORTNAME ?> classes directory (autoload classes looks in here).
│   │   ├── ini            <?= CMS_PROJECT_SHORTNAME ?> fixed INI and JSON hard coded control files directory.
│   │   ├── ops            <?= CMS_PROJECT_SHORTNAME ?> operations directory (e.g. login, login, edit config, etc.).
│   │   └── plugins        <?= CMS_PROJECT_SHORTNAME ?> plugin directory (autoload classes looks in here).
│   └── lib                Local copy of <?= CMS_PROJECT_SHORTNAME ?> 3rd party libraries, a directory for each library.
│       └── README_libs.md <?= CMS_PROJECT_SHORTNAME ?> readme on 3rd party libraries.
├── cms_lib_sqsh.sqsh      Read only mount of the ./cms directory (optional).
│
├── <?= ETC_DIR ?>		Config base directory (contains the editable configuration files).
│   │── backgrounds        Custom/uploaded background images directory.
│   ├── ext                Directory for external code (e.g. Google Analytics, etc. code).
│   ├── css                Generated (themed) css for <?= CMS_PROJECT_SHORTNAME ?> and applications.
│   │── icons              Custom icons directory.
│   ├── images             Custom/uploaded web page images directory.
│   ├── ini                Edited configuration/options INI and JSON file directory.
│   ├── sqlite             The <?= CMS_PROJECT_SHORTNAME ?> sqlite configuration database directory.
│   └── (other)            Other Apps config directories as required.
│
├── <?= LOCAL_WS_TOOLS_DIR ?>		Local tools directory (supplied by user).
│
└── <?= VAR_WS_DIR ?>		Temporary / transitory data directory (should not need to be backed up).
   ├── apps               Applications data directory for Apps.
   ├── backups            Backups directory.
   ├── cache              Cache directory (each application has a sub-directory).
   ├── exports            Exports directory.
   ├── logs               Logs files.
   ├── sessions           PHP user session data directory (if used).
   ├── Trash              General directory for deleted files (local recycle bin).
   ├── variables          Variable storage directory (e.g. counts, stats, etc.).
   └── (other)            Other Apps variable directories as required.
			</pre>

<br>
<b>Note:</b>
The &quot;index.php&quot;, &quot;ajax.php&quot;, &quot;api.php&quot;, &quot;ws.php&quot;, &quot;login.php&quot; and  &quot;logout.php&quot; files
in (&quot;(DOCROOT)/[alias/]&quot;) are considered hook files. Often these files are modified or replaced for application requirements.
As a reference, the &quot;<?= CMS_WS_DIR ?>docroot_files/&quot; directory contains the default code.
