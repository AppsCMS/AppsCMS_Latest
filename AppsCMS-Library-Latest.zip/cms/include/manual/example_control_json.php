<?php
/*
* Applications Management System Library for PHP (AppsCMS)
* see Licence in cms/LICENCE.txt
* _SVN_build: $Id: example_control_json.php 2786 2022-08-31 05:40:44Z robert0609 $
*/
?>

The JSON file format allows a much broader scope for settings allowing type and selections settings controlled from the comments.JSON (i.e the controlling JSON).
The &quot;apps_comments.json&quot; is the controlling entity for the Ccms_edit class.
<br>
For example;-
<pre class="page_config">

	<?php readfile(CMS_FS_INCLUDE_MANUAL_DIR . 'example_controls.json') ?>

</pre>
