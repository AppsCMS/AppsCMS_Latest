<?php
/*
* Applications Management System Library for PHP (AppsCMS)
* see Licence in cms/LICENCE.txt
* _SVN_build: $Id: example_api_map.php 2786 2022-08-31 05:40:44Z robert0609 $
*/
?>

The API mapping follows the &quot;OpenAPI&quot; V2.0.

A &quot; Swagger&quot; API test is available at &quot;<a href="index.php?cms_action=cms_api_test" target="_blank">Admin-&gt;API Test</a>&quot;.

The API map summary (URI=&quot;/apt/summary&quot;) is self explanatory.
<br>
The current API map is;-
			<pre class="page_config">
		<?= htmlentities(Ccms_base::json_encode(Ccms_api_map::get_api_resource_map())) ?>
			</pre>

The &quot;paths&quot; array accommodates applications as;-

			<pre class="page_config">
			'paths' => array(
				'/(APP_NAME)/my_get_data' => array(	// API request path
					'_role' => '', // 'admin' or 'manager' or 'user' or 'public' (default), access setting
					'_func' => 'my_get_api_data',	// internal function to callback in (APP_NAME) class
					'get' => array(	// or put, etc.
						// ...
						),
					),

			</pre>

<b>Note</b> The minimum requirements for an API call are;-
<ul class="page_config">
	<li class="page_config">&quot;path&quot; - the URI path (with part of the request and is decode by the web server).</li>
	<li class="page_config">&quot;_role&quot; - used for security/access control (default is public, anyone can see)</li>
	<li class="page_config">
		&quot;_func&quot; - the function (global) or method (in the app's primary class) the <?= CMS_PROJECT_SHORTNAME ?> calls to process requests.
		The parameters passed to the &quot;_func&quot; are as _func($method,&amp;$func_cntl,&amp;$params), where;-
		<ul class="page_config">
			<li class="page_config">&quot;$method&quot; is get, post, etc. - the request method from the client to request different server methods.</li>
			<li class="page_config">&quot;&amp;$func_cntl&quot; is a pointer to the controls under the methods in the API map.</li>
			<li class="page_config">&quot;&amp;$params&quot; is a pointer to the parameters array (maybe passed by ['name'] or by order [0], [1], etc.</li>
		</ul>
	</li>
	<li class="page_config">&quot;method (get, post, etc.)&quot; - the request method from the client to request different server methods.</li>
	<li class="page_config">&quot;parameters&quot; - the paramter controls for the (_func) to provide / check function or method paramters.</li>
</ul>

