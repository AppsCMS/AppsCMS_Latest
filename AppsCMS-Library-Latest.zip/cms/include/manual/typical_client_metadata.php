<?php
/*
* Applications Management System Library for PHP (AppsCMS)
* see Licence in cms/LICENCE.txt
* _SVN_build: $Id: typical_client_metadata.php 2793 2022-09-10 06:40:19Z robert0609 $
*/
?>

Client browser metadata. The <?= CMS_PROJECT_SHORTNAME ?> provides an automated client metadata ajax response
(along the cookie discussed above) from the client browser and is saved in the Ccms_base::get_cms_sess_var('clientMetadata').
This feature can be disabled/enabled by the configuration.
It provides metadata feedback for applications that need to know the dimensions (e.g. depth, width, height, timezone, language, etc.) of the client&rsquo;s browser window.
This is typical metadata;-
<pre class="page_config">
	Ccms_base::get_cms_sess_var('clientMetadata') = {
			window_innerWidth: window.innerWidth,
			window_innerHeight: window.innerHeight,
			window_outerWidth: window.outerWidth,
			window_outerHeight: window.outerHeight,
			screen_width: screen.width,
			screen_height: screen.height,
			screen_colourDepth: screen.colorDepth,
			screen_pixelDepth: screen.pixelDepth,
			screen_availWidth: screen.availWidth,
			screen_availHeight: screen.availHeight,
			user_lang: (n.language || n.userLanguage),
			char_set: document.characterSet,
			timezone_minutes: d.getTimezoneOffset(),
			time_ms: d.getTime(),	// milliseconds from 00:00:00.000 on the 1st of January 1970
			date: d.toJSON(),	// formated as the ISO-8601 standard: YYYY-MM-DDTHH:mm:ss.sssZ
			cookies_enabled: n.cookieEnabled,
			name: n.appName,
			code_name: n.appCodeName,
			platform: n.platform,
			product: n.product,
			vendor: n.vendor,
			agent: n.userAgent,
			version: n.appVersion,
			isIE5IE6: (window.XMLHttpRequest ? false:true),
			isOpera: isOpera,	// Opera 8.0+
			isFirefox: isFirefox,	// Firefox 1.0+
			isSafari: isSafari,	// Safari 3.0+ "[object HTMLElementConstructor]"
			isIE: isIE,	// Internet Explorer 6-11
			isEdge: (!(isIE || !!document.documentMode) && !!window.StyleMedia),	// Edge 20+
			isChrome: isChrome,	// Chrome 1 - 79
			isEdgeChromium: (isChrome && (n.userAgent.indexOf("Edg") != -1)),	// Edge (based on chromium) detection
			isVivaldi: isVivaldi, // Vivaldi 1.9
			isBlinkEng: ((isChrome || isOpera) && !!window.CSS),	// Blink engine detection
			};

</pre>

<br>
From &quot;Ccms_metadata&quot; javascipt class.
