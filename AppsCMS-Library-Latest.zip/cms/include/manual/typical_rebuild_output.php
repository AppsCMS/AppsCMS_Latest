<?php
/*
* Applications Management System Library for PHP (AppsCMS)
* see Licence in cms/LICENCE.txt
* _SVN_build: $Id: typical_rebuild_output.php 2935 2022-10-31 10:31:03Z robert0609 $
*/
?>

Successful rebuild output looks similar to this;-
			<pre class="page_config">
				Starting -&gt; rebuilding setup for <?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?>.
				INFO: Installation check.
				INFO: No install issues detected.
				INFO: Checking <?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?> database for updates.
				INFO: Checking table cms_users
				INFO: Checking table cms_bodies
				INFO: Checking table lm_sections
				INFO: Checking table lm_links
				INFO: Checking table cms_tools
				INFO: Checking table cms_configs
				SUCCESS: Checked <?= CMS_S_DB_SQLITE_DATABASE ?> tables - success
				INFO: Installed plugin configs for maplatlong, email, contactus.
				SUCCESS: Updated cms_styles_main.css
				SUCCESS: Updated cms_styles_block.css
				SUCCESS: Updated cms_styles_inline.css
				INFO: DB updated to <?= CMS_PROJECT_VERSION ?>.
				Finished -&gt; rebuilding setup for <?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?>.
			</pre>
<br>
If any errors or warnings occurred, these will be printed out.

