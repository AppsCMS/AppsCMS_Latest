<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: email_client_PHPMailer_6.php 3314 2023-04-11 08:13:04Z robert0609 $
 */

/**
 * Description of email_client
 * The connector class to cms/lib/PHPmailer
 *
 * @author robert0609
 */

// include the classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once CMS_FS_LIB_DIR . 'PHPMailer_6/src/Exception.php';
require_once CMS_FS_LIB_DIR . 'PHPMailer_6/src/PHPMailer.php';
require_once CMS_FS_LIB_DIR . 'PHPMailer_6/src/SMTP.php';

class Cemail_client_PHPMailer_6 extends Ccms_base {

	protected $mailer = false;

	function __construct(&$mailer_conf,$mail_id_str = '') {
		parent::__construct();
		$this->add_headers = array();
		$this->add_params = array();
		if(!empty($mail_id_str)) $this->mail_id_str = $mail_id_str;
		else $this->mail_id_str = 'X-Mailer: PHP v' . phpversion();

		$this->mailer = new PHPMailer(true);
		try {
			//Server settings
			if((!empty($mailer_conf)) && (is_array($mailer_conf))) {
				// do AppsCMS config to PHPMailer setting
				foreach($mailer_conf as $k => $v) {
					$v = self::conv_conf_val_to_type($v);
					switch($k) {
					case 'AUTH': $this->mailer->SMTPAuth = $v; break;	// $this->mailer->SMTPAuth   = true;                                   //Enable SMTP authentication
					case 'AUTH_TYPE': $this->mailer->AuthType; break;
					case 'DEBUG': $this->mailer->SMTPDebug = $v; break;	// $this->mailer->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
					case 'DEBUG_OUTPUT': $this->mailer->Debugoutput = $v; break;
					case 'HOST': $this->mailer->Host = $v; break;	// $this->mailer->Host       = 'smtp.example.com';                     //Set the SMTP server to send through
					case 'PASSWORD': $this->mailer->Password = $v; break;	// 	$this->mailer->Password   = 'secret';                               //SMTP password
					case 'PORT': $this->mailer->Port = (int)$v; break;	// $this->mailer->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
					case 'SECURE':
						// Options: '', PHPMailer::ENCRYPTION_STARTTLS, or PHPMailer::ENCRYPTION_SMTPS.
						// $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
						switch($v) {
						case 'tls': $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; break;
						case 'ssl': $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; break;
						default: $this->mailer->SMTPSecure = ''; break;
						break;
						} // switch
					case 'TIMEOUT': $this->mailer->Timeout = (int)$v; break;
					case 'USERNAME': $this->mailer->Username = $v; break;	// $this->mailer->Username   = 'user@example.com';                     //SMTP username
					case 'WORDWRAP': $this->mailer->WordWrap = $v; break;	// Set word wrap to 50 characters
					default: break;	// not used
						} // switch
					} // foreach
				} // if
			// load language
			$code = strtolower(Ccms_base::get_user_language());
			$this->mailer->setLanguage($code);
			$this->mailer->XMailer = $this->mail_id_str;	// set id
			$this->mailer->isSMTP();	//Send using SMTP
			} // try
		catch (Exception $e) {
			self::addAdminMsg("Mailer could not be configured. Mailer Error: {$this->mailer->ErrorInfo}");
			return;
			} // catch

		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	protected function isHTML($text){
		$processed = htmlentities($text);
		if($processed == $text) return false;
		return true;
		} // isHTML()

	public function send(
			$to_name,
			$to_email_address,
			$email_subject,
			$email_text,
			$from_email_name = '',
			$from_email_address = '',
			$attached_filenames = ''
			) {

		if(!PL_CMS_EMAIL_SEND_EMAILS) return true;

		if (empty($to_email_address) || empty($email_subject) || empty($email_text)) {
			self::log_msg(__CLASS__ . '->' . __FUNCTION__ . '; not all parameters provided.','warn');
		    return false;
			} // if

		try {
			//Recipients
			$this->mailer->setFrom($from_email_address, $from_email_name);
			$this->mailer->addAddress($to_email_address, $to_name);     //Add a recipient
			// $this->mailer->addAddress('ellen@example.com');               //Name is optional
			// $this->mailer->addReplyTo('info@example.com', 'Information');
			// $this->mailer->addCC('cc@example.com');
			// $this->mailer->addBCC('bcc@example.com');

			//Attachments
			if(!empty($attached_filenames)) {
				foreach($attached_filenames as $att) $this->mailer->addAttachment($att);         //Add attachments
				// $this->mailer->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
				} // if

			//Content
			$this->mailer->Subject = $email_subject;
			if((PL_CMS_EMAIL_USE_HTML) && ($this->isHTML($email_text))) {
				$this->mailer->isHTML(true);                                  //Set email format to HTML
				$this->mailer->Body    = $email_text;
				$this->mailer->AltBody = strip_tags(preg_replace('/<style.+<\/style>/is', '',$email_text));	// plain text
				} // if
			else {
				if($this->isHTML($email_text)) $email_text = strip_tags(preg_replace('/<style.+<\/style>/is', '',$email_text));	// plain text
				$this->mailer->isHTML(false);                                  //Set email format to plain text
				$this->mailer->Body    = $email_text;
				} // if

			$this->mailer->send();
			self::addAdminMsg ('Message has been sent','success');
			} // try
		catch (Exception $e) {
			self::addAdminMsg ("Failed to send email message. Mailer Error: {$this->mailer->ErrorInfo}",'warn');
			return false;
			} // catch

		return true;
		} // send()

} // Cemail_client


