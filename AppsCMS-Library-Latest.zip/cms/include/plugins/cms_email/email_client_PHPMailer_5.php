<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: email_client_PHPMailer_5.php 3314 2023-04-11 08:13:04Z robert0609 $
 */

/**
 * Description of email_client
 * The connector class to cms/lib/PHPmailer
 *
 * @author robert0609
 */

// include the classes
require_once(CMS_FS_LIB_DIR . 'PHPMailer_5.2.4/class.phpmailer.php');

class Cemail_client_PHPMailer_5 extends Ccms_base {
	protected $html = false;
	protected $mail_id_str = '';
	protected $to = '';
	protected $to_name = '';
	protected $from = '';
	protected $from_name = '';
	protected $subject = '';
	protected $message = '';
	protected $attachments = '';

	protected $mailer = false;

	function __construct(&$mailer_conf,$mail_id_str = '') {
		parent::__construct();
		$this->add_headers = array();
		$this->add_params = array();
		if(!empty($mail_id_str)) $this->mail_id_str = $mail_id_str;
		else $this->mail_id_str = 'X-Mailer: PHP v' . phpversion();

//		mb_language("en");
//		mb_internal_encoding(CMS_S_CHAR_SET);	//"ISO-8859-1");	// "UTF-8");
//		mb_detect_order("ASCII," . CMS_S_CHAR_SET . ",UTF-8");
//		mb_http_output(CMS_S_CHAR_SET);	//"ISO-8859-1");	// "UTF-8");
//		mb_substitute_character("none");

		$this->mailer = new PHPMailer;
		if((!empty($mailer_conf)) && (is_array($mailer_conf))) {
			// do AppsCMS config to PHPMailer setting
			foreach($mailer_conf as $k => $v) {
				$v = self::conv_conf_val_to_type($v);
				switch($k) {
				case 'AUTH': $this->mailer->SMTPAuth = $v; break;
				case 'AUTH_TYPE': $this->mailer->AuthType; break;
				case 'DEBUG': $this->mailer->SMTPDebug = $v; break;
				case 'DEBUG_OUTPUT': $this->mailer->Debugoutput = $v; break;
				case 'HOST': $this->mailer->Host = $v; break;
				case 'PASSWORD': $this->mailer->Password = $v; break;
				case 'PORT': $this->mailer->Port = (int)$v; break;
				case 'SECURE': $this->mailer->SMTPSecure = $v; break;
				case 'TIMEOUT': $this->mailer->Timeout = (int)$v; break;
				case 'USERNAME': $this->mailer->Username = $v; break;
				case 'WORDWRAP': $this->mailer->WordWrap = $v; break;	// Set word wrap to 50 characters
				default: break;	// not used
					} // switch
				} // foreach
			} // if

		// load language
		$code = strtolower(Ccms_base::get_user_language());
		$this->mailer->SetLanguage($code);
		$this->mailer->XMailer = $this->mail_id_str;	// set id
		$this->mailer->IsSMTP();			// Set mailer to use SMTP
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	protected function isHTML($text){
		$processed = htmlentities($text);
		if($processed == $text) return false;
		return true;
		} // isHTML()

	protected function stripCR($text) {	// text \n \r
		$text = str_replace("\r\n", PHP_EOL, $text);
		$text = str_replace("\n\r", PHP_EOL, $text);
		$text = str_replace(PHP_EOL, " ", $text);
		return trim($text);
		} // stripCR()

	protected function setTo($to_name,$to_email_address) {
		$this->to = $this->stripCR($to_email_address);
		$this->to_name = $this->stripCR($to_name);
		$this->mailer->AddAddress($this->to,$this->to_name);

		return true;
		} // setTo()

	protected function setFrom($from_name,$from_email_address) {
		if(empty($from_name)) $from_name = trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME));
		if(empty($from_email_address)) $from_email_address = CMS_C_EMAIL_ADDRESS;

		$this->from = $this->stripCR($from_email_address);
		$this->from_name = $this->stripCR($from_name);
		$this->mailer->From = $this->from;
		$this->mailer->FromName = $this->from_name;
		return true;
		} // setFrom()

	protected function setSubject($email_subject) {
		if(strlen($email_subject) > 250) $email_subject = substr($email_subject, 0, 250);
		$this->subject = $this->stripCR($email_subject);	// clean and copy
		$this->mailer->Subject = $this->subject;
		return true;
		} // setSubject()

	protected function setMessage($email_text) {	// must be done to set the header in the correct order

		$this->message = nl2br($email_text);
		if((PL_CMS_EMAIL_USE_HTML) && (preg_match('/<.+>/', $this->message))) {	// assume html
			$this->html = true;
			$this->mailer->Body = $this->message;
			$this->mailer->AltBody = strip_tags(preg_replace('/<style.+<\/style>/is', '',$this->message));	// plain text
			} // if
		else {
			$this->html = false;
			$this->mailer->Body = strip_tags(preg_replace('/<style.+<\/style>/is', '',$this->message));	// plain text
			} // else

		$this->mailer->IsHTML($this->html);

		return true;
		} // setMessage()

	protected function setAttachments($attached_filenames) {
		if(empty($attached_filenames)) return true;	// no attachments

		if(is_array($attached_filenames)) {
			$res = true;
			foreach($attached_filenames as $attached_filename) {
				$res &= $this->setAttachments($attached_filename);	// recurse
				} // foreach
			return $res;
			} // if

		// one filename
		if(!is_readable($attached_filenames)) return false;
		$this->mailer->AddAttachment($attached_filenames);
		return true;
		} // setAttachments()

	public function send(
			$to_name,
			$to_email_address,
			$email_subject,
			$email_text,
			$from_email_name = '',
			$from_email_address = '',
			$attached_filenames = ''
			) {

		if(!PL_CMS_EMAIL_SEND_EMAILS) return true;

		if (empty($to_email_address) || empty($email_subject) || empty($email_text)) {
			self::log_msg(__CLASS__ . '->' . __FUNCTION__ . '; not all parameters provided.','warn');
		    return false;
			} // if

		if((!$this->setMessage($email_text)) ||	// must be done to set the header in the correct order
			(!$this->setTo($to_name,$to_email_address)) ||
			(!$this->setFrom($from_email_name,$from_email_address)) ||
			(!$this->setSubject($email_subject)) ||
			(!$this->setAttachments($attached_filenames))) {
			// failed to set up
			self::addMsg ('Failed to setup email message.','warn');
			return false;
			} // id

		$ok = $this->mailer->Send();
		if(!empty($this->mailer->ErrorInfo)) {
			self::log_msg($this->mailer->ErrorInfo);
			self::addAdminMsg ($email_subject . ' - ' . $this->mailer->ErrorInfo,'warn');
			} // if
		return $ok;
		} // send()

} // Cemail_client


