<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: gotcha_code.php 3250 2023-03-02 02:13:34Z robert0609 $
 */

/**
 * Description of gotcha
 * Wrapper class for gotchas,
 * main purpose is to stop output inappropiate data at the wrong time
 *
 * @author robert0609
 */

require_once(CMS_FS_LIB_DIR . 'securimage-3.6.7/securimage.php');
require_once(CMS_FS_LIB_DIR . 'securimage-3.6.7/WavFile.php');

class Cgotcha_code extends Securimage {

	protected $img_file = '';
	protected $snd_file = '';
	protected $id = false;
	protected $suffix = '';
	protected $ok = false;
	protected $cache_fs_dir = '';
	protected $cache_ws_dir = '';

	public function __construct($suffix) {
		// use a better ttf file
		$this->ttf_file = CMS_FS_LIB_DIR . 'AlteHaasGrotesk_Bold.ttf';

		parent::__construct();
		if(empty($this->cache_fs_dir)) {
			$this->cache_fs_dir = VAR_FS_CACHE_GOTCHA_DIR;
			$this->cache_ws_dir = VAR_WS_CACHE_GOTCHA_DIR;
			} // if
		Ccms::chkdir($this->cache_fs_dir);
		if(empty($suffix)) $suffix = 'zz';
		$this->suffix = $suffix;
		$this->id = 'gotcha_' . md5(microtime() . session_id()) . '_' . $this->suffix;
		$this->img_file = $this->id . '.png';	// gotcha image file
		$this->snd_file = $this->id . '.wav';	// gotcha audio file
		} // __construct()

	public function __destruct() {
		// parent::__destruct();
		} // __destruct()

    /**
     * The main image drawing routing, responsible for constructing the entire image and serving it
     */
    protected function doImage() { // replaces securimage-3.6.7 show(), does wrong things
        if( ($this->use_transparent_text || $this->bgimg != '') && function_exists('imagecreatetruecolor')) {
            $imagecreate = 'imagecreatetruecolor';
        } else {
            $imagecreate = 'imagecreate';
			} // else

        $this->im     = $imagecreate($this->image_width, $this->image_height);
        $this->tmpimg = $imagecreate($this->image_width * $this->iscale, $this->image_height * $this->iscale);

        $this->allocateColors();
        imagepalettecopy($this->tmpimg, $this->im);

        $this->setBackground();

        $this->createCode();

        if ($this->noise_level > 0) {
            $this->drawNoise();
			} // if
			
		$this->drawWord();

        if ($this->perturbation > 0 && is_readable($this->ttf_file)) {
            $this->distortedCopy();
			} // if

        if ($this->num_lines > 0) {
            $this->drawLines();
			} // if

        if (trim($this->image_signature) != '') {
            $this->addSignature();
			} // if

		} // doImage()

    /**
     * Sends the appropriate image and outputs image to the browser
     */
    protected function outputImgFile($background_image = '') { // replaces securimage-3.6.7 show(), does wrong things
        if($background_image != '' && is_readable($background_image)) {
            $this->bgimg = $background_image;
	        }
        $this->doImage();

        $res = false;
		switch ($this->image_type) {
			case self::SI_IMAGE_JPEG:
				$res = imagejpeg($this->im, $this->cache_fs_dir . $this->img_file, 90);
				break;
			case self::SI_IMAGE_GIF:
				$res = imagegif($this->im, $this->cache_fs_dir . $this->img_file);
				break;
			default:
				$res = imagepng($this->im, $this->cache_fs_dir . $this->img_file);
				break;
				} // switch
			if(file_exists($this->cache_fs_dir . $this->img_file)) Ccms::chmod_chown ($this->cache_fs_dir . $this->img_file);

        imagedestroy($this->im);
        return $res;
		} // outputImgFile

	 protected function outputSndFile() { // replaces securimage-3.6.7 outputAudioFile(), does wrong things
        $ext = 'wav'; // force wav - mp3 is insecure

        $audio = $this->getAudibleCode($ext);
		if(($fh = Ccms::file_safe_wopen($this->cache_fs_dir . $this->snd_file,'wb'))) {
			fwrite($fh,$audio);
			Ccms::file_safe_wclose($fh,$this->cache_fs_dir . $this->snd_file);
			return true;
			} // if
        return false;
		} // outputSndFile()

	 protected function get_img_element($class = false) {
		//Change some settings
		$this->image_width     = 280;
		$this->image_height    = 100;
		$this->perturbation    = 0.9;      // high level of distortion
		$this->code_length     = rand(5,7); // random code length
		$this->image_bg_color  = new Securimage_Color("#ffffff");
		$this->num_lines       = 12;
		$this->noise_level     = 5;
		$this->text_color      = new Securimage_Color("#000000");
		$this->noise_color     = new Securimage_Color("#000000");
		$this->line_color      = new Securimage_Color("#cccccc");

		$this->ok = $this->outputImgFile();
		if(!$this->ok) return '';
		$text = '';
		$text .= '		<img ' . ($class ? ' class="' . $class . '" ':'') . 'src="' . $this->cache_ws_dir . $this->img_file . '" alt="CAPTCHA Image" style="text-align: left">' . PHP_EOL;
		return $text;
		} // get_img_element()

	 protected function get_snd_element() {
		if(!$this->ok) return '';	// img not done
		$this->ok = $this->outputSndFile();
		if(!$this->ok) return '';	// error
		$text = '';
		$text .= '<object codetype=\"audio/basic\" height=\"0\" width=\"0\" data=\"' . $this->cache_ws_dir . $this->snd_file . '\"></object>';
		return $text;
		} // get_snd_element()

	// html, js and ajax text functions
	protected function get_ws_prefix() {	// for js
		return $this->cache_ws_dir . $this->id;
		} // get_ws_prefix()

	protected function output_js($snd_flg = false) {
		$suffix = $this->suffix;	// update
		if(!$this->ok) return '';

		$snd_text = '';
		if($snd_flg) {
			$snd_text .= $this->get_snd_element();
			if(!$this->ok) return '';
			} // if
		$text = PHP_EOL;
		$text .= '<script type="text/javascript">' . PHP_EOL;
		$text .= '	var gotcha_id' . $suffix . ' = "' . $this->get_ws_prefix() . '";' . PHP_EOL;
		$text .= '	' . PHP_EOL;
		if(!empty($snd_text)) {
			$text .= '	function sayGotchaCode' . $suffix . '() {' . PHP_EOL;
			$text .= '		var sndFile = gotcha_id' . $suffix . ' + ".wav";' . PHP_EOL;
 			$text .= '		var text = "<object height=\"5\" width=\"5\" data=\"" + sndFile + "\"></object>";' . PHP_EOL;
//			$text .= '		var test = "<embed src=\"" + sndFile + "\" height=\"0\" width=\"0\" autostart=\"true\" loop=\"false\">";' . PHP_EOL;
			$text .= '		document.getElementById("id_gotcha_snd' . $suffix . '").innerHTML = "&nbsp;" // clear previous snd' . PHP_EOL;
			$text .= '		if((cms_ajaxOps[\'reloadGotchaCode' . $suffix . '\']) && (cms_ajaxOps[\'reloadGotchaCode' . $suffix . '\'].ajax_running)) return;' . PHP_EOL;
			$text .= '		document.getElementById("id_gotcha_snd' . $suffix . '").innerHTML = text;' . PHP_EOL;
//				$text .= '		playSound(sndFile);' . PHP_EOL;
			$text .= '		} // sayGotchaCode' . $suffix . '()' . PHP_EOL;
			$text .= '	' . PHP_EOL;
			} // if
		$text .= '	function reloadGotchaCode' . $suffix . '(img,snd) {' . PHP_EOL;
		$text .= '		if(!cms_ajaxOps[\'reloadGotchaCode' . $suffix . '\']) {' . PHP_EOL;
		$text .= '			cms_ajaxOps[\'reloadGotchaCode' . $suffix . '\'] = new Ccms_ajaxOps(\'id_gotcha_img' . $suffix . '\',\'id_gotcha_img' . $suffix . '\',\'\',false);' . PHP_EOL;
		$text .= '			} // if' . PHP_EOL;
		if(!empty($snd_text)) {
			$text .= '		document.getElementById("id_gotcha_snd' . $suffix . '").innerHTML = "&nbsp;" // clear previous snd' . PHP_EOL;
			} // if
		$text .= '		return cms_ajaxOps[\'reloadGotchaCode' . $suffix . '\'].doAjaxRequest(\'reloadGotchaCode&plugin=cms_gotcha&suffix=' . $suffix . '&img=\' + (img ? \'true\':\'false\') + \'&snd=\' + (snd ? \'true\':\'false\'));' . PHP_EOL;
		$text .= '		} // reloadGotchaCode' . $suffix . '()' . PHP_EOL;
		$text .= '	' . PHP_EOL;
		$text .= '</script>' . PHP_EOL;

		return $text;
		} // output_js()

	public function output_html($form_id,$snd_flg = false,$required = false,$class = false,$placeholder = false) {
		$suffix = $this->suffix;	// update
		// process
		$img_text = '';
		$img_text .= $this->get_img_element($class);
		if(!$this->ok) return '';

		$snd_text = '';
		if($snd_flg) {
			$snd_text .= $this->get_snd_element();
			if(!$this->ok) return '';
			} // if
		$tc = ($class ? ' class="' . $class . '"':'');

		// output text
		$text = PHP_EOL;
		$text .= '<table cellspacing="5" cellpadding="5"' . $tc . '>' . PHP_EOL;
		$text .= '	<tr' . $tc . '>' . PHP_EOL;
		$text .= '		<td style="text-align: right;"' . $tc . '>' . PHP_EOL;
		$text .= '			<span id="id_gotcha_img' . $suffix . '">' . $img_text . '</span>' . PHP_EOL;
		$text .= '		</td>' . PHP_EOL;
		$text .= '		<td style="text-align: left;"' . $tc . '>' . PHP_EOL;
		if(empty($snd_text)) {
			$text .= '			<button type="button" title="Reload check code" onClick="reloadGotchaCode' . $suffix . '(true,false)">Reload</button>' . PHP_EOL;
			} // if
		else {
			$text .= '			<button type="button" title="Reload check code" onClick="reloadGotchaCode' . $suffix . '(true,true)">Reload</button>' . PHP_EOL;
			$text .= '			<button type="button" title="Click to say the check code" onClick="sayGotchaCode' . $suffix . '()">Say</button>' . '<span id="id_gotcha_snd' . $suffix . '">&nbsp;</span>' . PHP_EOL;
			} // else
		$text .= '		</td>' . PHP_EOL;
		$text .= '		<td>&nbsp;</td>' . PHP_EOL;
		$text .= '	</tr>' . PHP_EOL;
		$text .= '	<tr' . $tc . '>' . PHP_EOL;
		$text .= '		<td' . $tc . ' colspan="2" valign="top">' . (!$placeholder ? 'Enter Check Code:':'') . PHP_EOL;
		$text .= '			<input type="text"' . ($placeholder ? ' placeholder="' . $placeholder . '"':'') . ' name="gotcha_text' . $suffix . '" title="Enter the check code, or reload the check code of it is not clear enough." autocapitalize="off"' . ($required ? ' REQUIRED':'') . '/>'. (is_string($required) ? $required:'') . PHP_EOL;
		$text .= '		</td>' . PHP_EOL;
		$text .= '		<td>&nbsp;</td>' . PHP_EOL;
		$text .= '	</tr>' . PHP_EOL;
		$text .= '</table>' . PHP_EOL;
		$text .= self::output_js() . PHP_EOL;

		return $text;
		} // output_html()

	public function output_ajax() {
		// output text
		$img_text = '';
		if(Ccms_base::get_or_post('img')) $img_text .= $this->get_img_element();	// generate img
		if(Ccms_base::get_or_post('snd')) $img_text .= $this->get_snd_element();	// generate snd
		if($this->ok) return $img_text;
		return '';
		} // output_ajax()

} // Cgotcha_code

?>
