<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: appo_correct_user_details_form.php 3079 2023-01-01 11:44:28Z robert0609 $
 */


Ccms::page_start_comment(__FILE__);
$user_details = Ccms_appointments_plugin::get_user_details();
$url = self::get_base_url(true) . Ccms::get_body_uri();
$row_cntr = 0;

?>

<div class="page_database" style="text-align: center;">
	<h1 class="page_database">
		Please Enter Valid Details to Continue.
	</h1>
	<p class="page_database" style="text-align: center;">
		Error/s were found in your details.
	</p>
	<form name="set_user_<?= Ccms_appointments_plugin::PLUGIN ?>" action="<?= $url ?>" method="post" autocomplete="off">
	<input type="hidden" name="user_id" value="<?= $user_details['user_id'] ?>"/>
	<input type="hidden" name="op" value="code_verification"/>

		<table class="page_database">

			<tr class="page_database<?= (($row_cntr++ & 1) ? ' page_database_odd':' page_database_even') ?>">
				<td class="page_database" style="text-align: right;">
					<label class="page_database">
						Please check name is valid, if not please enter correct your name.
					</label>
				</td>
				<td class="page_database" style="text-align: left;">
					<input type="text" name="<?= Ccms_appointments_plugin::PLUGIN ?>_name" value="<?= $user_details['user_name'] ?>"/>
				</td>
			</tr>
			<tr class="page_database<?= (($row_cntr++ & 1) ? ' page_database_odd':' page_database_even') ?>">
				<td class="page_database" style="text-align: right;">
					<label class="page_database">
						Please check email is valid, if not please enter correct email address.
					</label>
				</td>
				<td class="page_database" style="text-align: left;">
					<input type="text" name="<?= Ccms_appointments_plugin::PLUGIN ?>_email" value="<?= $user_details['user_email'] ?>"/>
				</td>
			</tr>
			<tr class="page_database<?= (($row_cntr++ & 1) ? ' page_database_odd':' page_database_even') ?>">
				<td class="page_database" style="text-align: right;">
					<label class="page_database">
						Please check mobile is valid, if not please enter correct mobile number.
					</label>
				</td>
				<td class="page_database" style="text-align: left;">
					<input type="text" name="<?= Ccms_appointments_plugin::PLUGIN ?>_mobile" value="<?= $user_details['user_mobile'] ?>"/>
				</td>
			</tr>

			<tr class="page_database">
				<td class="page_database" colspan="2" style="text-align: center;">
					<button type="submit" name="verif_codes" value="update_user"/>Save</button>
					<button type="submit" name="verif_codes" value="cancel" formnovalidate/>Cancel</button>
				</td>
			</tr>
		</table>
	</form>
	<p class="page_database" style="text-align: center;">
		<?= Ccms_base::getMsgs(); ?>
	</p>
</div>	

<?php
		
Ccms::page_end_comment(__FILE__);
