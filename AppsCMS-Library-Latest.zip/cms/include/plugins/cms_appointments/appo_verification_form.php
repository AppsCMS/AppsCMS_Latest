<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: appo_verification_form.php 3139 2023-02-14 20:38:55Z robert0609 $
 */


Ccms::page_start_comment(__FILE__);
$user_details = Ccms_appointments_plugin::get_user_details();
$url = self::get_base_url(true) . Ccms::get_body_uri();
global $appo_class;
if(empty($appo_class)) $appo_class = 'page_body';
$resend = false;
$type = Ccms_base::get_or_post('verif_codes');
if($type == 'resend') $resend = true;
$row_cntr = 0;
?>

<div class="<?= $appo_class ?>" style="text-align: center;">
	<h1 class="<?= $appo_class ?>">
		Please Enter Codes to Continue.
	</h1>
	<form name="set_user_<?= Ccms_appointments_plugin::VERIFY_TYPE ?>" action="<?= $url ?>" method="post" autocomplete="off">
		<input type="hidden" name="user_id" value="<?= $user_details['user_id'] ?>"/>
		<input type="hidden" name="op" value="code_verification"/>

		<table class="<?= $appo_class ?>">

<?php	if((!empty($user_details['user_email'])) && (empty($user_details['email_confirmed'])) &&
			(Ccms_auth::send_email_verification_code($user_details['user_email'],$user_details['user_name'],$resend,Ccms_appointments_plugin::VERIFY_TYPE))) {
?>
			<tr class="<?= $appo_class ?><?= (($row_cntr++ & 1) ? ' <?= $appo_class ?>_odd':' <?= $appo_class ?>_even') ?>">
				<th class="<?= $appo_class ?>" colspan="2" style="text-align: center;">
					Verification code has been emailed to <?= $user_details['user_email'] ?>
				</th>
			</tr>
			<tr class="<?= $appo_class ?><?= (($row_cntr++ & 1) ? ' <?= $appo_class ?>_odd':' <?= $appo_class ?>_even') ?>">
				<td class="<?= $appo_class ?>" style="text-align: right;">
					<label class="<?= $appo_class ?>">
						Enter email verification code:
					</label>
				</td>
				<td class="<?= $appo_class ?>" style="text-align: left;">
					<input type="number" name="email_code" value="" required/>
					<input type="hidden" name="email" value="<?= $user_details['user_email'] ?>"/>
				</td>
			</tr>
<?php	} // if ?>
	
<?php	if((!empty($user_details['user_mobile'])) && (empty($user_details['mobile_confirmed'])) &&
			(Ccms_auth::send_sms_verification_code($user_details['user_mobile'],$user_details['user_name'],$resend,Ccms_appointments_plugin::VERIFY_TYPE))) {
?>
			<tr class="<?= $appo_class ?><?= (($row_cntr++ & 1) ? ' <?= $appo_class ?>_odd':' <?= $appo_class ?>_even') ?>">
				<th class="<?= $appo_class ?>" colspan="2" style="text-align: center;">
					Verification SMS code has been sent to <?= $user_details['user_mobile'] ?>
				</th>
			</tr>
			<tr class="<?= $appo_class ?>">
				<td class="<?= $appo_class ?>" style="text-align: right;">
					<label class="<?= $appo_class ?>">
						Enter mobile phone verification code:
					</label>
				</td>
				<td class="<?= $appo_class ?>" style="text-align: left;">
					<input type="number" name="mobile_code" value="" required/>
					<input type="hidden" name="mobile" value="<?= $user_details['user_mobile'] ?>"/>
				</td>
			</tr>
<?php	} // if ?>

			<tr class="<?= $appo_class ?>">
				<td class="<?= $appo_class ?>" style="text-align: right;">
					<label class="<?= $appo_class ?>">
						Verification codes:
					</label>
				</td>
				<td class="<?= $appo_class ?>" style="text-align: left;">
					<button type="submit" name="verif_codes" value="verify"/>Save</button>
					<button type="submit" name="verif_codes" value="resend" formnovalidate/>Resend</button>
				</td>
			</tr>
		</table>
	</form>
	<p class="<?= $appo_class ?>" style="text-align: center;">
		<?= Ccms_base::getMsgs(); ?>
	</p>
</div>	

<?php
		
Ccms::page_end_comment(__FILE__);
