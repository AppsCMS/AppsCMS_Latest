<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: map_location.php 3255 2023-03-03 07:19:12Z robert0609 $
 */

/*
 * see "https://developers.google.com/maps/documentation/js/examples/places-autocomplete#maps_places_autocomplete-html" 
 *
 * Modifies to be a page element (instead of the whole page) 
 * 
 */
global $loc_name,$loc_value;

?>

		<section>
			<!--	Place Autocomplete-->
			
			<div class="pac-card" id="pac-card">

				<div>
					<div id="addr_title">Address search</div>
					<div id="type-selector" class="pac-controls">
						<input type="radio" name="type" id="changetype-all" />
						<label for="changetype-all">All</label>

						<input type="radio" name="type" id="changetype-establishment" />
						<label for="changetype-establishment">establishment</label>

						<input type="radio" name="type" id="changetype-address" />
						<label for="changetype-address">address</label>

						<input type="radio" name="type" id="changetype-geocode" checked="checked" />
						<label for="changetype-geocode">geocode</label>

						<input type="radio" name="type" id="changetype-cities" />
						<label for="changetype-cities">(cities)</label>

						<input type="radio" name="type" id="changetype-regions" />
						<label for="changetype-regions">(regions)</label>
					</div>
					<br />
					<div id="strict-bounds-selector" class="pac-controls">
						<input type="checkbox" id="use-location-bias" />
						<label for="use-location-bias">Bias to map viewport</label>

						<input type="checkbox" id="use-strict-bounds" />
						<label for="use-strict-bounds">Strict bounds</label>
					</div>
				</div>

				<div id="pac-container">
					<input id="pac-input" type="text" name="<?= $loc_name ?>" value="<?= $loc_value ?>" placeholder="Enter a location" />
				</div>
			</div>
			<div id="loc_addr_map"></div>
			<div id="loc_infowindow-content">
				<span id="place-name" class="loc_title"></span><br />
				<span id="place-address"></span>
			</div>

		</section>