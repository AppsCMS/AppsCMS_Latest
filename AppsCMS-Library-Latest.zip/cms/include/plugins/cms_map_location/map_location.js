
		function loc_initMap() {
	
			let loc_map = null;
			let loc_service = null;
			let loc_infowindow = null;
			let loc_marker = null;
			
			let loc_LatLng = { lat: -25.363, lng: 131.044 };	// AU default
  

			function createMarker(place,title) {
				if (!place.geometry || !place.geometry.location) return;
				const marker = new google.maps.Marker({
					loc_map,
					title: title,
					anchorPoint: new google.maps.Point(0, -29),
					position: place.geometry.location,
					});
				} // createMarker()

  			loc_map = new google.maps.Map(document.getElementById("loc_addr_map"), {
				centre: loc_LatLng,
				zoom: 18,
				mapTypeControl: false,
				}
			);
			const card = document.getElementById("pac-card");
			const input = document.getElementById("pac-input");
			const biasInputElement = document.getElementById("use-location-bias");
			const strictBoundsInputElement = document.getElementById("use-strict-bounds");
			const options = {
				fields: ["formatted_address", "geometry", "name"],
				strictBounds: false,
				types: ["establishment"],
				};

			loc_map.controls[google.maps.ControlPosition.TOP_LEFT].push(card);

			const autocomplete = new google.maps.places.Autocomplete(input, options);

			// Bind the map's bounds (viewport) property to the autocomplete object,
			// so that the autocomplete requests use the current map bounds for the
			// bounds option in the request.
			autocomplete.bindTo("bounds", loc_map);

			loc_infowindow = new google.maps.InfoWindow();
			const infowindowContent = document.getElementById("loc_infowindow-content");

			loc_infowindow.setContent(infowindowContent);

			const marker = new google.maps.Marker({
				loc_map,
				anchorPoint: new google.maps.Point(0, -29),
				});
			
			if( input.value.length > 10 ) {	// have adrress
				// centre loc_map
				const request = {
					query: input.value,
					fields: ["name", "geometry"],
					};
				loc_service = new google.maps.places.PlacesService(loc_map);
				var results = [];
				loc_service.findPlaceFromQuery(request, (results, status) => {
					if (status === google.maps.places.PlacesServiceStatus.OK && results) {
						if(results.length > 0) {
							loc_LatLng = results[0].geometry.location;
							loc_map.setCenter(loc_LatLng);
							createMarker(loc_LatLng,input.value);
							} // if
						} // if
					});
				} // if
			else {
				} // else

			autocomplete.addListener("place_changed", () => {
				loc_infowindow.close();
				marker.setVisible(false);
				const place = autocomplete.getPlace();
				if (!place.geometry || !place.geometry.location) {
					// User entered the name of a Place that was not suggested and
					// pressed the Enter key, or the Place Details request failed.
					window.alert("No details available for input: '" + place.name + "'");
					return;
					} // if

				// If the place has a geometry, then present it on a map.
				if (place.geometry.viewport) {
					loc_map.fitBounds(place.geometry.viewport);
					} // if
				else {
					loc_map.setCenter(place.geometry.location);
					loc_map.setZoom(17);
					} // else

				marker.setPosition(place.geometry.location);
				marker.setVisible(true);
				infowindowContent.children["place-name"].textContent = place.name;
				infowindowContent.children["place-address"].textContent = place.formatted_address;
				loc_infowindow.open(loc_map, marker);
				});	// ()

			// Sets a listener on a radio button to change the filter type on Places
			// Autocomplete.
			function setupClickListener(id, types) {
				const radioButton = document.getElementById(id);

				radioButton.addEventListener("click", () => {
					autocomplete.setTypes(types);
					//input.value = "";
					}); // ()
				} // setupClickListener()

			setupClickListener("changetype-all", []);
			setupClickListener("changetype-address", ["address"]);
			setupClickListener("changetype-establishment", ["establishment"]);
			setupClickListener("changetype-geocode", ["geocode"]);
			setupClickListener("changetype-cities", ["(cities)"]);
			setupClickListener("changetype-regions", ["(regions)"]);
			biasInputElement.addEventListener("change", () => {
				if (biasInputElement.checked) {
					autocomplete.bindTo("bounds", loc_map);
					} // if
				else {
					// User wants to turn off location bias, so three things need to happen:
					// 1. Unbind from loc_map
					// 2. Reset the bounds to whole world
					// 3. Uncheck the strict bounds checkbox UI (which also disables strict bounds)
					autocomplete.unbind("bounds");
					autocomplete.setBounds({ east: 180, west: -180, north: 90, south: -90 });
					strictBoundsInputElement.checked = biasInputElement.checked;
					} // else

				// input.value = "";
				}); // ()

			autocomplete.setTypes(["address"]);	// just address

			strictBoundsInputElement.addEventListener("change", () => {
				autocomplete.setOptions({
					strictBounds: strictBoundsInputElement.checked,
					}); // setOptions()
				if (strictBoundsInputElement.checked) {
					biasInputElement.checked = strictBoundsInputElement.checked;
					autocomplete.bindTo("bounds", loc_map);
					} // if

				// input.value = "";
				}); // ()
			
			function markAddress(map,address) {
				if((!address) || (address.length < 10)) return;	// no address
				var geocoder = new google.maps.Geocoder();
				geocoder.geocode({'address': address}, function(results, status) {
					if (status === 'OK') {
						loc_LatLng = results[0].geometry.location;
						map.setCenter(loc_LatLng);
						loc_marker = new google.maps.Marker({
							map: map,
							position: loc_LatLng,
							label: { 
								className: 'map-marker-label',
								text: address,
								},
							});
						} // if
//					else {
//						alert('Cannot find address: ' + address + ', for the following reason: ' + status);
//						} // else
					 });
				} // markAddress()
				
			function getAddress(map,latLng) {
				var geocoder = new google.maps.Geocoder();
				var location  = new google.maps.LatLng(latLng);    // turn coordinates into an object          
				geocoder.geocode({'latLng': location}, function (results, status) {
					if(status == google.maps.GeocoderStatus.OK) {           // if geocode success
						input.value = results[0].formatted_address;         // if address found, pass to processing function
						markAddress(map,input.value);
						} // if
					else input.value = '(Address unknown.)';
					});
				} // getAddress()
				
			markAddress(loc_map,input.value);

			loc_map.addListener("click", (mapsMouseEvent) => {
				if(loc_infowindow) {
					loc_infowindow.close();
					loc_infowindow = null;
					}
				if(loc_marker) {
					loc_marker.setMap(null);	// remove from map
					loc_marker = null;	// close marker
					} // if
				loc_LatLng = mapsMouseEvent.latLng;
				loc_map.setCenter(loc_LatLng);

				loc_infoWindow = new google.maps.InfoWindow({
					//position: loc_LatLng,
					});
				//	loc_infoWindow.setContent(
				//		JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2)
				//	);
				loc_infoWindow.open(loc_map);
				loc_map.setCenter(loc_LatLng);
				
				getAddress(loc_map,loc_LatLng);
				}); // ()

			input.addEventListener('change',(event) => {	// fired when the input is change input
				markAddress(loc_map,input.value);	// putup marker
				});
			
			} // loc_initMap()

		window.initMap = loc_initMap;
