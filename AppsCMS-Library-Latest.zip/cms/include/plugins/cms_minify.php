<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_minify.php 3351 2023-07-18 01:29:19Z robert0609 $
 */

/**
 * Description of Minify plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */

class Ccms_minify_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_minify';
	protected static $enabled = null;

	protected static $expired = false;
	
	public static $html_min = false;

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(version_compare(PHP_VERSION, '7.0.0') < 0) self::$enabled = false;
			else if(!defined('PL_CMS_MINIFY_MINIFY_DEBUG')) self::$enabled = false;
			else if(!defined('PL_CMS_MINIFY_MINIFY_ADMIN')) self::$enabled = false;
			else self::$enabled = self::is_plugin_enabled(self::PLUGIN);
			} // if
		return self::$enabled;
		} // is_enabled()

	public static function is_this_ajax_plugin($ajax) {	// required function, check for ownership of ajax op by this plugin
		if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		return false;
		} // is_this_ajax_plugin()

	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		return '';	// default return
		} // get_ajax_text()

	protected static function add_libs() {
		// always include minify library code (else ws can be blocked by bad autoload)
		require_once CMS_FS_LIB_DIR . 'minify/src/Minify.php';	// include extra code
		require_once CMS_FS_LIB_DIR . 'minify/src/CSS.php';	// include extra code
		require_once CMS_FS_LIB_DIR . 'minify/src/JS.php';	// include extra code
		require_once CMS_FS_LIB_DIR . 'minify/src/Exception.php';	// include extra code

		require_once CMS_FS_LIB_DIR . 'path-converter/src/ConverterInterface.php';	// include extra code
		require_once CMS_FS_LIB_DIR . 'path-converter/src/Converter.php';	// include extra code
		require_once CMS_FS_LIB_DIR . 'path-converter/src/NoConverter.php';	// include extra code

		return true;	// generate
		} // add_libs()

	public static function reset_cache($cli = false) {
		if(!$cli) {
			if(self::$expired) return false;	// wait until it finishs loading
			if(!self::get_cms_sess_var('expired_minify')) return false;
			} // if
		self::unset_cms_sess_var('expired_minify');

		if((!defined('VAR_FS_CACHE_MINIFY_DIR')) ||
			(!is_dir(VAR_FS_CACHE_MINIFY_DIR)))
			return 0;

		$files = scandir(VAR_FS_CACHE_MINIFY_DIR);
		$cnt = 0;
		foreach($files as $f) {
			$fp = VAR_FS_CACHE_MINIFY_DIR . $f;
			if((is_file($fp)) &&
				(self::is_file_usable($fp))) {
				@unlink($fp);
				$cnt++;
				} // if
			} // if
		self::addDebugMsg('Reset ' . $cnt . ' minify cache files.','info');
		return $cnt;
		} // reset_cache()

	public static function expire_cache() {
		if(self::is_cli()) return self::reset_cache (true);
		self::$expired = true;
		self::set_cms_sess_var(true,'expired_minify');
		} // expire_cache()

	private static function chk_minify($file_ws_path,$type) {
		if($type != 'SCSS') {	// always minified (compiled)
			if((!defined('PL_CMS_MINIFY_MINIFY_ADMIN')) || (!PL_CMS_MINIFY_MINIFY_ADMIN)) {
				if(Ccms_auth::is_cms_admin_user()) return false;	// allow admins in unminified
				} // if
			if(!self::is_plugin_enabled(self::PLUGIN)) {
				return false;
				} // if
			if(!defined('PL_CMS_MINIFY_MINIFY_DEBUG')) return false;
			if((self::is_debug()) && (!PL_CMS_MINIFY_MINIFY_DEBUG)) return false;
			} // if

		if(filter_var($file_ws_path,FILTER_VALIDATE_URL)) return false;
		if(!self::chkdir(VAR_FS_CACHE_MINIFY_DIR)) return false;	// not there
		if(!file_exists(DOCROOT_FS_BASE_DIR . $file_ws_path)) {
			self::addDebugMsg ('Minify ' . $type . ': ' . $file_ws_path . ' not found.','warning');
			return false;
			} // if
		$cache_name = self::get_base_url(true) . CMS_PROJECT_VERSION . '-' . $file_ws_path;
		$cache_file  = preg_replace('/\/|:/','_',
			(($type != 'SCSS') ? $file_ws_path:preg_replace('/\.scss$/i','-scss.css',$cache_name)));
		if(PL_CMS_MINIFY_OBFUSCATE_FILENAME) {
			$pp = pathinfo($cache_file);
			$cache_file = md5($cache_file) . '.' . $pp['extension'];
			} // if
		if(((int)PL_CMS_MINIFY_MINIFY_TTL_DAYS > 0) &&
			(file_exists(VAR_FS_CACHE_MINIFY_DIR . $cache_file))) {
			// not cleared check TTL
			$ttl_seconds = (int)PL_CMS_MINIFY_MINIFY_TTL_DAYS * 24 * 3600;
			$now = time();
			$mtime = filemtime(VAR_FS_CACHE_MINIFY_DIR . $cache_file);
			if(($now - $mtime) >= $ttl_seconds) @unlink(VAR_FS_CACHE_MINIFY_DIR . $cache_file);
			} // if
		if((self::is_mode_change()) &&
			(is_file(VAR_FS_CACHE_MINIFY_DIR . $cache_file)))
			@unlink(VAR_FS_CACHE_MINIFY_DIR . $cache_file);
		return VAR_WS_CACHE_MINIFY_DIR . $cache_file;
		} // chk_minify()

	public static function minify_css($css_ws_path) {	// returns the cache path to minified output
		if(!($cache_file = self::chk_minify($css_ws_path,'CSS'))) {
			return $css_ws_path;
			} // if

		$sorc_path = DOCROOT_FS_BASE_DIR . $css_ws_path;
		$cache_path = DOCROOT_FS_BASE_DIR . $cache_file;
		if(file_exists($cache_path)) return $cache_file;

		// change relative URLs to absolute URLs in CSS file (so it it will minify to a different location)
		// as URLs in CSS files are relative to the location of the CSS file.
		$tmp_path = $cache_path . '-tmp';
		if(!self::file_safe_write($tmp_path,
			preg_replace_callback('/url\(\s*[\'"]?\/?(.+?)[\'"]?\s*\)/i',
				function ($match) {
					if(preg_match('/http:\/\/|https:\/\//',$match[0])) return $match[0];	// it's already absolute, dont touch
					$rel_path = $match[1];	// where is it really !!??
					while((!file_exists(DOCROOT_FS_BASE_DIR . $rel_path)) &&
						(substr($rel_path,0,3) == '../')) {
						$rel_path = substr($rel_path,3);
						}
					$baseURI = Ccms::$cms_page_info['base_ref'];
					return 'url('.$baseURI . $rel_path . ')';
					},
				file_get_contents($sorc_path)))) {
			self::addMsg('Failed cache file "' . $tmp_path . '"');
			} // if
		// else I am surprised that this works !!!!!
		// being cached in the var/cache/min/ directory is the secret (?)

		// minify
		self::add_libs();
		$minifier = new MatthiasMullie\Minify\CSS($tmp_path);
		$fp = self::file_safe_wopen($cache_path);
		if(!$fp) {
			self::log_msg('Failed to write "' . $cache_file . '".');
			return $css_ws_path;
			} // if
		fwrite($fp, $minifier->minify());
		self::file_safe_wclose($fp,$cache_path);
		if(!self::is_debug()) @unlink($tmp_path);
		return $cache_file;
		} // minify_css()

	public static function minify_scss($scss_ws_path) {	// returns the cache path to minified output
		if(!($cache_file = self::chk_minify($scss_ws_path,'SCSS'))) {
			return false;
			} // if

		$cache_path = DOCROOT_FS_BASE_DIR . $cache_file;
		if(file_exists($cache_path)) return $cache_file;

		// compile scss file
		$sorc_path = DOCROOT_FS_BASE_DIR . $scss_ws_path;
		
		$cSassc = new Ccms_sassc($sorc_path, $cache_path);	// compile it

		return $cache_file;
		} // minify_scss()

	protected static function add_minfile_htaccess() {
		$text =<<< EOTMIN

# allow acces to minified files
	<FilesMatch ".*\.(css|js)$">
			Require all granted
	</FilesMatch>

EOTMIN;

		self::chkdir(VAR_FS_CACHE_MINIFY_DIR, true);
		$htaccess = VAR_WS_CACHE_MINIFY_DIR . '.htaccess';
		return self::file_safe_write($htaccess,$text);
		} // add_minfile_htaccess()

	protected static function rm_minfile_htaccess() {
		$htaccess = VAR_WS_CACHE_MINIFY_DIR . '.htaccess';
		@unlink($htaccess);
		return true;
		} // rm_minfile_htaccess()

	public static function minify_js($js_ws_path) {
		if(!($cache_file = self::chk_minify($js_ws_path,'JS'))) {
			return $js_ws_path;
			} // if
		$cache_path = DOCROOT_FS_BASE_DIR . $cache_file;
		if(file_exists($cache_path)) return $cache_file;

		self::add_libs();
		$minifier = new MatthiasMullie\Minify\JS(DOCROOT_FS_BASE_DIR . $js_ws_path);
		$fp = self::file_safe_wopen($cache_path);
		if(!$fp) {
			self::log_msg('Failed to write "' . $cache_file . '".');
			return $js_ws_path;
			} // if
		fwrite($fp, $minifier->minify());
		self::file_safe_wclose($fp,$cache_path);
		return $cache_file;
		} // minify_js()

	public static function &minify_html(&$html) {
		// similar to "https://stackoverflow.com/questions/6225351/how-to-minify-php-page-html-output"
		// with fixes
		$search = array(
		 '/(\n|^)(\x20+|\t)/',
		 '/(\n|^)\/\/(.*?)(\n|$)/',
		 '/\n/',
		 '/\<\!--.*?--\>/',
		 '/(\x20+|\t)/', # Delete multispace (Without \n)
		 '/\>\s+\</', # strip whitespaces between tags
		 '/(\"|\')\s+\>/', # strip whitespaces between quotation ("') and end tags
		 '/=\s+(\"|\')/'); # strip whitespaces between = "'

		$replace = array(
		 PHP_EOL,
		 PHP_EOL,
		 " ",
		 "",
		 " ",
		 "><",
		 "$1>",
		 "=$1");

		// use reference to stop double bufferring thru the stack
		 self::$html_min = preg_replace($search,$replace,$html);
		 return self::$html_min;
		} // minify_html()

	public static function get_title() {	// get the plugin title
		return 'Minify';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Minify plugin (' . self::PLUGIN . ') is an assistive plugin used to generate minified CSS and JS files.'
			. ' Disabling ' . self::PLUGIN . ' plugin just bypasses the minify operation and supplies the original code.'
			. '<br>IMPORTANT NOTE: The ' . self::PLUGIN . ' is not enabled with PHP less than verion 7.0.';
		} // get_description()

	protected static function get_sql_install_data() {
		$cfg = array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "MINIFY_ADMIN",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_name' => "Miniify Admin",
				'cms_config_value' => "false",
				'cms_config_allowed_values' => "true:false",
				'cms_config_description' => "Set true to minify on admin, false to minify only on production.",
				),	// row data
			array(
				'cms_config_key' => "MINIFY_DEBUG",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_name' => "Miniify Debug",
				'cms_config_value' => "false",
				'cms_config_allowed_values' => "true:false",
				'cms_config_description' => "Set true to minify on debug, false to minify only on production.",
				),	// row data
			array(
				'cms_config_key' => "OBFUSCATE_FILENAME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_name' => "Obfuscate Minified Filename",
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "false:true",
				'cms_config_description' => "true = obfuscate minified file name, false = leave filename in plain text.",
				),	// row data
			array(
				'cms_config_key' => "MINIFY_TTL_DAYS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_name' => "Minify Time to Live (TTL) Days",
				'cms_config_value' => "0",
				'cms_config_allowed_values' => "",
				'cms_config_description' => "Enter a value in days as the TTL for minified files<br>" .
									"0 = minify if not present in the cache (the minified files are expired on install, theme and apps settings save)<br>" .
									"else enter the numer days the minified should be cached.<br>" .
									"<b>NOTE:</b> Minified files are cached in &quot;" . VAR_WS_CACHE_MINIFY_DIR . "&quot; directory.",
				),	// row data
			array(
				'cms_config_key' => "MINIFY_ALL_HTML",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_name' => "Minify All HTML",
				'cms_config_value' => "false",
				'cms_config_allowed_values' => "false:true",
				'cms_config_description' => "true = minify all of the web page, false = leave HTML as formated HTML (as generated).",
				),	// row data
			);
		return $cfg;
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		self::add_minfile_htaccess();
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		self::reset_cache(true);
		self::rm_minfile_htaccess();
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_minify_plugin
