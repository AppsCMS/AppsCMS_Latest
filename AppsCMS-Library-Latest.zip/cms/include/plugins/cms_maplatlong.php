<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_maplatlong.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of Google Map LL plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 *
 * basic code from "https://developers.google.com/maps/tutorials/fundamentals/adding-a-google-map"
 * basic marker from "https://developers.google.com/maps/tutorials/customizing/custom-markers"
 * a source of map icons is "http://mapicons.nicolasmollet.com/"
 *
 */

class Ccms_maplatlong_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_maplatlong';

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(preg_match('/edit_|login|logout/',Ccms::get_app_action())) return false;	// not on config pages
		if(!defined('PL_CMS_MAPLATLONG_GM_LL')) return false;
		if(strlen(PL_CMS_MAPLATLONG_GM_LL) < 3) return false;
		if((int)PL_CMS_MAPLATLONG_GM_WIDTH < 25) return false;
		if((int)PL_CMS_MAPLATLONG_GM_HEIGHT < 25) return false;
		if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		return true;
		} // is_enabled()

	public static function get_ajax_engage_uri() {	// default uri to engage plugin
		return CMS_WS_DIR . 'cms_ajax.php?ajax=loadMapFrm&plugin=' . self::PLUGIN;
		} // get_ajax_engage_uri()

	public static function is_this_ajax_plugin($ajax) {	// required function, check for ownership of ajax op by this plugin
		if(!self::is_enabled()) return false;	// default return
		if($ajax == 'loadMapFrm') return true;
		if($ajax == 'loadMap') return true;
		return false;
		} // is_this_plugin()

	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		// return '';	// default return
		$text = '';
		if (($ajax == 'loadMapFrm') ||
			($ajax == 'loadMap')) {
			$text .= self::generate($ajax);	// assume it is in an iframe
			} // if
		return $text;
		} // get_ajax_text()

	public static function generate($id,$suffix = '',$params = array()) {	// assume it is in an iframe
		if(!self::is_enabled()) return '';
		$map_api_url = 'https://maps.googleapis.com/maps/api/js';
		if(!$map_api_url = self::chk_web_host_up($map_api_url)) {
			self::addDebugMsg("Google maps API not available.");
			return;
			} // if

		$llsc = explode(':',PL_CMS_MAPLATLONG_GM_LL);
		$mkr_icon = explode(':',(defined('PL_CMS_MAPLATLONG_GM_MK_ICON') ? PL_CMS_MAPLATLONG_GM_MK_ICON:''));
		$mkr_title = explode(':',(defined('PL_CMS_MAPLATLONG_GM_MK_TITLE') ? PL_CMS_MAPLATLONG_GM_MK_TITLE:''));
		$lls = array();
		$lat_sum = 0.0;
		$long_sum = 0.0;
		for($i = 0; $i < count($llsc); $i++) {
			$ll = explode(' ',$llsc[$i]);
			$lls[$i]['lat'] = $ll[0];
			$lls[$i]['long'] = $ll[1];
			if((isset($mkr_icon[$i]) && (!empty($mkr_icon[$i])))) {
				$lls[$i]['icon'] = $mkr_icon[$i];
				} // if
			if((isset($mkr_title[$i]) && (!empty($mkr_title[$i])))) {
				$lls[$i]['title'] = $mkr_title[$i];
				} // if
			$lat_sum += $ll[0];
			$long_sum += $ll[1];
			} // for
		$lat_avg = $lat_sum / (float)count($llsc);
		$long_avg = $long_sum / (float)count($llsc);
		$icon_base = CMS_WS_IMAGES_DIR . 'icons/';
		$text = array();
		$text[] = '<!DOCTYPE html>';
		$text[] = '<html>';
		$text[] = '	<head>';
		$text[] = '		<style>';
		$text[] = '			#map-canvas {';
		$text[] = '				width: ' . (int)PL_CMS_MAPLATLONG_GM_WIDTH . 'px;';
		$text[] = '				max-width: 100%;';
		$text[] = '				height: ' . (int)PL_CMS_MAPLATLONG_GM_HEIGHT . 'px;';
		$text[] = '				overflow: hidden;';
		$text[] = '				position: relative;';
		$text[] = '				alignment-adjust: central;';
		$text[] = '				vertical-align: middle;';
		$text[] = '			}';
		$text[] = '		</style>';
		$text[] = '		<script type="text/javascript" src="' . $map_api_url . '"></script>';
		$text[] = '		<script type="text/javascript">';
		$text[] = '			var markers = [];';
		$text[] = '			function gmll_init() {';
		$text[] = '				var mapCanvas = document.getElementById("map-canvas");';
		$text[] = '				var myCntrLatlng = new google.maps.LatLng(' . $lat_avg . ', ' . $long_avg . ');';
		$text[] = '				var mapOptions = {';
		$text[] = '					center: myCntrLatlng,';
		$text[] = '					zoom: ' . (int)PL_CMS_MAPLATLONG_GM_ZOOM . ',';
		$text[] = '					mapTypeId: google.maps.MapTypeId.ROADMAP';
		$text[] = '					}';
		$text[] = '				var map = new google.maps.Map(mapCanvas, mapOptions);';
		$text[] = '				';
		$text[] = '				// To add the markers to the map, use the "map" property';
		for($i = 0; $i < count($llsc); $i++) {
			$text[] = '				markers[' . $i . '] = new google.maps.Marker({';
			$text[] = '					position: new google.maps.LatLng(' . $lls[$i]['lat'] . ', ' . $lls[$i]['long'] . '),';
			$text[] = '					map: map';
			if((isset($lls[$i]['icon'])) && (!empty($lls[$i]['icon']))) {
				$text[(count($text) - 1)] .= ',';
				$text[] = '					icon: "' . $icon_base . $lls[$i]['icon'] . '"';
				} // if
			if((isset($lls[$i]['title'])) && (!empty($lls[$i]['title']))) {
				$text[(count($text) - 1)] .= ',';
				$text[] = '					title: "' . preg_replace('/<br>/i','\n',$lls[$i]['title']) . '"';
				} // if
			$text[] = '					});';
			$text[] = '			';
			} // for
		$text[] = '					';
		$text[] = '				} // gmll_init()';
		$text[] = '			// google.maps.event.addDomListener(window, "load", gmll_init);';
		$text[] = '		</script>';
		$text[] = '	</head>';
		$text[] = '	<body onload="javascript:gmll_init()">';
		$text[] = '		<div id="map-canvas"></div>';
		$text[] = '	</body>';
		$text[] = '</html>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // generate()

	public static function get_title() {	// get the plugin title
		return 'Google Maps LL';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Google Map Latitude and Longitude plugin (' . self::PLUGIN . ') is used to generate a Google location map.'
		. '<br>To use the Google Map Latitude and Longitude plugin in , enter "'
		. htmlentities('<iframe src="' . CMS_WS_DIR . 'cms_ajax.php?ajax=loadMapFrm&plugin=' . self::PLUGIN . '"  width="350" height="350" frameborder="0" scrolling="no">' . '</iframe>')
		. '"<br>OR add ' . htmlentities('<span id="' . self::PLUGIN . '"></span>')
		. ' into the .html file.'
		. '<br>The width and height are usually set 5 to 10 pixels bigger than configured Map Width and Map Height.'
		. '<br>NOTE: This map is different from a direct address lookup map from Google Maps.'
		. ' This plugin is not needed for these address lookup maps. Just use the URL provided by Google Maps for an address in an iframe.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "GM_LL",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "0 0",	// latitude and longitude pairs
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Latitude and Longitude.",
				'cms_config_description' => "Latitude and longitude in decimal format, separated by a space.<br>If more than one location, enter further pairs of latitude and longitude separated by a colon (:).<br>If zero or empty map is disabled.<br>NOTE: Latitude and longitudes can be found at http://street-map.net.au/",
				),	// row data
			array(
				'cms_config_key' => "GM_MK_ICON",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// to use Google's standard marker
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Marker Pin Icon.",
				'cms_config_description' => "Leave empty to use default map marker icon.<br>Else enter the marker pin icon file from ." . CMS_WS_DIR . "/images/icons/ directory.<br>Multiple pins can be entered, one for each latitude and longitude pair separated by a colon.<br>A source of free map icons is http://mapicons.nicolasmollet.com/ Copy icon to " . CMS_WS_IMAGES_DIR . "icons/ directory to use.",
				),	// row data
			array(
				'cms_config_key' => "GM_MK_TITLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// to use Google's standard marker
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Marker Pin Title.",
				'cms_config_description' => "Leave empty to have no marker title/s.<br>Else enter the marker pin title, (e.g. place name).<br>Multiple pin titles can be entered, one for each marker pin separated by a colon.",
				),	// row data
			array(
				'cms_config_key' => "GM_WIDTH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "320",	//
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Map Width.",
				'cms_config_description' => "Enter map width in pixels.<br>If zero or empty map is disabled.",
				),	// row data
			array(
				'cms_config_key' => "GM_HEIGHT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "320",	//
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Map Height.",
				'cms_config_description' => "Enter map height in pixels.<br>If zero or empty map is disabled.",
				),	// row data
			array(
				'cms_config_key' => "GM_ZOOM",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "8",	//
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Map Zoom.",
				'cms_config_description' => "Enter map zoom factor. Typically between 8 and 16.",
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_maplatlong_plugin

