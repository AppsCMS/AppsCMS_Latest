<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_appointments.php 3232 2023-02-28 01:59:42Z robert0609 $
 */

/**
 * Description of Ccms_appointments_plugin
 *
 * Basic appointments calendar plugin
 *
 * @author robert0609
 */

class Ccms_appointments_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_appointments';

	public static $use_strong_passwds = true;

	protected const SECS_DAY = 86400;	// seconds per day
	protected const DAYS_WEEK = 7;
	protected const DAY_STRT_INC = 0; //  start day of week offset
	protected const DAY_FNSH_INC = 14; // end day of week offset, next fortnight
	protected const TIME_INC = (15 * 60);	// seconds increment
	protected const DB_CHARSET = "utf8";	// ??
	protected const LOGIN_TIMEOUT = 86400;	// login timeout
	protected const GUEST_USER_ID = -1;		// appointments table user ID for a guest
	public const VERIFY_TYPE = 'appo';

	protected $db_type = false;
	protected $cDBappo = false;
	protected $ok = false;
	
	protected $appo_class = '';

//	protected $user_name = false;
//	protected $user_passwd_md5 = false;
//	protected $user_mobile = false;
//	protected $user_email = false;
//	protected $user_message = false;

	protected $user_details = [];	// cache
	protected $appointment_details = [];	// cache
	
	protected $appo_manager = null;

	function __construct($install_tables = false, $appo_class = false) {
		if(!self::is_enabled()) return;
		
		if(!empty($appo_class)) $this->appo_class = $appo_class;
		if(empty($this->appo_class)) $this->appo_class = 'page_body';	// 'page_database';
		self::$use_strong_passwds = PL_CMS_APPOINTMENT_USE_STRONG_PASSWDS;
		
		$this->db_type = PL_CMS_APPOINTMENT_DB_TYPE;
		switch($this->db_type) {
		case 'SQLite':
			$db_file = ETC_FS_SQLITE_DIR . PL_CMS_APPOINTMENT_DB_NAME . '.sqlite';
			$this->cDBappo = new Ccms_database_sqlite($db_file);
			break;
		case 'MySQL':
			$db_host = PL_CMS_APPOINTMENT_DB_HOST;
			$db_name = PL_CMS_APPOINTMENT_DB_NAME;
			$db_user = PL_CMS_APPOINTMENT_DB_USER;
			$db_passwd = PL_CMS_APPOINTMENT_DB_PASSWORD;
			$this->cDBappo = new Ccms_database_mysql();
			break;
		default:
			self::addAdminMsg('Cannot identify ' . $this->get_title() . ' database type.');
			return;
			// break;
			} // switch
		if(($this->init($install_tables)) &&
			(self::is_enabled())) 
			$this->ok = true;
		} // __construct()

	function __destruct() {
		} // __destruct()

	// static methods
	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
		// check it is available
			if(!self::is_plugin_enabled(self::PLUGIN)) self::$enabled = false;
			else if(empty(PL_CMS_APPOINTMENT_MNGR_EMAIL)) {
				self::addAdminMsg('Missing appointments manager email address.');
				self::$enabled = false;
				} // if
			else self::$enabled = true;
			} // if
		return self::$enabled;
		} // is_enabled()

	protected static function fmt_datetime($time,$fmt = false) {
		if(empty($fmt)) $fmt = "Y-m-d g:ia";
		return date($fmt, $time);
		} // fmt_datetime(0

	protected static function fmt_hours_minutes($time) {
		$h = ((int)$time / 3600) % 24;
		$m = ((int)$time / 60) % 60;
		if($h == 12) { $a = 'pm'; }
		else if($h > 12) { $a = 'pm'; $h -= 12; }
		else $a = 'am';
		return sprintf('%d:%002d%s',$h,$m,$a);
		} // fmt_hours_minutes()

	public static function get_appo_js() {
		static $done = false;
		if($done) return '';	// do once, can be called in different ways
		$done = true;

		$text =<<< EOTJS
		<script  type="text/javascript">
			function appo_toggle_panel_forms(id,other_id) {
				let pan = document.getElementById(id);
				let pan_act = document.getElementById(id + '_act');
				if((!pan) || (!pan_act)) return false;
				var pan_open = false;
				if(pan.style.display == 'none') {
					pan_open = true;
					pan.style.display = 'initial';
					pan_act.style.display = 'none';
					} // if
				else {
					pan_open = false;
					pan.style.display = 'none';
					pan_act.style.display = 'initial';
					} // else
				if(other_id.length > 3) {
					let pan_other = document.getElementById(other_id);
					let pan_other_act = document.getElementById(other_id + '_act');
					if((!pan_other) || (!pan_other_act)) return false;
					if(pan_open) {
						pan_other.style.display = 'none';	// turn off companion panel
						pan_other_act.style.display = 'initial';	// turn on companion panel actuator
						} // if
					else {
						pan_other.style.display = 'initial';	// turn off companion panel
						pan_other_act.style.display = 'none';	// turn on companion panel actuator
						} // else				
					} // if
				return true
				} // appo_toggle_panel_forms()
		</script>
EOTJS;
		return $text;
		} // get_appo_js()

	public static function get_appo_styles() {
		static $done = false;
		if($done) return '';	// do once, can be called in different ways
		$done = true;
		$lr_cols_width_offset = ' - ' . ' 30px - ' . (Ccms_sm::show_left_column() ? CMS_S_LEFT_WIDTH:'0px') . ' - ' . (Ccms_sm::show_right_column() ? CMS_S_RIGHT_WIDTH:'0px');
		$app_table_cell_width = 150;
		$app_table_width = $app_table_cell_width * self::DAY_FNSH_INC;
				
		$text =<<< EOTSTY
		<style>
			::-webkit-scrollbar {
				width: 15px;   /* for vertical scroll bar */
				height: 15px;  /* for horizontal scroll bar */
				}

			.thin_scroll {	/* for Firefox add this class as well */
				scrollbar-width: auto; /* auto | thin | none | <length>; */
				}
			div.welcome {
				/*width: 98%;*/
				/* margin:6px; */
				/*padding: 0px;*/
				} 
			p.welcome {
				/*max-width: 98%;*/
				text-align: center;
				font-size: 1.2em;
				/* margin: auto; */
				}
			::-webkit-scrollbar {
				width: 20px;
				}
			div.cms_appo_h_scroll_box {
				width: calc(100vw {$lr_cols_width_offset});
				margin: 10px;
				overflow-x: auto;
				/*overflow-y: hidden;*/
				-webkit-overflow-scrolling: touch;
				}
			div.appo_panel {
				/* width: 98%; */
				/* margin: auto; /*
				text-align: center;
				}
			div.appo_row {
				display: table !important;
				/* width: 100% !important; */
				/* table-layout: fixed !important; */
				/* border-spacing: 10px !important; */
				padding: 5px 10px 5px 10px;
				margin: auto;
				}
			div.appo_column {
				display: table-cell !important;
				vertical-align: top;
				}

			table.cms_appo {
				min-width: {$app_table_width}px;
				margin: auto;
				}
				
			th.cms_appo_na,
			td.cms_appo_na {
				font-style: italic;
				color:	slategray;
				pointer-events: none;
				}
			th.cms_appo_available,
			td.cms_appo_available,
			th.cms_appo_na,
			td.cms_appo_na {
				border: 1px solid gray;
				vertical-align: top;
				padding: 5px;
				width: {$app_table_cell_width}px;
				text-align: center;
				}
		</style>
EOTSTY;
		return $text;
		} // get_appo_styles()

	// dynamic methods
	public function is_ok() { return $this->ok; } // is_ok()

	protected function init($install_tables) {
		if(self::is_rebuild()) $install_tables = true;
		if(($install_tables) ||
			(!$appo_result = $this->cDBappo->query("SELECT * FROM regd_users LIMIT 1")) ||
			(!$app = $this->cDBappo->fetch_array($appo_result,false))) {
			$install_scripts = $this->get_SQLite_install_script();
			switch($this->db_type) {
			case 'MySQL':
				$install_scripts = Ccms_database_common::convert_scriptSQLite2MySQL($install_scripts);
				break;
			case 'SQLite':
			default:
				break;
				} // switch
			if(!$this->cDBappo->install_db_tables('', $install_scripts)) {
				self::addAdminMsg('Failed to update/create ' . $this->get_title() . ' database.');
				return false;
				} // if
			} // if
		return true;
		} // init()
		
	protected function &is_appo_manager($user_id) {
		if(!is_null($this->appo_manager)) return $this->appo_manager;
		if(is_null($this->appo_manager)) {
			$this->appo_manager = false;	// init
			if((!empty($user_id)) && ($user_details = $this->get_user_details($user_id))) {
				$this->appo_manager = self::is_cms_app_manager(array('email' => $user_details['user_email'],'mobile' => $user_details['user_mobile'],));
				} // if
			else $this->appo_manager = self::is_cms_app_manager();	// check normal system user
			}
		return $this->appo_manager;
		} // is_appo_manager()	

	public function is_verification_codes_required($user) {
		if((!PL_CMS_APPOINTMENT_EMAIL_MOBILE_VERIFY) || (self::is_cli()) || (self::is_ajax())) return false;
		if((!empty($user['user_email'])) && (empty($user['user_email_confirmed']))) return $user;
		if((!empty($user['user_mobile'])) && (empty($user['user_mobile_confirmed']))) return $user;
		return false;	// not required or done
		} // is_verification_codes_required()

	protected function get_verification_codes_form($user_id) {
		if($mngr = $this->is_appo_manager($user_id)) return false;	// manager, part of base system (should be verified already)
		if((!$user = $this->get_user_details($user_id)) ||
			(!$this->is_verification_codes_required($user))) return false;

		$show_form = true;
		$url = self::get_base_url(true) . Ccms::get_body_uri();

		if((Ccms_base::get_or_post('op') == 'code_verification') &&
			($user_id = Ccms_base::get_or_post('user_id')) &&
			($user_id == $user['user_id'])) {		// check it
			$type = Ccms_base::get_or_post('verif_codes');
			if($type == 'resend') $resend = true;
			else if($type == 'verify') {
				$ok = true;	// assume it will be ok
				$feilds = [];
				if((!empty($user['user_email'])) && (empty($user['email_confirmed']))) {
					$email_code = Ccms_base::get_or_post('email_code');
					$email = Ccms_base::get_or_post('email');
					if(($user['user_email'] != $email) ||
						(!Ccms_auth::chk_auth_verification_code($email_code, $email, false, self::VERIFY_TYPE))) {
						$ok = false;
						Ccms_base::addMsg('Email verification code not found, try again.','info');
						} // if
					else {
						$fields['user_email_confirmed'] = 1;
						} // else
					} // if
				if((!empty($user['user_mobile'])) && (empty($user['mobile_confirmed']))) {
					$mobile_code = Ccms_base::get_or_post('mobile_code');
					$mobile = Ccms_base::get_or_post('mobile');
					if(($user['user_mobile'] != $mobile) ||
						(!Ccms_auth::chk_auth_verification_code($mobile_code, false, $mobile, self::VERIFY_TYPE))) {
						$ok = false;
						Ccms_base::addMsg('Mobile verification code not found, try again.','info');
						} // if
					else {
						$fields['user_mobile_confirmed'] = 1;
						} // else
					} // if
				if($ok) {	// update
					if($this->cDBappo->perform('regd_users',$fields,'update','user_id = ' . $user_id)) {
						Ccms_base::addMsg('Verification codes confirmed.','success');
						} // if
					$url = self::get_base_url(true) . Ccms::get_body_uri();
					Ccms_base::do_redirect_uri($url);	// should not return;
					$show_form = false;
					} // if
				} // else if
			else if($type == 'update_user') {
				if($user_inps = $this->get_user_details_input()) {
					// update user
					$fields = array(
						"user_name" => $name,		// the user name
						"user_email" => $email,			// the user email
						"user_mobile" => (!empty($mobile) ? $mobile:''),			// the user mobile phone number
						"user_password_md5" => md5($passwd),
						"user_last_login" => time(),
						"user_enabled" => 1,
						);
					if($this->cDBappo->perform('regd_users', $fields,'update','user_id = ' . $user_id)) {
						self::addAdminMsg('Update user: ' . $user_inps['name'] . '.');
						$url = self::get_base_url(true) . Ccms::get_body_uri();
						Ccms_base::do_redirect_uri($url);	// should not return;
						} // if
					} // if
				self::addAdminMsg('Failed to update user.');
				} // else if
			else {	// cancel
				$url = self::get_base_url(true);
				Ccms_base::do_redirect_uri($url);	// should not return;
				return '';
				} // else
			} // if
		
		if(
			((!empty($user['user_email'])) && (!$this->get_email('',$user['user_email'])))
			||
			((!empty($user['user_mobile'])) && (!$this->chk_get_mobile_number($user['user_mobile'])))
			) {
			ob_start();
			require(CMS_FS_PLUGINS_DIR . self::PLUGIN . '/appo_correct_user_details_form.php');
			$html = ob_get_clean();
			return $html;
			} // if
		
		if($show_form) {
			global $appo_class;
			$appo_class = $this->appo_class;
			ob_start();
			require(CMS_FS_PLUGINS_DIR . self::PLUGIN . '/appo_verification_form.php');
			$html = ob_get_clean();
			} // if
		else {
			$msgs = self::getMsgs();
			$html =<<<EOTDONE

	<div class="{$appo_class}" style="text-align: center;">
		<h1 class="{$appo_class}">
			Verification Done.
		</h1>
		<p class="{$appo_class}" style="text-align: center;">
			<button type="button" name="verif_codes" value="continue"
				onclick="window.location.href = '{$url}'"/>Continue</button>
		</p>
		<p class="{$appo_class}" style="text-align: center;">
			{$msgs}
		</p>
	</div>	

EOTDONE;
			} // else
		return $html;
		} // get_verification_codes_form()	 
	
	public function get_sess_logged_in_user_id() {
		$user_id = self::get_cms_sess_var(self::PLUGIN, 'user_id');
		if(!empty($user_id)) {
			if(!$user_details = $this->get_user_details($user_id)) {
				self::unset_cms_sess_var(self::PLUGIN, 'user_id');
				return false;
				} // if
			return $user_id;
			} // if
		return false;
		} // get_sess_logged_in_user_id()

	public function save_sess_logged_in_user_id($user_id) {
		 return self::set_cms_sess_var($user_id,self::PLUGIN,'user_id');
		} // save_sess_logged_in_user_id()
		
	protected function get_user_details_input($mngr = false) {
		// optional bits
		$passwd = self::get_or_post_str(self::PLUGIN . "_passwd");
		if((!empty($passwd)) && (strlen($passwd) < LM_C_MIN_PASSWD_LEN)) {
			if(!$mngr) {
				self::addMsg('Password too short.');
				return false;	// missing
				} // if
			} // if
		// must have bits
		$name = self::get_or_post_str(self::PLUGIN . "_name");
		$email = false; $mobile = false;
		if(PL_CMS_APPOINTMENT_MOBILE_LOGIN) {	// either email or mobile
			if((!$email = $this->get_email(self::PLUGIN . "_email",'')) &&
				(!$mobile = $this->get_mobile_number(self::PLUGIN . "_mobile",'','','-'))) {// could be mobile number 
				self::addMsg('Email address or mobile number not valid.');
				return false;	// bad
				} // if
			if((!empty($email)) && (empty($mobile))) {	// check for a mobile too
				$mobile = self::get_or_post_str(self::PLUGIN . "_mobile");
				if((!empty($mobile)) &&
					(!$mobile = $this->get_mobile_number('',$mobile,'','-'))) {
					self::addMsg('Mobile number not valid.');
					return false;	// bad
					} // if
				} // if			
			if((empty($name)) && (!empty($email)))
				$name = preg_replace('/^(.*)@.*$/','$1',$email);	// use email username part
			} // if
		else {
			if(!$email = $this->get_email(self::PLUGIN . "_email",'')) {
				self::addMsg('Email address not valid.');
				return false;	// bad
				} // if
			if(empty($name)) 
				$name = preg_replace('/^(.*)@.*$/','$1',$email);	// use email username part
			// optional bits
			$mobile = self::get_or_post_str(self::PLUGIN . "_mobile");
			if((!empty($mobile)) &&
				(!$mobile = $this->get_mobile_number('',$mobile,'','-'))) {
				self::addMsg('Mobile number not valid.');
				return false;	// bad
				} // if
			} // else
		if((!empty($mobile)) && (!$this->chk_get_mobile_number($mobile))) {
			self::addMsg('Mobile number is not SMS compatible.');
			return false;
			} // if

		$user_id = self::get_or_post(self::PLUGIN . "_user_id");	// may be empty
		return ['user_id' => $user_id, 'name' => $name, 'email' => $email, 'passwd' => $passwd, 'mobile' => $mobile];
		} // get_user_details_input()

	public function get_register_form($appo_class,$use_ssl = true) {
		if(!self::is_ssl_inuse()) {
			self::addAdminMsg('Cannot login to ' . self::PLUGIN . '. Not on a secure protocol.');
			return '';
			}
		$action_url = Ccms::get_body_uri();
		$plugin = self::PLUGIN;
		$email = self::get_or_post_str($plugin . '_email');
		$name = self::get_or_post_str($plugin . '_name');
		$mobile = self::get_or_post_str($plugin . '_mobile');
		$m_params = self::PHONE_NUMBER_MIN_MAX_PARAM;

		$passwd_txt = Ccms_html::set_JS_password_input($plugin . '_passwd','Password: Used to login','',self::$use_strong_passwds,false,false,'required');
		$text = self::get_appo_styles();
		$text .= self::get_appo_js();
		$text .= <<<EOTTXT
		<div id="reg_pan_act" class="{$appo_class} appo_panel"><button onclick="appo_toggle_panel_forms('reg_pan','login_pan');">Register</button></div>
		<div id="reg_pan" style="display: none;">
		<form action="{$action_url}" method="post">
			<div class="{$appo_class} appo_row">
				<div class="{$appo_class} appo_column"><input type="text" placeholder="Email address" name="{$plugin}_email" value="{$email}" title="Email: Used to login." REQUIRED></div>
				<div class="{$appo_class} appo_column">{$passwd_txt}</div>
				<div class="{$appo_class} appo_column"><button type="submit" onclick="Ccms_cursor.setWait();" name="{$plugin}_submit" value="register" title="Click to login.">Register</button></div>
			</div>
			<div class="{$appo_class} appo_row">
				<div class="{$appo_class} appo_column"><input type="text" placeholder="Name" title="Your name" name="{$plugin}_name" value="{$name}"></div>
				<div class="{$appo_class} appo_column"><input type="text" placeholder="Mobile number" title="Mobile: (Optional)" name="{$plugin}_mobile" value="{$mobile}" {$m_params}></div>
				<div class="{$appo_class} appo_column"><button type="button" onclick="appo_toggle_panel_forms('reg_pan','');" title="Click to cancel login.">Cancel</button></div>
			</div>
			<input type="hidden" name="{$plugin}_form" value="register_form">
		</form>
		</div>
EOTTXT;
		return $text;
		} // get_register_form()

	protected function db_register_appo_user($email,$passwd,$name,$mobile) {
		if((empty($email)) || (empty($passwd))) return false;
		if(empty($name)) $name = preg_replace('/^(.*)@.*$/','$1',$email);	// use email username part
		if($user_id = $this->cDBappo->get_data_in_table('regd_users', 'user_id','user_email = \'' . $email . '\'')) {
			self::addMsg('User email: ' . $email . ' already registered. Please login.','warn');
			return $user_id;
			} // if

		// register user
		$fields = array(
			"user_name" => $name,		// the user name
			"user_email" => $email,			// the user email
			"user_mobile" => (!empty($mobile) ? $mobile:''),			// the user mobile phone number
			"user_password_md5" => md5($passwd),
			"user_last_login" => time(),
			"user_enabled" => 1,
			);
		if(!$this->cDBappo->perform('regd_users', $fields)) {
			self::addAdminMsg('Failed to add user: ' . $name . '.');
			return false;
			} // if
		$user_id = $this->cDBappo->insert_id();
		$this->save_sess_logged_in_user_id($user_id);	// login user
		return $user_id;
		} // db_register_appo_user()

	public function register_appo_user() {
		$form = self::get_or_post_str(self::PLUGIN . "_form");
		switch($form) {
		case 'register_form':	// registering
		case 'bookit_form':	// not logged in, so see if we can login
			break;
		default:
			return false;	// no
			} // switch

		// must have bits
		if((!$passwd = self::get_or_post_str(self::PLUGIN . "_passwd")) ||
			(strlen($passwd) < LM_C_MIN_PASSWD_LEN)) {
			self::addMsg('Password too short.');
			return false;	// missing
			} // if
		$email = self::get_or_post_str(self::PLUGIN . "_email");
		if((!empty($email)) &&
			(!$email = $this->get_email('',$email))) {
			self::addMsg('Email address not valid.');
			return false;	// bad
			} // if
		$mobile = self::get_or_post_str(self::PLUGIN . "_mobile");
		if((!empty($mobile)) &&
			(!$mobile = $this->get_mobile_number('',$mobile,'','-'))) {
			self::addMsg('Mobile number not valid.');
			return false;	// bad
			} // if
		if(!PL_CMS_APPOINTMENT_MOBILE_LOGIN){
			if(empty($email)) {
				self::addMsg('Email address is required.');
				return false;	// bad
				} // if
			} // if
		else {	
			if((empty($email)) && (empty($mobile))) {
				self::addMsg('Email address or mobile number is required.');
				return false;	// bad
				} // if
			} // else
		$name = self::get_or_post_str(self::PLUGIN . "_name");
		if(empty($name)) $name = preg_replace('/^(.*)@.*$/','$1',$email);	// use email username part

		if((!empty($mobile)) && (!$this->chk_get_mobile_number($mobile))) {
			self::addMsg('Mobile number is not SMS compatible or not unique.');
			return false;
			} // if
		
		return $this->db_register_appo_user($email, $passwd, $name, $mobile);
		} // register_appo_user()

	public function get_login_form($appo_class,$use_ssl = true) {
		if(($use_ssl) && (!self::is_ssl_inuse())) {
			self::addAdminMsg('Cannot login to ' . self::PLUGIN . '. Not on secure protocol.');
			return '';
			}
		$action_url = Ccms::get_body_uri();
		$plugin = self::PLUGIN;
		$passwd_txt = Ccms_html::set_JS_password_input($plugin . '_passwd','Password: Used to login','',false,false,false,'required');
		$em_ph = (PL_CMS_APPOINTMENT_MOBILE_LOGIN ? 'Email address or mobile':'Email address');
		$text = self::get_appo_styles();
		$text .= self::get_appo_js();
		$text .= <<<EOTTXT

		<div id="login_pan_act" class="{$appo_class} appo_panel"><button onclick="appo_toggle_panel_forms('login_pan','reg_pan');">Login</buuton></div>
		<div id="login_pan" style="display: none;">
			<form action="{$action_url}" method="post">
			<div class="{$appo_class} appo_row">
				<div class="{$appo_class} appo_column"><input type="text" name="{$plugin}_email" value="" placeholder="{$em_ph}" title="Email: Used to login." REQUIRED></div>
				<div class="{$appo_class} appo_column">{$passwd_txt}</div>
				<div class="{$appo_class} appo_column"><button type="submit" onclick="Ccms_cursor.setWait();" name="{$plugin}_submit" value="login" title="Click to login.">Login</button></div>
				<div class="{$appo_class} appo_column"><button type="button" onclick="appo_toggle_panel_forms('login_pan','')" title="Click to cancel login.">Cancel</button></div>
			</div>
			<input type="hidden" name="{$plugin}_form" value="login_form">
			</form>
		</div>
EOTTXT;
		return $text;
		} // get_login_form()

	public function login_appo_user() {
		$user_id = $this->get_sess_logged_in_user_id();
		if((int)$user_id > 0) return $user_id;	// already logged in
		$form = self::get_or_post_str(self::PLUGIN . "_form");
		switch($form) {
		case 'login_form':	// logging in
		case 'bookit_form':	// not logged in, so see if we can login
			break;
		default:
			return false;	// no
			} // switch

		// must have bits
		if(!$passwd = self::get_or_post_str(self::PLUGIN . "_passwd")) return false;
		$chk_mob_flg = false;
		$where = 'user_password_md5 = \'' . md5($passwd) . '\'';
		if(PL_CMS_APPOINTMENT_MOBILE_LOGIN) {	// email or mobile
			if(!$email = $this->get_email(self::PLUGIN . "_email",'')) {	// not an email
				if((!$mobile = $this->get_mobile_number(self::PLUGIN . "_email",'','','-')) &&	// mobile in email input
					(!$mobile = $this->get_mobile_number(self::PLUGIN . "_mobile",'','','-')))	// mobile
					return false;
				$chk_mob_flg = true;
				// $where .= ' AND user_mobile LIKE \'%' . $mobile . '\'';	// format varys
				} // if
			else { // has an email
				$where .= ' AND user_email = \'' . $email . '\'';
				} // else
			} // if
		else {	// email only
			if(!$email = $this->get_email(self::PLUGIN . "_email",'')) return false;	// not an email
			$where .= 'user_email = \'' . $email . '\'';
			} // else
		if(!$user = $this->cDBappo->get_data_in_table('regd_users', ['user_id','user_email','user_mobile'],$where)) {
			if($form != 'login') return false;
			self::addMsg('Login failed.','warn');
			return false;	// bad
			} // if
		$user_id = $user['user_id'];
		if($chk_mob_flg) {	// found password (but no email)
			if(!self::is_mobile_numbers_same($mobile,$user['user_mobile'])) {
				if($form != 'login') return false;
				self::addMsg('Login failed.','warn');
				return false;	// bad
				} // if
			} // if		
		self::set_cms_sess_var($user_id,self::PLUGIN,'user_id');
		$this->cDBappo->query('UPDATE regd_users SET user_last_login = ' . time() . ', user_enabled = 1 WHERE user_id = ' . $user_id);
		self::addAdminMsg('User logged in.','info');
		return $user_id;
		} // login_appo_user()

	public function get_logout_form($appo_class,$user_id,$use_ssl = true) {
		if(($use_ssl) && (!self::is_ssl_inuse())) {
			self::addAdminMsg(self::PLUGIN . ' on insecure protocol.');
			} // if
		if(((int)$user_id <= 0) &&
			(!$user_id = $this->get_sess_logged_in_user_id()))
			return '';
		$action_url = Ccms::get_body_uri();
		$plugin = self::PLUGIN;

		$text = self::get_appo_styles();
		$text .= self::get_appo_js();
		$text .= <<<EOTTXT
		<form action="{$action_url}" method="post">
		<div class="{$appo_class}" appo_panel>
			<button type="submit" onclick="Ccms_cursor.setWait();" name="{$plugin}_submit" value="logout" title="Click to logout.">Logout</button>
		</div>
		<input type="hidden" name="{$plugin}_user_id" value="{$user_id}">
		<input type="hidden" name="{$plugin}_form" value="logout_form">
		</form>
EOTTXT;
		return $text;
		} // get_logout_form()

	public function logout_appo_user($user_id = false) {
		if(self::get_or_post_str(self::PLUGIN . "_form") != 'logout_form') return false;
		if((empty($user_id)) &&
			(!$user_id = $this->get_sess_logged_in_user_id()) &&
			(!$user_id = self::get_or_post(self::PLUGIN . "_user_id")))
			return false;

		self::set_cms_sess_var(0,self::PLUGIN,'user_id');
		$this->cDBappo->query('UPDATE regd_users SET user_last_login = 0 WHERE user_id = ' . $user_id);
		self::addAdminMsg('User looged out.','info');
		return true;
		} // logout_appo_user()

	public function get_chg_user_details_form($appo_class,$user_id,$use_ssl = true) {
		if(!self::is_ssl_inuse()) {
			self::addAdminMsg('Cannot login to ' . self::PLUGIN . '. Not on a secure protocol.');
			return '';
			}
		$action_url = Ccms::get_body_uri();
		$plugin = self::PLUGIN;
		if(empty($user_id)) $user_id = $this->get_sess_logged_in_user_id();
		if((empty($user_id)) ||
			(!$user_details = $this->get_user_details($user_id))) {
			return '';
			} // if
		$email = self::get_or_post_str($plugin . '_email');
		if(empty($email)) $email = $user_details['user_email'];
		
		$name = self::get_or_post_str($plugin . '_name');
		if(empty($name)) $name = $user_details['user_name'];
		
		$mobile = self::get_or_post_str($plugin . '_mobile');
		if(empty($mobile)) $mobile = $user_details['user_mobile'];
		$m_params = self::PHONE_NUMBER_MIN_MAX_PARAM;
		
		$passwd_txt = Ccms_html::set_JS_password_input($plugin . '_passwd','Password: Used to login. \nLeave empty to not change your password.','',self::$use_strong_passwds,false,false);
		$text = self::get_appo_styles();
		$text .= self::get_appo_js();
		$text .= <<<EOTTXT
		<div id="usr_dets_pan_act" class="{$appo_class} appo_panel"><button onclick="appo_toggle_panel_forms('usr_dets_pan','');" title="Click to update personal details.">Update</button></div>
		<div id="usr_dets_pan" style="display: none;">
		<form action="{$action_url}" method="post">
			<div class="{$appo_class} appo_row">
				<div class="{$appo_class} appo_column"><input type="text" placeholder="Email address" name="{$plugin}_email" value="{$email}" title="Email: Used to login." REQUIRED></div>
				<div class="{$appo_class} appo_column">{$passwd_txt}</div>
				<div class="{$appo_class} appo_column"><button type="submit" onclick="Ccms_cursor.setWait();" name="{$plugin}_submit" value="register" title="Click to login.">Update</button></div>
			</div>
			<div class="{$appo_class} appo_row">
				<div class="{$appo_class} appo_column"><input type="text" placeholder="Name" title="Your name" name="{$plugin}_name" value="{$name}"></div>
				<div class="{$appo_class} appo_column"><input type="text" placeholder="Mobile number" title="Mobile: (Optional)" name="{$plugin}_mobile" value="{$mobile}" {$m_params}></div>
				<div class="{$appo_class} appo_column"><button type="button" onclick="appo_toggle_panel_forms('usr_dets_pan','');" title="Click to cancel update.">Cancel</button></div>
			</div>
			<input type="hidden" name="{$plugin}_form" value="upd_usr_details_form">
		</form>
		</div>
EOTTXT;
		return $text;
		} // get_chg_user_details_form()

	protected function chk_mobile_number(&$mobile,$user_id = 0) {
		if(!empty($mobile)) {
			if(!$mobile = $this->get_mobile_number('',$mobile,'','-')) {
				self::addMsg('Mobile number not valid.');
				return false;	// bad
				} // if
			if(!$this->chk_get_mobile_number($mobile)) {
				self::addMsg('Mobile number is not valid.');
				return false;
				} // if
			} // if
		if($result = $this->cDBappo->query('SELECT user_mobile,user_id FROM regd_users')) {	// check if unique
			while($row = $this->cDBappo->fetch_array($result)) {
				if($user_id == $row['user_id']) continue;	// user
				if(self::is_mobile_numbers_same($mobile,$row['user_mobile'])) {
					self::addMsg('User mobile: ' . $mobile . ' allready registered. Please use another mobile number.','warn');
					return false;
					} // if
				} // while
			} // if
		return true;
		} // chk_mobile_number()
		
	protected function chk_email_address(&$email,$user_id = 0) {
		if(empty($email)) {
			self::addMsg('Email address not valid.');
			return false;	// bad
			} // if
		if(($other_user_id = $this->cDBappo->get_data_in_table('regd_users', 'user_id','user_email = \'' . $email . '\'')) &&
			($user_id != $other_user_id)) {	// someone elses email
			self::addMsg('User email: ' . $email . ' allready registered. Please use another email address.','warn');
			return false;
			} // if
		return true;
		} // chk_mobile_number()
		
	public function upd_appo_user_details($user_id) {
		if(self::get_or_post_str(self::PLUGIN . "_form") != 'upd_usr_details_form') return false;	// not me
		if((empty($user_id)) &&
			(!$user_id = $this->get_sess_logged_in_user_id())) {
			self:self::addAdminMsg('Cannot change user details. User not identified.');
			return false;
			} // if

		// update user
		$user_details = $this->get_user_details($user_id);
		$fields = array(
//			"user_name" => $name,		// the user name
//			"user_email" => $email,			// the user email
//			"user_mobile" => (!empty($mobile) ? $mobile:''),			// the user mobile phone number
//			"user_password_md5" => md5($passwd),
			"user_last_login" => time(),
			"user_enabled" => 1,
			);
		$passwd = self::get_or_post_str(self::PLUGIN . "_passwd");
		if(!empty($passwd )) {	// new password ||
			if(strlen($passwd) < LM_C_MIN_PASSWD_LEN) {
				self::addMsg('Password too short.');
				return false;	// missing
				} // if
			else {
				$fields['user_password_md5'] = md5($passwd);
				} // else
			} // if

		$email = $this->get_email(self::PLUGIN . "_email",'');
		if(!$this->chk_email_address($email,$user_id)) return false;

		$fields['user_email'] = $email;
		if(($user_details) && ($user_details['user_email'] != $email)) $fields['user_email_confirmed'] = 0;
		
		$name = self::get_or_post_str(self::PLUGIN . "_name");
		if(empty($name)) $name = preg_replace('/^([0-9a-z_-]+)@.*$/','$1',$email);	// use email username part
		$fields['user_name'] = $name;

		$mobile = $this->get_mobile_number(self::PLUGIN . "_mobile",'','-');
		if(!$this->chk_mobile_number($mobile,$user_id)) return false;
		$fields['user_mobile'] = $mobile;
		if(($user_details) && ($user_details['user_mobile'] != $mobile)) $fields['user_mobile_confirmed'] = 0;

		// udpate user
		if(!$this->cDBappo->perform('regd_users', $fields,'update','user_id = ' . (int)$user_id)) {
			self::addAdminMsg('Failed to update user: ' . $name . '.');
			return false;
			} // if
		self::addAdminMsg('Updated user: ' . $name . '.','success');
		return $user_id;
		} // upd_appo_user_details()

	protected function get_welcome($appo_class,$user_id) {
		$start_time = strtotime("today 00:00");
		$end_time = $start_time + (self::SECS_DAY * self::DAY_FNSH_INC);
		$text = array();
		if($mngr = $this->is_appo_manager($user_id)) {	// manager
			//$text[] = '<div class="' . $appo_class . ' welcome">';
			$text[] = '	<p class="' . $appo_class . ' welcome" style="font-weight: bold;">';
			$text[] = '		Appointments Management by: ' . $mngr['name'];
			$text[] = '	</p>';
			// $text[] = '</div>';
			} // if
		else {
			if(($user_id = $this->get_sess_logged_in_user_id()) ||
				($user_id = self::get_or_post(self::PLUGIN . "_user_id"))) 
				$user_details = $this->get_user_details($user_id);
			else $user_details = array();
			$text[] = '<div class="' . $appo_class . ' welcome">';
			if(strlen(PL_CMS_APPOINTMENT_WELCOME_MESSAGE) >= 15) {
				$text[] = '	<p class="' . $appo_class . ' welcome">';
				$text[] = '		' . (!empty($user_details['user_name']) ? $user_details['user_name'] . ': ':'') . PL_CMS_APPOINTMENT_WELCOME_MESSAGE;
				$text[] = '	</p>';
				} // if
			$text[] = '	<p class="' . $appo_class . ' welcome">';
			$text[] = '		For: ' . $this->fmt_datetime($start_time, 'd M') . ' to ' . $this->fmt_datetime($end_time, 'd M Y');
			$text[] = '	</p>';
			$text[] = '</div>';
			} // else
		$txt = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		return $txt;
		} // get_welcome()

	protected function get_mngr_form_modal($appo_class,&$dlg_name) {
		// enters form items inside the form
		$plugin = self::PLUGIN;
		$m_params = self::PHONE_NUMBER_MIN_MAX_PARAM;
		
		$id = 'mngr';
		$name = 'APPO';
		$n_i = $name . '_' . $id;	// should be the same $dlg_name
		$note_top = 'For: <span id="id_' . $plugin . '_from"></span>';
		if(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME)
			$note_top = ', To: <span id="id_' . $plugin . '_to"></span>';

		$modal_text =<<<EOTDLG
				
		<style>
			div.dlg,
			div.dlg tr,
			div.dlg th,
			div.dlg td { /* turn off borders */
				border: 0;
				}
			div.dlg table { /* turn on manager border */
				border: 2px solid red;
				border-radius: 5px;
				margin: 5px 0px;
				}
			div.dlg .label {
				text-align: right;
				padding-right: 5px;
				}
			div.dlg th.col1,
			div.dlg td.col1 { /* first column */
				width:	30%;
				}
			div.dlg td,
			div.dlg input {
				text-align: left;
				}
			div.dlg input[type="checkbox"] {
				width: unset;
				}
			div.dlg textarea,
			div.dlg input {
				width: 98%;
				}
			div.dlg textarea:read-only,
			div.dlg input:read-only {
				background-color: lightgrey;
				}
			label.top_note {
				font-weight: 600;
				}
		</style>

		<div id="id_{$n_i}_div" class="dlg">
			<table class="{$appo_class}">
				<tr class="{$appo_class}">
					<th class="{$appo_class}" colspan="2" style="text-align: center;">Appointment Details.</th>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class}" colspan="2">
						<label class="{$appo_class} top_note">{$note_top}</label>
					</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label col1"><label class="{$appo_class}">Name:</label></td>
					<td class="{$appo_class}"><input type="text" id="id_{$plugin}_name" name="{$plugin}_name" value=""></td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Email:</label></td>
					<td class="{$appo_class}"><input type="text" id="id_{$plugin}_email" name="{$plugin}_email" value=""></td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Mobile:</label></td>
					<td class="{$appo_class}"><input type="text" id="id_{$plugin}_mobile" name="{$plugin}_mobile" value="" {$m_params}></td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label  col1"><label class="{$appo_class}">Message:</label></td>
					<td class="{$appo_class}"><textarea id="id_{$plugin}_message" name="{$plugin}_message" title="Attendees / clients message." READONLY></textarea></td>
				</tr>
			</table>
			<table class="{$appo_class}">
				<tr class="{$appo_class}">
					<th class="{$appo_class}" colspan="2" style="text-align: center;">Appointment Management.</th>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label  col1"><label class="{$appo_class}">Comments:</label></td>
					<td class="{$appo_class}"><textarea id="id_{$plugin}_comments" name="{$plugin}_comments" placeholder="Enter managers comments." title="Not seen by appointee/client. For manager only."></textarea></td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Requested:</label></td>
					<td class="{$appo_class}" style="widthfloat: left;">
						<input type="checkbox" id="id_{$plugin}_requested" name="{$plugin}_requested">
						<span id="id_{$plugin}_requested_msg"></span>
					</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Confirmed:</label></td>
					<td class="{$appo_class}" style="float: left;">
						<input type="checkbox" id="id_{$plugin}_confirmed" name="{$plugin}_confirmed">
						<span id="id_{$plugin}_confirmed_msg"></span>
					</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class}" colspan="2" style="text-align: center;">
						<label class="{$appo_class}" id="id_save_btn"><button  
							onclick="submit_{$n_i}_form('id_{$n_i}_div','save');">Save</button></label>
						<label class="{$appo_class}" id="id_update_btn"><button 
							onclick="submit_{$n_i}_form('id_{$n_i}_div','update');">Update</button></label>
						<label class="{$appo_class}" id="id_delete_btn"><button 
							onclick="c{$n_i}_box.confirm_dlg(
								{ 
									'message': 'Are you sure you want to delete this appointment?',
									'ack': { 'func': confirmed_{$n_i}_delete },
									'dlg_id': 'id_{$n_i}_div',
									}
								);">Delete</button></label>
						<label class="{$appo_class}"><button 
							onclick="{$n_i}_close_modal();">Close</button></label>
					</td>
				</tr>
			</table>
		</div>
EOTDLG;

		$modal_text .= <<<EOTJS

		<script  type="text/javascript">
			var {$n_i}_form = false;
			var c{$n_i}_box = new Ccms_box();
			function submit_{$n_i}_form(dlg_id,op) {
				if(!{$n_i}_form) {
					console.log('ERROR: Dialog parent mngr form not found.');
					return false;
					} // if
				var dlg = document.getElementById(dlg_id);
				if(!dlg) {
					console.log('ERROR: Dialog ID: dlg_id not found.');
					return false;
					} // if
		
				var input = document.createElement("input");
				input.setAttribute("type", "hidden");
				input.setAttribute("name", '{$plugin}_' + op);
				input.setAttribute("value", op);
				{$n_i}_form.appendChild(input);	//append to form element that you want .

				// add dlg inputs to form
				let inps = dlg.getElementsByTagName('input');
				if(inps) for (let i = 0; i < inps.length; i++) {
					let inp = inps[i];
					var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", inp.name);
					input.setAttribute("value", inp.value);
					{$n_i}_form.appendChild(input);	//append to form element that you want .
					} // for

				// add dlg textareas to form
				let txts = dlg.getElementsByTagName('textarea');
				if(txts) for (let i = 0; i < txts.length; i++) {
					txt = txts[i];
					var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", txt.name);
					input.setAttribute("value", txt.value);
					{$n_i}_form.appendChild(input);	//append to form element that you want .
					} // for
				{$n_i}_form.submit();
				return true;
				} // submit_{$n_i}_form()
			function confirmed_{$n_i}_delete() {
				submit_{$n_i}_form('id_{$n_i}_div','delete');
				} // confirmed_{$n_i}_delete() {


		</script>

EOTJS;

		$header = '';	// if you provide a header, it is assumed to the complete dialog header.	
		$h1 = 'Appointment Management';
		$footer = '';

		$cModal = new Ccms_modal();
		$text = $cModal->get_modal($id, $modal_text, $appo_class, $h1, $header, $footer, $name);
		$dlg_name = $cModal->get_name();
		return $text;
		} // get_mngr_form_modal()

	 public function get_mngr_horizontal_slot_selectors($appo_class,$user_id = false, $use_ssl = true) {
		if(($use_ssl) && (!self::is_ssl_inuse())) {
			self::addAdminMsg('Call to ' . __CLASS__ . '::' . __METHOD__ . ' while not using a secure connection.');
			return '';
			} // if
		$plugin = self::PLUGIN;
		if(empty($user_id)) {	// not logged
			$user_id = 0;
			} // if
		$midnight = strtotime("today 00:00");
		$now = strtotime('today');
		$today = getdate($midnight);	// array
		$strt_dow = $today['wday'];
		// $start_time = $midnight - (($strt_dow + self::DAY_STRT_INC) * self::SECS_DAY);
		// $end_time = $start_time + (self::SECS_DAY * self::DAY_FNSH_INC);
		$start_time = $midnight;
		$end_time = $start_time + (self::SECS_DAY * self::DAY_FNSH_INC);

		$col_heads = self::get_slots_col_heads();
		$col_max = count($col_heads);
		$row_heads = self::get_slots_row_heads();
		$row_max = PL_CMS_APPOINTMENT_SLOTS_PER_DAY;
		
		$dlg_name = false;	// for ref
		$text = array();
		$text[] = self::get_appo_styles();
		$text[] = self::get_appo_js();

		$text[] = $this->get_mngr_form_modal ($appo_class, $dlg_name);
		$text[] = <<<EOTJSADM

	<script  type="text/javascript">
		function cms_appo_mngr_submit(form,event,slot_id,user_id,
			appointment_start,appointment_finish,
			name,email,mobile,message,comments,
			requested,confirmed,requested_msg,confirmed_msg,readonly) {

			var dlg_id = 'id_{$dlg_name}_container';
			var dlg = document.getElementById(dlg_id);
			if(!dlg) {
				console.log('ERROR: Dialog {$dlg_name} not found.');
				return false;
				} // if
			{$dlg_name}_open_modal();
			{$dlg_name}_form = form;
			let inps = [	// update dlg variables
				{'id': 'id_{$plugin}_from', 'type': 'span', 'value': appointment_start,},
				{'id': 'id_{$plugin}_to','type': 'span', 'value': appointment_finish,},
				{'id': 'id_{$plugin}_name', 'type': 'text', 'value': name, 'readonly_chk': true,},
				{'id': 'id_{$plugin}_email', 'type': 'text', 'value': email, 'readonly_chk': true,},
				{'id': 'id_{$plugin}_mobile', 'type': 'text', 'value': mobile, 'readonly_chk': true,}, 
				{'id': 'id_{$plugin}_message', 'type': 'textarea', 'value': message, 'readonly_chk': true,},
				{'id': 'id_{$plugin}_comments', 'type': 'textarea', 'value': comments,},
				{'id': 'id_{$plugin}_requested', 'type': 'checkbox', 'value': requested,},
				{'id': 'id_{$plugin}_confirmed', 'type': 'checkbox', 'value': confirmed,},
				{'id': 'id_{$plugin}_requested_msg','type': 'span', 'value': requested_msg,},
				{'id': 'id_{$plugin}_confirmed_msg','type': 'span', 'value': confirmed_msg,},
				];
			for(let i = 0; i < inps.length; i++) {
				let inp = inps[i];
				var elem = document.getElementById(inp['id']);
				if(!elem) {
					console.log('Elem id: ' + inp['id'] + ' not found.');
					continue;
					} // if
				switch(inp['type']) {
				case 'text':
					elem.value = inp['value'];
					break;
				case 'textarea':
					elem.value = inp['value'];
					break;
				case 'checkbox':
					elem.checked = (inp['value'] ? true:false);
					break;
				case 'span':
				default:
					elem.innerHTML = inp['value'];
					break;				
					} // switch
				if(inp['readonly_chk']) {
					elem.readOnly = (user_id ? true:false);					
					} // if
				} // for
			var sav_btn = document.getElementById('id_save_btn');
			if(sav_btn) {
				if(user_id) sav_btn.style.display = 'none';
				else  sav_btn.style.display = '';
				} // if
			var upd_btn = document.getElementById('id_update_btn');
			if(upd_btn) {
				if(!user_id) upd_btn.style.display = 'none';
				else  upd_btn.style.display = '';
				} // if
			var del_btn = document.getElementById('id_delete_btn');
			if(del_btn) {
				if(!user_id) del_btn.style.display = 'none';
				else  del_btn.style.display = '';
				} // if
				
			return true;
			} // cms_appo_mngr_submit()

	</script>

EOTJSADM;

		$text[] = '<div class="cms_appo_h_scroll_box">';
		$text[] = '		<table id="slot_select" class="' . $appo_class . ' cms_appo" style="width: unset; min-width: 100%;">';

		// if(self::is_debug())
		// put up week heading
		$text[] = '		<tr class="' . $appo_class . '">';
		for($day_time = $start_time,$c = $strt_dow; $day_time < $end_time; $day_time += self::SECS_DAY,$c++) {
			if($day_time < $now) {
				$text[] = '			<th class="' . $appo_class . ' ' .
								(($c & 1) ? '' . $appo_class . '_odd':'' . $appo_class . '_even') . ' cms_appo_na" style="text-align: center;">' . date('l',$day_time) . '<br>' . $this->fmt_datetime($day_time, 'd M') . '</th>';
				} // if
			else {
				$text[] = '			<th class="' . $appo_class . ' ' . 
								(($c & 1) ? '' . $appo_class . '_odd':'' . $appo_class . '_even') . ' cms_appo_available" style="text-align: center;">' . date('l',$day_time) . '<br>' . $this->fmt_datetime($day_time, 'd M') . '</th>';
				} // else
			} // for
		$text[] = '		</tr>';

		// put up booking slots
		$grid = self::unserialize_string2arry(PL_CMS_APPOINTMENT_TIME_SLOTS);	// contains offsets from midnight for each eweekday
		$booked = $this->get_appointments($start_time, $end_time);
		for($r = 0; $r < $row_max; $r++) {
			$text[] = '		<tr class="' . $appo_class . '">';
			for($day_time = $start_time,$c = $strt_dow; $day_time < $end_time; $day_time += self::SECS_DAY,$c++) {

				if(!empty($grid[($c % self::DAYS_WEEK)][$r])) {	// ok
					$grc = &$grid[($c % self::DAYS_WEEK)][$r];
					$s_strt = (int)$grc['strt'];
					$s_end = (int)$grc['end'];
					$past = (($day_time + $s_strt) < time()) ? true:false;
					$avail = ($past ? false:true);

					if(($s_strt > 0) && (($s_strt + self::TIME_INC) <= $s_end)) {	// check for no slot config  errors

						$slot_id = 'id_dlg_slot[' . $r . '][' . $c . ']';
						$text[] = '			<td class="' .
								(($c & 1) ? '' . $appo_class . '_odd':'' . $appo_class . '_even') . (!$avail ? ' cms_appo_na':' cms_appo_available') . '">';
						$text[] = '				<div id="' . $slot_id . '">';

						$start = ($day_time + $s_strt);
						$finish = ($day_time + $s_end);

						// find reserved slots
						$appointment = array_filter($booked, function($d) use ($start,$finish) {	// find unused keys
							if(($d['strt_time'] >= $start) && ($d['strt_time'] <= $finish)) return true;
							if(($d['end_time'] >= $start) && ($d['end_time'] <= $finish)) return true;
							if(($start >= $d['strt_time']) && ($start <= $d['end_time'])) return true;
							if(($finish >= $d['strt_time']) && ($finish <= $d['end_time'])) return true;
							return false;
							});
						$reserved = array_shift($appointment);

						$time_start = $this->fmt_datetime($start,'l M jS, g:ia');
						$time_finish = $this->fmt_datetime($finish,'l M jS, g:ia');
						$h_m_strt = self::fmt_hours_minutes($s_strt);
						$h_m_end = self::fmt_hours_minutes($s_end);
						
						$readonly = false;	// ($reserved['confirmed'] ? 'true':'false');
						if($reserved) {
							if($user_details = $this->get_user_details($reserved['user_id'])) {
								$user_name = $user_details['user_name'];
								$user_email = $user_details['user_email'];
								$user_mobile = $user_details['user_mobile'];
								} // if
							else if($appointment_details = $this->get_appointment_details($reserved['appo_id'])) {
								$user_name = $appointment_details['user_name'];
								$user_email = $appointment_details['user_email'];
								$user_mobile = $appointment_details['user_mobile'];
								} // else if
							else self::addDebugMsg('Appointment and user details not found.');
							} // if
						else {
							$user_name = '(No booking)';
							$user_email = '';
							$user_mobile = '';							
							} // else
						$requested_msg = ($reserved ? ($reserved['requested'] ? 'Request acknowledged':'Acknowledge request'):'');
						$confirmed_msg = ($reserved ? ($reserved['confirmed'] ? 'Confirmation sent':'Send confirmation'):'');
						if($avail) $text[] = '					<form action="' . Ccms::get_body_uri() . '" method="post"' .
							' onclick="cms_appo_mngr_submit(this,event,\'' . $slot_id . '\',' . ($reserved ? (int)$reserved['user_id']:0) . ',' .
								'\'' . $time_start . '\',\'' . $time_finish . '\',' .
								'\'' . $user_name . '\',\'' . $user_email . '\',\'' . $user_mobile . '\',' .
								'\'' . ($reserved ? $reserved['message']:'') . '\',\'' . ($reserved ? $reserved['comments']:'') . '\',' .
								($reserved ? (int)$reserved['requested']:0) . ',' . ($reserved ? (int)$reserved['confirmed']:0) . ',' .
								'\'' . $requested_msg . '\',\'' . $confirmed_msg . '\',' . $readonly . ');">' .
							' <input type="hidden" name="' . self::PLUGIN . '_form" value="admin_form">' .
							' <input type="hidden" name="' . self::PLUGIN . '_slot_id" value="' . $slot_id . '">' .
							' <input type="hidden" name="' . self::PLUGIN . '_user_id" value="' . ($reserved ? $reserved['user_id']:0) . '">' .
							' <input type="hidden" name="' . self::PLUGIN . '_appo_id" value="' . ($reserved ? $reserved['appo_id']:0) . '">' .
							' <input type="hidden" name="' . self::PLUGIN . '_start" value="' . $start . '">' .
							' <input type="hidden" name="' . self::PLUGIN . '_finish" value="' . $finish . '">';

						$status = 'Booking for ' . $user_name;
						if(($reserved) && ($reserved['confirmed'] > 0)) {
							$status .= ' CONFIRMED';									
							} // if
						else if(($reserved) && ($reserved['requested'] > 0)) {
							$status .= ' REQUESTED';
							} // else if
						else if($avail) $status = 'Available';
						else $status .= '?';
						$status .= '.';
						$text[] = '				' . $h_m_strt . '<br>' .
								(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? 'to<br>' . $h_m_end . '<br>':'') . $status;
						if($avail) $text[] = '				</form>';
						
						$text[] = '				</div>';
						$text[] = '			</td>';
						} // if
					else $text[] = '			<td>&nbsp;</td>';
					} //if
				else $text[] = '			<td>&nbsp;</td>';
				} // for
			$text[] = '		</tr>';
			} // for
		$text[] = '		</table>';
		$text[] ='	</div>';

		$txt = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		return $txt;
		} // get_mngr_horizontal_slot_selectors()
		
	protected function get_clnt_bookit_form_modal($appo_class,&$dlg_name,$user_id) {
		// enters form items inside the form
		$plugin = self::PLUGIN;
		$m_params = self::PHONE_NUMBER_MIN_MAX_PARAM;
		
		$id = 'bookit';
		$name = 'APPO';
		$n_i = $name . '_' . $id;	// should be the same $dlg_name
		$note_top = 'For: <span id="id_' . $plugin . '_from"></span>';
		if(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME)
			$note_top .= ', To: <span id="id_' . $plugin . '_to"></span>';

		$user_keys = ['user_name','user_email','user_mobile'];	// from appo regd_users table column names
		if(((int)$user_id > 0) && ($user = $this->get_user_details($user_id))) {	// logged in user
			foreach($user_keys as $k) $$k = $user[$k];
			if(empty($user_mobile)) $user_mobile = 'N.A.'; 
			$notes = 'If your details are incorrect, please update your details.';
			$disp_state = 'none';
			$readonly = ' READONLY';
			$user_passwd = '';
			} // if
		else {	// guest
			$notes = '';
			$disp_state = '';
			$readonly = '';
			foreach($user_keys as $k) {
				// put up input elements to login
				$v = '';
				switch($k) {
				case 'user_name':
					$v = '<input type="text" placeholder="Name" title="Your name (optional)" name="' . $plugin . '_name" value="">';
					break;
				case 'user_email':
					$v = '<input type="text" placeholder="Email" title="Your email (to login)" name="' . $plugin . '_email" value="">';
					break;
				case 'user_mobile':
					$v = '<input type="text" placeholder="Mobile/phone" title="Your mobile/phone' . (PL_CMS_APPOINTMENT_MOBILE_LOGIN ? ' (to login)':' (optional)') . '" name="' . $plugin . '_mobile" value="" ' . $m_params . '>';
					break;
				default:
					break;
					} // switch
				$$k = $v;
				} // foreach
			$user_passwd = Ccms_html::set_JS_password_input($plugin . '_passwd','Password to login','',self::$use_strong_passwds,false,false,'required');
			} // else

		$modal_text =<<<EOTDLG
				
		<style>
			div.dlg,
			div.dlg table,
			div.dlg tr,
			div.dlg td { /* turn off borders */
				border: 0;
				}
			div.dlg .label {
				text-align: right;
				padding-right: 5px;
				}
			div.dlg td,
			div.dlg input {
				text-align: left;
				}
			div.dlg textarea,
			div.dlg input {
				width: 98%;
				}
			label.top_note {
				font-weight: 600;
				}
		</style>

		<div id="id_{$n_i}_div" class="dlg">
			<table class="{$appo_class}">
				<tr class="{$appo_class}">
					<td class="{$appo_class}" colspan="2">
						<label class="{$appo_class} top_note">{$note_top}</label>
					</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Name:</label></td>
					<td class="{$appo_class}">{$user_name}</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Email:</label></td>
					<td class="{$appo_class}">{$user_email}</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Mobile:</label></td>
					<td class="{$appo_class}">{$user_mobile}</td>
				</tr>
				<tr class="{$appo_class}" style="display: {$disp_state};">
					<td class="{$appo_class} label"><label class="{$appo_class}">Password:</label></td>
					<td class="{$appo_class}">{$user_passwd}</td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class} label"><label class="{$appo_class}">Message:</label></td>
					<td class="{$appo_class}"><textarea name="{$plugin}_message" placeholder="Enter any questions or comments you may have."></textarea></td>
				</tr>
				<tr class="{$appo_class}">
					<td class="{$appo_class}" colspan="2" style="text-align: center;">
						<label class="{$appo_class}"><button name="{$plugin}_save" value="save" onclick="submit_{$n_i}_form('id_{$n_i}_div');" title="Request a booking for this appointment.">Book It</button></label>
						<label class="{$appo_class}"><button onclick="{$n_i}_close_modal();">Close</button></label>
						{$notes}
					</td>
				</tr>
			</table>
		</div>
EOTDLG;

		$modal_text .= <<<EOTJS

		<script  type="text/javascript">
			var {$n_i}_form = false;
			function check_elem_validity(elem) {	// because there is no submit element
				if(elem.checkValidity()) return true;
				elem.style.border = '2px solid red';			
				return false;
				} // check_elem_validity()
			function submit_{$n_i}_form(dlg_id) {
				if(!{$n_i}_form) {
					console.log('ERROR: Dialog parent bookit form not found.');
					return false;
					} // if
				var dlg = document.getElementById(dlg_id);
				if(!dlg) {
					console.log('ERROR: Dialog ID: dlg_id not found.');
					return false;
					} // if

				// add dlg inputs to form
				let inps = dlg.getElementsByTagName('input');
				var ok = true;
				if(inps) for (let i = 0; i < inps.length; i++) {
					let inp = inps[i];
					if(!check_elem_validity(inp)) ok = false;
					var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", inp.name);
					input.setAttribute("value", inp.value);
					{$n_i}_form.appendChild(input);	//append to form element that you want .
					} // for

				// add dlg textareas to form
				let txts = dlg.getElementsByTagName('textarea');
				if(txts) for (let i = 0; i < txts.length; i++) {
					txt = txts[i];
					if(!check_elem_validity(txt)) ok = false;
					var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", txt.name);
					input.setAttribute("value", txt.value);
					{$n_i}_form.appendChild(input);	//append to form element that you want .
					} // for

				// add dlg buttons to form
				let btns = dlg.getElementsByTagName('button');
				if(btns) for (let i = 0; i < btns.length; i++) {
					btn = btns[i];
					if((!btn.name) || (!btn.value)) continue;
					var input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", btn.name);
					input.setAttribute("value", btn.value);
					{$n_i}_form.appendChild(input);	//append to form element that you want .
					} // for
				if(!ok) return false;
				{$n_i}_form.submit();
				return true;
				} // submit_{$n_i}_form()

		</script>

EOTJS;

		$id = 'bookit';
		$name = 'APPO';
		$header = '';	// if you provide a header, it is assumed to the complete dialog header.	
		$h1 = (((int)$user_id <= 0) ? 'Guest ':'') . 'Appointment Calendar';
		$footer = '';

		$cModal = new Ccms_modal();
		$text = $cModal->get_modal($id, $modal_text, $appo_class, $h1, $header, $footer, $name);
		$dlg_name = $cModal->get_name();
		return $text;
		} // get_clnt_bookit_form_modal()

	 public function get_clnt_horizontal_slot_selectors($appo_class,$user_id = false, $use_ssl = true) {
		if(($use_ssl) && (!self::is_ssl_inuse())) {
			self::addAdminMsg('Call to ' . __CLASS__ . '::' . __METHOD__ . ' while not using a secure connection.');
			return '';
			} // if
		if(empty($user_id)) {	// not logged
			$user_id = 0;
			} // if
		$plugin = self::PLUGIN;
		$midnight = strtotime("today 00:00");
		$now = strtotime('today');
		$today = getdate($midnight);	// array
		$strt_dow = $today['wday'];
		// $start_time = $midnight - (($strt_dow + self::DAY_STRT_INC) * self::SECS_DAY);
		// $end_time = $start_time + (self::SECS_DAY * self::DAY_FNSH_INC);
		$start_time = $midnight;
		$end_time = $start_time + (self::SECS_DAY * self::DAY_FNSH_INC);

		$col_heads = self::get_slots_col_heads();
		$col_max = count($col_heads);
		$row_heads = self::get_slots_row_heads();
		$row_max = PL_CMS_APPOINTMENT_SLOTS_PER_DAY;
		
		$dlg_name = false;	// for ref
		$text = array();
		$text[] = self::get_appo_styles();
		$text[] = self::get_appo_js();

		$text[] = $this->get_clnt_bookit_form_modal($appo_class,$dlg_name,$user_id);
		$text[] = <<<EOTJSBK

	<script  type="text/javascript">
		function cms_appo_bookit_submit(form,event,slot_id,user_id,appointment_start,appointment_finish) {
			var dlg_id = 'id_{$dlg_name}_container';
			var dlg = document.getElementById(dlg_id);
			if(!dlg) {
				console.log('ERROR: Dialog {$dlg_name} not found.');
				return false;
				} // if
			{$dlg_name}_open_modal();
			{$dlg_name}_form = form;
			let inps = [
				{'id': 'id_{$plugin}_from', 'type': 'span', 'value': appointment_start,},
				{'id': 'id_{$plugin}_to','type': 'span', 'value': appointment_finish,},
				];
			for(let i = 0; i < inps.length; i++) {
				let inp = inps[i];
				var elem = document.getElementById(inp['id']);
				if(!elem) {
					console.log('Elem id: ' + inp['id'] + ' not found.');
					continue;
					} // if
				switch(inp['type']) {
				// only spans atm
				case 'span':
				default:
					elem.innerHTML = inp['value'];
					break;				
					} // switch
				} // for
//			var from = document.getElementById('id_{$plugin}_from');
//			if(from) from.innerHTML = appointment_start;
//			var to = document.getElementById('id_{$plugin}_to');
//			if(to) to.innerHTML = appointment_finish;
			return true;
			} // cms_appo_bookit_submit()
	</script>
EOTJSBK;

		$text[] = '<div class="cms_appo_h_scroll_box">';
		$text[] = '		<table id="slot_select" class="' . $appo_class . ' cms_appo">';

		// if(self::is_debug())
		// put up week heading
		$text[] = '		<tr class="' . $appo_class . '">';
		for($day_time = $start_time,$c = $strt_dow; $day_time < $end_time; $day_time += self::SECS_DAY,$c++) {
			if($day_time < $now) {
				$text[] = '			<th class="' . $appo_class . ' ' . 
								(($c & 1) ? '' . $appo_class . '_odd':'' . $appo_class . '_even') . ' cms_appo_na" style="text-align: center;">' . date('l',$day_time) . '<br>' . $this->fmt_datetime($day_time, 'd M') . '</th>';
				} // if
			else {
				$text[] = '			<th class="' . $appo_class . ' ' . 
								(($c & 1) ? '' . $appo_class . '_odd':'' . $appo_class . '_even') . ' cms_appo_available" style="text-align: center;">' . date('l',$day_time) . '<br>' . $this->fmt_datetime($day_time, 'd M') . '</th>';
				} // else
			} // for
		$text[] = '		</tr>';

		// put up booking slots
		$grid = self::unserialize_string2arry(PL_CMS_APPOINTMENT_TIME_SLOTS);	// contains offsets from midnight for each eweekday
		$booked = $this->get_appointments($start_time, $end_time);
		for($r = 0; $r < $row_max; $r++) {
			$text[] = '		<tr class="' . $appo_class . '">';
			for($day_time = $start_time,$c = $strt_dow; $day_time < $end_time; $day_time += self::SECS_DAY,$c++) {

				if(!empty($grid[($c % self::DAYS_WEEK)][$r])) {	// ok
					$grc = &$grid[($c % self::DAYS_WEEK)][$r];
					$s_strt = (int)$grc['strt'];
					$s_end = (int)$grc['end'];

					if(((int)$s_strt > 0) && ((int)$s_end > 0) && // check if slot is used
						(($s_strt + self::TIME_INC) <= $s_end)) {	// check for no slot config  errors

						$past = (($day_time + $s_strt) < time()) ? true:false;
						$avail = ($past ? false:true);
						$start = ($day_time + $s_strt);
						$finish = ($day_time + $s_end);

						// find reserved slots
						$appointment = array_filter($booked, function($d) use ($start,$finish) {	// find unused keys
							if(($d['strt_time'] >= $start) && ($d['strt_time'] <= $finish)) return true;
							if(($d['end_time'] >= $start) && ($d['end_time'] <= $finish)) return true;
							if(($start >= $d['strt_time']) && ($start <= $d['end_time'])) return true;
							if(($finish >= $d['strt_time']) && ($finish <= $d['end_time'])) return true;
							return false;
							});
						$reserved = array_shift($appointment);

						$time_start = $this->fmt_datetime($start,'l M jS, g:ia');
						$time_finish = $this->fmt_datetime($finish,'l M jS, g:ia');
						$h_m_strt = self::fmt_hours_minutes($s_strt);
						$h_m_end = self::fmt_hours_minutes($s_end);
						
						$slot_id = 'id_dlg_slot[' . $r . '][' . $c . ']';
						$text[] = '			<td id="' . $slot_id . '" class="' .
								(($c & 1) ? '' . $appo_class . '_odd':'' . $appo_class . '_even') . (!$avail ? ' cms_appo_na':' cms_appo_available') . '"' .
								(($avail) && (!$reserved) ? ' title="Click to book this time."':'') . '>';
						// $text[] = '				<div id="' . $slot_id . '">';

						if(($avail) && (!$reserved)) {
							$text[] = '					<form action="' . Ccms::get_body_uri() . '" method="post"' .
								' onclick="cms_appo_bookit_submit(this,event,\'' . $slot_id . '\',\'' . $user_id . '\',\'' . $time_start . '\',\'' . $time_finish . '\');">' .
								' <input type="hidden" name="' . self::PLUGIN . '_form" value="bookit_form">' .
								' <input type="hidden" name="' . self::PLUGIN . '_user_id" value="' . $user_id . '">' .
								' <input type="hidden" name="' . self::PLUGIN . '_start" value="' . $start . '">' .
								' <input type="hidden" name="' . self::PLUGIN . '_finish" value="' . $finish . '">';
							} // if

						if($reserved) {
							if($reserved['user_id'] == $user_id) {
								$status = 'Booked by you.';
								} // if								
							else $status = 'Reserved';
							} // if
						else if($avail) $status = 'Available';
						else $status = 'N.A.';
						$text[] = '				' . $h_m_strt . '<br>' .
								(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? 'to<br>' . $h_m_end . '<br>':'') . $status;
						if(($avail) && (!$reserved))
							$text[] = '				</form>';
						
						// $text[] = '				</div>';
						$text[] = '			</td>';
						} // if
					else $text[] = '			<td>&nbsp;</td>';
					} //if
				else $text[] = '			<td>&nbsp;</td>';
				} // for
			$text[] = '		</tr>';
			} // for
		$text[] = '		</table>';
		$text[] ='	</div>';

		$txt = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		return $txt;
		} // get_clnt_horizontal_slot_selectors()
	
	public function get_horizontal_slot_selectors($appo_class,$user_id = false, $use_ssl = true) {
		if($this->is_appo_manager($user_id))
			$text[] = $this->get_mngr_horizontal_slot_selectors($appo_class, $user_id);
		else 
			$text[] = $this->get_clnt_horizontal_slot_selectors($appo_class,$user_id);
		$txt = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		return $txt;
		} // get_horizontal_slot_selectors()

	protected function is_sms_ok() {
		if(!PL_CMS_APPOINTMENT_SMS_NOTIFY) return false;
		if(!Ccms_sms_plugin::is_enabled()) return false;
		return true;
		} // send_sms_msg()
		
	protected function send_sms_msg($sms_mobile_number,$sms_message) {
		if(!$this->is_sms_ok()) return false;
		$pl = new Ccms_sms_plugin();
		if($pl->send_sms_msg($sms_mobile_number, $sms_message)) {
			self::addAdminMsg('Send SMS Message: ' . $sms_message . ' - Sent to: ' . $sms_mobile_number,'success');
			return true;
			} // if
		return false;
		} // send_sms_msg()
		
	protected function get_sms_replies() {
		if(!$this->is_sms_ok()) return false;
		$pl = new Ccms_sms_plugin();
		if($replies = $pl->get_sms_replies()) {
			self::addAdminMsg('Received ' . count($replies) . ' SMS Replies.','success');
			return $replies;
			} // if
		return [];
		} // get_sms_replies()
		
	protected function get_iCal_event($message,$start,$finish) {
		$iCal_path = CMS_FS_LIB_DIR . 'ics/ICS.php';
		$iCal_class = 'ICS';
		if((!is_file($iCal_path)) && (!is_readable($iCal_path))) return '';
		require_once($iCal_path);
		if(!class_exists($iCal_class))return '';
		
		$properties = array(
			'description' => 'Appiontment with ' . CMS_C_CO_NAME,
			'dtend' => $this->fmt_datetime($start),
			'dtstart' => $this->fmt_datetime($start),
			'location' => PL_CMS_APPOINTMENTS_LOCATION,
			'summary' => $message,
			'url' => Ccms::get_body_uri(),
			);
		$ics = new ICS($properties);
		$ics_file_contents = $ics->to_string();
		return $ics_file_contents;	
		} // get_iCal_event()
		
	protected function email_booking_mngr_request($from_name,$from_address,$mobile,$message,$start,$finish) {
		if(!empty(PL_CMS_APPOINTMENT_MNGR_EMAIL)) {	// email manager
			if(!Ccms_email_plugin::is_enabled()) {	// dependancy
				self::addAdminMsg(self::PLUGIN . ' plugin needs the email plugin.','warning','CMS_C_ENABLED_PLUGINS');
				return false;
				} // if
			$email_text = '';
			$email_text .= $from_name . ' has requested an appointment from ' . self::fmt_datetime($start) . 
									(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? ' to ' . self::fmt_datetime($finish):'') . '<br>';
			$email_text .= (!empty($mobile) ? '<br>Mobile: ' . $mobile:'');
			$email_text .= '<br>Email: ' . $from_address;
			$email_text .= (!empty($message) ? '<br>Message:<br>' . $message:'<br>No message.') . '<br>';

			$to_name = 'Appointment Manager';
			$to_address = PL_CMS_APPOINTMENT_MNGR_EMAIL;
			$email_subject = CMS_C_CO_NAME . ' - Appointment Request to Manager.';
			if(!Ccms_email_plugin::send_out_mail(
				$to_name,
				$to_address,
				$email_text,
				$email_subject,
				$from_name,
				$from_address)) {
				self::addAdminMsg('Failed to send appointment request to manager to email: "' . $to_address . '".');
				return false;
				} // if
			} // if
		return true;
		} // email_booking_mngr_request()

	protected function sms_booking_mngr_request($name,$email,$mobile,$message,$start,$finish) {
		if(!PL_CMS_APPOINTMENT_SMS_NOTIFY) return true;
		if(!empty(PL_CMS_APPOINTMENT_MNGR_SMS)) {	// email manager
			if(!Ccms_sms_plugin::is_enabled()) {	// dependancy
				self::addAdminMsg(self::PLUGIN . ' plugin needs the sms plugin.','error');
				return false;
				} // if
			$sms_text = '';	// keep inside 160 characters
			$sms_text .= CMS_C_CO_NAME . ' - Appointment Request.' . PHP_EOL;
			$sms_text .= $name . ' from ' . self::fmt_datetime($start) . 
									(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? ' to ' . self::fmt_datetime($finish):'') . PHP_EOL;
			$sms_text .= (!empty($mobile) ? PHP_EOL . 'Mobile: ' . $mobile:'');
			$sms_text .= PHP_EOL . 'Email: ' . $email;
			if(!empty($message)) $sms_text .= PHP_EOL . $message;

			$sms = new Ccms_sms_plugin();
			if(!$sms->send_sms_msg(PL_CMS_APPOINTMENT_MNGR_SMS, $sms_text)) {
				self::addAdminMsg('Failed to send appointment request to manager to SMS: "' . $mobile . '".');
				return false;
				} // if
			} // if
		return true;
		} // sms_booking_mngr_request()

	public function book_appointment($user_id = false) {
		if((!$op =  self::get_or_post_str(self::PLUGIN . "_form")) || 
			($op != 'bookit_form') ||
			(!$start = self::get_or_post_str(self::PLUGIN . "_start")) ||
			(!$finish = self::get_or_post_str(self::PLUGIN . "_finish"))) {
			return true;	// not making a booking
			} // if
		if(!$user_id) $user_id = self::get_or_post(self::PLUGIN . "_user_id");
		if(empty($user_id)) return false;
		
		if(self::get_or_post_str(self::PLUGIN . "_save") == 'save') {

			$message = self::get_or_post_str(self::PLUGIN . "_message");

			$user_details = $this->get_user_details($user_id);
			$name = $user_details['user_name'];
			$email = $user_details['user_email'];
			$mobile = $user_details['user_mobile'];

			$ok = true;
			if(!$this->email_booking_mngr_request($name, $email, $mobile, $message, $start, $finish)) {
				self::addAdminMsg('Failed to email booking manager request: ' . $email);
				$ok = false;
				} // if
			if(!$this->sms_booking_mngr_request($name,$email,$mobile,$message,$start,$finish)) {
				self::addAdminMsg('SMS failed to notify booking manager request: ' . $mobile);
				$ok = false;
				} // if
			if(($ok) && ($this->save_appointment($user_id, $name, $email, $mobile, $message, $start, $finish))) {
			self::addMsg('Appointment requested,','success');
				return true;
				} // if
			self::addAdminMsg('Failed to save appointment for user_id: ' . $user_id);
			return false;
			} // if
		return false;
		} // book_appointment()

	public function manage_appointment() {
		if((!$op =  self::get_or_post_str(self::PLUGIN . "_form")) || 
			($op != 'admin_form') ||
			(!$start = self::get_or_post_str(self::PLUGIN . "_start")) ||
			((PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME) && (!$finish = self::get_or_post_str(self::PLUGIN . "_finish")))) {
			return true;	// not making a booking
			} // if
		$user_inps = $this->get_user_details_input(true);
		if(empty($user_inps)) {
			self::addMsg('Did not receive enough information to manage appointment.');
			return false;
			} // if
		if(self::get_or_post_str(self::PLUGIN . "_delete") == 'delete') {
			$appo_id = self::get_or_post_str(self::PLUGIN . "_appo_id");
			if(!$this->cDBappo->set_data_in_table('appointments', 'appointment_deleted', 1, 'appointment_id = ' . $appo_id)) {
				self::addMsg('Failed to delete appointment for: ' . $user_inps['name'] . ', id: ' . $appo_id);
				return false;
				} // if
			self::addMsg('Deleted appointment for: ' . $user_inps['name'] . ', id: ' . $appo_id,'success');
			return true;
			} // if
		else if(self::get_or_post_str(self::PLUGIN . "_save") == 'save') {	// mngr making an appo
			
			$user_id = $this->cDBappo->get_data_in_table('regd_users', 'user_id', 'user_email = \'' . $user_inps['email'] . '\'' . 
				(PL_CMS_APPOINTMENT_MOBILE_LOGIN ? ' OR user_mobile = \'' . $user_inps['mobile'] . '\'':''));
			$message = self::get_or_post_str(self::PLUGIN . "_message");
			$comments = self::get_or_post_str(self::PLUGIN . "_comments");
			$requested = self::get_or_post_checkbox(self::PLUGIN . "_requested");
			$confirmed = self::get_or_post_checkbox(self::PLUGIN . "_confirmed");

			$fields = [
				"user_id" => (!empty($user_id) ? $user_id:self::GUEST_USER_ID),
				"user_name" => $user_inps['name'],
				"user_email" => $user_inps['email'],
				"user_mobile" => $user_inps['mobile'],
				"appointment_start" => $start,
				"appointment_finish" => (PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? $finish:0),
				"appointment_message" => $message,
				"appointment_requested" => $requested,
				"appointment_confirmed" => $confirmed,
				"appointment_comments" => $comments,
				];
			if(!$this->cDBappo->perform('appointments', $fields)) {	// insert new appo
				self::addAdminMsg('Failed to add guest user: ' . $user_inps['name'] . ', to appointments table.');
				return false;
				} // if
			self::addAdminMsg('Added guest appointment: ' . $user_inps['name']. ', to appointments table.','success');
			// @TODO notify client
			return true;
			} // else if
		else if(self::get_or_post_str(self::PLUGIN . "_update") == 'update') {

			$user_id = self::get_or_post(self::PLUGIN . "_user_id");
			$appo_id = self::get_or_post(self::PLUGIN . "_appo_id");
			$message = self::get_or_post_str(self::PLUGIN . "_message");
			$comments = self::get_or_post_str(self::PLUGIN . "_comments");
			$requested = self::get_or_post_checkbox(self::PLUGIN . "_requested");
			$confirmed = self::get_or_post_checkbox(self::PLUGIN . "_confirmed");

			$fields = [
				"user_id" => (!empty($user_inps['user_id']) ? $user_inps['user_id']:self::GUEST_USER_ID),
				"user_name" => $user_inps['name'],
				"user_email" => $user_inps['email'],
				"user_mobile" => $user_inps['mobile'],
				"appointment_start" => $start,
				"appointment_finish" => (PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? $finish:0),
				"appointment_message" => $message,
				"appointment_requested" => $requested,
				"appointment_confirmed" => $confirmed,
				"appointment_comments" => $comments,
				];
			if(empty($appo_id)) { // new manager appointment
				if(!$this->cDBappo->perform('appointments', $fields)) {	// insert new appo
					self::addAdminMsg('Failed to add guest user: ' . $user_inps['name'] . ', to appointments table.');
					return false;
					} // if
				self::addAdminMsg('Added guest user: ' . $user_inps['name']. ', to appointments table.','success');
				$appo_id = $this->cDBappo->insert_id();
				} // if
			else {	// a managed appointment
				if(!$this->cDBappo->perform('appointments', $fields,'update','appointment_id = ' . (int)$appo_id)) {
					self::addAdminMsg('Failed to update for user: ' . $user_inps['name'] . ', to appointments table.');
					return false;
					} // if
				self::addAdminMsg('Updated user: ' . $user_inps['name']. ', to appointments table.','success');
				} // else
			// @TODO notify client
			return true;
			} // else if
		return false;
		} // manage_appointment()

	protected function get_appointments($from, $to) {
		if($query_res = $this->cDBappo->query(
				"SELECT * FROM appointments WHERE appointment_deleted = 0 AND appointment_start >= " . $from . " AND appointment_finish <= " . $to . "")) {
			$res = [];
			while ($r = $this->cDBappo->fetch_array($query_res)) {
				$res[] = [
					'appo_id' => $r['appointment_id'],
					'strt_time' => $r["appointment_start"],
					'end_time' => $r["appointment_finish"],
					'message' => $r["appointment_message"],
					'strt_date' => $this->fmt_datetime($r["appointment_start"]),
					'end_date' => $this->fmt_datetime($r["appointment_finish"]),
					'user_id' => $r["user_id"],
					'requested' => $r['appointment_requested'],
					'confirmed' => $r['appointment_confirmed'],
					'comments' => $r['appointment_comments'],
					];
				} // while
			return $res;
			} // if
		return false;
		} // get_appointments()

	protected function save_appointment($user_id, $name, $email, $mobile, $message, $start, $finish) {
		$min = strtotime("+" . self::DAY_STRT_INC . " day");
		$max = strtotime("+" . self::DAY_FNSH_INC . " day");
		$day_time = $start;	// strtotime($start);
		if(($day_time < $min) || ($day_time > $max)) {
			self::addAdminMsg("Save failed: Date must be between " . $this->fmt_datetime($min) . " and " . $this->fmt_datetime($max));
			return false;
			} // if

		if(($query_result = $this->cDBappo->query("SELECT * FROM appointments WHERE appointment_start = " . $start . " AND appointment_finish = " . $finish . "")) &&
			(is_array($this->cDBappo->fetch_array($query_result)))) {
			self::addAdminMsg("Slot: " . $this->fmt_datetime($start) . " to " . $this->fmt_datetime($finish) . " already taken");
			return false;
			} // if

		if(!$query_result = $this->cDBappo->query("INSERT INTO appointments (appointment_start, appointment_finish, appointment_message, appointment_requested, user_id)" .
				  " VALUES ('" . $start . "','" . $finish . "','" . $message . "','1','" . $user_id . "')")) {
			self::addAdminMsg('Failed to create slot.');
			return false;
			} // if
		return true;
		} // save_appointment()

	protected function get_appointment_details($appo_id) {
		if((int)$appo_id <= 0) return false;
		if(!empty($this->appointment_details[$appo_id])) return $this->appointment_details[$appo_id];	// time saver
		if(($query_res = $this->cDBappo->query(
				"SELECT * FROM appointments WHERE appointment_id = " . (int)$appo_id)) &&
			($this->appointment_details[$appo_id] =  $this->cDBappo->fetch_array($query_res))) {
			return $this->appointment_details[$appo_id];
			} // if
		return false;
		} // get_appointment_details()
		
	public function get_user_details($user_id = false) {
		if((int)$user_id <= 0) $user_id = self::get_cms_sess_var(self::PLUGIN, 'user_id');
		if((int)$user_id <= 0) return false;
		if(!empty($this->user_details[$user_id])) return $this->user_details[$user_id];	// time saver
		if(($query_res = $this->cDBappo->query(
				"SELECT * FROM regd_users WHERE user_id = " . (int)$user_id . " AND user_enabled > 0 LIMIT 1")) &&
			($this->user_details[$user_id] =  $this->cDBappo->fetch_array($query_res))) {
			$this->user_details[$user_id]['timed_out'] = (($this->user_details[$user_id]['user_last_login'] < (time() - self::LOGIN_TIMEOUT)) ? true:false);
			return $this->user_details[$user_id];
			} // if
		return false;
		} // get_user_details()
		
	public function get_appointment_dialogs($appo_class,$user_id) {
		// if($this->is_appo_manager($user_id)) return '';	// manager ?)
		$text = array();
		if(empty($user_id)) {
			$text[] = '<div class="appo_panel">';
			$text[] = ' <div class="' . $appo_class . ' appo_row" style="justify-content: center; display: flex;">';
			$text[] = '		<div class="' . $appo_class . ' appo_column">' . $this->get_login_form($appo_class) . '</div>';
			$text[] = '		<div class="' . $appo_class . ' appo_column">' . '&nbsp;' . '</div>';	// spacer (margin style doesn't work)
			$text[] = '		<div class="' . $appo_class . ' appo_column">' . $this->get_register_form($appo_class) . '</div>';
			$text[] = '	</div>';
			$text[] = '</div>';
			} // if
		else {
			$text[] = '<div class="appo_panel">';
			$text[] = '	<div class="' . $appo_class . ' appo_row" style="justify-content: center; display: flex;">';
			$text[] = '		<div class="' . $appo_class . ' appo_column">' . $this->get_chg_user_details_form($appo_class,$user_id) . '</div>';
			$text[] = '		<div class="' . $appo_class . ' appo_column">' . '&nbsp;' . '</div>';	// spacer (margin style doesn't work)
			$text[] = '		<div class="' . $appo_class . ' appo_column">' . $this->get_logout_form($appo_class,$user_id) . '</div>';
			$text[] = '	</div>';
			$text[] = '</div>';
			} // else
		$txt = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		return $txt;
		} // get_appointment_dialogs()

	public function get_appointment_panel($appo_class = false) {

		if(!$this->is_ok()) return '';
		if(!empty($appo_class)) $this->appo_class = $appo_class;
		if(empty($this->appo_class)) $this->appo_class = 'page_body';	// 'page_database';


		$text = array();
		$text[] = self::get_appo_styles();
		$text[] = self::get_appo_js();

		if($this->logout_appo_user()) $user_id = false;
		if((!$user_id = $this->login_appo_user()) &&	// try login
			(!$user_id = $this->register_appo_user())) {	// then try to register
			$user_id = $this->get_sess_logged_in_user_id();	// already logged in 
			} // if
		if($html = $this->get_verification_codes_form($user_id)) {
			$text[] = $html;
			} // if
		else {	// normal
			$this->upd_appo_user_details($user_id);
			$this->book_appointment($user_id);
			$this->manage_appointment();

			$text[] = $this->get_welcome($this->appo_class,$user_id);

			if(PL_CMS_APPOINTMENT_DLGS_POSITION == 'above') {
				$text[] = $this->get_appointment_dialogs($this->appo_class,$user_id);
				} // if

			$text[] = $this->get_horizontal_slot_selectors($this->appo_class, $user_id);

			if(PL_CMS_APPOINTMENT_DLGS_POSITION != 'above') {
				$text[] = $this->get_appointment_dialogs($this->appo_class,$user_id);
				} // if
			} // else
		$txt = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		return $txt;
		} // get_appointment_panel()

// admin and config
	public static function get_SQLite_install_script() {	// the appointment data base
		return array(
			'regd_users' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'id' => 'user_id',	// row id column (optional)
				'asc' => 'user_name',	// ASC sort column (optional)
				'columns' => array(
					"user_id" => "INTEGER PRIMARY KEY AUTOINCREMENT",	// the row id
					"user_added" => "DATETIME",		// date and time the row was added
					"user_updated" => "DATETIME DEFAULT 0",		// date and time the row was updated
					"user_name" => "VARCHAR(128) NOT NULL",		// the user name
					"user_email" => "TEXT UNIQUE DEFAULT NULL",			// the user email
					"user_email_confirmed" => "BOOLEAN DEFAULT 0",			// the user email confirmation
					"user_mobile" => "TEXT UNIQUE DEFAULT NULL",			// the user mobile phone number
					"user_mobile_confirmed" => "BOOLEAN DEFAULT 0",			// the user mobile phone number confirmation
					"user_password_md5" => "VARCHAR(128) NOT NULL",
					"user_enabled" => "BOOLEAN DEFAULT 1",
					"user_last_login" => "DATETIME DEFAULT 0",		// time off last login
					"user_comments" => "TEXT DEFAULT ''",
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_regd_users" => "CREATE TRIGGER InsertTrigger_regd_users AFTER INSERT ON regd_users" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE regd_users SET user_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_regd_users" => "CREATE TRIGGER UpdateTrigger_regd_users AFTER UPDATE ON regd_users" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE regd_users SET user_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
//				'data' => array(	// in the same order as the columns
//					array(	// row data
//						"1",	// user_id
//						"DATETIME('NOW')",	// user_added
//						"0",	// user_updated
//						"'" . CMS_DEFAULT_ADMIN . "'",	// user_name
//						"'admin@appscms.org'",	// user_email
//						"'0400 000 000'",	// user_mobile
//						"'" . md5(CMS_DEFAULT_PASSWORD) . "'",	// user_password_md5
//						"1",	// user_enabled
//						"0",	// user_last_login
//						"'Default user'",	// user_comments
//						),
//					),
				),
			'appointments' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'id' => 'ppointment_id',	// row id column (optional)
				'asc' => 'appo_date,appo_slot',	// ASC sort column (optional)
				'columns' => array(
					"appointment_id" => "INTEGER PRIMARY KEY AUTOINCREMENT",	// the row id
					"appointment_added" => "DATETIME",		// date and time the row was added
					"appointment_updated" => "DATETIME DEFAULT 0",		// date and time the row was updated
					"user_id" => "INTEGER NOT NULL",	// the users row id
					"user_name" => "VARCHAR(128) DEFAULT ''",		// the user name used when appointment was booked
					"user_email" => "TEXT DEFAULT ''",	// the user email used to find user when appointment was booked
					"user_mobile" => "TEXT DEFAULT ''",	// the user mobile phone number used when appointment was booked
					"appointment_start" => "INTEGER NOT NULL",
					"appointment_finish" => "INTEGER NOT NULL",
					"appointment_message" => "TEXT DEFAULT ''",	// user message
					"appointment_requested" => "BOOLEAN DEFAULT 0",
					"appointment_confirmed" => "BOOLEAN DEFAULT 0",
					"appointment_completed" => "BOOLEAN DEFAULT 0",
					"appointment_deleted" => "BOOLEAN DEFAULT 0",
					"appointment_comments" => "TEXT DEFAULT ''",	// manager comments
					),
				'key_column' => '',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_appointments" => "CREATE TRIGGER InsertTrigger_appointments AFTER INSERT ON appointments" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE appointments SET appointment_added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_appointments" => "CREATE TRIGGER UpdateTrigger_appointments AFTER UPDATE ON appointments" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE appointments SET appointment_updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				),
			);
		} // get_SQLite_install_script()

	protected static function get_slots_col_heads() {
		// make $col_heads
		$col_heads = array('','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
		return $col_heads;
		} // get_slots_col_heads()

	protected static function get_slots_row_heads() {
		$row_heads = array();
		for($i = 0; $i < PL_CMS_APPOINTMENT_SLOTS_PER_DAY; $i++) $row_heads[] = 'Slot ' . ($i + 1);
		return $row_heads;
		} // get_slots_row_heads()

	public static function show_slot_grid($value,$col_heads) {	// the $value maybe a mess
		$text = array();
		$text[] = '<table class="page_config">';
		if((!empty($value)) &&
			($grid = self::unserialize_string2arry($value)) &&
			(!empty($grid))) {
			$col_heads = self::get_slots_col_heads();
			$col_max = count($col_heads);
			$row_heads = self::get_slots_row_heads();
			$row_max = PL_CMS_APPOINTMENT_SLOTS_PER_DAY;

			$text[] = '	<tr class="page_config">';
			for($c = 0; $c < $col_max; $c++) {
				$text[] = '		<th class="page_config" style="text-align: center; word-wrap: normal;">' . $col_heads[$c] . '</th>';
				} // for
			$text[] = '	</tr>';
			for($r = 0; $r < $row_max; $r++) {
				$text[] = '	<tr class="' . (($r & 1) ? 'page_config_odd':'page_config_even') . '">';
				$text[] = '		<th class="page_config" style="word-wrap: normal;">' . $row_heads[$r] . '</th>';
				for($c = 1; $c < $col_max; $c++) {
					$text[] = '		<td class="page_config" style="word-wrap: normal;">';
					if(!empty($grid[($c - 1)][$r])) {	// ok
						$grc = &$grid[($c - 1)][$r];
						$s_strt = (int)$grc['strt'];
						$s_end = (int)$grc['end'];
						if(($s_strt > 0) && ($s_strt < $s_end)) {
							$h_m_strt = self::fmt_hours_minutes($s_strt);
							if(!PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME)
								$text[] = '			' . $h_m_strt ;
							else {
								$h_m_end = self::fmt_hours_minutes($s_end);
								$text[] = '			' . $h_m_strt . ' =&gt; ' . $h_m_end;
								} // else
							} // if
						else $text[] = '			(N.A.)';
						} //if
					$text[] = '</td>';
					} // for
				$text[] = '	</tr>';
				} // for
			$text[] = '	<tr class="page_config"><td class="page_config" colspan="8" style="word-wrap: normal; white-space: nowrap;"><b>Note:</b> ' .
				(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? 'Using both start and finish times':'Using only the start times') . ' to book appointments.' .
				'</td></tr>';
			} // if
		else $text[] = '<tr class="page_config"><td class="page_config">(No values set)</td></tr>';
		$text[] = '</table>';

		return implode(PHP_EOL,$text) . PHP_EOL;
		} // show_slot_grid()

	public static function input_slot_grid($name,$value,$col_heads) {
		// @TODO change the weekdays to columns by day of week
		$grid = array();
		if(!empty($value)) {
			if(!is_array($value)) $grid = self::unserialize_string2arry($value);
			else $grid = $value;
			} // if
		if((!$grid) || (!is_array($grid))) $grid = array();	// empty
		else $grid = self::clean_array($grid,false);	// clean out dead rows

		$col_heads = self::get_slots_col_heads();
		$col_max = count($col_heads);
		$row_heads = self::get_slots_row_heads();
		$row_max = PL_CMS_APPOINTMENT_SLOTS_PER_DAY;
		$cCnf = new Ccms_config_funcs();
		$allowed_values = PL_CMS_APPOINTMENT_DAILY_START_TIME . ':' . self::TIME_INC . ':' . PL_CMS_APPOINTMENT_DAILY_FINISH_TIME;

		$text = array();
		$text[] = '	<table class="page_config" >';

		// put day of week as heading row
		$text[] = '		<tr class="page_config">';
		for($c = 0; $c < $col_max; $c++) {
			$text[] = '		<th class="page_config" style="text-align: center; white-space: nowrap;">' . $col_heads[$c] . '</th>';
			} // for
		$text[] = '</tr>';

		for($r = 0; $r < $row_max; $r++) {
			$text[] = '		<tr class="' . (($r & 1) ? 'page_config_odd':'page_config_even') . '">';
			$text[] = '			<th class="page_config" style="white-space: nowrap;">' . $row_heads[$r] . '</th>';
			for($c = 0; $c < ($col_max - 1); $c++) {
				$text[] = '			<td class="page_config" style="white-space: nowrap;">';
				$nam = $name . '[' . $c . '][' . $r . '][wday]';
				$text[] = '				<input type="hidden" name="' . $nam . '" value="' . $col_heads[($c + 1)] . '"></th>';
				// $text[] = 'C=' . $c . ', R=' .$r . '<br>';	// debug
				$val = $grid[$c][$r]['strt'];
				$nam = $name . '[' . $c . '][' . $r . '][strt]';
				$text[] = '				' .	$cCnf->select_time_of_day($nam,$val,$allowed_values);
				$text[] = '				=&gt;';
				$val = $grid[$c][$r]['end'];
				$nam = $name . '[' . $c . '][' . $r . '][end]';
				$text[] = '				' . $cCnf->select_time_of_day($nam,$val,$allowed_values);
				$text[] = '			</td>';
				} // for
			$text[] = '		</tr>';
			} // for
		$text[] = '		<tr class="page_config"><td class="page_config" colspan="8" style="word-wrap: normal; white-space: nowrap;"><b>Note:</b> ' .
				(PL_CMS_APPOINTMENT_SHOW_APPO_FINISH_TIME ? 'Showing both start and finish times':'Showing only the start times') . ' to book appointments.' .
				'</td></tr>';
		$text[] = '	</table>';
		return PH_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // input_slot_grid()

	public static function save_slot_grid($name,$value,$col_heads) {
		// return $value;	// test
		$grid = self::get_or_post_str($name);
		$text = '';
		if(!empty($grid)) $text = serialize($grid);
		return $text;
		} // save_slot_grid()

	public static function get_title() {	// get the plugin title
		return 'Appointments Calendar';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' appointments calendar plugin (' . self::PLUGIN . ') is an assistive plugin for appointment scheduling.<br>' .
				'The appointments calendar plugin uses a seperate database.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "WELCOME_MESSAGE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'Welcome to appointments calendar.',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Appointments Welcome Message.",
				'cms_config_description' => "Enter welcome message to display at the top of appointments panel.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "LOCATION",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => '',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Location of Appointments.",
				'cms_config_description' => "Enter the location address of appointments (if empty it is not used).",
				'cms_config_show_func' => 'show_map_address',
				'cms_config_input_func' => 'input_map_address',
				'cms_config_save_func' => 'save_map_address',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "MNGR_EMAIL",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => '',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Appointments Managers Email Address.",
				'cms_config_description' => "Enter the appointments managers email address.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => 'get_email',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "SMS_NOTIFY",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'true',
				'cms_config_allowed_values' => 'true:false',
				'cms_config_name' => "Appointments SMS Notification.",
				'cms_config_description' => "true = Use SMS notification (if the SMS plugin is enable and configured), false = SMS not used.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "MNGR_SMS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => '',
				'cms_config_allowed_values' => self::PHONE_NUMBER_MIN_MAX_PARAM,
				'cms_config_name' => "Appointments Manager SMS Mobile.",
				'cms_config_description' => "Enter the appointments managers notification SMS mobile telephone number.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_string',
				'cms_config_save_func' => 'get_mobile_number',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "MOBILE_LOGIN",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'true',
				'cms_config_allowed_values' => 'true:false',
				'cms_config_name' => "Allow Mobile Login.",
				'cms_config_description' => "true = login with mobile or email and password, false = login with email and password only.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "EMAIL_MOBILE_VERIFY",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'true',
				'cms_config_allowed_values' => 'true:false',
				'cms_config_name' => "Verify Email and Mobile.",
				'cms_config_description' => "true = verify mobile (if used for login) and email, false = not verified.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "TIME_SLOTS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => '',	//serialize([['Monday','09:00','12:00'],['Monday','13:30','16:00']]),
				'cms_config_allowed_values' => 'Weekday:Slot 1 Start =&gt; Finish:Slot 2 Start =&gt; Finish:Slot Start =&gt; Finish:Slot 4 Start =&gt; Finish',
				'cms_config_name' => "Weekly Appointments Slots.",
				'cms_config_description' => "Available appointment time slots for each weekday.<br>The slots can overlap.",
				'cms_config_show_func' => 'Ccms_appointments_plugin::show_slot_grid',
				'cms_config_input_func' => 'Ccms_appointments_plugin::input_slot_grid',
				'cms_config_save_func' => 'Ccms_appointments_plugin::save_slot_grid',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "DAILY_START_TIME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => (9 * 3600),	//seconds
				'cms_config_allowed_values' => '0:' . self::TIME_INC . ':' . self::SECS_DAY . '',	// start:seconds increment:finish
				'cms_config_name' => "Daily Appointments Start Time.",
				'cms_config_description' => "Daily start time for available appointments.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'select_time_of_day',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "SHOW_APPO_FINISH_TIME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'false',
				'cms_config_allowed_values' => 'true:false',
				'cms_config_name' => "Show Appointment Finish Times.",
				'cms_config_description' => "true = show the appointment finish for available appointments, false = show just the appointment start time.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "DLGS_POSITION",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'below',
				'cms_config_allowed_values' => 'above:below',
				'cms_config_name' => "Show Appointment Dailogs Above or Below.",
				'cms_config_description' => "above = show the appointment dialogs above the calendar, below = show appointment dialogs below the calendar.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "DAILY_FINISH_TIME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => (17 * 3600),	//seconds
				'cms_config_allowed_values' => '0:' . self::TIME_INC . ':' . self::SECS_DAY . '',	// start:seconds increment:finish
				'cms_config_name' => "Daily Appointments Finish Time.",
				'cms_config_description' => "Daily finish time for available appointments.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'select_time_of_day',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "SLOTS_PER_DAY",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 4,
				'cms_config_allowed_values' => 'min=1:max=10',
				'cms_config_name' => "Time Slots per Day.",
				'cms_config_description' => "The maximum number of time slots per day.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_number',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
//			array(
//				'cms_config_key' => "TIME_INC_SECS",	// gets prefixed with the PL_PluginName_ in uppercase
//				'cms_config_value' => self::TIME_INC,
//				'cms_config_allowed_values' => '',
//				'cms_config_name' => "Appointment Time Increment.",
//				'cms_config_description' => "Time increment in seconds appointments slots.",
//				'cms_config_show_func' => '',
//				'cms_config_input_func' => 'input_number',
//				'cms_config_save_func' => '',
//				// 'cms_config_comments' => '',
//				),	// row data
			array(
				'cms_config_key' => "USE_STRONG_PASSWDS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'true',
				'cms_config_allowed_values' => 'true:false',
				'cms_config_name' => "Use Strong Passwords.",
				'cms_config_description' => "true = check password strength (per &uot;Password Required Regex&quot; config), false = don&rsquo;t check password strength.<br>The minimum length of a password is set by config &quot;Minimum Password Length.&quot; (key: LM_C_MIN_PASSWD_LEN) value.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => '',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data

			array(
				'cms_config_key' => "DB_TYPE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'SQLite',
				'cms_config_allowed_values' => 'SQLite:MySQL',
				'cms_config_name' => "Appointments Database Type.",
				'cms_config_description' => "The type of database to use,<br>" .
						"SQLite DB is saved in the " . ETC_DIR . "sqlite directory (for small self contained).<br>" .
						"MySQL DB will need to setup on a database server with the credentials setup here (for larger fixed databases).",
				),	// row data
			array(
				'cms_config_key' => "DB_HOST",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'localhost',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Appointments MySQL Database Host.",
				'cms_config_description' => "The database host server,<br>Not used for SQLite DB.",
				),	// row data
			array(
				'cms_config_key' => "DB_NAME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'appointments',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Appointments MySQL Database Name.",
				'cms_config_description' => "The database name,<br>This is the database filename for the SQLite DB in the " . ETC_DIR . "sqlite directory.",
				),	// row data
			array(
				'cms_config_key' => "DB_USER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'admin',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Appointments MySQL Database Username.",
				'cms_config_description' => "The database username to access the MySQL DB.",
				),	// row data
			array(
				'cms_config_key' => "DB_PASSWORD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => 'admin',
				'cms_config_allowed_values' => '',
				'cms_config_name' => "Appointments MySQL Database Password.",
				'cms_config_description' => "The database password to access the MySQL DB.",
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_appointments_plugin
