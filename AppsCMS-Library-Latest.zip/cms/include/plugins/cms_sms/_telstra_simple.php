<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: _telstra_simple.php 3394 2023-07-25 00:25:01Z robert0609 $
 */

/**
 * Description of C_telstra_simple
 *
 * Description of Telstra SMS messaging using simple curl messaging API
 * 
 * See "https://dev.telstra.com/docs/messaging-api/" (need to login to dev account to get ID and key)
 * 
 * @author robert0609
 */

class C_telstra_simple extends Ccms_sms_base {
	
	private $config = null;
	private $urls = null;
	
	public function __construct($config = false, $urls = false) {
		// parent::__construct();
		self::$sms_error = false;	// ??
		if(!empty($config)) $this->config = $config;
		else  {
			$this->config = [
				"client_id"  => PL_CMS_SMS_TELSTRA_CLNT_ID,
				"client_secret"  => PL_CMS_SMS_TELSTRA_CLNT_SECRET,
				];			
			} // else
		if(!empty($urls)) $this->urls = $urls;
		else {
			// refer to "https://dev.telstra.com/docs/messaging-api/apiReference/apiReferenceOverviewEndpoints"
			$this->urls = [
				"url" => "https://tapi.telstra.com/v2/",
				"auth" => [ "uri" => "oauth/token", "method" => "POST", "content" => "application/x-www-form-urlencoded", ],
				"create_prov" => [ "uri" => "messages/provisioning/subscriptions", "method" => "POST", "content" => "application/json", "header" => ["Cache-Control: no-cache"], ],
				"get_prov" => [ "uri" => "messages/provisioning/subscriptions", "method" => "GET", "content" => "application/json", "header" => ["Cache-Control: no-cache"], ],
				"del_prov" => [ "uri" => "messages/provisioning/subscriptions", "method" => "DELETE", "content" => "application/json", "header" => ["Cache-Control: no-cache"], ],
				"sms_send" => [ "uri" => "messages/sms", "method" => "POST", "content" => "application/json", ],	// "header" => ["Accept: application/json"],
				"sms_status" => [ "uri" => "messages/sms/{messageId}/status", "method" => "GET", "content" => "application/json", ],
				"sms_replies" => [ "uri" => "messages/sms", "method" => "GET", "content" => "application/json", ],
				"get_bnums" => [ "uri" => "messages/freetrial/bnum", "method" => "GET", "content" => "application/json", ],
				"set_bnums" => [ "uri" => "messages/freetrial/bnum", "method" => "POST", "content" => "application/json", ],
				"health" => [ "uri" => "messages/sms/healthcheck", "method" => "GET", "content" => "application/json", ],
				// ?? why no "summary" => [ "uri" => "messages/sms/summary", "method" => "GET", "content" => "application/json", ],
				];
			} // else
		} // __construct()
	
	public function __destruct() {
		// parent::__destruct();
		} // __destruct()
		
	public static function get_description() {	// get the plugin description and help
		return 'The Telstra simple API using Curl to access the Telstra messaging API.' .
			'<br>See &quot;https://dev.telstra.com/docs/messaging-api/ &quot; for more details.';
		} // get_description()

	private static function do_curl($url, &$ctl,	$values = false, $token = false) {
		self::$sms_error = false;
		$options = array(
			CURLOPT_VERBOSE  => true,
			CURLOPT_RETURNTRANSFER  => true,
			CURLOPT_TIMEOUT  => 10
			);
		$url .= $ctl['uri'];
		$options[CURLOPT_CUSTOMREQUEST]  = $ctl['method'];
		
		if(!empty($token)) {
			$header = array('Content-Type: ' . $ctl['content'], 'Authorization: ' . $token['token_type'] . ' ' . $token['access_token']);
			} // if
		else {
			$header = array('Content-Type: ' . $ctl['content']);
			} // else
		if(!empty($ctl['header'])) $header = array_merge($header,$ctl['header']);
		$options[CURLOPT_HTTPHEADER] = $header;

		if(!empty($values)) {
			if(is_array($values)) {
				switch($ctl['content']) {
				case 'application/json':
					$options[CURLOPT_POSTFIELDS] = self::json_encode($values);
					break;
				case 'application/x-www-form-urlencoded':
					$options[CURLOPT_POSTFIELDS] = http_build_query($values);
					break;
				default:
					self::logSmsMsg('Unknown content type.','error','admin');
					return false;
					} // switch					
				} // if
			else {
				$url .= '?' . $values;	// already cooked
				} // else
			} // if
		// else // it is all in the url

		$ch = curl_init($url);
		curl_setopt_array($ch, $options);
		$response = curl_exec($ch);
		$info = curl_getinfo($ch);
		switch($info['http_code']) {
		case 200:	// ok response
		case 201:	// ok sms created/queued
		case 204:	// ok (no content)
			// ok
			break;
		default:
			self::logSmsMsg('CURL Request failed to: ' . $url . PHP_EOL . 
				'Token: ' . print_r($token,true) . PHP_EOL .
				'Values: ' . print_r($values,true) . PHP_EOL .
				'Response: ' . print_r($response,true) . PHP_EOL .
				'Info: ' . print_r(ksort($info),true),'error','debug');
			self::$sms_error = true;
			break;
			} // switch
		if(curl_error($ch)) {
			self::logSmsMsg('CURL Error: ' . curl_error($ch),'error','debug');
			self::$sms_error = true;
			} // if
		curl_close($ch);
		return (self::$sms_error ? false:self::json_decode($response, true));
		} // do_curl()
		
	protected function get_auth_token($options = []){
		if($token = self::get_telstra_cached_token()) return $token;
		if(empty($options)) $options = ['grant_type' => 'client_credentials', 'scope' => 'NSMS',];
		$token = self::do_curl($this->urls['url'], $this->urls['auth'], array_merge($options, $this->config));
		if(empty($token['access_token'])) {
			self::logSmsMsg('Failed to get authentication token.','error','debug');
			return false;
			} // if
		return self::set_telstra_cached_token($token);
		} // get_auth_token()

	public function createSubscription($options = []){
		$token = $this->get_auth_token();
		if($token) {
			if(empty($options)) $options = ["activeDays" => 30, "notifyURL" => "",];
			$result = self::do_curl($this->urls['url'], $this->urls['create_prov'], $options, $token);
			if(!empty($result['destinationAddress'])) return $result;
			self::logSmsMsg('Provision creation failed.','error','debug');
			} // if
		self::logSmsMsg('Error in Telstra SMS token provisioning.','error','debug');
		return false;
		} // crteate_provision()

	public function getSubscription($options = []) {
		$token = $this->get_auth_token();
		if($token) { 
			$result = self::do_curl($this->urls['url'], $this->urls['get_prov'], $options, $token);
			if(!empty($result['destinationAddress'])) return $result;
			self::logSmsMsg('Provision retrieval failed.','error','debug');
			} // if
		self::logSmsMsg('Error in Telstra SMS token provisioning.','error','debug');
		return false;
		} // getSubscription()

	public function deleteSubscription($options = []){
		$token = $this->get_auth_token();
		if($token) { 
			if(empty($options)) $options = ["emptyArr" => 0,];
			$result = self::do_curl($this->urls['url'], $this->urls['del_prov'], $options, $token);
			if($result) return $result;
			self::logSmsMsg('Provision deletion failed.','error','debug');
			} // if
		self::logSmsMsg('Error in Telstra SMS token provisioning.','error','debug');
		return false;
		} // deleteSubscription()

	public function set_free_trial_Bnums() {
		if(PL_CMS_SMS_SMS_MODE != 'debug') return false;
		if(empty(PL_CMS_SMS_TELSTRA_DEBUG_BNUMS)) return true;	// no Bnums (??)
		$nums = self::unserialize_string2arry(PL_CMS_SMS_TELSTRA_DEBUG_BNUMS);
		if(empty($nums)) return false;
		$nums_cln = [];
		foreach($nums as $n) $nums_cln[] = preg_replace('/[^0-9+]+/','',$n);	// remove formatting
		$bnums = array('bnum' => $nums_cln);
		$token = $this->get_auth_token();
		if($token) {
			$result = self::do_curl($this->urls['url'], $this->urls['set_bnums'], $bnums, $token);
			if((!empty($result['bnum'])) && ($result == $bnums)) return true;	// returns the bnum array;
			} // if
		return false;
		} // set_free_trial_Bnums()	

	public function get_free_trial_Bnums() {
		if(PL_CMS_SMS_SMS_MODE != 'debug') return false;
		$token = $this->get_auth_token();
		if($token) {
			$result = self::do_curl($this->urls['url'], $this->urls['get_bnums'], false, $token);
			if(!empty($result['bnum'])) return $result['bnum'];
			} // if
		return false;
		} // get_free_trial_Bnums()	

// why no summary endpoint, is it openapi ????
//	public function get_api_summary() {
////		$token = $this->get_auth_token();
////		if($token) {
//			$result = self::do_curl($this->urls['url'], $this->urls['summary']);
//			if(!empty($result['status'])) return $result;
////			} // if
//		return false;
//		} // get_api_summary()	

	public function get_sms_health() {
		$result = self::do_curl($this->urls['url'], $this->urls['health']);
		if(!empty($result['status'])) return $result;
		return false;
		} // get_sms_health()	

	protected function get_sms_reply($options = []) {	// one at a time from all mobile numbers to this account ID
		$token = $this->get_auth_token();
		if(!$token) return false;
		$reply = self::do_curl($this->urls['url'], $this->urls['sms_replies'], $options, $token);
		if(!empty($reply['status'])) return $reply;
		return false;
		} // get_sms_reply()	

	public function get_sms_replies($options = []) {
		$replies = [];
		while($reply = $this->get_sms_reply($options)) {
			if($reply['status'] == 'EMPTY') break;
			$replies[] = $reply;			
			} // whle
		return $replies;
		} // get_sms_replies()	

	protected function sms_send($options = []) {
		$token = $this->get_auth_token();
		if($token) {
			$result = self::do_curl($this->urls['url'], $this->urls['sms_send'], $options, $token);
			if(!isset($result['messages'])) {	// probably something went wrong with the config/setup.
				self::logSmsMsg('Curl SMS send Failed' . (!empty($result) ? ': ' . print_r($result,true):''),'error','debug');
				return false;				
				} // if
			return $result;
			} // if

		self::addDebugMsg('Error in Telstra SMS transmission.');
		return false;
		} // sms_send()

	public function send_sms_msg($args = []) {
		if(self::$sms_error) return false;
		foreach($args as $k => &$v) if(is_string($k)) $$k = $v;	// expand args
		if((empty($dest_number)) || (empty($message))) {
			self::logSmsMsg('Missing destination number or SMS message.','error','debug');
			return false;
			} // if
		if(strlen($message) > self::MAX_LEN) {
			$message = substr($message,0,self::MAX_LEN);
			self::logSmsMsg('SMS message length truncated to ' . self::MAX_LEN . ' characters.','error','debug');
			} // if
		$ok = true;
//		$prov = $this->getSubscription();
//		if(!empty($prov)) {
			$to = $this->chk_get_mobile_number($dest_number);
			if(($to) && ($result = $this->sms_send([
				'to' => $to,
				'body' => $message,
//				'from' => $prov['destinationAddress'],
//				'validity' => 1,
//				'scheduledDelivery' => 1,
//				'notifyURL' => '',
//				'replyRequest' => false,
				]))) {
				foreach($result['messages'] as $sms) {
					if ($sms['deliveryStatus'] == 'MessageWaiting') {
						self::logSmsMsg('Message to ' . $sms['to'] . " has been queued by Telstra.",'success','admin');
						} // if
					} // foreach
				return $result;
				} // if
			else {
				self::logSmsMsg('SMS send Failed');
				$ok = false;
				} // else
//			} // if
//		else {
//			self::logSmsMsg("Provision of mobile number not set.",'error','debug');
//			$ok = false;
//			} // else
		return $ok;		
		} // send_sms_msg()
		
} // C_telstra_simple

