<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: sms_everyone.php 3082 2023-01-03 04:43:06Z robert0609 $
 */

/**
 * Description of Csms_everyone class
 *
 * Description of SMS Everyone SMS messaging using Swagger messaging API
 * 
 * Contact "https://www.smseveryone.com.au/" for username and password.
 * 
 * See "https://www.smseveryone.com.au/restapi/"
 * 
 * @author robert0609
 */

class Csms_everyone extends Ccms_sms_base {
	
	protected $summary = false;
	protected const UTF8_MAX_LEN = 765;	//maximum body size
	protected const UNI_MAX_LEN = 335;	//maximum body size
	protected const REPLY_INTERVAL = (1 * 60);	// recommended interval in seconds between checking server for replies
	
	public function __construct($config = false, $urls = false) {
		// parent::__construct();
		self::$sms_error = false;
		if(!empty($config)) $this->config = $config;
		else  {
			$this->config = [
				"client_id"  => PL_CMS_SMS_SMS_EVERYONE_USERNAME,
				"client_secret"  => PL_CMS_SMS_SMS_EVERYONE_PASSWORD,
				"from_number" => PL_CMS_SMS_SMS_EVERYONE_FROM_NUMBER,
				];			
			} // else
		if(!empty($urls)) $this->urls = $urls;
		else {
			$this->urls = [
				"send_url" => "https://smseveryone.com/api/campaign",
				"reply_url" => "https://smseveryone.com/api/replies",
				"status_url" => "https://smseveryone.com/api/RetrieveUserSettings",
				];
			} // else
		} // __construct()
	
	public function __destruct() {
		// parent::__destruct();
		} // __destruct()
		
	public function __call($name, $args) {	// a PHP magic method
		return false;	// not used function
		} // __call()
		
	public static function get_provider_name() {
		return 'SMS Everyone';
		} // get_provider_name()
		
	public static function is_ok() {
		$ok = true;
		if((!defined('PL_CMS_SMS_SMS_EVERYONE_USERNAME')) || (strlen(PL_CMS_SMS_SMS_EVERYONE_USERNAME) < 4)) {
			self::logSmsMsg('SMS Everyone SMS messaging API username not configured.','error','admin');
			$ok = false;
			} // if
		if((!defined('PL_CMS_SMS_SMS_EVERYONE_PASSWORD')) || (strlen(PL_CMS_SMS_SMS_EVERYONE_PASSWORD) < 8)) {
			self::logSmsMsg('SMS Everyone SMS messaging API password not configured.','error','admin');
			$ok = false;
			} // if
		return $ok;
		if((!defined('PL_CMS_SMS_SMS_EVERYONE_FROM_NUMBER')) || (strlen(PL_CMS_SMS_SMS_EVERYONE_FROM_NUMBER) < 8)) {
			self::logSmsMsg('SMS Everyone SMS messaging API from number not configured.','error','admin');
			$ok = false;
			} // if
		} // is_ok()
		
	public static function get_description() {	// get the plugin description and help
		return '<b>SMS Everyone SMS interface.</b><br>' .
			'Provides access to the SMS Everyone SMS API schema.<br>.' .
			'See &quot;https://www.smseveryone.com.au/restapi &quot; for more informaation.';
		} // get_description()

	private static function do_curl($url, $values, $token) {
		self::$sms_error = false;
		$options = array(
			CURLOPT_VERBOSE  => true,
			CURLOPT_RETURNTRANSFER  => true,
			CURLOPT_TIMEOUT  => 10
			);
		$header = array('Content-Type: application/json', 'Authorization: Basic ' . $token);
		$options[CURLOPT_HTTPHEADER] = $header;
		$options[CURLOPT_CUSTOMREQUEST]  = 'POST';
		if(!empty($values)) {
			$options[CURLOPT_POSTFIELDS] = self::json_encode($values);
			} // if

		$ch = curl_init($url);
		curl_setopt_array($ch, $options);
		$response = curl_exec($ch);
		$info = curl_getinfo($ch);
		switch($info['http_code']) {
		case 200:	// ok response
		case 201:	// ok sms created/queued
		case 204:	// ok (no content)
			// ok
			break;
		default:
			self::logSmsMsg('CURL Request failed to: ' . $url . PHP_EOL . 
				'Token: ' . print_r($token,true) . PHP_EOL .
				'Values: ' . print_r($values,true) . PHP_EOL .
				'Response: ' . print_r($response,true) . PHP_EOL .
				'Info: ' . print_r(ksort($info),true),'error','debug');
			self::$sms_error = true;
			break;
			} // switch
		if(curl_error($ch)) {
			self::logSmsMsg('CURL Error: ' . curl_error($ch),'error','debug');
			self::$sms_error = true;
			} // if
		curl_close($ch);
		return (self::$sms_error ? false:self::json_decode($response, true));
		} // do_curl()
	
	protected function get_auth_token() {
		$str = PL_CMS_SMS_SMS_EVERYONE_USERNAME . ':' . PL_CMS_SMS_SMS_EVERYONE_PASSWORD;
		$token = base64_encode($str);
		return $token;		
		} // get_auth_token()
		
	public function get_sms_replies($options = []) {
		// @TODO don't at less than a minute
		if($last_reply_check = self::get_cms_sess_var('last_sms_reply_check')) {
			if(($last_reply_check + self::REPLY_INTERVAL) > time()) {
				return [ 'count' => 0, 'status' => 'Minimum time between reply checks is ' . (self::REPLY_INTERVAL / 60) . ' minutes.'];
				} // if
			} // if
		self::set_cms_sess_var(time(),'last_sms_reply_check');
		$token = $this->get_auth_token();
		if((empty($options)) || (!is_array($options))) {
			$options = [];	// clean
			if((int)PL_CMS_SMS_SMS_EVERYONE_REPLY_DAYS > 0)	$options['Days'] = (int)PL_CMS_SMS_SMS_EVERYONE_REPLY_DAYS;
			else {
				$options['DateStart'] = date('Y-m-d',strtotime('-30 day'));
				$options['DateEnd'] = date('Y-m-d');	// ,strtotime('+1 day'));
				} // else
			} // if
		if(self::is_debug()) $options['Test'] = true;
		
		$replies = self::do_curl($this->urls['reply_url'], $options, $token);
		return $replies;
		} // get_sms_replies()	

	protected function sms_send($options = []) {
		$token = $this->get_auth_token();
		$result = self::do_curl($this->urls['send_url'], $options, $token);
		return $result;
		} // sms_send()

	public function send_sms_msg($args = []) {
		if(self::$sms_error) return false;
		foreach($args as $k => &$v) if(is_string($k)) $$k = $v;	// expand args
		if((empty($dest_number)) || (empty($message))) {
			self::logSmsMsg('Missing destination number or SMS message.','error','debug');
			return false;
			} // if
		$enc = mb_detect_encoding($message);
		switch($enc) {			
		case 'ASCII':
		case 'UTF-8':
			if(strlen($message) > self::UTF8_MAX_LEN) {
				$message = substr($message,0,self::UTF8_MAX_LEN);
				self::logSmsMsg('UTF8 SMS message length truncated to ' . self::UTF8_MAX_LEN . ' characters.','error','debug');
				} // if
			break;
		default:
			if(strlen($message) > self::UNI_MAX_LEN) {
				$message = substr($message,0,self::UNI_MAX_LEN);
				self::logSmsMsg('Non UTF8 SMS message length truncated to ' . self::UNI_MAX_LEN . ' characters.','error','debug');
				} // if
			break;
			} // switch
		
		$dest = $this->chk_get_mobile_number($dest_number);
		$orig = $this->chk_get_mobile_number(PL_CMS_SMS_SMS_EVERYONE_FROM_NUMBER);
		if(($dest) && ($orig) && ($result = $this->sms_send([
			'Message' => $message,
			'Destinations' => [ $dest,],
			'Originator' => $orig,
			'Action' => 'create',
			]))) {
			if ($result['Code'] == 0) {
				self::logSmsMsg('Message to ' . $dest_number . " has been created by SMS Everyone.",'success','admin');
				} // if
			return $result;
			} // if
		self::logSmsMsg('SMS Everyone send Failed','error','admin');
		return false;		
		} // send_sms_msg()
		
	public function get_sms_status($options = []) {
		$token = $this->get_auth_token();
		$options = [];	// no options
		$status = self::do_curl($this->urls['status_url'], $options, $token);
		return $status;
		} // get_sms_status()	

	public static function get_sql_install_data() {	// extension to the parent plugin install data
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "SMS_EVERYONE_USERNAME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMS Everyone User.",
				'cms_config_description' => "The SMS Everyone messaging username obtained by contacting &quot;https://www.smseveryone.com.au/ &quot;.",
				),	// row data
			array(
				'cms_config_key' => "SMS_EVERYONE_PASSWORD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMS Everyone Password.",
				'cms_config_description' => "The SMS Everyone messaging password obtained by contacting &quot;https://www.smseveryone.com.au/ &quot;.",
				),	// row data
			array(
				'cms_config_key' => "SMS_EVERYONE_FROM_NUMBER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => self::PHONE_NUMBER_MIN_MAX_PARAM,
				'cms_config_name' => "SMS Everyone From Mobile Number.",
				'cms_config_description' => "The SMS Everyone messaging from mobile number obtained by contacting &quot;https://www.smseveryone.com.au/ &quot;.",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_string',
				'cms_config_save_func' => 'get_mobile_number',
				// 'cms_config_comments' => '',
				),	// row data
			array(
				'cms_config_key' => "SMS_EVERYONE_REPLY_DAYS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "0",
				'cms_config_allowed_values' => "min=0:max=500",
				'cms_config_name' => "SMS Everyone Reply Days.",
				'cms_config_description' => "The SMS Everyone messaging past days to check for SMS replies (default 0, returns new replies only and marks the reply as retrieved).",
				'cms_config_show_func' => '',
				'cms_config_input_func' => 'input_number',
				'cms_config_save_func' => '',
				// 'cms_config_comments' => '',
				),	// row data
			);
		} // get_sql_install_data()

} // Csms_everyone

