<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: _telstra_SDKapi.php 3077 2023-01-01 06:34:12Z robert0609 $
 */

/**
 * Description of C_telstra_SDKapi
 *
 * Description of Telstra SMS messaging using Telstra messaging SDK API
 * 
 * See "https://github.com/telstra/MessagingAPI-SDK-php"
 *
 * @author robert0609
 */

require_once(CMS_FS_LIB_DIR . 'vendor/autoload.php');

class C_telstra_SDKapi extends Ccms_sms_base {
	
	protected const MAX_LEN = 1900;	//maximum body size

	public function __construct($config = false, $urls = false) {
		// parent::__construct();
		} // __construct()
	
	public function __destruct() {
		// parent::__destruct();
		} // __destruct()
		
	public static function get_description() {	// get the plugin description and help
		return 'The Telstra Messaging API SDK to access the Telstra messaging API.' .
			'<br>See &quot;https://github.com/telstra/MessagingAPI-SDK-php &quot; for more details.';
		} // get_description()

	protected function getAuthToken() {
		if($token = self::get_telstra_cached_token()) return $token;
		$apiInstance = new Telstra_Messaging\Api\AuthenticationApi(
			// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
			// This is optional, `GuzzleHttp\Client` will be used as default.
			new GuzzleHttp\Client()
			);
		$client_id = PL_CMS_SMS_TELSTRA_CLNT_ID; // string | 
		$client_secret = PL_CMS_SMS_TELSTRA_CLNT_SECRET; // string | 
		$grant_type = 'client_credentials'; // string | 

		try {
			$result = $apiInstance->authToken($client_id, $client_secret, $grant_type);
			$token = [];
			foreach($result->getters() as $n => $func) {
				$token[$n] = $result->$func();
				} // foreach
			return self::set_telstra_cached_token($token);
			} 
		catch (Exception $e) {
			self::logSmsMsg('Exception when calling AuthenticationApi->authToken: ' . $e->getMessage(),'error','debug');
			} // catch
		return false;
		} // getAuthToken()
		
	public function createSubscription($options = []){
		$token = $this->getAuthToken();
		if(empty($token)) return false;
		$access_token = $token['access_token'];

		// Configure OAuth2 access token for authorization: auth
		$config = Telstra_Messaging\Configuration::getDefaultConfiguration()->setAccessToken($access_token);

		$apiInstance = new Telstra_Messaging\Api\ProvisioningApi(
			// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
			// This is optional, `GuzzleHttp\Client` will be used as default.
			new GuzzleHttp\Client(),
			$config
			);
		$provision_number_request = new \Telstra_Messaging\Model\ProvisionNumberRequest(); // \Telstra_Messaging\Model\ProvisionNumberRequest | A JSON payload containing the required attributes

		try {
			$result = $apiInstance->createSubscription($provision_number_request);
			if(!empty($result['destinationAddress'])) return $result;
			self::logSmsMsg('Provision creation failed.','error','debug');
			return false;
			} // try
		catch (Exception $e) {
			self::logSmsMsg('Exception when calling ProvisioningApi->createSubscription: ' . $e->getMessage(),'error','debug');
			} // catch
		return false;
		} // crteate_provision()

	public function getSubscription($options = []) {
		$token = $this->getAuthToken();
		if(empty($token)) return false;
		$access_token = $token['access_token'];

		// Configure OAuth2 access token for authorization: auth
		$config = Telstra_Messaging\Configuration::getDefaultConfiguration()->setAccessToken($access_token);

		$apiInstance = new Telstra_Messaging\Api\ProvisioningApi(
			// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
			// This is optional, `GuzzleHttp\Client` will be used as default.
			new GuzzleHttp\Client(),
			$config
			);

		try {
			$result = $apiInstance->getSubscription();
			if(!empty($result['destinationAddress'])) return $result;
			self::logSmsMsg('Provision retrieval failed.','error','debug');
			return false;
			} // try
		catch (Exception $e) {
			self::logSmsMsg('Exception when calling ProvisioningApi->getSubscription: ' . $e->getMessage(),'error','debug');
			} // catch				
		if(!empty($result['destinationAddress'])) return $result;
		self::logSmsMsg('Provision retrieval failed.','error','debug');
		return false;
		} // getSubscription()

	public function deleteSubscription($options = []){
		$token = $this->getAuthToken();
		if(empty($token)) return false;
		$access_token = $token['access_token'];

		// Configure OAuth2 access token for authorization: auth
		$config = Telstra_Messaging\Configuration::getDefaultConfiguration()->setAccessToken($access_token);

		$apiInstance = new Telstra_Messaging\Api\ProvisioningApi(
			// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
			// This is optional, `GuzzleHttp\Client` will be used as default.
			new GuzzleHttp\Client(),
			$config
			);
		$delete_number_request = new \Telstra_Messaging\Model\DeleteNumberRequest(); // \Telstra_Messaging\Model\DeleteNumberRequest | EmptyArr

		try {
			$apiInstance->deleteSubscription($delete_number_request);	// : void
			return true;	// assume it's done ???
			} // try
		catch (Exception $e) {
			self::logSmsMsg('Exception when calling ProvisioningApi->deleteSubscription: ' . $e->getMessage(),'error','debug');
			} // catch
		return false;
		} // deleteSubscription()

	protected function get_sms_reply($options = []) {	// one at a time from all mobile numbers to this account ID
		$token = $this->getAuthToken();
		if(empty($token)) return false;
		$access_token = $token['access_token'];

		// Configure OAuth2 access token for authorization: auth
		$config = Telstra_Messaging\Configuration::getDefaultConfiguration()->setAccessToken($access_token);

		$apiInstance = new Telstra_Messaging\Api\MessagingApi(
			// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
			// This is optional, `GuzzleHttp\Client` will be used as default.
			new GuzzleHttp\Client(),
			$config
			);

		try {
			$result = $apiInstance->retrieveSMSResponses();
			$reply = [];;
			foreach($result->getters() as $n => $func) {
				$reply[$n] = $result->$func();
				} // foreach
			return $reply;
			} // try
		catch (Exception $e) {
			echo 'Exception when calling MessagingApi->retrieveSMSResponses: ', $e->getMessage(), PHP_EOL;
			} // catch
		return false;
		} // get_sms_reply()	

	public function get_sms_replies($options = []) {
		$replies = [];
		while($reply = $this->get_sms_reply($options)) {
			if($reply['status'] == 'EMPTY') break;
			$replies[] = $reply;			
			} // whle
		return $replies;
		} // get_sms_replies()	

	public function send_sms_msg($args = []) {
		if(self::$sms_error) return false;
		foreach($args as $k => &$v) if(is_string($k)) $$k = $v;	// expand args
		if((empty($dest_number)) || (empty($message))) {
			self::logSmsMsg('Missing destination number or SMS message.','error','debug');
			return false;
			} // if
		if(strlen($message) > self::MAX_LEN) {
			$message = substr($message,0,self::MAX_LEN);
			self::logSmsMsg('SMS message length truncated to ' . self::MAX_LEN . ' characters.','error','debug');
			} // if
		
		$token = $this->getAuthToken();
		if(empty($token)) return false;
		$access_token = $token['access_token'];

		// Configure OAuth2 access token for authorization: auth
		$config = Telstra_Messaging\Configuration::getDefaultConfiguration()->setAccessToken($access_token);

		$apiInstance = new Telstra_Messaging\Api\MessagingApi(
			// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
			// This is optional, `GuzzleHttp\Client` will be used as default.
			new GuzzleHttp\Client(),
			$config
			);
		if(!$to = $this->chk_get_mobile_number($dest_number)) return false;
		$smsObj = [
			'to' => $to,
			'body' => $message
			];
		$send_sms_request = new \Telstra_Messaging\Model\SendSMSRequest($smsObj); // \Telstra_Messaging\Model\SendSMSRequest | A JSON or XML payload containing the recipient's phone number and text message.
		// This number can be in international format if preceeded by a '+' or in national format ('04xxxxxxxx') where x is a digit.

		try {
			$result = $apiInstance->sendSMS($send_sms_request);
			$sent = [];;
			foreach($result->getters() as $n => $func) {
				$sent[$n] = $result->$func();
				} // foreach
			return $sent;
			} // try
		catch (Exception $e) {
			self::logSmsMsg('Exception when calling MessagingApi->sendSMS: ' . $e->getMessage(),'error','debug');
			} // catch
		return false;		
		} // send_sms_msg()
		
} // C_telstra_SDKapi

