<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: telstra.php 3063 2022-12-26 09:10:56Z robert0609 $
 */

/**
 * Description of Ctelstra
 *
 * Description of Telstra SMS messaging
 * 
 * See "https://dev.telstra.com/docs/messaging-api/" (need to login to dev account to get ID and key)
 * and "https://github.com/telstra/MessagingAPI-SDK-php"
 *
 * @author robert0609
 */

class Ctelstra extends Ccms_sms_base {
	
	public static $use_simple = true;
	
	protected $cTapi = false;
	
	public function __construct($config = false, $urls = false) {
		// parent::__construct();
		if(!self::is_ok ()) return;
		self::$use_simple = ((PL_CMS_SMS_TELSTRA_API_TYPE == 'simple') ? true:false);
		if(self::$use_simple) {
			require_once '_telstra_simple.php';
			$this->cTapi = new C_telstra_simple($config, $urls);
			} // if
		else {
			require_once '_telstra_SDKapi.php';
			$this->cTapi = new C_telstra_SDKapi($config, $urls);
			} // else
		} // __construct()
	
	public function __destruct() {
		// parent::__destruct();
		} // __destruct()
		
	public static function is_ok() {
		$ok = true;
		if(strlen(PL_CMS_SMS_TELSTRA_CLNT_ID) < 8) {
			self::logSmsMsg('Telstra SMS messaging API client ID not configured.','error','admin');
			$ok = false;
			} // if
		if(strlen(PL_CMS_SMS_TELSTRA_CLNT_SECRET) < 8) {
			self::logSmsMsg('Telstra SMS messaging API client secret not configured.','error','admin');
			$ok = false;
			} // if
		return $ok;
		} // is_ok()
		
	protected static function is_telstra_method($class,$method) {
		if((method_exists($class, $method)) &&
			(is_callable([$class,$method]))) {
			return true;
			} // if
		return false;
		} // is_telstra_method()
		
	public function __call($name, $args) {	// a PHP magic method
		if(self::is_telstra_method($this->cTapi, $name)) {
			if((isset($args[0][0])) && ($args[0][0] == '__call')) {
				$args = $args[0];	// remove __call args depth progression
				array_shift($args);
				} // if
			if(isset($args[0])) $args = $args[0];	// remove __call args depth progression again
			return $this->cTapi->$name($args);
			} // if
		return false;
		} // __call()
		
	public static function get_provider_name() {
		$name = 'Telstra';
		$name .= ' (' . self::$use_simple = ((PL_CMS_SMS_TELSTRA_API_TYPE == 'simple') ? 'Simple API':'SDK API') . ').';
		return $name;
		} // get_provider_name()
		
	public static function get_description() {	// get the plugin description and help
		$desc = '<b>Telstra SMS interface.</b><br>' .
			'Provides on &quot;Telstra Messaging API&quot; to select access to these SMS API schemas.<br>.' .
			'<ul>';
		$files = glob(__DIR__ . '/_telstra_*.php');
		foreach($files as $f) {
			require_once $f;
			$class = 'C' . preg_replace('/\.php$/','',basename($f));
			$desc .= '	<li>' . $class::get_description() . '</li>';
			} // foreach					
		$desc .= '</ul>';
		return $desc;
		} // get_description()

	public function set_free_trial_Bnums() {	// special case
		require_once '_telstra_simple.php';
		if(self::is_telstra_method('C_telstra_simple','set_free_trial_Bnums')) {
			$cTapi = new C_telstra_simple();
			return $cTapi->set_free_trial_Bnums();
			} // if
		return false;
		} // set_free_trial_Bnums()	

	public function get_free_trial_Bnums() {	// special case
		require_once '_telstra_simple.php';
		if(self::is_telstra_method('C_telstra_simple','get_free_trial_Bnums')) {
			$cTapi = new C_telstra_simple();
			return $cTapi->get_free_trial_Bnums();
			} // if
		return false;
		} // get_free_trial_Bnums()	

	public function get_sms_health() {	// special case
		require_once '_telstra_simple.php';
		if(self::is_telstra_method('C_telstra_simple','get_sms_health')) {
			$cTapi = new C_telstra_simple();
			return $cTapi->get_sms_health();
			} // if
		return false;
		} // get_sms_health()	

	public static function get_sql_install_data() {	// extension to the parent plugin install data
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "TELSTRA_CLNT_ID",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Telstra Messaging ID.",
				'cms_config_description' => "The Telstra messaging ID obtained from &quot;https://dev.telstra.com/secrets/view-all-secrets &quot; account.",
				),	// row data
			array(
				'cms_config_key' => "TELSTRA_CLNT_SECRET",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Telstra Messaging Secret.",
				'cms_config_description' => "The Telstra messaging secret obtained from &quot;https://dev.telstra.com/secrets/view-all-secrets &quot; account.",
				),	// row data
			array(
				'cms_config_key' => "TELSTRA_API_TYPE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "simple",
				'cms_config_allowed_values' => "simple:SDKapi",
				'cms_config_name' => "Telstra Messaging API.",
				'cms_config_description' => "simple = uses a simple curl base API for messaging (default)<br>" .
					"from &quot;https://dev.telstra.com/docs/messaging-api/ &quot;,<br>" . 
					"sdkapi = uses the &quot;MessagingAPI-SDK&quot;<br>" .
					"from &quot;https://github.com/telstra/MessagingAPI-SDK-php &quot;.",
				),	// row data
			array(
				'cms_config_key' => "TELSTRA_DEBUG_BNUMS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "Bnum",
				'cms_config_name' => "Telstra Free Trial/Debug Bnumbers.",
				'cms_config_description' => "To use the free trial/debug messaging on Telstra, you will need to configure &quot;BNUMs&quot; as the recipients for messages in debug mode.<br>" .
					"See &quot;https://dev.telstra.com/docs/messaging-api/tutorialsMenuItem/SendAnSMS &quot;.<br>" .
					"<b>Note:</b> BNUMs (max 5) are only used in debug mode. And should be considered as temporary.'",
				'cms_config_show_func' => 'show_grid',
				'cms_config_input_func' => 'input_grid',
				'cms_config_save_func' => 'save_grid',
				),	// row data
			);
		} // get_sql_install_data()

} // Ctelstra

