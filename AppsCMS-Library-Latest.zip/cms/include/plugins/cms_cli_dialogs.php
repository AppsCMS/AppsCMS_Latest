<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_cli_dialogs.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of CLI Menu plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * For more information refer to the Linux "man dialog" or
 * refer to "http://linuxcommand.org/lc3_adv_dialog.php" and others for more help
 *
 * Author's Note: The Linux shell dialog package has many quirks (especially in the use of arrow keys and tab key operation)
 *  and is not ideal for a user without CLI user experience.
 *
 * @author robert0609
 */

class Ccms_cli_dialogs_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_cli_dialogs';

	protected static $cmd = false;
	protected static $pipes = array();
	protected static $process = null;
	protected static $output = '';
	protected static $ret = -1;

	public static $auto_width_height = false;
	public static $die_on_error = true;
	public static $keep_tite = true;

	const DLG_SH_BIN = 'dialog';

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

// static methods
	protected static function processStart($cmd) {
		if(!self::is_cli()) return false;
		self::$cmd = $cmd;
		self::$process = proc_open(
			$cmd,
			array(
				0 => STDIN,
				1 => STDOUT,
				2 => array('pipe', 'w'), // pipe to which child will write any errors
				3 => array('pipe', 'w') // pipe to which child will write any output
				),
			self::$pipes
			);
		return (is_resource(self::$process) ? true:false);
		} // processStart()

	protected static function processStop() {
		if(!is_resource(self::$process)) return false;
		if (isset(self::$pipes[0])) {
			fclose(self::$pipes[0]);
			usleep(2000);
			} // if

		self::$output = '';
		while ($_ = fgets(self::$pipes[3])) {
			self::$output .= $_;
			} // while

		$errors = '';
		$error_str = '';
		while ($_ = fgets(self::$pipes[2])) {
			$error_str .= $_ . PHP_EOL;
			$errors++;
			} // while

		if ($errors) {
			self::addMsg('Error in: "' . __CLASS__ . '", CMD: "' . self::$cmd . '"');
			if(self::$die_on_error) die($error_str);
			fwrite(STDERR,$error_str);
			return false;
			} // if

		fclose(self::$pipes[2]);
		fclose(self::$pipes[3]);

		do {
			usleep(2000);
			$status = proc_get_status(self::$process);
			} while ($status['running']);

		proc_close(self::$process);
		self::$process = null;
		self::$pipes = array();
		self::$ret = $status['exitcode'];
		return self::$ret;
		} // processStop()

	private static function get_h_w(&$title,&$backtitle,&$query,&$width,&$height) {
		if(self::$auto_width_height) {
			$width = 0; $height = 0; return;	// let dialog work it out
			} // if
		$lines = preg_split('/' . PHP_EOL . '/',$title . PHP_EOL . $backtitle . PHP_EOL . $query);	// join and split lines to find max width
		$w_min = 0;
		foreach($lines as $l) if($w_min < strlen($l)) $w_min = strlen($l);
		$w_min += 4;
		if($width < $w_min) $width = $w_min;
		$h_min = count($lines) + 4;
		if($height < $h_min) $height = $h_min;
		} // get_h_w()

	// simple forms
	public static function box_msg($title,$backtitle,$msg,$width = 0,$height = 0) {
		self::get_h_w($title,$backtitle,$msg,$width,$height);
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 --msgbox '" . $msg . "' " .$height . " " . $width);
		return (self::processStop() ? false:true);	// Exit code = 0 for ok;
		} // box_msg()

	public static function box_yes_no($title,$backtitle,$query,$width = 0,$height = 0) {
		self::get_h_w($title,$backtitle,$query,$width,$height);
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 --yesno '" . $query . "' " .$height . " " . $width);
		return (self::processStop() ? false:true);	// Exit code = 0 for ok;
		} // box_yes_no()

	public static function box_input($title,$backtitle,$query,$width = 0,$height = 0,$init=false) {
		self::get_h_w($title,$backtitle,$query,$width,$height);
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 --inputbox '" . $query . "' " .$height . " " . $width . ($init ? ' ' . $init:''));
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_input()

	public static function box_password($title,$backtitle,$query,$width = 0,$height = 0) {
		self::get_h_w($title,$backtitle,$query,$width,$height);
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 --passwordbox '" . $query . "' " .$height . " " . $width);
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_password()

	public static function box_calendar($title,$backtitle,$query,$date_dd_mm_yyyy = '',$width = 0,$height = 0) {
		$day = -1;
		$month = -1;
		$year = -1;
		if(!empty($date_dd_mm_yyyy)) {
			list($day,$month,$year) = preg_split('/[^0123456789]+/',$date_dd_mm_yyyy);
			} // if
		// self::get_h_w($title,$backtitle,$query,$width,$height);
		// $query .= ' ' . $height;	// test
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 --calendar '" . $query . "' " .$height . " " . $width . ' ' . $day . ' ' . $month . ' ' . $year);
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_calendar()

	public static function box_time($title,$backtitle,$query,$time_hh_mm_ss = '',$width = 0,$height = 0) {
		$hour = -1;
		$minute = -1;
		$second = -1;
		if(!empty($time_hh_mm_ss)) {
			list($hour,$minute,$second) = preg_split('/[^0123456789]+/',$time_hh_mm_ss);
			} // if
		// self::get_h_w($title,$backtitle,$query,$width,$height);
		// $query .= ' ' . $height;	// test
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 --timebox '" . $query . "' " .$height . " " . $width . ' ' . $hour . ' ' . $minute . ' ' . $second);
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_time()

	public static function box_username_password($title,$backtitle,$show_password = false) {
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 " .
				" --mixedform 'Enter Credentials\nUse the UP/DOWN keys\nENTER to use\nESC to cancel.' 12 30 0" .
				" 'Username:' 1 1 '' 1 10 16 0 0" .
				" 'Password:' 2 1 '' 2 10 16 0 " . ($show_password ? '0':'1'));
		if(self::processStop()) return false;	// cancel or escape
		$res = preg_split('/' . PHP_EOL . '|\t/',self::$output);
		if(empty($res)) return false;
		if(!is_array($res)) return $res;
		return array(
			'USERNAME' => (isset($res[0]) ? $res[0]:false),
			'PASSWORD' => (isset($res[1]) ? $res[1]:false),
			);
		} // box_username_password()

	/*
	 * $menu = array(
	 *	'title' => 'Menu Title',
	 *	'height' => 9,
	 *	'width' => 30,
	 *	'menuheight' => 0,	// typically 0 to default to 'height'
	 *	'items' => array(
	 *		'menu_return_tag' => 'Menu item description",
	 *		etc.
	 *		),
	 *	);
	 * or [ menu_return_tag desrcipt ] ... (as a dialog string)
	 */
	public static function box_menu($title,$backtitle,$menu) {
		self::get_h_w($title,$backtitle,$query,$width,$height);
		$cmd = self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3";
		if(is_array($menu)) {
			$width = (isset($menu['width']) ? $menu['width']:0);
			$height = (isset($menu['height']) ? $menu['height']:0);
			$menuheight = (isset($menu['menuheight']) ? $menu['menuheight']:0);
			$title = (isset($menu['title']) ? $menu['title']:'');
			$cmd .= "  --menu '" . $title . "' " . $height . " " . $width . " " . " " . $menuheight;
			foreach($menu['items'] as $tag => &$desc) {
				$cmd .= " '" . $tag . "' '" . $desc . "'";
				} // foreach
			} // if
		else $cms .= $menu;
		self::processStart($cmd);
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_menu()

	/*
	 * Example:
	 * $title = 'Enter Details';	// the box title
	 * $backtitle = 'The title at the top of the terminal screen.';	// the terminal title also
	 * $form => array(	// sets up a form of text edit elements
	 *	'title' => 'My Simple Form',	// the form title
	 *	'ok_label' => 'Submit',		// optional (default is OK)
	 *	'height' => 9,
	 *	'width' => 30,
	 *	'formheight' => 0,	// typically 0 to default to 'height'
	 *	'elements' => array(
	 *		array(
	 *			'label' => 'Who',	// the label of the input
	 *			'label_y' => 1,	// optional
	 *			'label_x' => 1,	// optional
	 *			'value' => 'ItsMe',	// optional
	 *			'value_y' => 1,	// optional
	 *			'value_x' => 12,	// optional
	 *			'flen' => 15,	// the input field length, optional if the field is the display length
	 *			'ilen' => 15,	// input length, optional (defaults to flen)
	 *			),
	 *		array(
	 *			next element
	 *			),
	 *		and so on ...
	 *		);
	 *	or title height width formheight [ elem_label y x elem_value y x flen ilen ] ... (as a dialog string)
	 *
	 */

	public static function box_simple_form($title,$backtitle,$form) {
		if(is_array($form)) {
			$cmd = " --ok-label 'Submit'" .
				" --form '" . $form['title'] . "' " . $form['height'] . ' ' . $form['width'] . ' ' . $form['formheight'];
				$e_cnt = 0;
				foreach($form['elements'] as &$elem) {
					$e_cnt++;
					$cmd .= " '" . $elem['label'] . "'";
					$cmd .= " " . (!isset($elem['label_y']) ? $e_cnt:$elem['label_y']);
					$cmd .= " " . (!isset($elem['label_x']) ? 1:$elem['label_x']);
					$cmd .= " '" . (!isset($elem['value']) ? '':$elem['value']) . "'";
					$cmd .= " " . (!isset($elem['value_y']) ? $e_cnt:$elem['value_y']);
					$cmd .= " " . (!isset($elem['value_x']) ? (strlen($elem['label']) + 1):$elem['value_x']);
					$cmd .= " " . (!isset($elem['flen']) ? (strlen($elem['label']) + 1):$elem['flen']);
					$cmd .= " " . (!isset($elem['ilen']) ? 0:$elem['ilen']);
							} // foreach
				//" 'Username:' 1 1	'' 	1 10 15 0" .
				//" 'Password:' 2 1	'' 	2 10 15 0");	//
			} // if
		else $cmd = $form;

		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 " . $cmd);	//
		if(self::processStop()) return false;	// cancel or escape
//		$res = explode(PHP_EOL,self::$output);
		$res = preg_split('/' . PHP_EOL . '|\t/',self::$output);
		if(empty($res)) return false;
		if(!is_array($form)) return $res;
		// else add keyed result
		$r_cnt = 0;
		foreach($form['elements'] as &$elem) {
			$res[($elem['label'])] = (isset($res[$r_cnt]) ? $res[$r_cnt]:false);
			$r_cnt++;
			} // foreach
		return $res;
		} // box_simple_form()

	public static function box_file_select($title,$backtitle,$dir,$width = 0,$height = 0) {
		self::get_h_w($title,$backtitle,$dir,$width,$height);
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') .
			" --title '" . $title . "\nUse the UP/DOWN keys, SPACE BAR to select\nENTER to use\nESC to cancel.'" .
			" --backtitle '" . $backtitle . "'" .
			" --output-fd 3" .
			" --fselect '" . $dir . "'" .
			" " . $height . " " . $width);
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_file_select()

	// compound and other forms
	public static function box_dialogs_direct($title,$backtitle,$dialogs_direct) {	// can be bash dialog form
		self::processStart(self::DLG_SH_BIN . (self::$keep_tite ? ' --keep-tite':'') . " --title '" . $title . "' --backtitle '" . $backtitle . "' --output-fd 3 " . $dialogs_direct);
		return (self::processStop() ? false:self::$output);	// Exit code = 0 for ok;
		} // box_dialogs_direct()

	public static function is_enabled() {	// required function, check plugin enabled
		return self::is_plugin_enabled(self::PLUGIN);
		} // is_enabled()

	public static function is_this_ajax_plugin($ajax) {	// required function, check for ownership of ajax op by this plugin
		if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		return false;
		} // is_this_ajax_plugin()

	public static function get_ajax_text($ajax) {	// required function, generate ajax text for this plugin
		return '';	// default return
		} // get_ajax_text()

	public static function get_title() {	// get the plugin title
		return 'CLI Dialogs';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' CLI Dialogs plugin (' . self::PLUGIN . ') is an assistive plugin used to generate command line (CLI) diaplog boxes for'
			. ' bash dialog boxes to aid in providing user input during CLI operation (typically setting up databases, etc.).';
		} // get_description()

	protected static function get_sql_install_data() {
		$cfg = array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
//			array(
//				'cms_config_key' => "KEY_NAME",	// gets prefixed with the PL_PluginName_ in uppercase
//				'cms_config_name' => "A People Name",
//				'cms_config_value' => "false",
//				'cms_config_allowed_values' => "true:false",
//				'cms_config_description' => "Set true to use, false to not use.",
//				),	// row data
			);
		return $cfg;
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
//		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		return true;	// nothing todo
		}	// install()

	public static function uninstall() {	// dummy function
//		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		return true;	// nothing todo
		}	// uninstall()

} // Ccms_cli_dialogs_plugin