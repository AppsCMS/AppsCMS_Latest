<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: facebook.php 2985 2022-11-14 03:22:23Z robert0609 $
 */

/**
 * Description of Facebook sub-plugin used by the Social Media plugin
 * primary access file to this subplugin
 * access to subplugins is always via classes
 * subplugin name is the name of this file (without the extension)
 *
 * @author robert0609
 *
 * the fundamentals of this sub-plugin come from
 * "https://developers.facebook.com/docs/plugins/like-button"
 *
 *
 */

class Cfacebook_subplugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'facebook';

	function __construct() {
		self::is_enabled();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(!defined('PL_CMS_SOCIALMEDIA_FB_ENABLE')) return false;
		if(!PL_CMS_SOCIALMEDIA_FB_ENABLE) return false;
		// if(!defined('PL_CMS_SOCIALMEDIA_FB_URL')) return false;
		if(strlen(PL_CMS_SOCIALMEDIA_FB_URL) < 8) return false;
		if(PL_CMS_SOCIALMEDIA_SM_LOCATION == 'center_right') return false;	// @TODO need a fly out setting from facebook API/SDK
		return true;
		} // is_enabled()

	public static function init_body_insert() {
		// from "https://developers.facebook.com/docs/plugins/like-button"
		$text =<<< EOTXT

		<!-- Load Facebook SDK for JavaScript -->
		<div id="fb-root"></div>
		<script async defer crossorigin="anonymous"
			src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v12.0&autoLogAppEvents=1"
				nonce="FOKrbAYI">
		</script>

EOTXT;
		return $text;
		} // init_body_insert()

	public static function generate($id,$suffix = '',$params = array()) {	// assume it is in an iframe
		if(!self::is_enabled()) return '';
		if (PL_CMS_SOCIALMEDIA_FB_TYPE == 'link') {	// direct link to face book page
			if((strlen(PL_CMS_SOCIALMEDIA_FB_LOGO_IMAGE) < 6) ||
				(!is_readable(ETC_FS_IMAGES_DIR . PL_CMS_SOCIALMEDIA_FB_LOGO_IMAGE))) {
				if(Ccms_base::is_cms_group_manager()) self::addMsg ('No Facebook logo setup.', 'warning');
				return '';
				} // if
			$text = '<a id="' . $id . $suffix . '" href="' . PL_CMS_SOCIALMEDIA_FB_URL . '" alt="Facebook" target="_blank">' . '<img src="' . ETC_WS_IMAGES_DIR . PL_CMS_SOCIALMEDIA_FB_LOGO_IMAGE . '"></img>' . '</a>' . PHP_EOL;
			return $text;
			} // if

		// from "https://developers.facebook.com/docs/plugins/like-button"
		$url = PL_CMS_SOCIALMEDIA_FB_URL;
		$layout = PL_CMS_SOCIALMEDIA_FB_TYPE;
		$size = PL_CMS_SOCIALMEDIA_FB_SIZE;	// small/large
		$action = PL_CMS_SOCIALMEDIA_FB_ACTION;
		$share = (PL_CMS_SOCIALMEDIA_FB_SHARE ? 'true':'false');
		$style = (!empty($params['style']) ? $params['style']:'');
		$text =<<< EOTXT

		<!-- Your {$layout} code -->
		<div class="fb-like"
			 {$style}
			 data-href="{$url}"
			 data-width=""
			 data-layout="{$layout}"
			 data-action="{$action}"
			 data-size="{$size}"
			 data-share="{$share}">
		</div>

EOTXT;
		return $text;

//		switch(PL_CMS_SOCIALMEDIA_FB_TYPE) {
//		case 'link':	// direct link to face book page
//			if((strlen(PL_CMS_SOCIALMEDIA_FB_LOGO_IMAGE) < 6) ||
//				(!is_readable(ETC_FS_IMAGES_DIR . PL_CMS_SOCIALMEDIA_FB_LOGO_IMAGE))) {
//				if(Ccms_base::is_cms_group_manager()) self::addMsg ('No Facebook logo setup.', 'warning');
//				return '';
//				} // if
//			$text = '<a id="' . $id . $suffix . '" href="' . PL_CMS_SOCIALMEDIA_FB_URL . '" alt="Facebook" target="_blank">' . '<img src="' . ETC_WS_IMAGES_DIR . PL_CMS_SOCIALMEDIA_FB_LOGO_IMAGE . '"></img>' . '</a>' . PHP_EOL;
//			return $text;
//			break;
//		case 'standard':
//			$w = '225px';
//			break;
//		case 'button':
//			$w = '47px';
//			break;
//		case 'box_count':
//			$w = '55px';
//			break;
//		case 'button_count':
//			$w = '90px';
//			break;
//			break;
//		default:
//			return '';
//			break;
//			} // switch
//
//		// widgets from Facebook "https://developers.facebook.com/docs/plugins/page-plugin/"
//		$text = array();
//		$text[] = '<div id="fb-root"></div>';
//		$text[] = '<script type="text/javascript">';
//		$text[] = '	(function(d, s, id) {';
//		$text[] = '		var js, fjs = d.getElementsByTagName(s)[0];';
//		$text[] = '		if (d.getElementById(id)) return;';
//		$text[] = '		js = d.createElement(s); js.id = id;';
//		$text[] = '		js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.3";';
//		$text[] = '		fjs.parentNode.insertBefore(js, fjs);';
//		$text[] = '	}(document, \'script\', \'facebook-jssdk\'));';
//		$text[] = '</script>';
//		$text[] = '';
//		$text[] = '<div';
//		$text[] = '	class="fb-like"';
//		$text[] = '	data-href="' . PL_CMS_SOCIALMEDIA_FB_URL . '"';
//		$text[] = '	data-layout="' . PL_CMS_SOCIALMEDIA_FB_TYPE . '"';
//		$text[] = '	data-action="' . 	PL_CMS_SOCIALMEDIA_FB_ACTION . '"';
//		$text[] = '	data-show-faces="' . (PL_CMS_SOCIALMEDIA_FB_SHOW_FRIENDS ? 'true':'false') . '"';
//		$text[] = '	data-share="' . (PL_CMS_SOCIALMEDIA_FB_SHARE ? 'true':'false') . '"';
//		$text[] = '	data-width="' . $w . '"';
//		$text[] = '	data-colorscheme="light"';
//		$text[] = '	></div>';
//		return (!empty($text) ? PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL:'');
		} // generate()

	public static function get_title() {	// get the plugin title
		return 'Facebook';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		$text = 'Facebook - ' . CMS_PROJECT_SHORTNAME . ' Social Media sub-plugin (' . self::PLUGIN . ') is used to provide links to Facebook.';
		return $text;
		} // get_description()

	public static function get_sql_install_data() {
		$cfg = array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "FB_ENABLE",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "false",	//
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Facebook Enable.",
				'cms_config_description' => "Set true to enable Facebook operation, false to disable.",
				),	// row data
			array(
				'cms_config_key' => "FB_URL",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "",	//
				'cms_config_allowed_values' => "",
				'cms_config_name' => "Facebook URL.",
				'cms_config_description' => "Set the URL at Facebook for your Facebook page (the same URL as Facebook uses).<br>" .
							"NOTE: If the URL is empty, Facebook operations are disabled.",
				),	// row data
			array(
				'cms_config_key' => "FB_TYPE",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "link",	//
				'cms_config_allowed_values' => "link:standard:button:box_count:button_count",
				'cms_config_name' => "Facebook Type.",
				'cms_config_description' => "Set the type of action you want for Facebook.<br>" .
							"Link - a direct link to the Facebook page. The Facebook URL and the Facebook Logo Image are used (Link shown in new tab/window),<br>" .
							"Standard - has like/recommend button and share button next to each other in a row,<br>" .
							"Button - has  like/recommend button<br>" .
							"Box Count - has liked/recommended count, like/recommend button and share button vertically positioned (no show friends),<br>" .
							"Button Count - has like/recommend button, share button and liked/recommended count on the same row (no show friends),<br>" .
							"NOTE: The share button can be enabled or disabled by the Share setting. The like or recommend setting is controlled by Like or Recommend setting.",
				),	// row data
			array(
				'cms_config_key' => "FB_ACTION",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "like",	//
				'cms_config_allowed_values' => "like:recommend",
				'cms_config_name' => "Facebook Action.",
				'cms_config_description' => "Set the type of links you want from Facebook.",
				),	// row data
			array(
				'cms_config_key' => "FB_SIZE",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "small",	//
				'cms_config_allowed_values' => "small:large",
				'cms_config_name' => "Facebook Size.",
				'cms_config_description' => "Set the size of the link from Facebook.",
				),	// row data
//			array(	// depreciated, no longer avalable due to privacy reasons
//				'cms_config_key' => "FB_SHOW_FRIENDS",	// gets prefixed with the SPL_PluginName_ in uppercase
//				'cms_config_value' => "false",	//
//				'cms_config_allowed_values' => "true:false",
//				'cms_config_name' => "Facebook Show Friends.",
//				'cms_config_description' => "Set true to show friends from Facebook (Facepile), false to not show.",
//				),	// row data
			array(
				'cms_config_key' => "FB_SHARE",	// gets prefixed with the SPL_PluginName_ in uppercase
				'cms_config_value' => "false",	//
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Facebook Share.",
				'cms_config_description' => "Set true to enable share button on Facebook, false to not share.",
				),	// row data
			array(
				'cms_config_key' => "FB_LOGO_IMAGE",	//
				'cms_config_value' => "",	//
				'cms_config_allowed_values' => "",	//
				'cms_config_name' => "Facebook Logo Image.",
				'cms_config_description' => "Select the Facebook logo image filename (stored in " . ETC_WS_IMAGES_DIR . " directory).",
				'cms_config_show_func' => "show_image",	//
				'cms_config_input_func' => "input_image",	//
				'cms_config_save_func' => "get_image",	//
				),	// row data
			);
		return $cfg;
		} // get_sql_install_data()

} // Cfacebook_subplugin

