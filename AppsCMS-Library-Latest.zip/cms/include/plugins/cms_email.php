<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_email.php 3325 2023-04-12 08:28:50Z robert0609 $
 */

/**
 * Description of Email plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */


class Ccms_email_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_email';
	protected static $enabled = null;

	private static $mailer_conf = null;

	protected static $client = false;

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(!defined('PL_CMS_EMAIL_SEND_EMAILS')) define('PL_CMS_EMAIL_SEND_EMAILS', false);	// @TODO why ??
			if(!PL_CMS_EMAIL_SEND_EMAILS) {
				if(Ccms_auth::is_cms_admin_user()) self::addMsg(self::$cDBcms->get_data_in_table('cms_configs','cms_config_name','cms_config_key = \'PL_CMS_EMAIL_SEND_EMAILS\'') . ' turned off.','info');
				self::$enabled = false;
				} // if
			else self::$enabled = self::is_plugin_enabled(self::PLUGIN);
			} // if
		return self::$enabled;
		} // is_enabled()

	protected static function is_smtp_host_starttls($host,$port) {
		$result = ''; $output = '';
		$cmd = 'echo | openssl s_client -connect ' . $host . ':' . $port . ' -starttls smtp | openssl x509 -noout';
		exec($cmd, $output, $result);
		if($result) return false;
		return true;
		} // is_smtp_host_starttls()

	protected static function is_smtp_host_ssl($host,$port) {
		$result = ''; $output = '';
		$cmd = 'echo | openssl s_client -connect ' . $host . ':' . $port . ' | openssl x509 -noout';
		exec($cmd, $output, $result);
		if($result) return false;
		return true;
		} // is_smtp_host_ssl()

	protected static function &get_mailer_conf() {
		if(empty(self::$mailer_conf)) {
			self::$mailer_conf = [];	// array
			$sql_query = 'SELECT cms_config_key,cms_config_value FROM cms_configs WHERE cms_config_key like \'PL_CMS_EMAIL_SMTP_%\'';
			if($result = Ccms::$cDBcms->query($sql_query)) {
				while($row = Ccms::$cDBcms->fetch_array($result)) {
					$key = preg_replace('/^PL_CMS_EMAIL_SMTP_/','',$row['cms_config_key']);
					self::$mailer_conf[$key] = $row['cms_config_value'];
					} // while
				if(self::$mailer_conf['SECURE'] == 'auto') {
					$host = self::$mailer_conf['HOST'];
					$port = self::$mailer_conf['PORT'];
					if(self::is_smtp_host_starttls($host, $port)) self::$mailer_conf['SECURE'] = 'tls';
					else if(self::is_smtp_host_ssl($host, $port)) self::$mailer_conf['SECURE'] = 'ssl';
					else self::$mailer_conf['SECURE'] = '';	// no secure
					} // if
				} // if
			} // if
		return self::$mailer_conf;
		} // get_mailer_conf()

	protected static function open_mailer() {
		if(self::$client !== false) return true;	// already open
		$mailer_conf = self::get_mailer_conf();
		$inc_file = CMS_FS_PLUGINS_DIR . self::PLUGIN . '/email_client_' . $mailer_conf['MAILER2USE'] . '.php';	//
		$class = 'Cemail_client_' . $mailer_conf['MAILER2USE'];
		if(!file_exists($inc_file)) {
			self::addAdminMsg('Mailer Class File: ' . $inc_file . ' does not exist.');
			return false;
			} // if
		require_once $inc_file;	// include extra code
		self::$client = new $class($mailer_conf,'X-Mailer: ' . trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME)) . ' Mailer');
		return true;
		} // open_mailer()

	public static function has_been_sent() {
		if(!$em = self::get_cms_sess_var('emailed')) return false;
		return $em;
		} // has_been_sent()

	public static function send(	// send email
			$from_name,
			$from_address,
			$email_text,
			$email_subject = '',
			$to_name = '',
			$to_address = ''
			) {
		if (!PL_CMS_EMAIL_SEND_EMAILS) return false;
		if(!self::open_mailer()) return false;

		// Send message
		$retval = self::$client->send(
			$to_name,
			$to_address,
			$email_subject,
			$email_text,
			$from_name,
			$from_address,
			$attached_filenames);

		if (($ccFlg) && ($retval) &&
			(defined ('PL_CMS_EMAIL_CC_EMAIL_ADDRESS')) &&
			(strlen(PL_CMS_EMAIL_CC_EMAIL_ADDRESS) > 4)) {
				// send emails to other people
				$client->send(
					$to_name,
					PL_CMS_EMAIL_CC_EMAIL_ADDRESS,
					$email_subject . ' (cc)',
					$email_text,
					$from_name,
					$from_address,
					$attached_filenames);
			} // if
		self::set_cms_sess_var($retval,'emailed');
		return $retval;
		} // send()

	public static function send_out_mail(	// send out an email from the server
			$to_name,
			$to_address,
			$email_text,
			$email_subject,
			$from_name = '',
			$from_address = '',
			$attached_filenames = '',
			$ccFlg = true) {

		if(empty($email_text)) self::addMsg('No text message in contact email.','warning');
		if(empty($from_name)) $from_name = trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME));
		if(empty($from_address)) $from_address = CMS_C_EMAIL_ADDRESS;
		if(empty($email_subject)) self::addMsg('No send suject in email.');
		if(empty($to_name)) self::addMsg('No send name in email.');
		if(empty($to_address)) self::addMsg('No send email address.');
		if(Ccms::getMsgsCount('error')) return false;

		if (!PL_CMS_EMAIL_SEND_EMAILS) return false;
		if(!self::open_mailer()) return false;

		// Send message
		$retval = self::$client->send(
			$to_name,
			$to_address,
			$email_subject,
			$email_text,
			$from_name,
			$from_address,
			$attached_filenames);

		if (($ccFlg) && ($retval) &&
			(defined ('PL_CMS_EMAIL_CC_EMAIL_ADDRESS')) &&
			(strlen(PL_CMS_EMAIL_CC_EMAIL_ADDRESS) > 4)) {
				// send emails to other people
				self::$client->send(
					$to_name,
					PL_CMS_EMAIL_CC_EMAIL_ADDRESS,
					$email_subject . ' (cc)',
					$email_text,
					$from_name,
					$from_address,
					$attached_filenames);
			} // if
		self::set_cms_sess_var($retval,'emailed');
		return $retval;
	} // send_out_mail()

	public static function get_title() {	// get the plugin title
		return 'Email';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Email plugin (' . self::PLUGIN . ') is an assistive plugin for sending emails from the web site.'
			. ' It is usually used by other plugins, but can be used directly in a .php file.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "SEND_EMAILS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Send Emails.",
				'cms_config_description' => "True = allow emails to be sent. False = no emails sent.",
				),	// row data
			array(
				'cms_config_key' => "USE_HTML",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Send HTML Emails.",
				'cms_config_description' => "True = allow emails to be sent in HTML. False = emails sent as plain text.",
				),	// row data
			array(
				'cms_config_key' => "CC_EMAIL_ADDRESS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "CC Email Address.",
				'cms_config_description' => "Email address to send carbon copies to. Leave empty no cc emails.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data

			// these have come from the CMS_FS_LIB_DIR PHPmailer
			array(
				'cms_config_key' => "SMTP_WORDWRAP",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "80",	// leave empty if no cc emails
				'cms_config_allowed_values' => "64:80:132:192:250:768",
				'cms_config_name' => "Mailer Wor Wrap.",
				'cms_config_description' => "Select the wordwrap to use.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_MAILER2USE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "PHPMailer_6",	// leave empty if no cc emails
				'cms_config_allowed_values' => "PHPMailer_5:PHPMailer_6",
				'cms_config_name' => "Mailer to Use.",
				'cms_config_description' => "Select the library mailer to use. Shown oldest to newest.<br>PHPMailer_5 is PHP 5 to 7, PHPMailer_6 is for PHP 7 and higher.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_HOST",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "localhost",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMTP Server Host.",
				'cms_config_description' => "Enter the SMTP email MTA hostname or IP address. Optional can contain the host:port format.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_PORT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "25",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMTP Server Default Port.",
				'cms_config_description' => "Enter the default SMTP email MTA port.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_AUTH",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "false",	// leave empty if no cc emails
				'cms_config_allowed_values' => "false:true",
				'cms_config_name' => "Use SMTP Server Authentication.",
				'cms_config_description' => "true = enable SMPT server authentication (need auth type, username and password to be configured), false = no authentication.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_AUTH_TYPE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "LOGIN",	// leave empty if no cc emails
				'cms_config_allowed_values' => "LOGIN:PLAIN:NTLM",
				'cms_config_name' => "SMTP Server Authentication Type.",
				'cms_config_description' => "Select SMPT server authentication type.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_USERNAME",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMTP Server Username.",
				'cms_config_description' => "Enter SMPT server user name.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_PASSWORD",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMTP Server Password.",
				'cms_config_description' => "Enter SMPT server password.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_SECURE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "auto",	// leave empty if no cc emails
				'cms_config_allowed_values' => "none:auto:ssl:tls",
				'cms_config_name' => "SMTP Server Security.",
				'cms_config_description' => "Select the SMTP email MTA secure mode.<br>none = no encryption, auto = check what SMPTP server needs (slow), ssl = SSL, tls = STARTTLS.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_TIMEOUT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "10",	// leave empty if no cc emails
				'cms_config_allowed_values' => "10:20:30:60:120:180:300",
				'cms_config_name' => "SMTP Server Timeout.",
				'cms_config_description' => "Select the SMTP server timeout.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_DEBUG",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "false",	// leave empty if no cc emails
				'cms_config_allowed_values' => "false:true",
				'cms_config_name' => "SMTP Server Debug.",
				'cms_config_description' => "true = provide debug information, false turn off debug information.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data
			array(
				'cms_config_key' => "SMTP_DEBUG_OUTPUT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "echo",	// leave empty if no cc emails
				'cms_config_allowed_values' => "echo:error_log",
				'cms_config_name' => "SMTP Server Debug Output.",
				'cms_config_description' => "echo = echo debug information to output (usually the browser), error_log = log debug inforamtion to error_log.<br>Note: requires SMPTP debug to be enabled.",
				// "cms_config_save_func" => "",	// uses a standard config check function get_email()
				),	// row data

			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_email_plugin