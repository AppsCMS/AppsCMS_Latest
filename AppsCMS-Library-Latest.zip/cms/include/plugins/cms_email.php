<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_email.php 3232 2023-02-28 01:59:42Z robert0609 $
 */

/**
 * Description of Email plugin
 * primary access file to this plugin
 * access to plugins is always via classes
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */


class Ccms_email_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_email';
	protected static $enabled = null;

	function __construct() {
		self::is_enabled();
		} // __construct()

	function __destruct() {
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(!defined('PL_CMS_EMAIL_SEND_EMAILS')) define('PL_CMS_EMAIL_SEND_EMAILS', false);	// @TODO why ??
			if(!PL_CMS_EMAIL_SEND_EMAILS) {
				if(Ccms_auth::is_cms_admin_user()) self::addMsg(self::$cDBcms->get_data_in_table('cms_configs','cms_config_name','cms_config_key = \'PL_CMS_EMAIL_SEND_EMAILS\'') . ' turned off.','info');
				self::$enabled = false;
				} // if
			else self::$enabled = self::is_plugin_enabled(self::PLUGIN);
			} // if
		return self::$enabled;
		} // is_enabled()

	public static function has_been_sent() {
		if(!$em = self::get_cms_sess_var('emailed')) return false;
		return $em;
		} // has_been_sent()

	public static function send(	// send email
			$from_name,
			$from_address,
			$email_text,
			$email_subject = '',
			$to_name = '',
			$to_address = ''
			) {
		if (!PL_CMS_EMAIL_SEND_EMAILS) return false;
		require_once CMS_FS_PLUGINS_DIR . self::PLUGIN . '/email_client.php';	// include extra code
		$client = new Cemail_client('X-Mailer: ' . trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME)) . ' Mailer');

		// Send message
		$retval = $client->send(
			$to_name,
			$to_address,
			$email_subject,
			$email_text,
			$from_name,
			$from_address,
			$attached_filenames);

		if (($ccFlg) && ($retval) &&
			(defined ('PL_CMS_EMAIL_CC_EMAIL_ADDRESS')) &&
			(strlen(PL_CMS_EMAIL_CC_EMAIL_ADDRESS) > 4)) {
				// send emails to other people
				$client->send(
					$to_name,
					PL_CMS_EMAIL_CC_EMAIL_ADDRESS,
					$email_subject . ' (cc)',
					$email_text,
					$from_name,
					$from_address,
					$attached_filenames);
			} // if
		self::set_cms_sess_var($retval,'emailed');
		return $retval;
		} // send()

	public static function send_out_mail(	// send out an email from the server
			$to_name,
			$to_address,
			$email_text,
			$email_subject,
			$from_name = '',
			$from_address = '',
			$attached_filenames = '',
			$ccFlg = true) {

		if(empty($email_text)) self::addMsg('No text message in contact email.','warning');
		if(empty($from_name)) $from_name = trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME));
		if(empty($from_address)) $from_address = CMS_C_EMAIL_ADDRESS;
		if(empty($email_subject)) self::addMsg('No send suject in email.');
		if(empty($to_name)) self::addMsg('No send name in email.');
		if(empty($to_address)) self::addMsg('No send email address.');
		if(Ccms::getMsgsCount('error')) return false;

		if (!PL_CMS_EMAIL_SEND_EMAILS) return false;
		require_once CMS_FS_PLUGINS_DIR . self::PLUGIN . '/email_client.php';	// include extra code
		$client = new Cemail_client('X-Mailer: ' . trim(preg_replace('/&\w*;/i', '', CMS_C_CO_NAME)) . ' Mailer');

		// Send message
		$retval = $client->send(
			$to_name,
			$to_address,
			$email_subject,
			$email_text,
			$from_name,
			$from_address,
			$attached_filenames);

		if (($ccFlg) && ($retval) &&
			(defined ('PL_CMS_EMAIL_CC_EMAIL_ADDRESS')) &&
			(strlen(PL_CMS_EMAIL_CC_EMAIL_ADDRESS) > 4)) {
				// send emails to other people
				$client->send(
					$to_name,
					PL_CMS_EMAIL_CC_EMAIL_ADDRESS,
					$email_subject . ' (cc)',
					$email_text,
					$from_name,
					$from_address,
					$attached_filenames);
			} // if
		self::set_cms_sess_var($retval,'emailed');
		return $retval;
	} // send_out_mail()

	public static function get_title() {	// get the plugin title
		return 'Email';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Email plugin (' . self::PLUGIN . ') is an assistive plugin for sending emails from the web site.'
			. ' It is usually used by other plugins, but can be used directly in a .php file.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "SEND_EMAILS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Send Emails.",
				'cms_config_description' => "True = allow emails to be sent. False = no emails sent.",
				),	// row data
			array(
				'cms_config_key' => "USE_HTML",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Send HTML Emails.",
				'cms_config_description' => "True = allow emails to be sent in HTML. False = emails sent as plain text.",
				),	// row data
			array(
				'cms_config_key' => "CC_EMAIL_ADDRESS",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",	// leave empty if no cc emails
				'cms_config_allowed_values' => "",
				'cms_config_name' => "CC Email Address.",
				'cms_config_description' => "Email address to send carbon copies to. Leave empty no cc emails.",
				"cms_config_save_func" => "get_email",	// uses a standard config check function get_email()
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_email_plugin