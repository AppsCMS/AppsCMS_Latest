<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_yandex.php 3436 2024-04-28 04:15:19Z robert0609 $
 */

/**
 * Description
 * Ccms_language translate text to another language
 * using the Linux translate_shell (trans)
 * @TODO May add more as required/available
 *
 * @author robert0609
 */

class Ccms_yandex extends Ccms_translate_base {

	private static $yandex_langs = false;
	
	protected const YANDEX_LANG_CACHE_JSON = 'yandex_languages_cache.json';

	function __construct() {
		} // __construct()

	function __destruct() {
		} // __destruct()

// static methods
	public static function &get_yandex_languages() {
		if(!empty(self::$yandex_langs)) return self::$yandex_langs;	// do once
		
		$y_cache = VAR_FS_TRANSLATIONS_DIR . self::YANDEX_LANG_CACHE_JSON;
		if((is_readable($y_cache )) &&
			((filemtime($y_cache) + Ccms_translate_cache::get_translate_cache_timeout()) < time())) {
			self::$yandex_langs = self::load_json($y_cache);
			return self::$yandex_langs['langs'];
			} // if

		// see "https://yandex.com/dev/translate/doc/dg/reference/getLangs.html"

		$data = array(
			'key' => PL_CMS_TRANSLATE_YANDEX_API_KEY,
			'ui' => Ccms_translate_plugin::get_lang_from(),
			);

		$url = PL_CMS_TRANSLATE_YANDEX_API1_URL . '/getLangs';
		$url .= '?' . http_build_query($data);

		$hdrs_response_info = self::get_lang_trans_curl_response($url);
		if(empty($hdrs_response_info['result']['langs'])) return self::$yandex_langs;
		self::$yandex_langs = $hdrs_response_info['result'];
		self::save_json($y_cache,self::$yandex_langs);
		return self::$yandex_langs['langs'];
		} // get_yandex_languages()

	protected static function yandex_api1_trans_lang_line($from_text,$html_fmt = true) {
		// see "https://yandex.com/dev/translate/doc/dg/reference/translate.html"
		// Bash example: Sending request and parse JSON string
		//    request=$(curl -sb -H "Accept: application/json" \
		//		"https://translate.yandex.net/api/v1.5/tr.json/translate?key=$apiKey&text=$text&lang=$firstLang-$lastLang" | jq '.text[0]')
		//    # Remove double quotes from a string
		//    request=${request//\"}
		//    # Sending notifications
		//    notify-send Translate: -i edit-paste "$request"
		//    # Copy the result to clipboard
		//    echo "$request" | xclip -selection clipboard

		$data = array(
			'text' => $from_text,
			'key' => PL_CMS_TRANSLATE_YANDEX_API_KEY,
			'format' => ($html_fmt ? 'html':'plain'),
			'lang' => preg_replace('/\W.*$/','',Ccms_translate_plugin::get_lang_from()) . '-' . preg_replace('/\W.*$/','',Ccms_translate_plugin::get_lang_to()),
			'options' => 1,
			);

		$url = PL_CMS_TRANSLATE_YANDEX_API1_URL . '/translate';
		$url .= '?' . http_build_query($data);

		$hdrs_response_info = self::get_lang_trans_curl_response($url);

		if(empty($hdrs_response_info['result']['text'][0])) return false;
		return $hdrs_response_info['result']['text'][0];
		} // yandex_appi1_trans_lang_line()

//	protected static function yandex_api2_trans_lang_line($from_text,$make_entities = false,$html_fmt = true) {
//		// see "https://cloud.yandex.com/en/docs/translate/api-ref/Translation/translate"
//		$apiKey = PL_CMS_TRANSLATE_YANDEX_API_KEY;
//		$url = PL_CMS_TRANSLATE_YANDEX_API2_URL . '/translate';
//		$post = array(
//			'sourceLanguageCode' => urlencode(Ccms_translate_plugin::get_lang_from()),
//			'targetLanguageCode' => urlencode(Ccms_translate_plugin::get_lang_from()),
//			'format' => ($html_fmt ? 'HTML':'PLAIN_TEXT'),
//			'folderID' => '',
//			'speller' => true,
//			'texts' => array(
//				(is_array($from_text) ? $from_text: array($from_text)),
//				),
//			// 'model' => '',	// Do not specify this field, custom models are not supported yet.
//			'glossaryConfig' => array(	// see: https://cloud.yandex.com/docs/translate/concepts/glossary
//				'glossaryData' => array(
//					'glossaryPairs' => array(),
//					),
//				),
//			);
//		$pairs = &$posts['glossaryConfig']['glossaryData']['glossaryPairs'];
//		if(!is_array($from_text)) {
//			$pairs[] = array(
//				'sourceText' => $from_text,
//				'translatedText' => '',
//				'exact' => true,
//				);
//			} // if
//		else {
//			foreach($from_text as $text) {
//				$pairs[] = array(
//					'sourceText' => $text,
//					'translatedText' => '',
//					'exact' => true,
//					);
//				} // foreach
//		} // else
//
//		return $result['text'];
//		} // yandex_api2_trans_lang_line()

	public static function yandex_trans_lang_line($from_text,$make_entities = false) {
		// steering function
		$html_fmt = true;	// @TODO check it
		return self::yandex_api1_trans_lang_line($from_text,$html_fmt);
	} // yandex_trans_lang_line()

	public static function get_title() {	// get the plugin title
		return 'Yandex Trans';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Yandex for Translate Shell Interface.';
		} // get_description()

	public static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => 'YANDEX_API1_URL',
				'cms_config_value' => 'https://translate.yandex.net/api/v1.5/tr.json',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Yandex API V1 URL.',
				'cms_config_description' => 'The Yandex API V1 URL for the language translator.<br>' .
					'See: &quot; https://cloud.yandex.com/en/docs/translate/api-ref/v1/translate &quot;',
				),	// row data
			array(
				'cms_config_key' => 'YANDEX_API2_URL',
				'cms_config_value' => 'https://translate.api.cloud.yandex.net/translate/v2',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Yandex API V2 URL.',
				'cms_config_description' => 'The Yandex API V2 URL for the language translator.<br>' .
					'See: &quot; https://cloud.yandex.com/en/docs/translate/api-ref/Translation/translate &quot;',
				),	// row data
			array(
				'cms_config_key' => 'YANDEX_API_KEY',
				'cms_config_value' => '',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Yandex API Key.',
				'cms_config_description' => 'Obtain a Yendex API key from &quot; https://yandex.com/dev/keys/ &quot; web site.',
				),	// row data
			);
		} // get_sql_install_data()

} // Ccms_yandex
