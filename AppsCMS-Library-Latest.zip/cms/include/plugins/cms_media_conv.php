<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_media_conv.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of Ccms_media_conv_plugin
 *
 * Description of top level media converter plugin

 * primary access file to Authentication plugins* plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */

// include the classes
require_once(CMS_FS_LIB_DIR . 'parsedown-1.8.0/Parsedown.php');

class Ccms_media_conv_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_media_conv';

	protected static $enabled = null;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(!self::is_plugin_enabled(self::PLUGIN)) {
				self::addAdminMsg(self::PLUGIN . ' plugin is disabled.','warning');
				self::$enabled = false;
				} // if
			self::$enabled = true;
			} // if
		return self::$enabled;
		} // is_enabled()

	public static function get_file_href($uri,$name,$title = false,$uri_params = false) {
		if(!self::is_enabled()) {
			return '<A HREF="' . $uri . '">' . $name . '</A>';
			} // if
		$text = '<a href="index.php?cms_action=cms_text_view' .
			'&uri=' . rawurlencode($uri) .
			'&ret=' . rawurlencode(($_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'])) .
			($uri_params ? rawurlencode($uri_params):'') .
			'"';
		$text .= ($title ? ' title="' . $title . '"':'');
		$text .= '>';
		$text .= $name;
		$text .= '</a>';
		return $text;
		} // get_file_href()

	protected static function get_md2html_text(&$text) {
		if(!PL_CMS_MEDIA_CONV_MARKDOWN_ENABLE) return $text;
		// see "https://www.markdownguide.org/cheat-sheet/" as a guide.
		require_once(CMS_FS_LIB_DIR . 'parsedown-1.8.0/Parsedown.php');	// include the library
		return Parsedown::instance()
			->setBreaksEnabled(true) // enables automatic line breaks
			->setMarkupEscaped(true) // escapes markup (HTML)
			->text($text);
		} // get_md2html_text()

	protected static function get_ascii2html_text(&$text) {
		// if(!PL_CMS_MEDIA_CONV_ASCII_ENABLE) return $text;
		$html = htmlentities($text);
		return self::nl2br($html);
		} // get_ascii2html_text()

	protected static function get_img2html_text($uri,$alt = '') {
		$text = array();
		$text[] = '<div style="text-align: center;">';
		$text[] = '	<img' . (!empty($alt) ? ' alt="' . $alt . '"':'') . ' src="' . $uri . '">';
		$text[] = '</div>';
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // get_img2html_text()

	protected static function get_mp4html_text($uri) {
		$text = array();
		$text[] = '<div style="text-align: center;">';
		$text[] = '	<video width="320" height="240" controls>';
		$text[] = '		<source src="' . $uri . '" type="video/mp4">';
		$text[] = '		Your browser does not support the video tag.';
		$text[] = '	</video>';
		$text[] = '</div>';
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // get_mp4html_text()

	public static function get_text_file2html($uri, $type = false) {
		if(empty($uri)) {
			self::addMsg('Empty text file.','warning');
			return '';
			} // if
		if(file_exists($uri)) $filepath = $uri;
		else $filepath = DOCROOT_FS_BASE_DIR . $uri;
		if(!file_exists($filepath)) {
			self::addMsg('Could read "' . $filepath . '".','warning');
			return '';
			} // if
		if(!$type) {
			$pinfo = pathinfo($filepath);
			if(!isset($pinfo['extension'])) {
				$type = '';	// make message
				} // if
			else $type = $pinfo['extension'];
			} // if
		// just use extension for now
		switch(strtolower($type))	{
		case 'md':
			$text = file_get_contents($filepath);	// ok to read in (??)
			return self::get_md2html_text($text);
			break;
		case 'info':
		case 'txt':
			$text = file_get_contents($filepath);	// ok to read in (??)
			return self::get_ascii2html_text($text);
			break;
		case 'jpg':
		case 'jpeg':
		case 'png':
		case 'gif':
		case 'svg':
			return self::get_img2html_text($uri);
			break;
		case 'mp4':
			return self::get_mp4html_text($uri);
			break;
		default:
			self::addMsg('Unknown text file type "' . $filepath . '".','warning');
			break;
			} // switch
		return '';
		} // get_text_file2html()

	public static function prn_text_file2html($filepath, $type = false) {
		echo self::get_text_file2html($filepath, $type);
		} // prn_text_file2html()

	public static function get_title() {	// get the plugin title
		return 'Media Converter';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' media converter plugin (' . self::PLUGIN . ') converts markdown (.md) files to html.<br>' .
			'or encapsulates text (.txt) files as a preformatted output.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "MARKDOWN_ENABLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Enable Markdown Convert.",
				'cms_config_description' => "True = enable mark down converter. False = output text unchanged.",
				),	// row data
			array(
				'cms_config_key' => "ASCII_ENABLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Enable ASCII Convert.",
				'cms_config_description' => "True = enable ASCII/UTF8 converter. False = output text unchanged.",
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_media_conv_plugin
