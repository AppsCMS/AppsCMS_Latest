<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_translate.php 3232 2023-02-28 01:59:42Z robert0609 $
 */

/**
 * Description
 * Ccms_language translate text to another language
 * using the Linux translate_shell (trans)
 * @TODO May add more as required/available
 *
 * @author robert0609
 */

class Ccms_translate_cache extends Ccms_base {	// private class

	protected static $cache_dir = false;

	protected const CACHE_TIMEOUT = (3600 * 8);
	protected const TRANS_DIR = 'translations/';

	function __construct() {
		} // __construct()

	function __destruct() {
		} // __destruct()

	// static methods
	public static function init_trans_cache(&$from_lang ,&$to_lang){
		self::$cache_dir = VAR_FS_CACHE_DIR . self::TRANS_DIR . $from_lang . '/' . $to_lang . '/';
		if(!self::chkdir(self::$cache_dir)) return false;
		return true;
		} // init_trans_cache()

	public static function get_cached(&$text) {
		if(empty($text)) return '';
		$thash = md5($text);
		$cache = self::$cache_dir . $thash;
		if(is_readable($cache )) {
			if(filemtime($cache) < (time() - self::CACHE_TIMEOUT)) return false;
			return file_get_contents($cache);
			} // if
		return false;
		} // get_cached()

	public static function put_cached(&$text,&$transd) {
		if(empty($text)) return false;
		$thash = md5($text);
		$cache = self::$cache_dir . $thash;
		return file_put_contents($cache,$transd);
		} // put_cached()

	public static function clear_cached() {
		self::trash_path(VAR_FS_CACHE_DIR . self::TRANS_DIR);
		self::addAdminMsg('Cleared translation cache.','info');
		} // clear_cached()

} // Ccms_translate_cache

class Ccms_translate_plugin extends Ccms_plugin_base {

	const PLUGIN = 'cms_translate';
	protected static $enabled = null;

	protected static $no_trans_lang_prefixes = ['en','zh'];

	private static $trans_langs = false;
	private static $trans_engines = false;

	private static $yandex_langs = false;

	protected static $lang_from = false;
	protected static $lang_rep = array();	// replace these entities in from text

	protected static $lang_to = false;
	protected static $lang_rm = array();	// remove these entities from translation

	// list of engines from "trans -S"
	// possible: 'aspell:google:deepl:bing:spell:hunspell:apertium:yandex' ??
	// @TODO finish checking translation engines
	protected const LANG_TRANS_ENGINES = 'google:yandex';
	protected const LANG_TRANS_ENGINE_DEF = 'google';
	private static $trans_cmd = false;

	private static $engine = false;

	public const TRANS_METHOD = 'translate_shell';	// my method name
	protected const TRANS_AWK_CMS = 'translate_shell/trans.awk';

	protected static $err_log = false;

	function __construct() {
		} // __construct()

	function __destruct() {
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(!CMS_S_LANG_TRANSLATE_BOOL) self::$enabled = false;	// disabled
			else if(CMS_S_LANG_TRANS_METHOD == self::TRANS_METHOD) self::$enabled = true;	// enabled if selected
			else if(!self::is_plugin_enabled(self::PLUGIN)) {
				self::addAdminMsg(self::PLUGIN . ' plugin is disabled.','warning');
				self::$enabled = false;
				} // if
			else self::$enabled = true;
			} // if
		return self::$enabled;
		} // is_enabled()

// static methods
	public static function clean_translated() {
		Ccms_translate_cache::clear_cached();
		} // clean_translated()

	public static function get_def_engine() {
		if(defined('PL_CMS_TRANSLATE_LANG_TRANS_ENGINE')) return PL_CMS_TRANSLATE_LANG_TRANS_ENGINE;
		return self::LANG_TRANS_ENGINE_DEF;
		} // get_def_engine()

	public static function get_translate_languages() {
		if(!empty(self::$trans_langs)) return self::$trans_langs;	// do once

		if(empty(self::$engine)) self::$engine = self::get_def_engine();
		switch(self::$engine) {
		case 'yandex':
			self::$trans_langs = self::get_yandex_languages();
			break;
		default:
			// gets a formatted list of languages"
			$lpath = CMS_FS_LIB_DIR . 'translate_shell/trans_langs.json';
			if(!$trans_sh_langs = self::load_json($lpath)) {
				self::addAdminMsg('Cannot load: ' . $lpath);
				return false;
				} // if
			self::$trans_langs = $trans_sh_langs['trans_langs'];
			break;
			} // switch

		return self::$trans_langs;
		} // get_translate_languages()

	public static function get_translate_engines() {
		if(empty(self::$trans_engines)) {
			if(empty(self::$engine)) self::$engine = self::get_def_engine();
			switch(self::$engine) {
			case 'yandex':
				self::$trans_engines = array('Yandex');
				break;
			default:
				// gets a formatted list of engines"
				$epath = CMS_FS_LIB_DIR . 'translate_shell/trans_engines.json';
				if(!$trans_sh_engines = self::load_json($epath)) {
					self::addAdminMsg('Cannot load: ' . $epath);
					return false;
					} // if
				self::$trans_engines = $trans_sh_engines['trans_engines'];
				break;
				} // switch
			} // if
		return self::$trans_engines;
		} // get_translate_engines()

	protected static function get_lang_trans_curl_response($url) {
		$ch = curl_init($url);
		if(preg_match('/^http:\/\/.+/i',$url)) {
			curl_setopt($ch, CURLPROTO_HTTP, true);
			} // if
		else if(preg_match('/^https:\/\/.+/i',$url)) {
			curl_setopt($ch, CURLPROTO_HTTPS, true);
			} // else if
		else {
			curl_close($ch);	// don't run out of memory with orphans
			return null;	// what ???
			} // else
		curl_setopt($ch, CURLOPT_HEADER, true);	// we want headers
		curl_setopt($ch,CURLOPT_HTTPHEADER,array (
			'Content-Type: application/x-www-form-urlencoded',
			"Accept: application/json",
			));

		curl_setopt($ch, CURLOPT_NOBODY, false);	// dont need body
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
		curl_setopt($ch, CURLOPT_POSTREDIR, 7);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);	// catch output (do NOT print!)
		$timeout_mS = 15000;
		if($timeout_mS) {
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout_mS);
			curl_setopt($ch, CURLOPT_TIMEOUT_MS, ($timeout_mS * 2));
			} // if
		// if((int)$port > 10) curl_setopt ($ch, CURLOPT_PORT, (int)$port);
		$response = curl_exec($ch);
		$info = curl_getinfo($ch);
		curl_close($ch);	// don't run out of memory with orphans
		if($response === false) {
			self::log_msg('URL: "' . $url . '" failed to respond.','warn');
			return null;
			} // if
		$header = substr($response,0,($info['header_size'] - 0));
		$json = substr($response,($info['header_size'] - 0));
		$result = self::json_decode($json, true);
		if((!empty($result['code'])) && ($result['code'] != 200)) {
			self::addAdminMsg('Curl returned code: ' . $result['code'] . ' for: ' . $result['message']);
			return null;
			} // if
		if((!empty($result['http_code'])) && ($result['http_code'] != 200)) {
			self::addAdminMsg('Curl returned http code: ' . $result['http_code'] . ' for: ' . $result['message']);
			return null;
			} // if
		return array('info' => $info,'headers' => $header,'result' => $result);
		} // get_lang_trans_curl_response()

	public static function &get_yandex_languages() {
		if(!empty(self::$yandex_langs)) return self::$yandex_langs;	// do once

		// see "https://yandex.com/dev/translate/doc/dg/reference/getLangs.html"

		$data = array(
			'key' => PL_CMS_TRANSLATE_YANDEX_API_KEY,
			'ui' => self::$lang_from,
			);

		$url = PL_CMS_TRANSLATE_YANDEX_API1_URL . '/getLangs';
		$url .= '?' . http_build_query($data);

		$hdrs_response_info = self::get_lang_trans_curl_response($url);
		if(empty($hdrs_response_info['result']['langs'])) return false;
		self::$yandex_langs = $hdrs_response_info['result'];
		return self::$yandex_langs['langs'];
		} // get_yandex_languages()

	protected static function get_lang_helpers() {
		if(preg_match('/^zh/i',self::$lang_to)) {
			self::$lang_rm = array('，', '&#xFF0C;');	// remove these from the chinese output
			self::$lang_rep = array(',' => '.',"'" => '','"' => '');	// replace these in the english input
			} // if
		// else if ss
		} // get_lang_helpers

	private static function chk_awk_version($awk) {
		$ret = false;
		$out = false;
		if((exec($awk . ' --version',$out,$ret) !== false) && (!$ret)) {
			foreach($out as $l) {
				if(preg_match('/^.*awk [4-9]\./i',$l)) {	// V4 or higher
					return true;
					} // if
				} // foreach
			// return true;
			} // if
		return false;
		} // chk_awk_version()

	public static function trans_chk() {
		self::$err_log = self::get_current_error_logfile();
		if(empty(self::$engine)) return false;
		$engines = self::get_translate_engines();
		if(!in_array(self::$engine,$engines)) {
			self::addAdminMsg('Trans engine: ' . self::$engine . ' not found.');
			return false;
			} // if
		if(self::$engine == 'yandex') return true;

		$trans_awk_path = '"' . CMS_FS_LIB_DIR . self::TRANS_AWK_CMS . '"';
		if(Ccms_posix::is_windows()) {
			$awk_win_paths = array(	// use the direct awk command
				'C:\Program Files\Git\usr\bin\awk.exe',
				'C:\Program Files (x86)\GnuWin32\bin\gawk-4.0.0.exe',
				'C:\Program Files (x86)\GnuWin32\bin\awk-4.0.0.exe',
				'C:\Program Files (x86)\GnuWin32\bin\gawk.exe',	// old version
				'C:\Program Files (x86)\GnuWin32\bin\awk.exe',	// old version
				// 'C:\xampp\install\awk.exe',	// old version
				);
			foreach($awk_win_paths as $p) {
				if((file_exists($p)) && (self::chk_awk_version($p))) {
					self::$trans_cmd = '"' . $p . '"' . ' -f ' . $trans_awk_path . ' - ';
					return true;
					} // if
				} // foreach
			self::addAdminMsg('Could not find Windows awk.exe or gawk.exe');
			return false;
			} // if

		if(Ccms_posix::is_linux()) {	// try linux trans
			// try awk
			$awk_lin_cmds = array(	// use the system awk command
				'awk',
				'gawk',
				);
			foreach($awk_lin_cmds as $c) {
				$ret = false;
				$out = false;
				if((exec('which ' . $c,$out,$ret) !== false) && (!$ret) &&
					(self::chk_awk_version($c))) {
					self::$trans_cmd = $out[0] . ' -f ' . $trans_awk_path . ' - ';
					return true;
					} // if
				} // foreach

			// try system translate-shell
			$ret = false;
			$out = false;
			if((exec('which trans',$out,$ret) !== false) &&
				(!$ret)) {
				self::$trans_cmd = $out[0];
				return true;
				} // if
			self::addDebugMsg('Could not find Linux trans or awk or gawk.');
			return false;
			} // if
		return false;
		} // trans_chk()

	protected static function yandex_api1_trans_lang_line($from_text,$html_fmt = true) {
		// see "https://yandex.com/dev/translate/doc/dg/reference/translate.html"
		// Bash example: Sending request and parse JSON string
		//    request=$(curl -sb -H "Accept: application/json" \
		//		"https://translate.yandex.net/api/v1.5/tr.json/translate?key=$apiKey&text=$text&lang=$firstLang-$lastLang" | jq '.text[0]')
		//    # Remove double quotes from a string
		//    request=${request//\"}
		//    # Sending notifications
		//    notify-send Translate: -i edit-paste "$request"
		//    # Copy the result to clipboard
		//    echo "$request" | xclip -selection clipboard

		$data = array(
			'text' => $from_text,
			'key' => PL_CMS_TRANSLATE_YANDEX_API_KEY,
			'format' => ($html_fmt ? 'html':'plain'),
			'lang' => preg_replace('/\W.*$/','',self::$lang_from) . '-' . preg_replace('/\W.*$/','',self::$lang_to),
			'options' => 1,
			);

		$url = PL_CMS_TRANSLATE_YANDEX_API1_URL . '/translate';
		$url .= '?' . http_build_query($data);

		$hdrs_response_info = self::get_lang_trans_curl_response($url);

		if(empty($hdrs_response_info['result']['text'][0])) return false;
		return $hdrs_response_info['result']['text'][0];
		} // yandex_appi1_trans_lang_line()

//	protected static function yandex_api2_trans_lang_line($from_text,$make_entities = false,$html_fmt = true) {
//		// see "https://cloud.yandex.com/en/docs/translate/api-ref/Translation/translate"
//		$apiKey = PL_CMS_TRANSLATE_YANDEX_API_KEY;
//		$url = PL_CMS_TRANSLATE_YANDEX_API2_URL . '/translate';
//		$post = array(
//			'sourceLanguageCode' => urlencode(self::$lang_from),
//			'targetLanguageCode' => urlencode(self::$lang_to),
//			'format' => ($html_fmt ? 'HTML':'PLAIN_TEXT'),
//			'folderID' => '',
//			'speller' => true,
//			'texts' => array(
//				(is_array($from_text) ? $from_text: array($from_text)),
//				),
//			// 'model' => '',	// Do not specify this field, custom models are not supported yet.
//			'glossaryConfig' => array(	// see: https://cloud.yandex.com/docs/translate/concepts/glossary
//				'glossaryData' => array(
//					'glossaryPairs' => array(),
//					),
//				),
//			);
//		$pairs = &$posts['glossaryConfig']['glossaryData']['glossaryPairs'];
//		if(!is_array($from_text)) {
//			$pairs[] = array(
//				'sourceText' => $from_text,
//				'translatedText' => '',
//				'exact' => true,
//				);
//			} // if
//		else {
//			foreach($from_text as $text) {
//				$pairs[] = array(
//					'sourceText' => $text,
//					'translatedText' => '',
//					'exact' => true,
//					);
//				} // foreach
//		} // else
//
//		return $result['text'];
//		} // yandex_api2_trans_lang_line()

	public static function yandex_trans_lang_line($from_text,$make_entities = false) {
		// steering function
		$html_fmt = true;	// @TODO check it
		return self::yandex_api1_trans_lang_line($from_text,$html_fmt);
	} // yandex_trans_lang_line()

	private static function trans_lang_sanitize_text($from_text) {
		$text = preg_replace("/'/",'\\\'',$from_text);
		$text = preg_replace("/[\n\t]+/",' ',$text);
		return $text;
		} // trans_lang_sanitize_text()

	private static function trans_lang_line($from_text,$make_entities = false) {
		if(!empty(self::$lang_rep)) {
			if(is_array(self::$lang_rep)) {
				foreach(self::$lang_rep as $s => $r)
					$from_text = str_replace($s,$r,$from_text);
				} // if
			} // if
		$to_entity = Ccms_translate_cache::get_cached($from_text);
		if($to_entity !== false) return $to_entity;

		$ret = false;
		$out = false;
		$text = self::trans_lang_sanitize_text($from_text);
		// old version	$cmd = self::$trans_cmd . ' -no-warn -e ' . self::$engine . ' -b ' . self::$lang_from . ':' . self::$lang_to . " '" . $text . "'";
		$cmd = self::$trans_cmd . ' -no-warn -e ' . self::$engine . ' -b ' . self::$lang_from . ':' . self::$lang_to . ' "' . $text . '"';

		if(Ccms_posix::is_linux()) $cmd .= ' 2>>' . self::$err_log;

		if(exec($cmd,$out,$ret) === false) return null;
		if($ret) {
			self::addDebugMsg($cmd . ' returned error code: ' . $ret);
			return false;
			} // id
		if(is_array($out)) $text = implode(PHP_EOL,$out);
		else $text = $out;
		if(empty($text)) {
			$text = $from_text;
			Ccms_translate_cache::put_cached($from_text,$text);	// cache anyway because languages have unusual formating
//			self::addAdminMsg('Translation from ' .
//					self::$lang_from . ' to ' . self::$lang_to .
//					' failed (Size: ' . strlen($from_text) . ').');
			return false;
			} // if

		// if((!empty($rm)) && (!is_array($rm))) $rm = explode(' ',$rm);
		$rm = self::$lang_rm;
		$to_entity = preg_replace_callback('/[\x{80}-\x{10FFFF}]/u', function ($m) use ($rm,$make_entities) {
			$char = current($m);
			if(($rm) && (in_array($char,$rm))) return '';
			if($make_entities) {
				$utf = iconv('UTF-8', 'UCS-4', $char);
				$ent = sprintf("&#x%s;", ltrim(strtoupper(bin2hex($utf)), "0"));
				if(($rm) && (in_array($ent,$rm))) return '';
				} // if
			else $ent = $char;
			return $ent;
			}, $text);
		// $to_entity = htmlentities($text);	//,(ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 | ENT_DISALLOWED),'ISO-8859-1',false);
		Ccms_translate_cache::put_cached($from_text,$to_entity);
		return  $to_entity;
		} // trans_lang_line()

	public static function trans_lang($from_text,$make_entities = false) {	// using linux translate-shell (trans cli)
		if(empty($from_text)) return $from_text;
		if(self::$lang_from == self::$lang_to) return $from_text;

		// else it's translate_shell wonder
		if(is_array($from_text)) {
			$transd = array();
			foreach($from_text as $k => &$t) {
				if(empty($t)) continue;
				$transd[$k] = self::trans_lang($t,$make_entities);
				if(is_null($transd[$k])) return false;	// something big is wrong
				} // foreach
			return $transd;
			} //if
		switch(self::$engine) {	// single text (not an array)
		case 'yandex':
			return self::yandex_trans_lang_line($from_text,$make_entities);
			break;
		default:
			break;
			} // switch
		return self::trans_lang_line($from_text,$make_entities);
		} // trans_lang()

	private static function chk_lang($lang) {
		switch(self::$engine) {
		case 'yandex':
		case 'google':
			$chkd = preg_replace('/[-_]+.*$/','',$lang);	// translators don't know hyphenated langs
			break;
		default:
			$chkd = str_replace('_','-',$lang);
			break;
			} // switch
		return $chkd;
		} // chk_lang()

	public static function sanitize_langs(&$langs) {
		if((!is_array($langs)) || (empty($langs['from_lang'])) || (empty($langs['to_lang']))) return false;
		$langs['from_lang'] = self::chk_lang($langs['from_lang']);
		$langs['to_lang'] = self::chk_lang($langs['to_lang']);
		if(!self::is_enabled()) return false;
		$from = preg_replace('/^([a-z]*).*$/i','$1',$langs['from_lang']);
		$to = preg_replace('/^([a-z]*).*$/i','$1',$langs['to_lang']);
		if($from == $to) {
			if(in_array($to,self::$no_trans_lang_prefixes)) return false;
			}
		if(preg_replace('/^([a-z]*).*$/i','$1',$langs['from_lang']) == preg_replace('/^([a-z]*).*$/i','$1',$langs['to_lang'])) return false;
		return (($langs['from_lang'] != $langs['to_lang']) ? $langs:false);
		} // sanitize_langs()
		
	public static function trans_init(&$lang) {
		if(!self::is_enabled()) return false;
		if(!self::sanitize_langs($langs)) return false;
		self::$lang_from = $langs['from_lang'];
		self::$lang_to = $langs['to_lang'];
		if($lang_to == $lang_from) return true;
		self::$engine = self::get_def_engine();
		if(!self::trans_chk()) return false;
		Ccms_translate_cache::init_trans_cache(self::$lang_from,self::$lang_to);
		self::get_lang_helpers();
		return true;
		} // trans_init()

	public static function get_title() {	// get the plugin title
		return 'Trans';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Translate Shell Interface plugin (' . self::PLUGIN . ') using online/external language translation.' .
				'<br>';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => 'LANG_TRANS_ENGINE',
				'cms_config_value' => self::LANG_TRANS_ENGINE_DEF,
				'cms_config_allowed_values' => implode(':',self::get_translate_engines()),
				'cms_config_name' => 'Translation engine.',
				'cms_config_description' => 'Select &quot;translate shell&quot; translation engine.',
				),	// row data
			array(
				'cms_config_key' => 'YANDEX_API1_URL',
				'cms_config_value' => 'https://translate.yandex.net/api/v1.5/tr.json',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Yandex API V1 URL.',
				'cms_config_description' => 'The Yandex API V1 URL for the language translator.<br>' .
					'See: &quot; https://cloud.yandex.com/en/docs/translate/api-ref/v1/translate &quot;',
				),	// row data
			array(
				'cms_config_key' => 'YANDEX_API2_URL',
				'cms_config_value' => 'https://translate.api.cloud.yandex.net/translate/v2',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Yandex API V2 URL.',
				'cms_config_description' => 'The Yandex API V2 URL for the language translator.<br>' .
					'See: &quot; https://cloud.yandex.com/en/docs/translate/api-ref/Translation/translate &quot;',
				),	// row data
			array(
				'cms_config_key' => 'YANDEX_API_KEY',
				'cms_config_value' => '',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Yandex API Key.',
				'cms_config_description' => 'Obtain a Yendex API key from &quot; https://yandex.com/dev/keys/ &quot; web site.',
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_translate_plugin
