<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_map_location.php 3251 2023-03-02 12:50:06Z robert0609 $
 */

/**
 * Description of Ccms_map_location_plugin
 *
 * Description of map address location plugin
 * see "https://developers.google.com/maps/documentation/js/examples/places-autocomplete#maps_places_autocomplete-html"
 * Note: don't use the "git clone -b sample-places-autocomplete https://github.com/googlemaps/js-samples.git"
 *	The subsequent npm i loads 85MB of rubbish on the server.
 * 
 * @author robert0609
 */

class Ccms_map_location_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_map_location';

	protected static $enabled = null;

	const CACHE_TTL_SECS = (24 * 3600);	// 1 day

	function __construct() {
		parent::__construct();
		self::is_enabled();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(!self::is_plugin_enabled(self::PLUGIN)) {
				self::addAdminMsg(self::PLUGIN . ' plugin is disabled.','warning');
				self::$enabled = false;
				} // if
			else if((!define('PL_CMS_MAP_LOCATION_GOOGLE_API_KEY')) ||
				(strlen(PL_CMS_MAP_LOCATION_GOOGLE_API_KEY) < 12)) {
				self::$enabled = false;
				} // else if
			else self::$enabled = true;
			} // if
		return self::$enabled;
		} // is_enabled()
		
	protected static function get_styles() {
		
		$text = '	<style>' . PHP_EOL;
		$css_file = CMS_WS_PLUGINS_DIR . self::PLUGIN . '/map_location.css';
		$min_file = Ccms_minify_plugin::minify_css($css_file);
		$text .= file_get_contents(DOCROOT_FS_BASE_DIR . $min_file) . PHP_EOL;
		$text .= '	</style>' . PHP_EOL;
		return $text;
		} // get_styles()
		
	protected static function get_js() {
			
		$text = '	<script type="text/javascript">' . PHP_EOL;
		$js_file = CMS_WS_PLUGINS_DIR . self::PLUGIN . '/map_location.js';
		$min_file = Ccms_minify_plugin::minify_js($js_file);
		$text .= file_get_contents(DOCROOT_FS_BASE_DIR . $min_file) . PHP_EOL;
		$text .= '	</script>' . PHP_EOL;
		return $text;
		} // get_js

	public static function show_map_location_address($value, $col_heads) {
		// just show the address line (not a map). Keep it simple.
		return $value;	// just a comma seperated string
		} // show_map_location_address()

	public static function input_map_location_address($name,$value,$col_heads) {
		// This example requires the Places library. Include the libraries=places
		// parameter when you first load the API. For example:
		// See: "https://developers.google.com/maps/documentation/js/examples/places-autocomplete"
		// 
		// <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

		// put the parts together
		global $loc_name,$loc_value;

		$text =array();
//		if((!CMS_S_POLYFILLIO_BOOL) ||
//			(strlen(CMS_S_POLYFILLIO_URL) < 8)) {	// add polyfill io for browser compatiblity, not done by system
//			$text[] = '		<script type="text/javascript" src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>';
//			} // if
		$text[] = self::get_styles();

		$loc_name = $name;
		$loc_value = $value;
		$php_file = CMS_FS_PLUGINS_DIR . self::PLUGIN . '/map_location.php';
		ob_start();
		include($php_file);
		$text[] = ob_get_clean();
		
		$text[] = self::get_js();
		$text[] = '		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=' . PL_CMS_MAP_LOCATION_GOOGLE_API_KEY . '&callback=loc_initMap&libraries=places&v=weekly" defer></script>';
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // input_map_location_address()

	public static function save_map_location_address($name,$value,$col_heads) {
		if(empty($value)) $value = self::get_or_post($name);
		return $value;	// just a comma seperated string
		} // save_map_location_address ()

		
	public static function get_title() {	// get the plugin title
		return 'Map Location Address';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' map address location lookup plugin (' . self::PLUGIN . '), using Google Maps API.';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => 'GOOGLE_API_KEY',
				'cms_config_value' => '',
				'cms_config_allowed_values' => '',
				'cms_config_name' => 'Google API Key.',
				'cms_config_description' => 'Enter the Google API key.<br>See: &quot;https://developers.google.com/maps/documentation/js/get-api-key &quot;.',
				),	// row data
//			array(
//				'cms_config_key' => 'SAMPLE',
//				'cms_config_value' => '600',
//				'cms_config_allowed_values' => 'min=60:max=7200',
//				'cms_config_name' => 'Client Browser Geolocation Time to Live.',
//				'cms_config_description' => 'Sets the number of seconds before the client Geo location is refreshed. Stops repeated Share Location pop ups from client browser.',
//				'cms_config_show_func' => 'show_number',
//				'cms_config_input_func' => 'input_number',
//				'cms_config_save_func' => 'save_number',
//				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_map_location_plugin
