<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_geoip.php 3366 2023-07-20 07:23:55Z robert0609 $
 */

/**
 * Description of Ccms_geoip_plugin
 *
 * Description of Geo plugin
 * Plugin to (try) to sort out the geoip location data and code
 * plugin name is the name of this file (without the extension)
 *
 * @author robert0609
 */

class Ccms_geoip_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_geoip';
	protected static $enabled = null;

	protected static $geoip_cache = array();

	const CACHE_TTL_SECS = (24 * 3600);	// 1 day

	function __construct() {
		parent::__construct();
		self::is_enabled();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		if(is_null(self::$enabled)) {	// time saver
			if(!self::is_plugin_enabled(self::PLUGIN)) {
				self::addAdminMsg(self::PLUGIN . ' plugin is disabled.','warning');
				self::$enabled = false;
				} // if
			else self::$enabled = true;
			} // if
		return self::$enabled;
		} // is_enabled()

	private static function get_geoip_cache_file($ip) {
		$dir = VAR_FS_CACHE_DIR . 'MAXMIND/';
		if(!self::chkdir($dir)) return false;
		return $dir . $ip . '-cache.json';
		} // get_geoip_cache_file()

	private static function read_geoip_cache($ip, $key = false) {	// speed lookup
		if(empty(self::$geoip_cache[$ip])) {
			if(!$file = self::get_geoip_cache_file($ip)) return false;
			if(file_exists($file)) self::$geoip_cache[$ip] = self::load_json($file);
			else self::$geoip_cache[$ip] = array();
			if((empty(self::$geoip_cache[$ip]['ttl'])) ||
				((int)self::$geoip_cache[$ip]['ttl'] < time())) self::$geoip_cache[$ip] = array();
			} // if
		if(!empty($key)) {
			if(!empty(self::$geoip_cache[$ip][$key]))
				return self::$geoip_cache[$ip][$key];
			return false;
			} // if
		return self::$geoip_cache[$ip];
		} // read_geoip_cache()

	private static function write_geoip_cache($ip, $key, $value) {	// speed lookup
		$cache = self::read_geoip_cache($ip);
		$cache[$key] = $value;
		$cache['ip'] = $ip;
		$cache['ttl'] = time() + self::CACHE_TTL_SECS;
		if(!$file = self::get_geoip_cache_file($ip)) return false;
		if(!self::save_json($file, $cache)) {
			self::addDebugMsg('Failed to MAXMIND cache: ' . basname($file));
			return false;
			} // if
		return true;
		} // write_geoip_cache()

	// @TODO add MM cache

	protected static function get_MM_geoip_record($ip,$mmdb) {
		include_once(CMS_FS_LIB_DIR . 'maxmind_geoip.php');
		return Cmaxmind_geoip::get_MM_geoip_data($ip,$mmdb);
		} // get_MM_geoip_record()

	protected static function get_MM_geoip_record_ASN($ip, $lang) {
		if((!defined('PL_CMS_GEOIP_MAXMIND_ASN_MMDB')) ||
			(strlen(PL_CMS_GEOIP_MAXMIND_ASN_MMDB) < 5) ||
			(!file_exists(PL_CMS_GEOIP_MAXMIND_ASN_MMDB))) return false;
		if($record = self::get_MM_geoip_record($ip,PL_CMS_GEOIP_MAXMIND_ASN_MMDB)) {

			} // if
		return false;
		} // get_MM_geoip_record_ASN()

	protected static function get_MM_geoip_record_country($ip, $lang) {
		if((!defined('PL_CMS_GEOIP_MAXMIND_COUNTRY_MMDB')) ||
			(strlen(PL_CMS_GEOIP_MAXMIND_COUNTRY_MMDB) < 5) ||
			(!file_exists(PL_CMS_GEOIP_MAXMIND_COUNTRY_MMDB))) return false;
		if($record = self::get_MM_geoip_record($ip,PL_CMS_GEOIP_MAXMIND_COUNTRY_MMDB)) {
			return $record->country->name;
			} // if
		return false;
		} // get_MM_geoip_record_country()

	protected static function get_MM_geoip_record_city($ip, $lang) {
		if((!defined('PL_CMS_GEOIP_MAXMIND_CITY_MMDB')) ||
			(strlen(PL_CMS_GEOIP_MAXMIND_CITY_MMDB) < 5) ||
			(!file_exists(PL_CMS_GEOIP_MAXMIND_CITY_MMDB))) return false;
		if($record = self::get_MM_geoip_record($ip,PL_CMS_GEOIP_MAXMIND_CITY_MMDB)) {
			$record->city->name;
			} // if
		return false;
		} // get_MM_geoip_record_city()

	protected static function get_MM_geoip_account_data($ip, $lang) {
		// see "https://dev.maxmind.com/geoip/geolocate-an-ip/web-services?lang=en"

		// Retrieve data for an arbitrary IP address.
		// curl -u "{account_id}:{license_key}" "https://geoip.maxmind.com/geoip/v2.1/country/{ip_address}?pretty"
		// or curl -u "{account_id}:{license_key}" "https://geolite.info/geoip/v2.1/country/{ip_address}?pretty"

		if(empty($ip)) return false;
		if((!defined('PL_CMS_GEOIP_MAXMIND_ACCOUNT')) ||
			(strlen(PL_CMS_GEOIP_MAXMIND_ACCOUNT) < 5)) {
			self::addDebugMsg('No MAXMIND accout number.');
			return false;
			} // if
		if((!defined('PL_CMS_GEOIP_MAXMIND_LICENSE_KEY')) ||
			(strlen(PL_CMS_GEOIP_MAXMIND_LICENSE_KEY) < 5)) {
			self::addDebugMsg('No MAXMIND licence key.');
			return false;
			} // if
		if((!defined('PL_CMS_GEOIP_MAXMIND_URL')) ||
			(strlen(PL_CMS_GEOIP_MAXMIND_URL) < 5)) {
			self::addDebugMsg('No MAXMIND URL.');
			return false;
			} // if

		$user = PL_CMS_GEOIP_MAXMIND_ACCOUNT . ':' . PL_CMS_GEOIP_MAXMIND_LICENSE_KEY;
		$url = preg_replace('/\{ip_address\}|\{ip\}|\{address\}/i',$ip,PL_CMS_GEOIP_MAXMIND_URL);

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_USERPWD, $user);
		// curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		// curl_setopt($ch, CURLOPT_USERAGENT, $this->_getUserAgent());
		$result = curl_exec($ch);
		curl_close($ch);
		if(empty($result)) return false;
		$data = self::json_decode($result,true);
		if(!empty($data['error'])) {
			self::addDebugMsg('MAXMIND: ' . $data['code'] . ', ' . $data['error']);
			return false;
			} // if
		return $data;
		} // get_MM_geoip_account_data()

	protected static function get_MM_geoip_country($ip, $lang = 'en') {
		// try GeoIP system package first
//		if($country = self::get_MM_geoip_record_country($ip, $lang)) {
//			return $country;
//			} // if
//		// if(!self::is_plugin_enabled(self::PLUGIN)) return false;
		if($data = self::get_MM_geoip_account_data($ip, $lang)) {
			if(!empty($data['country']['names'][$lang]))
				return $data['country']['names'][$lang];
			} // if
		return false;
		} // get_MM_geoip_country()

	public static function get_geoip_country($ip, $lang = 'en') {
		$country = self::read_geoip_cache($ip, 'country');
		if(!empty($country)) return $country;	// cached

		if(function_exists('geoip_country_name_by_name')) {
			$country = geoip_country_name_by_name($ip, $lang);
			if(!empty($country)) {
				self::read_geoip_cache($ip, 'country', $country);
				return $country;
				} // if
			} // if
		$country = self::get_MM_geoip_country($ip, $lang);
		if(!empty($country)) {
			self::write_geoip_cache($ip, 'country', $country);
			return $country;
			} // if
		return false;
		} // get_geoip_country()

	public static function get_title() {	// get the plugin title
		return 'Geo';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' Geo Location plugin (' . self::PLUGIN . ') is data lookup plugin for geo location data.' .
				'<br>';
		} // get_description()

	protected static function get_sql_install_data() {
		return array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => 'BROWSER_GEOLOCATE_ALLOW',
				'cms_config_value' => 'false',
				'cms_config_allowed_values' => 'true:false',
				'cms_config_name' => 'Allow Client Browser Geolocation Records.',
				'cms_config_description' => 'True = allow the client browser location (latitude and longitude) is recorded for the session (requires SSL connection), false = disables client brwser geolocation.',
				),	// row data
			array(
				'cms_config_key' => 'BROWSER_GEOLOCATE_TTL',
				'cms_config_value' => '600',
				'cms_config_allowed_values' => 'min=60:max=7200',
				'cms_config_name' => 'Client Browser Geolocation Time to Live.',
				'cms_config_description' => 'Sets the number of seconds before the client Geo location is refreshed. Stops repeated Share Location pop ups from client browser.',
				'cms_config_show_func' => 'show_number',
				'cms_config_input_func' => 'input_number',
				'cms_config_save_func' => 'save_number',
				),	// row data
			array(
				'cms_config_key' => "MAXMIND_ENABLE_ACCT",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "disabled",
				'cms_config_allowed_values' => "enabled:disabled",
				'cms_config_name' => "MAXMIND Enable Account.",
				'cms_config_description' => "True = use MAXMIND geoip location. False = no MAXMIND geoip location.",
				),	// row data
			array(
				'cms_config_key' => 'MAXMIND_URL',
				'cms_config_name' => 'MAXMIND URL.',
				'cms_config_description' => 'Enter MAXMIND check API url.<br>e.g. https://geoip.maxmind.com/geoip/v2.1/country/{ip_address}?pretty or https://geolite.info/geoip/v2.1/country/{ip_address}?pretty',
				),	// row data
			array(
				'cms_config_key' => 'MAXMIND_ACCOUNT',
				'cms_config_name' => 'MAXMIND Account Number.',
				'cms_config_description' => 'Enter MAXMIND account number.',
				),	// row data
			array(
				'cms_config_key' => 'MAXMIND_LICENSE_KEY',
				'cms_config_name' => 'MAXMIND License Key.',
				'cms_config_description' => 'Enter MAXMIND license key.',
				),	// row data
			array(
				'cms_config_key' => 'MAXMIND_COUNTRY_MMDB',
				'cms_config_value' => '/var/lib/GeoIP/GeoLite2-Country.mmdb',
				'cms_config_name' => 'MAXMIND Country mmdb File.',
				'cms_config_description' => 'Enter MAXMIND Country mmdb database file location (typically: /var/lib/GeoIP/GeoLite2-Country.mmdb).',
				),	// row data
			array(
				'cms_config_key' => 'MAXMIND_CITY_MMDB',
				'cms_config_value' => '/var/lib/GeoIP/GeoLite2-City.mmdb',
				'cms_config_name' => 'MAXMIND City mmdb File.',
				'cms_config_description' => 'Enter MAXMIND City mmdb database file location (typically: /var/lib/GeoIP/GeoLite2-City.mmdb).',
				),	// row data
			array(
				'cms_config_key' => 'MAXMIND_ASN_MMDB',
				'cms_config_value' => '/var/lib/GeoIP/GeoLite2-ASN.mmdb',
				'cms_config_name' => 'MAXMIND ASN mmdb File.',
				'cms_config_description' => 'Enter MAXMIND ASN mmdb database file location (typically: /var/lib/GeoIP/GeoLite2-ASN.mmdb).',
				),	// row data
			);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_geoip_plugin
