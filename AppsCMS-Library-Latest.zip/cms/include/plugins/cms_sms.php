<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_sms.php 3394 2023-07-25 00:25:01Z robert0609 $
 */

/**
 * Description of Ccms_sms_plugin
 * Top level SMS messaging plugin
 * and associated private classes
 * plugin name is the name of this file (without the extension)
 *
 * Description of Ccms_sms_base
 * Base class used by provider classes to engage common SMS code and variables
 *
 * @author robert0609
 */

class Ccms_sms_base extends Ccms_base {

	public static $sms_verbose = false;
	protected static $sms_error = false;
	private static $telstra_token = false; // memory cache
    protected const MAX_LEN = 1900;	//maximum body size

	function __construct() {
		// parent::__construct();
		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

	public static function get_telstra_cached_token() {
		if((!self::$telstra_token) &&
			($token = self::get_cms_sess_var('sms_telstra','token'))) {	// check for token in session
			if((!empty($token['expire'])) &&
				(!empty($token['token_type'])) &&
				(!empty($token['access_token'])) &&
				($token['expire'] > time())) self::$telstra_token = $token;
			else self::unset_cms_sess_var('sms_telstra','token');
			} // if
		return self::$telstra_token;
		} // get_telstra_cached_token()

	public static function set_telstra_cached_token($token = []) {
		$token['expire'] = time() + $token['expires_in'] - 60;	// quick check for expiry
		self::$telstra_token = $token;
		self::set_cms_sess_var($token,'sms_telstra','token');	// save token in session
		return self::$telstra_token;
		} // set_telstra_cached_token()

	public static function logSmsMsg($msg,$type,$mode) {
		if((self::$sms_verbose) || (self::is_cms_admin_user())) {
			switch($mode) {
			case 'admin':
				self::addAdminMsg($msg, $type);
				break;
			case 'debug':
				self::addDebugMsg($msg, $type);
				break;
			case 'user':
				self::addMsg($msg,$type);
				break;
			default:
				self::log_msg($msg,$type);
				break;
				} // switch
			} // if
		else {
			self::log_msg($msg, $type);
			} // else
		} // logSmsMsg()

	} // Ccms_sms_base

class Ccms_sms_plugin extends Ccms_plugin_base {	// extends Ccms_plugin_base required

	const PLUGIN = 'cms_sms';

	const SMS_LOG_PREFIX = '_SMS-MSGS-';	// leading underscore make it a system file and stop it being managed by the logger.

	protected static $sms_logfile = false;
	protected static $sms_log_maintanence_done = false;

	protected $provider = false;

	private static $cSelf = false;

	function __construct($provider = false, $sms_verbose = false) {
		self::$cSelf = $this;
		// parent::__construct();
		self::$sms_logfile = self::get_sms_log_filename();	// todays
		Ccms_sms_base::$sms_verbose = $sms_verbose;
		if(empty($provider)) $this->provider = PL_CMS_SMS_SMS_PROVIDER;
		else  $this->provider = $provider;
		if(!self::is_enabled()) {
			self::addAdminMsg('Plugin: ' . self::PLUGIN . ' is disabled.');
			return;
			} // if
		if((self::is_cms_group_manager()) ||
			(self::is_cms_app_manager()))
			self::sms_log_maintanence ();
		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

	public static function is_enabled() {	// required function, check plugin enabled
		// check it is available
		if((!self::is_plugin_enabled(self::PLUGIN)) ||
			(!PL_CMS_SMS_SMS_ENABLE)) return false;
		if(!is_object(self::$cSelf)) self::$cSelf = new Ccms_sms_plugin();
		if(!$class = self::$cSelf->get_provider_class()) return false;
		$func = $class . '::is_ok';
		if((is_callable($func)) && (!$func())) return false;
		return true;
		} // is_enabled()

	protected static function get_sms_log_filename($time = false) {
		if(empty($time)) $time = time();	// default to today
		$sms_logfile = VAR_FS_LOGS_DIR . self::SMS_LOG_PREFIX . date('Ymd',$time) . '.json.log';
		return $sms_logfile;
		} // get_sms_log_filename()

	public static function get_sms_log($time = false,$sms_logfile = false) {
		if(empty($sms_logfile)) $sms_logfile = self::get_sms_log_filename($time);
		if(!is_readable($sms_logfile)) return [];
		return self::load_json($sms_logfile);
		} // get_sms_log()

	 protected static function append_sms_log($sms_info = []) {
		if(empty($sms_info)) return true;
		$sms_logfile = self::get_sms_log_filename();
		$smslog = self::get_sms_log(false,$sms_logfile);	// todays log
		if(isset($sms_info[0][0])) $smslog = array_merge($smslog,$sms_info);	// mms send and replies
		else $smslog[] = $sms_info;	// send sms
		return self::save_json($sms_logfile,$smslog);
		} // append_sms_log()

	protected static function sms_log_maintanence() {
		if(self::$sms_log_maintanence_done) return true;
		self::$sms_log_maintanence_done = true;	// once only
		$path = VAR_FS_LOGS_DIR;
		return self::_log_file_maintainer($path,'/^' . self::SMS_LOG_PREFIX . '/',true);
		} // sms_log_maintanence()

//	public static function get_provider_name() {
//		return ucwords(PL_CMS_SMS_SMS_PROVIDER);
//		} // get_provider_name()
//
	protected function get_provider_class($prov = false) {
		if(empty($prov)) $prov = ($this->provider ?:PL_CMS_SMS_SMS_PROVIDER);
		$path = CMS_FS_PLUGINS_DIR . self::PLUGIN . '/' . $prov  . '.php';	// include provider class
		if(!file_exists($path)) return false;
		require_once $path;
		$class = 'C' . ($prov ?:PL_CMS_SMS_SMS_PROVIDER);
		if(!class_exists($class)) return false;
		return $class;
		} // get_provider_class()

	public function __call($name, $args) {	// a PHP magic method
		$class = $this->get_provider_class();
		if($class) {
			$sms = new $class();	// use defaults
			array_unshift($args,'__call');	// indicate caller level
			return $sms->$name($args);
			} // if
		return null;
		} // __call()

	public function get_sms_replies($options = []) {
		$class = $this->get_provider_class();
		if($class) {
			$sms = new $class();	// use defaults
			$replies = $sms->get_sms_replies($options);
			if(is_array($replies)) $replies['class'] = $class;
			self::append_sms_log($replies);
			return $replies;
			} // if
		return false;
		} // get_sms_replies()

	public function send_sms_msg($sms_mobile_number, $sms_message) {
		$class = $this->get_provider_class();
		if($class) {
			$sms = new $class();	// use defaults
			$result = $sms->send_sms_msg(['dest_number' => $sms_mobile_number, 'message' => $sms_message]);
			if(is_array($result)) {
				$result['dest_number'] = trim($sms_mobile_number);
				$result['message'] = trim($sms_message);
				$result['class'] = $class;
				} // if
			self::append_sms_log($result);
			return $result;
			} // if
		return false;
		} // send_sms_msg()

	public function get_sms_status($options = []) {
		$class = $this->get_provider_class();
		if($class) {
			$sms = new $class();	// use defaults
			$status = $sms->get_sms_status($options);
			if(is_array($status)) $status['class'] = $class;
			self::append_sms_log($status);
			return $status;
			} // if
		return false;
		} // get_sms_replies()

	public static function get_title() {	// get the plugin title
		return 'SMS';
		} // get_title()

	public static function get_avail_providers_list() {
		$p_sms_files = glob(CMS_FS_PLUGINS_DIR . self::PLUGIN . '/*.php');
		if(empty($p_sms_files)) return [];
		sort($p_sms_files);
		$providers = [];
		if(!is_object(self::$cSelf)) self::$cSelf = new Ccms_sms_plugin();
		foreach($p_sms_files as $p) {
			$f = basename($p);
			if(preg_match('/^_/',$f)) continue;	// provider extension used by provider code
			$v = preg_replace('/\.php$/','',$f);
			if(!$class = self::$cSelf->get_provider_class($v)) continue;
			// if(!$class::is_ok()) continue;
			$name = ucwords(preg_replace('/[^0-9a-z]/i',' ',$v));
			$providers[] = [ 'ok' => $class::is_ok(), 'path' => $p, 'file' => $f, 'value' => $v, 'name' => $name, 'class' => $class];
			} // foreach
		return $providers;
		} // get_avail_providers_list()

	public static function get_sms_provider_select($name,$value) {
		$providers = self::get_avail_providers_list();
		if(empty($providers)) {
			self::addAdminMsg('No SMS providers code found.');
			return 'No SMS providers code found.';
			} // if
		$text = []; $descs = [];
		$text[] = '<select name="' . $name . '">';
		$text[] = '	<option value="-1" disabled selected hidden>- Select SMS Provider -</option>';
		foreach($providers as &$p) {
			$text[] = '	<option value="' . $p['value'] . '"' . ($p['value']  == $value ? ' SELECTED':'') . '>' . $p['name'] . ($p['ok'] ? ' (enabled)':' (disabled)') . '</option>';
			require_once $p['path'];
			$desc = $p['class']::get_description();
			if(!empty($desc)) $descs[] = '<li>' . $desc . '</li>';
			} // foreach
		$text[] = '</select>';
		if(!empty($descs)) {// add selection descriptions
			$label = '<b>Click for SMS Messaging Providers Information.</b>';
			$txt = '<ul>' . implode('',$descs) . '</ul>';
			$text[] = '<br><br>' . Ccms_drop_box::panel_block($label,$txt, '', '') . '<br>';
			} // if
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // get_sms_provider_select()

	public static function get_description() {	// get the plugin description and help
		return 'The ' . CMS_PROJECT_SHORTNAME . ' SMS messaging plugin (' . self::PLUGIN . ') is an assistive plugin for sending SMS messages.' .
			'<br><b>Click SMS Providers Description</b> for more information.';
		} // get_description()

	protected static function get_providers_sql_install_data() {
		$providers = glob(CMS_FS_PLUGINS_DIR . self::PLUGIN . '/*.php');
		if(empty($providers)) {
			self::addAdminMsg('No SMS providers code found.');
			return [];
			} // if
		$sql_insts = [];
		foreach($providers as $p) {
			if(preg_match('/^_/',basename($p))) continue;	// extension
			require_once $p;	// include provider class
			$class = 'C' . preg_replace('/\.php$/','',basename($p));
			$method = $class . '::get_sql_install_data';
			if(self::is_static_callable($method)) {
				$sql_insts = array_merge($sql_insts,$method());
				} // if
			} // foreach
		return $sql_insts;
		} // get_providers_sql_install_data()

	protected static function get_sql_install_data() {
		$sql_inst = array(	// NOTE: including the sql wrapper ' is not needed (eg "text" not "'text'")
			array(
				'cms_config_key' => "SMS_ENABLE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "true",
				'cms_config_allowed_values' => "true:false",
				'cms_config_name' => "Use SMS Messaging.",
				'cms_config_description' => "true = use external authentication, false = no external authentication.",
				),	// row data
			array(
				'cms_config_key' => "SMS_MODE",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "debug",
				'cms_config_allowed_values' => "live:debug",
				'cms_config_name' => "SMS Live/Debug Messaging.",
				'cms_config_description' => "live = live messaging (needs a full SMS account), false = for debug/trial/testing SMS messaging.",
				),	// row data
			array(
				'cms_config_key' => "SMS_PROVIDER",	// gets prefixed with the PL_PluginName_ in uppercase
				'cms_config_value' => "",
				'cms_config_allowed_values' => "",
				'cms_config_name' => "SMS Messaging Provider.",
				'cms_config_description' => "Select the SMS messaging provider.'",
				'cms_config_show_func' => '',
				'cms_config_input_func' => __CLASS__ . '::get_sms_provider_select',
				'cms_config_save_func' => '',
				),	// row data
			);
		return array_merge(self::get_providers_sql_install_data(),$sql_inst);
		} // get_sql_install_data()

	// special functions
	public static function install($chk_flg = true) {
		return self::install_db_data(self::PLUGIN,self::get_title(),self::get_sql_install_data(),$chk_flg);
		}	// install()

	public static function uninstall() {	// dummy function
		return self::uninstall_db_data(self::PLUGIN,self::get_sql_install_data());
		}	// uninstall()

} // Ccms_sms_plugin
