<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_show_sitemap.php 3092 2023-02-04 05:13:14Z robert0609 $
 */

if(!Ccms_xml_sitemap::get_html_sitemap_file()) {
	//Ccms::reset_session_actions();
	//$url = Ccms_base::get_base_url(true) . Ccms::get_body_uri();
	//Ccms_base::do_redirect_uri($url);
	Ccms::addMsg("Sitemap not available.",'warn');
	//return;
	} // if
?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_body">
	<caption>Log in page</caption>
	<tr class="page_body">
		<th class="page_body">
			<h1 class="page_config" title="Sitemap of all the URLs available.">Site Map</h1>
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<?php Ccms_xml_sitemap::show_html_sitemap() ?>
		</td>
	</tr>
</table>

<?= Ccms::page_end_comment(__FILE__) ?>

