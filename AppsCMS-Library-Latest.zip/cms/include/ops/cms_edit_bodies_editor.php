<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_bodies_editor.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

// the body editor for cms_edit_bodies.php

Ccms::page_start_comment(__FILE__);

?>

<span id="ws_text_input" style="display: none;">
	<?php // echo Ccms::get_admin_scroll2anchor(0,true,'Edit_Top') ?>
	<table class="page_config">
		<tr class="page_config">
			<th class="page_config">
				<h1 class="page_config"><?= $page_name ?> - Page Body Editor.</h1>
			</th>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<h2 class="page_config" class="page_body">Available Body Link URIs</h2>
				<select id="ws_link_list_id" name="ws_link_list" size="1" onchange="javascript:cms_get_selected_ws_link();"><?= Ccms::make_ws_link_select_options() ?></select>
				<br>

				<input type="text" id="ws_link_selected_id" value="" size="60" title="Select/hi-light the link text, copy and paste into link/href path." autocapitalize="off"/>
			</td>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<h2 class="page_config" class="page_body">Available Body Image URIs</h2>
				<span id="ws_image_selector_id"><?= Ccms_options::get_ws_image_uri_selection() ?></span>
				<input type="file" accept="image/*" id="ws_image_upload_id" name="" onchange="javascript:cms_ajax_upload_image();" title="Select images to upload. Stored in the <?= ETC_WS_IMAGES_DIR ?> directory, and updates the available body image URIs"/>
					<br><input type="text" id="ws_image_selected_id" value="" size="60" title="Select/hi-light the image text and copy with Control-C, and paste with Control-V into Image URL input." autocapitalize="off"/>
					<span id="uploading_image_id"></span>
			</td>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<h3 class="page_config">Editor:</h3>
<?php
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_body_name))
					Ccms::get_return2search_link(true);
?>
			</td>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<div class="cms_sticky_left">
					<button onclick="cms_setView('ws_config');" type="button" title="Goto to page body config.">Config</button>
					&nbsp;&nbsp;
					<button onclick="cms_setView('ws_text_input');" type="button" disabled="true">Editor</button>
					<?php if(preg_match('/\.htm$|\.html$/i',$cms_body_file)) { ?>
					&nbsp;&nbsp;
					<button onclick="cms_setView('ws_text_view');" type="button" title="Goto to view page body.">View</button>
					<?php	} // if ?>
					&nbsp;&nbsp;
					<?php if($cms_body_id == 0) { ?>
					<button name="insert" value="insert" type="submit">Add</button>
					<?php } else { ?>
					<button name="save" value="save" type="submit">Save</button>
					<?php	} // else ?>
					&nbsp;&nbsp;
					<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
				</div>
			</td>
		</tr>
	</table>
	<table class="page_body">
		<tr class="page_body">
			<td class="page_body">
				<?= $cWYSIWYG->output_edit_text($body_text) ?>
			</td>
		</tr>
		<tr class="page_body">
			<td class="page_config" style="text-align: right">
<?php
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_body_name))
					Ccms::get_return2search_link(true);
?>

				<button onclick="cms_setView('ws_config');" type="button" title="Goto to page body config.">Config</button>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_input');" type="button" disabled="true">Editor</button>
				<?php if(preg_match('/\.htm$|\.html$/i',$cms_body_file)) { ?>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_view');" type="button" title="Goto to view page body.">View</button>
				<?php	} // if ?>
				&nbsp;&nbsp;
				<?php if($cms_body_id == 0) { ?>
				<button name="insert" value="insert" type="submit">Add</button>
				<?php } else { ?>
				<button name="save" value="save" type="submit">Save</button>
				<?php	} // else ?>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
			</td>
		</tr>
	</table>
</span>
<span id="ws_text_view_blk" style="display: none;">
	<table class="page_config">
		<tr class="page_config">
			<th class="page_config">
				<h1 class="page_config"><?= $page_name ?> - Page Body View.</h1>
			</th>
		</tr>
		<tr class="page_config">
			<td class="page_config" style="text-align: right">
<?php
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_body_name))
					Ccms::get_return2search_link(true);
?>

				<button onclick="cms_setView('ws_config');" type="button" title="Goto to page body config.">Config</button>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_input');" type="button" title="Goto edit page body <?= (Ccms::$cms_page_info['html_wysiwyg_allow'] ? '(' . $cWYSIWYG->get_wysiwyg_title() . ')':'') ?>.">Editor</button>
				<?php if(preg_match('/\.htm$|\.html$/i',$cms_body_file)) { ?>
				&nbsp;&nbsp;
				<button onclick="cms_setView('ws_text_view');" type="button" disabled="true">View</button>
				<?php	} // if ?>
				&nbsp;&nbsp;
				<?php if($cms_body_id == 0) { ?>
				<button name="insert" value="insert" type="submit">Add</button>
				<?php } else { ?>
				<button name="save" value="save" type="submit">Save</button>
				<?php	} // else ?>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
			</td>
		</tr>
	</table>
	<table class="page_body">
		<tr class="page_body">
			<td class="page_body">
				<div id="ws_text_view">
					<?php
						if(preg_match('/\.htm$|\.html$/i',$cms_body_file))
							echo $body_text;
					?>
				</div>
			</td>
		</tr>
	</table>
</span>

<?php
Ccms::page_end_comment(__FILE__);

