<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_config.php 3267 2023-03-11 06:57:32Z robert0609 $
 */

$cCMS_C = new Ccms_config_funcs();

$cms_config_id = 0;
$cms_config_op = '';
Ccms_export::export_table('cms_configs');
if(Ccms::get_cms_action() == 'cms_edit_config') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	if((Ccms::is_get_or_post('name')) && (!Ccms::is_get_or_post('config_edit_id'))) {
		$direct_name = Ccms::get_or_post('name');	// from direct edit
		$direct_id = (int)Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_id',"cms_config_key = '" . $direct_name . "'");
		if($direct_id > 0) Ccms::get_or_post_pushback('config_edit_id',$direct_id);
		} // if
	if(((Ccms::is_get_or_post('edit')) && (Ccms::is_get_or_post('config_edit_id'))) ||
		($config_name = Ccms::get_or_post('name')) ||
		((Ccms::is_get_or_post('config_edit_id')) && ((int)Ccms::get_or_post('config_edit_id') > 0))) {
		$cms_config_op = 'edit';
		if(Ccms::is_get_or_post('config_edit_id')) $cms_config_id = (int)Ccms::get_or_post('config_edit_id');
		else { // what??
			$cms_config_op = '';
			$cms_config_id = 0;
			} // else

		$sql_query = "SELECT  cms_config_name, cms_config_value,cms_config_description, cms_config_key, cms_config_allowed_values" .
			", cms_config_show_func, cms_config_input_func, cms_config_save_func,cms_config_comments" .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_config_added','cms_config_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_config_updated','cms_config_updated') .
			" FROM  cms_configs WHERE length('cms_config_name') > 0 AND cms_config_id = '" . (int)$cms_config_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($config = Ccms::$cDBcms->fetch_array($result))) {
			foreach($config as $c => $v) $$c = $v;
			Ccms::$cDBcms->free_result($result);
			} // if
		} // if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('cms_config_id'))) {
		$cms_config_op = 'save';
		$cms_config_id = (int)Ccms::get_or_post('cms_config_id');
		$cms_config_name = html_entity_decode(Ccms::get_or_post('cms_config_name'));
		$method = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_save_func',"cms_config_id = '" . (int)$cms_config_id . "'");
		if((!empty($method)) &&
			(method_exists($cCMS_C,$method))) {
			// $cms_config_old_value = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_value',"cms_config_id = '" . (int)$cms_config_id . "'");
			$cms_config_allowed_values = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_allowed_values',"cms_config_id = '" . (int)$cms_config_id . "'");
			$cms_config_value = $cCMS_C->$method('cms_config_value',false,$cms_config_allowed_values);
			} // if
		else if((!empty($method)) &&
			(Ccms_base::is_static_callable($method))) {
			// $cms_config_old_value = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_value',"cms_config_id = '" . (int)$cms_config_id . "'");
			$cms_config_allowed_values = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_allowed_values',"cms_config_id = '" . (int)$cms_config_id . "'");
			$cms_config_value = call_user_func($method,'cms_config_value',false,$cms_config_allowed_values);
			} // if
		else $cms_config_value = html_entity_decode(Ccms::get_or_post('cms_config_value',false));

		$cms_config_key = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_key',"cms_config_id = '" . (int)$cms_config_id . "'");
		$cms_config_old = Ccms::$cDBcms->get_data_in_table('cms_configs','cms_config_value',"cms_config_id = '" . (int)$cms_config_id . "'");
		if($cms_config_key == 'CMS_C_WYSIWYG_EDITOR') { // special case
			if($wigs = Ccms::get_or_post('wigs')) {	// have configs
				if(Ccms_wysiwyg::save_wysiwyg_configs($wigs)) {
					Ccms::addMsg('Saved WYSIWYG configs.','success');
					} // if
				else {
					Ccms::addMsg('Failed to save WYSIWYG configs.');
					} //
				} // if
			if(!Ccms_wysiwyg::is_wysiwyg_available($cms_config_value)) {
				Ccms::addMsg('WYSIWYG disabled (using ' . $cms_config_value . ').','warn');
				$cms_config_value = 'None';
				} // if
			} // if
		$cms_config_comments = Ccms::get_or_post('cms_config_comments');

		if((!preg_match('/^save_[\S]+$/',$method)) && // special cases
			(!$cCMS_C->is_config_value_ok($cms_config_id,$cms_config_value))) {
			Ccms::addMsg('Value not allowed in ' . $cms_config_key);
			// reget values
			$sql_query = "SELECT  cms_config_name, cms_config_description, cms_config_key" .
				", cms_config_allowed_values, cms_config_show_func, cms_config_input_func,cms_config_comments" .
				", " . Ccms::$cDBcms->get_db_sql_localtime('cms_config_added','cms_config_added') .
				", " . Ccms::$cDBcms->get_db_sql_localtime('cms_config_updated','cms_config_updated') .
				" FROM  cms_configs WHERE  cms_config_id = '" . (int)$cms_config_id . "'";
			if(($result = Ccms::$cDBcms->query($sql_query)) &&
				(Ccms::$cDBcms->num_rows($result) > 0) &&
				($config = Ccms::$cDBcms->fetch_array($result))) {
				foreach($config as $c => $v) $$c = $v;
				Ccms::$cDBcms->free_result($result);
				} // if
			} // if
		else {	// update it
			$fields = array();
			$fields['cms_config_value'] = $cms_config_value;
			$fields['cms_config_comments'] = $cms_config_comments;
			if(!Ccms::$cDBcms->perform('cms_configs',$fields,'update',"cms_config_id = '" . (int)$cms_config_id . "'")) {
				Ccms::addMsg('Config update, ' . $cms_config_name . " failed");
				} // if
			else {
				// Ccms_base::unset_cms_sess_var('cms_config_id');
				Ccms_export::export_table('cms_configs');
				Ccms::backupOnSave();
				Ccms::addMsg('Saved configuration values in ' . CMS_PROJECT_SHORTNAME . ' database.','success');
				if(Ccms_sm::is_htaccess_regen_reqd($cms_config_key, $cms_config_value,$cms_config_old)) {
					Ccms::rebuild_docroot_htaccess(array($cms_config_key => $cms_config_value));
					} // if
				} // else
			$cms_config_op = '';
			} // if

		if((preg_match('/^CMS_C_API_/',$cms_config_key)) &&
			($api_map = Ccms_api_map::get_api_resource_map(true))) {
			Ccms_sm::addMsg('Rebuild API map.','info');
			} // if


		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('export'))) {
		$cms_user_op = 'export';
		$cms_user_id = 0;
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('import'))) {
		$cms_user_op = 'import';
		$cms_user_id = 0;
		Ccms_export::import_table('cms_configs');
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$cms_config_op = 'reloadDB';
		$cms_config_id = 0;
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('checkDB'))) {
		$cms_config_op = 'checkDB';
		$cms_config_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_config_op = 'cancel';
		$cms_config_id = 0;
		} // else if
	} // if

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config" style="text-align: left">
			<h1 class="page_config">Configuration Values</h1>
		</th>
	</tr>
	<?php if($cms_config_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Reloading Configuration Table in Database
			<?php Ccms::$cDBcms->installDatabase('cms_configs',true ,true) ?>
		</td>
	</tr>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<?php } // if ?>
	<?php if($cms_config_op == 'checkDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Checking Configuration Table in Database
			<?php Ccms::$cDBcms->installDatabase('cms_configs',false ,false) ?>
		</td>
	</tr>
	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>
	<?php } // if ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<form name="cms_edit_config" action="index.php" method="post" enctype="multipart/form-data">
			<input type="hidden" name="cms_action" value="cms_edit_config">
				Select config name:&nbsp;
			<?= Ccms_search::get_form_search_hidden_inputs() ?>
			<input type="hidden" name="cms_config_id" value="<?= $cms_config_id ?>"/>
			<?= Ccms_edit::get_select_option_filter('prim_id', '',-1) ?>
			<select name="config_edit_id" id="prim_id" size="1"
				style="max-width: unset;"
				onchange="setConfigButtons(this);">
				<option value="0"> -- Select Config Option -- </option>
				<?php
					$sql_query = "SELECT cms_config_id,cms_config_name,cms_config_value,cms_config_comments" .
								" FROM  cms_configs" .
								" WHERE length('cms_config_name') > 0" .
								" ORDER BY cms_config_name";
					$cnt = 0;
					if(($result = Ccms::$cDBcms->query($sql_query)) &&
						(($cnt = Ccms::$cDBcms->num_rows($result)) > 0)) {
						while($config = Ccms::$cDBcms->fetch_array($result)) {
							if(empty($config['cms_config_name'])) continue;	// invisibles
							echo '<option value="' . $config['cms_config_id'] .'"'.
								((int)$config['cms_config_id'] == $cms_config_id ? ' SELECTED':'') . '>' .
								strip_tags($config['cms_config_name']) .
								((int)$config['cms_config_id'] == $cms_config_id ? ' **':'') .
								'</option>' . PHP_EOL;
							} // while
						} // if
					else echo '<option value="0">(No configs setup)</option>' . PHP_EOL;
				?>
			</select>
<!--			&nbsp;&nbsp;
			<button id="b_edit_id" name="edit" value="edit" type="submit" onclick="Ccms_cursor.setWait();">Edit</button>-->
			<?php if(Ccms_auth::is_cms_admin_user()) { ?>
			&nbsp;&nbsp;
			<button name="checkDB" value="checkDB" type="submit" title="Check configuration table in database for missing entries." onClick="if(var ret = confirm_check('Check and refresh configuration table in database?')) Ccms_cursor.setWait(); return ret;">Check</button>
			<?php	} // if ?>
			<?php if((Ccms_auth::is_cms_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
			&nbsp;&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise configuration table in database." onClick="return confirm_check('Clear and re-initialise configuration table in database?')">Reload</button>
			<?php	} // if ?>
			<?= Ccms_export::get_table_form_text('cms_configs') ?>
			<?php Ccms::get_return2search_link() ?>
			</form>
			<span id="working_id">&nbsp;</span>
			<script type="text/javascript">

				function filter_rows_keywords(obj) {
					var cnt = 0;
					var filter = obj.value.toLowerCase();
					var rows = document.getElementsByTagName('TR');
					if(rows.length < 1) return 0;
					if(filter.length < 1) {	// turn on all rows
						for( var i = 0; i < rows.length;i++) {
							var tr = rows[i];
							var keywords = tr.getAttribute('data-keywords');
							if(!keywords) continue;
							tr.style.display = '';	// show
							cnt++;
							} // for	
						var cntr = document.getElementById('id_filter_cnt');
						cntr.innerText = ' Display: ' + cnt;
						return 1;
						} // if
					// else filter rows
					var words = filter.split(/(\s+)/);
					for( var i = 0; i < rows.length;i++) {
						var tr = rows[i];
						var keywordsU = tr.getAttribute('data-keywords');
						if(!keywordsU) continue;
						var keywords = keywordsU.toLowerCase();
						var fnd = true;
						for(var j = 0; j < words.length; j++) {
							var word = words[j];
							if(keywords.search(word) < 0) {
								fnd = false;
								break;
								} // if
							} // for
						if(fnd) { tr.style.display = ''; cnt++; }	// show
						else  tr.style.display = 'none';	// hide
						} // for					
					var cntr = document.getElementById('id_filter_cnt');
					cntr.innerText = ' Found: ' + cnt;
					return 2;			
					} // filter_rows_keywords()

				function confirm_check(txt) {
					if(confirm(txt)) {
						document.getElementById('working_id').innerHTML = '<?= Ccms_msgs::make_message_text('submiting input.', 'working') ?>';
						Ccms_cursor.setWait();
						cms_sleep(2000);	// allow img to load
						return true;
						} // if
					return false;
					} // confirm_check()

				function setConfigButtons(elem) {
					var sel = document.getElementById('prim_id');
					if(!sel) return;
					if(sel.selectedIndex > 0) {
						// document.getElementById('b_edit_id').disabled = false;
						if(elem) elem.form.submit();
					} else {
						// document.getElementById('b_edit_id').disabled = true;
					} // else
					} // setBodyConfigButtons()
				setConfigButtons(false);	// initial
			</script>
		</td>
	</tr>
<!--	<tr class="page_config"><td class="page_config">&nbsp;</td></tr>-->

	<?php
	if((($cms_config_op == 'edit') || ($cms_config_op == 'save')) &&
		(isset($cms_config_id)) && ($cms_config_id > 0)) {
	?>

	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form name="cms_edit_config" action="index.php" method="post" enctype="multipart/form-data">
			<input type="hidden" name="cms_action" value="cms_edit_config">
			<input type="hidden" name="cms_config_id" value="<?= $cms_config_id ?>"/>
			<input type="hidden" name="cms_config_name" value="<?= $cms_config_name ?>"/>
			<?= Ccms_search::get_form_search_hidden_inputs() ?>
			<table class="page_config">
				<tr class="page_config">
					<th class="page_config" colspan="2">
						Edit Configuration Value - <?= (!empty($cms_config_name) ? $cms_config_name:'(Invisible, ReadOnly)') ?>
						&nbsp;&nbsp;
						<span class="page_config">(
							Added:&nbsp;<?= $cms_config_added;?>
							&nbsp;&nbsp;
							Updated:&nbsp;<?= $cms_config_updated;?>
						)</span>
<?php
			// if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_config_key))
			// 	Ccms::get_return2search_link(true);
?>
					</th>
				</tr>
<?php if (!empty($cms_config_name)) { ?>
				<tr class="page_config">
					<td class="page_config" colspan="3" style="text-align: left;">
							<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
							&nbsp;&nbsp;
							<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="page_config">
					<th class="page_config" style="text-align: right;">Description:</th>
					<td class="page_config" style="text-align: left">
						<i><?= Ccms::sanitiseText4Html($cms_config_description) ?></i>
					</td>
				</tr>
				<tr class="page_config">
					<th class="page_config" style="text-align: right">Value:</th>
					<td class="page_config" style="text-align: left">
						<?= (!empty($cms_config_name) ? $cCMS_C->show_input_elem($cms_config_value,$cms_config_allowed_values,$cms_config_input_func):$cms_config_value) ?>
					</td>
				</tr>
<?php			if(Ccms::is_debug()) { ?>
<?php 		if($cms_config_key == 'CMS_C_WYSIWYG_EDITOR') { // special case ?>
				<tr class="page_config">
					<th class="page_config" style="text-align: right">Available WYSIWYGs:</th>
					<td class="page_config" style="text-align: left">
						<?= Ccms_wysiwyg::get_wysiwyg_descriptions() ?>
					</td>
				</tr>
				<tr class="page_config">
					<th class="page_config" style="text-align: right">Config WYSIWYGs:</th>
					<td class="page_config" colspan="2" style="text-align: left">
						<?= Ccms_wysiwyg::config_wysiwygs($cms_config_value) ?>
					</td>
				</tr>
<?php			} // if ?>
				<tr class="page_config">
					<th class="page_config" style="text-align: right">Code Key:</th>
					<td class="page_config" style="text-align: left" title="The define used in source code to access this value."><i><?= $cms_config_key ?></i></td>
				</tr>
<?php				} // if ?>
<?php if (!empty($cms_config_name)) { ?>
				<tr class="page_config">
					<th class="page_config" style="text-align: right">Admin Comments:</th>
					<td class="page_config">
						<?= (!empty($cms_config_name) ? $cCMS_C->show_input_comments($cms_config_comments):$cms_config_comments) ?>
						<br>
						<?= Ccms::getAdminCommentHint('edit_config',(!empty($cms_config_name) ? $cms_config_name:$cms_config_key)) ?>
					</td>
				</tr>
				<tr class="page_config">
					<td class="page_config" style="text-align: right" colspan="2">
						<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
						&nbsp;&nbsp;
						<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
					</td>
				</tr>
<?php	} // if ?>
			</table>
		</form>
		</td>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			<h2 class="page_config">More configurations.</h2>
		</td>
	</tr>
	<?php } // if  ?>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<label title="Enter keywords to filter configurations, clear to see all configurations.">
				Filter: <input id="id_setting_filter" type="text" name="setting_filter" value="" placeholder="Filter" oninput="filter_rows_keywords(this);">
				<span id="id_filter_cnt" style="font-weight: bold;"></span>
			</label>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<table class="page_config">
				<tr class="page_config">
					<th style="width: 200px;" class="page_config">Name</th>
					<!--<th style="width: 200px;" class="page_config" title="Constant value used in php code">Code Key</th>-->
					<th style="width: 250px;" class="page_config">Value</th>
					<th class="page_config">Description</th>
				</tr>
	<?php
		$sql_query = "SELECT  cms_config_id,cms_config_key,cms_config_name,cms_config_value,cms_config_allowed_values,cms_config_description,cms_config_key,cms_config_show_func" .
			" FROM  cms_configs" .
			" WHERE length(cms_config_name) > 0" .
			" ORDER BY  cms_config_name,cms_config_id";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$row = 0;
			while($config = Ccms::$cDBcms->fetch_array($result)) {
				$data_keywords = ' data-keywords="' . Ccms::make_nice_name($config['cms_config_key']) . ' ' . $config['cms_config_value'] . ' ' . $config['cms_config_description'] . '"';
				echo '<tr ' . $data_keywords . ' class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left" valign="top">';
				if(Ccms::is_debug()) echo 'ID: ' . $config['cms_config_id'] . ', ';
				echo '<a href="index.php?cms_action=cms_edit_config&config_edit_id=' . $config['cms_config_id'] . '">' . $config['cms_config_name'] . '</a>';
				if(Ccms::is_debug()) {
					echo '<br>(' . $config['cms_config_key'] . ')' . PHP_EOL;					
					} // if
				echo '</td>' . PHP_EOL;
				echo '<!--<td class="page_config" style="text-align: left">' . $config['cms_config_key'] . '</td>-->';
				echo '<td class="page_config" style="text-align: left; overflow-wrap: anywhere;">';
					if((!empty($config['cms_config_show_func'])) &&
						(method_exists($cCMS_C,$config['cms_config_show_func']))) {
						$method = $config['cms_config_show_func'];
						echo $cCMS_C->$method($config['cms_config_value'],$config['cms_config_allowed_values'],'page_config');
						} // if
					else if((!empty($config['cms_config_show_func'])) &&
						(Ccms_base::is_static_callable($config['cms_config_show_func']))) {
						// left over from V5
						$method = $config['cms_config_show_func'];
						echo call_user_func($method,$config['cms_config_value'],$config['cms_config_allowed_values'],'page_config');
						} // if
					else if(!empty($config['cms_config_allowed_values'])) echo Ccms::make_nice_name ($config['cms_config_value']);
					else echo (!empty($config['cms_config_value']) ? wordwrap($config['cms_config_value'], 80, '</br>'):'(empty)');
				echo '</td>' . PHP_EOL;
				echo '<td class="page_config" style="text-align: left">' . $config['cms_config_description'] . '</td>' . PHP_EOL;
				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			Ccms::$cDBcms->free_result($result);
			} // if
		else echo '<tr class="page_config"><td class="page_config" style="text-align: left">(No configs setup)</td></tr>' . PHP_EOL;
		?>
			</table>
		</td>
	</tr>
</table>


<?php Ccms::page_end_comment(__FILE__) ?>
