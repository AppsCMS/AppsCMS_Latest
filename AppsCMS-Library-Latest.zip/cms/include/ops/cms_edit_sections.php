<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_sections.php 3224 2023-02-22 06:30:47Z robert0609 $
 */
$cCMS_C = new Ccms_config_funcs();

function delete_sections($lm_section_id,$del_sect_links) {
	static $fnd_sects = array();	// used to stop faulty DB entries causing infinite loops
	if($del_sect_links) {	// recuse thru child sections
		$parent_id = Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_parent_id','lm_section_id = ' . (int)$lm_section_id);
		if(((int)$parent_id > 0) && (!in_array($parent_id,$fnd_sects))) {
			$fnd_sects[] = $parent_id;
			delete_sections($parent_id,$del_sect_links);	// recurse
			} // if
		} // if
	$sql_query = "DELETE FROM  lm_sections WHERE  lm_section_id = '" . (int)$lm_section_id . "'";
	Ccms::$cDBcms->query($sql_query);
	if($del_sect_links) {
		$sql_query = "DELETE FROM  lm_links WHERE  lm_link_section_id = '" . (int)$lm_section_id . "'";
		} // if
	else {
		$sql_query = "UPDATE lm_links SET lm_link_section_id = 0 WHERE lm_link_section_id = '" . (int)$lm_section_id . "'";
		} // else
	Ccms::$cDBcms->query($sql_query);
	} // delete_sections()

$lm_section_id = 0;
$lm_section_op = '';
$lm_section_clone = false;
$lm_section_clone_from_id = Ccms::get_or_post("lm_section_clone_from_id");
$lm_section_clone_insert = ((Ccms::get_or_post("lm_section_clone") == 'true') ? true:false);

Ccms_export::export_table('lm_sections');
if(Ccms::get_cms_action() == 'cms_edit_sections') { // a bit of caution
	if((Ccms::is_get_or_post('delete')) &&
		((Ccms::is_get_or_post('section_edit_id')) || (Ccms::is_get_or_post('lm_section_id')))) {
		$lm_section_op = 'delete';
		$lm_section_id = (int)(Ccms::is_get_or_post('lm_section_id') ? Ccms::get_or_post('lm_section_id'):Ccms::get_or_post('section_edit_id'));

		$sql_query = "SELECT  lm_section_name,lm_section_enabled" .
					" FROM  lm_sections WHERE  lm_section_id = '" . (int)$lm_section_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($section = Ccms::$cDBcms->fetch_array($result))) {
			$lm_section_name = $section['lm_section_name'];
			$lm_section_enabled = $section['lm_section_enabled'];
			} // if
		} // else if
	else if((Ccms::is_get_or_post('confirm_delete')) && (Ccms::is_get_or_post('lm_section_id'))) {
		$lm_section_op = 'confirm_delete';
		$lm_section_id = (int)Ccms::get_or_post('lm_section_id');
		$del_sect_links = Ccms::get_or_post_checkbox('del_sect_links');
		delete_sections($lm_section_id,$del_sect_links);
		new Ccms_xml_sitemap();	// do sitemap
		$lm_section_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('add')) {
		$cols = Ccms::$cDBcms->get_columns_list('lm_sections',true);
		foreach($cols as $c => $v) $$c = $v;
		$lm_section_enabled = 1;

		$sql_query = "SELECT MAX(lm_section_order) AS max_lm_section_order FROM  lm_sections";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			($row = Ccms::$cDBcms->fetch_array($result))) {
			$lm_section_order = $row['max_lm_section_order'] + 100;	// next app
			} // if
		else Ccms::$cDBcms->free_result($result);

		$lm_section_op = 'add';
		$lm_section_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('insert')) && (Ccms::is_get_or_post('lm_section_id'))) {
		$lm_section_op = 'insert';
		} // else if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('lm_section_id'))) {
		$lm_section_op = 'save';
		} // else if
	else if((Ccms::is_get_or_post('clone')) && (Ccms::is_get_or_post('lm_section_id'))) {
		$lm_section_op = 'clone';
		$lm_section_clone = true;
		} // else if
	else if((CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$lm_section_op = 'reloadDB';
		$lm_section_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$lm_section_op = 'cancel';
		$lm_section_id = 0;
		Ccms::do_cms_return_action();
		} // else if
	else if(Ccms::is_get_or_post('import')) {
		$lm_section_op = 'import';
		$lm_section_id = 0;
		if(Ccms_export::import_table('lm_sections')) {
			// nothing yet
			} // if
		} // else if
	else if(($lm_section_id = (int)Ccms::get_or_post('section_edit_id')) > 0) {
		$lm_section_op = 'edit';

		$sql_query = "SELECT  lm_section_name, lm_section_order,lm_section_group_ids" .
			", lm_section_name , lm_section_description, lm_section_title" .
			", lm_section_image_url, lm_section_icon_url, lm_section_enabled" .
			", lm_section_parent_id ,lm_section_columns, lm_section_group_ids" .
			", lm_section_comments" .
			", " . Ccms::$cDBcms->get_db_sql_localtime('lm_section_added','lm_section_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('lm_section_updated','lm_section_updated') .
			" FROM  lm_sections WHERE  lm_section_id = '" . (int)$lm_section_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($section = Ccms::$cDBcms->fetch_array($result))) {
			foreach($section as $k => &$v) $$k = $v;
			Ccms::$cDBcms->free_result($result);
			} // if
		else { // not found
			$lm_section_id = 0;
			$lm_section_op = '';
			$lm_section_added = '';
			$lm_section_updated = '';
			} // else
		} // if

	if(($lm_section_op == 'save') || ($lm_section_op == 'clone') || ($lm_section_op == 'insert')) {
		// do it once
		$lm_section_id = (int)Ccms::get_or_post('lm_section_id');
		$lm_section_name = html_entity_decode(Ccms::get_or_post('lm_section_name'));
		$lm_section_columns = (int)Ccms::get_or_post('lm_section_columns');
		$lm_section_description = html_entity_decode(Ccms::get_or_post('lm_section_description'));
		$lm_section_title = html_entity_decode(Ccms::get_or_post('lm_section_title'));
		$lm_section_order = (int)Ccms::get_or_post('lm_section_order');
		$lm_section_group_ids = implode(':',Ccms::get_or_post('lm_section_group_ids'));
		$lm_section_enabled = Ccms::get_or_post_checkbox('lm_section_enabled');
		$lm_section_parent_id = Ccms::get_or_post('lm_section_parent_id');
		$lm_section_added = html_entity_decode(Ccms::get_or_post('lm_section_added'));
		$lm_section_updated = html_entity_decode(Ccms::get_or_post('lm_section_updated'));
		$lm_section_image_url = $cCMS_C->get_image('lm_section_image_url',Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_image_url','lm_section_id = ' . (int)$lm_section_id),ETC_WS_IMAGES_DIR);
		$lm_section_icon_url = $cCMS_C->get_image('lm_section_icon_url',Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_icon_url','lm_section_id = ' . (int)$lm_section_id),ETC_WS_ICONS_DIR);
		$lm_section_comments = Ccms::get_or_post('lm_section_comments');

		if($lm_section_op != 'clone') {
			Ccms_DB_checks::is_section_name_ok($lm_section_name, $lm_section_op,"lm_section_id != " . (int)$lm_section_id);

			if((int)$lm_section_columns > 10) $lm_section_columns = 10;
			else if((int)$lm_section_columns < 1) $lm_section_columns = 1;

			if(!Ccms::getMsgsCount('error')) {	// update it
				$fields = array();
				$fields['lm_section_name'] = $lm_section_name;
				$fields['lm_section_columns'] = $lm_section_columns;
				$fields['lm_section_description'] = $lm_section_description;
				$fields['lm_section_title'] = $lm_section_title;
				$fields['lm_section_image_url'] = $lm_section_image_url;
				$fields['lm_section_icon_url'] = $lm_section_icon_url;
				$fields['lm_section_order'] = $lm_section_order;
				$fields['lm_section_group_ids'] = $lm_section_group_ids;
				$fields['lm_section_enabled'] = $lm_section_enabled;
				$fields['lm_section_parent_id'] = $lm_section_parent_id;
				$fields['lm_section_comments'] = $lm_section_comments;

				if(($lm_section_op == 'insert') &&
					(!Ccms::$cDBcms->perform('lm_sections',$fields,'insert',''))) {
					Ccms::addMsg('Section insert, ' . $lm_section_name . " failed");
					} // if
				else if(($lm_section_op == 'save') &&
					(!Ccms::$cDBcms->perform('lm_sections',$fields,'update',"lm_section_id = " . (int)$lm_section_id . ""))) {
					Ccms::addMsg('Section update, ' . $lm_section_name . " failed");
					} // if
				else {
					// Ccms_base::unset_cms_sess_var('lm_section_id');
					Ccms_export::export_table('lm_sections');
					Ccms::addMsg('Saved section config.','success');
					Ccms::do_cms_return_action();
					} // else
				new Ccms_xml_sitemap();	// do sitemap
				$lm_section_id = 0;
				$lm_section_op = '';
				$lm_section_added = '';
				$lm_section_updated = '';
				$lm_section_clone_insert = false;
				$lm_section_clone = false;
				} // if
			} // if
		if((($lm_section_op == 'clone') || ($lm_section_clone_insert)) &&
			(((int)$lm_section_clone_from_id > 0) || ((int)$lm_section_id > 0))) {
			$lm_section_clone_from_id = (((int)$lm_section_clone_from_id > 0) ? $lm_section_clone_from_id:$lm_section_id);
			$lm_section_clone = true;	// retry !!
			$lm_section_op = 'insert';
			$lm_section_id = 0;
			Ccms::addMsg('Cloning user "' . $lm_section_name . '".','info');
			} // if
		} // if

	if((Ccms::get_cms_action() == 'cms_edit_sections') && // a bit of caution
		($lm_section_qk_op = Ccms::get_or_post('lm_section_qk_op')) &&
		($lm_section_qk_id = Ccms::get_or_post('lm_section_qk_id'))) {	// single value change
		switch($lm_section_qk_op) {
		case 'edit_section_qk':
			$lm_section_qk_parent_id = Ccms::get_or_post('lm_section_qk_parent_id');
			if(is_numeric($lm_section_qk_parent_id)) {
				$sql = "UPDATE lm_sections SET lm_section_parent_id = " . (int)$lm_section_qk_parent_id . ' WHERE lm_section_id = ' . (int)$lm_section_qk_id;
				if(!Ccms::$cDBcms->query($sql)) {
					Ccms::addMsg('Failed to update section parent.');
					} // if
				} // if
			break;
		case 'edit_section_input':
			if(($lm_section_qk_type = Ccms::get_or_post('lm_section_qk_type')) &&
				($lm_section_qk_name = Ccms::get_or_post('lm_section_qk_name')) &&
				($lm_section_qk_value = Ccms::get_or_post('lm_section_qk_value'))) {
				$sql = false;
				switch($lm_section_qk_type) {
				case 'checkbox':
					switch($lm_section_qk_name) {
					case 'lm_section_qk_delete': // confirm already checked
						if($lm_section_qk_value == 'on') {
							$sql = "DELETE FROM lm_sections" .
								' WHERE lm_section_id = ' . (int)$lm_section_qk_id;
							} // if
						break;
					default:
						$sql = "UPDATE lm_sections SET " . $lm_section_qk_name . " = '" . (($lm_section_qk_value == 'on') ? 1:0) . "'" .
							' WHERE lm_section_id = ' . (int)$lm_section_qk_id;
						break;
						} // switch
					break;
				case 'number':
					$sql = "UPDATE lm_sections SET " . $lm_section_qk_name . " = " . (int)$lm_section_qk_value . "" .
						' WHERE lm_section_id = ' . (int)$lm_section_qk_id;
					break;
				default:	// treat the rest as text
					$sql = "UPDATE lm_sections SET " . $lm_section_qk_name . " = '" . $lm_section_qk_value . "'" .
						' WHERE lm_section_id = ' . (int)$lm_section_qk_id;
					break;
					} // switch
				if(!empty($sql)) {
					if(!Ccms::$cDBcms->query($sql)) {
						Ccms::addMsg('Failed to update section ID: ' . (int)$lm_section_qk_id . ', name: ' . $lm_section_qk_name . '.');
						} // if
					else Ccms::addDebugMsg('Updated section ID: ' . (int)$lm_section_qk_id . ', name: ' . $lm_section_qk_name . '.','success');
					} // if
				} // if
			break;
		default:
			break;
			} // switch
		$lm_section_qk_id = 0;
		$lm_section_qk_op = '';
		} // if
	} // if
$cnt = Ccms::$cDBcms->get_row_count_in_table('lm_sections');
$row = 0;

$edit_section_qk_filter = Ccms::get_or_post_keyed_session_var('edit_section_qk_filter');
$edit_section_qk_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_section_qk_enabled');

if((!Ccms::is_get_or_post('section_edit_id')) &&
	(Ccms::get_or_post('lm_section_qk_anchor') != 'null')) {	// return anchor
	$edit_section_qk_anchor = Ccms::get_or_post_keyed_session_var('lm_section_qk_anchor');
	} // if
else $edit_section_qk_anchor = false;	// edit the link

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<script type="text/javascript">
	function submit_edit_section_qk_input(event,obj,id,anchor) {
		if(obj.tagName != 'INPUT')
			return false;
		var name = obj.name;
		var form = document.createElement("FORM");

		form.method = "POST";
		form.action = "<?= $_SERVER['PHP_SELF'] ?>";

		var element1 = document.createElement("input");
		element1.value = "cms_edit_sections";
		element1.name = "cms_action";
		form.appendChild(element1);

		var element2 = document.createElement("input");
		element2.name = "lm_section_qk_op";
		element2.value = "edit_section_input";
		form.appendChild(element2);

		var element3 = document.createElement("input");
		element3.value = id;
		element3.name = "lm_section_qk_id";
		form.appendChild(element3);

		var element4 = document.createElement("input");
		element4.value = obj.type;
		element4.name = 'lm_section_qk_type';
		form.appendChild(element4);

		var element5 = document.createElement("input");
		element5.name = "lm_section_qk_name";
		element5.value = name;
		form.appendChild(element5);

		var element6 = document.createElement("input");
		if(obj.type == 'checkbox') {
			var chkd = obj.checked;
			element6.value = (chkd ? 'on':'off');
			} // if
		else element6.value = obj.value;
		element6.name = 'lm_section_qk_value';
		form.appendChild(element6);

		var element7 = document.createElement("input");
		element7.name = "lm_section_qk_anchor";
		element7.value = (anchor ? anchor:'');
		form.appendChild(element7);

		document.body.appendChild(form);
		form.submit();

		} // submit_edit_section_qk_section_input()

</script>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Sections Config</h1>
		</th>
	</tr>
	<?php if($lm_section_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php Ccms::$cDBcms->installDatabase('lm_sections',true ,true) ?>
		</td>
	</tr>
	<?php } // if ?>
	<form method="post" name="edit_section" action="index.php" method="post" enctype="multipart/form-data">
		<input type="hidden" name="cms_action" value="cms_edit_sections">
	<?= Ccms_search::get_form_search_hidden_inputs() ?>
	<?php Ccms::set_form_cms_return_action() ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Select section name:&nbsp;
			<?=  Ccms::gen_section_selection_list('section_edit_id',$lm_section_id,'size="1"') ?>
			<?php if($cnt > 0) { ?>
			&nbsp;&nbsp;
<!--			<button name="edit" value="edit" type="submit">Edit</button>
			&nbsp;&nbsp;-->
			<button name="delete" value="delete" type="submit">Delete</button>
			<?php	} //if ?>
			&nbsp;&nbsp;
			<button name="add" value="add" type="submit">Add</button>
			<?php if(CMS_S_ALLOW_TABLE_RELOAD_BOOL) { ?>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Sections table operations:&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" title="Clear and re-initialise sections table in database." onClick="return confirm('Clear and re-initialise sections table in database?')">Reload</button>
			<?php	} // if ?>
			<?= Ccms_export::get_table_form_text('lm_sections') ?>
			<?php Ccms::get_return2search_link() ?>
		</td>
	</tr>

	<?php
	if((($lm_section_op == 'edit') || ($lm_section_op == 'save') ||
		($lm_section_op == 'add') || ($lm_section_op == 'insert')) &&
		(isset($lm_section_id))) {
	?>
	<tr class="page_config">
		<th class="page_config">
			<?php if($lm_section_id == 0) {
				echo 'Add Section';
				} // if
			else {
				echo 'Edit Section' .
					'&nbsp;&nbsp;<span class="page_config">(Added:&nbsp;' . $lm_section_added .
					'&nbsp;&nbsp;Updated:&nbsp;' . $lm_section_updated . ')</span>';
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $lm_section_name))
					Ccms::get_return2search_link(true);
				} // else
			?>
		</th>
	</tr>
	<input type="hidden" name="lm_section_id" value="<?= $lm_section_id ?>"/>
	<input type="hidden" name="lm_section_name_old" value="<?= htmlentities($lm_section_name) ?>"/>
	<input type="hidden" name="lm_section_added" value="<?= htmlentities($lm_section_added) ?>"/>
	<input type="hidden" name="lm_section_updated" value="<?= htmlentities($lm_section_updated) ?>"/>
<?php if ($lm_section_clone) { ?>
	<input type="hidden" name="lm_section_clone" value="true"/>
	<input type="hidden" name="lm_section_clone_from_id" value="<?= $lm_section_clone_from_id ?>"/>
<?php	} // if ?>
	<tr class="page_config page_config_sticky">
		<td class="page_config">
			<div class="cms_sticky_left">
				<?php if($lm_section_id == 0) { ?>
				<button name="insert" value="insert" type="submit">Add</button>
				<?php } else { ?>
				<button name="save" value="save" type="submit">Save</button>
				&nbsp;&nbsp;
				<button name="clone" value="clone" type="submit">Clone</button>
				<?php	} // else ?>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
			</div>
		</td>
	</tr>
	<tr>
		<td>
			<table class="page_config page_config_edit">
<?php if($lm_section_clone) { ?>
				<tr class="page_config">
					<th class="page_config">Cloning Section:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Make changes to the cloned section of "' . $lm_section_name . '" to ensure uniqueness.','info') ?>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Section Name:</th>
					<td class="page_config">
						<input type="text" name="lm_section_name" size="40" value="<?= $lm_section_name ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						 Unique section name. Appears on page as a section heading. Minimum of 4 characters.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Columns:</th>
					<td class="page_config">
						<input type="number" name="lm_section_columns" size="8" value="<?= $lm_section_columns ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Number of columns across the page for links in this section. Maximum of 10 columns.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Description:</th>
					<td class="page_config">
						<input type="text" name="lm_section_description" size="80" value="<?= $lm_section_description ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Section description (optional), appears under the name.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Title:</th>
					<td class="page_config">
						<input type="text" name="lm_section_title" size="80" value="<?= $lm_section_title ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Section title (optional), appears when mouse is hovered over section name or image.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<?php echo Ccms_html::get_textarea_input('lm_section_comments',$lm_section_comments,false,' rows="2" autocapitalize="off"'); ?>
					</td>
					<td class="page_config">
						<?= Ccms::getAdminCommentHint('edit_sections',$lm_section_name) ?>
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config" valign="top">Select group/s:</th>
					<td class="page_config">
						<?=  Ccms::gen_group_selection_list('lm_section_group_ids[]',$lm_section_group_ids, 10, ' multiple') ?>
					</td>
					<td class="page_config">
						Select the groups the link section will appear under.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Image URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('lm_section_image_url', $lm_section_image_url, ETC_WS_IMAGES_DIR,'',false) ?>
					</td>
					<td class="page_config">
						<?= $cCMS_C->show_image($lm_section_image_url,ETC_WS_IMAGES_DIR,'page_config') ?>
						Section image (optional). Images are stored in the &quot;<?= ETC_WS_IMAGES_DIR ?>&quot; directory.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Icon URI:</th>
					<td class="page_config">
						<?= $cCMS_C->input_image('lm_section_icon_url', $lm_section_icon_url, ETC_WS_ICONS_DIR,'',false) ?>
					</td>
					<td class="page_config">
						<?= $cCMS_C->show_image($lm_section_icon_url,ETC_WS_ICONS_DIR,'page_config') ?>
						Section icon (optional). Icons are stored in the &quot;<?= ETC_WS_ICONS_DIR ?>&quot; directory.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Display Order:</th>
					<td class="page_config">
						<input type="number" name="lm_section_order" size="5" value="<?= $lm_section_order ?>" autocapitalize="off"/>
					</td>
					<td class="page_config">
						Sorting order of section. Used to control the order of the section. Low numbers at the top of the page, ascending down the page.
					</td>
				</tr>
				<tr>
					<th  class="page_config">Parent Section:</th>
					<td class="page_config">
						<?=  Ccms::gen_section_selection_list('lm_section_parent_id', $lm_section_parent_id, 'size="1"',$lm_section_id, false, false) ?>
					</td>
					<td class="page_config">
						Select parent section for this section to appear inside.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Enabled:</th>
					<td class="page_config">
						<input type="checkbox" name="lm_section_enabled"<?= ($lm_section_enabled > 0 ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to enable section, uncheck to disable section (all links under the section are also disabled).
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: right;">
			<?php if($lm_section_id == 0) { ?>
			<button name="insert" value="insert" type="submit">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit">Save</button>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
		</td>
	</tr>
	<?php } else if(($lm_section_op == 'delete') && (isset($lm_section_id)) && ($lm_section_id > 0)) { ?>
	<tr class="page_config"><th class="page_config">Delete Section - <?= $lm_section_name ?></th></tr>
	<input type="hidden" name="lm_section_id" value="<?= $lm_section_id ?>"/>
	<input type="hidden" name="lm_section_name" value="<?= htmlentities($lm_section_name) ?>"/>
	<tr class="page_config">
		<td class="page_config">
			Please confirm.
			&nbsp;&nbsp;
			<button name="confirm_delete" value="confirm_delete" type="submit">Confirm Delete</button>
			&nbsp;&nbsp;
			<input type="checkbox" name="del_sect_links" title="Also delete child sections and links in the section.">Delete Links
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" formnovalidate>Cancel</button>
		</td>
	</tr>
	<?php	} ?>
	</form>
</table>

<?php
include(CMS_FS_OPS_DIR . 'cms_edit_sections_list.php');
Ccms::page_end_comment(__FILE__);
