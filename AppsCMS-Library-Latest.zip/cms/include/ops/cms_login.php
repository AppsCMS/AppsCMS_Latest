<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_login.php 3100 2023-02-06 02:08:30Z robert0609 $
 */

if(Ccms_auth::is_login_allowed()) {	// not possible
?>
<?php Ccms::page_start_comment(__FILE__) ?>
	<table class="page_body login_extra">
		<caption>Log in page</caption>
		<tr class="page_body">
			<td class="page_body">&nbsp;</td>
			<td class="page_body login_extra">
				<div class="login_extra">
<?php
					Ccms::get_app_action(false);
					$text = Ccms_auth::get_login_logout('',false);
					// $text = Ccms_auth::get_signin_signout('',false);
					echo $text;
?>
				</div>
			</td>
			<td class="page_body">&nbsp;</td>
		</tr>
	</table>

<?php
	Ccms::page_end_comment(__FILE__);
	} // if
else {
	$url = CMS_WWW_URL . 'index.php?action=home';
	header('Location: ' . $url);
	exit(0);
	} // else
