<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_search.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

$results = Ccms_search::search();

if(!Ccms::is_get_or_post('ajax')) { ?>
<?php Ccms::page_start_comment(__FILE__) ?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<script type="text/javascript">
	var last_ajax_run_call = null;
	var ajax_running = false;
	var ajax_deb = 1200;
	function ajax_run(id) {
		if(ajax_running) return;
		if(last_ajax_run_call != null) {	// clear it
			window.clearTimeout(last_ajax_run_call);
			last_ajax_run_call = null;
			} // if
		// restart if
		last_ajax_run_call = window.setTimeout(function(id) {
			// return;	// test
			ajax_running = true;
			var min_l = 4;
			var keywords = document.getElementById(id).value.toString();
			if((keywords.length < min_l) ||
				(keywords.length == 0)) {
				document.getElementById('page_contents_ajax').innerHTML = "Minimum of " + min_l + " characters required.";
				ajax_running = false;
				return;
			} // if
			keywords = encodeURI(keywords);
			var exact = document.getElementById(id + '_exact').checked;
			var body_url = 'cms_edit_search&search=' + keywords + (exact ? '&exact=on':'');
			cms_ajax_body_page(body_url,'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
			ajax_running = false;
			return;
			},
		ajax_deb, id);
		} // ajax_run()
</script>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config" style="text-align: left">
			<h1 class="page_config">Search</h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form method="post" name="cms_edit_search" action="index.php">
				<input type="hidden" name="cms_action" value="cms_edit_search">
			<?= Ccms_search::get_form_search_hidden_inputs() ?>
				<span style="white-space: nowrap;">
					<label>
						<input type="text"
							id="keywords"
							name="keywords"
							style="width: unset;"
							oninput="javascript:ajax_run('keywords');"
							value="<?= ((Ccms::is_get_or_post('keywords')) ? Ccms::get_or_post('keywords'):((Ccms::is_get_or_post('search')) ? Ccms::get_or_post('search'):'')) ?>"
							title="<?= Ccms_search::help() ?>" autofocus autocapitalize="off"/>
						<button name="search" value="search" type="submit" onclick="Ccms_cursor.setWait();" title="Start the search.">Search</button>
					</label>
					<label>Exact:
						<input type="checkbox"  id="keywords_exact" name="exact"
							oninput="javascript:ajax_run('keywords');"
							title="Check for exact match." <?= (Ccms::get_or_post_checkbox('exact') ? ' CHECKED':'') ?>
							/>
					</label>
				</span>
			</form>
		</td>
	</tr>
</table>
<span id="page_contents_ajax" style="position: relative; ">
<?php	} // if ?>

	<table class="page_config">
		<?php if(Ccms::getMsgsCount()) { ?>
		<tr class="page_config_msgs">
			<td class="page_config_msgs">
				<?= Ccms::getMsgs() ?>
			</td>
		</tr>
<?php } //if ?>
<?php
	if(!empty($results)) {
		$cnt = 0;
		$keywords = $results['keywords'];
		unset($results['keywords']);
		foreach($results as $area) {
			if(!isset($area[0])) continue;	// no result
			$title = $area['title'];
			unset($area['title']);
?>
		<tr class="page_config">
			<th class="page_config" style="text-decoration: underline;">
				<?= $title ?>
			</th>
		</tr>
<?php

		for($i = 0; $i < count($area); $i++) {
			$meta = '';
			if(isset($area[$i]['meta'])) {
				$meta = Ccms_search::make_meta_search_text($area[$i]['meta']);
				} // if
			$a_txt = &$area[$i]['text'];
			$text = '<strong>' . $a_txt['name'] . '</strong>';
			$text .= ' = ';
			$text .= '&quot;' . $a_txt['str'] . '&quot;';
			if(!empty($a_txt['more'])) $text .= $a_txt['more'];

?>
		<tr class="page_config">
			<td class="page_config">
				<a href="<?= $area[$i]['uri'] ?>" onclick="Ccms_cursor.setWait();"><?= $text ?></a>
				<?= $meta ?>
			</td>
		</tr>
<?php
				$cnt++;
				} // for
			} // foreach
		if(!$cnt) Ccms::addMsg('No results found for: "' . $keywords . '"','warning');
		} // if
	else {
?>
<!--		<tr class="page_config">
			<td class="page_config">
				<?= Ccms_search::help() ?>
			</td>
		</tr>-->
<?php	} // else ?>
<?php if(Ccms::getMsgsCount()) { ?>
		<tr class="page_config_msgs">
			<td class="page_config_msgs">
				<?= Ccms::getMsgs() ?>
			</td>
		</tr>
<?php } //if ?>
	</table>
<?php
if(!Ccms::is_get_or_post('ajax')) {
	echo '</span>';
	Ccms::page_end_comment(__FILE__);
	} // if
