<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_closed.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

$reason_closed = '';
if(strlen(CMS_S_WEBSITE_CLOSED_REASON) >= LM_C_MIN_NAME_LEN) $reason_closed = CMS_S_WEBSITE_CLOSED_REASON;
else $reason_closed = 'Web Site Not Available.';

?>
<!DOCTYPE html>
<html dir="ltr"<?= (preg_match('/^UTF/i',CMS_S_CHAR_SET) ? ' lang="' . CMS_S_LANGUAGE_CODE . '"':'') ?>>
	<head>
		<meta charset="<?= CMS_S_CHAR_SET ?>">
		<title><?= CMS_C_CO_NAME ?> Closed</title>
		<META NAME="GENERATOR" CONTENT="<?= CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION ?>">
		<meta http-equiv="refresh" content="600">
	</head>
	<body>
<?php	Ccms::page_start_comment(__FILE__) ?>
		<p style="text-align: center; font-weight: bolder;"><?= ((strlen(CMS_C_CO_NAME) > 4) ? CMS_C_CO_NAME:CMS_WWW_URL) ?></p>
		<p style="text-align: center; font-weight: bolder;">
<?php
	if(file_exists(DOCROOT_FS_BASE_DIR . $reason_closed)) {
		include(DOCROOT_WS_BASE_DIR . $reason_closed);
		} // if
	else echo $reason_closed;


?>
		</p>
<?php
	Ccms::page_end_comment(__FILE__);
	Ccms::do_analytics_include();
?>
	</body>
</html>

