<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_text_view.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of text_view
 * general text file viewer
 *
 * @author robert0609
 */

$uri = Ccms::get_or_post('uri');
$ret = Ccms::get_or_post('ret');

Ccms::page_start_comment(__FILE__);
Ccms::get_admin_scroll2pageTop();
?>
<table class="page_config">
	<tr class="page_config">
		<td class="page_config" style="padding: 10px;">
			<?php Ccms_media_conv_plugin::prn_text_file2html($uri); 	?>
		</td>
	</tr>
<?php if(!empty($ret)) { ?>
	<tr class="page_config">
		<td class="page_config" style="padding-left: 10px; text-align: left;">
			<form action="<?= $ret ?>" method="POST">
				<button type="submit" title="Return to previous page.">Go Back</button>
			</form>
		</td>
	</tr>
<?php	} //if ?>
</table>

<?php
Ccms::page_end_comment(__FILE__);

