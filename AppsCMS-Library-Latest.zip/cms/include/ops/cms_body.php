<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_body.php 3137 2023-02-14 11:20:25Z robert0609 $
 */

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php
$body_cnt = Ccms::get_body_cnt();
$filename = '';
$body = '';
if($body_cnt > 0) {
	if(!$body = Ccms::get_body()) {	// should not happen
		Ccms::log_msg('ERROR: Could not find a page body.');
		return;
		} // if
	} // if
if(Ccms::is_full_body_view()) {	// should not get gere
	Ccms::output_body_core($body);
	return;
	} // if
if(Ccms::is_iframe_body_view()) {
	$url = Ccms::get_body_uri($body,false,true);
	$title = Ccms::get_body_title($body);
	Ccms::output_iframe_site_text($url,$title);
	return;
	} // if
?>

<?php if((Ccms::$cms_body_default_msgs) && (Ccms::getMsgsCount())) { ?>

	<div class="page_body_msgs">
		<?= Ccms::getMsgsTable() ?>
	</div>
<?php } //if ?>
<?php
if($body_cnt > 0) {
?>

	<div class="page_body">
<?php
		Ccms::output_body_core($body);
?>
	</div>
<?php	} // if ?>
<?php if((Ccms::$cms_body_default_msgs) && (Ccms::getMsgsCount())) { ?>
	<div class="page_body_msgs">
		<?= Ccms::getMsgsTable() ?>
	</div>
<?php } //if ?>

<?php Ccms::page_end_comment(__FILE__) ?>
