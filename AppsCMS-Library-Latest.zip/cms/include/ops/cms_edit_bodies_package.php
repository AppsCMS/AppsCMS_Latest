<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_bodies_package.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

$cms_apps_types = Ccms_DB_checks::get_apps_types_configs();

Ccms::page_start_comment(__FILE__);

?>

<form name="edit_body" action="index.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="cms_action" value="cms_edit_bodies">
<?= Ccms_search::get_form_search_hidden_inputs() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Page Bodies / Applications Packager</h1>
		</th>
	</tr>
	<tr class="page_config">
		<th class="page_config">
			Select &quot;<?= $cms_body_name ?>&quot; Application Package Dependencies and Accompanying Applications.
			<input type="hidden" name="cms_body_id" value="<?= $cms_body_id ?>"/>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
<?php 
		$cAppInstall = new Ccms_app_install('package',$cms_body_id,false);
?>
 		</td>
	</tr>
</table>
</form>

<?php Ccms::page_end_comment(__FILE__) ?>
