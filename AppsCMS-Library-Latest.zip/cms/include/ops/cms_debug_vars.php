<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_debug_vars.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

function help() {
	$text = "Enter search keywords, separated by spaces. Hits shown in RED.";
	return $text;
	} // help()

function bool_debug(&$val) {
	if(is_array($val)) {
		foreach($val as $k => &$v) {
			bool_debug($v);	// recurse
			} // foreach
		} // if
	if($val === true) $val = '(bool true)';
	else if($val === false) $val = '(bool false)';
	} // bool_debug()

function filter_debug(&$filter,$n,&$v,$exact) {
	if(empty($filter)) return '';	// show all
	if(empty($n)) return false;

	bool_debug($v);
	$str = strtolower((empty($n) ? '':$n));
	$txt = str_replace(PHP_EOL," ",print_r($v,true));
	$str .= ' ' . strtolower($txt);
	if(empty($str)) return false;
	$meta = Ccms_search::search_cmp($filter, $str,$exact);
	if(!$meta) return false;
	return Ccms_search::make_meta_search_text($meta);
} // filter_debug()

function pretty_debug(&$filter,$v) {
	bool_debug($v);
	$txt = print_r($v,true);
	$txt = str_replace(PHP_EOL,"\t\n",$txt);
	$txtw = wordwrap($txt, 80, "\n\t->\t", true);
	$txtx = preg_replace('/\n\t->\t\[/',' [',$txtw);	// remove over wrapped
	$txt = Ccms::hilite_filter($filter, $txtx);
	$txt = "<pre>" . $txt . "</pre>";
	return $txt;
} // pretty_debug()

$filter = Ccms_search::get_form_search_input_keywords_ary();
$exact = Ccms::get_or_post_checkbox('exact');

?>

<?php if(!Ccms::is_get_or_post('ajax')) { ?>
<?php Ccms::page_start_comment(__FILE__) ?>
<?= Ccms::get_admin_scroll2pageTop() ?>
<script type="text/javascript">
	var last_ajax_run_call = null;
	var ajax_running = false;
	var ajax_deb = 1200;
	function ajax_run(id) {
		if(ajax_running) return;
		if(last_ajax_run_call != null) {	// clear it
			window.clearTimeout(last_ajax_run_call);
			last_ajax_run_call = null;
			} // if
		// restart if
		last_ajax_run_call = window.setTimeout(function(id) {
			// return;	// test
			ajax_running = true;
			var min_l = 3;
			var keywords = document.getElementById(id).value.toString();
			if((keywords.length < min_l) ||
				(keywords.length == 0)) {
				document.getElementById('page_contents_ajax').innerHTML = "Minimum of " + min_l + " characters required.";
				ajax_running = false;
				return;
			} // if
			keywords = encodeURI(keywords);
			var exact = document.getElementById(id + '_exact').checked;
			var body_url = 'cms_debug_vars&search=' + keywords + (exact ? '&exact=on':'');
			cms_ajax_body_page(body_url,'page_contents_ajax');	// the "cms/cms_ajax.php?ajax=" is prefixed to the url by the Ccms_ajaxOps class
			ajax_running = false;
			return;
			},
		ajax_deb, id);
		} // ajax_run()
</script>
<table class="page_config">
	<caption>Debug variables for <?= strip_tags(CMS_PROJECT_SHORTNAME) ?> page</caption>
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Debug Values Page</h1>
		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<form method="post" name="cms_debug_view" action="index.php" onsubmit="Ccms_cursor.setWait();">
				<input type="hidden" name="cms_action" value="cms_debug_vars">
			<?php if(Ccms::is_get_or_post('keywords'))
				echo '<input type="hidden" name="search" value="' . Ccms::get_or_post('keywords') . '"/>' ?>
				<input type="text" id="keywords" name="keywords" size="40"
					oninput="javascript:ajax_run('keywords');"
					value="<?= ((Ccms::is_get_or_post('keywords')) ? Ccms::get_or_post('keywords'):((Ccms::is_get_or_post('search')) ? Ccms::get_or_post('search'):'')) ?>"
					title="<?= help() ?>" autofocus autocapitalize="off"/>
				<button name="search" value="search" type="submit" onclick="Ccms_cursor.setWait();" title="Start the search.">Filter / Search</button>
				<label>Exact:
					<input type="checkbox"  id="keywords_exact" name="exact"
						oninput="javascript:ajax_run('keywords');"
						title="Check for exact match." <?= (Ccms::get_or_post_checkbox('exact') ? ' CHECKED':'') ?>
						/>
				</label>
			</form>
		</td>
	</tr>
</table>
<span id="page_contents_ajax" style="position: relative; ">
<?php	} // if ?>
	<table class="page_config" style="color: black; background-color: white;">
		<tr class="page_config">
			<th class="page_config">
				<a name="Defines"></a>
				Web Site Global Constants
			</th>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<table class="page_config">
					<tr class="page_config">
						<th class="page_config" title="e.g. from define() function.\nCMS_S_ prefix is installer values,\nCMS_C_ prefix is from the sqlite conf table,\nPL_ prefix is for a plugin setting in the sqlite conf table,\nothers are from the fixed and auto configuration generation.">Definition Name:</th>
						<th class="page_config" title="defined value. Where the value is not printable it is convert to the closest html equivalent.">Value:</th>
					</tr>
<?php
		Ccms::get_bodies();	// get body defines
		$consts = get_defined_constants(true);
		$cnt = 0;
		ksort($consts['user']);
		foreach($consts['user'] as $n => $v) {	// do user defined
			if(($meta = filter_debug($filter,$n,$v,$exact)) === false) continue;
			echo '	<tr class="' . (($cnt++ & 1) ? 'page_config_odd':'page_config_even') . '">';
			echo '		<td class="page_config" style="vertical-align: top; font-weight: bold;">' . Ccms::hilite_filter($filter, $n) . $meta . '</td>' .
				'<td class="page_config" style="vertical-align: top;">' . pretty_debug($filter,$v) . '</td>';
			echo '	</tr>' . PHP_EOL;
			} // foreach
		if($cnt == 0) {
			echo '	<tr><td class="page_config">' .'Nothing found.' . '</td></tr>';
			} // if
?>
				</table>
			</td>
		</tr>
		<tr class="page_config">
			<th class="page_config">
				<a name="Globals"></a>
				Global Variables
			</th>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<table class="page_config">
					<tr class="page_config">
						<th class="page_config" title="Global variables generated the server and web site">Global Variable Name:</th>
						<th class="page_config" title="current value. May change as the site and server operate.">Value:</th>
					</tr>
<?php
		$gvars = $GLOBALS;	// get_defined_vars(true);
		$gvars['PHP'] = @file_get_contents("php://input");
		unset($gvars['GLOBALS']); // stop the recursion
		$cnt = 0;
		ksort($gvars);
		foreach($gvars as $n => $v) {	// do global vars
			if(empty($v)) continue;
			if(is_object($v)) continue;
			if(($meta = filter_debug($filter,$n,$v,$exact)) === false) continue;
			echo '	<tr class="' . (($cnt++ & 1) ? 'page_config_odd':'page_config_even') . '">';
			echo '		<td class="page_config" style="vertical-align: top; font-weight: bold;">' . '&#36;' . Ccms::hilite_filter($filter, $n) . $meta . '</td>' .
				'<td class="page_config" style="vertical-align: top;">' . pretty_debug($filter,$v) . '</td>';
			echo '	</tr>' . PHP_EOL;
			} // foreach
		if($cnt == 0) {
			echo '	<tr><td class="page_config">' .'Nothing found.' . '</td></tr>';
			} // if
?>
				</table>
			</td>
		</tr>

		<tr class="page_config">
			<th class="page_config">
				<a name="CMSclassVariables"></a>
				Main <?= CMS_PROJECT_SHORTNAME ?> &quot;Ccms&quot; Class Variables
			</th>
		</tr>
		<tr class="page_config">
			<td class="page_config">
				<table class="page_config">
					<tr class="page_config">
						<th class="page_config" title="Ccms class variables ">Class Variable Name:</th>
						<th class="page_config" title="Current value. May change as the site and server operate.">Value:</th>
					</tr>
<?php
		global $cCMS;
		$class_vars = get_class_vars(get_class($cCMS));
		$cnt = 0;
		ksort($class_vars);
		foreach($class_vars as $n => $v) {	// do class vars
			if(($meta = filter_debug($filter,$n,$v,$exact)) === false) continue;
			echo '	<tr class="' . (($cnt++ & 1) ? 'page_config_odd':'page_config_even') . '">';
			echo '		<td class="page_config" style="vertical-align: top; font-weight: bold;">' . '&#36;' . Ccms::hilite_filter($filter, $n) . $meta . '</td>';
			echo '		<td class="page_config" style="vertical-align: top;">' . pretty_debug($filter,$v) . '</td>';
			echo '	</tr>' . PHP_EOL;
			} // foreach
		if($cnt == 0) {
			echo '	<tr><td class="page_config">' .'Nothing found.' . '</td></tr>';
			} // if
?>
				</table>
			</td>
		</tr>

	</table>
<?php if(!Ccms::is_get_or_post('ajax')) { ?>
</span>
<?php
	Ccms::page_end_comment(__FILE__);
	} // if

