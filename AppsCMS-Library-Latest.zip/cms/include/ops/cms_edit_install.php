<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_install.php 3050 2022-12-16 03:17:35Z robert0609 $
 */

$cms_install_id = 0;
$cms_install_op = '';
if(Ccms::get_cms_action() == 'cms_edit_install') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('edit_options_ary')) && (is_array(Ccms::get_or_post('edit_options_ary')))) {
		Ccms_xml_sitemap::reset_xml_sitemap();
		$install = Ccms::get_or_post('edit_options_ary');
		Ccms_options::convert_ini_cms_form_input($install);
		Ccms::save_cms_ini_settings($install);
		Ccms::unset_get_or_post('save');
		Ccms::unset_get_or_post('edit_options_ary');
		} // if
	else if((Ccms::is_get_or_post('reloadINI')) && (Ccms::get_or_post('reloadINI') == 'reloadINI')) {
		if(Ccms::reload_ini_default_settings()) {
			Ccms::addMsg("Set install to default settings.",'info');
			} // if
		$cms_theme_op = '';
		$cms_theme_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_install_op = 'cancel';
		$cms_install_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('name')) {
		$cms_install_op = 'scroll';
		$cms_install_id = Ccms::get_or_post('name');
		} // else if
	} // if
?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php
	$h1 = 'Install Configuration';
	$conf = Ccms::read_cms_ini_settings(false,Ccms::get_theme_ini_sections());
	$comments = Ccms::read_cms_ini_comments(false,Ccms::get_theme_ini_sections());
	new Ccms_edit('cms_edit_install', $h1, $conf, $comments);
?>

<?php Ccms::page_end_comment(__FILE__) ?>
