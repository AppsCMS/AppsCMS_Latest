<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_no_cookie.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

?>
<?=	Ccms::page_start_comment(__FILE__) ?>
		<p style="text-align: center; font-weight: bolder;">
			<span class="cms_msg_warning">
				Please enable session cookies to login.
			</span>
		</p>
<?=	Ccms::page_end_comment(__FILE__) ?>

