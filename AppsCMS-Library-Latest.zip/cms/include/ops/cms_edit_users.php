<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_users.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

$cms_user_id = 0;
$cms_user_op = '';
$cms_user_clone = false;
$cms_user_clone_from_id = Ccms::get_or_post("cms_user_clone_from_id");
$cms_user_clone_insert = ((Ccms::get_or_post("cms_user_clone") == 'true') ? true:false);

Ccms_export::export_table('cms_users');
if(Ccms::get_cms_action() == 'cms_edit_users') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	if((Ccms::is_get_or_post('delete')) &&
		((Ccms::is_get_or_post('user_edit_id')) || (Ccms::is_get_or_post('cms_user_id')))) {
		$cms_user_op = 'delete';
		$cms_user_id = (int)(Ccms::is_get_or_post('cms_user_id') ? Ccms::get_or_post('cms_user_id'):Ccms::get_or_post('user_edit_id'));

		$sql_query = "SELECT  cms_user_name,cms_user_admin,cms_user_enabled" .
					" FROM  cms_users WHERE  cms_user_id = '" . (int)$cms_user_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($user = Ccms::$cDBcms->fetch_array($result))) {
			foreach($user as $k => &$v) $$k = $v;
			} // if
		} // else if
	else if((Ccms::is_get_or_post('confirm_delete')) && (Ccms::is_get_or_post('cms_user_id'))) {
		$cms_user_op = 'confirm_delete';
		$cms_user_id = (int)Ccms::get_or_post('cms_user_id');

		$sql_query = "DELETE FROM  cms_users WHERE  cms_user_id = '" . (int)$cms_user_id . "'";
		Ccms::$cDBcms->query($sql_query);
		$cms_user_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('add')) {
		$cols = Ccms::$cDBcms->get_columns_list('cms_users',true);
		foreach($cols as $c => $v) $$c = $v;
		$cms_user_op = 'add';
		$cms_user_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('insert')) && (Ccms::is_get_or_post('cms_user_id'))) {
		$cms_user_op = 'insert';
		} // else if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('cms_user_id'))) {
		$cms_user_op = 'save';
		} // else if
	else if((Ccms::is_get_or_post('clone')) && (Ccms::is_get_or_post('cms_user_id'))) {
		$cms_user_op = 'clone';
		$cms_user_clone = true;
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('export'))) {
		$cms_user_op = 'export';
		$cms_user_id = 0;
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('import'))) {
		$cms_user_op = 'import';
		$cms_user_id = 0;
		Ccms_export::import_table('cms_users');
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$cms_user_op = 'reloadDB';
		$cms_user_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_user_op = 'cancel';
		$cms_user_id = 0;
		} // else if
	else if(($cms_user_id = (int)Ccms::get_or_post('user_edit_id')) > 0) {
		$cms_user_op = 'edit';

		$sql_query = "SELECT  cms_user_name,cms_user_enabled, cms_user_admin" .
			", cms_user_group_ids,cms_user_auth_ldap,cms_user_auth_pam,cms_user_api" .
			", cms_user_email,cms_user_email_confirmed,cms_user_mobile,cms_user_mobile_confirmed,cms_user_comments" .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_user_added','cms_user_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_user_updated','cms_user_updated') .
			" FROM  cms_users WHERE  cms_user_id = '" . (int)$cms_user_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($user = Ccms::$cDBcms->fetch_array($result))) {
			$user = array_merge($user, Ccms_auth::get_user_json_data_ary($user['cms_user_name']));
			foreach($user as $k => &$v) $$k = $v;
			} // if
		else { // not found
			$cms_user_id = 0;
			$cms_user_op = '';
			$cms_user_added = '';
			$cms_user_updated = '';
			} // else
		} // if

	if(($cms_user_op == 'insert') || ($cms_user_op == 'clone') || ($cms_user_op == 'save')) {

		$cms_user_id = (int)Ccms::get_or_post('cms_user_id');
		$cms_user_name = html_entity_decode(Ccms::get_or_post('cms_user_name'));
		$cms_user_group_ids = implode(':',Ccms::get_or_post('cms_user_group_ids'));
		$cms_user_password = html_entity_decode(Ccms::get_or_post('cms_user_password'));
		$cms_user_confirm = html_entity_decode(Ccms::get_or_post('cms_user_confirm'));
		$cms_user_admin = Ccms::get_or_post_checkbox('cms_user_admin');
		$cms_user_enabled = Ccms::get_or_post_checkbox('cms_user_enabled');
		$cms_user_auth_ldap = Ccms::get_or_post_checkbox('cms_user_auth_ldap');
		$cms_user_auth_pam = Ccms::get_or_post_checkbox('cms_user_auth_pam');
		$cms_user_api = Ccms::get_or_post_checkbox('cms_user_api');
		// $cms_user_email = html_entity_decode(Ccms::get_or_post('cms_user_email'));
		// $cms_user_mobile = html_entity_decode(Ccms::get_or_post_str('cms_user_mobile'));
		$chkr = new Ccms_config_funcs();	// use the phone number and email address checkers in the config class
		$cms_user_mobile = $chkr->get_mobile_number('cms_user_mobile','');
		$cms_user_mobile_confirmed = Ccms::get_or_post_checkbox('cms_user_mobile_confirmed','');
		$cms_user_email = $chkr->get_email('cms_user_email','');
		$cms_user_email_confirmed = Ccms::get_or_post_checkbox('cms_user_email_confirmed','');
		$cms_user_added = html_entity_decode(Ccms::get_or_post('cms_user_added'));
		$cms_user_updated = html_entity_decode(Ccms::get_or_post('cms_user_updated'));
		$cms_user_comments = Ccms::get_or_post('cms_user_comments');

		$cms_user_eula_time_reset = Ccms::get_or_post_checkbox('cms_user_eula_time_reset');

		// check to see that there is always an administrator
		$admin_cnt = Ccms::$cDBcms->get_row_count_in_table('cms_users','cms_user_admin > 0 AND cms_user_enabled > 0');
		if(($cms_user_name == Ccms_auth::get_logged_in_username()) &&
			($cms_user_op == 'save') &&
			(!$cms_user_admin)) {	// check I am NOT the last admin
			if((int)$admin_cnt <= 1) {
				$cms_user_admin = 1;
				Ccms::addMsg('You are the last administrator, cannot disable administrator.','warning');
				} // if
			else Ccms::addMsg('You are no longer an administrator after you log out.','warning');
			} // if
		if((int)$admin_cnt <= 1) {
			Ccms::addMsg('No available administrators, you are now an administrator.','info');
			$fields = array();
			$fields['cms_user_enabled'] = 1;
			$fields['cms_user_admin'] = 1;
			Ccms::$cDBcms->perform('cms_users',$fields,'update',"cms_user_id = " . (int)Ccms_base::get_cms_sess_var('user','id') . "");
			} // if

		if($cms_user_op != 'clone') {
			if($cms_user_auth_pam) {
				if(!Ccms_auth::is_pam_ok()) {
					self::addMsg('PAM authentication not installed/configured.','warn');
					} // if
				} // if
			Ccms_DB_checks::is_user_password_ok($cms_user_auth_ldap, $cms_user_password, $cms_user_confirm,$cms_user_op);
			Ccms_DB_checks::is_user_name_ok($cms_user_name,$cms_user_op,"cms_user_id != " . (int)$cms_user_id);
			Ccms_DB_checks::is_user_email_ok($cms_user_email,$cms_user_op,"cms_user_id != " . (int)$cms_user_id);
			Ccms_DB_checks::is_user_mobile_ok($cms_user_mobile,$cms_user_op,"cms_user_id != " . (int)$cms_user_id);

			if(!Ccms::getMsgsCount('error')) {	// update it
				if(empty($cms_user_mobile)) $cms_user_mobile = null;	// stop conflict
				if(empty($cms_user_email)) $cms_user_email = null;	// stop conflict
				$fields = array();
				$fields['cms_user_name'] = $cms_user_name;
				$fields['cms_user_group_ids'] = $cms_user_group_ids;
				if(strlen($cms_user_password) > 0) {
					$fields['cms_user_password_md5'] = '';	// depreciated
					$fields['cms_user_passwd_hash'] = Ccms_auth_passwd::hash_passwd($cms_user_password);
					} // if
				$fields['cms_user_enabled'] = $cms_user_enabled;
				$fields['cms_user_admin'] = $cms_user_admin;
				$fields['cms_user_auth_ldap'] = $cms_user_auth_ldap;
				$fields['cms_user_auth_pam'] = $cms_user_auth_pam;
				$fields['cms_user_api'] = $cms_user_api;
				$fields['cms_user_email'] = $cms_user_email;
				$fields['cms_user_email_confirmed'] = $cms_user_email_confirmed;
				$fields['cms_user_mobile'] = $cms_user_mobile;
				$fields['cms_user_mobile_confirmed'] = $cms_user_mobile_confirmed;
				$fields['cms_user_comments'] = $cms_user_comments;

				if($cms_user_eula_time_reset > 0) {
					Ccms_auth::update_user_json_data('cms_user_eula_time',0,$cms_user_name);
					} // if

				if($cms_user_op == 'insert') {
					if(!Ccms::$cDBcms->perform('cms_users',$fields,'insert','')) {
						Ccms::addMsg('User insert, ' . $cms_user_name . " failed");
						} // if
					else {
						// Ccms_base::unset_cms_sess_var('cms_user_id');
						echo '<span class="page_config_msgs">' . 'INFO: New user data saved.</span>' . CMS_NL;
						} // else
					} // if
				else if($cms_user_op = 'save') {
					if(!Ccms::$cDBcms->perform('cms_users',$fields,'update',"cms_user_id = " . (int)$cms_user_id . "")) {
						Ccms::addMsg('User update, ' . $cms_user_name . " failed");
						} // if
					else {
						// Ccms_base::unset_cms_sess_var('cms_user_id');
						Ccms::addMsg('Saved user data.','success');
						Ccms_export::export_table('cms_users');
						Ccms::backupOnSave();
						} // else
					} else
				$cms_user_id = 0;
				$cms_user_op = '';
				$cms_user_clone_insert = false;
				$cms_user_clone = false;
				} // if
			} // if
		if((($cms_user_op == 'clone') || ($cms_user_clone_insert)) &&
			(((int)$cms_user_clone_from_id > 0) || ((int)$cms_user_id > 0))) {
			$cms_user_clone_from_id = (((int)$cms_user_clone_from_id > 0) ? $cms_user_clone_from_id:$cms_user_id);
			$cms_user_clone = true;	// retry !!
			$cms_user_op = 'insert';
			$cms_user_id = 0;
			Ccms::addMsg('Cloning user "' . $cms_user_name . '".','info');
			} // if
		} // if
	} // if
$cnt = Ccms::$cDBcms->get_row_count_in_table('cms_users');

$edit_user_qk_filter = Ccms::get_or_post_keyed_session_var('edit_user_qk_filter');
$edit_user_qk_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_user_qk_enabled');
$edit_user_qk_admin = Ccms::get_or_post_checkbox_keyed_session_var('edit_user_qk_admin');
$edit_user_qk_auth  = Ccms::get_or_post_keyed_session_var('edit_user_qk_auth');

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?php Ccms::set_JS_password_resource() ?>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Users</h1>
		</th>
	</tr>
	<?php if($cms_user_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<?php Ccms::$cDBcms->installDatabase('cms_users',true ,true) ?>
		</td>
	</tr>
	<?php } // if ?>
	<?= Ccms_search::get_form_search_hidden_inputs() ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			<form name="select_user" action="index.php" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_users">
				Select user name:&nbsp;
				<?=  Ccms::gen_user_selection_list('user_edit_id',$cms_user_id,'id="prim_id" size="1" onchange="javascript:setConfigButtons();"') ?>
				<?php if($cnt > 0) { ?>
	<!--			&nbsp;&nbsp;
				<button id="b_edit_id" name="edit" value="edit" type="submit" onclick="Ccms_cursor.setWait();">Edit</button>-->
				&nbsp;&nbsp;
				<button id="b_delete_id" name="delete" value="delete" type="submit" onclick="Ccms_cursor.setWait();">Delete</button>
				<?php	} //if ?>
				&nbsp;&nbsp;
				<button name="add" value="add" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
				<?php if((Ccms_auth::is_cms_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
				&nbsp;&nbsp;
				<button name="reloadDB" value="reloadDB" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise users table in database." onClick="return confirm_check('Clear and re-initialise users table in database?')">Reload</button>
				<?php	} // if ?>
				<?= Ccms_export::get_table_form_text('cms_users') ?>
				<?php Ccms::get_return2search_link() ?>
				<span id="working_id">&nbsp;</span>
			</form>
			<script type="text/javascript">

				function confirm_check(txt) {
					if(confirm(txt)) {
						document.getElementById('working_id').innerHTML = '<?= Ccms_msgs::make_message_text('submiting input.', 'working') ?>';
						Ccms_cursor.setWait();
						cms_sleep(2000);	// allow img to load
						return true;
						} // if
					return false;
					} // confirm_check()

				function setConfigButtons() {
					var sel = document.getElementById('prim_id');
					if(!sel) return;
					if(sel.selectedIndex > 0) {
						document.getElementById('b_edit_id').disabled = false;
						document.getElementById('b_delete_id').disabled = false;
					} else {
						document.getElementById('b_edit_id').disabled = true;
						document.getElementById('b_delete_id').disabled = true;
					} // else
					} // setBodyConfigButtons()
				setConfigButtons();	// initial
			</script>
		</td>
	</tr>

	<?php
	if((($cms_user_op == 'edit') || ($cms_user_op == 'save') ||
		($cms_user_op == 'add') || ($cms_user_op == 'insert')) &&
		(isset($cms_user_id))) {
	?>
	<tr class="page_config">
		<th class="page_config">
			<?php if($cms_user_id == 0) {
				echo 'Add User' . ($cms_user_clone ? ' Clone':'');
				} // if
			else {
				echo 'Edit User' .
					'&nbsp;&nbsp;<span class="page_config">(Added:&nbsp;' . $cms_user_added .
					'&nbsp;&nbsp;Updated:&nbsp;' . $cms_user_updated . ')';
				if(isset($cms_user_login_count)) {
					echo '<br>' .
					(((int)$cms_user_login_count > 0) ?
					'Logged in locally ' . $cms_user_login_count . ' times.' .
					' Last login ' . $cms_user_last_login . '.' .
					' Last logoff ' . $cms_user_last_logoff .
					(($cms_user_last_login > $cms_user_last_logoff) ? ', still logged in.':'.'):'Never logged in locally.');
					} // if
				echo '</span>';
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_user_name))
					Ccms::get_return2search_link(true);
				$eula_time = Ccms_auth::get_eula_time();
				if($eula_time !== false) {
					echo '&nbsp;&nbsp;<span class="page_config">(EULA agreed:&nbsp;' . date('d/m/Y H:i:s',$eula_time) . ')</span>';
					} // if

			} // else
			$row = 0;
			?>

		</th>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<form name="edit_user" action="index.php" method="post" enctype="multipart/form-data">
			<input type="hidden" name="cms_action" value="cms_edit_users">
			<input type="hidden" name="cms_user_id" value="<?= $cms_user_id ?>"/>
			<input type="hidden" name="cms_user_added" value="<?= (isset($cms_user_added) ? htmlentities($cms_user_added):'') ?>"/>
			<input type="hidden" name="cms_user_updated" value="<?= (isset($cms_user_updated) ? htmlentities($cms_user_updated):'') ?>"/>
<?php if ($cms_user_clone) { ?>
			<input type="hidden" name="cms_user_clone" value="true"/>
			<input type="hidden" name="cms_user_clone_from_id" value="<?= $cms_user_clone_from_id ?>"/>
<?php	} // if ?>
			<div class="cms_sticky_left">
				<?php if($cms_user_id == 0) { ?>
				<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Insert</button>
				<?php } else { ?>
				<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
				&nbsp;&nbsp;
				<button name="clone" value="clone" type="submit">Clone</button>
				<?php	} // else ?>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
				&nbsp;&nbsp;
				<?php
					$blk_ary = array(	// use multi level params
						'text' => Ccms_auth::get_auth_descriptions(),	// usually 'text_inner'
						'outer_class' => 'cms_hover_block_outer',	// 'admin_pdb_container'),
						'inner_class' => 'cms_hover_block_inner',
						'outer_params' => 'style="font-size: 1.2em;"',
						'inner_params' => 'style="width: 320px; left: 0px;"',
						'table_class' => 'page_config',
						);
					echo Ccms_drop_box::hover_block('Authenications',$blk_ary);
				?>
			</div>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config">
			<table class="page_config page_config_edit">
<?php if($cms_user_clone) { ?>
				<tr class="page_config">
					<th class="page_config">Cloning User:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Make changes to the cloned user of "' . $cms_user_name . '" to ensure uniqueness.','info') ?>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">User Name:</th>
					<td class="page_config" style="min-width: 320px;">
						<input type="text" name="cms_user_name" value="<?= $cms_user_name ?>"  autocorrect="off" autocapitalize="off" REQUIRED/>
					</td>
					<td class="page_config">
						Enter a unique user name (required). Minimum of <?= LM_C_MIN_NAME_LEN ?> characters. Can be a username or email address.
						<br>
						If using LDAP / AD login, the username needs to be the same as used on LDAP / AD login.
					</td>
				</tr>

				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Email Address:</th>
					<td class="page_config">
						<input type="text" name="cms_user_email" value="<?= $cms_user_email;?>"<?= (CMS_C_USER_EMAIL_REQUIRED ? ' REQUIRED':'') ?>/>
						<input type="checkbox" name="cms_user_email_confirmed" 
							title="Check if email address has been confirmed."
							onclick="return confirm('Are you sure you want change confirmation?');" 
							<?= ($cms_user_email_confirmed ? 'CHECKED':'') ?>/>
					</td>
					<td class="page_config">
						Enter a unique user email address<?= (!CMS_C_USER_EMAIL_REQUIRED ? ' (optional)':' (required)') ?>.
						<?= ((CMS_C_USER_EMAIL_REQUIRED && CMS_C_CONFIRM_EMAIL) ? 'Email confirmation is required' . ($cms_user_email_confirmed ? '':' at next login') . '.':'') ?>
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Mobile Number:</th>
					<td class="page_config">
						<input type="text" name="cms_user_mobile" value="<?= $cms_user_mobile;?>"<?= (CMS_C_USER_MOBILE_REQUIRED ? ' REQUIRED':'') ?>/>
						<input type="checkbox" name="cms_user_mobile_confirmed" 
							title="Check if mobile phone number has been confirmed."
							onclick="return confirm('Are you sure you want change confirmation?');" 
							<?= ($cms_user_mobile_confirmed ? 'CHECKED':'') ?>/>
					</td>
				<td class="page_config">
						Enter a unique user mobile or telephone number<?= (!CMS_C_USER_MOBILE_REQUIRED ? ' (optional)':' (Required)') ?>.
						<?= ((CMS_C_USER_MOBILE_REQUIRED && CMS_C_CONFIRM_MOBILE) ? 'Mobile confirmation is required' . ($cms_user_mobile_confirmed ? '':' at next login') . '.':'') ?>
				</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<?php echo Ccms_html::get_textarea_input('cms_user_comments',$cms_user_comments,false,' rows="2" autocapitalize="off"'); ?>>
					</td>
					<td class="page_config">
						<?= Ccms::getAdminCommentHint('edit_users',$cms_user_name) ?>
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Password:</th>
					<td class="page_config">
						<?php Ccms::set_JS_password_input('cms_user_password','','',true) ?>
					</td>
					<td class="page_config">
						<?= (($cms_user_id == 0) ? 'Enter password,':'Leave blank to leave password unchanged,') ?>
						<br>
						(Not used if LDAP/AD authentication used, but can be used as a backup.)'
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Confirm:</th>
					<td class="page_config">
						<?php Ccms::set_JS_password_input('cms_user_confirm','','',true) ?>
					</td>
					<td class="page_config">
						Confirm password.
						<br>
						(Not used if LDAP/AD authentication used.)
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th style="width: 150px;" class="page_config">Select group/s:</th>
					<td class="page_config">
						<?=  Ccms::gen_group_selection_list('cms_user_group_ids[]',$cms_user_group_ids,10, ' multiple') ?>
					</td>
					<td class="page_config">
						Select users that are in this group.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Administrator:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_user_admin"<?= ($cms_user_admin == true ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check for <?= CMS_PROJECT_SHORTNAME ?> administrator access.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Enabled:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_user_enabled"<?= (($cms_user_enabled == true) || ($cms_user_op == 'add') ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Enable user in <?= CMS_PROJECT_SHORTNAME ?> (Application login can still be used).
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Use LDAP/AD Auth:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_user_auth_ldap"<?= ($cms_user_auth_ldap == true ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to use LDAP or AD authentication.
						(<?= (Ccms_auth::is_ldap_ok() ? 'LDAP/AD avvailable from &quot;' . CMS_S_LDAP_SERVER_URI . '&quot;':'No LDAP/AD server configured.');?>)
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Use PAM Auth:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_user_auth_pam"<?= ($cms_user_auth_pam == true ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to use PAM authentication (<?= (Ccms_auth::is_pam_ok() ? 'System PAM available':'Not available') ?>).
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">API Access:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_user_api"<?= ($cms_user_api == true ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to user API access.
					</td>
				</tr>
<?php if(Ccms_auth::is_eula_enabled()) { ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Reset EULA Time:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_user_eula_time_reset"/>
					</td>
					<td class="page_config">
						Check to reset user EULA agree time so that next they login the EULA will be presented.
					</td>
				</tr>
<?php	} // if ?>
			</table>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: right">
			<?php if($cms_user_id == 0) { ?>
			<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Insert</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</form>
		</td>
	</tr>
	<?php } else if(($cms_user_op == 'delete') && (isset($cms_user_id)) && ($cms_user_id > 0)) { ?>
	<tr class="page_config"><th class="page_config">Delete <?= ($cms_user_admin ? 'Administrator':'User') ?> - <?= $cms_user_name ?></th></tr>
	<tr class="page_config">
		<td class="page_config">
			<form name="delete_user" action="index.php" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_users">
				<input type="hidden" name="cms_user_id" value="<?= $cms_user_id ?>"/>
				<input type="hidden" name="cms_user_name" value="<?= htmlentities($cms_user_name) ?>"/>
				Please confirm.
				&nbsp;&nbsp;
				<button name="confirm_delete" value="confirm_delete" type="submit" onclick="Ccms_cursor.setWait();">Confirm Delete</button>
				&nbsp;&nbsp;
				for <b><?= $cms_user_name ?></b>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</form>
		</td>
	</tr>
	<?php }  ?>
	<tr class="page_config">
		<td class="page_config">
			<h3 class="page_config">Summary</h3>
			&nbsp;
			<form name="link_section_edit_filter" action="index.php" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_users"/>
				<input type="hidden" name="lm_link_qk_op" value="edit_user_qk_filter"/>
				<label style="text-decoration: none; font-weight: normal;">
					<input type="text" name="edit_user_qk_filter"
						value="<?= $edit_user_qk_filter ?>"
						oninput="chk_user_filter(event,this);"
						title="Enter filter keywords to find users separated by spaces."
						/>
					<input type="checkbox" name="edit_user_qk_enabled"
						onclick="chk_user_filter(event,this);"
						title="Check to filter only enabled users."
						<?= ($edit_user_qk_enabled ? ' CHECKED':'') ?>/>
					<input type="checkbox" name="edit_user_qk_admin"
						onclick="chk_user_filter(event,this);"
						title="Check to filter only admin users."
						<?= ($edit_user_qk_admin ? ' CHECKED':'') ?>/>
					<input type="radio" name="edit_user_qk_auth" value="any"
						onclick="chk_user_filter(event,this);"
						title="Check to not filter login auth type."
						<?= ($edit_user_qk_auth == 'any' || empty($edit_user_qk_auth) ? ' CHECKED':'') ?>/>
					<input type="radio" name="edit_user_qk_auth" value="local"
						onclick="chk_user_filter(event,this);"
						title="Check to filter only local login."
						<?= ($edit_user_qk_auth == 'local' ? ' CHECKED':'') ?>/>
					<input type="radio" name="edit_user_qk_auth" value="ldap"
						onclick="chk_user_filter(event,this);"
						title="Check to filter only ldap login."
						<?= ($edit_user_qk_auth == 'ldap' ? ' CHECKED':'') ?>/>
					user filters.
				</label>
			</form>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<table class="page_config">
				<tr class="page_config page_config_sticky">
					<th style="width: 120px;" class="page_config">User Name</th>
					<th style="width: 120px;" class="page_config">Comments</th>
					<th style="width: 120px;" class="page_config">Email</th>
					<th style="width: 70px;" class="page_config">Mobile</th>
					<th style="width: 70px;" class="page_config">Enabled</th>
					<th style="width: 70px;" class="page_config" title="Global web site administrator.">Admin</th>
					<th style="width: 70px;" class="page_config" title="API access.">API</th>
					<th style="width: 70px;" class="page_config" title="Local; authenticates to local user DB, LDAP; authenticates to a remote LDAP/AD server.<?= (!Ccms_auth::is_ldap_ok() ? '\nNOTE: No LDAP/AD server configured.':'');?>">Auth</th>
					<th class="page_config">Groups</th>
				</tr>
	<?php
		$where_filter = '';
		if(!empty($edit_user_qk_filter)) {
			$bowes = 0;
			$where_filter .= PHP_EOL . 'WHERE ( ';
			$filters = preg_split('/[\s,;:\/\'\"]+/',$edit_user_qk_filter);
			foreach($filters as $bow) {
				if($bowes > 0) $where_filter .= ' AND ';
					$where_filter .= '(cms_user_name LIKE \'%' . $bow . '%\'' .
						' OR cms_user_mobile LIKE \'%' . $bow . '%\'' .
						' OR cms_user_email LIKE \'%' . $bow . '%\' ) ' . PHP_EOL;
				$bowes++;
				} // foreach
			$where_filter .= ' ) ' . PHP_EOL;
			} // if
		if($edit_user_qk_enabled) {
			if(empty($where_filter)) $where_filter = ' WHERE ';
			else $where_filter .= ' AND ';
			$where_filter .= ' cms_user_enabled > 0 ';
			}
		if($edit_user_qk_admin) {
			if(empty($where_filter)) $where_filter = ' WHERE ';
			else $where_filter .= ' AND ';
			$where_filter .= ' cms_user_admin > 0 ';
			}
		if($edit_user_qk_auth) {
			switch($edit_user_qk_auth) {
			case 'local':
				$where_sub_filter = ' cms_user_auth_ldap = 0 ';
				break;
			case 'pam':
				$where_sub_filter = ' cms_user_auth_pam > 0 ';
				break;
			case 'ldap':
				$where_sub_filter = ' cms_user_auth_ldap > 0 ';
				break;
			default:
				$where_sub_filter = false;
				break;
				} // switch
			if(!empty($where_sub_filter)) {
				if(empty($where_filter)) $where_filter = ' WHERE ';
				else $where_filter .= ' AND ';
				$where_filter .= $where_sub_filter;
				} // if
			}
		$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_group_ids,cms_user_enabled" .
			",cms_user_admin,cms_user_auth_ldap,cms_user_auth_pam,cms_user_api" .
			",cms_user_email,cms_user_email_confirmed,cms_user_mobile,cms_user_mobile_confirmed,cms_user_comments" .
			PHP_EOL . " FROM  cms_users" .
			$where_filter .
			PHP_EOL . " ORDER BY  cms_user_name,cms_user_id";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$row = 0;
			while($user = Ccms::$cDBcms->fetch_array($result)) {
				$user = array_merge($user, Ccms_auth::get_user_json_data_ary($user['cms_user_name']));
				$user_title = ' title="' .
					(((int)$user['cms_user_login_count'] > 0) ?
					'Logged in locally ' . $user['cms_user_login_count'] . ' times.' .
					' Last login ' . $user['cms_user_last_login'] . '.' .
					' Last logoff ' . $user['cms_user_last_logoff'] .
					(($user['cms_user_last_login'] > $user['cms_user_last_logoff']) ? ', still logged in.':'.'):'Never logged in locally.') . '"';
				echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">';
				echo '<td class="page_config"' . $user_title . '>';
				if(Ccms::is_debug()) echo 'ID: ' . $user['cms_user_id'] . ', ';
				echo '<a href="index.php?cms_action=cms_edit_users&user_edit_id=' . $user['cms_user_id'] . '">' . $user['cms_user_name'] . '</a>';
				echo '</td>';
				echo '<td class="page_config">' . $user['cms_user_comments'] . '</td>';
				echo '<td class="page_config"><span style="white-space: nowrap;">' . $user['cms_user_email'] . '</span>  '. ($user['cms_user_email'] ? ($user['cms_user_email_confirmed'] ? 'Confirmed':'Unconfirmed'):'') . '</td>';
				echo '<td class="page_config"><span style="white-space: nowrap;">' . $user['cms_user_mobile'] . '</span> '. ($user['cms_user_mobile'] ? ($user['cms_user_mobile_confirmed'] ? 'Confirmed':'Unconfirmed'):'') . '</td>';
				echo '<td class="page_config">' . ($user['cms_user_enabled'] ? 'yes':'no') . '</td>';
				echo '<td class="page_config">' . ($user['cms_user_admin'] ? 'yes':'no') . '</td>';
				echo '<td class="page_config">' . ($user['cms_user_api'] ? 'yes':'no') . '</td>';
				echo '<td class="page_config">' . ($user['cms_user_auth_ldap'] ? 'ldap':'local') . ($user['cms_user_auth_pam'] ? ',PAM':'') . '</td>';
				echo '<td class="page_config">' . Ccms::get_group_ids_text($user['cms_user_group_ids'],false) . '</td>';
				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			Ccms::$cDBcms->free_result($result);
			} // if
		else echo '<tr class="page_config"><td class="page_config" style="text-align: left"><span class="cms_msg_warning">(No users setup)</span></td></tr>' . PHP_EOL;
		?>
			</table>
		</td>
	</tr>
</table>

<script type="text/javascript">
	var last_edit_user_qk_filter_call = null;
	function chk_user_filter(event,obj) {
		if(event.keyCode == 13) {
			obj.form.submit();
			return true;
			} // if
		if((event.type == 'click') &&
			(obj.type == 'checkbox')) {
			obj.form.submit();
			return true;
			} // if
		// don't submit on every char event, wait
		if(last_edit_user_qk_filter_call != null) {	// clear it
			window.clearTimeout(last_edit_user_qk_filter_call);
			last_edit_user_qk_filter_call = null;
			} // if
		// restart if
		last_edit_user_qk_filter_call = window.setTimeout(
			function (event,obj) {
				var keywords = obj.value;
				if((keywords.length > 3) ||
					(keywords.length == 0)) {
					obj.form.submit();
					return true;
					} // if
				return false;
				},
			750, event, obj);
		} // chk_user_filter()

</script>

<?php
Ccms::page_end_comment(__FILE__);
