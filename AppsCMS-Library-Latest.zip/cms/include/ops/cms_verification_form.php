<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_verification_form.php 3115 2023-02-10 02:33:50Z robert0609 $
 */

if(!$user = Ccms_auth::is_verification_codes_required()) {
	Ccms_auth::do_eula();	// if required should not return
	$url = Ccms_base::get_base_url(true);
	header('Location: ' . $url);
	exit (0);
	} // if

$send_code = true;
$show_form = true;

if((Ccms_base::get_or_post('op') == 'code_verification') &&
	($user_id = Ccms_base::get_or_post('user_id')) &&
	($user_id == $user['id'])) {		// check it
	$type = Ccms_base::get_or_post('verif_codes');
	$send_code = false;
	if($type == 'resend') $send_code = true;
	if($type == 'verify') {
		$ok = true;	// assume it will be ok
		$feilds = [];
		if((CMS_C_CONFIRM_EMAIL) && (Ccms_auth::is_email_verification_codes_enabled()) &&
			(empty($user['email_confirmed'])) && (!empty($user['email']))) {
			$email_code = Ccms_base::get_or_post('email_code');
			$email = Ccms_base::get_or_post('email');
			if(($user['email'] != $email) ||
				(!Ccms_auth::chk_auth_verification_code($email_code, $email, false))) {
				$ok = false;
				Ccms_base::addMsg('Email verification code not found, try again.','info');
				} // if
			else {
				$fields['cms_user_email_confirmed'] = 1;
				$user['email_confirmed'] = 1;
				} // else
			} // if
		if((CMS_C_CONFIRM_MOBILE) && (Ccms_auth::is_mobile_verification_codes_enabled()) &&
			(empty($user['mobile_confirmed'])) && (!empty($user['mobile']))) {
			$mobile_code = Ccms_base::get_or_post('mobile_code');
			$mobile = Ccms_base::get_or_post('mobile');
			if(($user['mobile'] != $mobile) ||
				(!Ccms_auth::chk_auth_verification_code($mobile_code, false, $mobile))) {
				$ok = false;
				Ccms_base::addMsg('Mobile verification code not found, try again.','info');
				} // if
			else {
				$fields['cms_user_mobile_confirmed'] = 1;
				$user['mobile_confirmed'] = 1;
				} // else
			} // if
		if($ok) {	// update
			Ccms_base::set_cms_sess_var($user,'user');
			if(Ccms::$cDBcms->perform('cms_users',$fields,'update','cms_user_id = ' . $user_id)) {
				Ccms_base::addMsg('Verification codes confirmed.','success');
				} // if
			Ccms::reset_session_actions();	// stop circular redirects
			// do eula
			Ccms_auth::do_eula();	// if required should not return
			$url = Ccms_base::get_base_url(true) . Ccms::get_body_uri();
			Ccms_base::do_redirect_uri($url);	// should not return;
			$show_form = false;
			} // if
		} // if
	} // if

Ccms::page_start_comment(__FILE__);

?>

<style>
	div.verify {
		font-size: 14pt;
		text-align: center;
		margin: 25px auto;
		}
	div.verify table {
		border: 2px solid darkgrey;
		padding: 10px;
		width: unset;
		margin: auto;
		}
	div.verify h1 {
		font-size: 1.6em;
		font-weight: bold;
		text-decoration: underline;	
		}
	div.verify h2 {
		font-size: 1.2em;
		text-decoration: underline;	
		padding-top: 25px;
		}
	div.verify tr {
		
		}
	div.verify th {
		font-size: 1.1em;
		text-decoration: underline;	
		padding-top: 25px;
		}
	div.verify td {
		padding:	10px;
		}
	
</style>

<div class="verify" style="text-align: center;">
<?php if($show_form) { ?>
	<h1 class="verify">
		Please Provide Verification Codes to Continue.
	</h1>
	<form name="set_user_verification" action="index.php" method="post" autocomplete="off">
	<input type="hidden" name="cms_action" value="get_verification"/>
	<input type="hidden" name="user_id" value="<?= $user['id'] ?>"/>
	<input type="hidden" name="op" value="code_verification"/>

	<table class="verify">

<?php	if(((CMS_C_CONFIRM_EMAIL) && (Ccms_auth::is_email_verification_codes_enabled()) &&
			(!empty($user['email'])) && (empty($user['email_confirmed']))) &&
			(Ccms_auth::send_email_verification_code($user['email'],$user['name'],$send_code))) {
?>
		<tr class="verify">
			<th class="verify" colspan="2" style="text-align: center;">
				Verification code has been emailed to <?= $user['email'] ?>
			</th>
		</tr>
		<tr class="verify">
			<td class="verify" style="text-align: right;">
				<label class="verify">
					Enter email verification code:
				</label>
			</td>
			<td class="verify" style="text-align: left;">
				<input type="number" name="email_code" value="" required/>
				<input type="hidden" name="email" value="<?= $user['email'] ?>"/>
			</td>
		</tr>
<?php	} // if ?>
	
<?php	if(((CMS_C_CONFIRM_MOBILE) && (Ccms_auth::is_mobile_verification_codes_enabled()) &&
			(!empty($user['mobile'])) && (empty($user['mobile_confirmed']))) &&
			(Ccms_auth::send_sms_verification_code($user['mobile'],$user['name'],$send_code))) {
?>
			<tr class="verify">
				<th class="verify" colspan="2" style="text-align: center;">
					Verification SMS code has been sent to <?= $user['mobile'] ?>
				</th>
			</tr>
			<tr class="verify">
				<td class="verify" style="text-align: right;">
					<label class="verify">
						Enter mobile phone verification code:
					</label>
				</td>
				<td class="verify" style="text-align: left;">
					<input type="number" name="mobile_code" value="" required/>
					<input type="hidden" name="mobile" value="<?= $user['mobile'] ?>"/>
				</td>
			</tr>
<?php	} // if ?>

			<tr class="verify">
				<td class="verify" style="text-align: right;">
					<label class="verify">
						Verification codes:
					</label>
				</td>
				<td class="verify" style="text-align: left;">
					<button type="submit" name="verif_codes" value="verify"/>Save</button>
					<button type="submit" name="verif_codes" value="resend" formnovalidate/>Resend</button>
				</td>
			</tr>
		</table>
	</form>
<?php	} else {	?>
	
	<h1 class="verify">
		Verification Codes Done.
	</h1>
	<p class="verify" style="text-align: center;">
		<button type="button" name="verif_codes" value="continue"
			onclick="window.location.href = 'index.php'"/>Continue</button>
	</p>

<?php	} ?>

	<p class="verify" style="text-align: center;">
		<?= Ccms_base::getMsgs(); ?>
	</p>

</div>	

<?php
		
Ccms::page_end_comment(__FILE__);
