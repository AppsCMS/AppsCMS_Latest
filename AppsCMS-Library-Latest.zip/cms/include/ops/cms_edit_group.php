<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_edit_group.php 3102 2023-02-06 07:39:28Z robert0609 $
 */

$cms_group_id = 0;
$cms_group_op = '';
$cms_group_clone = false;
$cms_group_clone_from_id = Ccms::get_or_post("cms_group_clone_from_id");
$cms_group_clone_insert = ((Ccms::get_or_post("cms_group_clone") == 'true') ? true:false);

Ccms_export::export_table('cms_groups');
if(Ccms::get_cms_action() == 'cms_edit_groups') { // a bit of caution
	Ccms_content_cache::reset_caches(false);
	if((Ccms::is_get_or_post('delete')) &&
		((Ccms::is_get_or_post('group_edit_id')) || (Ccms::is_get_or_post('cms_group_id')))) {
		$cms_group_op = 'delete';
		$cms_group_id = (int)(Ccms::is_get_or_post('cms_group_id') ? Ccms::get_or_post('cms_group_id'):Ccms::get_or_post('group_edit_id'));

		$sql_query = "SELECT  cms_group_name,cms_group_enabled" .
					" FROM  cms_groups WHERE  cms_group_id = '" . (int)$cms_group_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($group = Ccms::$cDBcms->fetch_array($result))) {
			foreach($group as $k => &$v) $$k = $v;
			} // if
		} // else if
	else if((Ccms::is_get_or_post('confirm_delete')) && (Ccms::is_get_or_post('cms_group_id'))) {
		$cms_group_op = 'confirm_delete';
		$cms_group_id = (int)Ccms::get_or_post('cms_group_id');

		$sql_query = "DELETE FROM  cms_groups WHERE  cms_group_id = '" . (int)$cms_group_id . "'";
		Ccms::$cDBcms->query($sql_query);
		$cms_group_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('add')) {
		$cols = Ccms::$cDBcms->get_columns_list('cms_groups',true);
		foreach($cols as $c => $v) $$c = $v;

		$sql_query = "SELECT MAX(cms_group_order) AS max_cms_group_order FROM  cms_groups";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			($row = Ccms::$cDBcms->fetch_array($result))) {
			$cms_group_order = $row['max_cms_group_order'] + 100;	// next app
			} // if
		else Ccms::$cDBcms->free_result($result);

		$cms_group_op = 'add';
		$cms_group_id = 0;
		} // else if
	else if((Ccms::is_get_or_post('insert')) && (Ccms::is_get_or_post('cms_group_id'))) {
		$cms_group_op = 'insert';
		} // else if
	else if((Ccms::is_get_or_post('save')) && (Ccms::is_get_or_post('cms_group_id'))) {
		$cms_group_op = 'save';
		} // else if
	else if((Ccms::is_get_or_post('clone')) && (Ccms::is_get_or_post('cms_group_id'))) {
		$cms_group_op = 'clone';
		$cms_group_clone = true;
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('export'))) {
		$cms_group_op = 'export';
		$cms_group_id = 0;
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (Ccms::is_get_or_post('import'))) {
		$cms_group_op = 'import';
		$cms_group_id = 0;
		Ccms_export::import_table('cms_groups');
		} // else if
	else if((Ccms_auth::is_cms_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL) && (Ccms::is_get_or_post('reloadDB'))) {
		$cms_group_op = 'reloadDB';
		$cms_group_id = 0;
		} // else if
	else if(Ccms::is_get_or_post('cancel')) {
		$cms_group_op = 'cancel';
		$cms_group_id = 0;
		} // else if
	else if(($cms_group_id = (int)Ccms::get_or_post('group_edit_id')) > 0) {
		$cms_group_op = 'edit';

		$sql_query = "SELECT  cms_group_name,cms_group_enabled, cms_group_admin, cms_group_order" .
			", cms_group_user_ids, cms_group_admin_ids, cms_group_description,cms_group_order,cms_group_comments" .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_group_added','cms_group_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('cms_group_updated','cms_group_updated') .
			" FROM  cms_groups WHERE  cms_group_id = '" . (int)$cms_group_id . "'";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0) &&
			($group = Ccms::$cDBcms->fetch_array($result))) {
			foreach($group as $k => &$v) $$k = $v;
			Ccms::$cDBcms->free_result($result);
			} // if
		else { // not found
			$cms_group_id = 0;
			$cms_group_op = '';
			$cms_group_added = '';
			$cms_group_updated = '';
			} // else
		} // if

	if(($cms_group_op == 'insert') || ($cms_group_op == 'clone') || ($cms_group_op == 'save')) {

		$cms_group_id = (int)Ccms::get_or_post('cms_group_id');
		$cms_group_name = html_entity_decode(Ccms::get_or_post('cms_group_name'));
		$cms_group_admin = Ccms::get_or_post_checkbox('cms_group_admin');
		$cms_group_user_ids = (Ccms::is_get_or_post('cms_group_user_ids') ? implode(':',Ccms::get_or_post('cms_group_user_ids')):0);
		$cms_group_admin_ids = (Ccms::is_get_or_post('cms_group_admin_ids') ? implode(':',Ccms::get_or_post('cms_group_admin_ids')):0);
		$cms_group_description = html_entity_decode(Ccms::get_or_post('cms_group_description'));
		$cms_group_enabled = Ccms::get_or_post_checkbox('cms_group_enabled');
		$cms_group_order = (int)Ccms::get_or_post('cms_group_order');
		$cms_group_comments = Ccms::get_or_post('cms_group_comments');

		if($cms_group_op != 'clone') {
			Ccms_DB_checks::is_group_name_ok($cms_group_name,$cms_group_op, "cms_group_id != " . (int)$cms_group_id);

			if(!Ccms::getMsgsCount('error')) {	// update it
				$fields = array();
				$fields['cms_group_name'] = $cms_group_name;
				$fields['cms_group_description'] = $cms_group_description;
				$fields['cms_group_enabled'] = $cms_group_enabled;
				$fields['cms_group_admin'] = $cms_group_admin;
				$fields['cms_group_user_ids'] = $cms_group_user_ids;
				$fields['cms_group_admin_ids'] = $cms_group_admin_ids;
				$fields['cms_group_order'] = $cms_group_order;
				$fields['cms_group_comments'] = $cms_group_comments;

				if($cms_group_op == 'insert') {
					if(!Ccms::$cDBcms->perform('cms_groups',$fields,'insert','')) {
						Ccms::addMsg('Group insert, ' . $cms_group_name . " failed");
						} // if
					else {
						// Ccms_base::unset_cms_sess_var('cms_group_id');
						Ccms_export::export_table('cms_groups');
						Ccms::backupOnSave();
						Ccms::addMsg('New group data saved.','success');
						} // else
					} // if
				else if($cms_group_op = 'save') {
					if(!Ccms::$cDBcms->perform('cms_groups',$fields,'update',"cms_group_id = " . (int)$cms_group_id . "")) {
						Ccms::addMsg('Group update, ' . $cms_group_name . " failed");
						} // if
					else {
						// Ccms_base::unset_cms_sess_var('cms_group_id');
						Ccms_export::export_table('cms_groups');
						Ccms::backupOnSave();
						Ccms::addMsg('Saved group data.','success');
						} // else
					} // else
				$cms_group_id = 0;
				$cms_group_op = '';
				$cms_group_clone_insert = false;
				$cms_group_clone = false;
				} // if
			} // if
		if((($cms_group_op == 'clone') || ($cms_group_clone_insert)) &&
			(((int)$cms_group_clone_from_id > 0) || ((int)$cms_group_id > 0))) {
			$cms_group_clone_from_id = (((int)$cms_group_clone_from_id > 0) ? $cms_group_clone_from_id:$cms_group_id);
			$cms_group_clone = true;	// retry !!
			$cms_group_op = 'insert';
			$cms_group_id = 0;
			Ccms::addMsg('Cloning user "' . $cms_group_name . '".','info');
			} // if
		} // if
	} // if
$cnt = Ccms::$cDBcms->get_row_count_in_table('cms_groups');

$edit_group_qk_filter = Ccms::get_or_post_keyed_session_var('edit_group_qk_filter');
$edit_group_qk_enabled = Ccms::get_or_post_checkbox_keyed_session_var('edit_group_qk_enabled');
$edit_group_qk_admin = Ccms::get_or_post_checkbox_keyed_session_var('edit_group_qk_admin');

?>

<?php Ccms::page_start_comment(__FILE__) ?>

<?= Ccms::get_admin_scroll2pageTop() ?>
<table class="page_config">
	<tr class="page_config">
		<th class="page_config">
			<h1 class="page_config">Groups</h1>
		</th>
	</tr>
	<?php if($cms_group_op == 'reloadDB') { ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Reloading Groups Config
			<?php Ccms::$cDBcms->installDatabase('cms_groups',true ,true) ?>
		</td>
	</tr>
	<?php } // if ?>
	<form name="edit_group" action="index.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="cms_action" value="cms_edit_groups">
	<?= Ccms_search::get_form_search_hidden_inputs() ?>
	<tr class="page_config">
		<td class="page_config" valign="bottom">
			Select group name:&nbsp;
			<?=  Ccms::gen_group_selection_list('group_edit_id',$cms_group_id,1) ?>
			<?php if($cnt > 0) { ?>
			&nbsp;&nbsp;
<!--			<button name="edit" value="edit" type="submit" onclick="Ccms_cursor.setWait();">Edit</button>
			&nbsp;&nbsp;-->
			<button name="delete" value="delete" type="submit" onclick="Ccms_cursor.setWait();">Delete</button>
			<?php	} //if ?>
			&nbsp;&nbsp;
			<button name="add" value="add" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			<?php if((Ccms_auth::is_cms_admin_user()) && (CMS_S_ALLOW_TABLE_RELOAD_BOOL)) { ?>
			&nbsp;&nbsp;
			<button name="reloadDB" value="reloadDB" type="submit" onclick="Ccms_cursor.setWait();" title="Clear and re-initialise groups table in database." onClick="return confirm_check('Clear and re-initialise groups table in database?')">Reload</button>
			<?php	} // if ?>
			<?= Ccms_export::get_table_form_text('cms_groups') ?>
			<?php Ccms::get_return2search_link() ?>
			<span id="working_id">&nbsp;</span>
			<script type="text/javascript">

				function confirm_check(txt) {
					if(confirm(txt)) {
						document.getElementById('working_id').innerHTML = '<?= Ccms_msgs::make_message_text('submiting input.', 'working') ?>';
						cms_sleep(2000);	// allow img to load
						return true;
						} // if
					return false;
					} // confirm_check()

			</script>
		</td>
	</tr>

	<?php
	if((($cms_group_op == 'edit') || ($cms_group_op == 'save') ||
		($cms_group_op == 'add') || ($cms_group_op == 'insert')) &&
		(isset($cms_group_id))) {
		$row = 0;
	?>
	<tr class="page_config">
		<th class="page_config">
			<?php if($cms_group_id == 0) {
				echo 'Add Group';
				} // if
			else {
				echo 'Edit Group' .
					'&nbsp;&nbsp;<span class="page_config">(Added:&nbsp;' . $cms_group_added .
					'&nbsp;&nbsp;Updated:&nbsp;' . $cms_group_updated . ')</span>';
				if((Ccms::is_get_or_post('name')) && (Ccms::get_or_post('name') == $cms_group_name))
					Ccms::get_return2search_link(true);
				} // else
			?>
		</th>
	</tr>
	<input type="hidden" name="cms_group_id" value="<?= $cms_group_id ?>"/>
	<input type="hidden" name="cms_group_name_old" value="<?= htmlentities($cms_group_name) ?>"/>
<?php if ($cms_group_clone) { ?>
	<input type="hidden" name="cms_group_clone" value="true"/>
	<input type="hidden" name="cms_group_clone_from_id" value="<?= $cms_group_clone_from_id ?>"/>
<?php	} // if ?>

	<tr class="page_config page_config_sticky">
		<td class="page_config">
			<div class="cms_sticky_left">
				<?php if($cms_group_id == 0) { ?>
				<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
				<?php } else { ?>
				<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
				&nbsp;&nbsp;
				<button name="clone" value="clone" type="submit">Clone</button>
				<?php	} // else ?>
				&nbsp;&nbsp;
				<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
			</div>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config">
			<table class="page_config page_config_edit">
<?php if($cms_group_clone) { ?>
				<tr class="page_config">
					<th class="page_config">Cloning Group:</th>
					<td class="page_config" colspan="2">
						<?= Ccms::make_message_text('Make changes to the cloned group of "' . $cms_group_name . '" to ensure uniqueness.','info') ?>
					</td>
				</tr>
<?php	} // if ?>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th width ="150px" class="page_config">Group Name:</th>
					<td class="page_config" style="min-width: 320px;">
						<input type="text" name="cms_group_name" value="<?= $cms_group_name ?>" autocapitalize="off" REQUIRED/>
					</td>
					<td class="page_config">
						Group name. Minimum of <?= LM_C_MIN_NAME_LEN ?> characters
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Description:</th>
					<td class="page_config">
						<?php echo Ccms_html::get_textarea_input('cms_group_description',$cms_group_description,false,' autocapitalize="off" REQUIRED'); ?>>
					</td>
					<td class="page_config">
						 Group description (for admin notes, not displayed to user)
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Comments:</th>
					<td class="page_config">
						<?php echo Ccms_html::get_textarea_input('cms_group_comments',$cms_group_comments,false,' autocapitalize="off"'); ?>>
					</td>
					<td class="page_config">
						<?= Ccms::getAdminCommentHint('edit_group',$cms_group_name) ?>
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Order:</th>
					<td class="page_config">
						<input type="number" name="cms_group_order" size="4" value="<?= $cms_group_order ?>" autocapitalize="off" REQUIRED/>
					</td>
					<td class="page_config">
						 Group display and priority order (lowest numbers first).
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Admin:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_group_admin"<?= ($cms_group_admin == true ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						 Check to make all members of this group administrators.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Select user/s:</th>
					<td class="page_config">
						<?=  Ccms::gen_group_user_selection_list('cms_group_user_ids[]',$cms_group_user_ids,10, ' multiple') ?>
					</td>
					<td class="page_config">
						Select users that are users in this group.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Select Manager/s:</th>
					<td class="page_config">
						<?=  Ccms::manager_selection_list('cms_group_admin_ids[]',$cms_group_admin_ids,10, ' multiple') ?>
					</td>
					<td class="page_config">
						Select users that are managers in this group.
					</td>
				</tr>
				<tr class="<?= (($row++ & 1) ? 'page_config_odd':'page_config_even') ?>">
					<th class="page_config">Enabled:</th>
					<td class="page_config">
						<input type="checkbox" name="cms_group_enabled"<?= (($cms_group_enabled == true) || ($cms_group_op == 'add') ? ' CHECKED':'');?>/>
					</td>
					<td class="page_config">
						Check to enable this group.
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr class="page_config">
		<td class="page_config" style="text-align: right">
			<?php if($cms_group_id == 0) { ?>
			<button name="insert" value="insert" type="submit" onclick="Ccms_cursor.setWait();">Add</button>
			<?php } else { ?>
			<button name="save" value="save" type="submit" onclick="Ccms_cursor.setWait();">Save</button>
			&nbsp;&nbsp;
			<button name="clone" value="clone" type="submit">Clone</button>
			<?php	} // else ?>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>

	<?php } else if(($cms_group_op == 'delete') && (isset($cms_group_id)) && ($cms_group_id > 0)) { ?>
	<tr class="page_config"><th class="page_config">Delete Group - <?= $cms_group_name ?></th></tr>
	<input type="hidden" name="cms_group_id" value="<?= $cms_group_id ?>"/>
	<input type="hidden" name="cms_group_name" value="<?= htmlentities($cms_group_name) ?>"/>
	<tr class="page_config">
		<td class="page_config">
			Please confirm.
			&nbsp;&nbsp;
			<button name="confirm_delete" value="confirm_delete" type="submit" onclick="Ccms_cursor.setWait();">Confirm Delete</button>
			&nbsp;&nbsp;
			<button name="cancel" value="cancel" type="submit" onclick="Ccms_cursor.setWait();" formnovalidate>Cancel</button>
		</td>
	</tr>
	<?php	}  ?>
	</form>
	<tr class="page_config">
		<td class="page_config">
			<h3 class="page_config">Summary</h3>
			&nbsp;
			<form name="link_section_edit_filter" action="index.php" method="get">
				<input type="hidden" name="cms_action" value="cms_edit_groups"/>
				<input type="hidden" name="lm_link_qk_op" value="edit_group_qk_filter"/>
				<label style="text-decoration: none; font-weight: normal;">
					<input type="text" name="edit_group_qk_filter"
						value="<?= $edit_group_qk_filter ?>"
						oninput="chk_link_section_filter(event,this);"
						title="Enter filter keywords to find groups separated by spaces."
						/>
					<input type="checkbox" name="edit_group_qk_enabled"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only enabled groups."
						<?= ($edit_group_qk_enabled ? ' CHECKED':'') ?>/>
					<input type="checkbox" name="edit_group_qk_admin"
						onclick="chk_link_section_filter(event,this);"
						title="Check to filter only admin users."
						<?= ($edit_group_qk_admin ? ' CHECKED':'') ?>/>
					group filters.
				</label>
			</form>
		</td>
	</tr>
	<tr class="page_config">
		<td class="page_config" style="text-align: left">
			<table class="page_config">
				<tr class="page_config page_config_sticky">
					<th width ="150px" class="page_config">Group</th>
					<th width ="150px" class="page_config">Comments</th>
					<th width ="70px" class="page_config">Order</th>
					<th width ="70px" class="page_config">Enabled</th>
					<th width ="70px" class="page_config" title="Global web site administrator group.">Admin</th>
					<th width ="150px" class="page_config" title="Group Users">User/s</th>
					<th width ="150px" class="page_config" title="Group Managers">Manager/s</th>
					<th class="page_config">Description</th>
				</tr>
	<?php
		$where_filter = '';
		if(!empty($edit_group_qk_filter)) {
			$bowes = 0;
			$where_filter .= PHP_EOL . 'WHERE ( ';
			$filters = preg_split('/[\s,;:\/\'\"]+/',$edit_group_qk_filter);
			foreach($filters as $bow) {
				if($bowes > 0) $where_filter .= ' AND ';
					$where_filter .= '(cms_group_name LIKE \'%' . $bow . '%\'' .
						' OR cms_group_description LIKE \'%' . $bow . '%\' ) ' . PHP_EOL;
				$bowes++;
				} // foreach
			$where_filter .= ' ) ' . PHP_EOL;
			} // if
		if($edit_group_qk_enabled) {
			if(empty($where_filter)) $where_filter = ' WHERE ';
			else $where_filter .= ' AND ';
			$where_filter .= ' cms_group_enabled > 0 ';
			}
		if($edit_group_qk_admin) {
			if(empty($where_filter)) $where_filter = ' WHERE ';
			else $where_filter .= ' AND ';
			$where_filter .= ' cms_group_admin > 0 ';
			}
		$sql_query = "SELECT  cms_group_id,cms_group_name,cms_group_description,cms_group_enabled,cms_group_order,cms_group_admin,cms_group_user_ids,cms_group_admin_ids,cms_group_comments" .
			PHP_EOL . " FROM  cms_groups" .
			$where_filter .
			PHP_EOL . " ORDER BY  cms_group_order,cms_group_id";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$row = 0;
			while($group = Ccms::$cDBcms->fetch_array($result)) {
				echo '<tr class="' . (($row & 1) ? 'page_config_odd':'page_config_even') . '">';
				echo '<td class="page_config">';
				if(Ccms::is_debug()) echo 'ID: ' . $group['cms_group_id'] . ', ';
				echo '<a href="index.php?cms_action=cms_edit_groups&group_edit_id=' . $group['cms_group_id'] . '">' . $group['cms_group_name'] . '</a></td>';
				echo '<td class="page_config">' . $group['cms_group_comments'] . '</td>';
				echo '<td class="page_config">' . $group['cms_group_order'] . '</td>';
				echo '<td class="page_config">' . ($group['cms_group_enabled'] ? 'yes':'no') . '</td>';
				echo '<td class="page_config">' . ($group['cms_group_admin'] ? 'yes':'no') . '</td>';
				echo '<td class="page_config">' . Ccms::get_group_user_ids_text($group['cms_group_user_ids'],false) . '</td>';
				echo '<td class="page_config">' . Ccms::get_group_manager_ids_text($group['cms_group_admin_ids'],false) . '</td>';
				echo '<td class="page_config">' . $group['cms_group_description'] . '</td>';
				echo '</tr>' . PHP_EOL;
				$row++;
				} // while
			} // if
		else echo '<tr class="page_config"><td class="page_config" style="text-align: left"><span class="cms_msg_warning">(No groups setup)</span></td></tr>' . PHP_EOL;
		?>
			</table>
		</td>
	</tr>
</table>

<script type="text/javascript">
	var last_edit_group_qk_filter_call = null;
	function chk_link_section_filter(event,obj) {
		if(event.keyCode == 13) {
			obj.form.submit();
			return true;
			} // if
		if((event.type == 'click') &&
			(obj.type == 'checkbox')) {
			obj.form.submit();
			return true;
			} // if
		// don't submit on every char event, wait
		if(last_edit_group_qk_filter_call != null) {	// clear it
			window.clearTimeout(last_edit_group_qk_filter_call);
			last_edit_group_qk_filter_call = null;
			} // if
		// restart if
		last_edit_group_qk_filter_call = window.setTimeout(
			function (event,obj) {
				var keywords = obj.value;
				if((keywords.length > 3) ||
					(keywords.length == 0)) {
					obj.form.submit();
					return true;
					} // if
				return false;
				},
			750, event, obj);
		} // chk_link_section_filter()

</script>

<?php Ccms::page_end_comment(__FILE__) ?>
