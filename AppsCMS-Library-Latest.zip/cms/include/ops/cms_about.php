<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_about.php 3254 2023-03-03 07:17:12Z robert0609 $
 */

Ccms::page_start_comment(__FILE__);

echo Ccms::get_admin_scroll2pageTop();
?>
<table class="page_body" style="color: black; background-color: white;">
	<caption>About <?= strip_tags(CMS_PROJECT_SHORTNAME) ?> page</caption>
	<tr class="page_body">
		<th class="page_body">
			<img height="150px" src="<?= CMS_IMAGE_LOGO ?>" alt="<?= CMS_PROJECT_SHORTNAME ?> Logo">
			<h1 class="page_config" style="white-space: normal;">About</h1>
			<br>
			<h2 class="page_config" style="white-space: normal;"><?php Ccms::prn_AppsCMS_title() ?></h2>
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				The <?= CMS_PROJECT_SHORTNAME ?> came from the need to have an easy to install, use and maintain web application management system for workshops, store rooms and laboratories.
				The <?= CMS_PROJECT_SHORTNAME ?> can operate on an isolated intranet network, making it ideal for internal private web sites.
				As well as for public access web sites.
			</p>
			<p class="page_body">
				The <?= CMS_PROJECT_SHORTNAME ?> is a PHP developers web multiple Applications Management System Library.
				Not wanting to wrangle with abstract concepts (both software and design) in mainstream
				content management systems and deal of problematic installations,
				I wrote the <?= CMS_PROJECT_SHORTNAME ?> for this role.
			</p>
			<p class="page_body">
				The installation comes as a self installing bash script (2,2MB) for LINUX and a ZIP (1.6M) file for general installations.
				Available on the &quot;https://github.com/AppsCMS/AppsCMS_Latest/&quot; repository and
				on &quot;https://<?= CMS_PROJECT_DOMAIN ?>/dist-pkgs/&quot; web sites.
			</p>
			<p class="page_body">
				Access to web pages is controlled by user and group permissions.
				Individual users or groups can have administration privileges, to a page or to the whole web site.
				Users with privileges are required to have a username and password.
				Access by public (guest) users is controlled by permissions.
			</p>
			<p class="page_body">
				<?= CMS_PROJECT_SHORTNAME ?> provides settings and configuration pages to write, edit and maintain the contents.
			</p>
			<p class="page_body">
				A further consideration is to have a common method to link to locally installed tools
				(e.g. WebSVN, Database tools, Regex testers, etc).
			</p>
			<p class="page_body">
				<?= CMS_PROJECT_SHORTNAME ?> also provides a methods for displaying only the necessary content for each user or group.
				A user can log into <?= CMS_PROJECT_SHORTNAME ?>.
				Each user can be a member of a number of groups
				and so allows content set for group/s to display the appropriate pages.
				A user also be an administrator or a group manager.
			</p>
			<p class="page_body">
				The <?= CMS_PROJECT_SHORTNAME ?> has many built in aids including programming aids, log viewing, debugging, examples and setup searches.
				Making the <?= CMS_PROJECT_SHORTNAME ?> easy to learn and implement.
			</p>
			<p class="page_body">
				The <a href="index.php?cms_action=cms_manual">Users Manual</a> has more details on the <?= CMS_PROJECT_SHORTNAME ?>.
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			Licence
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				As <?= CMS_PROJECT_SHORTNAME ?> has been useful, <?= CMS_PROJECT_SHORTNAME ?> has been released
				under the <a href="https://opensource.org/licences/BSD-3-Clause">The 3-Clause BSD Licence</a>.
			</p>
			<p class="page_body">
<!--				Refer to <a href="<?= CMS_WS_DIR ?>LICENCE.txt">LICENCE.txt</a>.-->
				Refer to <?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'LICENCE.txt','LICENCE') ?>.
			</p>
			<p class="page_body">
				Refer to the <a href="index.php?cms_action=cms_manual#Licence">Technical Manual Licence</a> for more licence information.
			</p>
		</td>
	</tr>
	<tr class="page_body">
		<th class="page_body">
			<a name="MoreInfo"></a>
			User Manual, Release Information and Feedback
		</th>
	</tr>
	<tr class="page_body">
		<td class="page_body">
			<p class="page_body">
				<a href="index.php?cms_action=cms_manual">Technical Manual</a>.
			</p>
			<p class="page_body">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'README.md','README') ?>
			</p>
			<p class="page_body">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'ReleaseNotes.md','Release Notes') ?>
			</p>
			<p class="page_body">
				<?= Ccms_media_conv_plugin::get_file_href(CMS_WS_DIR . 'Installation.md','Installation Notes') ?>
			</p>
				<?php if(Ccms_contactus_plugin::is_enabled()) {
					$text = '';
					$open_js = Ccms_contactus_plugin::generate_modal(
						$text,	// text buffer
						false,	// no button
						'',	// form_id
						'_mt',	// suffix
						'page_body',	// class usually 'page_body'
						true,	// geo_flg if available
						false,	// msg_drop_box
						CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ' Feedback', // $subject
						'feedback@' . CMS_PROJECT_DOMAIN	// rec_email
						);
					echo $text;
				?>
				<br>
				<a onclick="<?= $open_js ?>();">Hints, corrections and suggestions are always welcome. Email Feedback</a>.
				<br>
				<?php	} else { ?>
			<p class="page_body">
				Hints, corrections and suggestions are always welcome.
				<a href="mailto:feedback@<?= CMS_PROJECT_DOMAIN ?>?Subject=<?= rawurlencode(CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION) ?>">Email Feedback</a>.
			</p>
				<?php	} // else ?>
		</td>
	</tr>
</table>

<?= Ccms::page_end_comment(__FILE__) ?>
