<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_lm_filter.php 2908 2022-10-22 23:26:26Z robert0609 $
 */


/**
 *
 *  * Description of lm_filter
 *	* static class to provide text filter in user data
 *
 * @author robert0609
 */
class Ccms_lm_filter extends Ccms_general {

	protected static $filter_keywords = false;
//	protected static $sect_sql_filter = '';
//	protected static $link_sql_filter = '';

	protected static $linkkeys = array('lm_link_name','lm_link_title','lm_link_description');	// ,'lm_link_url','lm_link_image_url','lm_link_icon_url'
	protected static $sectkeys = array('lm_section_name', 'lm_section_description', 'lm_section_title');	// ,'lm_section_image_url', 'lm_section_icon_url'

	protected static $layout_data = false;

	private static $sections_fnd = false;
	private static $links_fnd = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function help() {
		$text = "Enter text keywords, separated by spaces, to find and filter Sections, Links, Titles, Desciptions and Names.";
		$text .= '\n' . (LM_C_FILTER_ANDED ? 'Must have all keywords.':'Can have any keyword.');
		return $text;
		} // help()

	protected static function is_filtering($keywords = false) {
		if((Ccms::is_admin_action()) && ($keywords)) return true;
		if(!LM_C_FILTER_OUTPUT) return false;
		if(self::$filter_keywords) return true;
		if((Ccms::is_get_or_post('keywords')) &&
			($keywords = Ccms::get_or_post('keywords'))) {
			self::$filter_keywords = $keywords;
			return true;
			} // if
//		else if((Ccms::is_get_or_post('filter')) &&
//			($keywords = Ccms::get_or_post('filter'))) {
//			self::$filter_keywords = $keywords;
//			return true;
//			} // if
		return false;
		} // is_filtering()

	protected static function check_ored_keywords($data,$keys,$keywords) {
		$words = explode(' ',($keywords ? $keywords:self::$filter_keywords));
		$txt = '';
		foreach($keys as $k) {
			if(!isset($data[$k])) continue;
			$txt .= ' ' . $data[$k];	// make a long str
			} // foreach
		foreach($words as $w) {
			if(empty($w)) continue;
			if(stripos($txt,$w) === false) return true;
			} // foreach
		return false;
		} // check_ored_keywords()

	protected static function check_anded_keywords($data,$keys,$keywords) {
		$words = explode(' ',($keywords ? $keywords:self::$filter_keywords));
		$txt = '';
		foreach($keys as $k) {
			if(!isset($data[$k])) continue;
			$txt .= ' ' . $data[$k];	// make a long str
			} // foreach
		$found = true;
		foreach($words as $w) {
			if(empty($w)) continue;
			if(stripos($txt,$w) === false) {
				$found = false;
				break;
				} // if
			} // foreach
		return $found;
		} // check_anded_keywords()

	protected static function check_keywords($data,$keys,$keywords) {
		if(!self::is_filtering($keywords)) return true;	// allow every thing
		if(LM_C_FILTER_ANDED) return self::check_anded_keywords ($data, $keys,$keywords);
		return self::check_ored_keywords($data, $keys,$keywords);
		} // check_keywords()

	protected static function check_section_keywords($section,$keywords) {
		if((!$keywords) && (!LM_C_FILT_INC_SECT)) return false;
		$keys = self::$sectkeys;
		return self::check_keywords($section,$keys,$keywords);
		} // check_section_keywords();

	protected static function check_link_keywords($link,$keywords) {
		$keys = self::$linkkeys;
		return self::check_keywords($link,$keys,$keywords);
		} // check_link_keywords()

	private static function find_links_in_section_layout(&$layout_data, &$filt, $section_id, $lev,$section_found) {
		$sql_link_query = "SELECT *" .
			" FROM  lm_links" .
			" WHERE lm_link_section_id = " . $section_id . ($filt['link']['enabled'] ? ' AND lm_link_enabled > 0 ':'') .
			" ORDER BY lm_link_order,lm_link_name;";
		$found = 0;
		if($result_link = Ccms::$cDBcms->query_unbuffered($sql_link_query)) {
			while($link = Ccms::$cDBcms->fetch_array_unbuffered($result_link)) {
				Ccms_DB_checks::sanitize_DB_table('lm_links',$link);
				$sql_section_query = 'SELECT lm_section_id FROM lm_sections WHERE lm_section_id = ' . $link['lm_link_section_id'];
				if(!$result_sect = Ccms::$cDBcms->query_unbuffered($sql_section_query)) {
					// no section, an orphan
					continue;
					} //if
		
				if($section_found)	// link in section
					$layout_data['sections'][$section_id]['links'][($link['lm_link_id'])]['data'] = $link;	// put all links if section matches
				else {
					if(self::check_link_keywords($link,$filt['link']['keywords'])) {
						$layout_data['sections'][$section_id]['links'][($link['lm_link_id'])]['data'] = $link;	// put in if link matches
						$found++;
						self::$layout_data['link_cnt']++;
						} // if
					} // else
				self::$links_fnd[] = $link['lm_link_id'];
				} // while
			} // if
		return $found;
		} // find_links_in_section_layout()

	private static function is_section_parent_available(&$section) {
		if((int)$section['lm_section_parent_id'] == 0) return false;	// is the base parent
		$parent_id = Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_id','lm_section_parent_id = ' . (int)$section['lm_section_parent_id']);
		if(empty($parent_id)) {
			$section['lm_section_parent_id'] = 0;
			return false;
			} // if
		return true;
		} // is_section_parent_available()

	private static function find_sections_links_layout_recurs(&$layout_data,&$filt,$inc_links, $section_id = false,$lev = 0) {
		$section_found = false;
		// if(empty($section_id)) $section_id = 0;
		$sql_section_query = "SELECT *" .
			" FROM  lm_sections" .
			" WHERE " . (empty($section_id) ? "(lm_section_parent_id = 0 OR lm_section_id = lm_section_parent_id OR lm_section_parent_id = 'null' OR lm_section_parent_id = '')":'lm_section_id = ' . (int)$section_id) . 
				($filt['section']['enabled'] ? " AND lm_section_enabled > 0 ":'') .
			" ORDER BY lm_section_order,lm_section_name;";
		if($result_section = Ccms::$cDBcms->query_unbuffered($sql_section_query)) {
			while($section = Ccms::$cDBcms->fetch_array_unbuffered($result_section)) {
				Ccms_DB_checks::sanitize_DB_table('lm_sections',$section);
				if(!self::check_user_group_ids($section['lm_section_group_ids'])) continue;
				if(((empty($filt['section']['keywords'])) && (empty($filt['link']['keywords']))) ||
					(!empty($filt['section']['keywords'])) && (empty($filt['link']['keywords']))) {	// only looking for links
					if(in_array($section['lm_section_id'],self::$sections_fnd)) continue;
					$section_found = self::check_section_keywords($section,$filt['section']['keywords']);
					} // if
				$links_found = false;
				if(((!empty($filt['link']['keywords'])) || ($section_found)) && ($inc_links)) {
					$links_found = self::find_links_in_section_layout($layout_data, $filt, $section['lm_section_id'], $lev,$section_found);
					} // if
				if(($section_found) || ($links_found)) {
					self::is_section_parent_available($section);
					$layout_data['sections'][($section['lm_section_id'])]['data'] = $section;
					$layout_data['sections'][($section['lm_section_id'])]['level'] = $lev;
					$layout_data['sections'][($section['lm_section_id'])]['found'] = $section_found;
					self::$layout_data['section_cnt']++;
					self::$sections_fnd[] = $section['lm_section_id'];
					} // if

				// check for children
				$sql_section_child_query = "SELECT lm_section_id" .
					" FROM  lm_sections" .
					" WHERE " . ($filt['section']['enabled'] ? " lm_section_enabled > 0 AND ":'') .
					' lm_section_parent_id = ' . (int)$section['lm_section_id'] .
					" ORDER BY lm_section_order,lm_section_name;";
				if($result_section_child = Ccms::$cDBcms->query_unbuffered($sql_section_child_query)) {
					while($section_child = Ccms::$cDBcms->fetch_array_unbuffered($result_section_child)) {
						Ccms_DB_checks::sanitize_DB_table('lm_sections',$section_child);
						$lm_section_child_id = $section_child['lm_section_id'];
						if(((int)$lm_section_child_id > 0) &&
							((int)$lm_section_child_id != (int)$section_id)) {
							if(empty($layout_data['sections'][($section['lm_section_id'])]))
								$layout_data['sections'][($section['lm_section_id'])] = false;	// seed
							$sub_section_found = self::find_sections_links_layout_recurs(	// recurse it
								$layout_data['sections'][($section['lm_section_id'])],
								$filt,$inc_links,
								$lm_section_child_id,($lev + 1));
							if($sub_section_found) {
								$layout_data['sections'][($section['lm_section_id'])]['data'] = $section;
								$layout_data['sections'][($section['lm_section_id'])]['level'] = $lev;
								$layout_data['sections'][($section['lm_section_id'])]['found'] = $section_found;
								self::$layout_data['section_cnt']++;
								self::$sections_fnd[] = $section['lm_section_id'];
								} // if
							} // if
						} // while
					} // if

				} // while
			}//if
		return $section_found;
		} // find_sections_links_layout_recurs()

	private static function find_orphan_sections_layout_recurs(&$layout_data,&$filt,$section_parent_id = 0,$lev = 0) {
		if(in_array($section_parent_id,self::$sections_fnd)) return;
		$where = '';
		if($filt['section']['enabled']) $where .= "lm_section_enabled > 0";
		$where .= " lm_section_parent_id = " . $section_parent_id;
		$sql_section_query = "SELECT * FROM  lm_sections" .
			(!empty($where) ? " WHERE " . $where:'') .
			" ORDER BY lm_section_order,lm_section_name;";
		if($result_section = Ccms::$cDBcms->query_unbuffered($sql_section_query)) {
			while($section = Ccms::$cDBcms->fetch_array_unbuffered($result_section)) {
				Ccms_DB_checks::sanitize_DB_table('lm_sections',$section);
				if(!self::check_user_group_ids($section['lm_section_group_ids'])) continue;
				if(in_array($section['lm_section_id'],self::$sections_fnd)) continue;
				if(in_array($section['lm_section_parent_id'],self::$sections_fnd)) continue;
				// if(self::check_section_keywords($section,$filt['section']['keywords'])) {
					self::is_section_parent_available($section);
					$layout_data['section_orphans'][($section['lm_section_id'])]['data'] = $section;
					$layout_data['section_orphans'][($section['lm_section_id'])]['level'] = $lev;
					$layout_data['section_orphans'][($section['lm_section_id'])]['level'] = 'orphan';
					self::$sections_fnd[] = $section['lm_section_id'];
				// 	} // if

					// check for children
					$sql_section_child_query = "SELECT lm_section_id" .
						" FROM  lm_sections" .
						" WHERE " . ($filt['section']['enabled'] ? " lm_section_enabled > 0 AND ":'') .
						' lm_section_parent_id = ' . (int)$section['lm_section_id'] .
						" ORDER BY lm_section_order,lm_section_name;";
					if($result_section_child = Ccms::$cDBcms->query_unbuffered($sql_section_child_query)) {
						while($section_child = Ccms::$cDBcms->fetch_array_unbuffered($result_section_child)) {
							Ccms_DB_checks::sanitize_DB_table('lm_sections',$section_child);
							$lm_section_child_id = $section_child['lm_section_id'];
							if(((int)$lm_section_child_id > 0) &&
								((int)$lm_section_child_id != (int)$section['lm_section_id'])) {
								if(empty($layout_data['section_orphans'][($section['lm_section_id'])]))
									$layout_data['section_orphans'][($section['lm_section_id'])] = false;	// seed
								$sub_section_found = self::find_orphan_sections_layout_recurs(	// recurse it
									$layout_data['section_orphans'][($section['lm_section_id'])],
									$filt,$lm_section_child_id,($lev + 1));
								if($sub_section_found) self::$layout_data['orphan_link_cnt']++;
								} // if
							} // while
						} // if

//				if((int)$section_parent_id != (int)$section['lm_section_id']) {
//					self::find_orphan_sections_layout_recurs(
//						$layout_data['section_orphans'][($section['lm_section_id'])],
//						$filt,$section['lm_section_parent_id']);	// recurse
//					} // if
				} // while
			}//if
		} // find_orphan_sections_layout_recurs()

	private static function find_orphan_links(&$layout_data, &$filt) {
		$sql_link_query = "SELECT * FROM  lm_links" .
			($filt['link']['enabled'] ? ' WHERE lm_link_enabled > 0':'') .
			" ORDER BY lm_link_order,lm_link_name;";
		$layout_data['link_orphans'] = array();
		if((!empty($filt['section']['keywords'])) &&	// nothing in section data to search
			(!preg_match('/orphan/i',$filt['section']['keywords']))) return;	// but show orphans

		if($result_link = Ccms::$cDBcms->query_unbuffered($sql_link_query)) {
			$layout_data['link_orphans'][0]['data'] = array(	// dummy section
				'lm_section_id' => -1,
				'lm_section_name' => '',	// 'Orphaned Links',
				'lm_section_description' => 'Links not connected to a section.',
				'lm_section_title' => '',
				);
			while($link = Ccms::$cDBcms->fetch_array_unbuffered($result_link)) {
				Ccms_DB_checks::sanitize_DB_table('lm_links',$link);
				$sql_section_query = 'SELECT lm_section_id FROM lm_sections WHERE lm_section_id = ' . $link['lm_link_section_id'];
				if(((!is_null($link['lm_link_section_id'])) && (!empty($link['lm_link_section_id']))) &&
					($result_sect = Ccms::$cDBcms->query_unbuffered($sql_section_query))) {
					// has a section, not an orphan
					continue;
					} //if
		
				// if(in_array($link['lm_link_id'],self::$links_fnd)) continue;
				if(self::check_link_keywords($link,$filt['link']['keywords'])) {
					$layout_data['link_orphans'][0]['links'][($link['lm_link_id'])]['data'] = $link;	// put in if link matches
					self::$links_fnd[] = $link['lm_link_id'];
					$layout_data['orphan_link_cnt']++;
					} // if
				} // while
			} // if
		} // find_orphan_links()

	public static function &find_sections_links_layout($filters = false,$inc_links = true,$inc_orphans = false) {
		if(self::$layout_data) return self::$layout_data;
		self::$sections_fnd = array();
		self::$links_fnd = array();
		if(Ccms::is_admin_action()) {	// extra seach columns
			self::$linkkeys = array('lm_link_name','lm_link_title','lm_link_description','lm_link_comments');	// ,'lm_link_url','lm_link_image_url','lm_link_icon_url'
			self::$sectkeys = array('lm_section_name', 'lm_section_title', 'lm_section_description','lm_section_comments');	// ,'lm_section_image_url', 'lm_section_icon_url'
			} // if
		$filt_def = array(	// fill in the gaps
			'section' => array( 'enabled' => true, 'keywords' => '',),
			'link' => array( 'enabled' => true, 'keywords' => '',),
			);
		if((!empty($filters)) && (is_array($filters))) {
			$filt = array_merge($filt_def,$filters);	// fill missing variables
			} // if
		else $filt = &$filt_def;

		self::$layout_data = array(
			'section_cnt' => 0,
			'link_cnt' => 0,
			'orphan_link_cnt' => 0,
			'filt' => $filt,	// info
			);
		self::find_sections_links_layout_recurs(self::$layout_data,$filt,$inc_links);
		if($inc_orphans) {
			self::find_orphan_sections_layout_recurs(self::$layout_data,$filt);
			if($inc_links) {
				self::find_orphan_links(self::$layout_data,$filt);
				} // if
			} // if
		if(self::is_debug())
			self::save_json (VAR_FS_TEMP_DIR . 'sections_links.json', self::$layout_data,false,true,true);
		return self::$layout_data;
		} // find_sections_links_layout()

} // Ccms_lm_filter
