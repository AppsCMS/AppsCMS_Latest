<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_html.php 3275 2023-03-18 04:01:17Z robert0609 $
 */

/**
 * Description of cms_html
 * static html class for AppsCMS
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_sm.php');	// speed up, save class lookup

class Ccms_html extends Ccms_sm {

	private static $cms_calendar_sent = false;
	private static $cms_calendar_ids = false;

	// private static $cms_rgbcp_sent = false;
	// private static $cms_rgbcp_ids = false;

	private static $cms_admin_scroll2anchor_done = array();
	
	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function send_downloads() {	// check for downloads and send them
		// need to initiate downloads before any header info is send.
		if (!$dls = self::get_cms_sess_var('downloads')) return 0;
		foreach ($dls as $k => $dn) {	// foreach to skip changes
			self::unset_cms_sess_var('downloads',$k);
			if (!file_exists($dn)) continue;
			// send a download
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="'.basename($dn).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($dn));
			readfile($dn);

			header('Refresh:0');
			exit(0);
			} // foreach
		} // send_downloads()

	public static function gen_group_selection_list($name, $cms_group_ids = 0, $size_max = '', $params = '') {
		if(!is_array($cms_group_ids)) $cms_group_ids = explode(':', $cms_group_ids);
		$sql_query = "SELECT" .
			" cms_group_id,cms_group_name,cms_group_enabled,cms_group_admin" .
			" FROM cms_groups ORDER BY cms_group_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
//			$options[] = array(
//					'value' => -1,
//					'selected' => false,
//					'text' => ' - Select Group - ',
//					'params' => ' disabled selected hidden',
//					);
			$options[] = array(
					'value' => 0,
					'selected' => (in_array(0,$cms_group_ids) ? true:false),
					'text' => 'All Groups (default)',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				$options[] = array(
					'value' => $row['cms_group_id'],
					'selected' => (in_array((int)$row['cms_group_id'],$cms_group_ids) ? true:false),
					'text' => $row['cms_group_name'] . ' (' . ($row['cms_group_enabled'] == true ? 'enabled':'disabled') . ($row['cms_group_admin'] == 1 ? ', admin':'') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No groups setup)</span>',
					);
		self::$cDBcms->free_result($result);
		if(empty($size_max)) $size_max = 6;
		if(count($options) < $size_max) $size_max = count($options);
		return self::gen_selection_list($name, $options, 'size="' . $size_max . '" ' . $params, false, true,false);
	} // gen_group_selection_list()

	public static function gen_group_user_selection_list($name, $cms_group_user_ids = 0, $size_max = '', $params = '') {
		if(!is_array($cms_group_user_ids)) $cms_group_user_ids = explode(':', $cms_group_user_ids);
		$sql_query = "SELECT" .
			" cms_user_id,cms_user_name,cms_user_enabled" .
			" FROM cms_users ORDER BY cms_user_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
//			$options[] = array(
//					'value' => -1,
//					'selected' => false,
//					'params' => ' disabled selected hidden',
//					'text' => ' - Select User/s - ',
//					);
			$options[] = array(
					'value' => 0,
					'selected' => (in_array(0,$cms_group_user_ids) ? true:false),
					'text' => ' All Users (enabled)',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				$options[] = array(
					'value' => $row['cms_user_id'],
					'selected' => (in_array((int)$row['cms_user_id'],$cms_group_user_ids) ? true:false),
					'text' => $row['cms_user_name'] . ' (' . ($row['cms_user_enabled'] == true ? 'enabled':'disabled') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No users setup)</span>',
					);
		self::$cDBcms->free_result($result);
		if(empty($size_max)) $size_max = 6;
		if(count($options) < $size_max) $size_max = count($options);
		return self::gen_selection_list($name, $options, 'size="' . $size_max . '" ' . $params);
	} // gen_group_user_selection_list()

	public static function manager_selection_list($name, $cms_group_admin_ids = 0, $size_max = '', $params = '') {
		if(!is_array($cms_group_admin_ids)) $cms_group_admin_ids = explode(':', $cms_group_admin_ids);
		$sql_query = "SELECT" .
			" cms_user_id,cms_user_name,cms_user_enabled" .
			" FROM cms_users ORDER BY cms_user_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => -1,
					'selected' => false,
					'text' => ' - Select Group Manager/s - ',
					'params' => ' disabled selected hidden',
					);
			$options[] = array(
					'value' => 0,
					'selected' => false,
					'text' => 'No Group Manager - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				$options[] = array(
					'value' => $row['cms_user_id'],
					'selected' => (in_array((int)$row['cms_user_id'],$cms_group_admin_ids) ? true:false),
					'text' => $row['cms_user_name'] . ' (' . ($row['cms_user_enabled'] == true ? 'enabled':'disabled') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No users setup)</span>',
					);
		self::$cDBcms->free_result($result);
		if(empty($size_max)) $size_max = 6;
		if(count($options) < $size_max) $size_max = count($options);
		return self::gen_selection_list($name, $options, 'size="' . $size_max . '" ' . $params);
	} // manager_selection_list()

	public static function page_start_comment($file, $prn = true) {	// outputs a stx marker for the php file
		return Ccms_trckr::page_start_track_comment($file, $prn);
	} // page_start_comment()

	public static function page_end_comment($file, $prn = true) {	// outputs a etx marker for the php file
		return Ccms_trckr::page_end_track_comment($file, $prn);
	} // page_end_comment()

	public static function get_agree_dialog(&$tla) {
		$text = '';

		if(!Ccms_auth::is_eula_enabled('terms')) return $text;
		if(empty($tla['terms'])) return $text;
		if(!$tla['terms_upfirst']) return $text;
		if(!$tla['terms_show']) return $text;

		$show = $tla['terms_show'];
		$name = 'terms';
		$terms = $tla['terms'];

		$text .= <<< EOTSTY
		<style>
			/* override modal background */
			#id_{$name}_id_dlg__modal {
				background-color: lightblue;	/* should be covered !! */
				border-radius: 7px;
				border: 2px solid black;
				}

			/* give h1 a boost */
			#id_{$name}_id_dlg__body h1 {
				text-align: center;
				color: purple;
				}

		</style>
EOTSTY;

		$form_id = '';
		$class = '';	// usually 'page_body'
		ob_start();
		include(CMS_FS_OPS_DIR . 'cms_eula_form.php');
		$body_text = ob_get_clean();

		// this could be done by calling panels separately
		$id = "id_{$name}_dlg_";
		$class_name = '';
		$h1 = '';
		$header = '';
		$footer = '';

		$cModal = new Ccms_modal();
		$text .= $cModal->get_modal($id, $body_text, $class_name, $h1, $header, $footer, $name,true);
		$m_name = $cModal->get_name();
		$m_show = ($show ? 'true':'false');
		$text .= <<< EOTJS

		<script type="text/javascript">
			function show_{$name}_modal() {
			{$m_name}_open_modal();
			} // show_{$name}_modal()

		var show = {$m_show};
		if(show) {
			show_{$name}_modal();	// open dialog
			} // if

		</script>

EOTJS;
		return $text;
		} // get_agree_dialog()

	public static function get_page_legals() {
		$tla = self::get_releasenotes_terms_licence_ack_uris();
		if(empty($tla['html'])) return '';
		$text = $tla['html'];
		$text .= Ccms::get_agree_dialog($tla);
		return $text;
		} // get_page_legals()

	public static function get_about_text_link() {
		$text = array();
		if(CMS_C_SHOW_CMS_ABOUT_LINK) {
			if((CMS_S_ALLOW_ABOUT_MANUAL_LINKS_BOOL) || (self::is_cms_user())) {
				$text[] = '<a href="index.php?cms_action=cms_about" title="About ' . self::get_version_str() . '"';
				$text[] = '	onclick="Ccms_cursor.setWait();">';
				$text[] = '	' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION;
				$text[] = '</a>';
				} // if
			else $text[] = (self::is_debug() ? ' (Debug)':'&nbsp;');
			} // if
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_about_text_link()

	public static function get_show_counter_text() {
		$text = array();

		if((CMS_C_SHOW_VISITOR_COUNTER) && (!empty(self::$cms_visitor_cnt))) {
			$sct = (!empty(self::$cms_site_data['ct']) ? ' title="Since: ' . date('jS M Y',self::$cms_site_data['ct']) . '"':'');
			$text[] = '<span' . $sct . '>Visitor # ' . number_format(self::$cms_visitor_cnt) . '.</span>';
			} // if

		// show visited to site count
		if(CMS_C_SHOW_COOKIE_COUNTER) {
			$text[] = '	<script type="text/javascript">';
			$text[] = '		Ccms_cookie.showClientVisitsCntrCookie("visits","Visited","times.",' . (int)CMS_C_SHOW_COOKIE_COUNTER  . ');';
			$text[] = '	</script>';
			} // if
		else $text[] = '&nbsp;'; // no cookie access
		return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
		} // get_show_counter_text()

	public static function get_copyright_text() {
		if(!empty(self::$cms_page_info['cms_body_copyright'])) {
			$text = self::$cms_page_info['cms_body_name'] . ' &copy; ' . self::$cms_page_info['cms_body_copyright'];
			return $text . PHP_EOL;
			} // if
		else if(($id = (int)self::$cms_tool_id) > 0) {
			foreach(self::$cms_tools as &$t) {
				if(($t['id'] == $id) && (!empty($t['copyright']))) {
					$text = $t['name'] . ' &copy; ' . $t['copyright'];
					return $text . PHP_EOL;
					} // if
				} // foreach
			} // else if
		if(strlen(CMS_C_META_COPYRIGHT) > LM_C_MIN_NAME_LEN) {
			$text = array();
			$text[] = CMS_C_META_COPYRIGHT . ' &copy; ' . date('Y') . ' ';
			if((defined('CMS_C_WEB_SITE_ADDRESS')) &&
				(strlen(CMS_C_WEB_SITE_ADDRESS) > LM_C_MIN_NAME_LEN)) {
				$text[] = '	<a href="' . CMS_C_WEB_SITE_ADDRESS . '" target="_blank">' . trim(CMS_C_CO_NAME) . '</a>';
				} // if
			else $text[] = trim(CMS_C_CO_NAME);
			return PHP_EOL . implode(PHP_EOL , $text) . PHP_EOL;
			} // if
		return '';
		} // get_copyright_text()

	private static function get_icon_file_elem($type,$id_name,$title,$class,$nbar) {
		if((empty($type)) || (empty($id_name))) return '';
		if((empty($title)) && (is_string($id_name))) $title = $id_name;
//		if((!$nbar) && (CMS_C_MENU_ICONS_ALLOW === false))
//			return $title;
//		if(($nbar) && (CMS_S_NAV_BAR_ELEM_SHOW_ICONS_BOOL === false))
//			return $title;

		$icon = false;
		if(((!$nbar) && (CMS_C_MENU_ICONS_ALLOW)) ||
			(($nbar) && (CMS_S_NAV_BAR_ELEM_SHOW_ICONS_BOOL))) {
			switch(strtolower($type)) {	// try the basic types first
			case 'admin':
			case 'manage':
			case 'config':
			case 'settings':
				$icon = ((strlen(CMS_C_ADMIN_ICON) > 4) ? CMS_C_ADMIN_ICON : 'admin.png');
				break;
			case 'tools':
				$icon = ((strlen(CMS_C_TOOLS_ICON) > 4) ? CMS_C_TOOLS_ICON : 'tools.png');
				break;
			case 'log_in':
			case 'cms_login':
				$icon = ((strlen(CMS_C_LOGIN_ICON) > 4) ? CMS_C_LOGIN_ICON : 'login.png');
				break;
			case 'log_out':
			case 'logout':
				$icon = ((strlen(CMS_C_LOGOUT_ICON) > 4) ? CMS_C_LOGOUT_ICON : 'logout.png');
				break;
			case 'change_password':
			case 'chg_passwd':
				$icon = ((strlen(CMS_C_CHG_PASSWD_ICON) > 4) ? CMS_C_CHG_PASSWD_ICON : 'chg_passwd.png');
				break;
			default:
				break;
				} // switcn
			} // if
		if(!$icon) {
			switch($type) {
			case 'app':
			case 'body':
				// now try page / app icons, $type is either a body id or a body name.
				$icon = self::$cDBcms->get_data_in_table('cms_bodies', ($nbar ? 'cms_body_icon_url':'cms_body_image_url'),
						"cms_body_id = " . (int)$id_name . " OR cms_body_app_key = '" . self::$cDBcms->input($id_name) . "' OR cms_body_name = '" . self::$cDBcms->input($id_name) . "'");
				break;
			case 'link':
				$icon = self::$cDBcms->get_data_in_table('lm_links', ($nbar ? 'lm_link_icon_url':'lm_link_image_url'),
						"lm_link_id = " . (int)$id_name . " OR lm_link_name = '" . self::$cDBcms->input($id_name) . "'");
				break;
			case 'tool':
				$icon = self::$cDBcms->get_data_in_table('cms_tools', ($nbar ? 'cms_tool_icon_url':'cms_tool_image_url'),
						"cms_tool_id = " . (int)$id_name . " OR cms_tool_name = '" . self::$cDBcms->input($id_name) . "'");
				break;
			default:
				break;
				} // switch
			} // if
		if(empty($icon))  return $title;

		$path = '';	// empty
		if(file_exists($icon)) $path = $icon;
		else if(file_exists(ETC_FS_ICONS_DIR . $icon)) $path = ETC_WS_ICONS_DIR . $icon;
		else if(file_exists(ETC_FS_IMAGES_DIR . $icon)) $path = ETC_WS_IMAGES_DIR . $icon;
		else if(file_exists(CMS_FS_ICONS_DIR . $icon)) $path = CMS_WS_ICONS_DIR . $icon;
		// @TODO check $icon as a URL
		if(empty($path)) return $title;

		$text = '<img alt="icon" class="' . $class . '" src="' . $path . '">';
		if((!self::is_tiny()) && (!self::is_tablet())) {	// small device
			$text .= $title;
			} // if
		return $text;
		} // get_icon_file_elem()

	public static function get_navbar_icon_text($id_name, $title = false, $class = "cms_nav_bar") {
		return self::get_icon_file_elem('nbar', $id_name, $title, $class, true);
		} // get_navbar_icon_text()

	public static function get_menu_icon_text($id_name, $title = false, $class = "menu_link_icon") {
		return self::get_icon_file_elem('body', $id_name, $title, $class, false);
		} // get_menu_icon_text()

	public static function get_tool_icon_text($id_name, $title = false, $class = "menu_link_icon") {
		return self::get_icon_file_elem('tool', $id_name, $title, $class, false);
		} // get_tool_icon_text()

	public static function get_link_icon_text($id_name, $title = false, $class = "menu_link_icon") {
		return self::get_icon_file_elem('link', $id_name, $title, $class, false);
		} // get_link_icon_text()

	public static function get_body_image_text($img, $alt = '', $class = '') {
		if(empty($img)) return $alt;
		$path = '';	// empty
		if(file_exists($img)) $path = $img;
		else if(file_exists(ETC_FS_IMAGES_DIR . $img)) $path = ETC_FS_IMAGES_DIR . $img;
		else if(file_exists(ETC_FS_IMAGES_DIR . $img)) $path = ETC_WS_IMAGES_DIR . $img;
		else if(file_exists(CMS_FS_IMAGES_DIR . $img)) $path = CMS_WS_IMAGES_DIR . $img;
		if(empty($path)) return $alt;

		$text = '<img alt="body image"' .
				(!empty($alt) ? ' alt="' . $alt . '"':'') .
				(!empty($class) ? ' class="' . $class . '"':'') .
				' src="' . $path . '">';
		return $text;
		} // get_body_image_text()

	public static function get_body_icon_text($img, $alt = '', $class = '') {
		if(empty($img)) return $alt;
		$path = '';	// empty
		if(file_exists($img)) $path = $img;
		else if(file_exists(ETC_FS_ICONS_DIR . $img)) $path = ETC_FS_ICONS_DIR . $img;
		else if(file_exists(ETC_FS_ICONS_DIR . $img)) $path = ETC_WS_ICONS_DIR . $img;
		else if(file_exists(CMS_FS_ICONS_DIR . $img)) $path = CMS_WS_ICONS_DIR . $img;
		if(empty($path)) return $alt;

		$text = '<img alt="body"' .
				(!empty($alt) ? ' alt="' . $alt . '"':'') .
				(!empty($class) ? ' class="' . $class . '"':'') .
				' src="' . $path . '">';
		return $text;
		} // get_body_icon_text()

	public static function &get_ws_links_options($sel0_option = false) {
		if(!empty(self::$cms_ws_links_options)) return self::$cms_ws_links_options;

//		if((self::get_cms_action() == 'cms_login') || (self::get_app_action() == 'login'))
//			$logging_in = true;
//		else $logging_in = false;
		$file_list = array();
		$file_list[] = array('text' => (!empty($sel0_option) ? $sel0_option:'-- Select --'), 'value' => -1,);

		$file_list[] = array('text' => 'Home', 'value' => 'index.php?action=home',);	// dont't use cms_action as it won't load the page CSS

		$file_list[] = array('name' => 'Menu: Admin', 'text' => 'Admin', 'value' => 'menu=admin',);

		$file_list[] = array('name' => 'Menu: Tools','text' => 'Tools', 'value' => 'menu=tools',);

		$file_list[] = array('name' => 'Menu: Apps','text' => 'Apps', 'value' => 'menu=apps',);

		if(Ccms_sm::is_links_manager_inuse()) {
			$file_list[] = array(
				'text' => 'Links',
				'value' => 'index.php?cms_action=lm_show_links',
				'title' => "Goto Links Manager page",
				);
			} // if

		foreach(Ccms_options::get_tools_menu_items() as &$sv) {
			if(empty($sv['uri'])) continue;
//			if($logging_in) $sv['allowed_now'] = false;
			$sv['name'] = 'Tool: ' . $sv['text'];
			$sv['value'] = (!empty($sv['id']) ? $sv['id']:$sv['uri']);
			$file_list[] = $sv;
			} // foreach

		$cms_app_menu_uris = Ccms::get_all_plugins_static_func_text('get_menu_uris');
		if(!empty($cms_app_menu_uris)) {
			foreach($cms_app_menu_uris as &$cms_app_items) {
				foreach($cms_app_items as $n => &$sv) {
					if(empty($sv['uri'])) continue;
					if($logging_in) $sv['allowed_now'] = false;
					if(!empty($sv['app_name']))  $sv['name'] = $sv['app_name'] . ': ' . $sv['text'];
					$sv['value'] = (!empty($sv['id']) ? $sv['id']:$sv['uri']);
					$file_list[] = $sv;
					} // foreach
				} // foreach
			} // if

		foreach(Ccms_options::get_bodies_menu_items() as &$sv) {
			if($sv['text'] == 'Links') continue;
			if(empty($sv['uri'])) continue;
//			if($logging_in) $sv['allowed_now'] = false;
			$sv['name'] = 'App: ' . $sv['text'];
			$sv['value'] = (!empty($sv['id']) ? $sv['id']:$sv['uri']);
			$file_list[] = $sv;
			} // foreach

		// add the other URIs
		$file_list[] = array(
			'text' => 'About',
			'value' => 'index.php?cms_action=cms_about',
			'title' => 'About ' . CMS_PROJECT_SHORTNAME,
			);

		$file_list[] = array(
			'text' => 'Manual',
			'value' => 'index.php?cms_action=cms_manual',
			'title' => CMS_PROJECT_SHORTNAME . ' Manual',
			);

		// $file_list[] = array(
		//	'text' => 'Disclaimer',
		//	'value' => 'index.php?cms_action=disclaimer',
		//	);

		$file_list[] = array(
			'text' => 'Login',
			'value' => 'login.php',
			);

		$file_list[] = array(
			'text' => 'Logout',
			'value' => 'logout.php',
			);

//		foreach($file_list as &$sv) {
//			if((!empty($sv['text'])) && (!empty($sv['value'])) &&
//				(strlen($sv['text']) > 2) && (strlen($sv['value']) > 6)) {
//				$sv['sub_vals'] = serialize(array('text'=> $sv['text'],'uri' => $sv['value']));
//				} // if
//			} // foreach

		self::$cms_ws_links_options = $file_list;
		return self::$cms_ws_links_options;
	} // get_ws_links_options()

	public static function get_simple_select($name,$value,$options,$params = false, $id = false,$title = false) {
		// intended to replace checkboxes in form control
		// (i.e. when checkbox is unchecked it returns nothing)
		// with good options, label should be unnecessary
		$text = '';
		$text .= '<select name="' . $name . '"' . ($params ? ' ' . $params:'') . ($id ? ' id="' . $id . '"':'') . ($title ? ' title="' . $title . '"':'') . '>';
		foreach($options as $v) {
			$text .= '<option value="' . rawurlencode($v) . '">' . htmlentities($v) . '</option>';
			} // foreach
		$text .= '</select>' . PHP_EOL;
		return $text;
		} // get_simple_select()

	public static function get_keyed_select($name,$value,$options,$params = false, $id = false,$title = false) {
		// intended to replace checkboxes in form control
		// (i.e. when checkbox is unchecked it returns nothing)
		// with good options, label should be unnecessary
		// also this is good on/off select using 0 and 1 as the keys
		$text = '';
		$text .= '<select name="' . $name . '"' . ($params ? ' ' . $params:'') . ($id ? ' id="' . $id . '"':'') . ($title ? ' title="' . $title . '"':'') . '>';
		foreach($options as $k => $v) {
			$text .= '<option value="' . $k . '"' . (($k == $value) ? ' SELECTED':'') . '>' . htmlentities($v) . '</option>';
			} // foreach
		$text .= '</select>' . PHP_EOL;
		return $text;
		} // get_keyed_select()

	public static function make_ws_link_select_options() {
		$file_list = self::get_ws_links_options('-- Select Link URI to Copy --');
		return self::add_svalues_options($file_list,'-1');
	} // make_ws_link_select_options()

	public static function add_svalues_options(&$svalues,$value) {
		$text = '';
		if(is_array($value)) $value = serialize($value);
		foreach($svalues as &$sv) {
			if((!is_array($sv)) && ((!empty($sv)) || (is_numeric($sv)))) {
				$svt = preg_replace('/\n|\r/i', ' ',  strip_tags($sv));
				$text .= PHP_EOL . '	<option value="' . $svt . '"' . (($value == $sv) ? ' SELECTED':'') . '>' . $svt . '</option>';
				} // if
			else if(is_array($sv)) {
				$val = (!empty($sv['sub_vals']) ? $sv['sub_vals']:$sv['value']);
				$text .= PHP_EOL . '	<option value="' . urlencode($val) . '"' . (($value == $val) ? ' SELECTED':'') . '>' . (!empty($sv['name']) ? $sv['name']:$sv['text']) . '</option>';
				} // else
			} // foreach
		return PHP_EOL . $text . PHP_EOL;
	} // add_svalues_options()

	protected static function gen_selection_list($name, $options, $params = '', $exc = false, $bare = false, $onchange_submit = false) {
		if((empty($options)) || (!is_array($options))) return '';
		if($exc) {
			if(!is_array($exc)) $exc = preg_split('/[\s,\;\;]+/',$exc);
			} // if
		else $exc = array();
		$id = '';
		$text = PHP_EOL;
		if(!$bare) {
			$text .= '<div class="cms_select_filtered">' . PHP_EOL;
			if(!empty($name)) {
				$id = 'id_' . $name;
				$text .= Ccms_edit::get_select_option_filter($id, '',-1,Ccms_edit::count_sel_opts($options)) . PHP_EOL;
				} // if
			} // if
		$text .= '<select' .
			(!empty($id) ? ' id="' . $id . '"':'') .
			(!empty($name) ? ' name="' . $name . '"':'') .
			(!$bare ? ' onclick="cms_filter_select_click(this);"':'') .
			($onchange_submit ? ' onchange="this.form.submit();"':'');
		if(!empty($params)) $text .= ' ' . $params;
		if((preg_match('/multiple/i',$params)) && (!preg_match('/title="/i', $params))) {
			$text .= ' title="Hold Ctl key down to select multiple options."';
			} // if
		$text .= '>' . PHP_EOL;
		for($i = 0, $n = count($options); $i < $n; $i++) {
			$option = &$options[$i];
			if((in_array($option['value'],$exc)) || (in_array($option['text'],$exc))) continue;
			$text .= PHP_EOL .
				'<option value="' . htmlentities($option['value']) . '"' .
				($option['selected'] ? ' SELECTED':'');
			if(!empty($option['params'])) $text .= ' ' . $option['params'];
			$text .= '>';
			$text .= $option['text'];
			$text .= '</option>' . PHP_EOL;
			} // for
		$text .= PHP_EOL . '</select>' . PHP_EOL;
		if(!$bare) $text .= '</div>' . PHP_EOL;
		return $text;
	} // gen_selection_list()

	public static function gen_user_selection_list($name, $cms_user_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT cms_user_id,cms_user_name,cms_user_enabled,cms_user_admin" .
			" FROM cms_users ORDER BY cms_user_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($cms_user_id ? false:true),
					'params' => ' disabled selected hidden',
					'text' => ' - Select User - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['cms_user_id'],$exc_ids)) continue;
				$options[] = array(
					'value' => $row['cms_user_id'],
					'selected' => ((int)$row['cms_user_id'] == (int)$cms_user_id ? true:false),
					'text' => $row['cms_user_name'] . ' (' . ($row['cms_user_enabled'] == true ? 'enabled':'disabled') . ($row['cms_user_admin'] == 1 ? ', admin':'') . ')',
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No users setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_user_selection_list()

	public static function gen_link_selection_list($name, $lm_link_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT lm_link_id,lm_link_name,lm_link_title,lm_link_description" .
			",lm_link_section_id,lm_section_name,lm_link_new_page, lm_link_image_url, lm_link_icon_url" .
			",lm_section_order,lm_section_title,lm_link_order,lm_link_enabled, lm_link_ssl, lm_link_add_name2url,lm_section_enabled,lm_section_id" .
			" FROM  lm_links as l LEFT JOIN lm_sections as s ON l.lm_link_section_id = s.lm_section_id" .
			" WHERE lm_link_id > 0" .
			" AND (l.lm_link_section_id = s.lm_section_id OR l.lm_link_section_id = 0)" .
			" ORDER BY lm_section_name,lm_link_name";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($lm_link_id ? false:true),
					'text' => ' - Select Link - ',
					'params' => ' disabled selected hidden',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['lm_link_id'],$exc_ids)) continue;
				$text = (empty($row['lm_section_name']) ? '(no section)':$row['lm_section_name']) .
						' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')';
				$text .= " -&gt; ";
				$text .= $row['lm_link_name'] . ' (' . ($row['lm_link_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['lm_link_id'] == (int)$lm_link_id ? ' **':'');
				$options[] = array(
					'value' => $row['lm_link_id'],
					'selected' => ((int)$row['lm_link_id'] == (int)$lm_link_id ? true:false),
					'text' => $text,
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No links setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_link_selection_list()

	public static function gen_section_selection_options($lm_section_id = 0, $exc_ids = false, $bare = false, $onchange_submit = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT lm_section_id,lm_section_name,lm_section_enabled" .
			" FROM lm_sections ORDER BY lm_section_name,lm_section_order";
		$options = array();
		$cnt = 0;
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			if(!$bare) {
				$options[] = array(
						'value' => 0,
						'selected' => ($lm_section_id ? false:true),
						'params' => ($onchange_submit ? ' disabled selected hidden':''),
						'text' => ' - Select Section - ',
						);
				} // if
			$options[] = array(
					'value' => 0,
					'selected' => false,
					'text' => '(Base parent)',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['lm_section_id'],$exc_ids))
					continue;
				$seld = false;
				if(((int)$lm_section_id > 0) &&
					((int)$lm_section_id == (int)$row['lm_section_id']))
					$seld = true;
				$options[] = array(
					'value' => $row['lm_section_id'],
					'selected' => $seld,
					'text' => (self::is_debug() ? 'ID: ' . $row['lm_section_id'] . ', ':'') . $row['lm_section_name'] . ' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')' . ($seld ? ' **':''),
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No sections setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return $options;
	} // gen_section_selection_options()

	public static function gen_link_section_js_selection_list($name, $lm_section_id, $params = '', $exc_ids = false, $bare = false, $onchange_submit = false) {
		$sql_query = "SELECT lm_section_id,lm_section_name,lm_section_enabled,lm_section_parent_id" .
			" FROM lm_sections" .
			" WHERE lm_section_id = " . (empty($lm_section_id) ? 0:(int)$lm_section_id);
		$options = array();
		$cnt = 0;
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
			($row = self::$cDBcms->fetch_array($result))) {
			$options[] = array(
				'value' => (empty($row['lm_section_id']) ? 0:$row['lm_section_id']),
				'selected' => false,
				'text' => (self::is_debug() ? 'ID: ' . $row['lm_section_id'] . ', ':'') . $row['lm_section_name'] . ' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['lm_section_id'] == (int)$lm_section_id ? ' **':''),
				);
			} // if
		else {
			$options[] = array(
				'value' => 0,
				'selected' => false,
				'text' => '(Orphaned Link)',
				);
			} // else
		return self::gen_selection_list($name, $options, $params, false, $bare,$onchange_submit);
	} // gen_link_section_js_selection_list()

	public static function gen_parent_section_js_selection_list($name, $lm_section_id, $params = '', $exc_ids = false, $bare = false, $onchange_submit = false) {
		$sql_query = "SELECT lm_section_id,lm_section_name,lm_section_enabled,lm_section_parent_id" .
			" FROM lm_sections" .
			" WHERE lm_section_id = " . (int)$lm_section_id;
		$options = array();
		$cnt = 0;
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0) &&
			($row = self::$cDBcms->fetch_array($result))) {
//			if(!empty($exc_ids)) {
//				if(in_array($row['lm_section_id'],$exe_ids)) continue;
//				} // if
			$stat = '';
			if((int)$row['lm_section_parent_id'] == 0) {
				$stat .= ' (Base parent)';
				} // if
			else if((int)$row['lm_section_parent_id'] == (int)$row['lm_section_id']) {
				$stat .= ' (Orphan)';
				} // if
			else {
				$section_parent_name = Ccms::$cDBcms->get_data_in_table('lm_sections','lm_section_name',"lm_section_id = " . (int)$row['lm_section_parent_id'] . "");
				$stat .= (self::is_debug() ? 'ID: ' . $row['lm_section_parent_id'] . ', ':'') . (empty($section_parent_name) ? '(Orphan)':$section_parent_name);
				$stat .= ' (' . ($row['lm_section_enabled'] == true ? 'enabled':'disabled') . ')';
				} // else
			$stat .= ((int)$row['lm_section_id'] == (int)$lm_section_id ? ' **':'');
			$options[] = array(
				'value' => $row['lm_section_id'],
				'selected' => false,
				'text' => $stat,
				);
			} // if
		else {
			$options[] = array(
				'value' => '-1',
				'selected' => false,
				'text' => '(Base parent)',
				);
			} // else
		return self::gen_selection_list($name, $options, $params, false, $bare,$onchange_submit);
	} // gen_parent_section_js_selection_list()

	public static function gen_section_selection_list($name, $lm_section_id = 0, $params = '', $exc_ids = false, $bare = false, $onchange_submit = true) {
		$options = self::gen_section_selection_options($lm_section_id,$exc_ids,$bare,$onchange_submit);
		return self::gen_selection_list($name, $options, $params, false, $bare,$onchange_submit);
	} // gen_section_selection_list()

	public static function gen_body_selection_list($name, $cms_body_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT cms_body_id,cms_body_installed,cms_body_nomenu,cms_body_name,cms_body_app_key,cms_body_enabled,cms_body_group_ids" .
			" FROM cms_bodies WHERE cms_body_nomenu < 1 ORDER BY cms_body_name,cms_body_order";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($cms_body_id ? false:true),
					'text' => ' - Select App/Body - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['cms_body_id'],$exc_ids)) continue;
				if(!self::is_cms_group_manager($row['cms_body_group_ids'])) continue;
				$options[] = array(
					'value' => $row['cms_body_id'],
					'selected' => ((int)$row['cms_body_id'] == (int)$cms_body_id ? true:false),
					'text' => $row['cms_body_name'] . ' (' . ($row['cms_body_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['cms_body_id'] == (int)$cms_body_id ? ' **':''),
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No page bodies setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_body_selection_list()

	public static function gen_tool_selection_list($name, $cms_tool_id = 0, $params = '',$exc_ids = false, $bare = false) {
		if($exc_ids) {
			if(!is_array($exc_ids)) $exc_ids = preg_split('/[^0-9]+/',$exc_ids);
			} // if
		else $exc_ids = array();
		$sql_query = "SELECT cms_tool_id,cms_tool_name,cms_tool_enabled" .
			" FROM cms_tools ORDER BY cms_tool_name,cms_tool_order";
		$cnt = 0;
		$options = array();
		if(($result = self::$cDBcms->query($sql_query)) &&
			(($cnt = self::$cDBcms->num_rows($result)) > 0)) {
			$options[] = array(
					'value' => 0,
					'selected' => ($cms_tool_id ? false:true),
					'params' => ' disabled selected hidden',
					'text' => ' - Select Tool - ',
					);
			while($row = self::$cDBcms->fetch_array($result)) {
				if(in_array($row['cms_tool_id'],$exc_ids)) continue;
				$options[] = array(
					'value' => $row['cms_tool_id'],
					'selected' => ((int)$row['cms_tool_id'] == (int)$cms_tool_id ? true:false),
					'text' => $row['cms_tool_name'] . ' (' . ($row['cms_tool_enabled'] == true ? 'enabled':'disabled') . ')' . ((int)$row['cms_tool_id'] == (int)$cms_tool_id ? ' **':''),
					);
				} // while
			} // if
		else $options[] = array(
					'value' => 0,
					'selected' => true,
					'text' => '<span class="cms_msg_warning">(No tools setup)</span>',
					);
		self::$cDBcms->free_result($result);
		return self::gen_selection_list($name, $options, $params, false, $bare,true);
	} // gen_tool_selection_list()

	public static function is_iframeable_url($url, $add_msg = true) {
		// return false if full url or error, anti click jacking may be in play
		if(!$parts = parse_url($url)) return false;
		if(((isset($parts['scheme'])) && (!empty($parts['scheme']))) ||
			((isset($parts['host'])) && (!empty($parts['host'])))) {
			// not local
			$url_headers = @get_headers($url);
			if($url_headers) {
				foreach ($url_headers as &$value) {
					if(preg_match('/X-Frame-Options.*DENY|X-Frame-Options.*SAMEORIGIN|X-Frame-Options.*ALLOW-FROM/i',$value)) {
						if($add_msg)
							self::addMsg('URL: "' . $url . '" only allowed in new page.',(CMS_C_EXT_URL_NEW_PAGE ? 'warn':'error'));
						return false;
						} // if
					} // foreach
				} // if
			} // if
		return true;	// @TODO $url may not exist
	} // is_iframeable_url()

	public static function get_body_app_run_scripts($name,$cli_script,$option0,$body_dir) {
		$option_cnt = 0;
		$base = preg_replace('/\/.*$/','/',($body_dir . '/'));	// a start folder
		if((!empty($body_dir)) && (!empty($base))) {
			$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Body URL or Include code.">' . PHP_EOL;
			$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select App URL - ') . '</option>' . PHP_EOL;
			if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
			$script_base = APPS_WS_DIR . $base . 'cli/';
			$scripts = @scandir(DOCROOT_FS_BASE_DIR . $script_base);
			if(empty($scripts)) return 'NA';
			foreach($scripts as $file) {
				$script = $file;	// $script = 'cli/' . $file;
				if(!self::is_file_usable($script)) continue;
				if(!preg_match('/\.php$|\.sh$/',$file)) continue;
				$text .= '<option value="' . rawurlencode($file) .'"' . ($file == $cli_script ? ' SELECTED':'') . '>' . $script . '</option>';
				$option_cnt++;
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $cli_script . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No application script found.)</span>';
			return $text;
			} // if
		return $text;
		} // get_body_app_run_scripts()

	private static function  get_body_docs_tools_ext_file_selection_recurse($path,&$text,&$value,&$option_cnt,$base = '',$depth = 0,$preg_match = false) {	// recursive
		if($depth >= (int)CMS_S_TOOLS_SEARCH_DEPTH_MAX) return false;	// no deeper
		$files = @scandir($path . $base);
		if(empty($files)) return false;
		sort($files);
		for($i = 0, $n = count($files); $i < $n; $i++) {
			$file = $files[$i];
			if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN,$file)) continue;	// no hiddens, version control or directory nav
			$file_path = preg_replace('/^\//','',$base . '/' . $file);
			$file_path = self::clean_path($file_path);
			if(is_dir($path . $file_path)) {
				self::get_body_docs_tools_ext_file_selection_recurse($path,$text,$value,$option_cnt, $file_path,($depth + 1));	// recurse
				} // if
			else if(preg_match('/\.htm$|\.php$|\.html$|\.js$|\.css$|\.txt$|\.md$|\.crt$|\.csr$|\.key$/i',$file)) {
				$option_cnt++;
				$text .= PHP_EOL . '<option style="text-align:left;" value="' . htmlentities($file_path) . '"' . (($file_path == $value) ? ' SELECTED':'') . '>' . $file_path . (($file_path == $value) ? ' **':'') . '</option>' . PHP_EOL;
				} // else if
			} // for
		return true;
		} // get_body_docs_tools_ext_file_selection_recurse()

	public static function get_body_dir_selection($name,$body_url,$option0,$body_dir,$preg_match = false) {
		$option_cnt = 0;
		$base = APPS_FS_DIR . $body_dir . '/';	// a start folder
		$value = preg_replace('/^.*' . preg_quote($body_dir,'/') . '\//','',$body_url);	// clean up old settings, remove app dir
		if((!empty($body_dir)) && (!empty($base))) {
			$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Body URL or Include code.">' . PHP_EOL;
			$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select App URL - ') . '</option>' . PHP_EOL;
			if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
			self::get_body_docs_tools_ext_file_selection_recurse($base,$text,$value,$option_cnt,'',0,$preg_match);	// recurse
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $body_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No files found in "' . self::clean_path(APPS_WS_DIR . $base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_body_dir_selection()

	public static function get_tools_dir_selection($name,$cms_tool_url,$option0 = false,$tool_dir = '') {
		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Tool URL or Include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select Tool URL - ') . '</option>' . PHP_EOL;
		if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		$option_cnt = 0;
		if(!empty($tool_dir)) $base = preg_replace('/\/.*$/','/',$tool_dir . '/');	// a start folder
		else $base = '';
		self::get_body_docs_tools_ext_file_selection_recurse(LOCAL_FS_TOOLS_DIR,$text,$cms_tool_url,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;
		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $cms_tool_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_error">(No tool files found in "' . LOCAL_FS_TOOLS_DIR . $base . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_tools_dir_selection()

	public static function get_docs_selection($name,$doc_file,$option0 = false) {
		$option_cnt = 0;
		$base = APPS_WS_DOCS_DIR;	// a start folder
		if(!file_exists(APPS_WS_DOCS_DIR))
			self::chkdir (APPS_WS_DOCS_DIR);

		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Ext include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select Document Include File - ') . '</option>' . PHP_EOL;
		if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		self::get_body_docs_tools_ext_file_selection_recurse(DOCROOT_FS_BASE_DIR,$text,$doc_file,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;

		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $ext_code_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No include docs files found in "' . self::clean_path(APPS_WS_DIR . $base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_docs_selection()

	public static function get_ext_code_dir_selection($name,$ext_code_url,$option0 = false) {
		$option_cnt = 0;
		$base = ETC_WS_EXT_INCLUDES_DIR;	// a start folder
		if(!file_exists(ETC_FS_EXT_INCLUDES_DIR))
			self::chkdir (ETC_FS_EXT_INCLUDES_DIR);

		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Ext include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select External Code Include File - ') . '</option>' . PHP_EOL;
		if($option0) $text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		self::get_body_docs_tools_ext_file_selection_recurse(DOCROOT_FS_BASE_DIR,$text,$ext_code_url,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;

		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $ext_code_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No ext code include files found in "' . self::clean_path($base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_ext_code_dir_selection()

	public static function get_ssl_dir_selection($name,$ssl_url,$option0 = false) {
		$option_cnt = 0;
		$base = ETC_WS_SSL_INCLUDES_DIR;	// a start folder
		if(!file_exists(ETC_FS_SSL_INCLUDES_DIR))
			self::chkdir (ETC_FS_SSL_INCLUDES_DIR);

		$text = PHP_EOL . '<select name="' . $name . '" size="1" title="Ext include code.">' . PHP_EOL;
		$text .= PHP_EOL . '<option value="-1" style="text-align: left" selected hidden>' . ($option0 ? $option0:' - Select SSL Cert File - ') . '</option>' . PHP_EOL;
		$text .= PHP_EOL . '<option value="0" style="text-align: left"> - (Not Set) - </option>' . PHP_EOL;
		self::get_body_docs_tools_ext_file_selection_recurse(DOCROOT_FS_BASE_DIR,$text,$ssl_url,$option_cnt,$base);	// recurse
		$text .= PHP_EOL . '</select>' . PHP_EOL;

		if(!$option_cnt) {
			// nothing line, saye something
			$text = '<input type="hidden" name="' . $name . '" value="' . $ssl_url . '">' . PHP_EOL;
			$text .= '<span class="cms_msg_info">(No include SSL files found in "' . self::clean_path($base) . '" directory.)</span>';
			return $text;
			} // if
		return $text;
		} // get_ssl_selection()

	public static function get_admin_scroll2anchor($topOffset = false, $js_flg = true, $name = 'Top', $class = '') {
		if(in_array($name,self::$cms_admin_scroll2anchor_done)) return '';	// not more than once with the same name
		$nsp_name = preg_replace('/[^0-9a-zA-Z]+/','_',$name);	// remove spaces and other silly chars
		self::$cms_admin_scroll2anchor_done[] = $nsp_name;
		$text = '' . PHP_EOL;
		$text .= '<a name="' . $nsp_name . '"></a>' . PHP_EOL;
		if(($js_flg) && (!self::is_tablet())) {
			$htm_name = htmlentities($name);
			$block = (self::use_block_html() ? 'true':'false');
			$bid = 'cms_lo_body_column';
			if(!is_numeric($topOffset)) $topOffset = 'false';
			$text .= <<< EOTANCH

<div id="id_cms_goto_{$nsp_name}_box"
	class="admin_scroll2anchor_box {$class}"
	ondragend="cms_dragend_elem_save('id_cms_goto_{$nsp_name}_box','{$bid}');"
	ondragstart="cms_drag_start(event);"
	draggable="true" onclick="cms_scroll2Name('{$nsp_name}',{$topOffset});"
	title="Back to {$name}"
	>{$htm_name}
</div>

<script  type="text/javascript">
	function check_goto_top_box(id) {
		var x = document.getElementById('{$bid}');
		if(!x) return;
		var blk = {$block};
		var b = document.getElementById(id);
		if(!blk) { // inline
			var sY = window.scrollY;
			var iH = window.innerHeight;
			if(sY > (iH / 10)) {	// down the page
				if(typeof cms_dragend_elem_restore === 'function') cms_dragend_elem_restore(id,'{$bid}');
				b.style.display = 'block';
				} // if
			else {	// at/near top of page
				b.style.display = 'none';
				} // else
			} // if
		else { // block
			var sT = x.scrollTop;
			var oH = x.offsetHeight;
			if(sT > (oH / 10)) { // block down the window
				if(typeof cms_dragend_elem_restore === 'function') cms_dragend_elem_restore(id,'{$bid}');
				b.style.display = 'block';
				} // if
			else { // at/near top window
				b.style.display = 'none';
				} // else
			} // else if
		} // check_goto_top_box

	document.addEventListener("DOMContentLoaded", function() {
		check_goto_top_box('id_cms_goto_{$nsp_name}_box');
		window.addEventListener("resize", function() {
			check_goto_top_box('id_cms_goto_{$nsp_name}_box');
			}); // function

		if({$block})
			document.getElementById('{$bid}').addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		else
			window.addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		}); // function
</script>

EOTANCH;

			} // if
		return $text;
		} // get_admin_scroll2anchor()

	public static function get_cookie_values($id) {
		if(!empty($_COOKIE[$id])) $vals = $_COOKIE[$id];
		else return false;
		return $vals;
		} // get_cookie_values()

	public static function get_admin_scroll2pageTop($class = '') {
		$name = 'Top';
		if(in_array($name,self::$cms_admin_scroll2anchor_done)) return '';	// not more than once with the same name
		$nsp_name = preg_replace('/[^0-9a-zA-Z]+/','_',$name);	// remove spaces and other silly chars
		self::$cms_admin_scroll2anchor_done[] = $nsp_name;
		if(self::use_block_html()) {
			$bod = 'cms_lo_body_column';
			} // if
		else $bod = '';
		$id = 'id_cms_goto_' . $nsp_name . '_box';
		if($rect = self::get_cookie_values('CMS_dargend_' . $id)) {
			list($left,$top) = explode(',',$rect);

			} // if
		$text = '' . PHP_EOL;
		if(!self::is_tablet()) {
			$htm_name = htmlentities($name);
			$block = (self::use_block_html() ? 'true':'false');
			$bid = 'cms_lo_body_column';
			$text .= <<< EOTANCH

<div id="{$id}"
	class="admin_scroll2anchor_box {$class}"
	style="display: none;"
	ondragend="cms_dragend_elem_save('id_cms_goto_{$nsp_name}_box','{$bid}');"
	ondragstart="cms_drag_start(event);"
	draggable="true" onclick="cms_scroll2PageTop('{$bod}');"
	title="Goto top of page."
	>{$name}</div>

<script  type="text/javascript">
	function check_goto_top_box(id) {
		var x = document.getElementById('{$bid}');
		if(!x) return;
		var blk = {$block};
		var b = document.getElementById(id);
		if(!blk) { // inline
			var sY = window.scrollY;
			var iH = window.innerHeight;
			if(sY > (iH / 10)) {	// down the page
				if(typeof cms_dragend_elem_restore === 'function') cms_dragend_elem_restore(id,'{$bid}');
				b.style.display = 'block';
				} // if
			else {	// at/near top of page
				b.style.display = 'none';
				} // else
			} // if
		else { // block
			var sT = x.scrollTop;
			var oH = x.offsetHeight;
			if(sT > (oH / 10)) { // block down the window
				if(typeof cms_dragend_elem_restore === 'function') cms_dragend_elem_restore(id,'{$bid}');
				b.style.display = 'block';
				} // if
			else { // at/near top window
				b.style.display = 'none';
				} // else
			} // else if
		} // check_goto_top_box

	document.addEventListener("DOMContentLoaded", function() {
		check_goto_top_box('id_cms_goto_{$nsp_name}_box');
		window.addEventListener("resize", function() {
			check_goto_top_box('id_cms_goto_{$nsp_name}_box');
			}); // function

		if({$block})
			document.getElementById('{$bid}').addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		else
			window.addEventListener("scroll", function() {
				check_goto_top_box('id_cms_goto_{$nsp_name}_box');
				}); // function
		}); // function
</script>

EOTANCH;

			} // if
		return $text;
		} // get_admin_scroll2pageTop()

	public static function get_social_media($location) {
		if(!defined('PL_CMS_SOCIALMEDIA_SM_LOCATION')) return false;
		if(PL_CMS_SOCIALMEDIA_SM_LOCATION != $location) return false;
		// we have social media
		$text = Ccms_socialmedia_plugin::generate('SM',$location);
		return $text;
		} // get_social_media()

	public static function output_noscript_warning() {
		echo '	<noscript>'  . PHP_EOL .
			'		<span class="cms_msg_warning">'  . PHP_EOL .
			'			Detected that your browser\'s JavaScript maybe disabled.<br>'  . PHP_EOL .
			'			You need JavaScript enabled and functional in your browser to utilize the functionality of this website.'  . PHP_EOL .
			'		</span>'  . PHP_EOL .
			'	</noscript>' . PHP_EOL;
		} // output_noscript_warning()

	public static function output_link_or_tool_text($uri, $title, $https = false, $extra_styles = false) {
		// echo Ccms::get_admin_scroll2pageTop();
		// outside a page_body	$id_frame = (self::$cms_left_column ? (self::$cms_right_column ? 'cms_link_frame_wlrc':'cms_link_frame_wlc'):'cms_link_frame_nolc');
		$id_frame = 'cms_link_frame';	// inside a page body (no margins needed)
		$parts = parse_url($uri);
		if(!empty($parts['scheme'])) {
			if((self::is_ssl_inuse()) && ($parts['scheme'] != 'https')) {	// mixed prorocols, not allowed
				self::addAdminMsg('Mixed iframe protocols, set to HTTPS for: ' . $uri, 'warn');
				$url = preg_replace('/^http:/','https:',$uri);
				} // if
			else if((!self::is_ssl_inuse()) && ($parts['scheme'] != 'http')) {	// mixed prorocols, not allowed (??)
				self::addAdminMsg('Mixed iframe protocols, set to HTTP for: ' . $uri, 'warn');
				$url = preg_replace('/^https:/','http:',$uri);	// @TODO may not work on all browsers
				} // if
			else $url = $uri;	// let it go
			} // if
		else {
			if($https) {
				$url = CMS_SSL_URL . $uri;
				} // if
			else $url = self::get_base_url(true) . $uri;
			} // else
		// echo '<div id="lm_link_frame"' .
			(!empty($title) ? ' title="' . $title . '"':'') .
			' class="' . ((self::is_tablet()) ? 'link_frame_tablet':'link_frame_moz') . '"' .
			(!empty($extra_styles) ? ' style="' . $extra_styles . '"':'') . '>' . PHP_EOL;
		self::output_noscript_warning();
		echo '		<iframe src="' . $url . '"' . (!empty($title) ? ' title="' . $title . '"':'') . ' class="tools ' . ((self::is_tiny()) ? 'iframe_tablet':'iframe_moz') . '" id="' . $id_frame . '" ' .
			(!empty($extra_styles) ? ' style="' . $extra_styles . '"':'') .
			' scrolling="auto"' .
			// (!self::use_block_html() ? ' onload="this.style.height=(this.contentWindow.document.body.scrollHeight+20)+\'px\';"':'') .
			'>' . PHP_EOL;
		echo '			<p>Your browser does not support iframes. <a href="' . urlencode($url) . '">Click to show</a></p>' . PHP_EOL;
		echo '		</iframe>' . PHP_EOL;
		// echo '</div>' . PHP_EOL;
		self::reset_session_actions();
		} // output_link_or_tool_text()

	public static function output_iframe_site_text($uri, $title, $https = false) {
		// echo Ccms::get_admin_scroll2pageTop();
		$id_frame = 'cms_site_frame';	// inside a page body (no margins needed)
		$parts = parse_url($uri);
		if(!empty($parts['scheme'])) {
			$url = $uri;	// let it go
			} // if
		else {
			if($https) {
				$url = CMS_SSL_URL . $uri;
				} // if
			else $url = self::get_base_url(true) . $uri;
			} // else

		//echo '<div id="lm_link_frame">' . PHP_EOL;
		echo '		<iframe src="' . urlencode($url) . '"' . (!empty($title) ? ' title="' . $title . '"':'') . ' class="iframe_moz" id="' . $id_frame . '" scrolling="auto">' . PHP_EOL;
		echo '			<p>Your browser does not support iframes. <a href="' . urlencode($url) . '">Click to show</a></p>' . PHP_EOL;
		echo '		</iframe>' . PHP_EOL;
		//echo '</div>' . PHP_EOL;
		self::reset_session_actions();
		} // output_iframe_site_text()

	public static function output_file_body_text($inc_file, $capture = false) {
		if($capture) ob_start();
		if(preg_match('/\.(md|txt|info)$/i',$inc_file)) {
			echo Ccms_media_conv_plugin::get_text_file2html($inc_file);
			} // if
		else {
			include($inc_file);
			} // else
		if($capture) return ob_get_clean();
		return true;
		} // output_file_body_text()

	public static function output_body_core($body) {
		$filename = false;
		if((Ccms_vfs::is_vfs()) &&	// check for sub file includes
			($vfs_url = Ccms_vfs::get_vfs_url()) &&
			($vfs_name = Ccms_vfs::get_vfs_name()) &&
			($vfs_dest = Ccms_vfs::get_vfs_dest()) &&
			(!empty($vfs_url)) && (!empty($body['cms_body_dir'])) &&
			(!empty($body['cms_body_virtual_name'])) &&
			($body['cms_body_virtual_name'] == $vfs_name)) {
			$filename = APPS_FS_DIR . $body['cms_body_dir'] . '/' . $vfs_url;
			} // if
		else if(!empty($body['filepath'])) {
			$filename = $body['filepath'];
			} // else if
		else {
			self::addAdminMsg('Failed to find body file. Id: ' . self::$cms_body_id . ', Name: ' . self::$cms_body_name);
			return false;	//
			} // else
		if(is_readable($filename)) {
			if(!self::is_full_body_view()) self::page_start_comment($filename);
			if($body['cms_body_cached'] > 0) {
				Ccms_content_cache::cache_content($filename, false, true);
				} // if
			else {
				if($langs = Ccms_language::get_body_lang_trans_codes($filename,$body)) {	// returns true if translation required
					ob_start();
					} // if
				if(preg_match('/\.htm$|\.html$/i',$filename)) {
					echo file_get_contents($filename);
					} // else
				else {
					include $filename;
					} // else
				if($langs) {
					echo Ccms_language::translate_body_html(ob_get_clean(),$langs);
					} // if
				} // else
			if(!self::is_full_body_view()) self::page_end_comment($filename);
			} // if
		else {
			self::addAdminMsg('Cannot read file: ' . $filename);
			return false;
			} // else
		return true;
		} // output_body_core()

	public static function get_inc_method_callback($inc_file_or_func_or_text) {
		$callable_name = false;
		if((is_callable($inc_file_or_func_or_text,true,$callable_name)) &&	// static methods and functions
			(!empty($callable_name)) &&
			(function_exists($callable_name))) return $callable_name;

		if(preg_match('/[ !?@]+/',$inc_file_or_func_or_text)) return false;	// not legal
		$cl_fn = preg_split('/::|->|\(|,|\)/',$inc_file_or_func_or_text);
		if(count($cl_fn) >= 2) {
			if((Ccms_autoloader::find_class($cl_fn[0])) &&
				(method_exists($cl_fn[0],$cl_fn[1]))) {
				$callback = $cl_fn[0] . '::' . $cl_fn[1];
				return $callback;
				} // if
			if((Ccms_autoloader::find_plugin($cl_fn[0])) &&
				(method_exists($cl_fn[0],$cl_fn[1]))) {
				$callback = $cl_fn[0] . '::' . $cl_fn[1];
				return $callback;
				} // if
			} // if
		return false;
		} // get_inc_method_callback()

	public static function output_include_body_text($inc_file_or_func_or_text,
			$more_globals_ary = '',$inc_top_msgs = true, $inc_bot_msgs = true,
			$is_common_content = false, $cacheit = false) {
		if(Ccms_base::is_page_done()) return;
		Ccms_base::is_page_done(true);
		if(is_array($inc_file_or_func_or_text)) {	// extract vars
			$params = $inc_file_or_func_or_text;
			$inc_file_or_func_or_text = false;
			foreach($params as $n =>&$v) $$n = $v;
			} // if
		if(!empty($more_globals_ary)) {
			foreach($more_globals_ary as $g) {
				global $$g;
				} // foreach
			} // if
		if(!self::is_ajax()) {	// no positioning in ajax responses
			self::output_noscript_warning();
			if(!self::is_full_body_view()) {
				echo PHP_EOL;
				if($inc_top_msgs) echo self::getMsgsStack();
				} // if
			}	// if

		if(!empty($inc_file_or_func_or_text)) {
			if(is_readable($inc_file_or_func_or_text)) {
				if($cacheit) {
					Ccms_content_cache::cache_content($inc_file_or_func_or_text,$is_common_content,$cacheit);
					} // if
				else self::output_file_body_text ($inc_file_or_func_or_text);
				if(!self::is_full_body_view()) {
					$smtxt = self::get_social_media('center_left');
					if(!empty($smtxt)) echo $smtxt . PHP_EOL;
					$smtxt = self::get_social_media('center_right');
					if(!empty($smtxt)) echo $smtxt . PHP_EOL;
					} // if
				} // if
			else if($callback = self::get_inc_method_callback ($inc_file_or_func_or_text)) {
				call_user_func($callback);
				if(!self::is_full_body_view()) {
					$smtxt = self::get_social_media('center_left');
					if(!empty($smtxt)) echo $smtxt . PHP_EOL;
					$smtxt = self::get_social_media('center_right');
					if(!empty($smtxt)) echo $smtxt . PHP_EOL;
					} // if
				} // else if
			else echo $inc_file_or_func_or_text;
			} // if
		else {
			self::addAdminMsg('Missing file or function: "' . $inc_file_or_func_or_text . '"');
			if(self::is_debug()) {
				$stack = debug_backtrace();
				if(!empty($stack)) {
					self::log_info_msg('Call stack: ' . PHP_EOL . print_r($stack,true));
					} // if
				} // if
			} // else

		if(!self::is_ajax()) {	// no positioning in ajax responses
			if(!self::is_full_body_view()) {
				if($inc_bot_msgs) echo self::getMsgsStack();
				} // if
			echo PHP_EOL;
			self::reset_session_actions();
			} // if
		} // output_include_body_text()

	public static function output_include_legal_text($inc_file,$h1) {
		if(!self::is_ajax()) {	// no positioning in ajax responses
			self::output_noscript_warning();
			}	// if
		if(Ccms_base::is_page_done()) return;
		Ccms_base::is_page_done(true);
		if(!empty($h1)) echo PHP_EOL . '<h1 class="page_body">' . $h1 . '</h1>' . PHP_EOL;
		echo PHP_EOL . '		<div class="page_body cms_legal">' . PHP_EOL;
		if((!is_dir($inc_file)) && (is_readable($inc_file))) {
			if(preg_match('/\.(md|txt)$/i',$inc_file))
				echo Ccms_media_conv_plugin::get_text_file2html($inc_file);
			else include($inc_file);
			} // if
//		else if($callback = self::get_inc_method_callback ($inc_file)) {
//			call_user_func($callback);
//			} // if
		else {
			self::addMsg('Missing legal file: "' . $inc_file . '"');
			} // else

		echo PHP_EOL . '		</div>' . PHP_EOL;
		if(!self::is_ajax()) {	// no positioning in ajax responses
			} // if
		} // output_include_legal_text()

	public static function get_header_tools_pdb_text($outer = true) {
		$text = '';
		if((!self::$cms_header_tools_sent) &&
			(self::get_cms_action() != 'get_eula') &&
			(Ccms::get_tool_cnt() > 0)) {
			$cms_tools = self::get_tools_menu('left');
			if(!empty($cms_tools)) {
				if($outer) {
					$text .= Ccms_drop_box::hover_block('Tools',$cms_tools);
					} // if
				else {
					$text .= Ccms_drop_box::hover_block('Tools',$cms_tools);
					} // else
				} // if
			self::$cms_header_tools_sent = !empty($text);
			} // if
		return $text;
		} // get_header_tools_pdb_text()

	public static function get_header_abmin_pdb_text($outer = true) {
		$text = '';
		if((self::is_cms_group_manager()) &&
			(self::get_cms_action() != 'get_eula')) {
			$admin = Ccms::get_admin_menu('left');
			if(!empty($admin)) {
				if($outer) {
					$text .= Ccms_drop_box::hover_block('Admin',$admin);
					} // if
				else {
					$text .= Ccms_drop_box::hover_block('Admin',$admin);
					} // else
				} // if
			self::$cms_header_admin_sent = !empty($text);
			} // if
		return $text;
		} // get_header_abmin_pdb_text()

	public static function get_header_menu_pdb_text($outer = true) {
		$text = '';
		if((!self::$cms_header_menu_sent) &&
			(self::get_cms_action() != 'get_eula') &&
			(Ccms::get_body_cnt() > 0)) {
			$cms_bodies = Ccms_apps::get_apps_menus('left');
			if(!empty($cms_bodies)) {
				if($outer) {
					$text .= Ccms_drop_box::hover_block('Menu',$cms_bodies);
					} // if
				else {
					$text .= Ccms_drop_box::hover_block('Main Menu',$cms_bodies);
					} // else
				} // if
			self::$cms_header_menu_sent = !empty($text);
			} // if
		return $text;
		} // get_header_menu_pdb_text()

	public static function get_header_admin_tools_pdb_text() {
		$text = '' . PHP_EOL;
		if(self::is_drop_down_menus_in_header()) {
			$text .= PHP_EOL;
			$text .= '	<div class="top_menus">' . PHP_EOL;
			$text .= '		<ul class="top_menus">' . PHP_EOL;

			if(self::is_drop_down_menu_apps_in_header())
				$text .= '			<li class="top_menus">' . self::get_header_menu_pdb_text() . '</li>';

			if(self::is_drop_down_menu_tools_in_header())
				$text .= '			<li class="top_menus">' . self::get_header_tools_pdb_text() . '</li>';

			if(self::is_drop_down_menu_admin_in_header())
				$text .= '			<li class="top_menus">' . self::get_header_abmin_pdb_text() . '</li>';

			$text .= '		</ul>' . PHP_EOL;
			$text .= '	</div>' . PHP_EOL;
			} //if
		return $text;
		} // get_header_admin_tools_pdb_text()

	public static function get_JS_calendar_resource($prn_flg = true) {
		// output links for calendar
		$text = array();
		if(!self::$cms_calendar_sent) {
			self::$cms_calendar_sent = true;
			$text[] = '		<link rel="stylesheet" type="text/css" href="' . Ccms_minify_plugin::minify_css(CMS_WS_LIB_DIR . 'calendar/calendar.css') . '">';
			$text[] = '		<script type="text/javascript" src="' . Ccms_minify_plugin::minify_js(CMS_WS_LIB_DIR . 'calendar/calendar.js') . '"></script>';
			} // if
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // get_JS_calendar_resource()

	private static function set_JS_calendar_elem(&$text,$id,&$date_fmt_cntl) {
		$text[] = 'Ccalendar.set(' . $id . ',' . $date_fmt_cntl . ');';
		if(!isset(self::$cms_calendar_ids[$id])) self::$cms_calendar_ids[] = $id;
		} // set_JS_calendar_elem()

	public static function set_JS_calendar_init($ids,$date_fmt_cntl = 'y-m-d',$prn_flg = true) {
		// $ids can be an array of values or a single value
		$text = array();
		if(!empty($ids)) {
			if(!self::$cms_calendar_ids) self::$cms_calendar_ids = array();
			if(!is_array($ids)) self::set_JS_calendar_elem ($text, $ids, $date_fmt_cntl);	// single id string
			else { // an array of id strings
				foreach($ids as &$id) self::set_JS_calendar_elem ($text, $id, $date_fmt_cntl);
				} // else
			} // if
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // set_JS_calendar_init()

	public static function get_JS_colour_picker_resource($prn_flg = true) {
		// output links for calendar
		$text = array();
// @TODO replace colour picker
//		if(!self::$cms_rgbcp_sent) {
//			self::$cms_rgbcp_sent = true;
//			$text[] = '		<link rel="stylesheet" type="text/css" href="' . Ccms_minify_plugin::minify_css(CMS_WS_CSS_DIR . 'rgbcp.css') . '">';
//			$text[] = '		<script type="text/javascript" src="' . Ccms_minify_plugin::minify_js(CMS_WS_JS_DIR . 'rgbcp.js') . '"></script>';
//			} // if
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // get_JS_colour_picker_resource()

	public static function set_JS_colour_picker_onclick($id) {
		// @TODO not ready debugged
		$text = '';	// onclick="cPicker.create_colour_picker(\'' . $id . '\');"';
		return $text;
		} // set_JS_colour_picker_onclick()

	public static function set_JS_password_resource($prn_flg = true) {
		if((self::$cms_password_resource_done) || (Ccms::is_ajax())) return '';
		self::$cms_password_resource_done = true;
		if((CMS_S_REVEAL_PASSWORD_BOOL) || (CMS_S_SHOW_PASSWORD_BOOL)) {
			$reveal = (CMS_S_REVEAL_PASSWORD_BOOL ? 'true':'false');
			$text =<<< EOTJS

			<script type="text/javascript">
				if(typeof togglePassWD != "function") {

					function mouseoverPassWD(ev,chkcb,id,id_img) {
						var obj = document.getElementById(id);
						setInpType(obj,'text',chkcb,id_img);
						} // mouseoverPassWD()

					function mouseoutPassWD(ev,chkcb,id,id_img) {
						var obj = document.getElementById(id);
						setInpType(obj,'password',chkcb,id_img);
						} // mouseoutPassWD()

					function togglePassWD(ev,chkcb,id,id_img) {
						var obj = document.getElementById(id);
						var val = obj.value;
						if(!chkcb.type) {
							if(obj.type == 'password') setInpType(obj,'text',chkcb,id_img);
							else setInpType(obj,'password',chkcb,id_img);
							} // if
						else if({$reveal}) chkcb.checked = false;
						else {
							if(chkcb.checked) setInpType(obj,'text',id_img);
							else setInpType(obj,'password',id_img);
							} // else
						} // togglePassWD()

					function setInpType(obj, new_type,chkcb,id_img) {
						var new_obj = document.createElement('input');
						new_obj.type = new_type;
						if(obj.size) new_obj.size = obj.size;
						if(obj.value) new_obj.value = obj.value;
						if(obj.name) new_obj.name = obj.name;
						if(obj.placeholder) new_obj.placeholder = obj.placeholder;
						if(obj.id) new_obj.id = obj.id;
						if(obj.className) new_obj.className = obj.className;
						if(obj.style) new_obj.style.width = obj.style.width;
						obj.parentNode.replaceChild(new_obj,obj);
						var img = document.getElementById(id_img);
						if(img) {
							var src = img.src;
							if(new_obj.type != 'password')
								img.src = src.replace('closed','open');
							else
								img.src = src.replace('open','closed');
							console.log(img.src);
							} // if
						return new_obj;
						} // setInpType();

					} // if
			</script>

EOTJS;
			if($prn_flg) echo $text;
			return $text;
			} // if
		return '';
		} // set_JS_password_resource()

	public static function set_JS_password_input($name_or_ary,$title = '',$value = '',$chk_strength = false,$allow_autocomplete = false,$prn_flg = true,$extras = '') {
		static $idx = 0;
		if(is_array($name_or_ary)) {
			foreach($name_or_ary as $k => $v) $$k = $v;			
			} // if
		else $name = $name_or_ary;
		
		$mh_id = 'id_' . $name . $idx++;	// incr id of form, may have more than one form
		return self::set_JS_password_input_by_id($mh_id,$name, $title, $value, $chk_strength, $allow_autocomplete, $prn_flg,$extras);
		} // set_JS_password_input()

	public static function set_JS_password_input_by_id($mh_id,$name,$title = '',$value = '',$chk_strength = false,$allow_autocomplete = false,$prn_flg = true,$extras = '') {
		$text = array();
		$mh_id_cb = $mh_id . '_cb';
		$mh_id_img = $mh_id . '_img';
		$text[] = self::set_JS_password_resource(false);
		$text[] = '		<div style="white-space: nowrap">';
		// $text[] = '		<input type="hidden" id="id_username" name="username" placeholder="Username" value="' . Ccms_auth::get_logged_in_username() . '">';	// stop popup asking user for password
		if(!$allow_autocomplete) $text[] = '		<input type="password" style="display:none; width: unset;"> <!--Stop autocomplete-->';
		if($chk_strength) {
			$pwd_chks = self::get_password_chk_regex();
			if(!empty($title)) {
				$tit = $title . (!empty($pwd_chks['title']) ? '\n' . $pwd_chks['title']:'');
				} // if
			else $tit = $pwd_chks['title'];
			$text[] = '		<input class="std" style="width: unset;" type="password" placeholder="Password" pattern="' . $pwd_chks['pattern'] . '" id="' . $mh_id . '" name="' . $name . '" value="' . $value . '" title="' . $tit . '"';
			} // if
		else $text[] = '		<input class="std" style="display: inline-block; width: unset;" type="password" placeholder="Password" id="' . $mh_id . '" name="' . $name . '" value="' . $value . '"';
		if(!empty($extras)) $text[] = $extras;
		if(!$allow_autocomplete) $text[] = '			autocomplete="new-password"';
		if(!empty($title)) $text[] = '			title="' . $title . '"';
		$text[] = '		/>';
		if(CMS_S_SHOW_PASSWORD_BOOL) {
			$text[] = '		<span id="' . $mh_id_cb . '"';
			if(CMS_S_REVEAL_PASSWORD_BOOL) {
				$text[] = '			onmouseover="mouseoverPassWD(event,this,\'' . $mh_id . '\',\'' . $mh_id_img . '\');"';
				$text[] = '			onmouseout="mouseoutPassWD(event,this,\'' . $mh_id . '\',\'' . $mh_id_img . '\');"';
				// $text[] = '			title="reveal"';
				// $text[] = '			disabled="ON"';
				$text[] = '>';
				} // if
			else {
				$text[] = '		onclick="togglePassWD(event,this,\'' . $mh_id . '\',\'' . $mh_id_img . '\')"';
				// $text[] = '		onclick="document.getElementById(\'' . $mh_id . '\').type = (this.checked ? \'text\' : \'password\');"';
				// $text[] = '			title="show"';
				$text[] = '>';
				} // else
			$text[] = '			<img name="eye_img" class="eye_img" id="' . $mh_id_img . '"';
			$text[] = '				src="' . CMS_WS_ICONS_DIR . 'eye_closed.png"/></span>';
			} // if
		$text[] = '		</div>';
		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // set_JS_password_input_by_id()

	protected static function get_clientMeta_sender() {
		if(!CMS_C_CLIENTMETA_ALLOW) return '';
		if((self::is_ssl_required()) && (!self::is_ssl_inuse())) return '';

		$deb_ms = (int)CMS_C_CLIENTMETA_MIN_MS;
		if($deb_ms < 200) $deb_ms = 200;

		$text = <<< EOTMD

		<script type="text/javascript">
			var cmsMetadata_deb_ms = {$deb_ms};	// don't be hasty
		</script>

EOTMD;
		$text .= self::get_head_JS_url(CMS_WS_DIR . 'cms_metadata.js',false);
		return $text;
		} // get_clientMeta_sender()

	public static function get_return2search_link($found = false) {
		// if(self::get_or_post('cancel')) return;
		if($found) {
			echo '&nbsp;&nbsp;<span class="cms_msg_success"><img alt="success" src="' . self::get_msg_icon('success.gif','') . '">Found here</span>';
			} // if
		echo Ccms_search::get_form_search_inputs();
		} // get_return2search_link()
		
	public static function get_link_html($link) {
		$text = '';
		if(empty($link)) return '&nbsp;';
		if((Ccms_auth::is_cms_admin_user()) && (LM_C_SHOW_CONF_LINKS)) {
			$text .= '<a href="index.php?cms_action=cms_edit_links&link_edit_id=' . $link['lm_link_id'] . '&lm_link_qk_anchor=_null&cms_return_action=lm_show_links"';
			$text .= ' title="Configure link,">';
			$text .= '<img class="lm_cog" src="' . CMS_WS_ICONS_DIR . 'cog.gif" alt="cog"/>';
			$text .= '</a>' . PHP_EOL;
			} // if
		$url_parts = parse_url($link['lm_link_url']);
		$url = '';

		if((empty($url_parts['scheme'])) &&
			(empty($url_parts['host'])) &&
			($link['lm_link_ssl']))
			$url .= self::get_base_url(true);

		if($link['lm_link_new_page']) {
			$url .= $link['lm_link_url'] . ((int)$link['lm_link_add_name2url'] ? '?name=' . trim($link['lm_link_name']):'');
			} // if
		else {
			$url .= 'index.php?cms_action=link&link_id=' . (int)$link['lm_link_id'] . '&name=' . urlencode(trim($link['lm_link_name']));
			} // else

		if($link['lm_link_new_page']) {
			$text .= '<a href="' . self::urlEncode3986($url) . '"';
			$text .= ' target="_blank"';
			$text .= ' title="' . (!empty($link['lm_link_title']) ? strip_tags($link['lm_link_title']) . PHP_EOL:'') . (LM_C_SHOWINNEWTAB ? '(in a new tab)':'') . '"';
			} // if
		else {
			$text .= '<a href="' . self::urlEncode3986($url) . '"';
			if(!empty($link['lm_link_title'])) $text .= ' title="' . strip_tags($link['lm_link_title']) . '"';
			} // else

		$text .= ' class="link_body">';

		if(!empty($link['lm_link_image_url'])) {
			$cCMS_C = new Ccms_config_funcs();
			$text .= $cCMS_C->show_image($link['lm_link_image_url'],ETC_WS_IMAGES_DIR,CMS_C_SMALL_IMAGE_HEIGHT);
			$text .= '<br>';
			} // if
//		if(!empty($link['lm_link_icon_url'])) {
//			if(!isset($cCMS_C)) $cCMS_C = new Ccms_config_funcs();
//			$text .= $cCMS_C->show_image($link['lm_link_icon_url'],ETC_WS_ICONS_DIR,CMS_C_SMALL_IMAGE_HEIGHT);
//			$text .= '<br>';
//			} // if
		$text .= trim($link['lm_link_name']);
		$text .= '</a>';
		if((LM_C_SHOW_LINK_DESCRIPTION) &&
			(!empty($link['lm_link_description']))) $text .= '<br><small>' . $link['lm_link_description'] . '</small>';
		if((!empty($link['lm_link_comments'])) && (Ccms_auth::is_cms_admin_user())) {
			$text .= '&nbsp;';
			$text .= self::getSimpleNotesDD($link['lm_link_comments'],'Comments:');
			} // if
		return $text;
		} // get_link_html()
		
	public static function get_textarea_input($name,$value,$id = false,$params = false, $max = self::TEXT_LEN_MAX,$cntr = true) {
		if(empty($id)) $id = 'id_' . $name;
		if(empty($params)) $params = ' rows="5" style="width: 98%;"';
		$val = htmlentities($value);
		$text = '';
		$text .= '<textarea id="' . $id . '" name="' . $name . '" maxlength="' . $max . '"';
		if($cntr)
			$text .= ' oninput="cms_input_char_cnt(this,event,\'' . $id . '\',\'' . $max . '\')"';
		$text .= ' ' . $params;
		$text .=  '>' . $val . '</textarea>';
		if($cntr)
			$text .= PHP_EOL . '<span class="text_cnt" id="' . $id . '_cnt">' . strlen($val) . '/' . $max . '</span>';		
		return $text . PHP_EOL; 
		} // get_textarea_input()

	public static function get_live_search_input($name,$value,$ajax_uri = '',$title = '',$class = '',$callback = false) {
		// made from "https://www.w3schools.com/php/php_ajax_livesearch.asp"

		$id = 'id_' . $name;
		if(!empty($callback)) {
			self::set_cms_sess_var($callback,'callbacks','cms_livesearch',$name,'func');
			$ajax_uri = 'cms/cms_ajax.php?ajax=cms_livesearch&name=' . urlencode($name);
			} // if
		else if(empty($ajax_uri)){
			Ccms::addMsg(__CLASS__ . '::' . __METHOD__ . ' has no ajax_uri for "' . $name . '".');
			return '';
			} // else
		$pre = $name . '_';
		if(!empty($title)) $title = ' title="' . $title . '"';
		$text =<<< EOT_GLSI
		<script type="text/javascript">'
			function {$pre}showResult(str) {
				if (str.length==0) {
					document.getElementById("{$id}").innerHTML="";
					document.getElementById("{$id}").style.border="0px";
					return;
				} // if
				if (window.XMLHttpRequest) {
					// code for IE7+, Firefox, Chrome, Opera, Safari
					xmlhttp=new XMLHttpRequest();
					} // if
				else {	// code for IE6, IE5
					xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				} // else
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("{$id}").innerHTML=this.responseText;
						document.getElementById("{$id}").style.border="1px solid #A5ACB2";
						} // if
					} // if
				var url = "{$ajax_uri}" + "&q=" + encodeURI(str);	// assume ajax_url already has steering (not need ?)
				xmlhttp.open("GET",url,true);
				xmlhttp.send();
				} // {$pre}showResult()

			function {$pre}selectResult(obj) {
				var new_value = document.getElementById("{$id}").innerHTML;
				document.getElementById("{$id}_inp").innerHTML = new_value;
				} // {$pre}selectResult()

		</script>

		<div class="cms_live_search_input {$class}">
			<input id="{$id}_inp" type="text" oninput="{$pre}showResult(this.value)" value="${value}" {$title}>
			<div id="{$id}" onclick="{$pre}selectResult(this)"></div>
		</div>

EOT_GLSI;

		return $text;
		} // get_live_search_input()

	public static function get_cookie_banner($class = '') {

		switch(CMS_C_COOKIE_BANNER_POSITION) {
		case 'top':
			$b_class = 'cookie_banner_top';
			break;
		case 'bottom':
			$b_class = 'cookie_banner_bottom';
			break;
		default:
			return '';	// no banner
			} // switch

		// don't pester user
		$exDays = CMS_C_COOKIE_BANNER_TTL;
		$cvalue = ((int)$exDays * 24 * 3600);	// seconds
		if($close_time = Ccms_auth::get_user_json_data_key('cms_user_cookie_banner_time')) {
			$next_time = $close_time + $cvalue;
			if((int)$next_time > time()) return '';
			} // if
		else {
			$bc_key = 'cookie_banner_time';
			if((isset($_COOKIE[$bc_key])) &&
				($bc_time = (int)$_COOKIE[$bc_key])) {
				if((int)$bc_time < $cvalue) return '';	// no banner
				} // if
			} // else

		$c_file = DOCROOT_FS_BASE_DIR . CMS_C_COOKIE_BANNER_LINK;
		if(!@file_exists($c_file)) {
			$c_file = ETC_FS_EXT_INCLUDES_DIR . CMS_C_COOKIE_BANNER_LINK;
			if(!@file_exists($c_file)) return '';
			} // if
		if(preg_match('/.*\.(html|htm)$/i',$c_file)) $msg = file_get_contents($c_file);
		else {
			ob_start();
			include($c_file);
			$msg = ob_get_clean();
			} // else

		$text = '';
		$text .= <<< EOTXT

		<style>
		div.cookie_banner_top,
		div.cookie_banner_bottom {
			display: block;
			background-color: white;
			color: black;
			border: 1px solid grey;
			font-size: inherit;
			opacity: 1;
			transition: opacity 0.5s;
			text-align: center;
			z-index: +1000;
			width: 100%;
			}
		div.cookie_banner_top {
			position: fixed;
			top: 0px;
			}
		div.cookie_banner_bottom {
			position: fixed;
			bottom: 0px;
			}
		span.cookie_banner_close {
			float: right;
			cursor: pointer;
			padding: 0px 7px;
			font-size: 2em;
			}
		</style>

		<script type="text/javascript">
			function close_cookie_banner(obj) {
				var banner = obj.parentElement;
				if(banner) banner.style.display = 'none';
//				Ccms_cookie.set('{$bc_key}','{$value}', {$exDays});

				var xmlhttp = false;
				if (window.XMLHttpRequest) {
					// code for IE7+, Firefox, Chrome, Opera, Safari
					xmlhttp = new XMLHttpRequest();
					} // if
				else {	// code for IE6, IE5
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} // else
				if(!xmlhttp) return;
				var url = 'cms/cms_ajax.php?ajax=cms_cookie_banner_closed';
				xmlhttp.open("GET",url,true);
				xmlhttp.send();
				} // close_cookie_banner()
		</script>

		<div class="{$b_class} {$class} ">
			<span class="cookie_banner_close" onclick="close_cookie_banner(this);" title="Close">&times;</span>
			<div style="padding: 5px 0px;">
				{$msg}
			</div>
		</div>

EOTXT;

		return $text;
		} // get_cookie_banner()

	public static function hilite_filter(&$filter,&$text,$cc_flg = false) {
		$txt = strip_tags($text);
		if(empty($filter)) {	// show all
			if($cc_flg) return '<span onclick="cms_copyElemToClipboard(event,this);">'. $txt . '</span>';
			return $txt;
			} // if
		if(empty($txt)) return '';
		for($i = 0; $i < count($filter); $i++) {
			$f = &$filter[$i];
			if(empty($f)) continue;
			$pat = '/(' . $f . ')/i';
			$txt = preg_replace($pat, '<b style="color: red;">$0</b>', $txt);
			} // foeach
		if($cc_flg) return '<span onclick="cms_copyElemToClipboard(event,this);">'. $txt . '</span>';
		return $txt;
		} // hilite_filter()

	private static function get_tree_view_recurs(&$tree,&$text,$filter,$depth = 1) {

		foreach($tree as $k => &$v) {
			if(is_array($v)) {
				$text .= str_repeat("\t",$depth) . '<li class="cms_tv">';
				$text .= '	<span class="cms_tv" onclick="cms_tv_toggle_ul(this);" title="Click to open">' . $k . ':</span>' . PHP_EOL;
				$text .= str_repeat("\t",$depth) . '	<ul class="cms_tv"' . (($depth > 2) ? ' style="display: none;"':'') . '>' . PHP_EOL;
				if(empty($v)) $text .= 'empty()';
				else {
					self::get_tree_view_recurs($tree[$k],$text,$filter,($depth + 2));
					} // if
				$text .= str_repeat("\t",$depth) . '	</ul>' . PHP_EOL;
				} // if
			else {
				switch(strtolower(gettype($v))) {
				case 'boolean':
					$vb = ($v ? 'true':'false');
					$vt = self::hilite_filter($filter,$vb);
					break;
				case 'integer':
				case 'double':
				case 'string':
				default:
					if(is_null($v)) {
						$vt = 'null';
						break;
						} // if
					$s = strval($v);	// for ref
					$vt = self::hilite_filter($filter,$s);
					break;
				case 'array':
					if(empty($v)) {
						$vt = 'empty';
						break;
						} // if
					$s = strval($v);	// for ref
					$vt = self::hilite_filter($filter,$s);
					break;
//				case 'object':
//				case 'resource':
//				case 'null':
//					$vt = '(' . gettype($v) . ')';
//					break;
					} // switch
				$kt = self::hilite_filter($filter,$k);
				$text .= str_repeat("\t",$depth) .
					'<li class="cms_tv"><span style="font-style: italic;">' . $kt . ':</span> ' .
					$vt . '</li>' . PHP_EOL;
				} // else
			} // foreach
			return $depth;
		} // get_tree_view_recurs()

	public static function get_tree_view($id,&$tree,$filter = false,$depth = 1) {
		// creates a simple tree view form an array
		$text = '';
		static $sty_done = false;
		if(!$sty_done) {
			$sty_done = true;
			$text .= <<< EOTSTY
				<style>
				ul.cms_tv, li.cms_tv {
					list-style-type: none;
					margin: 0;
					}
				span.cms_tv {
					font-weight: bold;
					font-style: italic;
					}
				span.cms_tv:hover {
					text-decoration: underline;
					font-size: 1.05em;
					}
				</style>

				<script type="text/javascript">
					function cms_tv_toggle_ul(obj) {
						if(!obj) return false;
						var parent = obj.parentNode;
						var ul = parent.getElementsByTagName("UL")[0];
						if(ul) {
							if(ul.style.display == 'none')
								ul.style.display = 'block';
							else ul.style.display = 'none';
							} // if
						return true;
						} // cms_tv_toggle_ul()
				</script>

EOTSTY;
			} // if

		$text .= '<ul class="cms_tv" id="cms_tv_' . $id . '">' .PHP_EOL;
		self::get_tree_view_recurs($tree,$text,$filter,$depth);
		$text .= '</ul>' .PHP_EOL;
		return $text;
		} // get_tree_view()

	public static function getFormSimpleDropPanel($label,&$form) {
		if(empty($form)) return '';	// no form
		$text = PHP_EOL;
		$text .= Ccms_drop_box::panel_block($label,$form);
		return $text . PHP_EOL;
		} // getFormSimpleDropPanel()

	public static function getSimpleNotesDD($text,$head,$inner_style = false) {
		$h_hd= (!empty($head) ? '<h4>' . $head . '</h4><br>':'');
		$in_styl = (!empty($inner_style) ? ' style="' . $inner_style . '"':'');
		$notes_img = CMS_WS_ICONS_DIR . 'notes.gif';
		$text = <<< EOTTXT

		<div class="cms_ddwn_outer">
			<span>
				<img class="cms_ddwn_img" src="{$notes_img}" alt="notes"/>
			</span>
			<div class="cms_ddwn_inner" {$in_styl}>
			{$h_hd}
			{$text}
			</div>
		</div>

EOTTXT;
		return $text;
		} // getSimpleNotesDD()

	public static function getAdminCommentHint($edit_type,$name = '') {
		$text = '';
		switch($edit_type) {
		case 'edit_config':
			$text .= 'Enter &quot;' . self::make_nice_name($name) . '&quot; administrator comments.';
			break;
		case 'edit_body':
		case 'edit_group':
		case 'edit_links':
		case 'edit_tools':
		case 'edit_sections':
		case 'edit_users':
			$text .= 'Enter &quot;' . self::make_nice_name($name) . ' &quot; administrator comments.';
			break;
		default:
			$text .= 'Enter administrator comments.';
			break;
			} // switch
		$text .= '<br>(Administrator only, not seen by user.)';
		return $text;
		} // getAdminCommentHint()

	public static function get_column_layout($column_mode = 'left_column',$column_class = 'left_container') {

		$flgs = array(
			'admin_menu_flg' => false,
			'tool_menu_flg' => false,
			'tools_items_flg' => false,
			'bodies_menu_flg' => false,
			'bodies_items_flg' => false,
			'item_cnt' => 0,
			);
		if(!CMS_C_ENABLE_CUSTOM_COLUMNS_LAYOUT) return $flgs;
		$non_menu_items = array();
		$col_layouts = self::chk_unserialize(CMS_C_CUSTOM_COLUMNS_LAYOUT);
		if(empty($col_layouts)) return $flgs;
		foreach($col_layouts as &$item) {
			if($item[$column_mode] != 'on') continue;
			if(is_array($item['uri'])) {
				$uri = $item['uri']['uri'];
				$name = $item['uri']['text'];
				} // if
			else {
				$uri = $item['uri'];
				$name = $item['name'];
				} // else
			$title = (!empty($item['title']) ? ' title="' . $item['title'] . '"':'');
			if(preg_match('/^menu=[\S]+$/',$uri)) {
				$menu = preg_replace('/^menu=([\S]+)$/','$1',$uri);
				switch($menu) {
				case 'admin':	// admin drop box
					if(!Ccms_base::is_cms_group_manager()) continue 2;
					$flgs['admin_menu_flg'] = true;
					echo '				<tr class="' . $column_class . '"><td class="' . $column_class . '">' . PHP_EOL;
					echo Ccms::get_admin_menu($column_mode);
					echo '					</td></tr>' . PHP_EOL;
					break;
				case 'tools':	// tools drop box
					if(Ccms::get_tool_cnt() <= 0) continue 2;
					$flgs['tool_menu_flg'] = true;
					echo '				<tr class="' . $column_class . '"><td class="' . $column_class . '">' . PHP_EOL;
					echo self::get_tools_menu($column_mode);
					echo '					</td></tr>' . PHP_EOL;
					break;
				case 'apps':	// apps drop box
					if(Ccms::get_body_cnt() <= 2) continue 2;
					$flgs['bodies_menu_flg'] = true;
					echo '				<tr class="' . $column_class . '"><td class="' . $column_class . '">' . PHP_EOL;
					echo Ccms_apps::get_apps_menus($column_mode);
					echo '					</td></tr>' . PHP_EOL;
					break;
				default:
					continue 2;
					break;
					} // switch
				} // if
			else {
				if(!empty($item['uri']['uri'])) $uri = $item['uri']['uri'];
				else if(!empty($item['uri'])) $uri = $item['uri'];
				else $uri = false;
				if(!empty($uri)) {
					if((!$flgs['bodies_menu_flg']) && (preg_match('/^id_(app|body)_[\d]+$|body=|app=/',$uri))) {
						$non_menu_items[] = $item;
						$flgs['bodies_items_flg'] = true;
						} // if
					else if((!$flgs['tool_menu_flg']) && (preg_match('/^id_tool_[\d]+$|tool=/',$uri))) {
						$non_menu_items[] = $item;
						$flgs['tools_items_flg'] = true;
						} // else if
					// else only full admin shown
					} // if
				} // else
			$flgs['item_cnt']++;
			} // foreach

		if(!empty($non_menu_items)) {	// show individually select items
			echo Ccms_apps::get_apps_menus($column_mode,$non_menu_items,true);
			} // if

		return $flgs;
		} // get_column_layout()

	public static function get_admin_menu($column_mode = 'left_column',$menu_name = 'Admin menu') {
		if(Ccms_auth::is_config_user()) {
			$config_menu = array(
				'role' => 'admin',
				'th' => array(
					'text' => Ccms_html::get_menu_icon_text(Ccms_auth::is_cms_admin_user() ? 'Admin':'Manage'),
					'title' => "Config and edit settings for " . strip_tags(CMS_PROJECT_NAME . ' ' . CMS_PROJECT_VERSION) . ".",
					),
				'td' => array(),
				);
			$config_items = Ccms_options::get_admin_config_items();	// add 'td's in display order
			foreach($config_items as &$item) {
				if(empty($item['allowed_now'])) continue;
				if(empty($item['func'])) {
					$config_menu['td'][] = $item;
					continue;
					} // if
				// submenus
				$func = $item['func'];
				if(self::is_static_callable($func))
					$func($config_menu,$column_mode);
				} // foreach

			self::$cms_admin_menu_output = true;
			$vm = new Ccms_generate_Vmenu('amenu','admin_pdb_container',$config_menu,true,true,32,$menu_name);
			return $vm->get_text();
			} // if
		return '';
		} // get_admin_menu()

	public static function get_tools_menu($column_mode = 'left_column',$menu_name = 'Tools menu', $db_only = true) {
		if(Ccms::get_tool_cnt() > 0) {
			$cms_tools_menu = array(
				'th' => array(
					'text' => Ccms_html::get_menu_icon_text('Tools'),
					'title' => "Tools for users. Tools are hard coded.",
					),
				'td' => array(),
				);
			// add 'td's in display order
			$cms_tools_items = Ccms_options::get_tools_menu_items();
			$cms_tools_items_allowed = array();

			foreach($cms_tools_items as &$item) {
				if(empty($item['allowed_now'])) continue;
				$cms_tools_items_allowed[] = $item;
				if(empty($item['func'])) {
					$cms_tools_menu['td'][] = $item;
					continue;
					} // if
				// submenus
				$func = $item['func'];
				if(self::is_static_callable($func))
					$func($cms_tools_menu,$column_mode);
				} // foreach
			if(empty($cms_tools_menu['td'][0])) return '';
			
			if((!$db_only) && (count($cms_tools_items_allowed) == 1) &&
				(count($cms_tools_items_allowed) == (count($cms_tools_menu['td'])))) {	// one item
				return $cms_tools_items_allowed[0];
				} // if

			self::$cms_tools_menu_output = true;
			$vm = new Ccms_generate_Vmenu('tmenu','tools_pdb_container',$cms_tools_menu,false,false,false,$menu_name);
			return $vm->get_text();
			} // if
		return '';
		} // get_tools_menu()

} // Ccms_html
