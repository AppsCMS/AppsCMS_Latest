<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_tool_install.php 3266 2023-03-10 10:55:33Z robert0609 $
 */

/**
 * Description of cms_tool_install
 *
 * Class to package, install and update tools
 *
 * @author robert0609
 */

class Ccms_tool_install extends Ccms_general {

	protected $op = false;
	protected $package_id = 0;
	protected $package = false;
	protected $package_file = false;
	protected $package_file_tree = false;
	protected $cZIP = false;
	protected $priv_objs = false;

	const PKG_INFO_JSON = 'package_info.json';
	const PRIVATE_OBJS_CHKS = 'nbproject,private,.settings,.project,.vscode';	// keep IDE settings out of package

	function __construct($op = 'install',$package_id = 0, $package = false) {
		if(!self::is_tool_pkg_ops_ok()) return;
		parent::__construct();
		$this->package_id = $package_id;
		$this->op = $op;
		$this->package = $package;

		switch($this->op) {
		case 'build_package':
			$this->package_localtool($this->package_id);
			break;
		case 'package':
			$this->get_package_form($this->package_id);
			break;
		case 'install_package':
			$this->install_localtool($this->package);
			break;
		case 'install':
			$this->get_install_form($this->package);
			break;
		default:
			self::get_error_return_text('Unknown install packager operation');
			return;
			} // switch
		} // __construct()

	function __destruct() {
		parent::__destruct();
		if(($this->cZIP) && ($this->cZIP->status))
			$this->cZIP->close();
		} // __destruct()

	// static methods
	public static function is_tool_pkg_ops_ok() {
		if(!@class_exists('ZipArchive')) return false;
		return true;
		} // is_tool_pkg_ops_ok()

	protected static function get_error_return_text($msg, $type = false) {
		self::addMsg($msg,$type);
		if($type) return;	// only errors
		// put up a return link
		echo '<p>' . $msg . '</p>' . PHP_EOL;
		echo '<a href="index.php?cms_action=cms_edit_tools">Close</a>' . PHP_EOL;
		} // get_error_return_text()

	public static function get_package_upload_file() {
		$destpath = VAR_FS_TEMP_DIR;
		if($filename = self::save_uploaded_file($destpath,'packageToUpload')) return $filename;
		return false;
		} // get_package_upload_file()

	// dynamic methods
	protected function add_package_json_to_zip() {
		$json = self::json_encode($this->package);
		$json = self::json_text_pretty($json);
		if(!$this->cZIP->addFromString(self::PKG_INFO_JSON,$json)) {
			$error = $this->cZIP->getStatusString();
			return false;
			} // if
		return true;
		} // add_package_json_to_zip()

	private function is_sorc_ok($dir_file) {
		//		if((is_dir($dir_file)) & (!self::is_dir_usable($dir_file))) return false;
		//		else if(!self::is_file_usable($dir_file)) return false;
		if(!$this->priv_objs) $this->priv_objs = explode(',',self::PRIVATE_OBJS_CHKS);
		foreach($this->priv_objs as $o) {
			$pat = '/' . preg_quote($o,'. \ + * ? [ ^ ] $ ( ) { } = ! < > | : - #') . '/i';
			if(preg_match($pat,$dir_file))
				return false;
			} // foreach
		return true;
		} // is_sorc_ok()

	protected function add_file_to_zip($dir,$file) {
		$path = (empty($dir) ? $file:self::clean_path($dir . '/' . $file)); // dont make absolute
		if(in_array($path,$this->package_file_tree)) return true;	// already there
		$this->package_file_tree[] = $path;
		if((!empty($dir)) && (!in_array($dir,$this->package_file_tree))) {
			$this->package_file_tree[] = $dir;
			$this->cZIP->addEmptyDir($dir);
			} // if
		if(!$this->cZIP->addFile(
			self::clean_path(DOCROOT_FS_BASE_DIR . $path),
			self::clean_path($path))) {
			$error = $this->cZIP->getStatusString();
			return false;
			} // if
		return true;
		} // add_file_to_zip()

	protected function add_dir_to_zip($dir,$exclude = array()) {
		if(empty($dir)) return false;
		if(!is_dir(DOCROOT_FS_BASE_DIR . $dir)) return false;
		if(in_array($dir,$this->package_file_tree)) return true;	// already there
		$this->package_file_tree[] = $dir;
		$this->cZIP->addEmptyDir($dir);
		if(in_array(preg_replace('/^.*\//','',$dir),$exclude)) return true;	// dir saved
		$files = opendir(DOCROOT_FS_BASE_DIR . $dir);
		while($file = readdir($files)) {
			if(preg_match(CMS_DONT_ZIP_PATH_PATTERN,$file)) continue;
			// need hiiden files	if(!self::is_dir_usable($file)) continue;
			$path = self::clean_path($dir . '/' . $file);
			if(is_link(DOCROOT_FS_BASE_DIR . $path)) continue;
			else if(is_dir(DOCROOT_FS_BASE_DIR . $path)) {
				if(!$this->is_sorc_ok($file)) continue;
				$this->add_dir_to_zip($path,$exclude);
				} // if
			else if(is_file(DOCROOT_FS_BASE_DIR . $path)) {
				if(!$this->is_sorc_ok($file)) continue;
				if(in_array($file,$exclude)) continue;
				$this->add_file_to_zip($dir, $file);
				} // if
	 		} // while
		return true;
		} // add_dir_to_zip()

	private function add_associated_files($tool) {
		// used to collect images, icons, etc. in directories outside the local tools dir.
		$tool_files2chk = array(
			"cms_tool_icon_url",
			"cms_tool_image_url",
			"cms_tool_terms_url",
			"cms_tool_acknowledgment_url",
			"cms_tool_licence_url",
			"cms_tool_release_notes_url",
			"cms_tool_readme_url",
			);
		if((!isset($this->package['assoc'])) ||
			(!is_array($this->package['assoc'])))
			$this->package['assoc'] = array();
		$tool_dir = LOCAL_WS_TOOLS_DIR . preg_replace('/\/.*$/','',$tool['cms_tool_url']);
		foreach($tool_files2chk as $fc) {
			$file = $tool[$fc];
			if(empty($file)) continue;
			if(preg_match('/^-1$|^0$/',$file)) continue;	// mostly the select option default
			if((!empty($tool_dir)) && (strstr($file,$tool_dir) !== false)) continue;	// in the tool dir
			if(in_array($file, $this->package['assoc'])) continue;
			if(file_exists(DOCROOT_FS_BASE_DIR . $file)) {
				$this->package['assoc'][] = $file;
				$this->add_file_to_zip('',$file);
				} // if
			else if(!file_exists(DOCROOT_FS_BASE_DIR . '/' . LOCAL_TOOLS_DIR . '/' . $file)) {
				self::addDebugMsg('Unknown file / url: "' . $file . '" in "' . $tool['cms_tool_name'] . '".','warn');
				} // else
			} // foreach
		return $this->package['assoc'];
		} // add_associated_files()

	private function get_nav_bar_tool_link($cms_tool_id, $cms_tool_name) {
		if (strlen(CMS_C_NAVBAR_LINKS) < 8) return false;
		$grid_all = self::chk_unserialize(CMS_C_NAVBAR_LINKS,array());
		$link = false;
		foreach ($grid_all as $g) { // check body enabled
			if(empty($g[0])) continue;
			if(preg_match('/(tool=' . $cms_tool_id . '|id_tool_' . $cms_tool_id . '|tool=' . $cms_tool_name . '|id_tool_' . $cms_tool_name . ')/',$g[0])) {
				// remember $cms_body_id is transient between installs
				$link = array('uri' => $g[0], 'text' => $g[1], 'title' => $g[2]);
				break;
				} // if
			} // foreach
		return $link;
		} // get_nav_bar_tool_link()

	protected function package_localtool($package_id,$cms_tool_package_excludes = '') {
		$package_name = self::get_or_post('package_name');
		$inc_dt_suffix = self::get_or_post_checkbox('add_dt_suffix');
		if($inc_dt_suffix) $dt_suffix = '-' . self::get_gm_datetime(false,true);
		else $dt_suffix = '';
		$packages = self::get_or_post('packages');
		if(empty($package_id)) $package_id = self::get_or_post ('packge_id');
		if((empty($package_name)) || (empty($package_id)) || (empty($packages)) || (count($packages) <= 0)) {
			self::get_error_return_text('Cannot find required package information, not packaged.','warn');
			return false;
			} // if
		if($excludes = self::get_or_post_str('cms_tool_package_excludes',false))
			$cms_tool_package_excludes = $excludes;
		$excludes = explode(',',$cms_tool_package_excludes);
		$this->package_file_tree = array();
		$this->package = array(
			'tools' => array(),
			'nav_bar' => array(),
			);
		$sql_query = "SELECT * FROM cms_tools WHERE cms_tool_id = " . (int)$package_id;
		if(($result = self::$cDBcms->query($sql_query)) &&
			($tool = self::$cDBcms->fetch_array($result))) {
			foreach($tool as $k => $v) $$k = $v;
			$tool_filepath = LOCAL_FS_TOOLS_DIR . $cms_tool_url;
			if((file_exists($tool_filepath)) && (is_readable($tool_filepath))) {
				$package_name = preg_replace('/[ -]/','_',strip_tags($package_name));
				$package_name = preg_replace('/&#?[a-z0-9]{2,8};/i','',$package_name);
				$this->package_file = $package_name . $dt_suffix . '.zip';
				$this->cZIP = new ZipArchive();
				if($this->cZIP->open(VAR_FS_EXPORT_DIR . $this->package_file,(ZipArchive::CREATE | ZipArchive::OVERWRITE)) !== true) {
					self::get_error_return_text('Cannot create "' . $this->package_file . '".');
					return false;
					} // if
				$tool_url = preg_replace('/^\//','',$tool['cms_tool_url']);
				$tool_dir = LOCAL_WS_TOOLS_DIR . preg_replace('/\/.*$/','',$tool_url);
				$this->add_dir_to_zip($tool_dir,$excludes);
				$this->package['tools'][$cms_tool_name] = $tool;
				$this->add_associated_files($tool);

				$this->package['name'] = $package_name;
				$this->package['type'] = 'local_tool';
				$this->package['packager'] = CMS_PROJECT_SHORTNAME;
				$this->package['packager_version'] = CMS_PROJECT_VERSION;
				$this->package['_JSON_ModTime'] = time();	// self::get_gm_datetime();
				$this->package['_JSON_ModUser'] = Ccms_auth::get_logged_in_username();
				$this->package['nav_bar'][$cms_tool_name] = $this->get_nav_bar_tool_link($cms_tool_id, $cms_tool_name);

				if($this->add_package_json_to_zip()) {
					$this->cZIP->close();
					self::get_error_return_text('Packaged local tool "' . $cms_tool_name . '".','success');
					self::set_cms_sess_var(VAR_FS_EXPORT_DIR,'download_dir');
					self::set_cms_sess_var($this->package_file,'download_file');
					// $url = self::get_base_url(true) . 'index.php?download_file=' . $this->package_file;
					// return $url;
					$url = $_SERVER['HTTP_REFERER'] . '&build=done';
					echo <<< EOTLD

	<script type="text/javascript">

		window.location.href = '{$url}';

	</script>

EOTLD;
					return true;
					} // if
				} // if
			} // if
		$this->cZIP->close();
		self::get_error_return_text('Failed to find tool id ' . $package_id);
		return false;
		} // package_localtool()

	public function get_package_form($package_id) {
		// get dependant packages and put up selection table
		$sql_query = "SELECT * FROM cms_tools WHERE cms_tool_id = " . (int)$package_id;
		if(($result = self::$cDBcms->query($sql_query)) &&
			($tool = self::$cDBcms->fetch_array($result))) {
			foreach($tool as $k => $v) $$k = $v;
			$tool_filepath = LOCAL_FS_TOOLS_DIR . $cms_tool_url;
			if((file_exists($tool_filepath)) && (is_readable($tool_filepath))) {
				$package_name = preg_replace('/[ -]/','_',strip_tags(CMS_C_CO_NAME . '_Local_Tool_' . $cms_tool_name . (!empty($cms_tool_version) ? '_' . $cms_tool_version:'')));
				$package_name = preg_replace('/&#?[a-z0-9]{2,8};/i','',$package_name);
				$row = 0;
				$exclude = array();
				$tr_class = (($row++ & 1) ? 'page_config_odd':'page_config_even');
				echo <<< EOTTOP

			<table class="page_config page_config_edit">
				<tr class="page_tool">
					<th class="page_config">Application Name</th>
					<th class="page_config">Include in package.</th>
					<th class="page_config">Comments</th>
				</tr>
				<tr class="{$tr_class}">
					<th class="page_config">{$cms_tool_name}</th>
					<td class="page_config">
						<input type="hidden" name="package_id" value="{$package_id}">
						<label>Select: <input type="checkbox" name="packages[{$package_id}]"
							title="Local tool" CHECKED READONLY/></label>
					</td>
				</tr>
			</table>
EOTTOP;

				echo <<< EOTBOT

			<br>
			<table class="page_config page_config_edit">
				<tr class="page_config">
					<td class="page_config">
						<br>
						<label>Package Name: <input type="text" name="package_name" value="{$package_name}"
							size="80" style="width: unset; max-width: unset;"
							title="Package name, punctuation and spaces are converted to underscores.">
						</label>
						&nbsp;
						<label><input type="checkbox" name="add_dt_suffix"
							title="Check to add date time suffix (e.g. YYYMMDD-HHMMSS) to package file name."
							CHECKED>
						</label>
						&nbsp;
						<label>
							<button type="submit" name="build_package" value="package" title="Build package.">
								Build
							</button>
						</label>
						&nbsp;
						<label>
							<button type="submit" name="cancel" value="cancel" title="Return to tools config.">
								Close
							</button>
						</label>
					</td>
				</tr>
			</table>

EOTBOT;
				return true;
				} // if
			} // if
		self::get_error_return_text('Failed to find tool id ' . $package_id);
		return false;
		} // get_package_form()


/////////////////////////////////////// Install section \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

	public function install_localtool($package_file) {
		if((empty($package_file)) || (!file_exists($package_file))) {
			$pack_filename = self::get_or_post('pack_filename');
			if(empty($pack_filename)) {
				self::get_error_return_text('Cannot get package filename.');
				return false;
				} // if
			$package_file = VAR_FS_TEMP_DIR . rawurldecode($pack_filename);
			if(!file_exists($package_file)) {
				self::get_error_return_text('Cannot get package "' . $package_file . '".');
				return false;
				} // if
			} // if
		$this->package_file = $package_file;
		if(!$this->get_unzip_package_tree()) {
			// hmm
			return false;
			} // if
		$cms_tools = self::get_or_post('tools');
		$files = &$this->package_file_tree;
		$nav_bar = self::get_or_post('nav_bar');
		$cZIP = new ZipArchive();
		if($cZIP->open($this->package_file) !== true) {	// open in read mode
			self::get_error_return_text('Cannot open "' . $package_file . '".');
			return false;
			} // if
		$seld_files = array();
		if((!empty($files)) && (is_array($files))) {
			foreach($files as $file => $ck) {
				// $ck = 'on'
				$seld_files[] = urldecode($file);
				} // foreach
			} // if
		$seld_tools = array();
		foreach($cms_tools as $tool => $ck) {
			// $ck = on
			$seld_tool = urldecode($tool);
			$tool_conf = $this->package['tools'][$seld_tool];
			$seld_tools[$seld_tool] = $tool_conf;
			} // foreach

		$seld_nav_bar_links = array();
		if((!empty($nav_bar)) && (is_array($nav_bar))) {
			foreach($nav_bar as $link => $ck) {
				// $ck = on
				$seld_link = urldecode($link);
				$link_conf = $this->package['nav_bar'][$seld_link];
				$seld_nav_bar_links[$seld_link] = $link_conf;
				} // foreach
			} // if
		
		for ($i = 0; $i < $cZIP->numFiles; $i++) {
			$file = $cZIP->getNameIndex($i);
			if($file == self::PKG_INFO_JSON) continue;
			if(!@$cZIP->extractTo(DOCROOT_FS_BASE_DIR,$file)) {	// save it;
				self::get_error_return_text('Cannot save "' . $file . '".');
				$cZIP->close();
				return false;
				} // if
			self::chmod_chown(DOCROOT_FS_BASE_DIR . $file);
			} // for
		$cZIP->close();

		// now add / update DB
		foreach($seld_tools as $name => &$conf) {
			$fields = $conf;
			unset($fields['cms_tool_id']);
			$fields['cms_tool_installed'] = (self::get_or_post_checkbox('allow_changes') ? 0:1);
			$id = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_id', "cms_tool_name = '" . $conf['cms_tool_name'] . "'");
			if((int)$id > 0) {	// update
				if(self::$cDBcms->perform('cms_tools',$fields,'update','cms_tool_id = ' . $id )){
					self::get_error_return_text('Updated "' . $conf['cms_tool_name'] . '".','success');
					} // if
				else {
					self::get_error_return_text('Failed to update "' . $conf['cms_tool_name'] . '".');
					return false;
					} // else
				} // if
			else { // insert
				if(self::$cDBcms->perform('cms_tools',$fields)){
					self::get_error_return_text('Added "' . $conf['cms_tool_name'] . '".','success');
					} // if
				else {
					self::get_error_return_text('Failed to add "' . $conf['cms_tool_name'] . '".');
					return false;
					} // else
				} // else
			} // foreach

		// now add / update nav bar links
		$grid_all = self::chk_unserialize(CMS_C_NAVBAR_LINKS,array());
		$chgd = false;
		foreach($seld_nav_bar_links as $name => &$v) {
			// each tool ony gets one mention on the nav bar
			if(empty($v)) continue;
			$id = self::$cDBcms->get_data_in_table('cms_tools', 'cms_tool_id', "cms_tool_name = '" . $name . "'");
			if((int)$id <= 0) continue;
			$url = 'index.php?tool=' . $id . '&name=' . urlencode($name);
			$uri = 'id_tool_' . $id;
			// search match
			$found = false;
			foreach($grid_all as &$g) {
				if($g[0] == $uri) {
					$g[1] = $v['text'];
					$g[2] = $v['title'];
					$found = true;
					$chgd = true;
					break;
					} // if
				} // foreach
			if(!$found) {
				$grid_all[] = array(
					0 => array('uri' => $uri, 'text' => $v['text']),
					1 => $v['text'],
					2 => $v['title'],
					);
				$chgd = true;
				} // if
			} // foreach
		if($chgd) {
			$cms_c_navbar_links = serialize($grid_all);
			self::$cDBcms->query('UPDATE cms_configs SET cms_config_value = \'' . $cms_c_navbar_links . '\' WHERE cms_config_key = \'CMS_C_NAVBAR_LINKS\';');
			} // if

 		self::get_error_return_text('Installed local tool package "' . $this->package['name'] . '".','success');
		return true;
		} // install_localtool()

	protected function get_unzip_package_tree() {
		$cZIP = new ZipArchive();
		if($cZIP->open($this->package_file) !== true) {	// open in read mode
			self::get_error_return_text('Cannot open "' . $package_file . '".');
			return false;
			} // if
		$this->package_file_tree = array();
		$j = 0;
		for ($i = 0; $i < $cZIP->numFiles; $i++) {
			$name = $cZIP->getNameIndex($i);	// get name
			if($name == self::PKG_INFO_JSON) {
				$json = $cZIP->getFromIndex($i);
				$this->package = self::json_decode($json, true);
				continue;
				} // if
			$this->package_file_tree[$j++] = $name;	// tree it;
			} // for

		$cZIP->close();
		return true;
		} // get_unzip_package_tree()

	public function get_install_form($package_file) {
		$this->package_file = $package_file;
		if(!$this->get_unzip_package_tree()) {
			// hmm
			return false;
			} // if
		$ok = true;
		// present the options to admin
		$package = &$this->package;
		if($package['type'] != 'local_tool') {
			self::get_error_return_text('Package is not a local tool (type is: ' . $package['type'] . ').');
			return false;
			} // if
		$pack_filename = basename($this->package_file);

		$package_name = $package['name'];
		$packager = $package['packager'];
		$packager_version = $package['packager_version'];
		$package_build_dt = $package['_JSON_ModTime'];
		$package_build_user = $package['_JSON_ModUser'];

		$cms_tools = &$package['tools'];
		$assoc = &$package['assoc'];

		echo '<input type="hidden" name="pack_filename" value="' . rawurlencode($pack_filename) . '">';

		echo <<< EOTTOP

			<table class="page_config page_config_edit">
				<tr class="page_config">
					<th class="page_config">
						<h2>{$package_name}</h2>
					</th>
				</tr>
				<tr class="page_config">
					<td class="page_config">
						Package file: {$pack_filename}
						<br>
						Packager: {$packager}, Packager version: {$packager_version}.
						<br>
						Build date: {$package_build_dt}, Built by user name: {$package_build_user}.
					</td>
				</tr>
				<tr class="page_config"><td class="page_config">&nbsp;</td></tr>

EOTTOP;
		$row = 0;
		if((!empty($cms_tools)) && (count($cms_tools) > 0)) {
			echo '<tr class="page_config"><th class="page_config">Local Tools.</th></tr>';
			foreach($cms_tools as $name => &$tool) {
				$update = self::$cDBcms->is_data_in_table('cms_tools', 'cms_tool_name',  $tool['cms_tool_name']);
				echo '				<tr class="' . (($row++ & 1) ? 'page_config_odd':'page_config_even') . '"><td class="page_config">';
				echo '<label' . (!empty($tool['cms_tool_description']) ? ' title="Description: ' . $tool['cms_tool_description'] . '"':'') . '">';
				echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $tool['cms_tool_name'] . '&nbsp;';
				echo '<input type="checkbox" name="tools[' . urlencode($tool['cms_tool_name']) . ']" CHECKED>';
				echo '</label>';
				if((isset($nav_bar[($tool['cms_tool_name'])])) && (!empty($nav_bar[($tool['cms_tool_name'])]))) {
					echo '<br>';
					echo '<label>';
					echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $tool['cms_tool_name'] . ' nav bar link' . '&nbsp;';
					echo '<input type="checkbox" name="nav_bar[' . urlencode($tool['cms_tool_name']) . ']" CHECKED>';
					echo '</label>';
					} // if
				echo '</td></tr>' .PHP_EOL;
				} // foreach
			echo '<tr class="page_config"><td class="page_config">&nbsp;</td></tr>';
			} // if
		else {
			echo '<tr class="page_config"><td class="page_config">Package has no tools.</td></tr>';
			} // else

		if((!empty($files)) && (count($files) > 0)) {
			echo '<tr class="page_config"><th class="page_config">Associated Files.</th></tr>';
			foreach($files as $fa) {
				$update = file_exists(DOCROOT_FS_BASE_DIR . $fa);
				echo '				<tr class="' . (($row++ & 1) ? 'page_config_odd':'page_config_even') . '"><td class="page_config">';
				echo '<label>';
				echo ($update ? 'Update: ':'Install: ') . '&nbsp;' . $fa . '&nbsp;';
				echo '<input type="checkbox" name="assoc[' . urlencode($fa) . ']" CHECKED>';
				echo '</label>';
				echo '</td></tr>' .PHP_EOL;
				} // foreach
			echo '<tr class="page_config"><td class="page_config">&nbsp;</td></tr>';
			} // if
		else {
			echo '<tr class="page_config"><td class="page_config">No associated files.</td></tr>';
			} // else
		echo '<tr class="page_config"><td class="page_config"><label>Allow change: <input type="checkbox" name="allow_changes" title="Allow the tool to be changed."></label></td></tr>';

		echo <<< EOTBOT

				<tr class="page_config">
					<td class="page_config">
						<br>
						<label><button type="submit" name="install_package" value="package" title="Install package.">Install</button>
						&nbsp;
						<label><button type="submit" name="cancel" value="cancel" title="Return to local tools config." formnovalidate>Cancel</button>
					</td>
				</tr>
			</table>

EOTBOT;

		return $ok;
		} // get_install_form()

} // Ccms_tool_install
