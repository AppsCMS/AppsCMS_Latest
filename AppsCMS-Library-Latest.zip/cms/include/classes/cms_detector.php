<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_detector.php 3007 2022-12-01 01:07:32Z robert0609 $
 */

/**
 * Description of cms_detector
 * class to detect what is the client
 *
 * @author robert0609
 */

class Ccms_detector extends Ccms_base {

	private static $det_done = false;
	
	// client screen threhold values
	private const TINY_WIDTH = 480;
	private const TINY_HEIGHT = 640;
	private const TABLET_WIDTH = 800;
	private const TABLET_HEIGHT = 1024;

	function __construct() {
		if(self::$det_done) return;
		self::$det_done = true;
		parent::__construct();

		if(self::is_api()) return;	// no
		if(self::is_ajax()) return;	// no
		if(self::is_cli()) return;	// no

		$this->detect_client();

		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

// static

// dynamic methods
	// methods NOT CALLED PUBLICALLY

	protected function detect_client() {
		
		$users_agent_str = $this->get_user_agent();
		// style override ?
		if (preg_match('/Edge\/[0-9]+\.[0-9]+$/i', $users_agent_str)) {
			// self::use_block_html(false); // @TODO OK ??
			self::is_ms_edge(true); // @TODO compatibility issues in JS
			// self::is_html5(false);	// @TODO ?? has issues still
			} // if
		else if (preg_match('/Safari\/[0-9]+\.[0-9]+$/i', $users_agent_str)) {
			self::is_safari(true);  // @TODO OK on MAC ??, devices done separately
			} // if
		else if (preg_match('/^Mozilla\/4\../i', $users_agent_str)) {
			self::use_block_html(false); // IE 6 and others
			self::is_moz4(true); // compatibility issues
			self::is_html5(false);
			} // if
		else if (preg_match('/Konqueror\/4\.3/i', $users_agent_str)) {
			// Konqueror 4.3.4 is full of problems, bugs and compatibility issues
			self::is_moz4(true); // try to keep it sane
			self::is_html5(false); // NOT
			} 
		else
			self::is_moz4(false);

		if (preg_match('/chrome\/[0-9]+/i', $users_agent_str))
			self::is_chrome(true);
		else
			self::is_chrome(false);

		if (preg_match('/^Mozilla\/.*Firefox\//i', $users_agent_str)) {
			self::is_firefox(true);
			} 
		else
			self::is_firefox(false);

		if((CMS_C_CLIENTMETA_ALLOW) &&
			($clientMetadata = self::get_cms_sess_var('clientMetadata')) &&
			(!empty($clientMetadata))) {
			// do defaults
			self::is_chrome(false);
			self::is_firefox(false);
			self::is_safari(false);  // @TODO OK on MAC ??, devices done separately
			self::is_ms_edge(false); // @TODO compatibility issues in JS
			$width = false;
			$height = false;

			// check client meta data
			foreach($clientMetadata as $k => &$v) {
				switch($k) {
				case 'isIE5IE6':	// (window.XMLHttpRequest ? false:true),
					break;
				case 'isOpera':	// isOpera,	// Opera 8.0+
					break;
				case 'isFirefox':	// isFirefox,	// Firefox 1.0+
					self::is_firefox(true);
					break;
				case 'isSafari':	// isSafari,	// Safari 3.0+ "[object HTMLElementConstructor]"
					self::is_safari(true);  // @TODO OK on MAC ??, devices done separately
					break;
				case 'isIE':	// isIE,	// Internet Explorer 6-11
					break;
				case 'isEdge':	// (!(isIE || !!document.documentMode) && !!window.StyleMedia),	// Edge 20+
					self::is_ms_edge(true); // @TODO compatibility issues in JS
					break;
				case 'isChrome':	// isChrome,	// Chrome 1 - 79
					self::is_chrome(true);
					break;
				case 'isEdgeChromium':	// (isChrome && (n.userAgent.indexOf("Edg") != -1)),	// Edge (based on chromium) detection
					break;
				case 'isVivaldi':	// isVivaldi, // Vivaldi 1.9
					break;
				case 'window_innerWidth':	// window.innerWidth,
					$width = (int)$v;
					break;
				case 'window_innerHeight':	// window.innerHeight,
					$height = (int)$v;
					break;
				case 'window_outerWidth':	// window.outerWidth,
				case 'window_outerHeight':	// window.outerHeight,
				case 'screen_width':	// screen.width,
				case 'screen_height':	// screen.height,
				case 'screen_colourDepth':	// screen.colorDepth,
				case 'screen_pixelDepth':	// screen.pixelDepth,
				case 'screen_availWidth':	// screen.availWidth,
				case 'screen_availHeight':	// screen.availHeight,
				case 'user_lang':	// (n.language || n.userLanguage),
				case 'char_set':	// document.characterSet,
				case 'timezone_minutes':	// d.getTimezoneOffset(),
				case 'time_ms':	// d.getTime(),	// milliseconds from 00:00:00.000 on the 1st of January 1970
				case 'date':	// d.toJSON(),	// formated as the ISO-8601 standard':	// YYYY-MM-DDTHH:mm:ss.sssZ
				case 'cookies_enabled':	// n.cookieEnabled,
				case 'name':	// n.appName,
				case 'code_name':	// n.appCodeName,
				case 'platform':	// n.platform,
				case 'product':	// n.product,
				case 'vendor':	// n.vendor,
				case 'agent':	// n.userAgent,
				case 'version':	// n.appVersion,
				case 'isBlinkEng':	// ((isChrome || isOpera) && !!window.CSS),	// Blink engine detection
				default:
					break;
					} // switch
				} // foreach
			if(($width) && ($height)) {	// do basic device classification
				// do by number of pixels (area)
				$pixels = $width * $height;
				if(($width <= self::TINY_WIDTH) || ($pixels <= (self::TINY_WIDTH * self::TINY_HEIGHT))) {
					self::is_tiny(true);
					self::is_tablet(false);
					} // if
				else if(($width <= self::TABLET_WIDTH) || ($pixels <= (self::TABLET_WIDTH * self::TABLET_HEIGHT))) {
					self::is_tiny(false);
					self::is_tablet(true);
					} // else if
				else {
					self::is_tiny(false);
					self::is_tablet(false);
					} // else
				} // if
			} // if 
		else {
			self::is_tiny($this->is_tiny_device_chk($users_agent_str));
			self::is_tablet(($this->is_mobile_device_chk($users_agent_str) && !self::is_tiny()));

			// self::is_tiny(true);	// test	@TODO comment out after testing
			// self::is_tablet(true);	// test	@TODO comment out after testing
			if($this->use_browscap()) return true;
			} // else

		return true;
		} // detect_client()

	protected function use_browscap() {
		if(!empty(self::$cms_browsercap_result)) return true;	// time saver
		if(self::$cms_browsercap_done) return true;
		self::$cms_browsercap_done = true;
		
		// $browser = get_browser(null,true);

		$classPath = CMS_FS_LIB_DIR . 'browscap/src/phpbrowscap/Browscap.php';
		$cachePath = VAR_FS_CACHE_DIR . 'Browscap';
		if((!defined('CMS_C_BROWSCAP_ALLOW')) ||
			(!CMS_C_BROWSCAP_ALLOW) ||
			(!is_readable($classPath)) ||
			(!self::chkdir($cachePath))) {
			return false;
			} // if
		// see (mostly) "https://github.com/GaretJax/phpbrowscap/wiki/QuickStart"
		// Loads the class
		require_once($classPath);

		// Create a new Browscap object (loads or creates the cache)
		$bc = new Browscap($cachePath);

		// Set local browscap INI file. Can be;-
		//	full_php_browscap.ini - large (>100mB) file with every known browser,
		//	php_browscap.ini - contains the typeical PHP browser list,
		//	lite_php_browscap.ini - contains all the typical browsers (900KB).

		// Set INI source
		switch(CMS_C_BROWSCAP_URL) {
		case 'Lite':
			$bc->remoteIniUrl = 'http://browscap.org/stream?q=Lite_PHP_BrowsCapINI';	// ok (900KB) but not complete
			break;
		case 'PHP':
			$bc->remoteIniUrl = 'http://browscap.org/stream?q=PHP_BrowsCapINI'; // big (21MB) slow
			break;
		case 'Full':
	    	$bc->remoteIniUrl = 'http://browscap.org/stream?q=Full_PHP_BrowsCapINI'; // too big (102MB) too slow
			break;
		case 'Local':
		default:	// local
			$bc->localFile = CMS_FS_LIB_DIR . 'ini/lite_php_browscap.ini';
			break;
			} // switch


		// Get information about the current browser's user agent
		self::$cms_browsercap_result = $bc->getBrowser();
		if(Ccms::is_debug()) {
			$user = Ccms_auth::get_logged_in_username();
			if(empty($user)) $user = Ccms_auth::get_client_ip_address();		// sub
			$debugFile = VAR_FS_TEMP_DIR . 'browscap-' . $user . '-browser.json';
			Ccms::save_json($debugFile, self::$cms_browsercap_result);
			} // if
		if((empty(self::$cms_browsercap_result)) ||
			(!isset(self::$cms_browsercap_result->isTablet)) ||
			(!isset(self::$cms_browsercap_result->isMobileDevice)) ||
			(!isset(self::$cms_browsercap_result->Browser)))
			return false;

		self::is_tablet(self::$cms_browsercap_result->isTablet);
		self::is_tiny((self::$cms_browsercap_result->isMobileDevice && !self::is_tablet()));

		// style override ?
		self::is_html5(true);	// assume
		switch(strtolower(self::$cms_browsercap_result->Browser)) {
		case 'edge':
			// self::use_block_html(false); // @TODO OK ??
			self::is_ms_edge(true); // @TODO compatibility issues in JS
			// self::is_html5(false);	// @TODO ?? has issues still
			break;
		case 'safari':
			self::is_safari(true);  // @TODO OK on MAC ??, devices done separately
			break;
		case 'ie':
		case 'mozilla':
			self::use_block_html(false); // IE 6 and others
			self::is_moz4(true); // compatibility issues
			self::is_html5(false);
			break;
		case 'tv':
		case 'tv device':
			self::use_block_html(false); // IE 6 and others
			self::is_moz4(true); // compatibility issues
			self::is_html5(false);
			break;
		case 'konqueror':
			self::is_moz4(true); // try to keep it sane
			self::is_html5(false); // NOT
			break;
		case 'chrome':
			self::is_chrome(true);
			break;
		case 'firefox':
			self::is_firefox(true);
			break;
		default:
			self::is_moz4(false);
			self::is_chrome(false);
			self::is_firefox(false);
			break;
			} // switch

		// self::is_tiny(true);	// test	@TODO comment out after testing
		// self::is_tablet(true);	// test	@TODO comment out after testing

		return true;
		} // use_browscap()

	protected function get_user_agent() {
		if(!empty($_SERVER['HTTP_USER_AGENT'])) {
			return $_SERVER['HTTP_USER_AGENT'];
			} // if
		return 'agent_unknown';
		} // get_user_agent()

	protected function is_mobile_device_chk($useragent = '') {

		// the preg_match patterns come from "http://detectmobilebrowsers.com/", too specific miss the commen common
		if(empty($useragent)) $useragent = $this->get_user_agent();
		if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent)) {
			return true;
			} // if
		if(preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($useragent, 0, 4))) {
			return true;
			} // if

		// look for safari, WebAidkit, ?
		// eg Mozilla/5.0 (iPad; CPU OS 6_1_3 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B329 Safari/8536.25
		if(preg_match('/.*(iPad|iPod|iPhone).*/i', $useragent)) {
			return true;
			} // if

		// look for Android
		// eg Mozilla/5.0 (Linux; U; Android 4.2.2; en-au; SM-T315T Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30
		if(preg_match('/.*Android.*/i', $useragent)) {
			return true;
			} // if

		if(preg_match(
			"/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i",
			$useragent))
			return true;

		return false;
		} // is_mobile_device_chk()

	protected function is_tiny_device_chk($useragent = '') {
		if(preg_match('/.*(iPad).*/i', $useragent)) {
			return false;
			} // if

		// the preg_match patterns come from "http://detectmobilebrowsers.com/", too specific miss the commen common
		if(empty($useragent)) $useragent = $this->get_user_agent();
		if(preg_match('/.+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent)) {
			return true;
			} // if

		if(preg_match('/.*(iPod|iPhone).*/i', $useragent)) {
			return true;
			} // if

		// and one for Google ( Bot) which does not fit anymore
		// "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.111 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
		if(preg_match('/.+android.+mobile.+(safari|firefox|chrome)/i', $useragent)) { // ????
			return true;
			} // if

		return false;
		} // is_tiny_device_chk()

} // Ccms_detector
