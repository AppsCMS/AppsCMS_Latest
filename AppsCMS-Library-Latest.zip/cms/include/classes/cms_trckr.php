<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_trckr.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of cms_trckr
 * A debug helper class.
 *
 * @author robert0609
 */
class Ccms_trckr extends Ccms_base {
	//put your code here

	function __construct() {
		parent::__construct();
		// self::send_downloads();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function get_callers() {
		$ex = new Exception();
		$callers = $ex->getTrace();
		return $callers;
		} // get_caller()

	protected static function chk_caller_file($file = false) {
		if(empty($file)) {
			$callers = self::get_callers();
			for ( $i = 2; $i < count($callers); $i++) {
				if(!isset($callers[$i])) break;
				$caller = &$callers[$i];
				if(preg_match('/^page_(start|end)_comment/i',$caller['function'] )) {
					$file = $caller['file'];
					break;
					} // if
				} // for
			} // if
		return $file;
		} // chk_caller_file()

	public static function page_start_track_comment($file = false, $prn = true) {	// outputs a stx marker for the php file
		if(!self::is_debug()) return '';
		if(empty($file))
			$file = self::chk_caller_file();
		$file = basename($file);
		$text = PHP_EOL . '<!-- '. $file . ' stx -->' . PHP_EOL;
		if($prn) echo $text;
		return $text;
	} // page_start_track_comment()

	public static function page_end_track_comment($file = false, $prn = true) {	// outputs a etx marker for the php file
		if(!self::is_debug()) return '';
		if(empty($file))
			$file = self::chk_caller_file();
		$file = basename($file);
		$file = basename($file);
		$text = PHP_EOL . '<!-- '. $file . ' etx -->' . PHP_EOL;
		if($prn) echo $text;
		return $text;
	} // page_end_track_comment()



} // Ccms_trckr
