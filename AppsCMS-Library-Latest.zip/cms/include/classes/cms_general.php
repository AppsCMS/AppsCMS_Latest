<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_general.php 3133 2023-02-13 05:11:52Z robert0609 $
 */

/**
 * Description of cms_general
 * general base class for cms functions
 *
 * @author robert0609
 */

require_once 'cms_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_general extends Ccms_base {

	public static $cALcms = false;

	private static $cms_install_settings_done = false;

	const INLINE_IMG_MIN_SIZE = 100;

	protected static $cms_site_data_default = array(
		'ct' => false,	// create timestamp
		'mt' => false,	// modify timestamp
		'dom' => false,	// domain
		'alias' => false,	// ws alias
		'access_cntr' => 0,	// access counter
		);

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// dynamic methods

	protected function get_user_agent() {
		if((!empty($_SERVER['HTTP_USER_AGENT'])) &&
			(!empty($_SERVER['HTTP_USER_AGENT']))) {
			return $_SERVER['HTTP_USER_AGENT'];
			} // if
		return 'agent_unknown';
		} // get_user_agent()

	protected function get_next_body_file() {
		if(!$next_body_filename = self::get_cms_sess_var('next_body_filename')) return false;
		self::unset_cms_sess_var('next_body_filename');	// only once
		if(empty($next_body_filename)) return false;
		if(!file_exists($next_body_filename)) return false;
		return $next_body_filename;
		} // set_next_body_file()

	protected function get_visitor_count() {
		// visitor number to site
		if(self::$cms_visitor_cnt) return self::$cms_visitor_cnt;

		// make site data json indexed to DOM in the ETC_FS_SITE_DATA_DIR so it will be saved by the versioning.
		$cms_site_data_json = ETC_FS_SITE_DATA_DIR . 'CMS_DOM--' . preg_replace('/[\/\s,]+/i','-',CMS_DOMAIN . '-' . CMS_URI_ALIAS) . '-Site_Data.json';

		$mode = (file_exists($cms_site_data_json) ? 'r+':'w');
		if($fp = self::file_safe_wopen($cms_site_data_json,$mode)) {	// open data and lock it
			if($mode == 'w') {	// new json
				$cms_site_data = self::$cms_site_data_default;
				$cms_site_data['ct'] = time();
				$cms_site_data['dom'] = CMS_DOMAIN;
				$cms_site_data['alias'] = CMS_URI_ALIAS;
				self::addAdminMsg('Initialised new site access counter.','warn');
				} // if
			else if($site_json = fread($fp,1024)) {
				$cms_site_data = self::json_decode($site_json, true);
				$cms_site_data['mt'] = time();
				} // else if
			else {	// ??
				self::file_safe_wclose($fp);
				self::addAdminMsg('Failed to update site access counter.','warn');
				return false;
				} // else
			$cms_site_data['access_cntr'] += 1;
			self::$cms_site_data = $cms_site_data;
			$site_json = self::json_encode($cms_site_data);
			@fseek($fp,0);
			fwrite($fp,$site_json);
			self::file_safe_wclose($fp);
			if($mode == 'w') self::chmod_chown($cms_site_data_json);
			self::$cms_visitor_cnt = $cms_site_data['access_cntr'];
			return self::$cms_visitor_cnt;
			} // if
		return false;
		} // get_visitor_count()

// static methods
	public static function get_cms_settings($redefine = false) {

		if($redefine) self::$cms_ini = false;
		else if((self::$cms_install_settings_done) &&
			(self::$cms_ini !== false)) return self::$cms_ini;
		self::$cms_install_settings_done = true;

		$settings = (self::$cms_ini ? self::$cms_ini : self::read_cms_ini_settings());

		// define installed settingss
		foreach($settings as $sect_name => $sect) {
			if(preg_match('/^_/i',$sect_name)) continue;
			foreach($sect as $key => $val) {
				if(defined('CMS_S_' . $key)) continue;
				if($sect_name == 'ThemeSettings') {
//					$cont = false;
					switch($key) {
					case 'FOOTER_BOOL':
					case 'FOOTER_HEIGHT':
					case 'HEADER_BOOL':
					case 'HEADER_HEIGHT':
					case 'LEFT_COLUMN_BOOL':
					case 'LEFT_WIDTH':
					case 'MODAL_HEIGHT':
					case 'MODAL_WIDTH':
					case 'NAV_BAR_BOOL':
					case 'NAV_BAR_HEIGHT':
					case 'NAV_BAR_LINKS_POSITION':
					case 'NAV_BAR_ELEM_SHOW_ICONS_BOOL':
					case 'NAV_BAR_RIGHT_BOOL':
					case 'PAGE_STYLE_BLOCK_BOOL':
					case 'RIGHT_COLUMN_BOOL';
					case 'RIGHT_WIDTH':
						break;	// needed
					default:
						// PHP Warning:  "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"?
						// see PHP 7.3 bug "https://www.mantisbt.org/bugs/view.php?id=25033"
						continue 2;	// dont define these 'ThemeSettings' not used at runtime
//						$cont = true;
//						break;
						} // switch
//					if($cont) continue;
					} // if
				$val = self::get_macro_lookup($sect_name,$sect, $key, $val);
				$val = self::conv_conf_val_to_type($val);
				define('CMS_S_' . $key,$val);
				} // foreach
			} // foreach
		return $settings;
		} // get_cms_settings()

	public static function has_dns_record($url, $types = array(DNS_A,DNS_AAAA,DNS_CNAME)) {
		// types can be DNS_A, DNS_CNAME, DNS_HINFO, DNS_CAA, DNS_MX, DNS_NS, DNS_PTR, DNS_SOA, DNS_TXT, DNS_AAAA, DNS_SRV, DNS_NAPTR, DNS_A6, DNS_ALL or  or DNS_ANY
		$url_chk = parse_url($url);
		if(empty($url_chk['host'])) return false;
		if(strlen($url_chk['host']) < 6) return false;
		if(is_array($types)) {
			foreach($types as $t) {
				if(dns_get_record($url_chk['host'],$t)) return true;
				} // foreach
			} // if
		else if(dns_get_record($url_chk['host'],$types)) return true;
		if(preg_match('/^(::1|127.0.0.1|localhost)$/i',$url_chk['host'])) return true;
		return false;
		} // has_dns_record()

	// static methods
	public static function get_header_bar_title($delimiter = ' - ') { // set page title, a bit of basic SEO
		$title = (!empty(self::$cms_page_info['header_title']) ? self::$cms_page_info['header_title']:'');	// error
		switch(self::get_cms_action()) {
		case 'tool':
			if(((int)Ccms::$cms_tool_id > 0) &&
				($name = self::$cDBcms->get_data_in_table('cms_tools','cms_tool_title','cms_tool_id = ' . (int)Ccms::$cms_tool_id)) &&
				(!empty($name))) {
				$title .= $delimiter . $name;
				} // if
			break;
		case 'cms_login':
		case 'cms_edit_tools':
		case 'cms_edit_bodies':
		case 'cms_edit_groups':
		case 'cms_edit_users':
		case 'cms_edit_search':
		case 'cms_edit_install':
		case 'cms_edit_config':
		case 'cms_about':
		case 'home':
		default:
			break;
		} // switch
		return $title;
		} // get_header_bar_title()

	public static function is_wysiwyg_allowed() {
		if(empty(self::$cms_page_info['html_wysiwyg_allow'])) return false;
		return self::$cms_page_info['html_wysiwyg_allow'];
		} // is_wysiwyg_allowed()

	public static function is_drag_drop_used() {
		if(CMS_S_DRAG_DROP_PRELOAD_BOOL) return true;
		if(self::is_admin_action()) return true;
		if(empty(self::$cms_body_id)) return true;	// links page
		return false;
		} // is_drag_drop_used()

	public static function get_head_JS_url($js_file, $async = true) {
		static $dones = [];
		if(in_array($js_file,$dones)) return '';	// done
		$dones[] = $js_file;
		if(!is_readable(DOCROOT_FS_BASE_DIR . $js_file)) return '';
		$minnd = Ccms_minify_plugin::minify_js($js_file);
		if(empty($minnd)) return '';
		$text = '		<script type="text/javascript"';
		$text .= ' src="' . $minnd .'"';
		if($async) $text .= ' async';
		$text .= ' ></script>';
		return $text;
		} // get_head_JS_url()

	public static function get_head_CSS_url($css_file, $async = true) {
		static $dones = [];
		if(in_array($css_file,$dones)) return '';	// done
		$dones[] = $css_file;
		// see "https://developer.mozilla.org/en-US/docs/Web/HTML/Preloading_content"
		if(!is_readable(DOCROOT_FS_BASE_DIR . $css_file)) return '';
		$minnd = (preg_match('/\.css$/',$css_file) ? Ccms_minify_plugin::minify_css($css_file):Ccms_minify_plugin::minify_scss($css_file));
		if(empty($minnd)) return '';
		$text = '';
		if($async) {
			$text = '		<link rel="preload"';
			$text .= ' href="' . $minnd . '"';
			$text .= ' as="style">' . PHP_EOL;
			} // if
		$text .= '		<link rel="stylesheet"';
		$text .= ' href="' . $minnd . '">';
		return $text;
		} // get_head_CSS_url()

	public static function output_page_headers() {
		if(headers_sent()) return;
		// header('X-Frame-Options: DENY');
		if((!CMS_S_ENABLE_BROWSER_CACHING_BOOL) || (self::is_debug())) {
			header("Expires: " . date('r',time() - (7 * 24 * 60 * 60)));	// last week
			header("Cache-Control: no-cache, must-revalidate, post-check=0, pre-check=0");
			header("Pragma: no-cache");
			} // if
		echo '<!DOCTYPE html>' . PHP_EOL;
		} // output_page_headers()

	public static function output_head($newTitle = '', $prn_flg = true) {
		if(self::$cms_head_output_flg) return false;	// donot output twice
		self::$cms_head_output_flg = true;
		$app_head = Ccms_apps::get_head_text();
		$lang = self::get_core_language();
		$text = array();
		$text[] = '	<head' . (!empty($lang) ? ' lang="'  . $lang . '"':'')  . '>';
		$text[] = '		<meta charset="' . CMS_S_CHAR_SET . '">';
		$text[] = '		<meta http-equiv="content-language" content="' . $lang . '">';
//		if(self::is_debug()) {
//			$text[] = '		<meta http-equiv="cache-control" content="no-cache, must-revalidate, post-check=0, pre-check=0" />';
//			$text[] = '		<meta http-equiv="cache-control" content="max-age=0" />';
//			$text[] = '		<meta http-equiv="expires" content="0" />';
//			$text[] = '		<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />';
//			$text[] = '		<meta http-equiv="pragma" content="no-cache" />';
//			} // if

		if(empty($newTitle)) $newTitle = (!empty(self::$cms_page_info['title']) ? self::$cms_page_info['title']:false);	// error
		if((!empty($app_head)) && (empty($newTitle)) && ($app_head['title'])) $newTitle = $app_head['title'];
		if(!empty($newTitle))
			$text[] = '		<title>' . strip_tags($newTitle) . '</title>';

		if(strlen(CMS_C_META_DEFAULT_EXTRAS) > 4) {
			$grid_all = self::chk_unserialize(CMS_C_META_DEFAULT_EXTRAS,array());
			foreach ($grid_all as &$g) { // check body enabled
				$text[] = '		<meta name="' . $g[0] . '" content="' . $g[1] . '">';
				} // foreach
			} // if

		$text[] = '		<base id="cms_base_ref" href="' . self::$cms_page_info['base_ref'] . '">';
		$text[] = '		<meta name="generator" content="'. CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . '">';

		if(strlen(CMS_C_META_OWNER) > 4)
			$text[] = '		<meta name="owner" content="' . CMS_C_META_OWNER . '">';
		if(strlen(CMS_C_META_COPYRIGHT) > 4)
			$text[] = '		<meta name="copyright" content="' . CMS_C_META_COPYRIGHT . '">';
		if(strlen(CMS_C_META_AUTHOR) > 4)
			$text[] = '		<meta name="author" content="' . CMS_C_META_AUTHOR . '">';
		if(strlen(CMS_C_META_CONTACT) > 4)
			$text[] = '		<meta name="contact" content="' . CMS_C_META_CONTACT . '">';

		if(!empty(self::$cms_page_info['meta_keywords']))
			$text[] = '		<meta name="keywords" content="' . self::$cms_page_info['meta_keywords'] . '">';

		if(!empty(self::$cms_page_info['meta_description']))
			$text[] = '		<meta name="description" content="' . self::$cms_page_info['meta_description'] . '">';
		if(!CMS_S_ALLOW_ROBOTS_BOOL)
			$text[] = '		<meta name="robots" content="nofollow">';

		if((self::is_tiny()) || (self::is_tablet())) {
			// $text[] = '		<meta name="viewport" content="initial-scale = 1.0, user-scalable = no">';
			$text[] = '		<meta name="viewport" content="initial-scale = 1.0">';
			$text[] = '		<meta name="apple-mobile-web-app-capable" content="yes">';
			} // if

//		if(!CMS_S_ENABLE_BROWSER_CACHING_BOOL) {
//			$text[] = '		<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">';
//			$text[] = '		<meta HTTP-EQUIV="Expires" CONTENT="-1">';
//			} // if

		$this_url = '';	// self::get_base_url();
		if(is_readable(DOCROOT_FS_BASE_DIR . 'favicon.ico')) {
			$text[] = '		<link rel="shortcut icon" type="image/x-icon" href="' . $this_url . 'favicon.ico"/>';
			$text[] = '		<link rel="icon" href="' . $this_url . 'favicon.ico" type="image/x-icon"/>';
			} // if
		else if(is_readable(DOCROOT_FS_BASE_DIR . 'favicon.png')) {
			$text[] = '		<link rel="shortcut icon" type="image/png" href="' . $this_url . 'favicon.png"/>';
			$text[] = '		<link rel="icon" type="image/png" href="' . $this_url . 'favicon.png"/>';
			} // if

		$text[] = self::get_head_CSS_url(ETC_WS_CSS_DIR . 'cms_styles_main.css',false);
		$text[] = self::get_head_CSS_url(ETC_WS_CSS_DIR . (self::use_block_html() ? 'cms_styles_block.css':'cms_styles_inline.css'),false);

		if(strlen(CMS_S_CUSTOM_CSS_URI) > 4)  {	// custom CSS setting.
			$text[] = self::get_head_CSS_url(CMS_S_CUSTOM_CSS_URI);
			} // if
		$text[] = Ccms_apps::output_apps_css(false);

		$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_boxes.js',false);
		$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_funcs.js',false);
		if(self::is_drag_drop_used()) {
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_drag_drop.js',false);
			} // if

		if(strlen(CMS_S_CUSTOM_JS_URI) > 4) {	// custom CSS setting.
			$text[] = self::get_head_JS_url(CMS_S_CUSTOM_JS_URI);
			} // if

		switch(self::get_cms_action()) {
		case 'cms_edit_bodies':
			if((Ccms::is_get_or_post('add')) ||
				(Ccms::is_get_or_post('edit')) ||
				(Ccms::is_get_or_post('body_edit_id'))) {
				$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);

				if(Ccms::is_get_or_post('body_edit_id')) {
					if((CMS_C_ALLOW_TEXT_EDITORS) &&
						((int)Ccms::get_or_post('body_edit_id') > 0)) {
						$file = self::$cDBcms->get_data_in_table('cms_bodies','cms_body_file','cms_body_id = ' . (int)Ccms::get_or_post('body_edit_id'));
						self::$cms_page_info['html_wysiwyg_allow'] = (preg_match('/\.htm$|\.html$/i', $file) ? true:false);
						} // if
					else self::$cms_page_info['html_wysiwyg_allow'] = true;	// just allow, @TODO use js select editor type later for new body file
					} // if
				} // if
			break;
		case 'lm_show_links':
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_lm.js',false);
			break;
		case 'cms_edit_links':
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_lm.js',false);
			break;
			
		case 'cms_edit_header_footer':
			if(Ccms::is_get_or_post('edit')) {
				$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
				self::$cms_page_info['html_wysiwyg_allow'] = CMS_C_ALLOW_TEXT_EDITORS;
				} // if
			break;

		// the ajaxed results for cms pages
		case 'admin_extend':	// output app js and css files
			$cms_app_name = Ccms::get_or_post('app_name');
			if($cms_app_def = Ccms_apps::get_app_extend_body($cms_app_name)) {
				if((!empty($cms_app_def['cms_body_dir'])) && (is_dir($cms_app_def['cms_body_dir']))) {
					if(isset($cms_app_def['app_css'])) {
						$text[] = self::get_head_CSS_url($cms_app_def['app_css']);
						} // if
					if(isset($cms_app_def['app_scss'])) {
						$text[] = self::get_head_CSS_url($cms_app_def['app_scss']);
						} // if
					if(isset($cms_app_def['app_js'])) {
						$text[] = self::get_head_JS_url($cms_app_def['app_js']);
						} // if
					} // if
				} // if
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
			break;
		case 'cms_edit_search':
		case 'cms_debug_code':
		case 'cms_debug_vars':
		case 'cms_log_view':
		case 'cms_browse_sessions':
		case 'cms_users_stats':
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
			break;
		default:
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
			if(((int)self::$cms_body_id > 0) || (self::get_app_action() == 'body_extend')) {	//include the app css and js if present
				$body_defines = &self::get_bodies_defines();
				if(isset($body_defines[self::$cms_body_id])) {
					$body_define = &$body_defines[self::$cms_body_id];
					if(isset($body_define['app_css'])) {
						$text[] = self::get_head_CSS_url($body_define['app_css']);
						} // if
					if(isset($body_define['app_scss'])) {
						$text[] = self::get_head_CSS_url($body_define['app_scss']);
						} // if
					if(isset($body_define['app_js'])) {
						$text[] = self::get_head_JS_url($body_define['app_js']);
						} // if
					} // if
				} // if
			else if((Ccms_base::is_cms_action()) || (Ccms_base::is_page_done())) break;
			else if((LM_C_USE_LM_AS_HOME) &&
				(empty(Ccms::$cms_body_id)) &&
				(Ccms_sm::is_links_manager_inuse())) {
				// $text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
				$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_lm.js',false);
				} // else if
			break;
			} // switch
			
//		switch(self::get_app_action()) {
//		case 'lm_show_links':
//			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_body_funcs.js',false);
//			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_lm.js',false);
//			break;
//		default:
//			break;
//			} // switch

		if(self::use_tooltips()) {
			$text[] = self::get_head_JS_url(CMS_WS_JAVASCRIPT_DIR . 'cms_title_tooltips.js',false);
			} // if

		$text[] = Ccms_apps::output_apps_js(false);

		if(self::is_cms_group_manager()) {
			$text[] = self::get_head_CSS_url(CMS_WS_STYLESHEETS_DIR . 'cms_admin.css',false);
			$text[] = self::get_head_CSS_url(CMS_WS_STYLESHEETS_DIR . 'cms_admin_pdb.css',false);
			} // if
		else if(self::is_admin_action()) {	// it's an admin type page
			$text[] = self::get_head_CSS_url(CMS_WS_STYLESHEETS_DIR . 'cms_admin.css',false);
			} // if
//		else if((Ccms::show_nav_bar()) && (self::is_cms_group_manager())) {
//			$text[] = self::get_head_CSS_url(CMS_WS_STYLESHEETS_DIR . 'cms_admin_pdb.css',false);
//			} // else if

		$text[] = Ccms_html::get_clientMeta_sender();
		if(strlen(CMS_C_LOGO_IMAGE) > 4) {
			if(is_readable(CMS_C_LOGO_IMAGE)) $img = CMS_C_LOGO_IMAGE;
			else $img = ETC_WS_IMAGES_DIR . CMS_C_LOGO_IMAGE;
			$text[] = '		<link rel="preload" as="image" href="' . $img . '">';
			} // if

		if(!empty($app_head)) {
			if(is_array($app_head)) {
				foreach($app_head as $t => &$v) {
					switch($t) {
					case 'title':	// done already
					case 'base':	// not used
						break;
					case 'script':
						$text[] = '<' . $t . ' ' . $v . '></' . $t . '>';
						break;
					case 'mata':
					case 'link':
					default:
						$text[] = '<' . $t . ' ' . $v . '>';
						break;
						} // switch
					} // foreach
				} // if
			else {
				$text[] = $app_head;
				} // else
			} // if

		$text[] = '	</head>';

		if(CMS_S_ANALYTICS_EXT_INHEAD_BOOL) {
			ob_start();
			Ccms::do_analytics_include();
			$text[] = ob_get_clean();
			} // if

		$head = PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $head;
		return $head;
		} // output_head()

	public static function chk_bld_crit_dirs($bld = true) {
		if(!$bld) $bld = self::is_rebuild();
		$crit_dirs_check_list = array(	// critical read/write paths

			VAR_FS_DIR,	// worrying
			VAR_FS_APPS_DIR,
			VAR_FS_AUTH_DIR,
			VAR_FS_LOGS_DIR,
			VAR_FS_BACKUP_DIR,
			VAR_FS_CACHE_DIR,
			VAR_FS_CACHE_APPS_DIR,
			VAR_FS_CACHE_CONTENTS_DIR,
			VAR_FS_CACHE_GOTCHA_DIR,
			VAR_FS_CACHE_MINIFY_DIR,
			VAR_FS_EXPORT_DIR,
			VAR_FS_RUN_DIR,
			VAR_FS_SESSION_DIR,
			VAR_FS_TEMP_DIR,
			VAR_FS_TRASH_DIR,
			VAR_FS_VARIABLES_DIR,
			VAR_FS_USERS_DIR,
			VAR_FS_PROXY_DIR,
			VAR_FS_API_KEYS_DIR,

			ETC_FS_DIR,	// very worrying
			ETC_FS_EXT_INCLUDES_DIR,
			ETC_FS_IMAGES_DIR,
			ETC_FS_BACKGROUNDS_DIR,
			ETC_FS_IMAGES_DIR,
			ETC_FS_ICONS_DIR,
			ETC_FS_INI_DIR,
			ETC_FS_CSS_DIR,
			ETC_FS_SQLITE_DIR,	// for CMS_S_DB_SQLITE_DATABASE,

			ETC_FS_SITE_DATA_DIR,

			LOCAL_FS_TOOLS_DIR,
			LOCAL_FS_TOOLS_IMAGES_DIR,
			LOCAL_FS_TOOLS_ICONS_DIR,
			);
		if(!self::is_apps_readonly()) {
			$crit_dirs_check_list = arraY_merge($crit_dirs_check_list,
				array(
					APPS_BODIES_FS_DIR,
					APPS_FS_DIR,
					APPS_FS_ICONS_DIR,
					APPS_FS_IMAGES_DIR,
					APPS_FS_INCLUDE_DIR,
					APPS_FS_PLUGINS_DIR,
					APPS_FS_CLASSES_DIR,
					APPS_FS_DOCS_DIR,
					APPS_FS_INI_DIR,
					));
			} // if
		$ok = true;
		foreach($crit_dirs_check_list as $vd) {
			if(!self::chkdir($vd,$bld)) {
				$ok = false;
				self::addMsg('Cannot create "' . substr($vd,strlen(DOCROOT_FS_BASE_DIR)) . '" directory.');
				} // if
			// else ok
			} // foreach
		return $ok;
		} // chk_bld_crit_dirs()

	private static function chk_bld_crit_files($touch = true) {

		$files_r_check_list = array(	// read files
			CMS_FS_CMS_CONFIG_MSGS,
			CMS_FS_CMS_CONFIG_DEFAULT,
			);

		$files_rw_check_list = array(	// read/write file
			ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE => array(),
			ETC_FS_CSS_DIR . 'cms_styles_main.css' => array( 'func' => 'Ccms::reload_ini_default_settings'),
			ETC_FS_CSS_DIR . 'cms_styles_block.css' => array( 'func' => 'Ccms::reload_ini_default_settings'),
			ETC_FS_CSS_DIR . 'cms_styles_inline.css' => array( 'func' => 'Ccms::reload_ini_default_settings'),
			);

		$ok = true;

		foreach($files_r_check_list as $f) {
			if(!file_exists($f)) {
				self::addMsg('Readonly file . "' . $f . '" does not exist.');
				$ok = false;
				} // if
			else if(!is_readable($f)) {
				self::addMsg($f . ' is not readable.');
				$ok = false;
				} // if
			// else ok
			} // foreach

		foreach($files_rw_check_list as $f => &$op) {
			if(!file_exists($f)) {
				if(isset($op['func'])) {
					$func = $op['func'];
					if($func()) continue;
					} // if
				self::addMsg('RW File . "' . $f . '" does not exist.',($touch ? 'warning':''));
				$ok = false;
				} // if
			else if(!is_writable($f)) {
				if(!self::chmod_chown($f)) {
					self::addMsg('File "' . $f . '" is not writeable.');
					$ok = false;
					} // if
				} // if
			// else ok
			} // foreach

		if(!self::is_apps_readonly()) {
			// help squashfs understand mountings
			$chk_seed_fileslist = array(
				PAGE_HEADER_FS_INC => '<p>Default seed code</p><p>Add include code or text here.</p>',
				PAGE_FOOTER_FS_INC => '<p>Default seed code</p><p>Add include code or text here.</p>',
				);
			foreach($chk_seed_fileslist as $f => &$v) {
				if(!file_exists($f)) {
					if((!file_put_contents($f,$v)) || (!self::chmod_chown($f))) {
						$ok = false;
						self::addMsg('Cannot seed "' . substr($f,strlen(DOCROOT_FS_BASE_DIR)) . '" file.');
						} // if
					} // if
				// else ok
				} // foreach
			} // if

		return $ok;
		} // chk_bld_crit_files()

	private static function chk_dir_defines() {
		$defines = get_defined_constants(true);
		if(!isset($defines['user'])) return true;

		// find all the var/ directory settings and check they exist
		$user_d = &$defines['user'];
		$ok = true;
		$dir_bases = array(
			APPS_WS_DIR,
			VAR_WS_DIR,
			);
		foreach($dir_bases as $bd) {
			$prefix = DOCROOT_FS_BASE_DIR . $bd;
			$prefix_len = strlen($prefix);
			reset($user_d);
			foreach($user_d as $k => &$v) {
				if((substr($v,-1) == '/') && (substr($v,0,$prefix_len) == $prefix)) {	// use preg_match instead ???
					if(!self::chkdir($v,true)) {
						self::log_msg('Failed to create "' . $v . '" (1).');
						$ok = false;
						} // if
					// too much else self::log_msg('"' . $v . '" ok (1).','info');
					} // if
				else if((substr($v,-1) == '/') && (substr($v,0,strlen($bd)) == $bd)) {	// use preg_match instead ???
					$dir = DOCROOT_FS_BASE_DIR . $v;
					if(!self::chkdir($dir,true)) {
						self::log_msg('Failed to create "' . $v . '" (2).');
						$ok = false;
						} // if
					// too much else self::log_msg('"' . $v . '" ok (2).','info');
					} // if
				} // foreach
			} // foreach
		return $ok;
		} // chk_dir_defines()

	public static function do_install_warnings_func_chks($func_class_chk_list) {
		$ok = true;
		foreach($func_class_chk_list as $f) {
			$type = 'error';
			if((!empty($f['type']))) $type = $f['type'];
			if($type != 'error') $install_msg = ' install recommended.';
			else $install_msg = ' to be installed.';
			if((isset($f['func'])) &&
				(!function_exists($f['func']))) {
				if(empty($f['msg']))
					self::addMsg('System Function: ' . $f['func'] . '() not installed. Needs ' . $f['needs'] . $install_msg,$type);
				else self::addMsg('System Function: ' . $f['func'] . '() not installed. ' . $f['msg'] . '',$type);
				if($type == 'error') $ok = false;
				} // if
			if((isset($f['class'])) &&
				(!class_exists($f['class'],false))) {
				if(empty($f['msg']))
					self::addMsg('System Class: ' . $f['class'] . ' not installed. Needs ' . $f['needs'] . $install_msg,$type);
				else self::addMsg('System Class: ' . $f['class'] . '() not installed. ' . $f['msg'] . '',$type);
				if($type == 'error') $ok = false;
				} // if
			if(isset($f['cli'])) {
				if(Ccms_posix::is_windows()) continue;
				$result = '';
				$output = '';
				exec('which ' . $f['cli'], $output, $result);
				if($result) {
					if(empty($f['msg']))
						self::addMsg('System command not installed: Needs ' . $f['needs'] . '.',$type);
					else self::addMsg('System command not installed: ' . $f['needs'] . '. ' . $f['msg'] . '',$type);
					if($type == 'error') $ok = false;
					} // if
				} // if
			if((isset($f['module'])) && (function_exists('apache_get_modules'))) {
				// $modules = apache_get_modules();	// debug
				$found = array_filter(apache_get_modules(), function($d) use ($f) {	// find module
					if(stripos($d,$f['module']) !== false) return true;	// found
					return false;
					});
				if(empty($found)) {
					if(empty($f['msg']))
						self::addMsg('System module not installed: Needs ' . $f['needs'] . '.',$type);
					else self::addMsg('System module not installed: ' . $f['needs'] . '. ' . $f['msg'] . '',$type);
					if($type == 'error') $ok = false;
					} // if
				} // if
			} // foreach
		return $ok;
		} // do_install_warnings_func_chks()

	public static function do_cms_cli_warnings($chk_flg = false) {
		if(!self::is_cli()) return true;
		$ok = true;
		if($chk_flg) {
			$func_class_chk_list = array(
				array(
					'cli' => 'dialog',	// complete test command (empty = fail)
					'needs' => 'System package: dialog. Not installed, required for CLI diaplog boxes.',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'cli' => 'fusermount',	// complete test command (empty = fail)
					'needs' => 'System package: fuse. Not installed, fusemount required for ' . CMS_PROJECT_SHORTNAME . ' read only operation.',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'cli' => 'squashfuse',	// complete test command (empty = fail)
					'needs' => 'System package: squashfuse. Not installed, squashfuse required for ' . CMS_PROJECT_SHORTNAME . ' read only operation.',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
//				array(
//					'cli' => 'geoipupdate',	// complete test command (empty = fail)
//					'needs' => 'System packages : GeoIP, GeoIP-Data and geoipupdate recommended for ' . CMS_PROJECT_SHORTNAME . ' location data.',
//					'type' => 'warn',	// default is 'error', are the same as addMsg()
//					),
//				array(
//					'func' => 'ncurses_init',	// not reliable
//					'needs' => 'PECL nurses or System pkg php-pecl-ncurse',	// not reliable
//					),
//				array(
//					'cli' => 'sassc',	// complete test command (empty = fail)
//					'needs' => 'System package: sassc. Not installed, sassc stylesheet compiler required for ' . CMS_PROJECT_SHORTNAME . ' .sass stylesheet source code intergration.',
//					'type' => 'warn',	// default is 'error', are the same as addMsg()
//					),
				);
			$ok &= self::do_install_warnings_func_chks($func_class_chk_list);
			} // if
		return $ok;
		} // do_cms_cli_warnings()

	public static function chk_docroot_htaccess() {
		// if(self::is_cli()) return true;	// not docroot
		$rw_base = self::clean_path('/' . DOCROOT_WS_BASE_DIR . '/');
		$ht = DOCROOT_FS_BASE_DIR . '.htaccess';
		if(is_readable($ht)) {
			$pat = 'RewriteBase\s+' . preg_quote($rw_base,'/');
			if(preg_match('/' . $pat . '/im',file_get_contents($ht))) return true;	// ok
			} // if
		// else no good
		$ht_text_inc = self::get_rewrite_htaccess_text();
		self::addMsg('Need this text added near the top of "' . $ht . '" = "' . $ht_text_inc . '".','warn');
		return false;
		} // chk_docroot_htaccess

	public static function rebuild_docroot_htaccess($new_vals = null) {
		$htaccess_new = Ccms::get_rewrite_htaccess_text(true,$new_vals);
		$htaccess_file = DOCROOT_FS_BASE_DIR . '.htaccess';
		if(!file_put_contents($htaccess_file,$htaccess_new)) {
			self::addMsg('Failed to write: ' . $htaccess_file);
			return false;
			} // if
		return true;
		} // rebuild_docroot_htaccess()

	private static function get_recent_key_value(&$new_vals, $key) {
		// $new_vals are the current saved vals (ie not yet defined)
		if((!empty($new_vals)) &&
			(!empty($new_vals[$key]))) {
			$val = self::conv_conf_val_to_type($new_vals[$key]);
			return $val;
			} // if
		if(defined($key)) return constant($key);
		self::addAdminMsg('Key: ' . $key . ' is not defined.');
		return false;
		} // get_recent_key_value

	public static function get_rewrite_htaccess_text($auto_flg = false,$new_vals = null) {
		$lg_name = CMS_PROJECT_NAME;
		$sh_name = CMS_PROJECT_SHORTNAME;
		$name_sig = CMS_PROJECT_SHORTNAME;
		$proj_name = CMS_PROJECT_SHORTNAME;
		$proj_ver = CMS_PROJECT_VERSION;
		$gen_type = ($auto_flg ? 'automatically inserted':'for manual insertion');
		$filepath = '(DOCROOT)/.htaccess';

		// Note: $new_vals contains the most recent changes
		$api_q_name = self::get_recent_key_value($new_vals, 'CMS_C_API_REWRITE_NAME');
		$api_enabled = self::get_recent_key_value($new_vals, 'CMS_C_API_ENABLE');

		$ws_enabled = self::get_recent_key_value($new_vals, 'CMS_S_WS_REDIR_ENABLE_BOOL');
		$ws_ip = self::get_recent_key_value($new_vals, 'CMS_S_WS_REDIR_SVR_IP');
		$ws_socks_port = self::get_recent_key_value($new_vals, 'CMS_S_WS_REDIR_PORT');

		$ht_text_inc = '';

		if($auto_flg) {	// put on header
			$ht_text_inc .= <<< EOTAUTO

#	{$lg_name} ({$sh_name}).
#	see Licence in cms/LICENCE.txt
#	_SVN_build: \$Id\$

# NOTE: access to sub-directories from .htaccess is not possible and
# need a seperate .htaccess file in the directory requiring accessibility options

EOTAUTO;
			} // if

		$ht_text_inc .= <<< EOTTOP

########### {$name_sig} {$filepath} insert begin #########################
#
# Generated by {$proj_name} {$proj_ver} from configuration/settings and {$gen_type} into {$filepath}

# ensure PHP handler is engaged
<FilesMatch \.php>
	SetHandler application/x-httpd-php
</FilesMatch>

DirectoryIndex index.php

<IfModule mod_security.c>
	SecFilterEngine Off
	SecFilterScanPOST Off
</IfModule>

<IfModule mod_rewrite.c>

	RewriteEngine On
	# RewriteCond %{HTTPS} off
	# RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

EOTTOP;

		if($api_enabled) {
			$ht_text_inc .= <<< EOTAPI

	# redirect all api calls to /api.php
	RewriteCond %{REQUEST_URI} !/api\.php
	RewriteCond %{REQUEST_URI} /api/
	RewriteRule ^api/(.*)$ api.php?{$api_q_name}=$1 [QSA,L]
	# Note: query name, "{$api_q_name}", is set Admin -> Config -> CMS_C_API_REWRITE_NAME

EOTAPI;
		} // if
	else {
			$ht_text_inc .= <<< EOTAPIN

	# API disabled

EOTAPIN;
		} // else

		if($ws_enabled) {
			$ht_text_inc .= <<< EOTWS

	# redirect/upgrade client websocket connections
	# optional need firewall {$ws_socks_port} port opened for non local redirect
	RewriteCond %{SERVER_PORT} "-eq {$ws_socks_port}"
	RewriteCond %{HTTP:Connection} Upgrade [NC]
	RewriteCond %{HTTP:Upgrade} websocket [NC]
	RewriteRule /(.*) ws://{$ws_ip}:{$ws_socks_port}/$1 [P,L]
	# Note: ws_ip and port need to the same as configured in Admin -> Install -> WS_REDIR_SVR_IP and WS_REDIR_HTTP_PORT

EOTWS;
		} // if
	else {
			$ht_text_inc .= <<< EOTWSN

	# Websockets disabled

EOTWSN;
		} // else

		$ht_text_inc .= <<< EOTBOT

	# If the request is a file, folder or symlink that exists, serve it up
	# else direct to index.php
	RewriteCond %{REQUEST_FILENAME} !-f
	RewriteCond %{REQUEST_FILENAME} !-l
	RewriteCond %{REQUEST_FILENAME} !-d
	RewriteRule .* index.php [L]

</IfModule>

# running "./cms_lib_sqsh.sh --rebuild-all" in the (DOCROOT)/ directory will set all directories .htaccess files and index the class autoload data.
# no need to limit access at (DOCROOT)/ here
<Files "*">
	Require all granted
</Files>

########## {$name_sig} {$filepath} insert end ##########################

EOTBOT;

		if($auto_flg) {	// put on header
			$ht_text_inc .= <<< EOTAUTO2

# EOF

EOTAUTO2;
		} // if

		return $ht_text_inc;
		} // get_rewrite_htaccess_text()

	public static function do_cms_warnings($chk_flg = false) {
		if(self::is_rebuild()) {
			$chk_flg = true;
			self::build_css_stylesheets();
			} // if
		if((!$chk_flg) && (!CMS_S_INSTALLATION_WARNINGS_BOOL)) return true;
		$ok = true;
//		$ok = self::chk_docroot_htaccess();

		if($chk_flg) {
			self::log_msg((Ccms_auth::is_cms_admin_user () ? 'Admin ':'') . 'Installation Check.','info');
			} // if
		$ok &= self::chk_bld_crit_files();
		if(!self::chk_dir_defines()) $ok = false;

		if($chk_flg) {
			$func_class_chk_list = array(
				array(
					'func' => 'mb_strlen',
					'needs' => 'php[n]-mbstring',
					),
				array(
					'func' => 'geoip_country_name_by_name',
					'needs' => 'PECL geoip >= 1.0 or System pkg php[n]-pecl-geoip or pecl install geoip',
					'msg' => ' Recommended for geoip lookup.',
					'type' => 'info',	// default is 'error', are the same as addMsg()
					),
				array(
					'func' => 'shmop_open',
					'needs' => 'php[n]-shmop',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'func' =>'json_decode',
					'needs' => 'php[n]-json',
					),
				array(
					'func' =>'posix_getgrgid',
					'needs' => 'php[n]-posix or php[n]-process',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
//				array(
//					'func' => 'posix_getpwuid',
//					'needs' => 'php[n]-posix or php[n]-process',
//					'type' => 'warn',	// default is 'error', are the same as addMsg()
//					),
				array(
					'func' => 'curl_init',
					'needs' => 'php[n]-curl',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'func' => 'ldap_connect',
					'needs' => 'php[n]-ldap',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					'msg' => 'Requires php[n]-ldap for LDAP login.',
					),
				array(
					'func' => 'imagecreate',
					'needs' => 'php[n]-gd',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					'msg' => 'Requires php[n]-gd for image manipulation.',
					),
				array(
					'func' => 'locale_accept_from_http',
					'needs' => 'php[n]-intl',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'class' => 'SQLite3',
					'needs' => 'php[n]-sqlite (or include/enable extension)',
					),
				array(
					'class' => 'finfo',
					'needs' => 'php[n]-fileinfo or pecl install fileinfo',
					),
				array(
					'class' => 'gzfile',
					'needs' => 'php[n]-gzip or php-pecl-zip (or include/enable extension)',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'class' => 'DOMDocument',
					'needs' => 'php[n]-doc (or include/enable extension)',
					'type' => 'err',	// default is 'error', are the same as addMsg()
					),
				array(
					'class' => 'ZipArchive',
					'needs' => 'php[n]-zlib (or include/enable extension)',
					),
				array(
					'function' => 'mysqli_init',
					'needs' => 'php[n]-mysql or php[n]-mysqlnd (or include/enable extension)',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'function' => 'iconv',
					'needs' => 'php[n]-iconv',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'function' => 'ctype_digit',
					'needs' => 'php[n]-ctype for client browser meta data.',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					),
				array(
					'class' => 'tidy',
					'needs' => 'php[n]-tidy (or include/enable extension)',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					'msg' => 'Recommended php[n]-tidy for WYSIWYG editing and debugging.',
					),
				array(
					'func' => 'socket_create',
					'needs' => 'php[n]-sockets',
					),
				array(
					'func' => 'posix_access',
					'needs' => 'php[n]-posix and php[n]-intl',
					),
				array(
					'module' => 'rewrite',	// mod_rewrite on OS15, rewrite_module on C8
					'needs' => 'Apache rewrite module to be enabled',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					'msg' => 'Required for API and webockets operation.',
					),
				array(
					'func' => 'openssl_sign',
					'needs' => 'php[n]-openssl or php[n]-ssl',
					),
				);
			if(CMS_S_PAM_AUTH_ENABLED_BOOL) {
				$func_class_chk_list[] = array(
					'func' => 'pam_auth',
					'needs' => 'pecl install pam',
					'type' => 'warn',	// default is 'error', are the same as addMsg()
					'msg' => 'Need PECL pam for PAM/system authentication.',
					);
				} // if
			$ok &= self::do_install_warnings_func_chks($func_class_chk_list);
			} // if

		if((!self::is_cli()) &&
			(defined('CMS_C_WYSIWYG_EDITOR')) &&	// can be defined later
			(!Ccms_wysiwyg::is_wysiwyg_available())) {
			self::log_msg('No WYSIWYG configured.','warning');
			// $ok = false;
			} // if

		if((!$chk_flg) && ($ok)) self::getMsgs();	// no error clear it
		if(($chk_flg) && (!Ccms_posix::is_windows())) {
//			if(is_writable(CMS_FS_INCLUDES_DIR . 'cms_configure.php')) {
//				self::addMsg(CMS_FS_INCLUDES_DIR . 'cms_configure.php is writeable.','warning');
//				// $ok = false;
//				}
			if($ok) self::log_msg('No install issues detected.','info');
			} // if
		return $ok;
	} // do_cms_warnings()

	public static function clean_orphaned_settings($clean_old_apps_sections = false) {
		if(!self::is_rebuild()) return false;	// only when rebuilding

		// do AppsCMS first
		$cms_settings = self::read_cms_ini_settings();	// will also put in missing values
		$cms_comments = self::read_cms_ini_comments();
		$orphan_cnt= 0;
		$clean_settings = array();
		foreach($cms_settings as $sect_name => $sect) {
			if(!isset($cms_comments[$sect_name])) {
				self::addMsg('Removed orphaned cms settings section "' . $sect_name . '".','info');
				$orphan_cnt++;
				continue;
				} // if
			foreach($sect as $k => $v) {
				if(!isset($cms_comments[$sect_name][$k])) {
					self::addMsg('Removed orphaned cms settings section "' . $sect_name . '", key "' . $k . '".','info');
					$orphan_cnt++;
					continue;
					} // if
				$clean_settings[$sect_name][$k] = $v;
				} // foreach
			} // foreach
		self::save_cms_ini_settings($clean_settings,true);
		self::addMsg('Removed ' . $orphan_cnt . ' cms orphaned settings.','info');

		// clean apps settings orphans
		$cms_apps_settings = Ccms_apps::read_apps_ini_settings();
		$cms_apps_comments = Ccms_apps::read_apps_ini_comments();
		if(!$cms_apps_settings) return false;
		$orphan_cnt= 0;
		$clean_settings = array();
		foreach($cms_apps_settings as $sect_name => $sect) {
			if(($clean_old_apps_sections) && (!isset($cms_apps_comments[$sect_name]))) {
				self::addMsg('Removed orphaned apps settings section "' . $sect_name . '".','info');
				$orphan_cnt++;
				continue;
				} // if
			// else it maybe an old app settings
			foreach($sect as $k => $v) {
				if(!isset($cms_apps_comments[$sect_name][$k])) {
					self::addMsg('Removed orphaned apps settings section "' . $sect_name . '", key "' . $k . '".','info');
					$orphan_cnt++;
					continue;
					} // if
				$clean_settings[$sect_name][$k] = $v;
				} // foreach
			} // foreach
		Ccms_apps::save_apps_ini_settings($clean_settings,true);
		self::addMsg('Removed ' . $orphan_cnt . ' apps orphaned settings.','info');

		return true;
	} // clean_orphaned_settings()

	public static function make_nice_name($ini_key, $delim = '_', $substitutes = null) {	// turns "MAGE_IMPORT_CHANGED_ONLY_BOOL_BOOL" into "Mage Continue Import"
		if(is_array($substitutes)) $subs = $substitutes;
		else {
			$subs = array(
				'DB' => 'DB',	// keep same
				'WS' => 'WS',	// keep same
				'BOOL' => '',	// remove type at end of $ini_key
				'TZ' => '', // remove type at end of $ini_key
				'CMS_C_' => 'CMS_CONFIG_',	// pretty it a bit
				'AuthSettings' => 'AuthenticationSettings',	// pretty it a bit
				);
			} // else
		if(preg_match('/^[a-z]+[A-Z]+[a-z]*$/',$ini_key)) return $ini_key;	// careful with these sort of words
		if(preg_match('/^[A-Z]+$/',$ini_key)) return $ini_key;	// careful with these sort of words

		$ini_key = str_replace(array_keys($subs),array_values($subs),$ini_key);
		$name = '';
		// deliniate camel case with underscore
		$ini_key = preg_replace('/([a-z])([A-Z][a-z])/','$1' . $delim . '$2',$ini_key);
		$words = explode($delim,$ini_key);
		if((!is_array($words)) || (count($words) < 2)) return trim($ini_key);
		self::array_trim($words);
		foreach($words as $word) {
			if(!empty($name)) $name .= ' ';
			if(isset($subs[$word])) $name .= $subs[$word];
			else if(preg_match('/^[a-z]+[A-Z]+[a-z]*$/',$word)) $name .= $word;	// careful with these sort of words
			else $name .= ucwords(strtolower($word));	// make proper noun
			} // foreach
		return trim($name);
	} // make_nice_name()

	public static function unmake_hungarion_fmt($str) {
		// @TODO left over from older sibling ????
		return self::make_nice_name($str);
//		$text = '';
//		$idx = 0; $spFlg = true; $c_l = '';
//		while($idx < strlen($str)) {
//			$c = substr($str,$idx++,1);
//			if(strlen($text) > 0) {
//				if($c == '_' || $c == '-') {
//					if(!$spFlg || $c_l != ' ') {	// only one space
//						$text .= ' ';
//						$spFlg = true;
//						} // if
//					$c_l = ' ';
//					continue; // dont add $c
//					} // if
//				else if($c >= 'A' && $c <= 'Z' && ($c_l < 'A' || $c_l > 'Z')) {
//					if(!$spFlg) {	// only one space
//						$text .= ' ';
//						$spFlg = true;
//						} // if
//					// add $c
//					} // if
//				else $spFlg = false;
//				} // if
//			$c_l = $c;
//			$text .= $c;
//			} // while
//		return $text;
	} // unmake_hungarion_fmt()

	public static function get_body_description($cms_body_id, $name, $description, $expand = true) {
		if(!$expand) {
			if(empty($description)) return '(empty)';
			else if(file_exists(DOCROOT_FS_BASE_DIR . $description)) {
				// return self::make_message_text('Filename: &quot;' . $description . '&quot; OK.','info');
				return 'Filename mode: &quot;' . $description . '&quot; OK.';
				} // else if
			else if(preg_match('/^[a-z_]+::[a-z_]+/i',$description)) {
				if($func = self::get_inc_method_callback($description)) {
					try {
						$text = @$func($cms_body_id,$name);
						// return self::make_message_text('Callback Method: &quot;' . $description . '&quot; OK.','info');
						return 'Callback mode: &quot;' . $description . '&quot; OK.';
					} catch (Exception $ex) {
						return self::make_message_text('Callback Method failed: &quot;' . $func . '&quot;.','warn');
						}
					} // if
				else {
					return self::make_message_text('Callback Method not found: &quot;' . $description . '&quot;.', 'warn');
					} // else
				} // else if
			// return self::make_message_text('Default Text:<br>&quot;' . nl2br($description) . '&quot;.','info');
			return 'Text mode: &quot;' . nl2br($description) . '&quot;';
			} // if

		if(empty($description)) return '';	// nothing
		else if(file_exists(DOCROOT_FS_BASE_DIR . $description)) {
			ob_start();
			include($description);
			$text = ob_get_clean();
			return $text;
			} // else if
		else if($func = self::get_inc_method_callback($description)) {
			try {
				$text = @$func($cms_body_id,$name);
				return $text;
			} catch (Exception $ex) {
				self::addMsg('Failed to call "' . $func . '(id,name)".');
				return '';
				}
			} // else if
		return '<p>' . preg_replace('/\n/','</p><p>',$description) . '</p>';
		} // get_body_description()

	public static function get_time_zones() {
		$timezones = timezone_identifiers_list();

		// include the aliases from "https://en.wikipedia.org/wiki/List_of_tz_database_time_zones"
		$aliases = array(
			'Africa/Addis_Ababa',
			'Africa/Asmara',
			'Africa/Bamako',
			'Africa/Bangui',
			'Africa/Banjul',
			'Africa/Blantyre',
			'Africa/Brazzaville',
			'Africa/Bujumbura',
			'Africa/Conakry',
			'Africa/Dakar',
			'Africa/Dar_es_Salaam',
			'Africa/Djibouti',
			'Africa/Douala',
			'Africa/Freetown',
			'Africa/Gaborone',
			'Africa/Harare',
			'Africa/Kampala',
			'Africa/Kigali',
			'Africa/Kinshasa',
			'Africa/Libreville',
			'Africa/Lome',
			'Africa/Luanda',
			'Africa/Lubumbashi',
			'Africa/Lusaka',
			'Africa/Malabo',
			'Africa/Maseru',
			'Africa/Mbabane',
			'Africa/Mogadishu',
			'Africa/Niamey',
			'Africa/Nouakchott',
			'Africa/Ouagadougou',
			'Africa/Porto-Novo',
			'Africa/Sao_Tome',
			'Africa/Timbuktu',
			'America/Anguilla',
			'America/Antigua',
			'America/Argentina/ComodRivadavia',
			'America/Aruba',
			'America/Atka',
			'America/Buenos_Aires',
			'America/Catamarca',
			'America/Cayman',
			'America/Coral_Harbour',
			'America/Cordoba',
			'America/Dominica',
			'America/Ensenada',
			'America/Fort_Wayne',
			'America/Grenada',
			'America/Guadeloupe',
			'America/Indianapolis',
			'America/Jujuy',
			'America/Knox_IN',
			'America/Kralendijk',
			'America/Louisville',
			'America/Lower_Princes',
			'America/Marigot',
			'America/Mendoza',
			'America/Montreal',
			'America/Montserrat',
			'America/Porto_Acre',
			'America/Rosario',
			'America/Santa_Isabel',
			'America/Shiprock',
			'America/St_Barthelemy',
			'America/St_Kitts',
			'America/St_Lucia',
			'America/St_Thomas',
			'America/St_Vincent',
			'America/Tortola',
			'America/Virgin',
			'Antarctica/McMurdo',
			'Antarctica/South_Pole',
			'Arctic/Longyearbyen',
			'Asia/Aden',
			'Asia/Ashkhabad',
			'Asia/Bahrain',
			'Asia/Calcutta',
			'Asia/Chongqing',
			'Asia/Chungking',
			'Asia/Dacca',
			'Asia/Harbin',
			'Asia/Istanbul',
			'Asia/Kashgar',
			'Asia/Katmandu',
			'Asia/Kuwait',
			'Asia/Macao',
			'Asia/Muscat',
			'Asia/Phnom_Penh',
			'Asia/Rangoon',
			'Asia/Saigon',
			'Asia/Tel_Aviv',
			'Asia/Thimbu',
			'Asia/Ujung_Pandang',
			'Asia/Ulan_Bator',
			'Asia/Vientiane',
			'Atlantic/Faeroe',
			'Atlantic/Jan_Mayen',
			'Atlantic/St_Helena',
			'Australia/Canberra',
			'Australia/Yancowinna',
			);
		reset($timezones);
		$timezones = array_merge($timezones,$aliases);
//		foreach($aliases as $tz) {
//			if(!in_array($tz, $timezones)) {
//				$timezones[] = $tz;
//				} // foreach
//			} // if
		sort($timezones);
		return $timezones;
		} // get_time_zones()

	public static function get_charsets() {
		$charsets = array(	// html5 only
		//	'ASCII',
		//	'ANSI',
			'ISO-8859-1',	// must be in <head> as '<meta charset="ISO-8859-1">'
			'UTF-8',
			'UTF-16',
			);
		return $charsets;
		} // get_charsets()

	public static function get_group_ids_text($cms_group_ids,$only_enabled = true,$type = 'User ') {
		$ids = explode(':',$cms_group_ids);
		$text = $type;
		foreach($ids as $id) {
			if(!empty($text)) $text .= ', ';
			if((int)$id == 0) $text .= 'All Groups';
			else {
				$name = self::$cDBcms->get_data_in_table('cms_groups','cms_group_name','cms_group_id = ' . $id . ($only_enabled ? ' cms_group_enabled > 0':''));
				if((!$only_enabled) && (Ccms_auth::is_cms_admin_user())) {
					$text .= '<a href="index.php?cms_action=cms_edit_groups&group_edit_id=' . $id . '">' . $name . '</a>';
					} // if
				else $text .= $name;
				if((!$only_enabled) &&
					(!self::$cDBcms->get_data_in_table('cms_groups','cms_group_enabled','cms_group_id = ' . $id))) {
					$text .= ' (disabled)';
					} // if
				} // else
			} // foreach
		return $text;
		} // get_group_ids_text()

	public static function get_group_user_ids_text($cms_group_user_ids,$only_enabled = true) {
		$ids = explode(':',$cms_group_user_ids);
		$text = '';
		foreach($ids as $id) {
			if(!empty($text)) $text .= ', ';
			if((int)$id == 0) $text .= 'All users';
			else {
				$name = self::$cDBcms->get_data_in_table('cms_users','cms_user_name','cms_user_id = ' . $id . ($only_enabled ? ' cms_user_enabled > 0':''));
				if(!$only_enabled) {
					$text .= '<a href="index.php?cms_action=edit_user&user_edit_id=' . $id . '">' . $name . '</a>';
					} // if
				else $text .= $name;
				if((!$only_enabled) &&
					(!self::$cDBcms->get_data_in_table('cms_users','cms_user_enabled','cms_user_id = ' . $id))) {
					$text .= ' (disabled)';
					} // if
				} // else
			} // foreach
		return $text;
		} // get_group_user_ids_text()

	public static function get_group_manager_ids_text($cms_group_admin_ids,$only_enabled = true) {
		$ids = explode(':',$cms_group_admin_ids);
		$text = '';
		foreach($ids as $id) {
			if(!empty($text)) $text .= ', ';
			if((int)$id == 0) $text .= 'No group managers';
			else {
				$name = self::$cDBcms->get_data_in_table('cms_users','cms_user_name','cms_user_id = ' . $id . ($only_enabled ? ' cms_user_enabled > 0':''));
				if(!$only_enabled) {
					$text .= '<a href="index.php?cms_action=edit_user&user_edit_id=' . $id . '">' . $name . '</a>';
					} // if
				else $text .= $name;
				if((!$only_enabled) &&
					(!self::$cDBcms->get_data_in_table('cms_users','cms_user_enabled','cms_user_id = ' . $id))) {
					$text .= ' (disabled)';
					} // if
				} // else
			} // foreach
		return $text;
		} // get_group_manager_ids_text()

	public static function do_plugin_installs($cms_plugins = '', $verbose = false) {
		if((empty($cms_plugins)) && (defined('CMS_C_ENABLED_PLUGINS'))) $cms_plugins = CMS_C_ENABLED_PLUGINS;
		$ctl = new Ccms_config_funcs();
		$avail_plugins = $ctl->get_plugins($cms_plugins);

		// if(empty($cms_plugins)) return true;
		$nl = (self::is_cli() ? PHP_EOL:'<br>');
		if($verbose) echo $nl . "Installing/Updating plugins." . $nl;
		$cms_plugins = explode(':',$cms_plugins);
		foreach($avail_plugins as $cms_plugin) {
			if(empty($cms_plugin)) continue;	// blank in the config
			$class = 'C' . $cms_plugin['name'] . '_plugin';
			if(in_array($cms_plugin['name'],$cms_plugins)) {	// install
				$class::install();
				if($verbose) echo "Installed plugin: " . $class . $nl;
				} // if
			else {
				$class::uninstall();
				if($verbose) echo "Uninstalled plugin: " . $class . $nl;
				} // else
			} // foreach
		self::addMsg('Installed plugin configs for;- ' . PHP_EOL . implode(', ' . PHP_EOL,$cms_plugins) . '.', 'info');
		return true;
		} // do_plugin_installs()

//	public static function cnt_digits($digits_str) {
//		$idx = 0; $cnt = 0;
//		while($idx < strlen($digits_str)) {
//			if(is_numeric(substr($digits_str,$idx,1))) $cnt++;
//			$idx++;
//			} // while
//		return $cnt;
//		} // cnt_digits()

	public static function validate_phone_number(&$phone, $sep = false) {	// au for the moment @TODO others
		if(preg_match('/[a-zA-Z]+/',$phone)) return false;
		$num = preg_replace('/[^0-9]+/','',$phone);
		if(empty($sep)) $sep = (preg_match('/ /',$phone) ? ' ':'-');	// what's the preference
		$digits = strlen($num);	// self::cnt_digits($num);
		if(($digits < 6) || ($digits > 18)) {
			return false;
			} // if

		// format phone number
		if((preg_match('/^1[38]00/', $num)) && (strlen($num) >= 10)) { // 1300 or 1800 number
			$frt = substr($num,0,4);
			$mid = substr(substr($num,-6),0,3);
			$bck = substr($num,-3);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // if
		else if((substr($num,0,2) == '04') && (strlen($num) == 10)) { // mobile number
			$frt = substr($num,0,4);
			$mid = substr(substr($num,-6),0,3);
			$bck = substr($num,-3);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // else if
//		else if((substr($num,0,1) == '4') && (strlen($num) == 9)) { // mobile number (no 0)
//			$frt = '0' . substr($num,0,3);
//			$mid = substr(substr($num,-6),0,3);
//			$bck = substr($num,-3);
//			$phone = $frt . $sep . $mid . $sep . $bck;
//			} // else if
		else if((substr($num,0,2) == '13') && (strlen($num) == 6)) { // 13 number
			$frt = substr($num,0,2);
			$mid = substr(substr($num,-4),0,2);
			$bck = substr($num,-2);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,2) == '61') && (strlen($num) == 11)) {	// international
			$frt = substr($num,0,2);
			$std = substr($num,2,1);
			$mid = substr(substr($num,-8),0,4);
			$bck = substr($num,-4);
			$phone = '+' . $frt . $sep . $std . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,3) == '610') && (strlen($num) == 12)) {	// international
			$frt = substr($num,0,2);
			$std = substr($num,3,1);
			$mid = substr(substr($num,-8),0,4);
			$bck = substr($num,-4);
			$phone = '+' . $frt . $sep . $std . $sep . $mid . $sep . $bck;
			} // else if
		else if((substr($num,0,1) == '0') && (strlen($num) == 10)) { // std number
			$frt = substr($num,0,2);
			$mid = substr(substr($num,-8),0,4);
			$bck = substr($num,-4);
			$phone = $frt . $sep . $mid . $sep . $bck;
			} // else if
		else if(strlen($num) == 8) {	// local number
			$frt = substr($num,0,4);
			$bck = substr($num,-4);
			$phone = $frt . $sep . $bck;
			} // else
		else return false;

		return true;
	} // validate_phone_number()

	public static function get_code_errors() {	// get errors that are not normally displyed in debug
		if(!self::is_debug()) return '';

		$text = '';
		if(($prerr = preg_last_error()) != PREG_NO_ERROR) {	// regex error
			static $errtext;
			if (!isset($errtxt)) {
				$errtext = array();
				$constants = get_defined_constants(true);
				foreach ($constants['pcre'] as $c => $n) if (preg_match('/_ERROR$/', $c)) $errtext[$n] = $c;
				} // if
			$text .= array_key_exists($errcode, $errtext)? $errtext[$errcode] : '';
			} // if
		if(!empty($text)) self::addMsg($text);
		return $text;
		} // get_code_errors()

	public static function backup_settings_configs() {
		// @TODO the windows version
		$res = array(); $ret = array();
		exec(CMS_FS_CLI_DIR . 'cms_backup_settings.sh',$res,$ret);
		if(($ret == 0) && (!empty($res))) {	// ok
			self::addMsg('Backed up settings and configurations.','success');
			return true;
			} // if
		self::addMsg('Failed to back up settings and configurations.','warning');
		return false;
		} // backup_settings_configs()

	public static function backupOnSave() {
		// virtual place holder
		if(!CMS_S_DB_SQLITE_BACKUP_ON_SAVE_BOOL) return true;	// it's ok
		return self::$cDBcms->backupDatabase();
		} // backupOnSave()

	public static function locate_image_url4css($dest_dir,$img_path,$image) {
		// @TODO only simple for now, needs to check/optimise for path and css directories.
		if(empty($image)) return '';
		if(is_readable($image)) {	// directly readable
			$img_path = dirname($image) . '/';
			$image = basename($image);
			} // if
		else if(!is_readable($img_path . '/' . $image)) return '';

		// assumes that both parameters are referenced to the same location
		$cnt = substr_count($dest_dir, '/');
		$pre = str_repeat('../',$cnt);
		$dl = strlen($img_path);
		$chk = substr($image,0,$dl);
		if($chk == $img_path) {	// it from the from of the string
			$image = substr($image,$dl);
			$text = 'url("' . $pre . $img_path . $image . '")';
			} // if
		else $text = 'url("' . $pre . $img_path . $image . '")';
		return $text;
		} // locate_image_url4css()

	public static function get_password_chk_regex($strength = false,$minlen = false) {
		if(!$strength) $strength = CMS_S_PASSWORD_REQUIRED_REGEX;
		if(!$minlen) $minlen = LM_C_MIN_PASSWD_LEN;
		$strng_punc = '!@#$%^&*';
		// not needed inside []	$strng_punc = preg_quote($strng_punc);
		$password_regexs = array(
			'feeble' => array(
				'min' => (LM_C_MIN_PASSWD_LEN + 0),
				'reg' => '.*',
				'title' => 'Any characters (min of $minlen characters)',
				),
			'weak' => array(
				'min' => (LM_C_MIN_PASSWD_LEN + 0),
				'reg' => '(?=.*[0-9a-zA-Z])',
				'title' => 'Numbers, upper and lower case (min of $minlen characters)',
				),
			'medium' => array(
				'min' => (LM_C_MIN_PASSWD_LEN + 2),
				'reg' => '(?=.*\d)(?=.*[a-z])(?=.*[A-Z])',
				'title' => 'At least 1 number, 1 lowercase and 1 uppercase (min of $minlen characters)',
				),
			'strong' => array(
				'min' => (LM_C_MIN_PASSWD_LEN + 4),
				'reg' => '(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[' . $strng_punc . '])',
				'title' => 'At least 1 number, 1 lowercase, 1 uppercase and 1 of ' . htmlentities($strng_punc) . ' (min of $minlen characters)',
				),
			);
		if(!isset($password_regexs[$strength])) $strength = 'medium';
		if($minlen < $password_regexs[$strength]['min'])
			$minlen = $password_regexs[$strength]['min'];
		$regex = '^' . $password_regexs[$strength]['reg'] . '.{' . $minlen . ',}$';
		$title = $password_regexs[$strength]['title'];
		eval("\$title = \"$title\";");
		return array(
			'pattern' => $regex,
			'title' => $title,
			);
		} // get_password_chk_regex()

	protected static function fmt2inline_alt_image($img_data, $alt = '') {
		if(!CMS_C_INLINE_ICONS_IMAGES_ALLOW) return false;
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE < self::INLINE_IMG_MIN_SIZE) return false;
		// typical $img_data = "data:image/png;base64,(some b64 string of image)"
		if(!preg_match('/data\:image\//i',$img_data)) {
			return false;	// for now
			} // if
		$alt2 = preg_replace('/^.?alt="(.+?)".*$/i','$1',$img_data);
		if(empty($alt)) $alt = $alt2;	// use old
		$src = preg_replace('/^.?src="(.+?)".*$/i','$1',$img_data);
		// else assume $img_data is 'data:image/' . $ext . ';base64,' . $b64 (see conv2inline_alt_image)
		$text = (!empty($alt) ? 'alt="' . $alt . '"':'') .' src="'. $src . '"';
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE > strlen($text)) return false;
		return $text;
		} // fmt2inline_alt_image()

	public static function conv2inline_alt_image($img_file, $alt) {
		if(!CMS_C_INLINE_ICONS_IMAGES_ALLOW) return false;
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE < self::INLINE_IMG_MIN_SIZE) return false;
		if (empty($alt)) return false;
		if (!is_file($img_file)) return false;
		$bin = file_get_contents($img_file);
		$b64 = base64_encode($bin);
		$ext = pathinfo($img_file, PATHINFO_EXTENSION);
		$text = 'alt="' . $alt . '" src="data:image/' . $ext . ';base64,' . $b64 .'"';
		if((int)CMS_C_INLINE_ICONS_IMAGES_MAXSIZE > strlen($text)) return false;
		return $text;
		} // conv2inline_alt_image()

	public static function get_users_stats() {
		$users_path = VAR_FS_USERS_DIR;
		$users = array();
		$expiry = time() - self::$cms_session_timeout;
		if($dh = opendir($users_path)) { // check sessions location
			$stmp = session_encode();	// save current session
			while (($file = readdir($dh)) !== false) {
				if(!Ccms::is_dir_usable($file)) continue;
				if(is_dir($users_path . $file)) continue;
				if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $file)) continue;
				$filepath = $users_path . $file;
				if((is_readable($filepath)) &&
					(preg_match('/\.json$/i',$file))) {
					if((!self::get_or_post_checkbox('show_expired')) &&	// include expired
						(filemtime($filepath) < $expiry)) continue;	// expired
					$json = self::load_json($filepath);
					if((!empty($json)) && (!empty($json['username']))) {
						$usr = array(
							'username' => $json['username'],
							'file' => $file,
							'expired' => ((filemtime($filepath) < $expiry) ? true:false),
							'data' => $json,
							);
						$users[] = $usr;
						} // if
					} // if
				} // while
			} // if
		return $users;
		} // get_users_stats()

	public static function get_human_fmt_time_interval($secs, $longest_unit = '') {
		$bit = array(
			'years' => array ('secs' => 31556926, 'mod' => 12,),
			'weeks' => array ('secs' => 604800, 'mod' => 52,),
			'days' => array ('secs' => 86400, 'mod' => 7,),
			'hours' => array ('secs' => 3600, 'mod' => 24,),
			'minutes' => array ('secs' => 60, 'mod' => 60,),
			'seconds' => array ('secs' => 1, 'mod' => 60),
			 );
		$flg = false; $ret = array();
		foreach($bit as $k => &$sm) {
			if((!$flg) && (!empty($longest_unit))) {
				if(strcasecmp($k,$longest_unit)) continue;
				$flg = true;
				$v = $secs / $sm['secs'];
				$ret[] = $v . $k;
				continue;
				} // if
			$v = $secs / $sm['secs'] % $sm['mod'];
			if($v > 0) {
				$ret[] = $v . $k;
				} // if
			} // foreach
		if((!$flg) && (!empty($longest_unit))) return "(Interval FMT error.)";
		return join(' ', $ret);
		} // get_human_fmt_time_interval()

} // Ccms_general
