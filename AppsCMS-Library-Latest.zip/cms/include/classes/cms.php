<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms.php 3231 2023-02-24 12:22:54Z robert0609 $
 */

/**
 * Description of cms
 * The top class for cms
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_html.php');
require_once(CMS_FS_CLASSES_DIR . 'cms_DB_config.php');

class Ccms extends Ccms_html {

	function __construct() {
		if(self::is_api()) return;

		self::$cms_page_start_time = self::get_us_timestamp();

		// hook in global error handler
		self::$cms_prevErrorHandler = set_error_handler('Ccms_base::global_error_handler');

		// do critical checks
		if((!self::is_api()) && (!self::chk_bld_crit_dirs())) {		// should never happen
			echo self::getMsgs();
			echo PHP_EOL . "<br>Critical errors found (1). Exiting.<br>" . PHP_EOL;
			exit (1);
			} // if
		self::$cDBcms = new Ccms_DB_config(); // also reads in configuration definitions

		// complete the defines from the ini files
		self::get_cms_settings();

		// check for and engage virtual folders
		self::chk_engage_vfs();

		if(self::is_admin_action())
			Ccms_database_common::$readonly_db = false;

		self::get_vhosts_urls();
		Ccms_ops::do_site_redirect();
		// $this->php_mods = get_loaded_extensions();
		if((!self::is_cli()) && (!headers_sent())) {	// stop PHP 7 complaining
			if ((CMS_S_ALLOW_HTTP_COMPRESSION_BOOL) &&
				// (!in_array('eAccelerator', $this->php_mods)) &&
				(!Ccms::is_get_or_post('ajax')) &&
				(!self::is_debug())) {
				self::set_chk_php_value("zlib.output_compression", 'On');
				} //if
			else {
				self::set_chk_php_value("zlib.output_compression", 'Off');
				} // else
			} // if

		// until this point the any DB logging is disabled (so don't log init() ops.)
		if(defined('CMS_C_LOGS_DB_OPS')) {
			switch(CMS_C_LOGS_DB_OPS) {
			case 'all':
				Ccms_database_common::$m_bSaveDBtransactions = true;
				break;
			case 'debug':
				if(self::is_debug()) Ccms_database_common::$m_bSaveDBtransactions = true;
				break;
			case 'none':
				break;
			default:
				break;
				} // switch
			} // if

		// don't call before body_defines()	// Ccms_apps::get_apps_settings();
		if(!self::chk_domain_to_host()) exit(100);	// not me
		if((!self::is_api()) && (!self::is_rebuild())) {	// don't do twice
			if(!self::is_ajax()) {
				self::$cDBcms->checkDBversion(self::$cDBcms->m_bNew); // if new DB will rebuild install and CSS files
				} // if
			// don't call before body_defines()	// self::get_bodies_defines();	// to define APPs_ constants
			} // if

		// $sid = session_id();	// test
		Ccms_sessions::init();

		self::chk_request_dns_ip();

		// set user local
		$locale = self::get_user_locale();
		setlocale(LC_ALL,$locale);

		parent::__construct();

		Ccms_apps::get_apps_settings();

		self::do_redirect_uri();

		if(!self::is_rebuild()) {
			self::$cALcms = new Ccms_apps(); // reads in apps configuration definitions
			if((!self::is_ajax()) && (!self::is_api())) {
				self::send_downloads();
				$this->get_visitor_count();
				} // if

			self::do_download_file();

			if((defined('CMS_C_EULA_ALL')) &&
				(CMS_C_EULA_ALL))
				Ccms_auth::do_eula();

			Ccms_location::chk_geo_location();
			} // if
		$this->log_http_access();
		
		if((!self::is_api()) && (!self::is_ajax()))
			self::log_file_maintanence();

		} // __construct()

	function __destruct() {
		// $this->log_http_access();
		parent::__destruct();
//		if (is_object(self::$cDBcms))
//			self::$cDBcms->close();
		if(self::have_session()) {
			if(!is_array(self::get_cms_sess_var(CMS_PROJECT_SHORTNAME)))
				self::set_cms_sess_var(array(),CMS_PROJECT_SHORTNAME);
			self::set_cms_sess_var(CMS_PROJECT_VERSION,CMS_PROJECT_SHORTNAME,'current');
			} // if
		} // __destruct()

// dynamic functions

// static functions

	public static function get_page_stats() {
		$text = date('d M Y');
		if (CMS_C_SHOW_STATS) {
			$text .= ', Used: ' . number_format((memory_get_peak_usage() / 1024)) . 'kB';
			self::$cms_page_end_time = self::get_us_timestamp(); // not quite the end
			$diff_us = self::$cms_page_end_time - self::$cms_page_start_time;
			$text .= sprintf(", %0.3f seconds.", (float)($diff_us / 1e6));
			$text .= Ccms_location::get_client_browser_geolocation_text();
		} // if
		// else $text .= '&nbsp;'; // something
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		$text .= $tla['version_html'];
		return $text;
	} // get_page_stats()

	public static function do_analytics_include() {
		if ((strlen(CMS_S_ANALYTICS_EXT_INC) > 4)) {
			$config_host = parse_url(CMS_C_WEB_SITE_ADDRESS, PHP_URL_HOST);
			$run_host = CMS_DOMAIN;
			if((self::is_debug()) || (stripos($config_host,$run_host) !== false) || (stripos($run_host,$config_host) !== false)) {	// backwards / forwards check
				$ap = ETC_FS_EXT_INCLUDES_DIR . CMS_S_ANALYTICS_EXT_INC;
				if(!is_readable($ap)) {
					$ap = DOCROOT_FS_BASE_DIR . CMS_S_ANALYTICS_EXT_INC;
					if(!is_readable($ap)) return;
					} // if
				Ccms::page_start_comment(CMS_S_ANALYTICS_EXT_INC);
				include($ap);
				Ccms::page_end_comment(CMS_S_ANALYTICS_EXT_INC);
				} // if
			} //if
	} // do_analytics_include()

	public static function chk_request_dns_ip() {
		if(!CMS_S_VALIDATE_DNS_IP_ADDRESS_BOOL) return false;
		if((self::have_session()) &&
			(!empty($_SERVER['SERVER_NAME']) &&
			(!preg_match('/localhost/',$_SERVER['SERVER_NAME'])))) {	// running as a web app
			// check if name is real, not a NSCI scanner
			if(!self::get_cms_sess_var('dns')) {
				$req_dns = dns_get_record($_SERVER['SERVER_NAME'],DNS_ALL);
				if((!empty($req_dns)) && (is_array($req_dns))) {
					foreach($req_dns as &$d) {
						if(!empty($d['ip'])) {
							self::set_cms_sess_var($d['ip'],'dns','ns_ip');
							self::set_cms_sess_var($_SERVER['SERVER_NAME'],'dns','server_name');
							self::set_cms_sess_var($_SERVER['SERVER_ADDR'],'dns','server_addr');
							break;
							} // if
						} // foreach
					} // if
				} // if
			if(self::get_cms_sess_var('dns')) {
				$my_ip = $_SERVER['SERVER_ADDR'];
				$dns_ip = self::get_cms_sess_var('dns','ns_ip');
				if($dns_ip != $my_ip) {
					// not me. log it and kill it
					self::log_msg('ERROR DNS: ' . $_SERVER['SERVER_NAME'] . ' does not match server IP: ' . $my_ip);
					exit(111);
					} // if
				} // if
			} // if
		return true;	// ok
		} // chk_request_dns_ip()

} // Ccms
