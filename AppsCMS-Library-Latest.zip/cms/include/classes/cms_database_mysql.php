<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_database_mysql.php 3366 2023-07-20 07:23:55Z robert0609 $
 */

/**
 * Description of database_mysql
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_database_common.php');

class Ccms_database_mysql extends Ccms_database_common {

	protected static $inst = array();
	protected $inst_num = false;
	protected $link = false;
	protected $host = false;
	protected $port = false;
	protected $ssl_key = null;
	protected $ssl_cert = null;
	protected $ssl_ca = null;
	protected $user = false;
	protected $results = false;
	protected $tables = false;
	protected $tables_columns = false;
	public $table2query_audits = false;	// an array('table' => array('update_time' => 'col_name', 'mod_cnt' => 'col_name',);

	const LOCAL_HOST_IP = '127.0.0.1';	// some versions of MySQL don't like 'localhost'

	const DB_SIG_PRE = 'signatMySQL_';

	public static $do_db_table_query_audit = false;

	function __construct($user,$passwd,$database, $host = 'localhost',$port = 3306, $timeout = 3000,
		$ssl_key = null, $ssl_cert = null, $ssl_ca = null,$log = '') {
		if((empty($user)) && (empty($passwd)) && (empty($database))) return;	// doing a separate open
		parent::__construct($log);
		// save instance vals
		$this->inst_num = count(self::$inst);
		self::$inst[$this->inst_num] = $this;
		// set up
		$this->open($user, $passwd, $database, $host, $port, $timeout,
			$ssl_key, $ssl_cert, $ssl_ca);
		$this->m_bDB_checked = true;
	} // __construct()

	function __destruct() {
		// clean before I go home
		parent::__destruct();
		$this->close();
	} // __destruct()

	// static methods
	public static function is_mysql_host_ok($addr, $port = 3306,
		$db = false, $user = false, $password = false) {	// mysqli_ping() wants a connection first (blah !!!)
		if((!empty($user)) ||
			(!empty($db))) {	// unprotected DB
			$link = @mysqli_connect(
				(!empty($addr) ? $addr . (!empty($port) ? ':' . $port:''):null),
				(!empty($user) ? $user:null),
				(!empty($password) ? $password:(!empty($user) ? '':null)),
				(!empty($db) ? $db:''));
			if($link) {
				mysqli_close($link);
				return true;
				} // if
			return false; // no dough
			} // if
		return self::host_check($addr,$port);
		} // is_mysql_host_ok()

	public static function is_user_available($user,$password,$host = 'localhost', $port = 3306) {
		return self::is_host_available($user,$password,$host,$port);
		} // is_user_available()

	public static function is_host_available($user,$password,$host = 'localhost', $port = 3306,$db = false) {
		$fp = @fsockopen($host, $port, $errno, $errstr);
		if (!$fp) return false;
		fclose($fp);
		if(!self::is_mysql_host_ok($host, $port, $db, $user, $password)) return false;	// mysqli_ping() wants a connection first (blah !!!)
		return true;
		} // is_host_available()

	public static function is_database_present($name,$user,$password,$host = 'localhost') {
		$link = @mysqli_connect($host, $user, $password);
		if (!$link) return false;

		if(!empty($name))
			$db_selected = @mysqli_select_db($link, $name);
		mysqli_close($link);
		if((!empty($name)) && (!$db_selected)) return false;
		return true;
		} // is_database_present()

    //public static function create_database($adm_link,$name) {
    //    $sql = 'CREATE DATABASE IF NOT EXISTS ' . $name . ';';
    //    if (mysqli_query($adm_link, $sql)) {
    //        self::log_msg('Database: "' . $name . '" created successfully on host: "' . $host . '".','info');
    //        } // if
    //    else {
    //        self::addAdminMsg('Failed to create database: "' . $name . '" on host: "' . $host . '"; ' . mysqli_error());
    //        $ok = false;
    //        } // else
    //    return $ok;
    //    } // create_database()

	public static function install_user_privileges_database($admin_user,$admin_passwd,$db_user,$db_password,$db_host,$db_name) {
		self::addAdminMsg('Connecting as MySQL server admin user: "' . $admin_user . '" on "' . $db_host . '".','info');
		if(!$link = @mysqli_connect($db_host, $admin_user, $admin_passwd)) {
			self::addAdminMsg('Failed to connect as admin user "' . $admin_user . '" on "' . $db_host . '": ' . mysqli_connect_error());
			return false;
			} // if

		self::addAdminMsg('Creating DB: "' . $db_name . '" on "' . $db_host . '".','info');
		if(!$result = mysqli_query($link,"CREATE DATABASE IF NOT EXISTS " . $db_name . ";")) {
			self::addAdminMsg('Failed to create database "' . $db_name . '" on "' . $db_host . '": ' . mysqli_error($link));
			mysqli_close($link);
			return false;
			} // if

		self::addAdminMsg('Checking DB user: "' . $db_user . '" on "' . $db_host . '".','info');
		if((!$result = mysqli_query($link,"SELECT user FROM mysql.user WHERE user = '" . $db_user ."' AND host ='" . $db_host . "';")) ||
			(mysqli_num_rows($result) <= 0)) {
			self::addAdminMsg('Creating DB user: "' . $db_user . '" on "' . $db_host . '".');
			if(!$result = mysqli_query($link,"CREATE USER '" . $db_user ."'@'" . $db_host . "' IDENTIFIED BY '" . $db_password ."';")) {
				$err = mysqli_error($link);
				// try the other version
				if(!$result = mysqli_query($link,"CREATE USER '" . $db_user ."'@'" . $db_host . "';")) {
					self::addAdminMsg('Failed to create user "' . $db_user . '" on "' . $db_host . '": ' . mysqli_error($link));
					mysqli_close($link);
					return false;
					} // if
				if(!$result = mysqli_query($link,"SET PASSWORD FOR '" . $db_user ."'@'" . $db_host . "' = '" . $db_password . "';")) {
					self::addAdminMsg('Failed to set password for user "' . $db_user . '" on "' . $db_host . '": ' . mysqli_error($link));
					mysqli_close($link);
					return false;
					} // if
				} // if
			} // if

		self::addAdminMsg('Granting DB user: "' . $db_user . '" on "' . $db_host . '" ALL privileges.','info');
		if(!$result = mysqli_query($link,"GRANT ALL PRIVILEGES ON " . $db_name . ".* TO '" . $db_user ."'@'" . $db_host . "' ;")) {
			self::addAdminMsg('Failed to grant user privileges on "' . $db_name . '" on "' . $db_host . '": ' . mysqli_error($link));
			mysqli_close($link);
			return false;
			} // if

		self::addAdminMsg('MySQL setup done for "' . $db_name . '" on "' . $db_host . '".','success');

		if(!strcasecmp($db_host,'localhost')) {
			// work around MySQL localhost user privileges bug
			return self::install_user_privileges_database($admin_user,$admin_passwd,$db_user,$db_password,self::LOCAL_HOST_IP,$db_name);
			} // if
		return true; // done
		} // install_user_privileges_database()

	// dynamic methods
	public function get_host() { return $this->host; } // get_host() override virtual

	public function get_DB_signat() {
		if(!self::is_debug())
			return self::DB_SIG_PRE . md5($this->host . $this->m_sDatabase);
		return self::DB_SIG_PRE . preg_replace('/[ .]+/i','_', ($this->host . ' ' . $this->m_sDatabase));
		} // get_DB_signat()

	public function set_query_auditing($table2query_audits) {
		// example of $table2query_audits array
		// $table2query_audits = array(
		//		// NOTE: $op (first of query), $table and $where are available for variable substitution
		// 		'table_name' => array(	// table name
		//			'insert' => array(	// insert section (matches type of query)
		//				// what to do
		//				"sql" => "UPDATE table_name SET some_column_name = CURRENT_TIMESTAMP where condition",	// update new row (WHERE is added automatically)
		//				),
		//			'update' => array(	// update sections (matches type of query)
		//				// what to do
		//				"sql" => "UPDATE table_name SET NEW.some_column_name = OLD.some_column_name + 1 WHERE $where",	// update old row  update new row (WHERE is added automatically)
		//				),
		//			// NOTE: $where is extracted from the query SQL and substituted by th eval(0 function.
		//			'log_query' => true,	// false (default)
		//		);

		$this->table2query_audits = $table2query_audits;
		if(Ccms::is_debug()) {
			if(!$this->link) {
				self::addAdminMsg('CODE ERROR: Open MySQL link before setting audit columns.');
				$this->table2query_audits = false;
				return false;
				} // if
			foreach($table2query_audits as $t => $ops) {
				if(!$this->is_table_present($t)) {
					unset($this->table2query_audits[$t]);
					self::addAdminMsg('CODE ERROR: Table "' . $t . '" not present from audit columns.');
					continue;
					} // if
				if((empty($ops)) || (!is_array($ops))) {
					self::addAdminMsg('CODE ERROR: Missing audit ops for table "' . $t . '".');
					break;
					} // if
				foreach($ops as $op => $sql) {
					// limit to known ops
					switch(strtolower($op)) {
					case 'insert':
					case 'update':
					case 'log_query':
						// clean it
						unset($this->table2query_audits[$t][$op]);
						$op = strtolower($op);
						$this->table2query_audits[$t][$op] = $sql;
						break;	// ok
					default:
						self::addAdminMsg('CODE ERROR: Op "' . $op .'" unknown from table "' . $t . '".');
						unset($this->table2query_audits[$t][$op]);
						break;
						} // if
					} // foreach
				} // foreach
			} // if
		return true;
		} // set_query_auditing()

//	protected function set_time_limit($timeout) {	// virtual override
//		// this is a global setting set in /.htaccess	self::set_chk_php_value('max_execution_time', sprintf('%d',$timeout));
//		self::set_chk_php_value('mysql.connect_timeout', sprintf('%d',$timeout));
//		} // set_time_limit()

	private function chk_ssl_file($ssl) {
		if(empty($ssl)) return null;
		if(file_exists($ssl)) return $ssl;
		if(file_exists(DOCROOT_FS_BASE_DIR . $ssl))
			return DOCROOT_FS_BASE_DIR . $ssl;
		return null;
		} // chk_ssl_file()

	protected function chk_ssl($ssl_key, $ssl_cert, $ssl_ca) {
		if((empty($ssl_key)) ||
			(empty($ssl_cert)))
			return false;
		$this->ssl_ca = $this->chk_ssl_file($ssl_ca);	// optional
		$this->ssl_key = $this->chk_ssl_file($ssl_key);
		$this->ssl_cert = $this->chk_ssl_file($ssl_cert);
		if((empty($this->ssl_key)) ||
			(empty($this->ssl_cert)))
			return false;
		return true;
		} // chk_ssl()

	protected function open($user,$passwd,$database = false, $host = 'localhost',
		$port = 3306, $timeout = 300,
		$ssl_key = null, $ssl_cert = null, $ssl_ca = null) {
		$this->close();	// any previous first
		if(empty($database)) return false;
		if(!self::host_check($host, $port)) {
			self::addAdminMsg('MySQL Server:"' . $host . ':' . $port . '" not available.');
			return false;
			} // if
		// setup some common values
		if(empty($port)) $port = 3306;

		if($this->chk_ssl($ssl_key,$ssl_cert,$ssl_ca)) {
			// we can use SSL when the big fat bug PHP 7.* is fixed
			$this->link = @mysqli_init();
			mysqli_options($this->link,MYSQLI_OPT_SSL_VERIFY_SERVER_CERT,true);
			$ssl = @mysqli_ssl_set($this->link, $this->ssl_key, $this->ssl_cert, $this->ssl_ca,null);
			if(!$conn = @mysqli_real_connect($this->link, $host,$user,$passwd,$database,$port)) {
				if(!self::is_mysql_host_ok($host,$port)) {
					self::addAdminMsg('DB server:"' . $host . ':' . $port . '" not available.');
					return false;
					} // if
				$err = mysqli_connect_error();
				self::addAdminMsg('Cannot connect: ' . $err);
				$this->onError('Cannot connect: ' . $err);
	//			mysqli_close($this->link);
	//			$this->link = false;
				// check for warnings
				if (mysqli_warning_count($this->link)) {
					$e = mysqli_get_warnings($this->link);
					do {
						self::addAdminMsg("Warning: $e->errno: $e->message",'warn');
						} while ($e->next());
					} // if
				return false;
				} // if
			} // if
		else {	// normal (??) connection
			$this->link = @mysqli_connect($host,$user,$passwd,$database,$port);
			if($this->link === false ) {
				if(!self::is_mysql_host_ok($host,$port)) {
					self::addAdminMsg('DB server:"' . $host . ':' . $port . '" not available.');
					return false;
					} // if
				$err = mysqli_connect_error();
				self::addAdminMsg('Cannot connect: ' . $err);
				$this->onError('Cannot connect: ' . $err);
	//			mysqli_close($this->link);
	//			$this->link = false;
				return false;
				} // if
			// check for warnings
			if (mysqli_warning_count($this->link)) {
				$e = mysqli_get_warnings($this->link);
				do {
					self::addAdminMsg("Warning: $e->errno: $e->message",'warn');
					} while ($e->next());
				} // if
			} // else
		if(!empty($timeout)) mysqli_options($this->link,MYSQLI_OPT_CONNECT_TIMEOUT,$timeout);
		// save the details
		$this->host = $host;
		$this->port = $port;
		$this->user = $user;
		$this->m_sDatabase = $database;
		$this->m_bOpen = true;
		$this->m_sVersion = @mysqli_get_server_info($this->link);

		return true;	// done
		} // open()

	public function close() {
		if(!$this->link) return true;
		mysqli_close($this->link);
		$this->link = false;
		$this->m_bOpen = false;
		return true;
		} // close()

	public function is_connected() {
		if(!$this->link) return false;
		return true;
		} // is_connected()

	public function is_open() {
		if(!$this->is_connected()) return false;
		if(empty($this->m_sDatabase)) return false;
		return true;
		} // is_open()

	public function is_ok() {	// virtual override
		return $this->is_open();
		} // is_ok()

	public function get_db_sql_localtime($col_name = false,$as = false,$offset = false) {
		if(!empty($col_name)) $sql = "CONVERT_TZ(" . $col_name . ", @@session.time_zone, @@global.time_zone";
		else $sql = $sql = "LOCALTIME(";
		if(!empty($offset)) {	// e.g. DATETIME('NOW','LocalTime','-" . LM_C_RECENT_CHANGES_DAYS . " Day') as updated"
				$sql .= ', ' . $offset;
			} // if
		// else e.g. DATETIME(lm_link_updated, 'LocalTime')
		$sql .= ')';
		if(!empty($as)) $sql .= ' as ' . $as;
		return $sql;
		} // get_db_sql_localtime()

	public function list_databases() {
		if(!$this->is_connected()) return false;
		$dbs = array();
		$res = mysqli_query($this->link,"SHOW DATABASES");
		while ($row = mysqli_fetch_assoc($res)) {
			$dbs[] = $row['Database'];
			} // while
		@mysqli_free_result($res);
		return $dbs;
		} // list_databases()

	public function list_tables($database = false) {
		if(!$this->is_open()) return false;
		if(empty($database)) $database = $this->m_sDatabase;
		$sql = "SHOW TABLES FROM $database";
		if(!$result = $this->query($sql)) {
			self::addAdminMsg('Could not list tables from database "' . $database . '".');
			$this->onError('Could not list tables from database "' . $database . '".');
			return false;
			} // if
		$this->tables = array();
		while ($row = mysqli_fetch_row($result)) {
			$this->tables[] = $row[0];
			} // while
		@mysqli_free_result($result);
		return $this->tables;
		} // list_tables()

	public function is_table_present($table) {
		if(!$this->is_ok()) return false;
		if(($result = mysqli_query($this->link,'SELECT 1 FROM `' . $table . '` LIMIT 1')) !== false) {
			return true;
			} // if
		return false;
		} // is_table_present()

	public function list_table_columns($table) {
		if(!$this->is_open()) return false;
		if(empty($table)) return false;
		if(empty($this->tables_columns)) $this->tables_columns = array();
		if(($col_hd_result = mysqli_query($this->link,"SHOW COLUMNS FROM ".$table."")) &&
			(mysqli_num_rows($col_hd_result) > 0)) {
			while ($hd = mysqli_fetch_assoc($col_hd_result)) {
				$this->tables_columns[$table][] = $hd['Field'];
				} // while
			} // if
		return $this->tables_columns[$table];
		} // list_table_columns()

	public function input($string) {
		$string = mysqli_real_escape_string($this->link,$string);
		return $string;
		} // input()

	protected function do_auditing($query) {
		// typical $query = 'UPDATE `table` SET `col_name` = \''.$num.'\ WHERE `id` = '.some_id. '\'';
		if(!self::$do_db_table_query_audit) return false;
		if($this->table2query_audits) return false;

		$op = preg_replace('/^([a-z]+)\s.*$/i','$1',$query);
		$table = preg_replace('/^.*FROM\s+([`0-9a-zA-Z]+)\s+.*$/i','$1',$query);
		$where = (preg_match('/\s+WHERE\s+/i',$query) ? preg_replace('/^.*where\s+(.*)$/i','$1',$query):'');
		if((isset($this->table2query_audits[$table]['log_query'])) &&
			($this->table2query_audits[$table]['log_query'])) {
			self::log_msg('DB AUDIT: "' . $query . '".','info');
			} // if
		if(isset($this->table2query_audits[$table][$op]['sql'])) {
			$sql = $this->table2query_audits[$table][$op]['sql'];
			try {
				eval("\$sql = \"$sql\";");
				$ret = mysqli_query($this->link, $sql);
				if(!$ret) {
					self::log_msg('DB AUDIT ERROR QUERY: Failed on query: "' . $sql . '".');
					self::log_msg('DB AUDIT ERROR TEXT: ' . mysqli_errno($this->link) . ": " . mysqli_error($this->link));
					} // if
				return $ret;
				}
			catch (ParseError $error) {
				// Output expected ParseError.
				self::addAdminMsg($error,'debug');
				}
			catch (Error $error) {
				// Output any unexpected errors.
				self::addAdminMsg($error,'debug');
				}
			return false;
			} // if
		return true;
		} // do_auditing()

	public function query($query) {
		$this->results = false;
		if(!$this->is_open()) {
			$err = 'DB link not open';	//mysqli_error($this->link);
			self::addDebugMsg('Attempt to query non open MySQL database: ' . $err);
			$this->onError('Attempt to query non open MySQL database: ' . $err);
			return false;
			} // if
		try {	// for XAMPP
			if(!$this->results = mysqli_query($this->link,$query)) {
				$err = mysqli_error($this->link);
				if(preg_match('/duplicate|unique/i',$err)) self::addAdminMsg ($err,'warn');
				else self::addDebugMsg($err);
				$this->onError($err);
				return false;
				} // if
			} // try
		catch(Exception $e) {
			$err = $e->getMessage();
			self::addDebugMsg($err);
			return false;
			} // catch
		$this->do_auditing($query);
		return $this->results;
		} // query()

	public function get_row_cnt($results = false) {
		if(empty($results)) $results = $this->results;
		if(empty($results)) return 0;
		return mysqli_num_rows($results);
		} // get_row_cnt()

	public function fetch_array_assoc($results = false) {	// fetch keyed array
		if(empty($results)) $results = $this->results;
		if(empty($results)) return false;
		return mysqli_fetch_assoc($results);
		} // fetch_array_assoc()

	public function fetch_array_enum($results = false) {	// fetch enumerated array (caution)
		if(empty($results)) $results = $this->results;
		if(empty($results)) return false;
		return mysqli_fetch_row($results);
		} // fetch_array_enum()

	public function fetch_array($results = false,$unescape_flg = true,$full = false) {	// fetch keyed with enumerated array (slower)
		if(empty($results)) $results = $this->results;
		if(empty($results)) return false;
		if(!$full) $result = $this->fetch_array_assoc($results);
		else $result = $this->mysqli_fetch_array($results);
		if($unescape_flg) $result = $this->output($result);
		return $result;
		} // fetch_array()

	public function output($string) {
		return $string;
		} // output()

	public function num_rows($result) {
		if(!$this->is_ok()) return false;
		if(!$result) return false;
		return mysqli_num_rows($result);
		} // num_rows()

	public function query_unbuffered($query) {	// a compatibility func
		return $this->query($query);
		} // query_unbuffered()

	public function fetch_array_unbuffered($query_result,$next = true) {
		return $this->fetch_array_assoc($query_result);
		} // fetch_array_unbuffered()

	public function perform($table, $data, $action = 'insert', $where_params = '',$unchecked_cols = null) {
		if(!$this->is_ok()) return false;
		if(empty($data)) {
			self::addAdminMsg('Empty data to perform() on table: ' . $table);
			return false;
			} // if
		$this->chk_table_row_sanity($table,$row);
		reset($data);
		if ($action == 'insert') {
			if(!empty($unchecked_cols) && is_array($unchecked_cols)) {
				$data = array_merge($data,$unchecked_cols);
				} // if
			$values = '';
			$query = 'insert into ' . $table . ' (' . "\n";
			foreach($data as $columns => &$value) {
				$value = preg_replace("/^'|'$/",'',$value);
				$query .= $columns . ', ';
				switch ((string) $value) {
					case 'now()':
						$values .= 'now(), ';
						break;
					case 'null':
						$values .= 'null, ';
						break;
					default:
						if(is_bool($value)) $values .= ($value ? 1:0) . ', ';
						else if(is_numeric($value)) $values .= $value . ', ';
						else $values .= "'" . $this->input($value) . "', ";
//						$values .= '\'' . $this->input($value) . '\', ';
						break;
				} // switch
			$query .= "\n";
			} // while
			$query = substr($query, 0, -3) . ')' . "\n" . 'values (' . $values;
			$query = substr($query, 0, -2) . ')' . "\n";
			} // if
		elseif ($action == 'update') {
			if(!empty($unchecked_cols) && is_array($unchecked_cols)) {
				if(($check_query = $this->query("select * from " . $table . " where " . $where_params)) &&
					($check = $this->fetch_array($check_query))) {
					$chgdFlg = false;
					foreach($check as $c => $v) {
						if(isset($data[$c])) {	// has column
							if($data[$c] != $v) {	// different
								$chgdFlg = true;
								break;
								} // if
							} // if
						} // foreach
					if(!$chgdFlg) return true;	// unchanged
					} // if
				$data = array_merge($data,$unchecked_cols);
				} // if
			$query = 'update ' . $table . ' set ' . "\n";
			foreach ($data as $column => &$value) {
				$value = preg_replace("/^'|'$/",'',$value);
				switch ((string) $value) {
					case 'now()':
						$query .= $column . ' = now(), ';
						break;
					case 'null':
						$query .= $column .= ' = null, ';
						break;
					default:
						if(is_bool($value)) $query .= $column . ' = ' . ($value ? 1:0) . ', ';
						else if(is_numeric($value)) $query .= $column . ' = ' . $value . ', ';
						else $query .= $column . " = '" . $this->input($value) . "', ";
						break;
					} // switch
				$query .= "\n";
				} // foreach
			$query = substr($query, 0, -3) . "\n" . ' where ' . $where_params;
			} // elseif
		else return false;	// wrong method ???
		$this->db_chgd = true;
		return $this->query($query);
		} // perform()

	public function free_result($result) {
		if(!$this->is_ok()) return false;
		if(!$result) return false;
		@mysqli_free_result($result);
		return true;
		} // free_result()

	public function get_last_insert_id() {
		return mysqli_insert_id($this->link);
		} // get_last_insert_id()

	public function is_table_column_present($table,$column) {
		if(!$this->is_ok()) return false;
		$bFound = false;
		if (($test_result = $this->query("SHOW COLUMNS FROM " . $table . " LIKE '" . (is_array($column) ? $column[0]:$column) . "';")) &&
			(mysqli_num_rows($test_result))) {
			return true;
			} // if
		return false;
		} // is_table_column_present()

	private function make_MySQL_type($mr, $ary_flg = false) {
		$type = array();
		if(!$ary_flg) {
			$type[] = $mr['COLUMN_TYPE'];
			$type[] = $mr['COLUMN_KEY'];
			$type[] = $mr['EXTRA'];
			if(isset($mr['COLUMN_DEFAULT'])) $type[] = 'DEFAULT ' . $mr['COLUMN_DEFAULT'];
			if($mr['IS_NULLABLE'] == 'NO') $type[] = ' NOT NULL';
			return implode(' ',$type);
			} // if
		$type['COLUMN_TYPE'] = $mr['COLUMN_TYPE'];
		$type['COLUMN_KEY'] = $mr['COLUMN_KEY'];
		$type['EXTRA'] = $mr['EXTRA'];
		$type['COLUMN_DEFAULT'] = $mr['COLUMN_DEFAULT'];
		$type['IS_NULLABLE'] = $mr['IS_NULLABLE'];
		return $type;
		} // make_MySQL_type()

	public function get_columns_list($table, $default_values = false, $inc_type = false) {	// return column names array
		if(!$this->is_ok()) return false;
		if($mr_result = $this->query("SELECT " . ($inc_type ? '*':'COLUMN_NAME') . " FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" . $table . "';")) {
			$columns = array();
			while($mr = $this->fetch_array($mr_result)) {
				if(!$inc_type) $columns[] = $mr['COLUMN_NAME'];
				else $columns[($mr['COLUMN_NAME'])] = $this->make_MySQL_type($mr);
				} // while
			return $columns;
			} // if
		return false;
		} // get_columns_list()

	public function get_column_type($table,$column_name) {	// returns column names with type array
		if(!$this->is_ok()) return false;
		if($mr_result = $this->query("SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" . $table . "' AND COLUMN_NAME = '" . $column_name . "';")) {
			if($mr = $this->fetch_array($mr_result)) {
				return $this->make_MySQL_type($mr,true);
				} // if
			} // if
		return false;
		} // get_columns_type()

	public function get_row_count_in_table($table,$where = '') {
		if(!$this->is_ok()) return false;
		if(!$this->is_table_present($table)) return false;	// no table
		$test_sql = "select count(*) as total from " . $table;
		if(!empty($where)) {
			if(stripos($where,'where') === false) $test_sql .= ' where ' . $where;
			else $test_sql .= ' ' .$where;
			} // if
		if($test_result = $this->query($test_sql)) {
			if($test = $this->fetch_array($test_result)) {	// $this->get_row_cnt($test_result)
				return $this->output($test['total']);
				} // if
			} // if
		return false; // no data, error
		} // get_row_count_in_table()

	protected function update_row_data($table,$columns,$row,$updateable_columns,$key_column) {
		if(empty($updateable_columns)) return true;	// nothing can changed
		$upd_cols = explode(',',$updateable_columns);
		if(count($upd_cols) < 1) return true;	// nothing to do

		$colnames = array_keys($columns);
		$key_idx = 0;	// assume it's the id col
		if(!empty($key_column)) {
			$key_idx = array_search($key_column, $colnames);
			if($key_idx === false) return false;
			} // if

		$idx = 0;
		$fields = array();
		if((int)$this->get_row_count_in_table($table,$key_column . ' = ' . $row[$key_idx]) > 0) {
			$action = 'update';
			} // if
		else $action = 'insert';
		foreach($columns as $col => $type) {
			if($idx >= self::CMS_TABLE_AUDIT_COLS) {	// let autoincrement and datatime do its thing
				if($action == 'insert') $fields[$col] = $row[$idx];
				else if(in_array($col, $upd_cols)) {
					$fields[$col] = $row[$idx]; // add values to update to $sql_query
					} // if
				} // if
			$idx++;
			} // foreach

		if($action == 'update') {
			if(!$this->perform($table,$fields,$action,$key_column . ' = ' . $row[$key_idx])) return false;
			} // if
		else if($action == 'insert') {
			if(!$this->perform($table,$fields,$action)) return false;
			} // else
		$this->db_chgd = true;
		return true;
		} // update_row_data()

	protected function checkAddDBcolumn($table, $column, $type) {	// override base
		if(!$this->is_ok()) return false;
		$bFound = false;
		if (!$this->is_table_column_present($table,$column)) {
			if(!$this->query('ALTER TABLE ' . $table . ' ADD COLUMN `' . $column . '` ' . $type . ';')) { // add
				return false;
				} // if
			} // if
		else if($type) {
			// $set_type = $this->get_column_type($table,$column,$type);	// test
			if(!$this->query('ALTER TABLE ' . $table . ' MODIFY COLUMN `' . $column . '` ' . $type . ';')) { // add
				return false;
				} // if
			} // if
		$this->db_chgd = true;
		return true;
		} // checkAddDBcolumn()

	public function checkDropDBcolumn($table, $column) {	// override base
		if(!$this->is_ok()) return false;
		$bFound = false;
		if ($this->is_table_column_present($table,$column)) {
			if(!$this->query('ALTER TABLE ' . $table . ' DROP COLUMN `' . $column . '`;')) { // drop
				return false;
				} // if
			} // if
		return true;
		} // checkDropDBcolumn()

	protected function installTable($table,&$params,$drop = false, $verbose = false) {
		if(!$this->is_ok()) return false;
		if((empty($table)) || (!is_array($params))) return false;

		// $params
		// 'drop' => 'False' or 'True'
		// 'columns' => array( 'col_name' => 'type/def' )
		// 'data' => array() of column data in columns order

		$ok = true; $table_present = false;
		if(((isset($params['drop'])) &&
			(($params['drop'] == 'True') || ($params['drop'] === true))) ||
			($drop)) {
			$this->query("DROP TABLE IF EXISTS `" . $table . "`;");
			$table_present = false;
			} // if
		else $table_present = $this->is_table_present($table);

		$this->query("SET @saved_cs_client     = @@character_set_client;");	// save language
		$this->query("SET character_set_client = utf8;");	// set language

		if((is_array($params['columns'])) && (count($params['columns']) > 0)) {
			$columns = &$params['columns'];

			if(!$table_present) {
				$sql_query = 'CREATE TABLE IF NOT EXISTS ' . $table . "\n";
				$sql_query .= ' (' . "\n";
				$cnt = 0;
				foreach ($columns as $name => $type) {
					if($cnt > 0) $sql_query .= ', ' . "\n";
					$sql_query .= (is_numeric($name) ? '':"`" . $name . "` ") . $type;
					$cnt++;
					} // foreach
				$sql_query .= "\n" . ');' . "\n";
				if(!$this->query($sql_query)) {
					$ok = false;
					} // if
				} // if
			else {	// check all columns are there
				if(isset($params['delete_columns'])) {	// delete unused columns first
					foreach($params['delete_columns'] as $dcol) {
						$dcol_sql = 'ALTER TABLE ' . $table . ' DROP COLUMN IF EXISTS ' . $dcol . ';';
						$this->query($dcol_sql);
						} // foreach
					} // if
				foreach ($columns as $name => $type) {
					if(empty($name)) continue;
					if(!$this->checkAddDBcolumn($table, $name, $type))
						$ok = false;
					} // foreach
				} // else

			if(($ok) && (isset($params['functions']))) {	// create triggers, filters and functions
				foreach($params['functions'] as $k => $v) {
					// check if function ($k) is already there first
					if($test_query = $this->query("SHOW TRIGGERS;")) {
						$found = false;
						while($test = $this->fetch_array($test_query,false)) {
							if($test['Trigger'] == $k) {
								$found = true;
								break;
								} // if
							} // while
						if($found) continue;
						} // if
					$sql_query = $v;
					if(!$this->query($sql_query)) {
						$ok = false;
						break;
						} // if
					} // foreach
				} // if

			if(($ok) && (isset($params['extras'])) && (!empty($params['extras']))) {	// extra creat string
				$sql_query = $params['extras'];
				if(!$this->query($sql_query)) $ok = false;
				} // if

			if(($ok) && (isset($params['data'])) && (is_array($params['data'])) && (count($params['data']) > 0)) {
				$columns = &$params['columns'];
				$data = &$params['data'];	// in the same order as the columns
				$row_cnt = 0;
				if(($table_present) && (isset($params['updateable_columns'])) && (!empty($params['updateable_columns'])) &&
					((isset($params['key_column'])) && (!empty($params['key_column'])))) {
					$msg_itr = $this->get_msg_iteration_cnt($data);
					foreach($data as &$row) {
						if(!$this->update_row_data($table,$columns,$row,$params['updateable_columns'],$params['key_column'])) $ok = false;
						if(($verbose) && ((++$row_cnt % $msg_itr) == 0))	// speed up
							$this->out_import_stat_msg('Table: ' . $table . ', row: ' . $row_cnt . '.');
						} // foreach
					} // if
				else {
					$now = gmdate('Y-m-d H:i:s');
					$msg_itr = $this->get_msg_iteration_cnt($data);
					foreach($data as &$row) {
						if((count($columns) == count($row)) &&
							(array_key_exists(1,$row)) &&
							(!$table_present)) {	// assume data in column order
							$sql_query = "INSERT INTO `" . $table . "` VALUES (" . $this->implode_ary2str(',',$row) . ");";
							if(!$this->query($sql_query))
								$ok = false;
							} // if
						else {	// add / update columns
							$fields = array(); $idx = 0;
							foreach($columns as $cn => &$cv) {	// tables colum names and data may not be aligned
								if(is_numeric($cn)) continue;
								if(!isset($row[$idx])) {
									if(!isset($row[$cn])) continue;	// use default
									$val = $row[$cn];
									} // if
								else if(isset($row[$idx])) $val = $row[$idx];
								else $val = '0';
								// do SQLite --> MySQL value changes
								$dval = preg_replace(
									array('/CURRENT_TIMESTAMP/','/DATETIME\(\'NOW\'\)/','/NOW\(\)/'),	// patterns
									array($now,$now,$now),	// matching replacements
									$val);
								$fields[$cn] = $dval;	// $this->input($dval);
								$idx++;
								} // foreach
							if(!$table_present) {
								if(!$this->perform($table, $fields))
									$ok = false;
								} // if
							else if((isset($params['key_column'])) && (!empty($params['key_column'])) && (isset($fields[($params['key_column'])])) &&
								(isset($params['id'])) && (isset($fields[($params['id'])]))) {
								$id = $fields[($params['id'])];
								$key = $fields[($params['key_column'])];
								unset($fields[($params['id'])]);
								unset($fields[($params['key_column'])]);
								$where_var = (is_numeric($key) ? $key:"'" . preg_replace('/^\'|\'$/','',$key) . "'");
								if(!$this->perform($table, $fields, 'update', $params['key_column'] . ' = ' . $where_var))
									$ok = false;
								} // else
							else if((isset($params['id'])) && (isset($fields[($params['id'])]))) {
								$id = $fields[($params['id'])];
								unset($fields[($params['id'])]);
								if(!$this->perform($table, $fields, 'update', $params['id'] . ' = ' . $id))
									$ok = false;
								} // else
							else {
								self::addAdminMsg('Unknown DB data type for table; ' . $table);
								$ok = false;
								} // else
							} // else
							if(($verbose) && ((++$row_cnt % $msg_itr) == 0))	// speed up
								$this->out_import_stat_msg('Table: ' . $table . ', row: ' . $row_cnt . '.');
						} // foreach
					} // else
				if($verbose) $this->out_import_stat_msg('Table: ' . $table . ', total rows: ' . $row_cnt . '.' . PHP_EOL);
				} // if
			} // if
		else $ok = false;

		$this->query("SET character_set_client = @saved_cs_client;");	// restore language
		if($ok) $this->db_chgd = true;
		if($verbose) $this->out_import_stat_msg(PHP_EOL);
		return $ok;
		} // installTable()

	public function install_db_tables($only_table, $install_scripts, $verbose = false, $drop = false) {
		if(!$this->is_ok()) return false;
		$ok = true;
		foreach($install_scripts as $table => &$params) {
			if((strlen($only_table) > 0) &&
				($table != $only_table)) continue;

			if($verbose) echo ($drop ? 'Installing':'Updating') . ' table ' . $table . CMS_NL;
			if(!$this->installTable($table,$params,$drop,$verbose)) {
				if($verbose) echo 'ERROR: failed to install ' . $table . ' in ' . $this->get_name() . CMS_NL;
				self::log_msg('Failed to install ' . $table . ' in ' . $this->get_name());
				$ok = false;
				} // if
			} // foreach
		if($verbose) {
			if($ok) echo CMS_NL. ($drop ? 'Installed':'Updated') . " " . $this->get_name() . " tables - success" . CMS_NL;
			else echo CMS_NL . "Failed to " . ($drop ? 'install':'update') . " " . $this->get_name() . " tables - failed" . CMS_NL;
			} // if
		if($ok) $this->db_chgd = true;
		return $ok;
		} // install_db_tables()

//	function backupDatabase($backupFolder = false,$cms_msg_info = false) {
//		// virtual override
//		if(!$this->is_ok()) return false;
//		if($cms_msg_info) self::addAdminMsg('Saved DB to "' . basename($filepath) . '".','success');
//		return true;
//	} // backupDatabase()

//	function restoreDatabase($backupfile) {	// needs to be preceeded with "Are you sure"
//		// virtual override
//		if(!$this->is_ok()) return false;
//		return true;
//		} // restoreDatabase()

	public static function backup_mysql_cli($backup_sql_file,
		$db_host, $db_name, $db_user,$db_passwd) {
		//Please do not change the following points
		//Export of the database and output of the status
		$command='mysqldump --opt  --skip-extended-insert -h' .$db_host .' -u' .$db_user .' -p' .$db_passwd .' ' .$db_name .' > ' .$backup_sql_file;
		exec($command,$output=array(),$worked);
		switch($worked){
		case 0:
			self::addAdminMsg('The database "' .$db_name .'"' .
				' was successfully stored in the following path "' . $backup_sql_file .'".','success');;
			return true;
			break;
		case 1:
			self::addAdminMsg('An error occurred when exporting "' .$db_name .'" to "' . $backup_sql_file .'".');
			break;
		case 2:
			self::addAdminMsg('An export error has occurred, please check the following information: ' .
				' Database: "' .$db_name .'"' .
				', User: "' .$db_user .'"' .
				', Host: "' .$db_host .'".');
			break;
			} // switch
		return false;
		} // backup_mysql_cli()

	public static function restore_mysql_cli($restore_sql_file,
		$db_host, $db_name, $db_user,$db_passwd) {
		//Please do not change the following points
		//Import of the database and output of the status
		$command='mysql -h' .$db_host .' -u' .$db_user .' -p' .$db_passwd .' ' .$db_name .' < ' .$restore_sql_file;
		exec($command,$output=array(),$worked);
		switch($worked){
		case 0:
			self::addAdminMsg('The data from the file "' .$restore_sql_file .'"' .
				' were successfully imported into the database "' .$db_name .'".','success');
			return true;
			break;
		case 1:
			self::addAdminMsg('An error occurred during the import.' .
				' Please check if the file is in the same folder as this script.' .
				' Also check the following data again: ' .
				' Database: "' . $db_name .'"'.
				', User: "' . $db_user .'"' .
				', Host: "' . $db_host .'"' .
				', Restore File: ' . $restore_sql_file .'".');
			break;
			} // switch
		return false;
		} // restore_mysql_cli()

} // Ccms_database_mysql
