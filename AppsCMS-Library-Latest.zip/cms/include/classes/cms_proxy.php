<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_proxy.php 2793 2022-09-10 06:40:19Z robert0609 $
 */

/**
 * Description of cms_proxy
 * proxy class to access files on local file systems and network shares
 * the proxy operation needs to be as fast as possible (not using the AppsCMS code or defines)
 *
 * @author robert0609
 */

include_once 'cms_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_proxy extends Ccms_base {

	const SLASH_KEY = '_##_';
	const PROXY_PRE_URI = 'cms/cms_proxy.php?proxy=';
	const PROXY_TTL = (3600 * 12);	// 12 hours
	const PROXY_TTL_ALL = (3600 * 24 * 2);	// 2 days

	private static $signat_file = false;	// time saver

	function __construct() {
		parent::__construct();
		self::output_proxy_file();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function clear_signats($cli = false) {
		if(!$cli) {
			// later !!
			} // if

		if((!defined('VAR_FS_PROXY_DIR')) ||
			(!self::chkdir(VAR_FS_PROXY_DIR)))
			return 0;

		$files = scandir(VAR_FS_PROXY_DIR);
		$cnt = 0;
		foreach($files as $f) {
			$fp = VAR_FS_PROXY_DIR . $f;
			if((is_file($fp)) &&
				(self::is_file_usable($fp))) {
				@unlink($fp);
				$cnt++;
				} // if
			} // if
		self::addDebugMsg('Reset ' . $cnt . ' proxy signat files.','info');
		return $cnt;
		} // clear_signats()

	private static function get_signat_filename() {
		if(!self::$signat_file) {
			self::$signat_file = true;	// do once

			if(version_compare(PHP_VERSION, '5.4.0') >= 0) {
				if (session_status() == PHP_SESSION_NONE) {
					// @TODO check on other browsers
					@session_name(CMS_SESSION_NAME);
					@session_start();
					} // if
				} // if
			else {	// < 5.4
				if((session_id() == '') ||
					(!self::have_session())) {
					// @TODO check on other browsers
					@session_name(CMS_SESSION_NAME);
					@session_start();
					} // if
				} // else
			$sess_id = session_id();
			self::$signat_file = VAR_FS_PROXY_DIR . 'proxy_' . $sess_id . '-lst.json';
			} // if
		return self::$signat_file;
		} // get_signat_filename()

	private static function gen_signature_key($scr) {
		if((!file_exists($scr)) || (!is_readable($scr))) return false;
		return md5(self::clean_path($scr));
//		// @TODO the $scr needs to obvascated better
//		if(self::is_debug()) {
//			$scr_key = str_replace('/',self::SLASH_KEY, self::clean_path($scr));
//			} // if
//		else {	// @TODO need to add security, $scr_key needs $scr in signat file
//			$scr_key = md5(self::clean_path($scr));
//			} // else
//		return $scr_key;
		} // gen_signature_key()

	protected static function save_proxy_signat($scr,$d_attach) {	// save a check signature for url for security reasons
		if(!$signat_file = self::get_signat_filename()) return false;
		if(!$signats = self::load_json($signat_file,true)) $signats = array();
		else if((empty($signats['ttl'])) || ((int)$signats['ttl'] < time()))
			$signats = array('ttl' => time() + self::PROXY_TTL_ALL,);	// expired
		$scr_key = self::gen_signature_key($scr);
		$mime = self::mime_content_type($scr);
		$signats[$scr_key] = array(
			'src' => $scr,
			'name' => basename($scr),
			'size' => filesize($scr),
			'mime' => (!empty($mime) ? $mime:false),
			'scr_key' => $scr_key,
			'ttl' => time() + self::PROXY_TTL,
			'url' => self::PROXY_PRE_URI . rawurlencode($scr_key),
			'attch' => $d_attach,	// download
			);
		if(!self::save_json($signat_file,$signats)) {
			self::addMsg('Failed to save proxy signature file "' . $signat_file . '".');
			return false;
			} // if
		return $signats[$scr_key];
		} // save_proxy_signat()

	protected static function check_proxy_signat($scr_key) {	// save a check signature for url for security reasons
		if(!$signat_file = self::get_signat_filename()) return false;
		if($signats = self::load_json($signat_file,true)) {	// get signats
			if((int)$signats['ttl'] < time()) return false;	// expired
			if(!empty($signats[$scr_key])) {
				if((int)$signats[$scr_key]['ttl'] < time()) return false;	// expired
				return $signats[$scr_key];
				} // if
			} // if
		self::log_msg('INFO: Failed to find proxy signature for "' . $scr_key . '".');
		return false;
		} // check_proxy_signat()

	public static function get_proxy_data($scr,$d_attach = false) {		// returns the url to use in the web code, called from web code
		$scr_key = self::gen_signature_key($scr);
		if(!$signat = self::save_proxy_signat($scr,$d_attach)) return false;
		return $signat;
		} // get_proxy_url()

	public static function get_proxy_url($scr,$d_attach = false) {		// returns the url to use in the web code, called from web code
		if(!$signat = self::get_proxy_data($scr,$d_attach)) return false;
		return $signat['url'];
		} // get_proxy_url()

	public static function clear_file_proxy() { // clear user session proxy list
		if(!$signat_file = self::get_signat_filename()) return false;
		if(!file_exists($signat_file)) return true;
		if(@unlink($signat_file) !== false) return true;	// cleared
		self::log_msg('ERROR: Failed to clear proxy signature file "' . $signat_file . '".');
		return false;
		} // clear_file_proxy()

	public static function output_proxy_file() {	// outputs the file given by get_proxy_url(), called from cms/cms_proxy.php
		if(self::is_get_or_post('proxy')) {
			$url = self::get_or_post('proxy');
			$scr_key = rawurldecode($url);
// 			echo $scr_key;
			if(!$scr = self::check_proxy_signat($scr_key)) {
				return '';
				} // if
			if((file_exists($scr['src'])) && (is_readable($scr['src']))) {
				if(!empty($scr['mime'])) header('Content-Type: ' . $scr['mime'] ."\r\n");
				header('Content-Length: ' . $scr['size'] . "\r\n");
				if($scr['attch']) header('Content-Disposition: attachment; filename="' . $scr['name'] . '"');
				readfile($scr['src']);	// outputs the file
				return true;
				} // if
			else {	// add docroot
				$dr_src = '../' . $scr['src'];
				if((file_exists($dr_src)) && (is_readable($dr_src))) {
					if(!empty($scr['mime'])) header('Content-Type: ' . $scr['mime'] ."\r\n");
					header('Content-Length: ' . $scr['size'] . "\r\n");
					if($scr['attch']) header('Content-Disposition: attachment; filename="' . $scr['name'] . '"');
					readfile($dr_src);	// outputs the file
					return true;
					} // if
				} // else
			} // if
		echo '';
		return false;
		} // output_proxy_file()

	} // Ccms_proxy
