<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_plugin_base.php 3119 2023-02-11 00:28:22Z robert0609 $
 */

/**
 * Description of plugin_base
 *
 * base class for all plugins
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_base.php');

class Ccms_plugin_base extends Ccms_base {

	protected static $cms_plugins_enabled = false;

	function __construct() {
		Ccms_sm::get_bodies_defines();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	protected static function is_plugin_enabled($cms_plugin) {	// required function, check plugin enabled
		if(empty($cms_plugin)) {
			self::addMsg('Unnamed plugin.');
			return false;
			} // if
		if(!self::$cms_plugins_enabled) {
			self::$cms_plugins_enabled = array();
			$cms_plugins_enabled = self::unserialize_string2arry(CMS_C_ENABLED_PLUGINS,':');
			for($i = 0; $i < count($cms_plugins_enabled); $i++) {
				self::$cms_plugins_enabled[] = $cms_plugins_enabled[$i];
				} // for
			} // if
		if(in_array($cms_plugin, self::$cms_plugins_enabled)) return true;
		return false;
		} // is_plugin_enabled()

	public static function is_this_ajax_plugin($ajax) {	// virtual function, check for ownership of ajax op by this plugin
		return false;
		} // is_this_plugin()

	public static function get_ajax_text($ajax) {	// virtual function, generate ajax text for this plugin
		return '';	// default return
		} // get_ajax_text()

	public static function init_body_insert() {	// virtual function, get test to insert after body tag
		return '';	// default return
		} // init_body_insert()

	public static function generate($id,$suffix = '',$params = array()) {	// virtual function
		return '';	// use the generate() method for direct include
		} // generate()

	public static function validate($code,$suffix = '') {	// virtual function
		return true;
		} // validate()

	public static function execute_form() {	// virtual
		return false;
		} // execute_form()

	public static function executed_url() {	// default url when plugin finishes executing form
		self::set_cms_sess_var('','body_id');
		$url = '/' . CMS_URI_ALIAS . 'index.php';	// home
		return $url;
		} // executed_url()

	public static function get_iframe_engage_uri() {	// iframe uri to engage plugin (typically url to get iframe)
		return '';	// use the generate() method for direct include
		} // get_iframe_engage_uri()

	public static function get_ajax_engage_uri() {	// ajax uri to engage plugin (typically calls call up plugin text)
		return '';	// use the generate() method for direct include
		} // get_ajax_engage_uri()

	// special functions
	public static function get_PL_config_keys_values($class) {	// looks for polymorphed get_sql_install_data()
		if(!method_exists($class, 'get_sql_install_data')) return false;	// no install array why ??
		$confs = @$class::get_sql_install_data();
		if(empty($confs)) return false;	// no configs
		$pl_key = strtoupper($class::PLUGIN);
		$enabled_plugins = explode(':',CMS_C_ENABLED_PLUGINS);
		$enabled = (in_array($class::PLUGIN,$enabled_plugins) ? true:false);
		$config_keys = array(
			'info' => array('plugin' => $class::PLUGIN, 'class' => $class, 'key' => $pl_key,'enabled' => $enabled),
			);
		foreach($confs as $conf) {
			$key = 'PL_' . $pl_key . '_' . $conf['cms_config_key'];	// eg PL_BOOK_KEEP_MYSQL_HOST
			$val = 	self::$cDBcms->get_data_in_table('cms_configs','cms_config_value',"cms_config_key = '" . $key . "'");
			if($val === false) continue;	// mt
			$config_keys[$key] = $val;
			} // foreach
		return $config_keys;
		}	// get_PL_config_keys_values()

	public static function install($chk_flg = true) {	// virtual function
		// put code here to add rows to the cms_configs DB table
		// if $chk_flg then check installed
		return true;
		}	// install()

	public static function uninstall() {	// virtual function
		// put code here to remove rows from the cms_configs DB table
		return true;
		}	// uninstall()

	protected static function install_db_data($cms_plugin,$title,$data,$chk_flg) {
		foreach($data as $row) {
			$key = 'PL_' . strtoupper($cms_plugin) . '_' . $row['cms_config_key'];
			$name = 'Plugin - ' . $title . ': ' . $row['cms_config_name'];
			$fields = $row;
			$fields['cms_config_name'] = $name;

			// remove the not allowed values
			if(isset($fields['cms_config_id'])) unset($fields['cms_config_id']);
			if(isset($fields['cms_config_added'])) unset($fields['cms_config_added']);
			if(isset($fields['cms_config_updated'])) unset($fields['cms_config_added']);

			if((int)Ccms::$cDBcms->get_row_count_in_table('cms_configs','cms_config_key = \'' . $key . '\'') > 0) {
				$action = 'update';
				unset($fields['cms_config_key']);
				unset($fields['cms_config_value']);
				Ccms::$cDBcms->perform('cms_configs',$fields,$action,'cms_config_key = \'' . $key . '\'');
				} // if
			else {
				$action = 'insert';
				$fields['cms_config_key'] = $key;
				Ccms::$cDBcms->perform('cms_configs',$fields,$action);
				} // else
			} // foreach
		return true;
		}	// install_db_data()

	protected static function uninstall_db_data($cms_plugin,$data) {
		return true;	// do nothing for the moment, @TODO what ?
		}	// uninstall_db_data()

	public static function get_title() {	// get the plugin title
		return 'Unknown Plugin.';
		} // get_title()

	public static function get_description() {	// get the plugin description and help
		return 'No help available (' . CMS_PROJECT_SHORTNAME . ' base).';	// virtual return
		} // get_description()

} // Ccms_plugin_base
