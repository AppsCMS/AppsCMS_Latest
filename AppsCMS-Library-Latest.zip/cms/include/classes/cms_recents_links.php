<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_recents_links.php 3049 2022-12-16 02:47:04Z robert0609 $
 */

/**
 *
 *  * Description of Ccms_recents_links
 *	* static class to provide recent changes
 *
 * @author robert0609
 */
class Ccms_recents_links extends Ccms_general {

	protected static $recents_keywords = false;
//	protected static $sect_sql_recents = '';
//	protected static $link_sql_recents = '';

	protected static $linkkeys = array('lm_link_name','lm_link_title','lm_link_description');	// ,'lm_link_url','lm_link_image_url', 'lm_link_image_url'
	protected static $sectkeys = array('lm_section_name', 'lm_section_description', 'lm_section_title');	// ,'lm_section_image_url', 'lm_section_icon_url'

	protected static $layout_ids = false;

			function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function help($cnt = LM_C_RECENT_CHANGES_MAX) {
		$text = "The " . $cnt . " most recent changes that occured in the last " . LM_C_RECENT_CHANGES_DAYS . " days.";
		return $text;
		} // help()

	protected static function get_changes() {
		$list = array();
		$sql_query = "SELECT " . PHP_EOL .
			"l.lm_link_id, l.lm_link_name, l.lm_link_section_id, l.lm_link_url, lm_link_order" .
			", l.lm_link_name , l.lm_link_description, l.lm_link_title" .
			", lm_link_image_url, lm_link_icon_url, lm_link_new_page, lm_link_ssl, lm_link_enabled, lm_link_add_name2url" .
//			", " . Ccms::$cDBcms->get_db_sql_localtime('lm_link_added','lm_link_added') .
			", " . Ccms::$cDBcms->get_db_sql_localtime('lm_link_updated','lm_link_updated') .
			", s.lm_section_id, s.lm_section_name, s.lm_section_updated, s.lm_section_group_ids" . PHP_EOL .
			" FROM  lm_sections as s, lm_links as l" . PHP_EOL .
			" WHERE s.lm_section_id = l.lm_link_section_id" . PHP_EOL .
			" AND l.lm_link_enabled > 0" . PHP_EOL .
			" AND s.lm_section_enabled > 0" . PHP_EOL .
			" AND " . Ccms::$cDBcms->get_db_sql_localtime('lm_link_updated') . " >= " . Ccms::$cDBcms->get_db_sql_localtime(false,false,"'-" . LM_C_RECENT_CHANGES_DAYS . " day'") . PHP_EOL .	// @TODO make compatible with SQLite and MySQL
			// " AND " . Ccms::$cDBcms->get_db_sql_localtime('lm_link_updated') . " >= DATETIME('now', 'LocalTime', '-" . LM_C_RECENT_CHANGES_DAYS . " day')" . PHP_EOL .	// @TODO make compatible with SQLite and MySQL
			" ORDER BY lm_link_updated DESC" . PHP_EOL .
			" LIMIT " . LM_C_RECENT_CHANGES_MAX . ";";
		if($sql_result = Ccms::$cDBcms->query($sql_query)) {
			while($recent = Ccms::$cDBcms->fetch_array($sql_result)) {
				if(!self::check_user_group_ids($recent['lm_section_group_ids']))	continue;
				$list[] = $recent;
				} // while
			Ccms::$cDBcms->free_result($sql_result);
			} // if
		return $list;
		} // get_changes()

	protected static function get_option_link($link) {
		$text = '';
		if(empty($link)) return '&nbsp;';
		$url_parts = parse_url($link['lm_link_url']);
		$url = '';

		if((empty($url_parts['scheme'])) &&
			(empty($url_parts['host'])) &&
			($link['lm_link_ssl']))
			$url .= self::get_base_url(true);

		if($link['lm_link_new_page']) {
			$url .= $link['lm_link_url'] . ((int)$link['lm_link_add_name2url'] ? '?name=' . $link['lm_link_name']:'');
			} // if
		else {
			$url .= 'index.php?cms_action=link&link_id=' . (int)$link['lm_link_id'] . '&name=' . urlencode($link['lm_link_name']);
			} // else

		if($link['lm_link_new_page']) {
			$text = $url . '&PARAM=_blank';
			} // if
		else {
			$text = $url;
			} // else

		return $text;
		} // get_option_link()

	public static function get_recent_changes($class = 'page_body') {
		if(!LM_C_RECENT_CHANGES_ENABLED) return false;
		$list = self::get_changes();
		if(empty($list)) return false;
		$text = '';
		$text .= '<select name="recents" id="recents" onchange="javascript:gotoOption(this)" title="' . self::help(count($list)) . '">' . PHP_EOL;
//		$text .= '	<option class="' . $class .'">' . 'Recent Changes' . '</option>' . PHP_EOL;
		foreach($list as $l) {
			$url = self::get_option_link($l);
			$text .= '	<option class="' . $class . '" value="' . urlencode($url) . '">' .
				$l['lm_link_name'] . ' in ' . $l['lm_section_name'] . ' on ' . $l['lm_link_updated'] .
				'</option>' . PHP_EOL;
			} // foreach
		$text .= '</select>' . PHP_EOL;
		$text .= PHP_EOL;
		$text .= '<script type="text/javascript">' . PHP_EOL;
		$text .= PHP_EOL;
		$text .= '	function gotoOption(elm) {' . PHP_EOL;
		$text .= '		var val = elm.options[elm.selectedIndex].value;' . PHP_EOL;
		$text .= '		var uri = decodeURIComponent(val.replace(/\+/g, " "));' . PHP_EOL;
//		$text .= '		alert(uri);' . PHP_EOL;
		$text .= '		var parts = uri.split("&PARAM=");' . PHP_EOL;
//		$text .= '		alert(parts);' . PHP_EOL;
		$text .= '		window.open(parts[0],parts[1]);' . PHP_EOL;
		$text .= '	} // gotoOption()' . PHP_EOL;
		$text .= PHP_EOL;
		$text .= '</script>' . PHP_EOL;
		$text .= PHP_EOL;
		return $text;
		} // get_recent_changes()

} // Ccms_recents_links
