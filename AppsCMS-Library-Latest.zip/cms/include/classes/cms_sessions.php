<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_sessions.php 3115 2023-02-10 02:33:50Z robert0609 $
 */

/**
 * Description of Ccms_sessions
 *
 * This classes Ccms_sessions_mysql and Ccms_sessions_file operate by static method calls from the web server, these calls are prefixed by underscore (_)
 *
 * The dynamic calls to Ccms_sessions are for session maintenance.
 *
 * NOTE: the mysql mode needs to use separate code from other mysql code as the web server may call after the destructors here have run.
 *
 * Refer to: "http://php.net/manual/en/function.session-set-save-handler.php"
 *
 * @author robert0609
 */

class Ccms_sessions_file extends Ccms_base {
	protected static $session_path_prefix = '';

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function _file_open($save_path, $session_name) {
		if(!self::chkdir($save_path)) {
			if(self::is_debug()) {
				self::logSessEvent($save_path . ' not a directory !!!!');
				} // if
			syslog(LOG_CRIT, $save_path . ' not a directory !!!!');
			return false;
			} // if
		if(!is_readable($save_path)) {
			if(self::is_debug()) {
				self::logSessEvent($save_path . ' not readable  (set RW owner to web server user)!!!!');
				} // if
			syslog(LOG_CRIT, $save_path . ' not readable  (set RW owner to web server user)!!!!');
			return false;
			} // if
		if(!is_writable($save_path)) {
			if(self::is_debug()) {
				self::logSessEvent($save_path . ' not writable  (set RW owner to web server user)!!!!');
				} // if
			syslog(LOG_CRIT, $save_path . ' not writable  (set RW owner to web server user)!!!!');
			return false;
			} // if
		self::$session_path_prefix = $save_path . $session_name;
		return true;
		} // _file_open()

	public static function _file_close() {
		return true;
		} // _file_close()

	public static function _file_read($key) {
		if(empty(self::$session_path_prefix)) return '';
		$expiry = time() - self::$cms_session_timeout;

		$filepath = self::$session_path_prefix . $key;
		if(is_readable($filepath)) {
			if(filemtime($filepath) < $expiry) return '';
			$value = file_get_contents($filepath);
			} // if

		if((!isset($value)) || (empty($value))) return '';
		return self::_decode_session_data($value);
		} // _file_read()

	public static function _file_write($key, $val) {
		if(self::$cms_session_no_write) return true;
		if(empty(self::$session_path_prefix)) return false;
		if(empty($key)) return false;
		if(self::save_cms_sess()) {	// ??? what, destructor not called
			$val = session_encode();			
			} // if
		$filepath = self::$session_path_prefix . $key;
		if((file_exists($filepath)) && (!is_writable($filepath))) {
			if(self::is_debug()) {
				self::logSessEvent('Existing ' . $filepath . ' not writable (set RW owner to web server user)!!!!');
				} // if
			syslog(LOG_CRIT, 'Existing ' . $filepath . ' not writable (set RW owner to web server user) !!!!');
			return false;
			} // if
		if(file_put_contents($filepath, self::_encode_session_data($val)) === false) return false;
		return true;
		} // _file_write()

	public static function _file_destroy($key) {
		if(empty(self::$session_path_prefix)) return false;
		@unlink(self::$session_path_prefix . $key);
		return true;
		} // _file_destroy()

	public static function _file_gc($maxlifetime) {
		if(!defined('CMS_S_SESSIONS_DATA_TIMEOUT_DAYS')) return true;
		$timeout = -1;	// not set
		if((int)CMS_S_SESSIONS_DATA_TIMEOUT_DAYS < 1) return true;	// keep all
		$timeout = time() - ((int)CMS_S_SESSIONS_DATA_TIMEOUT_DAYS * 3600 * 24);	// back in time
		$expiry = time() - $maxlifetime;	// back in time (from PHP.INI)

		if ($handle = opendir(session_save_path())) {
			while (false !== ($file = readdir($handle))) {
				if (substr($file,0,1) == '.') continue;
				$path = session_save_path() . $file;
				$atime = fileatime($path);
				if($atime < $expiry) {
					@unlink($path);
					} // if
				if(($timeout > 0) && ($atime < $timeout)) {
					@unlink($path);
					} // if
				} // while
			closedir($handle);
			} // if
		return true;
		} // _file_gc()

	protected static function _encode_session_data($value) {
		$value = preg_replace('/^' . CMS_SESSION_NAME . '_/','', $value);	// remove previous prefix
		return CMS_SESSION_NAME . '_' . $value;
		} // _encode_session_data()

	protected static function _decode_session_data($value) {
		$value = preg_replace('/^' . CMS_SESSION_NAME . '_/','', $value);	// remove previous prefix
		return $value;
		} // _decode_session_data()

	public static function init_sessions_file() {
		$sess_path = DOCROOT_FS_BASE_DIR . CMS_S_SESSIONS_FILEPATH;
		if(!is_writable($sess_path)) {
			// something wrong, will not be able to login
			self::addMsg('File path of session directory "' . basename(CMS_S_SESSIONS_FILEPATH) . '" is not writeable.');
			return false;
			} // if
		session_save_path($sess_path);
		session_set_save_handler(
			'Ccms_sessions_file::_file_open',
			'Ccms_sessions_file::_file_close',
			'Ccms_sessions_file::_file_read',
			'Ccms_sessions_file::_file_write',
			'Ccms_sessions_file::_file_destroy',
			'Ccms_sessions_file::_file_gc');
		return true;
		} // init_sessions_file()

	public static function get_user_sessions($get_expired = false) {
		$sess_path = session_save_path();
		$sesssions = array();
		$expiry = time() - self::$cms_session_timeout;
		if($dh = opendir($sess_path)) { // check sessions location
			$stmp = session_encode();	// save current session
			while (($file = readdir($dh)) !== false) {
				if(!Ccms::is_dir_usable($file)) continue;
				if(is_dir($sess_path . $file)) continue;
				if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $file)) continue;
				$filepath = $sess_path . $file;
				if(is_readable($filepath)) {
					if((!$get_expired) &&	// include expired
						(filemtime($filepath) < $expiry)) continue;	// expired
					$sess = array(
						'file' => $file,
						'expired' => ((filemtime($filepath) < $expiry) ? true:false),
						'data' => '',
						);
					$value = file_get_contents($filepath);
					if(!empty($value)) {
						session_unset();
						session_decode(self::_decode_session_data($value));	// sticks it in $_SESSION
						$sess['data'] = $_SESSION;
						$sesssions[] = $sess;
						} // if
					} // if
				} // while
			session_unset();
			session_decode($stmp);	// restore current session
			} // if
		return $sesssions;
		} // get_user_sessions()

	public static function delete_user_session($sid) {
		return self::_file_destroy($sid);
		} // delete_user_session()

	// dynamic methods

} // Ccms_sessions_file

class Ccms_sessions_mysql extends Ccms_base {

	protected static $link = false;
	const SESSIONS_MYSQL_TABLE = "appscms_sessions_table";	// CMS_MYSQL table to use to store sessions

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	private static function get_create_table() {
		$creat_table = "" .
			"CREATE TABLE IF NOT EXISTS `" . self::SESSIONS_MYSQL_TABLE . "` (" .
			"  `sesskey` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL," .
			"  `mtime` int(10) unsigned NOT NULL," .
			"  `value` text NOT NULL," .
			"  PRIMARY KEY (`sesskey`)" .
			") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
		return $creat_table;
		} // get_create_table()

	private static function init_db() {	// test connect and check table present
		self::$link = new mysqli(CMS_S_SESSIONS_MYSQL_HOST,CMS_S_SESSIONS_MYSQL_USER,CMS_S_SESSIONS_MYSQL_PASSWD,CMS_S_SESSIONS_MYSQL_DATABASE);
		/* check connection */
		if(self::$link->connect_errno) {
			self::addMsg("Init connect failed: %s\n", $mysqli->connect_error);
			self::$link->close();
			self::$link = false;
			return false;
			} // if
		if(!self::$link->query(self::get_create_table())) {
			self::$link->close();
			self::$link = false;
			return false;
			} // if
		return true;
		}	// init_db()

	public static function _mysql_open($save_path_dummy, $session_name_dummy) {
		if(!self::$link) {
			self::$link = new mysqli(CMS_S_SESSIONS_MYSQL_HOST,CMS_S_SESSIONS_MYSQL_USER,CMS_S_SESSIONS_MYSQL_PASSWD,CMS_S_SESSIONS_MYSQL_DATABASE);
			/* check connection */
//			if(self::$link->connect_errno) {
//				self::addMsg("Connect failed: %s\n", $mysqli->connect_error);
//				self::$link->close();
//				self::$link = false;
//				return false;
//				} // if
			} // if
		return true;
		} // _mysql_open()

	public static function _mysql_close() {
		if(self::$link) {
			self::$link->close();
			self::$link = false;
			} // if
		return true;
		} // _mysql_close()

	public static function _mysql_read($key) {
		if($value_query = self::$link->query(
			"select value,expiry" .
			" from " . self::SESSIONS_MYSQL_TABLE .
			" where sesskey = '" . $key . "'")) {
			$value = $value_query->fetch_assoc();
			$value_query->close();
			if(!empty($value)) {
				$val = self::_decode_session_data($value['value']);
				return $val;
				} // if
			} // if
		return '';
		} // _mysql_read()

	public static function _mysql_write($key, $val) {

		if(self::$cms_session_no_write) return true;
		if(!self::is_cms_sess_saved()) {	// ??? what, destructor not called
			self::save_cms_sess();
			$val = session_encode();			
			} // if

		$mtime = time();
		$value = self::_encode_session_data($val);

		$sql = "REPLACE INTO " . self::SESSIONS_MYSQL_TABLE  .
			" SET sesskey = '" . $key . "'" .
			", mtime = '" . $mtime . "'" .
			", value = '" . $value . "'";
		return (self::$link->query($sql) ? true:false);
		} // _mysql_write()

	public static function _mysql_destroy($key) {
		$sql = "DELETE FROM " . self::SESSIONS_MYSQL_TABLE  .
			" WHERE sesskey = '" . $key . "'";
		return (self::$link->query($sql) ? true:false);
		} // _mysql_destroy()

	public static function _mysql_gc($maxlifetime) {
		if(!defined('CMS_S_SESSIONS_DATA_TIMEOUT_DAYS')) return true;
		if((int)CMS_S_SESSIONS_DATA_TIMEOUT_DAYS < 1) return true;	// keep all
		$sql = "DELETE FROM " . self::SESSIONS_MYSQL_TABLE  .
			" WHERE mtime < " . (time() + $maxlifetime) . "";
		if((int)CMS_S_SESSIONS_DATA_TIMEOUT_DAYS > 0) {
			$max_seconds = (int)CMS_S_SESSIONS_DATA_TIMEOUT_DAYS * 24 * 3600;
			$sql .= ' OR mtime < ' . (time() + $max_seconds) . '';
			}
		return (self::$link->query($sql) ? true:false);
		} // _mysql_gc()

	protected static function _encode_session_data($value) {
		$value = preg_replace('/^' . CMS_SESSION_NAME . '_/','', $value);	// remove previous prefix
		return CMS_SESSION_NAME . '_' . $value;
		} // _encode_session_data()

	protected static function _decode_session_data($value) {
		$value = preg_replace('/^' . CMS_SESSION_NAME . '_/','', $value);	// remove previous prefix
		return $value;
		} // _decode_session_data()

	public static function init_sessions_mysql() {
		if(!self::init_db()) return false;
		session_set_save_handler(
			'Ccms_sessions_mysql::_mysql_open',
			'Ccms_sessions_mysql::_mysql_close',
			'Ccms_sessions_mysql::_mysql_read',
			'Ccms_sessions_mysql::_mysql_write',
			'Ccms_sessions_mysql::_mysql_destroy',
			'Ccms_sessions_mysql::_mysql_gc');
		return true;
		} // init_sessions_mysql()

	public static function get_user_sessions($get_expired = false) {
		$sesssions = array();
		$expiry = time() - self::$cms_session_timeout;
		if($value_query = self::$link->query(
			"select value,expiry" .
			" from " . self::SESSIONS_MYSQL_TABLE .
			(!$get_expired ? " where expiry >= " . $expiry:''))) {
			$stmp = session_encode();	// save current session
			while($value = $value_query->fetch_assoc()) {
				if(!empty($value)) {
					$val = self::_decode_session_data($value['value']);
					$sess = array(
						'expired' => (((int)$value['expiry'] < $expiry) ? true:false),
						'file' => 'MySQL',
						'data' => '',
						);
					if(!empty($val)) {
						session_unset();
						session_decode(self::_decode_session_data($val));	// sticks it in $_SESSION
						$sess['data'] = $_SESSION;
						$sesssions[] = $sess;
						} // if
					} // if
				} // while
			$value_query->close();
			session_unset();
			session_decode($stmp);	// restore current session
			} // if
		return $sesssions;
		} // get_user_sessions()

	public static function delete_user_session($sid) {
		return self::_mysql_destroy($sid);
		} // delete_user_session()

	// dynamic methods

} // Ccms_sessions_mysql

class Ccms_sessions extends Ccms_base {

	protected static $types = array(
		'APACHE_FILE',	// native apache or web server user
		'PHP_FILE',		// php code
		'CMS_FILE',		// cms filesystem (similar to PHP_FILE but stored by AppsCMS functions)
		'CMS_MYSQL',	// uses a MySQL database table.
		);

	protected static $cms_session_save_path = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function get_session_types() {
		return self::$types;
		} // get_session_types()

	private static function has_reload_marker($remove = false) {
		// this function is used to stop repeated reloads
		if(!is_dir(VAR_FS_VARIABLES_DIR)) @mkdir(VAR_FS_VARIABLES_DIR);
		if(file_exists(SESSION_RELOADED_MRKER)) {
			if($remove) @unlink(SESSION_RELOADED_MRKER);
			else {
				echo <<< EOTRED

	<p>Error persists, contact administrator.</p>

EOTRED;

				} // else
			return true;
			} // if
		if(!$remove) {
			file_put_contents(SESSION_RELOADED_MRKER,'Bad session reload: ' . date('Ymd-His') . PHP_EOL);
			$url = $_SERVER['PHP_SELF'];
			echo <<< EOTRED

	<p>Attempting to reload. If error persists contact administrator.</p>
	<script>
		setTimeout(function () {
			window.location.replace("{$url}");	// reload
			}, 2000);
	</script>

EOTRED;

			} // if
		return false;
		} // has_reload_marker()

	public static function init() {

		if (self::is_cli()) return false;	// cli mode, no session

		// these two are usually hard code errors.
		// Or caused by error correction stats, either way these are installation/update or hard code errors.
		if(!empty($_SESSION)) {
			echo '<p>Unspecified session already exists. Cannot start user session.</p>';
			self::has_reload_marker();
			ob_flush();
			flush();
			exit(0);
			} // if
		// echo 'Testing 123' .PHP_EOL; ob_flush(); flush();	// test
		if(headers_sent()) {
			echo '<p>Headers already sent. Cannot start user session.</p>';
			self::has_reload_marker();
			@ob_flush();
			flush();
			exit(0);
			} // if
		self::has_reload_marker(true);

		$type = self::get_cms_sess_type();
		session_name(CMS_SESSION_NAME);

		switch($type) {	// sort as most complex first, make sure we get a session
		default:
		case 'CMS_MYSQL':	// uses a MySQL database table.
			if(Ccms_sessions_mysql::init_sessions_mysql()) 	break;
			// lese fall thru
		case 'CMS_FILE':	// cms filesystem (similar to PHP_FILE)
			if(Ccms_sessions_file::init_sessions_file()) break;
			// lese fall thru
		case 'PHP_FILE':	// php code
			// set the PHP handler directory location
			if(is_writable(VAR_FS_SESSION_DIR)) {
				session_save_path(VAR_FS_SESSION_DIR);
				break;
				} // if
			// something wrong, will not be able to login
			self::addAdminMsg('Session directory "' . basename(VAR_FS_SESSION_DIR) . '" is not writeable.');
			// lese fall thru
		case 'APACHE_FILE':	// native apache
			// nothing here, apache automatic
			break;
			} // switch
		self::$cms_session_save_path = session_save_path();
		self::have_session(Ccms_auth::start_user_session());
		self::$cms_session_id = session_id();

		return self::have_session();
		} // init()

	public function decode_foreign_session_values2array($values) {	// this method decodes someone elses session information (e.g. for stats)

		self::$cms_session_no_write = true;
		// session_save_session(FALSE);
		$current = session_encode();
		session_unset();
		session_decode($values);
		$values_array = $_SESSION;
		session_unset();
		session_decode($current);
		// session_save_session(TRUE);
		self::$cms_session_no_write = false;

		return $values_array;
		} // decode_foreign_session_values2array()

	public static function is_session_browsing_available() {
		$type = CMS_S_SESSION_TYPE;
		switch($type) {
		case 'CMS_MYSQL':	// uses a MySQL database table.
		case 'CMS_FILE':	// cms filesystem (similar to PHP_FILE)
			return true;
		case 'PHP_FILE':	// php code
		case 'APACHE_FILE':	// native apache
		default:
			if((!empty(self::$cms_session_save_path)) &&
				(is_dir(self::$cms_session_save_path)) &&
				(is_readable(self::$cms_session_save_path)))
				return true;
			break;
			} // switch
		return false;
		} // is_session_browsing_available()

	public static function get_user_sessions_title() {
		if(!self::is_session_browsing_available()) return false;
		$type = CMS_S_SESSION_TYPE;
		switch($type) {
		case 'CMS_MYSQL':	// uses a MySQL database table.
			return CMS_PROJECT_SHORTNAME . ' MySQL DB Session Storage';
		case 'CMS_FILE':	// cms filesystem (similar to PHP_FILE)
			return CMS_PROJECT_SHORTNAME . ' Files Session Storage';
		case 'PHP_FILE':	// php code
			return 'PHP Files Session Storage';
		case 'APACHE_FILE':	// native apache
			return 'Apache Files Session Storage';
		default:
			break;
			} // switch
		return '';
		} // get_user_sessions_title()

	public static function get_user_sessions($get_expired = false) {
		if(!self::is_session_browsing_available()) return false;
		if(self::get_or_post_checkbox('show_expired')) $get_expired = true;
		$type = CMS_S_SESSION_TYPE;
		switch($type) {
		case 'CMS_MYSQL':	// uses a MySQL database table.
			return Ccms_sessions_mysql::get_user_sessions($get_expired);
		case 'CMS_FILE':	// cms filesystem (similar to PHP_FILE)
			return Ccms_sessions_file::get_user_sessions($get_expired);
		case 'PHP_FILE':	// php code
		case 'APACHE_FILE':	// native apache
			return self::get_sys_user_sessions();
		default:
			break;
			} // switch
		return false;
		} // get_user_sessions()

	public static function delete_user_session($sid) {
		$type = CMS_S_SESSION_TYPE;
		switch($type) {
		case 'CMS_MYSQL':	// uses a MySQL database table.
			return Ccms_sessions_mysql::delete_user_session($sid);
		case 'CMS_FILE':	// cms filesystem (similar to PHP_FILE)
			return Ccms_sessions_file::delete_user_session($sid);
		case 'PHP_FILE':	// php code
		case 'APACHE_FILE':	// native apache
			return self::delete_sys_user_session($sid);
		default:
			break;
			} // switch
		return false;
		} // delete_user_session()

	protected static function get_sys_user_sessions() {
		$sess_path = self::$cms_session_save_path;
		$sesssions = array();
		$expiry = time() - self::$cms_session_timeout;
		if($dh = opendir($sess_path)) { // check sessions location
			$stmp = session_encode();	// save current session
			while (($file = readdir($dh)) !== false) {
				if(!Ccms::is_dir_usable($file)) continue;
				$filepath = $sess_path . '/' . $file;
				if(is_dir($filepath)) continue;
				if(preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $file)) continue;
				if(is_readable($filepath)) {
					if((!self::get_or_post_checkbox('show_expired')) &&	// include expired
						(filemtime($filepath) < $expiry)) continue;	// expired
					$sess = array(
						'file' => $file,
						'expired' => ((filemtime($filepath) < $expiry) ? true:false),
						'data' => '',
						);
					$value = file_get_contents($filepath);
					if(!empty($value)) {
						session_unset();
						session_decode(self::_decode_session_data($value));	// sticks it in $_SESSION
						$sess['data'] = $_SESSION;
						$sesssions[] = $sess;
						} // if
					} // if
				} // while
			session_unset();
			session_decode($stmp);	// restore current session
			} // if
		return $sesssions;
		} // get_sys_user_sessions()

	protected static function delete_sys_user_session($sid) {
		$sess_path = self::$cms_session_save_path . '/' . $sid;
		if(file_exists($sess_path)) {
			unlink($sess_path);
			return true;
			} // if
		return false;
		} // delete_sys_user_session()

	protected static function _encode_session_data($value) {
		$value = preg_replace('/^' . CMS_SESSION_NAME . '_/','', $value);	// remove previous prefix
		return CMS_SESSION_NAME . '_' . $value;
		} // _encode_session_data()

	protected static function _decode_session_data($value) {
		$value = preg_replace('/^' . CMS_SESSION_NAME . '_/','', $value);	// remove previous prefix
		return $value;
		} // _decode_session_data()

	public static function filter_session(&$filter,&$session,$exact,$show_expired) {
		// remove clutter
		// unset($session['data']['clientMetadata']);
		// unset($session['data']['msgs']);

		// add readable DT
		if(!empty($session['data']['user']['logged_in_time'])) {
			$session['data']['user']['logged_in_time_dt'] = date('Y-m-d H:i:s',$session['data']['user']['logged_in_time']);
			} // if
		if(!empty($session['data']['user']['time'])) {
			$timeout = (!empty($session['data']['session_timeout']) ? $session['data']['session_timeout']:self::$cms_session_timeout);
			if(((int)$session['data']['user']['time'] + $timeout) < (int)time()) {
				$session['expired'] = true;
				if(!$show_expired)	// remove expired, not shown
						return false;
				} // if
			else $session['expired'] = false;
			$session['data']['user']['timeout_dt'] = date('Y-m-d H:i:s',($session['data']['user']['time'] + $timeout));
			} // if
		if(!empty($session['data']['last_time']))
			$session['data']['last_time_dt'] = date('Y-m-d H:i:s',$session['data']['last_time']);

	//	if(Ccms::is_ajax())
	//		unset($session['data']['last_ajax']);	// weird

		ksort($session['data']);
		if(!empty($session['data']['user']))
			ksort($session['data']['user']);

		if(empty($filter)) return true;	// show all

		$str = strtolower(self::json_encode($session['data']));
		return Ccms_search::search_cmp($filter, $str,$exact);
		} // filter_session()

	// dynamic methods

} // Ccms_sessions
