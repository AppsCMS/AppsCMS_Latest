<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_auth.php 3444 2024-05-05 06:37:14Z robert0609 $
 */

/**
 * Description of Ccms_auth
 *
 * @author robert0609
 */

require_once 'cms_api_jwt.php';	// speed up for proxy (no autoloader needed)

class Ccms_auth_pam extends Ccms_base {	// PAM class
	protected static $disabled = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_pam_ok() {	// check if PAM is setup
		if(self::$disabled) return false;
		if((!extension_loaded('pam')) || (!function_exists('pam_auth'))) {
			self::log_msg('INSTALL ERROR: No PAM PHP functions installed.');
			self::$disabled = true;
			return false;	// the LDAP module not loaded
			} // if
		return true;
		} // is_pam_ok()

	public static function is_pam_authenticated($username = false, $passwd = false) {
		if(!self::is_pam_ok()) return false;

		if(!$username) $username = self::get_or_post_str('user_name');
		if(!$passwd) $passwd = self::get_or_post_str('user_password');

		$error = false;
		if(pam_auth($username, $passwd, $error)) {
			return true;	// authenticated
			} // if
		else {	//
			if(!empty($error)) {
				self::addMsg('PAM login failed for ' . $username . ': ' . $error . '.','warn');
				} // if
			return false;
			} // else
		} // is_pam_authenticated()

} // Ccms_auth_pam

class Ccms_auth_ldap extends Ccms_base {	// LDAP class
	const LDAP_OPT_DIAGNOSTIC_MESSAGE = 0x0032;

	protected static $disabled = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_ldap_ok() {	// check if LDAP is setup
		if(self::$disabled) return false;
		if(strlen(CMS_S_LDAP_SERVER_URI) < 6) {	// have no server
			self::$disabled = true;
			return false;
			} // if
		if(!function_exists('ldap_connect')) {
			self::log_msg('INSTALL ERROR: No LDAP PHP functions installed.');
			self::$disabled = true;
			return false;	// the LDAP module not loaded
			} // if
		return true;
		} // is_ldap_ok()

	private static function get_ldap_search_result(&$ldapconn,$username) {

		if((strlen(CMS_S_LDAP_SERVER_SEARCH_DOM) > 8) &&
			(strlen(CMS_S_LDAP_SERVER_SEARCH_FILTER) > 4)) {	// want search with somewhere to put results

			$dom = CMS_S_LDAP_SERVER_SEARCH_DOM;
			$filter = CMS_S_LDAP_SERVER_SEARCH_FILTER;	// put in username, if there
			$filter = str_replace('$username',$username,$filter);
			$attributes = array("*");
			if(strlen(CMS_S_LDAP_SERVER_SEARCH_KEYS) > 2)
				$attributes = explode(',',CMS_S_LDAP_SERVER_SEARCH_KEYS);	// make keys

			if(($search_handle = ldap_search($ldapconn, $dom, $filter, $attributes)) === false) {
				self::set_cms_sess_var(false,'ldap'); // bad search
				$err = ldap_error($ldapconn);
				self::addDebugMsg('LDAP Search Failed: ' . $err);
				} // if
			else {
				self::set_cms_sess_var(ldap_get_entries($ldapconn, $search_handle),'ldap');
				} // else
			} // if
		return true;
		} // get_ldap_search_result()

	private static function chk_ldap_connection_authed(&$ldapconn,&$username,&$password) {
		// Help talking to AD
		ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
		ldap_set_option($ldapconn, LDAP_OPT_REFERRALS, 0);

		// binding to ldap server
		$user_dom = Ccms_auth::chk_add_default_user_domain($username);
		if(!$ldapbind = @ldap_bind($ldapconn, $user_dom, $password)) {
			$extended_error = false;
			$err = '';
			ldap_get_option($ldapconn, self::LDAP_OPT_DIAGNOSTIC_MESSAGE, $extended_error);
			if (!empty($extended_error)) {
				$err .= $extended_error;
			    $errno = explode(',', $extended_error[2]);
				// $errno = explode(' ', $errno[2]);
				if ((int)$errno[0] == 532) {
					$err .= ': Password expired.';
					} // if
				}
			self::log_msg('WARNING: Failed to auth "' . $username . '"' . $err . '.','warn');
			return false;	// ???
			} // if

		self::get_ldap_search_result($ldapconn, $username);

		@ldap_unbind($ldapbind);	// let em go on
		return true;
		} // chk_ldap_connection_authed()

	public static function is_user_ldap_authed($username,$password) { // using ldap bind
		if(!self::is_ldap_ok()) {	// have a server
			self::log_msg('No LDAP server setup.','info');
			return false;
			} // if
		if((empty($username)) || (empty($password))) {	// some basics
			self::log_msg('CODE ERROR: LDAP auth attempt missing parameter by caller.');
			return false;
			} // if
		// check authed
		$def_port = (((strlen(CMS_S_LDAP_SERVER_URI_PORT) >= 2) && (is_numeric(CMS_S_LDAP_SERVER_URI_PORT))) ? (int)CMS_S_LDAP_SERVER_URI_PORT:389);
		$ldap_servers = self::unserialize_string2arry(CMS_S_LDAP_SERVER_URI,',');
		if((empty($ldap_servers)) || (!is_array($ldap_servers)) || (!isset($ldap_servers[0]))) {
			self::log_msg('No LDAP server/s configured.');
			return false;
			} // if
		$ldapconn = false;
		foreach($ldap_servers as $lds) {
			if(!isset($lds[0])) continue;	// false marker
			if(empty($lds[0])) continue;
			$lds = $lds[0];
			if(preg_match('/\:[0-9]{3,5}$/', $lds))	{	// check if port is supplied
				$port = preg_replace('/^(.*:)([0-9]{3,5})$/', '\2', $lds);	// strip the off server
				$lds = preg_replace('/\:[0-9]{3,5}$/', '', $lds);	// strip the off port
				} // if
			else $port = $def_port;
			if((self::can_connect2host($lds,$port,CMS_S_LDAP_SERVER_TIMEOUT,false)) &&	// don't hang if no LDAP server
				(($ldapconn = @ldap_connect($lds, $port)) !== false)) {
				self::log_info_msg('LDAP connect to ' . $lds . ':' . $port);
				if(self::chk_ldap_connection_authed($ldapconn, $username, $password)) {
					self::log_info_msg('User "' . $username . '" authenticated on ' . $lds . ':' . $port);
					return true;	// authed ok
					} // if
				} // if
			// keep going
			} // foreach
		if($ldapconn === false) {
			self::$disabled = true;
			self::log_msg('ERROR: Failed to connect to a LDAP server.');
			return false;
			} // if
		self::log_msg('WARNING: Failed to auth "' . $username . '".','warn');
		return false;	// ???
		} // is_user_ldap_authed()

	public static function logout_ldap_user() {
		self::unset_cms_sess_var('ldap');
		// that's it
		return true;
		} // logout_ldap_user()

} // Ccms_auth_ldap

class Ccms_auth_cookie extends Ccms_base {
	// cookie auth functions
	public static function get_user_login_cookie_id($user_id) {
		$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_added,cms_user_updated" .
			" FROM  cms_users" .
			" WHERE cms_user_id = " . (int)$user_id . "";
		if(($user = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user))) {
			$cookie_id = $user['cms_user_id'] . ':' . session_id() . ':' . sha1($user['cms_user_name'] . $user['cms_user_added'] . $user['cms_user_updated']) ;
			return $cookie_id;
			} // if$
		return false;
		} // get_user_login_cookie_id()

	protected static function set_login_cookie($value = false,$time = false,$secure = true,$httponly = true) {
		if(empty($_COOKIE)) return false;
		if(!CMS_S_ALLOW_COOKIE_LOGIN_BOOL) return false;
		if(($secure) && (!self::is_ssl_inuse())) return false;
		$name = CMS_LOGIN_COOKIE_NAME;
		if($value === false) $value = (!empty($_COOKIE[$name]) ? $_COOKIE[$name]:'');
		if($time === false) $time = time() + CMS_S_SESSIONS_COOKIE_TIMEOUT_SECS;	// 90 days
		$path = CMS_URI_ALIAS;
		if(empty($path)) $path = '/';
		$dom = CMS_DOMAIN;

		if(!setcookie($name, $value, $time,$path,$dom,$secure,$httponly)) {
			self::addDebugMsg('Falied to set ' . $name . ' login cookie.');
			return false;
			} // if
		return true;
		} // set_login_cookie()

	public static function is_a_cookie_login($secure = true) {
		if(Ccms_api_jwt::is_use_jwt_ok()) return false;
		if(($secure) && (!self::is_ssl_inuse())) return false;
		if(((!isset($_COOKIE)) || (empty($_COOKIE))) &&	// no cookies
			(preg_match('/no_cookie/',self::get_cms_action() . self::get_app_action()))) {	// don't redirect again
			$url = 'index.php?cms_action=no_cookie';	// putup cookie msg
			self::do_redirect_uri($url);	// should not return;
			return false;
			} // if
		$name = CMS_LOGIN_COOKIE_NAME;
		if((CMS_S_ALLOW_COOKIE_LOGIN_BOOL) &&
			// already logged in (self::is_login_allowed()) &&
			(isset($_COOKIE[$name])) &&
			(!empty($_COOKIE[$name]))) {
			return true;
			} // if
		return false;
		} // is_a_cookie_login()

	public static function login_check_cookie() {
		if(!self::is_a_cookie_login())
			return false;	// no cookie

		if(($user = self::get_cms_sess_var('user')) &&
			(!empty($user['id']))) {
			self::set_login_cookie();	// update cookie time
			return true;
			} // if

		// else do cookie login
		$cookie = $_COOKIE[CMS_LOGIN_COOKIE_NAME];
		list($id,$sid,$sig) = explode(':',$cookie);
		$chk_cookie = self::get_user_login_cookie_id($id);
		if(($chk_cookie == $cookie) &&
			(Ccms_auth::log_in_user_id($id,false))) {	// also calls login_user_cookie()
			self::set_login_cookie();	// update cookie time
			$url = self::get_base_url(true) . Ccms::get_body_uri();
			self::do_redirect_uri($url);
			} // if
		return false;
		} // login_check_cookie()

	public static function login_user_cookie($cms_user_id,$cms_user_name = false) {
		if(!CMS_S_ALLOW_COOKIE_LOGIN_BOOL) return false;
		if(Ccms_api_jwt::is_use_jwt_ok()) return false;
		$cookie_id = self::get_user_login_cookie_id($cms_user_id);
		self::set_login_cookie($cookie_id);
		$next_time = time() + CMS_S_SESSIONS_COOKIE_TIMEOUT_SECS;
		self::update_user_json_data('cms_user_login_cookie_time', $next_time,$cms_user_name);
		return true;
		} // login_user_cookie()

	public static function logout_cookie_user() {
		if(isset($_COOKIE[CMS_LOGIN_COOKIE_NAME])) {
			$time = time() - (CMS_S_SESSIONS_COOKIE_TIMEOUT_SECS * 10);	// expire cookie
			self::set_login_cookie('',$time);
			unset($_COOKIE[CMS_LOGIN_COOKIE_NAME]);
			} // if
		} // logout_cookie_user()

	} // Ccms_auth_cookie

class Ccms_auth_passwd extends Ccms_base {

	const PASSWD_ALG = 'sha256';

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods
	public static function hash_passwd($passwd) {
		$hash = hash(self::PASSWD_ALG, $passwd);
		return $hash;
		} // hash_passwd()

	public static function chk_passwd_hash($passwd,$hash) {
		$chk = self::hash_passwd($passwd);
		if(trim($chk) == trim($hash)) return true;
		return false;
		} // chk_passwd_hash()

	public static function chk_user_passwd($passwd,$user_id) {
		$user = self::$cDBcms->get_data_in_table('cms_users',
			array('cms_user_passwd_hash','cms_user_password_md5'),
			"cms_user_enabled = 1 AND cms_user_id = " . (int)$user_id);
		if(self::chk_passwd_hash($passwd, $user['cms_user_passwd_hash'])) return true;
		if(md5($passwd) == $user['cms_user_password_md5']) return true;	// depreciated
		return false;
		} // chk_user_passwd()

	// dynamic methods

} // Ccms_auth_passwd

class Ccms_auth extends Ccms_base {

	protected static $cms_apps_auth_ok_chkd = false;	// timesaver
	protected static $cms_apps_auth_ok = false;
	protected static $cms_apps_login = false;
	protected static $cms_apps_session_started = false;
	protected static $eula_checked = false;	// timesaver

	protected static $login_local = false;

	protected static $cApps_Auth = false;

	protected static $login_allowed = false;
	protected static $user2apache = false;
	protected static $cms_access_logged = false;

	protected const AUTH_VERIFY_JSON = 'auth_verfication.json';

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		self::log_user2apache();
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_ldap_ok() {	// check if LDAP is setup link function
		return Ccms_auth_ldap::is_ldap_ok();
		} // is_ldap_ok()

	public static function is_pam_ok() {	// check if LDAP is setup link function
		return Ccms_auth_pam::is_pam_ok();
		} // is_ldap_ok()

	public static function get_verification_code() {
		$code = rand( 100000, 999999 );	// 6 digit
		return $code;
		} // get_verification_code()

	protected static function set_auth_verification_code($code = false, $email = false, $mobile = false, $type = 'base') {
		$path = VAR_FS_AUTH_DIR . self::AUTH_VERIFY_JSON;
		$mode = (file_exists($path) ? 'r+':'w');
		if(!$fp = self::file_safe_wopen($path,$mode)) {	// failed to open data and lock it
			self::addAdminMsg('AUTH SET CODE: Failed to open code verification json.');
			return false;
			} // if
		if($mode == 'w') {	// new json
			$verif = [];
			self::addAdminMsg('Initialised new auth verification file.','warn');
			} // if
		else if($json = fread($fp,8192)) {
			$verif = self::json_decode($json, true);
			if(!is_array($verif)) $verif = [];
			} // else if
		else {	// ??
			self::file_safe_wclose($fp);
			self::addAdminMsg('Failed to open auth verification data.','warn');
			return false;
			} // else
		if((empty($code)) || (!$email && !$mobile)) { // clean codes
			$new_verif = []; $old_cnt = 0; $new_cnt = 0;
			$now = time();
			foreach($verif as $v) {
				if(empty($v['expiry'])) continue;	// sys indexes or something else
				$old_cnt++;
				if((int)$v['expiry'] > (int)$now) {
					$new_verif[] = $v;
					$new_cnt++;
					} // if
				} // foreach
			$json = self::json_encode($new_verif);
			@fseek($fp,0,SEEK_SET);
			fwrite($fp,$json);
			self::file_safe_wclose($fp);
			if($mode == 'w') self::chmod_chown($path);
			self::addAdminMsg('AUTH CODE: cleaned ' . ($old_cnt - $new_cnt) . ' expiried verification codes.','success');
			return true;
			} // if
//		if(empty($code)) {
//			self::addAdminMsg('AUTH CODE ERROR: missing verification code to save.');
//			return false;
//			} // if
		$expiry = (time() + ((int)CMS_C_VERIFY_CODE_EXPIRY_HOURS * 60 * 60));	// seconds
		$create_time = date('c');
		$expiry_time = date('c',$expiry);

		// do this way in case there is same code sent twice to different users
		$verif[] = array(	// add a standard default array
			'code' => $code,
			'email' => $email,
			'mobile' => $mobile,
			'expiry' => $expiry,
			'type' => $type,
			'create_time' => $create_time,	// for debug
			'expiry_time' => $expiry_time,	// for debug
			);
		usort($verif,function($a,$b) {
			if((int)$a['expiry'] < (int)$b['expiry']) return 1;
			if((int)$a['expiry'] > (int)$b['expiry']) return -1;
			return 0;
			});

		$json = self::json_encode($verif);
		@fseek($fp,0);
		fwrite($fp,$json);
		self::file_safe_wclose($fp);
		if($mode == 'w') self::chmod_chown($path);
		self::addAdminMsg('AUTH CODE: added verification codes.','success');
		return true;
		} // set_auth_verification_code()

	public static function clear_expired_verification_codes() {
		return self::set_auth_verification_code();
		} // clear_expired_verification_codes()

	public static function chk_auth_verification_code($code, $email = false, $mobile = false, $type = 'base') {
		if((!$code) || (!$email && !$mobile)) {
			self::addAdminMsg('AUTH CODE ERROR: missing verification code or email or mobile to checked.');
			return false;
			} // if
		$path = VAR_FS_AUTH_DIR . self::AUTH_VERIFY_JSON;
		if(!$verify = self::load_json($path)) {
			self::addAdminMsg('AUTH CHECK CODE: Failed to open code verification json.','warn');
			return false;
			} // if
		$now = time();
		foreach($verify as $v) {
			if(empty($v['expiry'])) continue;
			if(empty($v['code'])) continue;
			if((int)$v['expiry'] < (int)$now) continue;	// expired
			if($v['type'] != $type) continue;
			if((int)$v['code'] == (int)$code) {
				if(($email) && ($v['email']) && ($v['email'] == $email)) return true;	// verified email
				if(($mobile) && ($v['mobile']) && ($v['mobile'] == $mobile)) return true;	// verified mobile
				} // if
			} // foreach
		return false;	// not verified
		} // chk_auth_verification_code()

	public static function already_sent_auth_verification_code($email = false, $mobile = false, $type = 'base') {
		if(!$email && !$mobile) {
			self::addAdminMsg('AUTH CODE ERROR: missing verification email or mobile to check sent.');
			return false;
			} // if
		$path = VAR_FS_AUTH_DIR . self::AUTH_VERIFY_JSON;
		if(!$verify = self::load_json($path)) {
			self::addAdminMsg('AUTH SENT CODE: Failed to open code verification json.','warn');
			return false;
			} // if
		$now = time();
		foreach($verify as $v) {
			if(empty($v['expiry'])) continue;
			if((int)$v['expiry'] < (int)$now) continue;	// expired
			if($v['type'] != $type) continue;
			if(($email) && ($v['email']) && ($v['email'] == $email)) return true;	// have email
			if(($mobile) && ($v['mobile']) && ($v['mobile'] == $mobile)) return true;	// have mobile
			} // foreach
		return false;	// not verified
		} // already_sent_auth_verification_code()

	 public static function send_email_verification_code($to_address,$to_name = '',$resend = false, $type = 'base') {
		if(($type == 'base') && (!CMS_C_CONFIRM_EMAIL)) return false;	// not required
		if((!$resend) && (self::already_sent_auth_verification_code($to_address,false,$type))) return true;	// don't swamp inbox with codes
		if(!Ccms_email_plugin::is_enabled()) {
			self::addAdminMsg('AUTH CODE: Email confirm required but email plugin is not enabled.');
			return false;
			} // if
		$code = self::get_verification_code();
		$expiry = (time() + ((int)CMS_C_VERIFY_CODE_EXPIRY_HOURS * 60 * 60));	// seconds
		$expiry_time = date('l M jS, g:ia',$expiry);
		$email_text = 'Please enter the verfication code ' . $code . PHP_EOL .
			'for ' . CMS_C_CO_NAME . ' to verify your email address on your open web browser screen.' . PHP_EOL .
			'Code expires: ' . $expiry_time . '.' . PHP_EOL .
			'Regards' . PHP_EOL .
			CMS_C_CO_NAME . PHP_EOL;
		$email_subject =  'Email Verification Code ' . $code . ' from ' . CMS_C_CO_NAME;
//		$from_name and $from_address will be entered email plugin defaults,
		if(!Ccms_email_plugin::send_out_mail(
				$to_name,
				$to_address,
				$email_text,
				$email_subject)) {
			self::addMsg('Failed to send email verification code to "' . $to_address . '".');
			return false;
			} // if
		self::addMsg('Emailed verification code to "' . $to_address . '".','success');
		return self::set_auth_verification_code($code, $to_address, false,$type);
		} // send_email_verification_code()

	public static function send_sms_verification_code($to_mobile,$to_name = '',$resend = false, $type = 'base') {
		if(($type == 'base') && (!CMS_C_CONFIRM_MOBILE)) return false;	// not required
		if((!$resend) && (self::already_sent_auth_verification_code(false,$to_mobile,$type))) return true;	// don't swamp messages with codes
		if(!Ccms_sms_plugin::is_enabled()) {
			self::addAdminMsg('Mobile confirm required but SMS plugin is not enabled.');
			return false;
			} // if
		$code = self::get_verification_code();
		$expiry = (time() + ((int)CMS_C_VERIFY_CODE_EXPIRY_HOURS * 60 * 60));	// seconds
		$expiry_time = date('l M jS, g:ia',$expiry);
		$message = 'Please enter the verfication code ' . $code . PHP_EOL .
			'for ' . CMS_C_CO_NAME . ' to verify your mobile phone number on your open web browser screen.' . PHP_EOL .
			'Code expires: ' . $expiry_time . '.' . PHP_EOL .
			'Regards' . PHP_EOL .
			CMS_C_CO_NAME . PHP_EOL;
		$cPsms = new Ccms_sms_plugin();
		if(!$cPsms->send_sms_msg($to_mobile, $message)) {
			self::addMsg('Failed to send SMS verification code to "' . $to_mobile . '".');
			return false;
			} // if
		self::addMsg('Sent SMS message verification code to "' . $to_mobile . '".','success');
		return self::set_auth_verification_code($code, false, $to_mobile,$type);
		} // send_sms_verification_code()

	public static function chk_add_default_user_domain($username) {
		if((strlen(CMS_S_LDAP_DEF_DOMAIN) > 4) &&	// have a default domain
			(!preg_match('/^.+@.+$/', $username))) {	// and no domain in username
			$username .= '@' . CMS_S_LDAP_DEF_DOMAIN;	// add default domain
			self::log_info_msg('Using default domain for "' . $username . '".');
			} // if
		else self::log_info_msg('Domain part of "' . $username . '".');
		return $username;
		} // chk_add_default_user_domain()

	public static function sanitize($str) {
			// @TODO This might better belong in Cdatabase_xxx classes,
			// since correct SQL escaping could vary between databases.
			if (function_exists('sqlite_escape_string')) {
				return sqlite_escape_string($str);
			}
			if (method_exists('SQLite3','escapeString')) {
				return SQLite3::escapeString($str);
			}
			if (function_exists('mysqli_prepare')) {
				return mysqli_prepare($str);
			}
			return $str;
		}

	protected static function is_apps_auth_ok() {	// check if apps auth function
		if(!self::$cms_apps_auth_ok_chkd) {
			self::$cms_apps_auth_ok_chkd = true;	// do it once
			self::$cms_apps_auth_ok = false;
			if(!CMS_S_APPS_AUTH_BOOL) return false;
			if(!file_exists(APPS_FS_CLASSES_DIR . 'apps_auth.php')) return false;
			$reqd_methods = [
				'is_page_allowed',
				'is_navbar_element_allowed',
				'login',
				'init',
				'is_login_current',
				'logout',
				'get_short_name',
				'get_title',
				'get_JS',
				'get_html',
				];
			foreach($reqd_methods as $m) {
				if(!method_exists('Capps_auth', $m)) return false;
				} // foreach
			self::$cms_apps_auth_ok = true;
			} // if
		return self::$cms_apps_auth_ok;
		} // is_apps_auth_ok()

	public static function is_page_allowed($name_app_name) {
		if(!self::is_apps_auth_ok()) return true;
		return Capps_auth::is_page_allowed($name_app_name);
		} // is_page_allowed()

	public static function is_navbar_element_allowed($name_app_name) {
		if(!self::is_apps_auth_ok()) return true;
		return Capps_auth::is_navbar_element_allowed($name_app_name);
		} // is_navbar_element_allowed()

	public static function is_apps_auth_login_current() {	// check if apps auth function
		if((self::is_apps_auth_ok()) &&
			(Capps_auth::is_login_current() == false)) {
			return false;
			} // if
		return true;
		} // is_apps_auth_login_current()

	public static function is_apps_auth_logged_in() {	// check if apps auth function
		// if(!self::is_apps_auth_ok()) return false;
		if((self::get_cms_sess_var('apps_login')) &&
			(self::get_cms_sess_var('user')) &&	// check failed API calls leaving mixed up session data
			(!self::is_session_timed_out())) {
			return true;
			} // if
		return false;
		} // is_apps_auth_logged_in()

	protected static function init_apps_authed() {	// check if apps auth function
		if(!self::is_apps_auth_ok()) return true;	// ok don't logout
		if(self::$cms_apps_session_started) return true;	// don't redo
		self::$cms_apps_session_started = true;
		$user = self::get_logged_in_username();
		if(empty($user)) return true;	// ok don't logout
		if(preg_match('/guest|cli/i',$user)) return true;	// ok don't logout
		if(!self::is_apps_auth_ok()) return true;	// ok don't logout
		if(!self::$cApps_Auth) self::$cApps_Auth = new Capps_auth();	// run __construct()
		return Capps_auth::init($user);
		} // init_apps_authed()

	protected static function is_session_timed_out($update_time = true) {
		if(!self::get_cms_sess_var('user','time')) return false;	// no session or no timeout
		if(empty(self::$cms_session_timeout)) return false;	// no session_timeout (yet), no timeout
		if(((int)self::get_cms_sess_var('user','time') + self::$cms_session_timeout) < time()) return true;
		if($update_time) {
			self::set_cms_sess_var(time(),'user','time');
			self::set_cms_sess_var(self::$cms_session_timeout,'session_timeout');	// copy for session browser and backup
			} // if
		return false;
		} // is_session_timed_out()

	protected static function is_still_logged_in($update_time = true) {
		if(self::is_cms_guest()) return false;
		if(Ccms_api_jwt::is_use_jwt_ok()) {
			return Ccms_api_jwt::is_jwt_user();
			} // if
		if(self::is_session_timed_out($update_time)) {
			// login timeout
			self::logout_user();
			return false;
			} // if
		if((self::is_apps_auth_logged_in()) &&
			(!self::is_apps_auth_login_current())) {
			// remote login finished
			self::logout_user();
			return false;
			} // if
		return true;
		} // is_still_logged_in()

	protected static function inc_login_count() {
		$login_cnt = self::get_user_json_data_key('cms_user_login_count');
		if(!$login_cnt) $login_cnt = 0;
		$login_cnt++;
		self::update_user_json_data('cms_user_login_count', $login_cnt);

//		$login_datetime = self::get_gm_datetime();
//		self::update_user_json_data('cms_user_last_login', $login_datetime);
		self::update_user_json_data('cms_user_last_login', time());

		$user = self::get_logged_in_username();
		if(!empty($user)) {
			$adm = self::get_cms_sess_var('user','admin');	// goto direct to session
			self::log_msg((($adm > 0) ? 'Admin user: ':'User: ') . $user . ' logged in','info');
			} // if

		return true;
		} // inc_login_count()

	protected static function do_login_chores($user_admin,$username, $api = false) {
		// do login set ups
		self::is_cms_user(true);
		self::get_logged_in_username($username);
		self::inc_login_count();
		if(!$api) {
			clearstatcache();
			Ccms_content_cache::reset_caches(false);
			self::set_cms_sess_var(time(),'user','logged_in_time');	// login timeout in seconds
			if($user_admin) {
				if (((!Ccms::do_cms_warnings()) || (!Ccms::do_cms_cli_warnings(true))) &&
					(self::getMsgsCount() > 0) &&
					(CMS_S_DB_DIE_ON_ERRORS_BOOL)) {
					echo self::getMsgs();
					echo '<br>';
					die("Failed installation checks.");
					} // if

				if((self::is_apps_auth_ok()) &&
					(method_exists('Capps_auth','do_apps_warnings')))
					Capps_auth::do_apps_warnings(true);
				Ccms_apps::do_std_app_warnings();
				$cUP = new Ccms_update(true);	// check it
				} // if
			} // if
		else {
			self::update_user_json_data(Ccms_api::API_TOK_KEY, self::get_api_token());
			self::update_user_json_data('sid', self::$cms_session_id);
			} // if
		return true;
		} // do_login_chores()

	protected static function do_apps_login($user_name,$pass_word) {
		if(self::is_apps_auth_ok()) {
			if(Capps_auth::login($user_name,$pass_word)) {
				self::do_login_chores(false,$user_name);	// do login set ups
				return true;
				} // if
			// else
			// just fall thru return false to allow local only login
			// used on install and configuration
			} // if
		return false;
		} // do_apps_login()

	protected static function get_selected_db_user($user_inep, $api_flg) {
		$user_check = self::sanitize($user_inep);
		$user_phone = $user_inep;
		$where = " WHERE  cms_user_enabled = 1";
		if(CMS_S_WEBSITE_CLOSED_BOOL) $where .= ' AND cms_user_admin = 1';
		if($api_flg) $where .= " AND cms_user_api = 1";
		$where .= " AND (cms_user_name = '" . $user_inep . "'";
		if((!$api_flg) && ((int)$user_inep > 0)) $where .= " OR cms_user_id = " . (int)$user_inep;
		if((CMS_C_ALLOW_PHONE_LOGIN) &&
			(Ccms::validate_phone_number($user_phone)) &&	// $user_phone will be false if not valid else changed to std format
			($user_phone)) {
			$where .= " OR cms_user_mobile = '" . $user_phone . "'";
			} // if
		else if((CMS_C_ALLOW_EMAIL_LOGIN) && (preg_match('/^.+@.+$/',$user_check))) {
			$where .= " OR cms_user_email = '" . $user_check . "'";
			} // if
		$where .= " )";

		if(!$api_flg) {
			$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_admin,cms_user_group_ids" .
				" ,cms_user_auth_ldap,cms_user_auth_pam,cms_user_api" .
				" ,cms_user_email,cms_user_email_confirmed,cms_user_mobile,cms_user_mobile_confirmed" . PHP_EOL .
				" FROM  cms_users" . PHP_EOL .
				$where . PHP_EOL . " LIMIT 1";
			} // if
		else {
			$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_auth_ldap,cms_user_auth_pam,cms_user_api". PHP_EOL .
				" FROM  cms_users". PHP_EOL . $where. PHP_EOL . " LIMIT 1";
			} // else
		if(($user = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user)))
			return $user;
		return false;
		} // get_selected_db_user()

	public static function log_in_user_id($user_inep,$remember = false, $auth_type = false, $api = false) {
		if(!self::check_login_gotacha()) return false;
		if((self::$cDBcms->is_table_present('cms_users')) &&
			($user_rows = self::$cDBcms->query("SELECT COUNT(*) AS total FROM  cms_users WHERE  cms_user_enabled = 1")) &&
			($user_rows = self::$cDBcms->fetch_array($user_rows)) &&
			($user_rows['total'] > 0)) {

			if($user = self::get_selected_db_user($user_inep,false)) {
                extract($user);	// foreach($user as $k => $v) $$k = $v;

				if((int)$cms_user_admin == 0) { // maybe in an admin group
					$sql_grp_query = "SELECT  cms_group_id,cms_group_name" .
						" FROM  cms_groups" .
						" WHERE  cms_group_enabled = 1 AND cms_group_admin = 1" ;
					if($grp_res = self::$cDBcms->query($sql_grp_query)) {
						$u_g_ids = explode(',',$cms_user_group_ids);
						while($grp = self::$cDBcms->fetch_array($grp_res)) {
							if(in_array($grp['cms_group_id'],$u_g_ids)) {
								$cms_user_admin = 1;
								} // if
							} // while
						} // if
					} // if
				if((CMS_S_WEBSITE_CLOSED_BOOL) && ((int)$cms_user_admin == 0)) return false;
				$user_group_manager_ids = self::get_group_manager_ids($cms_user_admin, $cms_user_group_ids);

				$user_sess = array(
					'id' => $cms_user_id,
					'name' => $cms_user_name,
					'time' => time(),	// time in seconds
					'admin' => $cms_user_admin,	// administrator flag
					'API' => $cms_user_api,	// API user
					'group_manager_ids' => $user_group_manager_ids,
					'group_ids' => $cms_user_group_ids,	// group ids array
					'type' => ($auth_type ?:($cms_user_auth_ldap ? 'LDAP':'local')),
					'email' => $cms_user_email,
					'email_confirmed' => $cms_user_email_confirmed,
					'mobile' => $cms_user_mobile,
					'mobile_confirmed' => $cms_user_mobile_confirmed,
					);
				self::set_cms_sess_var($user_sess,'user');
				if($remember)
					Ccms_auth_cookie::login_user_cookie($cms_user_id,$cms_user_name);
				self::do_login_chores($cms_user_admin,$cms_user_name,$api);	// do login set ups
				return true;	// on the AppsCMS
				} // if
			} // if
		return false;	// not on the AppsCMS
		} // log_in_user_id()

	public static function login_api_user(&$params) {
		if(!self::check_login_ip_allowed(false)) {
			return array('status' => 'error', 'message'=> 'Open session not allowed.');
			} // if
		if((Ccms_api_sid::is_use_sid_ok()) &&
			(self::is_still_logged_in())) {
			Ccms_api::get_api_http_code(202);
			return array(
				'status' => 'success',
				Ccms_api::API_TOK_KEY => urlencode(Ccms_api_sid::get_api_token()),
				'message'=> 'API session already open.',
				);
			} // if

		$user_inep = $params['username'];
		$passwd = $params['password'];

		$cms_user_name = '';
		$cms_user_id = 0;
		$cms_user_auth_ldap = 0;

		if((self::$cDBcms->is_table_present('cms_users')) &&
			($user_rows = self::$cDBcms->query("SELECT COUNT(*) AS total FROM  cms_users WHERE cms_user_enabled = 1")) &&
			($user_rows = self::$cDBcms->fetch_array($user_rows)) &&
			($user_rows['total'] > 0)) {
			if($user = self::get_selected_db_user($user_inep,true)) {
				foreach($user as $k => $v) $$k = $v;
				} // if
			else {
				self::log_msg('API username not found.');
				Ccms_api::get_api_http_code(401);
				return array('status' => 'error', 'message'=> 'API username not found.');
				} // else
			} // if

		if(Ccms_auth_passwd::chk_user_passwd($passwd,$cms_user_id)) {
			if(Ccms_api_jwt::is_use_jwt_ok()) {
				$cJWT = new Ccms_api_jwt();
				$result = array(
					'status' => 'success',
					'message'=> 'API JWT session open.',
					Ccms_api::API_JWT_KEY => $cJWT->make_jwt($cms_user_id),
					);
				self::log_msg('API JWT User: ' . $user . ' logged out','info');
				} // if
			else if((Ccms_api_sid::is_use_sid_ok()) &&
				(self::log_in_user_id($cms_user_id,false,'API'))) {
				self::set_cms_sess_var('API','LOGGED_IN');
				// logged in
				$cSID = new Ccms_api_sid();
				$result = array(
					'status' => 'success',
					'message'=> 'API SID session open.',
					Ccms_api::API_TOK_KEY => $cSID->make_sid($cms_user_id),
					);
				self::log_msg('API SID User: ' . $user_inep . ' logged in','info');
				} // else if
			else {
				$result = array('status' => 'error', 'message'=> 'API open failed - authentication type.');
				} // else
			// Ccms_api::get_api_http_code(200);
			return $result;
			} // if
		Ccms_api::get_api_http_code(401);
		return array('status' => 'error', 'message'=> 'API open failed authentication.');
		} // login_api_user()

	public static function logout_api_user(&$params) {
		if(!self::is_still_logged_in()) {
			return array(
				'status' => 'warning',
				'message'=> 'API session not open.',
				);
			} // if
		if(Ccms_api_jwt::is_use_jwt_ok()) {
			$token = $params[Ccms_api::API_JWT_KEY];
			if(Ccms_api_jwt::del_jwt_filename($token)) {
				// logged out
				$result = array(
					'status' => 'success',
					'message'=> 'API JWT session closed.',
					);
				} // if
			else {
				$result = array(
					'status' => 'error',
					'message'=> 'API JWT session not found.',
					);
				} // else
			} // if
		else if(Ccms_api_sid::is_use_sid_ok()) {
			$user = self::get_logged_in_username();
			$token = $params[Ccms_api::API_TOK_KEY];
			$cSID = new Ccms_api_sid();
			if(!empty($user)) {
				self::update_user_json_data('cms_user_last_logoff', time());	// self::get_gm_datetime());
				self::log_msg('API User: ' . $user . ' logged out','info');
				} // if
			// make sure it is completely logout, stop redirect loop
			Ccms::reset_session_actions(true,'LOGGED_IN');
			// logged out
			$result = array(
				'status' => 'success',
				'message'=> 'API SID session closed.',
				);
			} // else if
		else {
			$result = array('status' => 'error', 'message'=> 'API close failed - authentication type.');
			} // else

		return $result;
		} // logout_api_user()

	public static function cms_cookie_banner_closed() {
		$timeout = time() + ((int)CMS_C_COOKIE_BANNER_TTL * 24 * 3600);
		self::update_user_json_data('cms_user_cookie_banner_time', $timeout);
		} // cms_cookie_banner_closed()

	public static function post_process_login($failed = false) {
		if(!$failed) {
			$user = self::get_logged_in_username();
			if(CMS_S_FONT_SIZE_ADJUST_BOOL || CMS_S_FONT_SIZES_EM_ONLY_BOOL) {	// save user fontsize
				$_COOKIE['fontSize'] = self::get_user_json_data_key('cms_user_font_size',$user);	// get for login				
				} // if
			if(CMS_S_LANG_TRANSLATE_BOOL && CMS_S_LANG_TRANS_SELECT_BOOL) {	// save user selected language
				self::get_user_language(self::get_user_json_data_key('cms_user_selected_language',$user));	// get for login				
				} // if
			} // if
		self::is_in_auth_mode(false);
		if((!$failed) && (!CMS_S_LOGIN_FAIL2REFERER_BOOL)) {
			// normal post login page
			// clean up to stop repeats to same action (i.e. login)

			self::reset_session_actions();
			$url = self::get_base_url(true) . Ccms::get_body_uri();
			self::do_redirect_uri($url);
			} // if

		$referer = $_SERVER['HTTP_REFERER'];
		if (((self::is_ssl_required()) && (substr($referer,0,strlen(CMS_SSL_URL)) == CMS_SSL_URL)) ||
			((!self::is_ssl_required()) && (substr($referer,0,strlen(CMS_WWW_URL)) == CMS_WWW_URL))) {
			// Redirect to referer if it's part of our site

			if(self::is_ssl_required())
				$referer = preg_replace('/^http:/','https:',$referer);	// change referrer to https
			$referer = preg_replace('/&?login_failed=\\w+/','',$referer);	// clean previous fail
			$referer = preg_replace('/&?action=.*login/','',$referer);	// stop circular redirects
			$referer = preg_replace('/\\?$/','',$referer);	// remove the trailing ? if present

			if ($failed) {
				$referer .= strpos($referer,'?') === false ? '?' : '&';
				$referer .= 'login_failed=true';
				} // if
			} // if
		else {
			// Otherwise something funky's going on, just go to homepage
			$referer = self::get_base_url(true) . Ccms::get_body_uri();
			if ($failed) $referer .= '?login_failed=true';
			} // else
		self::do_redirect_uri($referer);
		} // post_process_login()

	protected static function check_login_gotacha($always = false) {
		if((!$always) && (!self::is_in_auth_mode())) return true;
		if((CMS_S_ADD_GOTCHA_LOGIN_BOOL) && (Ccms_gotcha_plugin::is_enabled())) {
			$suffix = 'zz';
			$gotcha_text = self::get_or_post('gotcha_text' . $suffix);
			if(($gotcha_text === false) ||	// not me
				(!Ccms_gotcha_plugin::validate($gotcha_text,$suffix))) {
				self::log_msg('Login Gotcha failed.');
				// self::login_failed();
				return false;
				} // if
			} // if
		return true;	//ok
		} // check_login_gotacha()

	public static function login_failed() {
		if(CMS_S_LOGIN_FAIL2REFERER_BOOL) self::post_process_login(true);		// will not return
		self::addMsg('Login failed.','warning');
		return;
		} // login_failed()

	public static function login_user() {	// read login forms and check
		if(!self::is_login_allowed()) {
			$url = self::get_base_url(true) . Ccms::get_body_uri();
			self::do_redirect_uri($url);
			} // if
		if(self::is_still_logged_in()) {
			self::reset_session_actions();
			return true;
			} // if

		if(Ccms_auth_plugin::is_enabled()) {
			$username = self::get_or_post('user_name');
			$password = self::get_or_post('user_password');
			if(Ccms_auth_plugin::auth($username,$password)) {
				if(!self::get_cms_sess_var('user')) self::set_cms_sess_var(array(),'user');
				$user = array(
					'name' => $username,
					'time' => time(),	// time in seconds
					'type' => 'PL_AUTH',
					);
				self::set_cms_sess_var(array_merge($user,self::get_cms_sess_var('user')),'user');
				self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
				self::do_eula();			// will redirect to EULA if required
				self::post_process_login();
				return true;
				} // if
			if(PL_CMS_AUTH_AUTH_ONLY) return false;	// dont try other methods
			} // if
		self::$login_local = self::get_or_post_str('local_login');
		if((!self::$login_local) &&
			(self::is_apps_auth_ok()) && // use apps login (from remote auth)
			(!self::is_get_or_post('user_name')) &&
			(!self::is_get_or_post('user_password')) &&
			($response = Capps_auth::login())) {
			self::reset_session_actions();
			if(self::is_cms_user()) self::set_cms_sess_var(true,'apps_login');
			else self::set_cms_sess_var(false,'apps_login');
			// logged in
			self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
			self::do_eula();			// will redirect to EULA if required
			self::post_process_login();
			} // if
		$cms_user_name = '';
		$cms_user_id = 0;
		$cms_user_auth_ldap = 0;
//		if(self::is_get_or_post('user')) {	// blind admin login for closed site
//			if((self::$cDBcms->is_table_present('cms_users')) &&
//				(!$cms_user_name = self::$cDBcms->get_data_in_table('cms_users','cms_user_name',
//					"cms_user_enabled = 1 AND  cms_user_name = '" . self::get_or_post_str('user') . "'" .
//					(CMS_S_WEBSITE_CLOSED_BOOL ? ' AND cms_user_admin = 1':'')))) {
//				// username not found
//				self::login_failed();
//				} //if
//			// else username found
//			} // if
//		else
		if((self::is_get_or_post('user_name')) &&
			(self::is_get_or_post('user_password'))) {
			$user_inep = self::get_or_post_str('user_name');
			$user_passwd = self::get_or_post_str('user_password');
			if(self::$login_local) {
				if($user = self::do_apps_login($user_inep, $user_passwd)) {
					self::reset_session_actions();
					self::set_cms_sess_var(true,'apps_login');
					self::set_cms_sess_var(self::get_short_name(),'LOGGED_IN');
					// logged in
					self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
					self::do_eula();			// will redirect to EULA if required
					self::post_process_login();
					} // if
				else {
					// have live admins
					if($user = self::get_selected_db_user($user_inep,false)) {
						$cms_user_id = $user['cms_user_id'];
						$cms_user_name = $user['cms_user_name'];
						$cms_user_auth_ldap = $user['cms_user_auth_ldap'];
						$cms_user_auth_pam = $user['cms_user_auth_pam'];
						$cms_user_api = $user['cms_user_api'];
						} // if
					else {
						self::log_msg('Username not found.');
						self::login_failed();
						return false;
						} // else
					} // if

	//		print_r($_POST); exit(0);	// test
	//		print_r($_SESSION); exit(0);	// test

				if((CMS_S_PAM_AUTH_ENABLED_BOOL) &&
					(Ccms_auth_pam::is_pam_authenticated($cms_user_name)) &&	// system PAM login
					(self::log_in_user_id($cms_user_id,(self::get_or_post_checkbox('remember') ? true:false)))) {
					self::reset_session_actions();
					// logged in
					self::set_cms_sess_var('SYS/PAM','LOGGED_IN');
					self::set_cms_sess_var(true,'pam_login');
					self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
					self::do_eula();			// will redirect to EULA if required
					self::post_process_login();
					} // else if
				else if(((int)$cms_user_auth_pam > 0) &&
					(Ccms_auth_pam::is_pam_authenticated($cms_user_name)) &&	// system PAM login
					(self::log_in_user_id($cms_user_id,(self::get_or_post_checkbox('remember') ? true:false)))) {
					self::reset_session_actions();
					// logged in
					self::set_cms_sess_var('USR/PAM','LOGGED_IN');
					self::set_cms_sess_var(true,'pam_login');
					self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
					self::do_eula();			// will redirect to EULA if required
					self::post_process_login();
					} // else if
				else if(((int)$cms_user_auth_ldap > 0) && // use ldap
					(Ccms_auth_ldap::is_user_ldap_authed($user_inep, $user_passwd)) &&
					(self::log_in_user_id($cms_user_id,(self::get_or_post_checkbox('remember') ? true:false)))) {
					self::reset_session_actions();
					self::set_cms_sess_var('LDAP/AD','LOGGED_IN');
					// logged in
					self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
					self::do_eula();			// will redirect to EULA if required
					self::post_process_login();
					} // if
				else if(((int)$cms_user_auth_ldap > 0) && (!CMS_S_LOCAL_LOGIN_AUTH_SERVER_NOT_FOUND_BOOL)) {
					self::log_msg('External Authentication Login failed.');
					self::login_failed();
					return false;
					} // else if
				else if((Ccms_auth_passwd::chk_user_passwd($user_passwd,$cms_user_id)) &&	// use local
					(self::log_in_user_id($cms_user_id,(self::get_or_post_checkbox('remember') ? true:false)))) {
					self::reset_session_actions();
					self::set_cms_sess_var('Local','LOGGED_IN');
					// logged in
					self::do_verification_codes();	// will redirect to verifications if required (and then EULA if required)
					self::do_eula();			// will redirect to EULA if required
					self::post_process_login();
					} // if

				} // if

			self::log_msg('Login failed.');
			self::login_failed();
			return false;
			} // if
		else {
			// no, it redirects, use the CMS_S_LOGIN_VIA_HOMEPAGE_BOOL = true	self::login_failed();
			// just fall thru to putup login page
			return false;
			}
		return self::is_cms_user();	// logged in
		} // login_user()

	public static function logout_user($redirect = false) {
		$user = self::get_logged_in_username();
		if(!empty($user)) {
			self::update_user_json_data('cms_user_last_logoff', time());	// self::get_gm_datetime());
			$adm = self::get_cms_sess_var('user','admin');	// goto direct to session
			self::log_msg((($adm > 0) ? 'Admin user: ':'User: ') . $user . ' logged out','info');
			} // if

		if(self::get_cms_sess_var('apps_login')) {
			if(self::is_apps_auth_ok()) self::logout();
			} // if

		Ccms_content_cache::reset_caches(false);	// for user name

		Ccms_auth_ldap::logout_ldap_user();
		self::reset_session_actions(array('user','apps_login','LOGGED_IN','ldap'));	// make sure it is completely logged out, stop redirect loop
		Ccms_proxy::clear_file_proxy(); // clear user session proxy list
		// too much session_destroy();

		Ccms_auth_cookie::logout_cookie_user();
		self::unset_cms_sess_var('user');

		Ccms_content_cache::reset_caches(false);		// for guest
		self::save_cms_sess();

		session_write_close();
		// session_destroy();

		if($redirect) {	// goto home page
			$url = self::get_base_url(true) . Ccms::get_body_uri();
			self::do_redirect_uri($url);
			} // if
		return true;
		} // logout_user()

	public static function start_user_session() {
		if((self::$cms_session_timeout !== false) &&
			(!empty($_SESSION)) &&
			(is_array($_SESSION)) &&
			(count($_SESSION) > 0)) {
			// session already
			self::log_msg('Session already open.','info');
			return true;
			} // if
		if(self::$cms_session_timeout === false) {
			if(self::is_api())
				self::$cms_session_timeout = CMS_S_SESSIONS_API_TIMEOUT_SECS;
			else if(Ccms_auth_cookie::is_a_cookie_login()) {
				// session lifetime for remembered logins
				self::$cms_session_timeout = CMS_S_SESSIONS_COOKIE_TIMEOUT_SECS;
				} // if
			else self::$cms_session_timeout = CMS_S_SESSIONS_USER_TIMEOUT_SECS;
			} // if

		@session_set_cookie_params(self::$cms_session_timeout);
		@session_start();

		self::init_cms_sess_ptr();

		self::is_still_logged_in();

		Ccms_auth_cookie::login_check_cookie();

		if((CMS_S_ALWAYS_LOGIN_BOOL) &&
			(!self::is_in_auth_mode())) {
			// @TODO check url
			if(self::is_cms_guest()) {
				$url = self::get_base_url(true) . 'login.php';
				self::do_redirect_uri($url);
				} // if
			} // if

		if(!self::init_apps_authed()) {
			self::addMsg('Apps authentication initialization failed.','warn');
			$url = self::get_base_url() . 'logout.php';
			self::do_redirect_uri($url);
			} // if
		return true; //ok
		} // start_user_session()

	private static function is_ip_local_subnet($ip) {
		$local_subnets = array('127.0.0.','172.16.','192.88.99.','192.168.', '10.', '::1' );
		foreach($local_subnets as $n) {
			if(substr($ip,0,strlen($n)) == $n) {
				return true;	// not public
				} // if
			} //foreach
		return false;
		} // is_ip_local_subnet()

	private static function get_client_ip_address_via_public_proxy() {
		// see http://en.wikipedia.org/wiki/X-Forwarded-For

		global $_SERVER;
		$ip = null;
		if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else if(getenv('HTTP_X_FORWARDED_FOR')) {
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} // else if

		if(empty($ip)) return false;	// no proxy used

		$ip_array = explode(',',$ip);
		$ip = $ip_array[0];

		// filter out local subnets
		if(self::is_ip_local_subnet($ip)) return false;	// not public
		return $ip;
		} // get_client_ip_address_via_public_proxy()

	public static function get_client_ip_address() {
		global $_SERVER;
		if(self::$cms_client_ip !== false) return self::$cms_client_ip;

		if (!empty($_SERVER)) {
			if (!empty($_SERVER['HTTP_CLIENT_IP']))
				self::$cms_client_ip = $_SERVER['HTTP_CLIENT_IP'];
			else if(self::$cms_client_ip = self::get_client_ip_address_via_public_proxy())
				return self::$cms_client_ip;
			else if(!empty($_SERVER['REMOTE_ADDR'])) {
				self::$cms_client_ip = $_SERVER['REMOTE_ADDR'];
			}
		} else {
			if (getenv('HTTP_CLIENT_IP'))
				self::$cms_client_ip = getenv('HTTP_CLIENT_IP');
			elseif(getenv('REMOTE_ADDR'))
				self::$cms_client_ip = getenv('REMOTE_ADDR');
		} // else

		if((!self::$cms_client_ip) && (!empty($_SERVER['REMOTE_ADDR'])))
			self::$cms_client_ip = $_SERVER['REMOTE_ADDR'];	// as a last resort

		// if(self::is_debug()) self::$cms_client_ip = '139.99.135.48';	// test
		return  self::$cms_client_ip;
		} // get_client_ip_address()

	public static function check_login_ip_allowed($log_flg = true) {
		if(self::is_cli()) return true;

		$cms_client_ip = self::get_client_ip_address();

		if((!defined('CMS_S_ALLOWED_LOGIN_IPS')) ||
			(strlen(CMS_S_ALLOWED_LOGIN_IPS) < 4)) return true;	// always ok

		$country = '';
		$allowed = self::unserialize_string2arry(CMS_S_ALLOWED_LOGIN_IPS,',');
		foreach($allowed as $allow) {
			if(preg_match('/^[a-z\s]+$/i',$allow)) {	// country name
				if(!self::is_ip_local_subnet ($cms_client_ip)) {
					$country = Ccms_geoip_plugin::get_geoip_country($cms_client_ip);
					if(!empty($country)) {
						if(preg_match('/' . $allow . '/i',$country)) return true;	// its ok
						return false;	// not ol
						} // if
					return true;	// error, but all changes
					} // if
				else return true;
				} // if
			else if(preg_match ('/^[0-9\.\/]*$/', $allow)) {	// ipv4 address or range
				if(self::ipCIDRCheck($cms_client_ip,$allow)) return true;	// its OK
				} // else
			else if(preg_match ('/^[0-9:]*$/', $allow)) {	// ipv6 address
				if($cms_client_ip == $allow) return true;	// its OK
				} // else
			} // foreach
		if($log_flg) self::log_msg ('Failed login attempt from ' . $cms_client_ip . (!empty($country) ? '(' . $country . ')':'') . ', IP not allowed.','warn');
		return false;
		} // check_login_ip_allowed()

	public static function is_login_allowed() {
		if(self::$login_allowed) return true;
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['eula_show'])) return false;
		if((!self::is_apps_auth_logged_in()) &&
			(self::session_cookie_ok()) &&
			(self::have_session()) &&
			(self::check_login_ip_allowed(false))
			)
			self::$login_allowed = true;
		return self::$login_allowed;
		} // is_login_allowed()

	public static function get_chg_password_lnk(&$txt,$span_flg = true,$label='&nbsp;**&nbsp;',$class=false) {
		if (self::is_cms_guest()) return false;
		if(self::get_cms_sess_var('user','type') == 'local') {	// only for local users
			$icon = Ccms_html::get_navbar_icon_text('chg_passwd',$label);
			if($span_flg) $txt .= '<span style="font-size: 10px; font-style: normal;font-weight:normal;">';
			$class_str = $class ? ' class="' . $class . '"' : '';
			$txt .= '<a href="index.php?cms_action=get_password" title="Change Local Password"' . $class_str . '>' . $icon . '</a>';
			if($span_flg) $txt .= '</span>';
			} // if
		} // get_chg_password_lnk()

	protected static function get_auth_types() {
		$auths = array();
		if((self::is_apps_auth_ok()) && (self::init_remote()) &&
			($text = Capps_auth::get_html()) && (!empty($text))) {
			$auths[] = array(
				// 'name' => Capps_auth::get_short_name (),
				'name' => Capps_auth::get_short_name (),
				'title' => Capps_auth::get_title(),
				'text' => $text,
				'JS' => Capps_auth::get_JS(),
				);
			} // if
		else {
			ob_start();
			require(CMS_FS_OPS_DIR . 'cms_login_local_form.php');
			$text = ob_get_clean();
			$auths[] = array(
				// 'name' => (self::is_ldap_ok() ? ((strlen(CMS_S_LDAP_DEF_DOMAIN) >4) ? '@' . CMS_S_LDAP_DEF_DOMAIN:'LDAP') . ' or Local':'Local'),
				'name' => CMS_C_CO_NAME,
				'title' => 'Local login.',
				'text' => $text,
				'JS' => '',
				);
			} // else
		return $auths;
		} // get_auth_types()

	protected static function get_auth_simple($auth_text,$dbox,$class = '',$h1_prefix = false) {
		// generate a plain form
		$auths = self::get_auth_types();
		$text = array();

		$text[] = '<div class="auth_drop" style="display: block;">';
		for($i = 0; $i < count($auths); $i++) {
			$title = $auths[$i]['title'];
			$text[] = '	<div class="auth_drop_section">';
			$text[] = '		<div class="auth_drop" id="id_auth_dropper[' . $i . '][cntl]"' .
				($dbox ? ' onclick="auth_drop_toggle(\'id_auth_dropper[' . $i . '][text]\',true);"':'') .
				(!empty($title) ? ' title="' . $title . '"':'') . '>';
			if(empty($h1_prefix)) $text[] = '<h4>' . $auths[$i]['name'] . '</h4>';
			else $text[] = '<h1>' . $h1_prefix . ' to: ' . $auths[$i]['name'] . '</h1>';
			$text[] = '		</div>';
			$text[] = '		<div class="auth_drop" id="id_auth_dropper[' . $i . '][text]" style="display: ' .
				($dbox ? 'none':'block') .
				';">';
			$text[] = '			' . $auths[$i]['text'];
			$text[] = '		</div>';
			$text[] = '	</div>';
			} // for
		$text[] = '</div>';
//		$text[] = $auths[0]['text'];
		return (!empty($text) ? PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL:'');
		} // get_auth_simple()

	protected static function get_auth_droppers($auth_text,$class = '',$dbox = true,$h1_prefix = false) {
		// $dbox = false;	// @TODO fix drop box has hover problems in new layout
		if(preg_match('/login/',self::get_app_action() . self::get_cms_action())) {	// app already logging in or cms already logging in
			$text = '';	// Ccms_html::set_JS_password_resource(false);	// get pw show/reveal first
			$text .= self::get_auth_simple($auth_text, $dbox, $class,$h1_prefix);
			} // if
		else if(($dbox) && ((self::is_ssl_inuse()) || (CMS_S_ALLOW_NON_SSL_LOGIN_BOOL)))	{ // drop box with a login form, one less screen reload
			$text = Ccms_html::set_JS_password_resource(false);	// get pw show/reveal first
			$auths = self::get_auth_types();
			if(!empty($auths[0]['text'])) $form = $auths[0]['text'];
			else if(!empty($auths[1]['text'])) $form = $auths[1]['text'];
			else $form = '';
			$pntr_text = '<span' . (!empty($class) ? ' class="' . $class . '"':'') . ' style="cursor: pointer;">' . $auth_text . '</span>';
			$text .= Ccms_html::getFormSimpleDropPanel($pntr_text,$form);	//
			} // else if
		else { // needing a URL
			$text = '<a' . (!empty($class) ? ' class="' . $class . '"':'') . ' href="' . (self::has_ssl_available() ? CMS_SSL_URL:CMS_WWW_URL) . 'index.php?cms_action=cms_login">' . $auth_text . '</a>';
			} // else
		return PHP_EOL . $text . PHP_EOL;
		} // get_auth_droppers()

	protected static function get_user_details() {
		$user_details = self::get_logged_in_username();
		$roles = array();
		if(self::is_cms_admin_user()) $roles[] = 'Admin';
		if(self::is_cms_group_manager()) $roles[] = 'Manager';
		if($r = self::get_cms_sess_var('LOGGED_IN')) $roles[] = $r;

		if(!empty($roles)) $user_details .= '(' . implode(', ',$roles) . ')';
		return $user_details;
		} // get_user_details()

	public static function is_header_login_logout_allowed() {
		if(self::is_cms_guest()) {	// not logged in
			if((self::is_login_allowed()) && (CMS_C_SHOW_LOGIN_LINK) &&
				(!preg_match('/(log|sign)[_-]*(in|out)/i',self::get_app_action() . self::get_cms_action())))
				return true;
			} // if
		else {	// logged in
			if(!preg_match('/(log|sign)[_-]*(in|out)/i',self::get_app_action() . self::get_cms_action()))
				return true;
			}
		return false;
		} // is_header_login_logout_allowed()

	public static function get_login_logout($class= '', $dbox = false, $include_chg_pw = false) {
		if(preg_match('/(get_verification|get_eula)/',(self::get_cms_action() . self::get_app_action()))) return '';
		$txt = '';
		if(self::is_cms_user()) {
			if((self::get_cms_sess_var('user.type') == 'local') &&
				(!self::is_apps_auth_logged_in())) {	// only for local users
				$include_chg_pw = true;
				} // if
			$user_details = self::get_user_details();
			$icon = Ccms_html::get_navbar_icon_text('logout','Log&nbsp;out');
			$txt .= '<a'. (!empty($class) ? ' class="' . $class . '"':'') . ' href="logout.php"' . (!empty($user_details) ? ' title="' . $user_details . '"':'') . ' onclick="Ccms_cursor.setWait();">' . $icon . '</a>';
			if ($include_chg_pw) self::get_chg_password_lnk($txt,false);
			} // if
		else if(self::is_login_allowed()) {
			$icon = Ccms_html::get_navbar_icon_text('login','User:&nbsp;Login');
			$auths_details = self::get_auth_droppers($icon,$class,$dbox,'Login');	// ,Ccms::show_nav_bar());
			$txt .= $auths_details;
			} // if
		return $txt;
		} // get_login_logout()

	public static function get_signin_signout($class= '', $dbox = true, $include_chg_pw = false) {	// similiar to get_login_logout() with cosmetic differences
		if(preg_match('/(get_verification|get_eula)/',(self::get_cms_action() . self::get_app_action()))) return '';
		$txt = '';
		if(self::is_cms_user()) {
			if((self::get_cms_sess_var('user.type') == 'local') &&
				(!self::is_apps_auth_logged_in())) {	// only for local users
				$include_chg_pw = true;
				} // if
			$user_details = self::get_user_details();
			// self::get_chg_password_lnk($txt,false);
			$icon = Ccms_html::get_navbar_icon_text('logout','Sign&nbsp;out');
			$txt .= '<a'. (!empty($class) ? ' class="' . $class . '"':'') . ' href="logout.php"' . (!empty($user_details) ? ' title="' . $user_details . '"':'') . ' onclick="Ccms_cursor.setWait();">' . $icon . '</a>';
			if ($include_chg_pw) self::get_chg_password_lnk($txt,false);
			} // if
		else if(self::is_login_allowed()) {
			$icon = Ccms_html::get_navbar_icon_text('login','User:&nbsp;Sign&nbsp;in');
			$auths_details = self::get_auth_droppers($icon,$class,$dbox,'Sign&nbsp;in');
			$txt .= $auths_details;
			} // if
		return $txt;
		} // get_signin_signout()

	public static function set_password() {
		$user_name = self::get_or_post_str('user_name');
		$user_password = self::get_or_post_str('user_password');
		$user_confirm = self::get_or_post_str('user_confirm');
		$user_id = self::get_or_post_str('user_id');
		$user_auth = self::get_or_post_str('user_auth');

		if((!$user_name) || (!$user_id) || (!$user_auth) ||
			(!$user_password) || (!$user_confirm)) {
			self::log_msg('Call to set password is missing parameters.');
			return false;	// missing something
			} // if

		$user_name = self::sanitize($user_name);
		if(CMS_S_USER_CURRENT_PASSWD_CHG_BOOL) {
			if(!Ccms_auth_passwd::chk_user_passwd(self::get_or_post_str('current_password'),$user_id)) {
				self::addMsg('Current password does not match.');
				return false;
				} // if
			} // if

		$sql_query = "SELECT  cms_user_id" .
			" FROM  cms_users" .
			" WHERE  cms_user_enabled = 1 AND  cms_user_name = '" . $user_name . "'" .
			" LIMIT 1";
		if(($user_ary = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user_ary))) {
			$user_id = $user['cms_user_id'];
			if((int)$user_id != (int)self::get_or_post('user_id')) {
				self::addMsg('Username and user id do not match.');
				return false;
				}
			} // if
		else {
			self::addMsg('Username: ' . $user_name . ' not found.');
			return false;
			} // else

		$cms_user_password = html_entity_decode($user_password);
		$cms_user_confirm = html_entity_decode($user_confirm);
		if(strlen($cms_user_password) < 4) {
			self::addMsg('Password too short.');
			} // else if
		else if($cms_user_password != $cms_user_confirm) {
			self::addMsg('Password/confirm error.');
			} // if
		else {
			$fields = array();
			$fields['cms_user_passwd_hash'] = Ccms_auth_passwd::hash_passwd($cms_user_password);
			$fields['cms_user_password_md5'] = '';	// depreciated
			if(self::$cDBcms->perform('cms_users',$fields,'update',"cms_user_id = " . (int)$user_id . "")) {
				self::log_info_msg('Set new local password for ' . $user_name . ".");
				self::log_in_user_id($user_id,false);
				self::addMsg('Set new password for ' . $user_name . ".",'info');
				$url = self::get_base_url(true) . Ccms::get_body_uri();
				self::do_redirect_uri($url);
				} // if
			} // if
		self::addMsg('Set password failed.');
		$url = self::get_base_url(true) . 'index.php?cms_action=get_password';
		self::do_redirect_uri($url);
		return false;	// never gets here
		} // set_password()

	public static function is_eula_enabled($key = false) {
		if(!CMS_C_EULA_ENABLE) return false;
		if((!$key) && (strlen(CMS_C_EULA_LINK) < 8)) return false;
//		$user = self::get_logged_in_username();
//		if(empty($user)) return false;
		return true;
		} // is_eula_enabled()

	public static function is_eula_agreement_required($key = false) {
		// the basics first
		if((self::is_cli()) || (self::is_rebuild())) return false;
		if((self::is_ajax()) || (self::is_api())) return false;
		if(!self::is_eula_enabled()) return false;
		// if(self::get_or_post_str('cms_action') == 'get_eula') return false;
		if(self::get_or_post_str('cms_action') == 'eula') return false;
		if(self::get_or_post_str('action') == 'eula') return false;
		if(!CMS_C_EULA_ALL) {
			if(self::is_cms_guest()) return false;
			} // if

		if(empty($key)) $key = 'cms_user_eula_time';
		$agree_time = self::get_user_json_data_key($key);
		if(!$agree_time) return true;
		$ttl_time = CMS_C_EULA_TTL * 24 * 3600;	// days to seconds
		if(($agree_time > 0) && ($agree_time + $ttl_time) > time()) return false;
		// else required
		return true;
		} // is_eula_agreement_required()

	public static function is_email_verification_codes_enabled() {
		if(Ccms_email_plugin::is_enabled()) return true;
		return false;	// not required or done
		} // is_email_verification_codes_enabled()

	public static function is_mobile_verification_codes_enabled() {
		if(Ccms_sms_plugin::is_enabled()) return true;
		return false;	// not required or done
		} // is_mobile_verification_codes_enabled()

	protected static function is_email_verification_code_required(&$user) {
		if((CMS_C_USER_EMAIL_REQUIRED) && (!empty($user['email'])) &&
			(CMS_C_CONFIRM_EMAIL) && (empty($user['email_confirmed']))) return $user;
		return false;	// not required or done
		} // is_email_verification_code_required()

	protected static function is_mobile_verification_code_required(&$user) {
		if((CMS_C_USER_MOBILE_REQUIRED) && (!empty($user['mobile']))
			&& (CMS_C_CONFIRM_MOBILE) && (empty($user['mobile_confirmed']))) return $user;
		return false;	// not required or done
		} // is_mobile_verification_code_required()

	public static function is_verification_codes_required() {
		if(!$user = self::get_cms_sess_var('user')) return false;	// not logged in
		if(empty($user['id'])) return false;
		if((self::is_email_verification_code_required($user)) &&
			(self::is_email_verification_codes_enabled())) return $user;
		if((self::is_mobile_verification_code_required($user)) &&
			(self::is_mobile_verification_codes_enabled())) return $user;
		return false;	// not required or done
		} // is_verification_codes_required()

	public static function do_verification_codes() {	// will redirect to verifications if required (and then EULA if required)
		if(!$user = self::is_verification_codes_required()) return false;
		$do_it = false;
		if(self::is_email_verification_code_required($user)) {
			if(self::is_email_verification_codes_enabled()) $do_it = true;
			else self::addAdminMsg('Email verification required but email verification disabled.','warn');
			} // if
		if(self::is_mobile_verification_code_required($user)) {
			if(self::is_mobile_verification_codes_enabled()) $do_it = true;
			else self::addAdminMsg('Mobile verification required but mobile SMS verification disabled.','warn');
			} // if
		if (!$do_it) return false;
		$url = self::get_base_url(true) . 'index.php?cms_action=get_verification';
		self::do_redirect_uri($url);	// should not return
		return true;
		} // do_verification_codes()

	public static function do_eula() {		// will redirect if EULA required
		if((self::is_cli()) || (self::is_ajax())) return false;
		if((!CMS_C_EULA_ALL) && (self::is_cms_guest())) return false;
		if(!self::is_eula_agreement_required()) return false;
		if(self::get_cms_action() == 'get_eula') return false;
		$url = self::get_base_url(true) . 'index.php?cms_action=get_eula';
		self::do_redirect_uri($url);
		} // do_eula()

	public static function get_eula_time() {
		if(!self::is_eula_enabled()) return false;
		$agree_time = self::get_user_json_data_key('cms_user_eula_time');
		if(!$agree_time) return false;
		return $agree_time;
		} // get_eula_time()

	public static function check_eula_form() {
		// if(!self::is_eula_enabled()) return false;
		$user_name = self::get_or_post_str('user_name');
		$user_id = self::get_or_post('user_id');
		$user_auth = self::get_or_post('user_auth');
		$cms_body_id = self::get_or_post('body_id');
		$cms_tool_id = self::get_or_post('tool_id');
		if((!$user_name) || (!$user_auth)) {
			if(self::get_or_post_str('eula_submit') != 'eula_save') {
				self::log_msg('ERROR: Call to check_eula_form is missing parameters.');
				return false;	// missing something
				} // if
			} // if

		if((self::get_or_post_str('eula') == 'agreed') ||
			(self::get_or_post_str('cms_eula') == 'agreed')) {
			// save they agreed
			if($cms_body_id) {
				Ccms::update_body_terms2show($cms_body_id,time());
				$url = $_SERVER['HTTP_REFERER'];
				self::do_redirect_uri($url);
				} // if
			else if($cms_tool_id) {
				Ccms::update_tool_terms2show($cms_tool_id,time());
				$url = $_SERVER['HTTP_REFERER'];
				self::do_redirect_uri($url);
				} // else if
			else {
				self::update_user_json_data('cms_user_eula_time',time());
				$url = self::get_base_url(true) . Ccms::get_body_uri();
				self::do_redirect_uri($url);
				} // else
			} // if
		// else reset eula and logout
		self::logout_user();
		self::update_user_json_data('cms_user_eula_time',0);
		$url = self::get_base_url(true) . Ccms::get_body_uri();
		self::do_redirect_uri($url);
		} // check_eula_form()

	public static function log_user_access() {
		if(self::$cms_access_logged) return true;
		self::$cms_access_logged = true;
		
		// if(self::is_in_auth_mode()) return true;

		$access_cnt = self::get_user_json_data_key('cms_user_access_count');
		if(!$access_cnt) $access_cnt = 0;
		$access_cnt++;
		self::update_user_json_data('cms_user_access_count', $access_cnt);
		
		if((!self::is_in_auth_mode()) && (!self::is_cli())) {
			if(CMS_S_FONT_SIZE_ADJUST_BOOL || CMS_S_FONT_SIZES_EM_ONLY_BOOL) {	// save user fontsize
				if(isset($_COOKIE['fontSize'])) {
					self::update_user_json_data('cms_user_font_size', $_COOKIE['fontSize']);	// save for login				
					} // if			
				} // if

			if(CMS_S_LANG_TRANSLATE_BOOL && CMS_S_LANG_TRANS_SELECT_BOOL) {	// save user selected language
				self::update_user_json_data('cms_user_selected_language', self::get_user_language());	// save for login				
				} // if
			} // if

//		$access_datetime = self::get_gm_datetime();
//		self::update_user_json_data('cms_user_access_time', $access_datetime);
		self::update_user_json_data('cms_user_access_time', time());

		return true;
		} // log_user_access()

	public static function log_user2apache($user = false) {
		if(self::is_cli()) return false;
		if((!defined('CMS_C_USER2APACHE')) ||
			(!CMS_C_USER2APACHE) ||
			(self::$user2apache))
			return false;
		self::$user2apache = true;	// only once
		if(empty($user)) $user = self::get_logged_in_username();
		if(empty($user)) return false;	// $user = 'UserNotLoggedIn';
		if((self::is_ajax()) && (CMS_C_USER2APACHE_AJAX)) $user .= '-Ajax';
		self::log_msg($user . ' access: ' . (empty($_SERVER['REQUEST_URI']) ? 'noURI':$_SERVER['REQUEST_URI']),'info');
		if(function_exists('apache_note')) apache_note('username',$user);
		else {	// (?)
			// @TODO nothing done at this atage
			return false;
			} // else
		return true;
		} // log_user2apache()

	public static function get_auth_descriptions() {	// get description of current options
		$text = array();
		$text[] = '<h3>Authentication Descriptions.</h3>';
		$text[] = '<p>Available authentication methods in order;-</p>';
		$text[] = '<ul>';
		if(self::is_apps_auth_ok()) {
			$text[] = '	<li>Applications authentication is global enabled.</li>';
			} // if
		if((CMS_S_PAM_AUTH_ENABLED_BOOL) && (self::is_pam_ok())) {
			$text[] = '	<li>System PAM authentication is global enabled.</li>';
			} // if
		if(self::is_pam_ok()) {
			$text[] = '	<li>System PAM authentication is enabled per user.</li>';
			} // if
		if(self::is_ldap_ok()) {
			$text[] = '	<li>LDAP/AD/Kerberos authentication is enabled per user.</li>';
			} // if
		$text[] = '	<li>' . CMS_PROJECT_SHORTNAME . ' authentication per user (default).</li>';
		$text[] = '</ul>';
		$text[] = '<p>Note: API authentication is by ' . CMS_PROJECT_SHORTNAME .'.</p>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // get_auth_descriptions()

	// dynamic methods

} // Ccms_auth
