<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_options.php 3482 2024-08-25 00:38:20Z robert0609 $
 */

/**
 * Description of Ccms_options
 *
 * Provides the setup and config options available.
 *
 * @author robert0609
 */

class Ccms_options extends Ccms_html {

	private static $std_colours = false;
	private static $lc_std_colours = false;	// lowercase, searchable version and cache it
	private static $contrast_text_colours = false;	// cache it
	private static $image_lists = false;	// cache it

	private static $font_families = array(
		"inherit",

		// see "https://www.w3schools.com/cssref/css_websafe_fonts.asp"
		"Arial, sans-serif",
		"Verdana, sans-serif",
		"Helvetica, sans-serif",
		"Tahoma, sans-serif",
		"'Trebuchet MS', sans-serif",
		"'Times New Roman', serif",
		"Georgia, serif",
		"Garamond, serif",
		"'Courier New', monospace",
		"'Brush Script MT', cursive",

		// other maybe useful font family combinations
		"'Courier New', Courier, monospace",
		"Verdana, Arial, Helvetica, sans-serif",
		"Verdana, Geneva, sans-serif",
		"helvetica, Arial, sans-serif",
		"'Lucida Grande', Helvetica, Arial",
		"'Lucida Calligraphy Italic', 'URW Chancery L', Arial",
		"'Lucida Handwriting Italic', 'URW Chancery L', Arial",
		"'Comic Sans MS', Arial",
		"Arial, Helvetica, sans-serif",
		"'Times New Roman', Times, serif",
		"Techno, Impact, sans-serif",
		"Helvetica, Arial",
		"'Trebuchet MS', sans-serif",
		"Terminal, monospace",
		"VT-100, monospace",
		"Textile, cursive",
		"Arial Black",
		"Impact",
		"sans-serif",
		);

	private static $font_styles = array(
		'inherit',
		'normal',
		'italic',
		'oblique',
		);

	private static $font_weights = array(
		'inherit',
		'normal',
		'bold',
		'bolder',
		'lighter',
		'100',
		'200',
		'300',
		'400',
		'500',
		'600',
		'700',
		'800',
		'900',
		);

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function make_image_list($paths = false) {
		if(empty($paths)) $pathes = array(CMS_WS_IMAGES_DIR);
		else if(!is_array($paths)) $pathes = array($paths);
		else $pathes = $paths;
		$ops_dir_list = Ccms_autoloader::get_ops_dirs_list();

		$p = DOCROOT_FS_BASE_DIR . $pathes[(array_key_first($pathes))];	// use this to check type
		if(preg_match('/background/',$p)) {
			$idx = 'backgrounds';
			$paths = array_merge($pathes,$ops_dir_list['backgrounds']);
			} // if
		else if(preg_match('/icons/',$p)) {
			$idx = 'icons';
			$paths = array_merge($pathes,$ops_dir_list['icons']);
			} // else if
		else {
			$idx = 'images';
			$paths = array_merge($pathes,$ops_dir_list['images']);
			} // else
		$paths = array_unique($paths);

		if(!isset(self::$image_lists[$idx])) {	// cache it
			$image_list = array();
			foreach($paths as $path) {
				$base_path = DOCROOT_FS_BASE_DIR . $path;
				if(!is_dir($base_path)) continue;
				if(($dh = opendir($base_path)) &&
					(!is_null($dh))) {
					while (($file = readdir($dh)) !== false) {
						if(preg_match('/\.png$|\.jpg$|\.jpeg$|\.gif$|\.svg$/',$file))
							$image_list[] = self::clean_path ($path . '/' . $file);
						} // while
					closedir($dh);
					} // if
				} // foreach
			if(empty(self::$image_lists)) self::$image_lists = array();
			sort($image_list);
			self::$image_lists[$idx] = array_unique($image_list);
			} // if
		return self::$image_lists[$idx];
	} // make_image_list()

	protected static function make_ws_image_select_options() {
		$paths = array(
			ETC_WS_IMAGES_DIR,
			ETC_WS_BACKGROUNDS_DIR,
			ETC_WS_ICONS_DIR,
			);
		$img_list = array();
		foreach($paths as $path) {
			if($dh = opendir(DOCROOT_FS_BASE_DIR . $path)) {
				while (($file = readdir($dh)) !== false) {
					if(preg_match('/\.png|\.jpg|\.jpeg|\.gif|\.svg/',$file)) $img_list[] = $path . $file;
					} // while
				closedir($dh);
				} // if
			} // foreach
		sort($img_list);
		$options = array_merge(array('-- Select Image URI to Copy --'),$img_list);
		return self::add_svalues_options($options,'-1');
	} // make_ws_image_select_options()

	public static function get_ws_image_uri_selection() {
		$text = '<select id="ws_image_list_id" name="ws_image_list" size="1" onchange="cms_get_selected_ws_image();">' . self::make_ws_image_select_options() . '</select>';
		return $text;
		} // get_ws_image_uri_selection()

	public static function make_image_select_options($paths,$value,$icon_flg = null) {
		$img_path = Ccms_config_funcs::find_img_path($value,$paths,$icon_flg);
		$img_list = self::make_image_list($paths,true);

		if(is_null($icon_flg)) {
			if(preg_match('/icon/',$img_path)) $icon_flg = true;
			else $icon_flg = false;
			} // if

		$text = PHP_EOL . '<option value=""' . (($value == '') ? ' SELECTED' : '') . '>&nbsp;' . ($icon_flg ? '(No Icon)':'(No Image)') . (($value == '') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
		// $text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
		foreach ($img_list as $img) {
			// put it together
			$text .= PHP_EOL . '<option value="' . htmlentities($img) . '"' . (($img_path == $img) ? ' SELECTED' : '') . '>';
			if($value == $img) $text .= '&nbsp;' . $img . ' **';
			else $text .= '&nbsp;' . $img . '&nbsp;';
			$text .= '</option>' . PHP_EOL;
			} // foreach
		return $text;
		} // make_image_select_options()

//	public static function make_uploaded_image_select_options($value) {
//		if(!self::chkdir(DOCROOT_FS_BASE_DIR . $path)) return false;
//		return self::make_image_select_options($path,$value);
//	} // make_uploaded_image_select_options()
//
//	public static function make_bkgnd_image_select_options($value) {
//		$path = ETC_WS_BACKGROUNDS_DIR;
//		if(!self::chkdir(DOCROOT_FS_BASE_DIR . $path)) return false;
//		return self::make_image_select_options($path,$value);
//	} // make_bkgnd_image_select_options()
//
//	public static function make_icon_select_options($value) {
//		$path = ETC_WS_ICONS_DIR;
//		if(!self::chkdir(DOCROOT_FS_BASE_DIR . $path)) return false;
//		return self::make_image_select_options($path,$value,true);
//	} // make_icon_select_options()

	public static function get_row_bkgnd_colour($even, $bk, $chg = 0.15) {
		self::make_colours();
		$chg = (float)$chg;
		if(is_numeric($bk)) $v = (int)$bk;
		if(is_string($bk)) {
			if((strlen($bk) == 7) &&
				(substr($bk, 0,1) == '#')) {	// hex value
				$v = hexdec(substr($bk,1));
				$r = (($v >> 16) & 0xff);
				$g = (($v >> 8) & 0xff);
				$b = ($v & 0xff);
				} // if
			else if((strlen($bk) == 4) &&
				(substr($bk, 0,1) == '#')) {	// hex value
				$v = hexdec(substr($bk,1));
				$r = (($v >> 4) & 0xf0);
				$g = ($v & 0xf0);
				$b = (($v << 4) & 0xf0);
				} // if
			else {
				$bk = strtolower($bk);
				if(key_exists($bk, self::$lc_std_colours)) {
					$v = hexdec(substr(self::$lc_std_colours[$bk],1));
					$r = (($v >> 16) & 0xff);
					$g = (($v >> 8) & 0xff);
					$b = ($v & 0xff);
					} // if
				else return $bk;	// a colour string, @TODO loolup colour
				} // else
			} // if

		$intensity = $r + $g + $b;

		if($even) { // make brighter
			$gain = 1.00 + (float)$chg;
			$offset = (255.00 - (float)$intensity) * (float)$chg / 3.0;
			} // if
		else {	// make darker
			$gain = 1.00 - (float)$chg;
			$offset = (255.00 - (float)$intensity) * (float)$chg / -3.0;
			} // else

		$rr = ((float)$r * $gain) + $offset;
		if($rr > 255.00) $r = 255;
		else if($rr < 0.00) $r = 0;
		else $r = (int)$rr;

		$gg = ((float)$g * $gain) + $offset;
		if($gg > 255.00) $g = 255;
		else if($gg < 0.00) $g = 0;
		else $g = (int)$gg;

		$bb = ((float)$b * $gain) + $offset;
		if($bb > 255.00) $b = 255;
		else if($bb < 0.00) $b = 0;
		else $b = (int)$bb;

		$new_bk = sprintf('#%02X%02X%02X',$r,$g,$b);

		return $new_bk;
		} // get_row_bkgnd_colour()

	private static function make_colours($add_rgb = true) {
		if(empty(self::$std_colours)) self::$std_colours = self::parse_ini_file(CMS_FS_CMS_STD_COLOURS);
		if(empty(self::$contrast_text_colours)) { // work out text colours and cache them
			self::$contrast_text_colours = array();
			self::$lc_std_colours = array();
			$cc_ary = array('CMS_C_CUSTOM_COLOURS','CMS_S_CUSTOM_COLOURS');
			foreach($cc_ary as $ccc) {
				if((defined($ccc)) && (strlen(constant($ccc)) > 6)) {
					if($cc = self::unserialize_string2arry(constant($ccc),':','=')) {
						foreach($cc as $c) {
							if(!is_array($c)) continue;	// bad entry
							if(!$add_rgb) $n = trim($c[0]);
							else $n = 'cc:  #' . strtoupper(trim($c[1]," \t\n\r\0\x0B#")) . ' ' . trim($c[0]);
							$v = '#' . trim($c[1]," \t\n\r\0\x0B#");
							if((isset(self::$lc_std_colours[$n])) && (self::$lc_std_colours[$n] = $v)) continue;	// dont double up
							self::$lc_std_colours[$n] = $v;
							} // foreach
						} // if
					} // if
				} // foreach
			foreach (self::$std_colours as $r => $v) {
				if(!$add_rgb) $n = trim($r);
				else $n = 'std: ' . strtoupper($v) . ' ' . trim($r);
				self::$lc_std_colours[$n] = $v;
				} // foreach
			ksort(self::$lc_std_colours);
			foreach (self::$lc_std_colours as $n => $v) {
				$h = substr($v,1);	// $h from self::$std_colours
				if(!preg_match('/^[ # ]*[0-9a-f]{6,6}$/i',$h)) {
					// typically get a string like "[#]red" or "[#]black" from custom colours
					$s = preg_replace('/^[ # ]*/','',$h);
					// now lookup $s in self::$lc_std_colours
					$sf = false;	// flg
					foreach(self::$std_colours as $sn => $sh) {
						if(!strcasecmp($s,$sn)) { // found
							$h = $sh;
							$sf = true;
							break;
							} // if
						} // foreach
					if(!$sf) continue;	// no good
					} // if
				$h = hexdec(preg_replace('/^[ # ]*/','',$h));
				$i = (($h >> 16) & 0xff) + (($h >> 8) & 0xff) + ($h & 0xff);	// intensity
				if($i > (3 * 96)) $c = 'black';	// contrast !!
				else $c = 'white';
				// self::$contrast_text_colours[$n] = $c;
				self::$contrast_text_colours[$n] = $c;
				} // foreach
			} // if
		} // make_colours()

	protected static function make_colour_select_options($value,$excluded_array = '') {
		//@TODO see "https://support.mozilla.org/en-US/questions/1141257" about option colour problems
		self::make_colours();
		if((empty($excluded_array))) $excluded_array = array();
		$value = strtolower($value);
		if(!in_array('default', $excluded_array)) {
			$text = PHP_EOL . '<option value="">  (Use Default) </option>' . PHP_EOL;	// special case
			} // if
		if(!in_array('inherit',$excluded_array)) {
			$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			} // if
		$pat = '/[\"\s]{1,}' . addcslashes($value,':/.()') . '[\s\"]{1,}/i';
		foreach (self::$lc_std_colours as $n => $v) {
			if(in_array($v, $excluded_array)) continue;
			if(isset(self::$contrast_text_colours[$n])) {
				$c = self::$contrast_text_colours[$n];
				if(in_array($c, $excluded_array)) continue;
				} // if
			else $c = 'black';

			// put it together
			$selected = '';
			if(preg_match($pat,'"' . $n . '"'))	// add quotes to make it work anywhere and not match grey to darkgrey
				$selected = ' SELECTED';
			else if(preg_match($pat,'"' . $v . '"'))
				$selected = ' SELECTED';

			$text .= PHP_EOL . '<option value="' . htmlentities($v) . '"' . $selected;
			$text .= ' style="background-color: ' . $v . '; color: ' . $c . '; display: list-item;">';
			if((stripos($n,$value) !== false) || (!strcasecmp($value,$v))) $text .= '&nbsp;' . $n . ' **';
			else $text .= '&nbsp;' . $n . '&nbsp;';
			$text .= '</option>' . PHP_EOL;
			} // foreach
		return $text;
	} // make_colour_select_options()

	public static function count_sel_opts(&$options, $exclude = -1) {
		// return count of options less any excluded values
		$cnt = 0;
		foreach($options as $n => &$v) {
			if(is_array($exclude)) {
				if(in_array($v,$exclude)) continue;
				} // if
			else if((int)$v == $exclude) continue;
			$cnt++;
			} // for
		return $cnt;
		} // count_selectable_options_count()

	public static function get_select_option_filter($id_select, $title = false, $drop_size = 0, $opts_cnt = -1, $class = '') {
		if(empty($id_select)) return '';
		if($drop_size < Ccms_edit::SEARCH_FILTER_DROP_SIZE_MIN) $drop_size = Ccms_edit::SEARCH_FILTER_DROP_SIZE_MIN;
		if(($opts_cnt > 0) && ($opts_cnt <= $drop_size)) return '';
		if(!empty($class)) $class = ' class="' . $class . '"';	// else ok
		else $class = ' class="std"';
		$text = PHP_EOL;
		$text .= '<div' . $class . ' style="display: inline-block;">' . PHP_EOL;
		$text .= '<label' . $class . '><input' . $class . ' type="text" id="id_filter_' . $id_select . '"' .
			//	' oninput="cms_filter_select_options(\'id_filter_' . $id_select . '\',\'' . $id_select . '\',\'id_filter_cnt_' . $id_select . '\');"' . PHP_EOL .
				' oninput="cms_filter_select_options(\'id_filter_' . $id_select . '\',\'' . $id_select . '\',\'id_filter_cnt_' . $id_select . '\');"' . PHP_EOL .
				' name="filters[' . $id_select . ']"' .
				' size="10"' .
				' placeholder="Filter"' .
				' value=""' . PHP_EOL .
				' data-dropsize="' . $drop_size . '"' .// html5 attribute, flag (-1 = match select width
				' title="' . (!empty($title) ? $title:'Enter select filter search keywords.') . '"/></label>' . PHP_EOL;
		$text .= '<span style="display: none; border: 1px solid lightgrey; margin: 2px; padding: 2px;" id="id_filter_cnt_' . $id_select . '" title="Found"></span>';
//		$text .= '<script type="text/javascript">' . PHP_EOL .
//				'	window.addEventListener("load", function() {' . PHP_EOL .
//				'		cms_filter_select_options(\'id_filter_' . $id_select . '\',\'' . $id_select . '\',\'id_filter_cnt_' . $id_select . '\');' . PHP_EOL .
//				'	});' . PHP_EOL .
//				'</script>' . PHP_EOL;
		$text .= '</div>' . PHP_EOL;
		// $text .= '<br>' . PHP_EOL;
		return $text;
		} // get_select_option_filter()

	public static function get_grid_headings(&$col_heads,$val_sep = ':') {
		// returns an array of numerically indexed heading data
		if(empty($col_heads)) return false;
		if(!is_array($col_heads)) {
			$col_hds_raw = self::chk_unserialize($col_heads);
			if(empty($col_hds_raw)) $col_hds_raw = explode($val_sep,$col_heads);
			} // if
		else $col_hds_raw = $col_heads;

		$col_hds_cntl = array();
		$idx = 0;
		foreach($col_hds_raw as $k => $v) {
			if(!is_numeric($k))	continue;	// only the LTR sequence
			if(is_string($v)) {
				$col_hds_cntl[$idx]['hd_text'] = $v;
				$col_hds_cntl[$idx]['name'] = $idx;
				$col_hds_cntl[$idx]['type'] = 'text';	// text input
				$col_hds_cntl[$idx]['inp_params'] = ' style="width: 95%;"';
				if(preg_match('/URI|URL/i', $col_hds_cntl[$idx]['hd_text'])) 
					$col_hds_cntl[$idx]['uris'] = Ccms::get_ws_links_options();	// return a reference
				else $col_hds_cntl[$idx]['uris'] = '';
				} // if
			else {
				$col_hds_cntl[$idx] = $v;
				if(isset($v['hd_text'])) $col_hds_cntl[$idx]['hd_text'] = $v['hd_text'];
				else if(isset($v['text'])) $col_hds_cntl[$idx]['hd_text'] = $v['text'];

				if((isset($v['name'])) && (!empty($v['name'])) &&
					(empty($col_hds_cntl[$idx]['name'])))
					$col_hds_cntl[$idx]['name'] = $v['name'];
				else if (empty($col_hds_cntl[$idx]['name'])) $col_hds_cntl[$idx]['name'] = $idx;

				if(isset($v['type'])) $col_hds_cntl[$idx]['type'] = $v['type'];
				else $col_hds_cntl[$idx]['type'] = 'text';

				if(isset($v['options'])) $col_hds_cntl[$idx]['options'] = $v['options'];

				if(isset($v['title'])) $col_hds_cntl[$idx]['title'] = $v['title'];
				else $col_hds_cntl[$idx]['title'] = '';

				if(isset($v['inp_params'])) $col_hds_cntl[$idx]['inp_params'] = $v['inp_params'];
				else if(isset($v['params'])) $col_hds_cntl[$idx]['inp_params'] = $v['params'];
				else $col_hds_cntl[$idx]['inp_params'] = ' style="width: 95%;"';

				if(!empty($v['func'])) {
					switch($v['func']) {
					case 'ws_abt_links':
						$uris = Ccms::get_ws_links_options();
						$col_hds_cntl[$idx]['uris'] = $uris;
						break;
					default:
						self::addAdminMsg('Missing grid function: ' . $v['func']);
						break;
						} // switch
					} // if
				}

			$idx++;
			} // foreach

		return $col_hds_cntl;
		} // get_grid_headings()

//	private static function get_grid_sub_vals(&$col_hds_cntl,&$grid) {
//		$chgs = 0;
////		if(!empty($grid)) {
////			for($r = 0 ; $r < count($grid); $r++) {
////				$gr = &$grid[$r];
////				for($c = 0; $c < count($gr); $c++) {
////					if((!empty($gr[$c])) && (($sub_vals = self::chk_unserialize($gr[$c])) !== false) && (is_array($sub_vals))) {
////						for($j = 0; $j < count($col_hds_cntl); $j++) {
////							$cnc = &$col_hds_cntl[$j];
////							foreach($sub_vals as $n => $v) {	// fill in empty
////								if($n == $cnc['sub_name']) {
////									if(empty($gr[$j])) {
////										$gr[$j] = $v;
////										$chgs++;
////										} // if
////									} // if
////								} // foreach
////							} // for
////						} // if
////					else {
////						for($j = 0; $j < count($col_hds_cntl); $j++) {
////							if(!empty($gr[$j])) continue;
////							$cnc = &$col_hds_cntl[$j];
////
////							} // for
////						} // else
////					} // for
////				} // for
////			} // if
//		return $chgs;
//		} // get_grid_sub_vals()

	public static function multi_row_input_get_form_elems(&$data_rows,&$name,$value,$col_heads,$class=false) {
		if(empty($class)) $class = 'page_config';
		$text = '';
		$col_cntl = self::get_grid_headings($col_heads);
		$text .= '<table class="' . $class . '">' . PHP_EOL;
		$text .= '<tr class="' . $class . '">';
		for($i = 0; $i < count($col_cntl); $i++) $text .= '<th class="' . $class . '">' . $col_cntl[$i]['hd_text'] . '</th>';
		$text .= '</tr>' . PHP_EOL;
		$row = 0;
		foreach($data_rows as &$p) {
			$text .= '<tr class="' . (($row++ & 1) ? 'page_config_even':'page_config_odd') . '">';
			$text .= '<td class="' . $class . '" valign="top" title="Type: ' . $p['name'] . '">' . $p['title'] . '</td>';
			$text .= '<td class="' . $class . '" valign="top" style="text-align: center;" title="Check to enable."><input type="checkbox" name="' . $name . '[' . $p['name'] . ']"' . (($p['enabled']) ? ' CHECKED':'') . '/></td>';
			$text .= '<td class="' . $class . '" valign="top">' . $p['description'] . '</td>';
			$text .= '</tr>' . PHP_EOL;
			} // foreach
		$text .= '</table>' . PHP_EOL;
		return $text;
		} // multi_row_input_get_form_elems()

	public static function multi_row_get_form_elems($name,$value,$avail,$val_sep) {
		$text = '';
		if((isset($_POST[$name])) && (!empty($_POST[$name])) && (is_array($_POST[$name]))) {
			$text_a = $_POST[$name];
			$text_p = array();
			foreach($text_a as $p => &$e) {
				if($e == 'on') {
					if(empty($avail)) $text_p[] = $p;
					else if(isset($avail[$p])) $text_p[] = $p;	// stop rubbish getting thru
					} // if
				} // foreach
			$text = implode($val_sep,$text_p);
			} // if
		else if(!empty($value)) {	// analyse the data
			if(is_array($value)) {
				$text = '';
				foreach($value as $k => $v) {
					if(strlen($text) > 0) $text .= $val_sep;
					if($v == 'on') $text .= $k;	// checkbox return
					else $text .= $v;	// a list return
					} // foreach
				} // if
			else $text = $value;
			} // else if
		return $text;
		} // multi_row_get_form_elems()

	protected static function get_ini_cms_input_ctl($ini_key) {
		$grid_inputs = array(
			'ALLOWED_LOGIN_IPS' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'CIDRs Allowed to Login',
				'val_sep' => ',',
				'data_sep' => '',
				),
			'CAN_TEST_APPS_CIDR' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Network or IP Address',
				'val_sep' => ',',
				'data_sep' => '',
				),
			'CUSTOM_COLOURS' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Name:Hex RGB Colour',
				'val_sep' => ':',
				'data_sep' => '=',
				),
			'CUSTOM_FONTS' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Font Name',
				'val_sep' => ':',
				'data_sep' => '',
				),
			'EXT_LIB_DIRS_LIST' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Section Name:Directory to scan for class code',
				'val_sep' => ':',
				'data_sep' => '=',
				),
			'HOSTS_URLS_ALLOWED' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Domains allowed run host',
				'val_sep' => ':',
				'data_sep' => '',
				),
			'LANGUAGES_ALLOWED' => array(	// ini_key to match
				'type' => 'multi_select',
				'col_heads' => 'Code:Use:Language',
				'val_sep' => ':',
				'data_sep' => '',
				'options_func' => 'Ccms_language::get_all_languages_multi_options',
				),
			'LDAP_SERVER_URI' => array(	// ini_key to match
				'type' => 'multi_input',
				'col_heads' => 'Host or IP Address',
				'val_sep' => ',',
				'data_sep' => '',
				),
			'ONLINE_MSGS_LEVEL' => array(	// ini_key to match
				'type' => 'multi_select',
				'col_heads' => 'Type:Show:Description',
				'val_sep' => ':',
				'data_sep' => '',
				'options_func' => self::class . '::get_online_msgs_options',
				),

			// the numbers
			'CONTENT_CACHE_TTL' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="300" step="10" max="7776000"',
				),
			'SESSIONS_DATA_TIMEOUT_DAYS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="7" step="1" max="720"',
				),
			'SESSIONS_API_TIMEOUT_SECS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="300" step="10" max="7776000"',
				),
			'SESSIONS_USER_TIMEOUT_SECS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="300" step="10" max="7776000"',
				),
			'SESSIONS_COOKIE_TIMEOUT_SECS' => array(	// ini_key to match
				'type' => 'number',
				'params' => 'min="7200" step="100" max="31104000"',
				),
			);
		if(empty($ini_key)) return $grid_inputs;
		if(isset($grid_inputs[$ini_key])) return $grid_inputs[$ini_key];
		return false;	// not found
		} // get_ini_cms_input_ctl()

	public static function convert_ini_cms_form_input(&$ini_ary) {
		foreach($ini_ary as $sect_name => &$s2c) {
			foreach($s2c as $k => &$v) {
				$val = $v;
				if($c = self::get_ini_cms_input_ctl($k)) {
					switch($c['type']) {
					case 'multi_select':
						$v = self::multi_row_get_form_elems($k,$v,'',$c['val_sep']);
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					case 'multi_input':
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					case 'number':
						$val = $v;
						break;
					default:
						break;
						} // switch
					} // if
				else if(is_array($v)) {
					if(in_array('',$v)) $val = '';	// use default
					else $val = implode(' ',$v);
					} // if
				$s2c[$k] = $val;	// ?? stripslashes($val);
				} // foreach
			} // foreach
		return $ini_ary;
		} // convert_ini_cms_form_input()

	public static function grid_show($value,&$col_heads,$val_sep,$data_sep,$class=false) {
		if(empty($class)) $class = 'page_config';
		$col_cntl = self::get_grid_headings($col_heads);
		if((empty($col_cntl)) || (count($col_cntl) < 1)) return '(empty)';
		$x_only = (count($col_cntl) <= 1 ? true:false);

		$text = array();
		$text[] = '<table class="' . $class . '">';
		$h_c = count($col_cntl);
		$text[] = '	<tr class="' . $class . '">';
		for($c = 0; $c < $h_c; $c++) {
			$text[] = '		<th class="' . $class . '">' . $col_cntl[$c]['hd_text'] . '</th>';
			} // for
		$text[] = '	</tr>';
		$grid = self::unserialize_string2arry($value,$val_sep,$data_sep);
		if(!empty($grid)){
			for($r = 0; $r < count($grid); $r++) {
				$gr = &$grid[$r];
				$text[] = '	<tr class="' . (($r & 1) ? 'page_config_odd':'page_config_even') . '">';
				if($x_only) {
					$val = (!empty($gr['uri']) ? $gr['uri']:(!empty($gr) ? $gr:''));
					$text[] = '		<td class="' . $class . '" valign="top">' . $val . '</td>';
					} // if
				else {
					for($c = 0; $c < $h_c; $c++) {
						$val = (!empty($gr[$c]['uri']) ? $gr[$c]['uri']:(!empty($gr[$c]) ? $gr[$c]:''));
						$text[] = '		<td class="' . $class . '" valign="top">' . $val . '</td>';
						} // for
					} // else
				$text[] = '	</tr>';
				} // for
			} // if
		else $text[] = '<tr class="' . $class . '"><td class="' . $class . '" colspan="'. $h_c . '">(No values set)</td></tr>';
		$text[] = '</table>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // grid_show()

	public static function grid_input_form_elems(&$name,$value,&$col_heads,$val_sep,$data_sep,$class=false) {
		$grid = array();
		if(!empty($value)) {
			if(!is_array($value)) $grid = self::unserialize_string2arry($value,$val_sep,$data_sep);
			else $grid = $value;
			} // if
		if((!$grid) || (!is_array($grid))) $grid = array();	// empty
		else $grid = self::clean_array($grid,false);	// clean out dead rows

		$col_cntl = self::get_grid_headings($col_heads);
		if((empty($col_cntl)) || (count($col_cntl) < 1)) return '';
		$x_only = (count($col_cntl) <= 1 ? true:false);
		if(empty($class)) $class = 'page_config';

		// self::get_grid_sub_vals($col_cntl,$grid);

		$new_entries = 1;
		$h_c = count($col_cntl);
		$r_c = (count($grid) + $new_entries);
		$img_arrow_params = ' width="15" height="15"';

		$text = array();
		$text[] = '';
		static $sent_gr_elem_tw_functions = false;
		if(!$sent_gr_elem_tw_functions) {
			$sent_gr_elem_tw_functions = true;
			$images_dir = CMS_WS_IMAGES_DIR;
			$debug = (Ccms::is_debug() ? 'true':'false');
			$text[] =<<< EOTGIFEJS

			<script type="text/javascript">

				Ccms_gife.debug = function() { return {$debug}; };
				Ccms_gife.up_arrow_url = function() { return '<img alt="up arrrow" src="{$images_dir}arrow-up.gif"{$img_arrow_params}/>'; };
				Ccms_gife.down_arrow_url = function() { return '<img alt="down arrrow" src="{$images_dir}arrow-down.gif"{$img_arrow_params}/>'; };

			</script>

EOTGIFEJS;
			} // if

		$text[] = '<table class="' . $class . '" id="' . $name . '_table">';
		$text[] = '	<tr class="' . $class . '">';
		$text[] = '		<th class="' . $class . '"' .
				' title="Order of entries.\n' .
				'Empty cell will delete the row.\n'.
				'New rows are added as required."' .
				'>' . '*' . '</th>';	// @TODO need a small circle I icon here
		for($c = 0; $c < $h_c; $c++) {
			if(!isset($col_cntl[$c])) continue;
			$cnc = &$col_cntl[$c];
			$text[] = '		<th class="' . $class . '"' .
				(!empty($cnc['title']) ? ' title="' . $cnc['title'] . '"':'') .
				'>' .
				$cnc['hd_text'] .
				'</th>';
			} // for
		$text[] = '		<td class="' . $class . '" title="Move up">' . '&nbsp;' . '</td>';
		$text[] = '		<td class="' . $class . '" title="Move down">' . '&nbsp;' . '</td>';
		$text[] = '	</tr>';

		for($r = 0; $r < $r_c; $r++) {
			$gr = &$grid[$r];

			$text[] = '	<tr class="' . $class . '" id="' . $name . '_table_row[' . $r . ']">';
			$text[] = '		<th class="' . $class . '" id="' . $name . '_table_cell[' . $r . '][' . 0 . ']">' . ($r + 1) . '</th>';

			for($c = 0; $c < $h_c; $c++) {
				if(!isset($col_cntl[$c])) continue;
				$cnc = &$col_cntl[$c];

				$text[] = '		<td class="' . $class . '" id="' . $name . '_table_cell[' . ($r + 0) . '][' . ($c + 1) . ']">';
				if(!empty($cnc['uris'])) {
					$text[] = '			<select id="' . $name . '[' . $r . '][' . $c . ']"' .
						' name="' . $name . '[' . $r . '][' . ((isset($cnc['name']) && !empty($cnc['name'])) ? $cnc['name']:$c) . ']"' .
						' onchange="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($cnc['inp_params']) ? $cnc['inp_params']:' style="width: 95%;"') .
						'>';
					$text[] = Ccms::add_svalues_options($cnc['uris'],(isset($gr['uri']) ? $gr['uri']:(!empty($gr[$c]) ? $gr[$c]:'')));
					$text[] = '</select>';
					} // if
				else if($cnc['type'] == 'select') {
					$name_suf = ((isset($cnc['name']) && !empty($cnc['name'])) ? $cnc['name']:$c);
					$text[] = '			<select id="' . $name . '[' . $r . '][' . $c . ']"' .
						' name="' . $name . '[' . $r . '][' . $name_suf . ']"' .
						' onchange="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($cnc['inp_params']) ? $cnc['inp_params']:' style="width: 95%;"') .
						'>';
					$text[] = Ccms::add_svalues_options($cnc['options'],(isset($gr[$name_suf]) ? $gr[$name_suf]:''));
					$text[] = '</select>';
					} // else if
				else if($cnc['type'] == 'checkbox') {
					$name_suf = ((isset($cnc['name']) && !empty($cnc['name'])) ? $cnc['name']:$c);
					$text[] = '			<input id="' . $name . '[' . $r . '][' . $c . ']"' .
						' type="' . $cnc['type'] . '"' .
						' name="' . $name . '[' . $r . '][' . $name_suf . ']"' .
						// ' oninput="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						// (!empty($cnc['inp_params']) ? $cnc['inp_params']:' style="width: 95%;"') .
						' style="text-align: center;"' .
						((!empty($gr[$name_suf]) && $gr[$name_suf] == 'on') ? ' CHECKED':'') .
						'/>';
					} // else if
				else {
					$name_suf = ((isset($cnc['name']) && !empty($cnc['name'])) ? $cnc['name']:$c);
					if($x_only) $c_val = (!empty($gr) ? $gr:'');
					else $c_val = (isset($gr[$name_suf]) ? $gr[$name_suf]:(!empty($gr[$c]) ? $gr[$c]:''));
					$text[] = '			<input id="' . $name . '[' . $r . '][' . $c . ']"' .
						' type="' . $cnc['type'] . '"' .
						' name="' . $name . '[' . $r . '][' . $name_suf . ']"' .
						' value="' . $c_val . '" autocapitalize="off"' .
						' oninput="Ccms_gife.chk_add_tabrow(this,\'' . $name . '\');"' .
						(!empty($cnc['inp_params']) ? $cnc['inp_params']:' style="width: 95%;"') .
						'/>';
					} // else
				$text[] = '		</td>';
				} // for
			$text[] = '		<td class="' . $class . '" id="' . $name . '_table_cell[' . $r . '][' . ($h_c + 1) . ']">';
			if(($r >= 1) && ($r < (count($grid) + $new_entries - 0))) {
				$text[] = '			<a onclick="Ccms_gife.move_up_tabrow(\'' . $name . '\',' . $r . ',' . $r_c . ',' . $h_c . ');" title="Move row up to ' . ($r - 1 + 1) . '">';
				$text[] = '				<img alt="up arrrow" src="' . CMS_WS_IMAGES_DIR . 'arrow-up.gif"' . $img_arrow_params . '/>';
				$text[] = '			</a>';
				} // if
			$text[] = '		</td>';
			$text[] = '		<td class="' . $class . '" id="' . $name . '_table_cell[' . $r . '][' . ($h_c + 2) . ']">';
			if(($r >= 0) && ($r < (count($grid) + $new_entries - 1))) {
				$text[] = '			<a onclick="Ccms_gife.move_down_tabrow(\'' . $name . '\',' . $r . ',' . $r_c . ',' . $h_c . ');" title="Move row down to ' . ($r + 1 + 1) . '">';
				$text[] = '				<img alt="down arrrow" src="' . CMS_WS_IMAGES_DIR . 'arrow-down.gif"' . $img_arrow_params . '/>';
				$text[] = '			</a>';
				} // if
			$text[] = '		</td>';
			$text[] = '	</tr>';
			} // for
		$text[] = '</table>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // grid_input_form_elems()

	public static function grid_multi_select_form_elems(&$name,$value,&$col_heads,$val_sep,$data_sep,$options_func) {
		$options = call_user_func($options_func,$value);
		$list = array();
		foreach($options as &$l) {	// convert
			$list[($l['value'])] = array(
				'class' => '',
				'name' => $l['value'],
				'title' => $l['value'],
				'enabled' => $l['selected'],
				'description' => $l['text'],
				);
			} // foreach
		ksort($list);
		return self::multi_row_input_get_form_elems($list,$name,$value,$col_heads);
		} // grid_multi_select_form_elems()

	public static function grid_get_form_elems($name,$value,$col_heads,$val_sep,$data_sep) {
		// return $value;	// test
		$col_cntl = self::get_grid_headings($col_heads);
		$x_only = (count($col_cntl) <= 1 ? true:false);
		$text = '';
		$dotted = preg_replace('/\]\[/','.',$name);
		$dotted = preg_replace('/[\[]/','.',$dotted);
		$dotted = preg_replace('/[\]]/','',$dotted);
		$text_n = self::getDottedKeys2Var($_POST, $dotted);
		if(!is_null($text_n)) {
			$text_a = array();
			for($r = 0; $r < count($text_n); $r++) {	// clean out empty entries
				$gr = &$text_n[$r];
				foreach($gr as $n => $v) {
					if(empty($v)) continue;
					if(!is_array($v)) {
						// no $v = urldecode($v);
						if((($sub_ary = self::chk_unserialize($v)) !== false) &&
							(is_array($sub_ary))) {	// unpick serialized array
							$gr[$n] = $sub_ary;
							} // if
						else $gr[$n] = $v;
						} // if
					} // foreach
				$mt = false; $uri = false;
				for($c = 0; $c < count($col_cntl); $c++) {
					$cnc = &$col_cntl[$c];
					$nc = $cnc['name'];
					switch($cnc['type']) {
					case 'select':
						if((empty($gr[$nc])) ||
							($gr[$nc] == ' -- Select -- ') ||
							($gr[$nc] == -1)) {
							$mt = true;	// ignore row
							} // if
						else if($nc == 'uri') $uri = $gr[$nc];
						break;
					case 'checkbox':
						if(empty($gr[$nc]))
							$gr[$nc] = 'off';
						break;
					default:
						if(empty($gr[$nc])) {
							if(!empty($gr['uri']['text']))
								$gr[$nc] = $gr['uri']['text'];
							} // if
						break;
						} // switch
					} // for
				if((!$mt) && (!empty($gr))) {
					// clean up uri
					if((!empty($gr[0]['uri'])) && (!is_array($gr[0]['uri']))) {
						$uri = urldecode($gr[0]['uri']);
						$gr[0]['uri'] = $uri;
						} // if
					else if((!empty($gr[0])) && (!is_array($gr[0]))) {
						$uri = urldecode($gr[0]);
						$gr[0] = $uri;
						} // else
					if($x_only) {
						if(!empty($gr[0])) $text_a[] = $gr[0];
						} // if
					else $text_a[] = $gr;	// one than one axis
					} // if
				} // for
			// self::get_grid_sub_vals($col_cntl,$text_a);
			if(count($text_a) > 0) {
				$text = serialize($text_a);
				} // if
			} // if
		else if(!empty($value)) $text = $value;
		return $text;
		} // grid_get_form_elems()

	protected static function add_increment_vw_series(&$svalues,$strt = 0.10,$size = 25,$factor = 1.15) {
		// add an incremental veiwport series
		$st = $strt;
		if($size < 0) $size = abs($size);
		if($size > 100) $size = 100;
		for($i = 1; $i <= $size; $i++) {	// do an incremental increase
			$svalues[] = sprintf("%0.2f",$st) . 'vw';
			$st *= $factor;	// inc factor
			} // for
		} // add_increment_vw_series()

	protected static function get_incrd_options($min,$max,$step,$suffix = '', $preload = array()) {
		$svalues = (is_array($preload) ? $preload:array());
		if($step == 0) return $svalues;
		for($i = $min; $i < $max; $i += $step) {
			$svalues[] = $i . $suffix;
			} // for
		if($i >= $max) {
			$svalues[] = $max . $suffix;
			} // if
		return $svalues;
		} // get_incrd_options()

	protected static function get_expon_options($min,$max,$expon,$prec,$suffix = '', $preload = array()) {
		$svalues = (is_array($preload) ? $preload:array());
		if(($min == 0.0000000) || ($expon == 1.000000))
			return self::get_incrd_options($min,$max,$expon,$suffix,$preload);

		if($expon < 1.0000000) $expon += 1.0000000;
		$value = $min;
		while($value < $max) {
			if(is_float($value)) $svalues[] = round($value,$prec) . $suffix;
			else $svalues[] = $value . $suffix;
			$value *= $expon;
			} // while
		if($value >= $max) {
			if(is_float($max)) $svalues[] = round($max,$prec) . $suffix;
			else $svalues[] = $max . $suffix;
			} // if
		return $svalues;
		} // get_expon_options()

	public static function make_type_input_selr($name,$ini_key,$value,$size = 30,$just_list = false,$readonly = false, $use_typedef_as_default = false, $required = false) {
		// @TODO this whole method needs to be done better
		$text = PHP_EOL;
		$id = 'id_' . $name;
		if(($required) && ($readonly)) $required = false;	// stop a lock up

		// do the grid layout type first
		if(($c = self::get_ini_cms_input_ctl($ini_key)) ||
			($c = Ccms_apps::get_ini_apps_input_ctl($ini_key))) {
			switch($c['type']) {
			case 'multi_select':
				$options_func = (!empty($c['class']) ? $c['class'] . '::':'') . $c['options_func'];
				$text .= self::grid_multi_select_form_elems($name, $value, $c['col_heads'], $c['val_sep'], $c['data_sep'],$options_func);
				break;
			case 'multi_input':
				$text .= self::grid_input_form_elems($name, $value, $c['col_heads'], $c['val_sep'], $c['data_sep']);
				break;
			case 'number':
				$text .= '<input type="number" name="' . $name . '" value="' . $value . '" ' . $c['params'] . '>' . PHP_EOL;
				break;
			default:
				break;
				} // switch
			if($just_list) return '';	// anything
			return $text;
			} // if

		// now the standard (obvious) types
		if(substr($ini_key,-11) == 'FONT_FAMILY') {	// multiple box for font family
			if($just_list) return false;
			if((defined('CMS_S_CUSTOM_FONTS')) && (strlen(CMS_S_CUSTOM_FONTS) > 4)) {
				$cf = explode(':', CMS_S_CUSTOM_FONTS);
				foreach($cf as $f) {
					// $f = str_replace("''", "'",("'" . $f . "'"));
					$f = str_replace("''", "'",$f);
					$f = stripslashes($f);
					if(in_array($f,self::$font_families)) continue;	// dont double up
					self::$font_families[] = $f;
					} // foreach
				// sort(self::$font_families);
				} // if
			natsort(self::$font_families);

			$text .= self::get_select_option_filter($id, 'Use to find font families.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" class="std" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value=""' . (empty($ff) ? ' SELECTED':'') . '> -- default -- </option>';
			//$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case

			foreach(self::$font_families as $ff) {
				$text .= PHP_EOL . '<option value="' . rawurldecode($ff) . '"' . 
										' style="font-family: ' . $ff . ';"' .
										((!strcasecmp($value,$ff)) ? ' SELECTED':'') . 
										'>' . 
										$ff .
										((!strcasecmp($value,$ff)) ? ' **':'') . 
									'</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key,-10) == 'FONT_STYLE') {	// multiple box for font style
			if($just_list) return false;
			$text .= self::get_select_option_filter($id, 'Use to find font style.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value=""' . (empty($ff) ? ' SELECTED':'') . '> -- default -- </option>';
			//$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			foreach(self::$font_styles as $ff) {
				$text .= PHP_EOL . '<option value="' . rawurldecode($ff) . '"' . ((!strcasecmp($value,$ff)) ? ' SELECTED':'') . '>' . $ff. ((!strcasecmp($value,$ff)) ? ' **':'') . '</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key,-11) == 'FONT_WEIGHT') {	// multiple box for font weight
			if($just_list) return false;
			$text .= self::get_select_option_filter($id, 'Use to find font weight.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value=""' . (empty($ff) ? ' SELECTED':'') . '> -- default -- </option>';
			//$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			foreach(self::$font_weights as $ff) {
				$text .= PHP_EOL . '<option value="' . rawurldecode($ff) . '"' . ((!strcasecmp($value,$ff)) ? ' SELECTED':'') . '>' . $ff. ((!strcasecmp($value,$ff)) ? ' **':'') . '</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key,-4) == 'BOOL') {	// a true / false box
			if($just_list) return array ('type' => 'BOOL','allowed' => array('true','false'));
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="false"'. (($value != 'true') ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;false&nbsp;&nbsp;&nbsp;&nbsp;</option>';
			$text .= PHP_EOL . '<option value="true"'. (($value == 'true') ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;true&nbsp;&nbsp;&nbsp;&nbsp;</option>';
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -2) == 'TZ') { // a time zone box
			$tzs = self::get_time_zones();
			if($just_list) return array ('type' => 'TZ','allowed' => $tzs);
			$text .= self::get_select_option_filter($id, 'Use to find time zones.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			foreach($tzs as $tz) {
				$text .= PHP_EOL . '<option value="' . htmlentities($tz) . '"' . (($value == $tz) ? ' SELECTED' : '') . ($required ? ' REQUIRED':'') . '>&nbsp;' . $tz . '&nbsp;</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (preg_match('/' . 'LANGUAGE_CODE|BASE_APP_LANG' . '$/',$ini_key)) { // a language code box
			$lcs = Ccms_language::get_available_languages();
			if($just_list) return array ('type' => 'LANGUAGE_CODE','allowed' => $lcs);
			$text .= self::get_select_option_filter($id, 'Use to find language.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="">&nbsp;' . '-- Select Language --' . '&nbsp;</option>';
			foreach($lcs as $lc => $ln) {
				$text .= PHP_EOL . '<option value="' . htmlentities($ln) . '"' . (($value == $ln) ? ' SELECTED' : '') . '>&nbsp;' . $lc . '&nbsp;</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -8) == 'CHAR_SET') { // a charset box
			$css = self::get_charsets();
			if($just_list) return array ('type' => 'CHAR_SET','allowed' => $css);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			foreach($css as $cs) {
				$text .= PHP_EOL . '<option value="' . htmlentities($cs) . '"' . (($value == $cs) ? ' SELECTED' : '') . '>&nbsp;' . $cs . '&nbsp;</option>';
				} // foreach
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == 'COLOUR') { // a colour box
			if($just_list) return false;
			$text .= self::get_select_option_filter($id, 'Use to find colours.',-1);
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . self::set_JS_colour_picker_onclick('id_' . $name) . '' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= self::make_colour_select_options($value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -10) == 'BKGD_IMAGE') { // a background image box
			if($just_list) return false;
			$cCMS_C = new Ccms_config_funcs();
			$text .= PHP_EOL . $cCMS_C->input_image($ini_key, $value, ETC_WS_BACKGROUNDS_DIR);
			} // if
		else if ((substr($ini_key, -21) == 'BODY_MAX_INLINE_WIDTH') || // width body max
			(substr($ini_key, -21) == 'PAGE_INLINE_MAX_WIDTH')) { // width page max
			if($just_list) return false;
			$svalues = self::get_incrd_options(800,6000,50,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Max Width</option>';
			$text .= PHP_EOL . '<option value="-1"' . (($value == -1) ? ' SELECTED':'') . '>No maximum</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -11) == 'MODAL_WIDTH') { // width modal
			if($just_list) return false;
			$svalues = self::get_incrd_options(200,3000,50,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Modal Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (preg_match('/LEFT_WIDTH$|RIGHT_WIDTH$/',$ini_key)) { // column widht
			if($just_list) return false;
			$svalues = self::get_incrd_options(50,400,5,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == '_WIDTH') { // general width
			if($just_list) return false;
			$svalues = self::get_expon_options(50,3000,0.25,0,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -12) == 'MODAL_HEIGHT') { // width modal
			if($just_list) return false;
			$svalues = self::get_incrd_options(200,3000,50,'px');
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Modal Height</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
//		else if (substr($ini_key, -7) == '_HEIGHT') { // general height
//			if($just_list) return false;
//			$svalues = self::get_expon_options(50,3000,0.25,0,'px');
//			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
//			$text .= PHP_EOL . '<option value="" selected disabled>Height</option>';
//			$text .= self::add_svalues_options($svalues, $value);
//			$text .= PHP_EOL . '</select>' . PHP_EOL;
//			} // if
		else if (substr($ini_key, -7) == '_HEIGHT') { // a height box
			if($just_list) return false;
			$preload = ['auto','unset','0%','5%','10%','15%','20%','25%','30%','35%','40%','45%',
				'50%','55%','60%','65%','70%','75%','80%','85%','90%','95%','100%',];
			$preload1 = self::get_expon_options(0.8,3.5,0.1,1,'em',$preload);
			$preload2 = self::get_incrd_options(15,300,5,'px',$preload1);
			$svalues = self::get_incrd_options(300,1000,50,'px',$preload2);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Height</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL . PHP_EOL;
			} // if
		else if ($ini_key == 'TOOLS_SEARCH_DEPTH_MAX') { // a width box
			if($just_list) return false;
			$svalues = self::get_incrd_options(1,5,1);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" selected disabled>Depth</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL . PHP_EOL;
			} // if
		else if (substr($ini_key, -14) == 'LINKS_POSITION') { // nav bar link width specials
			if($just_list) return false;
			$preload = array('left','right','even','spread',);
			$preload2 = self::get_expon_options(8, 100, 1.25, 0, '%',$preload);
			$svalues = self::get_incrd_options(15,200,5,'px',$preload2);
			$text .= self::get_select_option_filter($id, 'Use to find nav bar options.');
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			// $text .= PHP_EOL . '<option value="" disabled selected hidden>Link Width</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == 'RADIUS') { // a radius box
			if($just_list) return false;
			$preload = self::get_expon_options(1,25,1.5,0,'px',array('0px'));
			$svalues = self::get_expon_options(0.5, 2.0, 1.15, 2, 'em', $preload,false);
			$text .= self::get_select_option_filter($id, 'Use to find radii.');
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Radius</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -9) == 'FONT_SIZE') { // a size box
			if($just_list) return false;
			if(CMS_S_FONT_SIZES_EM_ONLY_BOOL || CMS_S_FONT_SIZE_ADJUST_BOOL) {
				$svalues = self::get_incrd_options(0.4, 4.0, 0.2, 'em');
				} // if
			else {
				$preloadA = self::get_incrd_options(0.4, 4.0, 0.2, 'em',['xx-small','	x-small','small','medium','large','x-large','xx-large']);
				$preloadB = self::get_expon_options(6.0, 72.0, 1.15, 0, 'pt', $preloadA);
				// $svalues = self::get_incrd_options(8,48,1.5,'px', $preloadB);
				$svalues = self::get_expon_options(8.0, 48.0, 1.25, 0, 'px', $preloadB);
				} // else
			// self::add_increment_vw_series($svalues);
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			//$text .= PHP_EOL . '<option value="" selected disabled>Size</option>';
			$text .= PHP_EOL . '<option value="inherit"' . (($value == 'inherit') ? ' SELECTED' : '') . '>&nbsp;inherit' . (($value == 'inherit') ? ' **' : '&nbsp;') . '</option>' . PHP_EOL;	// special case
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if (substr($ini_key, -6) == 'LENGTH') { // a length box
			if($just_list) return false;
			$svalues = self::get_incrd_options(3,20,1);
			$text .= self::get_select_option_filter($id, 'Use to find radii.');
			$text .= PHP_EOL . '<select id="' . $id . '" onclick="cms_filter_select_click(this);" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			//$text .= PHP_EOL . '<option value="" disabled selected hidden>Size</option>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Length</option>' . PHP_EOL;	// special case
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // if
		else if(substr($ini_key, -7) == '_MARGIN') {
			if($just_list) return false;
			$svalues = self::get_incrd_options(0,25,1,'px');
			self::add_increment_vw_series($svalues);
			$text .= self::get_select_option_filter($id, 'Use to find margin.');
			$text .= PHP_EOL . '<select id="' . $id . '1" onclick="cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Margin</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if(substr($ini_key, -8) == '_PADDING') {
			if($just_list) return false;
			$svalues = self::get_incrd_options(0,25,1,'px');
			self::add_increment_vw_series($svalues);
			$text .= self::get_select_option_filter($id, 'Use to find padding.');
			$text .= PHP_EOL . '<select id="' . $id . '1" onclick="cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Padding</option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if(substr($ini_key, -15) == 'LIST_STYLE_TYPE') {
			if($just_list) return false;
			$svalues = array('none','circle','disc','square','triangle');
			$text .= self::get_select_option_filter($id, 'Use to find list style type.');
			$text .= PHP_EOL . '<select id="' . $id . '1" onclick="cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>List Style Type<option>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if(substr($ini_key, -7) == '_BORDER') { // a width, style, colour box
			if($just_list) return false;
			$vs = preg_split('/\s/',$value);
			if((empty($vs)) || (count($vs) != 3)) {	// should not happen
				$vs = array(
					'1px',
					'none',
					(preg_match('/^#[0-9a-f]{6,6}$/i',$value) ? $value:'black'),
					);
				} // if
			while(count($vs) < 3) $vs[] = '';
			$svalues = self::get_incrd_options(1,25,1,'px');
			self::add_increment_vw_series($svalues);
			$text .= '<div style="overflow-wrap: break-word;">' . PHP_EOL;
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= PHP_EOL . '<select id="' . $id . '1" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border width.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Width</option>';
			$text .= self::add_svalues_options($svalues, $vs[0]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;

			$svalues = array(
				'none', 'hidden', 'dotted', 'dashed', 'solid', 'double', 'groove', 'ridge', 'inset', 'outset',
				);
			$text .= PHP_EOL . '<select id="' . $id . '2" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border style.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Style</option>';
			$text .= self::add_svalues_options($svalues, $vs[1]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= 'Border width, style and colour.' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			// $text .= '<br>' . PHP_EOL;
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= self::get_select_option_filter($id . '3', 'Use to find border colours.');
			$text .= PHP_EOL . '<select id="' . $id . '3" onclick="cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border colour.">';
			$text .= self::make_colour_select_options($vs[2],array('inherit'));	// inherit causes a CSS warning
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			} // if
		else if(substr($ini_key, -15) == 'TEXT_DECORATION') { // a line, style, thickness, colour box
			if($just_list) return false;
			$vs = preg_split('/\s/',$value);
			if((empty($vs)) || (count($vs) < 1)) {	// should not happen
				$vs = array(
					'initial',	// line
					'',	// style
					'',	// thickness
					// (preg_match('/^#[0-9a-f]{6,6}$/i',$value) ? $value:'black'),	// colour
					);
				} // if
			while(count($vs) < 3) $vs[] = '';
			
			$text .= '<div style="overflow-wrap: break-word;">' . PHP_EOL;

			// line
			$svalues = array('initial','inherit','none', 'underline', 'overline', 'line-through', 'underline overline',);
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= PHP_EOL . '<select id="' . $id . '2" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border style.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Line</option>';
			$text .= self::add_svalues_options($svalues, $vs[0]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			// $text .= '<br>' . PHP_EOL;
			
			// style
			$svalues = array('initial','inherit','solid', 'double', 'dotted', 'dashed', 'wavy',);
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= PHP_EOL . '<select id="' . $id . '2" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border style.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Style</option>';
			$text .= self::add_svalues_options($svalues, $vs[1]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			// $text .= '<br>' . PHP_EOL;
			
			// thickness
			$preload = self::get_incrd_options(0.02, 0.4, 0.02, 'em');
			$svalues = self::get_incrd_options(1,25,1,'px',$preload);
			self::add_increment_vw_series($svalues);
			$text .= '<div style="float: left;">' . PHP_EOL;
			$text .= PHP_EOL . '<select id="' . $id . '1" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border width.">';
			$text .= PHP_EOL . '<option value="" disabled selected hidden>Thickness</option>';
			$text .= self::add_svalues_options($svalues, $vs[2]);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;

//			// colour
//			$text .= '<div style="float: left;">' . PHP_EOL;
//			$text .= self::get_select_option_filter($id . '3', 'Use to find decoration colour.');
//			$text .= PHP_EOL . '<select id="' . $id . '3" onclick="cms_filter_select_click(this);" name="' . $name . '[]" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . ' title="Select border colour.">';
//			$text .= self::make_colour_select_options($vs[3]);
//			$text .= PHP_EOL . '</select>' . PHP_EOL;
//			$text .= '</div>' . PHP_EOL;
//			// $text .= '<br>' . PHP_EOL;

			// $text .= 'Decoration line, style, thickness and colour.' . PHP_EOL;
			$text .= '</div>' . PHP_EOL;
			} // if
//		else if (substr($ini_key, -17) == 'ONLINE_MSGS_LEVEL') { // messages level selection
//			if($just_list) return false;
//			$options = self::get_online_msgs_options($value);
//			$text .= self::gen_selection_list($name . '[]', $options, 'size="' . count($options) . '" multiple' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '');
//			} // else if
		else if (substr($ini_key, -12) == '_APP_PLUGINS') { // looks in the APPS_FS_PLUGINS_DIR for dynamic control plugins
			if($just_list) return false;
			}//if
		else if ($ini_key == 'PASSWORD_REQUIRED_REGEX') { // get password check level
			if($just_list) return false;
			$options = array(
				array(
					'value' => -1,
					'selected' => (empty($value) ? true:false),
					'params' => ' disabled selected hidden',
					'text' => '-- Select Password Check --',
					),
				array(
					'value' => 'feeble',
					'selected' => (($value == 'feeble') ? true:false),
					'text' => 'Feeble',
					),
				array(
					'value' => 'weak',
					'selected' => (($value == 'weak') ? true:false),
					'text' => 'Weak',
					),
				array(
					'value' => 'medium',
					'selected' => (($value == 'medium') ? true:false),
					'text' => 'Medium',
					),
				array(
					'value' => 'strong',
					'selected' => (($value == 'strong') ? true:false),
					'text' => 'Strong',
					),
				);
			$text = self::gen_selection_list($name,$options,($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '');
			} // else if
		else if (substr($ini_key, -13) == 'SESSION_TYPE') { // session types box
			if($just_list) return false;
			$svalues = Ccms_sessions::get_session_types();
			if(defined('CMS_S_LOCAL_SESSIONS_BOOL')) {	// early version settings
				$value = (CMS_S_LOCAL_SESSIONS_BOOL ? 'PHP_FILE':'APACHE_FILE');
				self::addMsg("Upgrading LOCAL_SESSIONS_BOOL to SESSION_TYPE",'info');
				} // if
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if (substr($ini_key, -17) == 'LANG_TRANS_METHOD') { // trans engine
			if($just_list) return false;
			$svalues = Ccms_language::get_trans_methods_available();
			$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
			$text .= self::add_svalues_options($svalues, $value);
			$text .= PHP_EOL . '</select>' . PHP_EOL;
			} // else if
		else if (substr($ini_key, -8) == '_EXT_INC') { // external code includde files
			if($just_list) return false;
			$text .= self::get_ext_code_dir_selection($name,$value);
			} // else if
		else if (substr($ini_key, -8) == '_SSL_INC') { // external SSL files
			if($just_list) return false;
			$text .= self::get_ssl_dir_selection($name,$value);
			} // else if
		else {
			if(is_array($value)) {
				$text .= '(Sub-Array)<input type="hidden" id="' . $id . '" name="' . $name . '" value="__SUB_ARRAY__"/>';
				} // if
			else if(($slen = strlen($value)) > $size) {	// a text area
				$text .= Ccms_html::get_textarea_input($name,$value,$id,
						' cols="' . ($size + 2) . '" rows="' . (($slen / $size) + 2) . '"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':''));
				} // else if
			else if($use_typedef_as_default) {	// use the type of $value to set the default
				switch(strtolower($value)) {
				case 'false':
					$value = false;
					break;
				case 'true':
					$value = true;
					break;
				default:
					break;
					} // switch
				if(is_bool($value)) {
					if($just_list) return array ('type' => 'BOOL','allowed' => array('true','false'));
					$text .= PHP_EOL . '<select id="' . $id . '" name="' . $name . '" size="1"' . ($readonly ? ' READONLY':'') . ($required ? ' REQUIRED':'') . '>';
					$text .= PHP_EOL . '<option value="false"'. (($value != true) ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;false&nbsp;&nbsp;&nbsp;&nbsp;</option>';
					$text .= PHP_EOL . '<option value="true"'. (($value == true) ? ' SELECTED':'') . '>&nbsp;&nbsp;&nbsp;&nbsp;true&nbsp;&nbsp;&nbsp;&nbsp;</option>';
					$text .= PHP_EOL . '</select>' . PHP_EOL;
					} // if
				else if(is_numeric($value)) {
					$text .= '<input type="number" id="' . $id . '" name="' . $name . '"' .
						' style="width: 98%;" ' .
						' value="' . $value . '"' .
						($readonly ? ' READONLY':'') .
						($required ? ' REQUIRED':'') .
						'/>';
					} // else if
				else {	// a text input box
					$text .= '<input type="text" id="' . $id . '" name="' . $name . '"' .
						' style="width: 98%;" ' .
						' value="' . $value . '"' .
						($readonly ? ' READONLY':'') .
						($required ? ' REQUIRED':'') .
						' autocapitalize="off"/>';
					} // else
				} // else if
			else {	// an input box
				$text .= '<input type="text" id="' . $id . '" name="' . $name . '"' .
//					' size="' . $size . '"' .
					' style="width: 98%;" ' .
					' value="' . $value . '"' .
					($readonly ? ' READONLY':'') .
					($required ? ' REQUIRED':'') .
					' autocapitalize="off"/>';
				} // else
			} // else
		if($just_list) return '';	// anything
		return $text;
	} // make_type_input_selr()

	public static function make_type_input($name,$sect_name,$ini_key,$value,$size = false, $readonly = false, $use_typedef_as_default = false, $required = false) {
		// $allowed = self::make_type_input_selr('', $ini_key, '', 0,true);
		if(!$size) $size = 30;
		if(($required) && ($readonly)) $required = false;	// stop a lock up
		$text = self::make_type_input_selr($name,$ini_key,$value,$size,false,$readonly,$use_typedef_as_default,$required);
		return $text;
	} // make_type_input()

	public static function get_border_attribute($border) {
		// if not 'none' or 'nil' (e.g. "7px solid green") then ouput border attribute
		list($w,$t,$c) = preg_split('/\s/',$border);
		switch($t) {
		case 'none':
			return 'border:		0;'  . PHP_EOL;	// no border
		default:	// the others 'hidden', 'dotted', 'dashed', 'solid', 'double', 'groove', 'ridge', 'inset', 'outset',
			break;
			} // switch
		return 'border:		' . $border . ';' . PHP_EOL;	
		} // get_border_attribute()

	public static function &get_admin_config_items() {	// returns admin config items for downs and columns
		if(!empty(self::$cms_admin_config_items)) return self::$cms_admin_config_items;
		$config_items = array();
		// add items in display order
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_search",
			'title' => "Search install, theme, config, page bodies and custom headers / footers.",
			'text' => 'Search',
			);
		$config_items[] = array(
			'allowed_now' => (((!CMS_S_HEADER_BOOL) || (CMS_C_CUSTOM_HEADER)) || Ccms_auth::is_cms_admin_user()),
			'uri' => "index.php",
			'title' => "Home Page",
			'text' => 'Home',
			);

		$config_items[] = array(
			'allowed_now' => (Ccms_apps::is_ini_congurable() && Ccms_auth::is_cms_admin_user()),
			'uri' => "index.php?cms_action=cms_edit_apps",
			'title' => "Edit local applications configuration settings",
			'text' => 'Apps Config',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'func' => 'Ccms_apps::get_apps_admin_extensions',
			'text' => 'Admin Extensions',
			);
		$config_items[] = array(
			'allowed_now' => ((file_exists(APPS_FS_APPS_MANUAL)) && (is_readable(APPS_FS_APPS_MANUAL)) && Ccms_auth::is_cms_group_manager()),
			'role' => 'manger',
			'uri' => "index.php?cms_action=apps_manual",
			'title' => CMS_C_CO_NAME . " Applications Technical Manual",
			'text' => "Apps Manual",
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_header_footer",
			'title' => "Edit applications custom header and footer contents.",
			'text' => 'Header / Footer',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_bodies",
			'title' => "Edit applications page body contents and applications control.",
			'text' => 'Apps / Bodies',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_tools",
			'title' => "Edit and change local tools.",
			'text' => 'Tools',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_users",
			'title' => "Edit and change " . CMS_PROJECT_SHORTNAME . " local users",
			'text' => 'Users',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_groups",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " user local groups",
			'text' => 'Groups',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_sections",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " sections on links page",
			'text' => 'Sections',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_links",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " links and URLs on links page",
			'text' => 'Links',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_config",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " configuration settings",
			'text' => 'Config',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_theme",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " theme settings",
			'text' => 'Theme',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_edit_install",
			'title' => "Edit " . CMS_PROJECT_SHORTNAME . " installation settings",
			'text' => 'Install',
			);
		$config_items[] = array(
			'allowed_now' => ((defined('CMS_S_SITEMAPS_BOOL')) && (CMS_S_SITEMAPS_BOOL) && Ccms_auth::is_cms_admin_user()),
			'uri' => "index.php?cms_action=update_sitemap",
			'title' => "Update XML sitemap and show HTML sitemap.",
			'text' => 'Show Map',
			);
		$config_items[] = array(
			'allowed_now' => ((file_exists(CMS_SITEMAP_XML_FILE)) && (is_readable(CMS_SITEMAP_XML_FILE)) && Ccms_auth::is_cms_admin_user()),
			'uri' => CMS_SITEMAP_XML_FILE,
			'new' => true,
			'title' => "Show the Google XML sitemap on new tab/window",
			'text' => 'Show XML Map',
			);
		$lo_inv = false;
		if(Ccms::show_nav_bar()) {
			$grid_chk = Ccms::get_navbar_grid();
			unset($grid_chk['apps']);
			foreach($grid_chk as $g) {
				$uri = (!empty($g[0]['uri']) ? $g[0]['uri']:$g[0]);
				if(preg_Match('/logout/i',$uri)) {
					$lo_inv = true;
					break;
					} // if
				} // foreach
			} // if
		$config_items[] = array(
			'allowed_now' => (((!CMS_S_HEADER_BOOL) || (CMS_C_CUSTOM_HEADER) || (!$lo_inv)) && Ccms_auth::is_cms_admin_user()),
			'uri' => "logout.php",
			'title' => "Logout: " . Ccms_auth::get_logged_in_username(),
			'text' => 'Logout',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_log_view",
			'title' => "View and manage " . CMS_PROJECT_SHORTNAME . " log files.",
			'text' => 'Logs',
			);
		$config_items[] = array(
			'allowed_now' => ((Ccms_sessions::is_session_browsing_available()) && Ccms_auth::is_cms_admin_user()),
			'role' => 'admin',
			'uri' => "index.php?cms_action=cms_browse_sessions",
			'title' => "Browse user sessions.",
			'text' => 'Sessions',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_users_stats",
			'title' => "Browse user statics.",
			'text' => 'User Stats',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_rebuild_setup",
			'confirm' => 'Check / rebuild installation.\nRebuild may take several minutes.',
			'title' => "Check / rebuild " . CMS_PROJECT_SHORTNAME . " installation and back up.\nRebuild installation, theme and configuration settings.\nNOTE: May take several minutes. See the manual.",
			'text' => 'Rebuild',
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_group_manager(),
			'uri' => "index.php?cms_action=cms_about",
			'title' => "About " . Ccms_base::get_version_str(),
			'text' => "About",
			);
		$config_items[] = array(
			'allowed_now' => Ccms_auth::is_cms_admin_user(),
			'uri' => "index.php?cms_action=cms_manual",
			'title' => strip_tags(CMS_PROJECT_NAME . ' ' . CMS_PROJECT_VERSION) . " technical manual.",
			'text' => 'Manual',
			);
		$config_items[] = array(
			'allowed_now' => ((Ccms::is_debug()) && Ccms_auth::is_cms_group_manager()),
			'uri' => "index.php?cms_action=cms_debug_vars",
			'title' => "Debug: show " . CMS_PROJECT_SHORTNAME . " values and constants.",
			'text' => 'Debug Values',
			);
		if(CMS_S_CODE_DEBUG_TEST_NTAB_BOOL) {
			$url = Ccms_base::get_base_url(true) . CMS_S_CODE_DEBUG_TEST_URI;
			} // if
		else $url = "index.php?cms_action=cms_debug_code";
		$config_items[] = array(
			'allowed_now' => ((defined('CMS_S_CODE_DEBUG_TEST_URI')) && (CMS_S_CODE_DEBUG_TEST_URI) &&
				(file_exists(DOCROOT_FS_BASE_DIR . CMS_S_CODE_DEBUG_TEST_URI)) && Ccms_auth::is_cms_group_manager()),
			'uri' => $url,
			'title' => "Run test debug code &quot;" . CMS_S_CODE_DEBUG_TEST_URI . "&quot;.",
			'text' => 'Debug Code',
			'new' => CMS_S_CODE_DEBUG_TEST_NTAB_BOOL,
			);
		$config_items[] = array(
			'allowed_now' => ((CMS_C_API_ENABLE) && Ccms_auth::is_cms_group_manager()),
			'uri' => "index.php?cms_action=cms_api_test",
			'title' => "API debug: Explore API interface.",
			'text' => 'API Test',
			);
		$doxy_uri = Ccms_base::get_base_url(true);
		$config_items[] = array(
			'allowed_now' => ((file_exists(DOXY_FS_DOCS_CMS_DIR . 'index.html')) && Ccms_auth::is_cms_group_manager()),
			'uri' => $doxy_uri . DOXY_WS_DOCS_CMS_DIR . 'index.html',
			'title' => "Code Docs: Explore " . CMS_PROJECT_SHORTNAME . " doxygen documents.",
			'text' => 'Doxy CMS',
			'new' => true,
			);
		$config_items[] = array(
			'allowed_now' => ((file_exists(DOXY_FS_DOCS_APPS_DIR . 'index.html')) && Ccms_auth::is_cms_group_manager()),
			'uri' => $doxy_uri . DOXY_WS_DOCS_APPS_DIR . 'index.html',
			'title' => "Code Docs: Explore Apps doxygen documents.",
			'text' => 'Doxy Apps',
			'new' => true,
			);
		$config_items[] = array(
			'allowed_now' => ((file_exists(DOXY_FS_DOCS_APPS_CMS_DIR . 'index.html')) && Ccms_auth::is_cms_group_manager()),
			'uri' => $doxy_uri . DOXY_WS_DOCS_APPS_CMS_DIR . 'index.html',
			'title' => "Code Docs: Explore Apps and " . CMS_PROJECT_SHORTNAME . " doxygen documents.",
			'text' => 'Doxy Apps &amp; CMS',
			'new' => true,
			);
		// $debug = print_r($config_items,true);	// debug var 1000000
		self::$cms_admin_config_items = $config_items;
		return self::$cms_admin_config_items;
		} // get_admin_config_items()

	public static function &get_bodies_menu_items() {	// returns bodies menu for downs and columns
		if(!empty(self::$cms_bodies_menu_items)) return self::$cms_bodies_menu_items;
		$body_items = array();
		$body_items[] = array(
			'func' => 'Ccms_apps::get_apps_menus_submenus',
			'text' => 'App Extensions',
			);
		if(Ccms_sm::is_links_manager_inuse()) {
			$body_items[] = array(
				'uri' => 'index.php?cms_action=lm_show_links',
				'title' => "Goto Links Manager page",
				'text' => 'Links',
				);
			} // if
		$sql_body_query = "SELECT  cms_body_id, cms_body_name, cms_body_app_key, cms_body_virtual_name, cms_body_lang, cms_body_iframe_view, cms_body_dir, cms_body_description, cms_body_file, cms_body_login_required" .
			", cms_body_ssl, cms_body_group_ids, cms_body_title,cms_body_manager_group_ids,cms_body_default,cms_body_enabled,cms_body_debug_only" .
			" FROM  cms_bodies" .
			" WHERE cms_body_nomenu < 1" .
			" ORDER BY  cms_body_default DESC, cms_body_order ASC,cms_body_id ASC;";
		if($result_body = self::$cDBcms->query($sql_body_query)) {
			while($body = self::$cDBcms->fetch_array($result_body)) {
				// if(!self::check_user_group_ids($body['cms_body_group_ids'])) continue;
				$filename = APPS_BODIES_FS_DIR . $body['cms_body_file'];
				if((!file_exists($filename)) || (!is_readable($filename))) {
					continue;
					} // if
				$allowed_now = (($body['cms_body_enabled'] > 0) ? true:false);
				if($allowed_now) {
					$allowed_now = self::check_user_group_ids($body['cms_body_group_ids']);
					if(($body['cms_body_login_required'] > 0) && (self::is_cms_guest()))
						$allowed_now = false;
					else if(($body['cms_body_ssl'] > 0) && (!self::is_ssl_inuse()))
						$allowed_now = false;
					else if(($body['cms_body_iframe_view'] > 0) && (!self::is_ssl_inuse()))
						$allowed_now = false;	// Most browsers prevent mixed active content from loading, and some also block mixed display content.
					else if(($body['cms_body_debug_only'] > 0) && (!self::is_debug()))
						$allowed_now = false;
					} // if
				$body_items[]  = array(
					'id' => 'id_body_' . $body['cms_body_id'],
					'allowed_now' => $allowed_now,
					'text' => $body['cms_body_name'],
					'uri' => self::get_body_uri($body),
					'description' => $body['cms_body_description'],
					'title' => $body['cms_body_title'],
					'plugins' => self::get_body_plugins($body),
					'app_key' => self::get_app_key($body),
					'app_name' => self::get_app_name($body),
					'app_dir' => $body['cms_body_dir'],
					'body' => $body,
					);
				} // while
			} // if

		// $debug = print_r($body_items,true);	// debug var 1000000
		self::$cms_bodies_menu_items = $body_items;
		return self::$cms_bodies_menu_items;
		} // get_bodies_menu_items()

	public static function &get_tools_menu_items() {	// returns bodies menu for downs and columns
		if(!empty(self::$cms_tools_menu_items)) return self::$cms_tools_menu_items;

		$sql_query = "SELECT  cms_tool_id,cms_tool_name,cms_tool_description,cms_tool_version,cms_tool_url,cms_tool_title, cms_tool_copyright, cms_tool_debug_only" .
			", cms_tool_new_page, cms_tool_enabled, cms_tool_ssl, cms_tool_login_required, cms_tool_group_ids, cms_tool_add_name2url,cms_tool_group_ids" .
			" FROM  cms_tools" .
			" ORDER BY  cms_tool_order,cms_tool_name,cms_tool_id";
		$cms_tools_items = array();
		if (($result = self::$cDBcms->query($sql_query)) &&
			(self::$cDBcms->num_rows($result) > 0)) {
			while ($tool = self::$cDBcms->fetch_array($result)) {
				if(empty($tool['cms_tool_url'])) continue;
				if(!file_exists(LOCAL_FS_TOOLS_DIR . $tool['cms_tool_url'])) continue;
				$allowed_now = (($tool['cms_tool_enabled'] > 0) ? true:false);
				if($allowed_now) {
					$allowed_now = self::check_user_group_ids($tool['cms_tool_group_ids']);
					if(($tool['cms_tool_login_required'] > 0) && (self::is_cms_guest()))
						$allowed_now = false;
					else if(($tool['cms_tool_ssl'] > 0) && (!self::is_ssl_inuse()))
						$allowed_now = false;
					else if(($tool['cms_tool_debug_only'] > 0) && (!self::is_debug()))
						$allowed_now = false;
					} // if
				$url = Ccms_sm::get_tool_uri($tool);
				$cms_tools_items[] = array(
					'id' => 'id_tool_' . $tool['cms_tool_id'],
					'allowed_now' => $allowed_now,
					'uri' => $url,
					'new' => $tool['cms_tool_new_page'],
					'title' => (!empty($tool['cms_tool_title']) ? strip_tags($tool['cms_tool_title']):''),
					'text' => $tool['cms_tool_name'],
					'description' => $tool['cms_tool_description'],
					'tool' => $tool,
					);
				} // while
			} // if
		self::$cms_tools_menu_items = $cms_tools_items;
		return self::$cms_tools_menu_items;
		} // get_tools_menu_items()

// dynamic methods


	} // Ccms_options
