<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_drop_box.php 3063 2022-12-26 09:10:56Z robert0609 $
 */

/**
 * Description of box_tool_tips
 *
 * @author robert0609
 */

class Ccms_drop_box {

	protected static $outer_class = '';
	protected static $outer_params = '';

	protected static $inner_class = '';
	protected static $inner_params = '';
	
	private static $class_idx = 0;

	public function __construct() {
		} // __construct()

	public function __destruct() {

		} // __destruct()

	public static function anchor($url,$label,&$text_inner_ary, $outer_class = '', $inner_class = '') {
		if(is_array($text_inner_ary)) {	// $text_inner_ary is a ref and can be a parameter array or the text_inner
			foreach($text_inner_ary as $k => &$v) {
				if(!is_numeric($k))
					$$k = $v;	// define arry contents
				} // foreach
			if(empty($text_inner)) {
				Ccms::addDebugMsg('CODE ERROR: Missing text_inner parameter for ' . $label . ' (1).');
				$text_inner = '';
				} // if
			} // if
		else $text_inner = &$text_inner_ary;
		if((!Ccms::is_hover_boxes_ok()) || (empty($label))) return '';
		$text = '<a class="' . (!empty($outer_class) ? ' ' . $outer_class:'cms_hover_block_outer') . '" href="' . $url . '">' . PHP_EOL .
				'	' . $label . PHP_EOL .
				'	<div class="' . (!empty($inner_class) ? ' ' . $inner_class:'cms_hover_block_inner') . '">' . PHP_EOL .
				'	' . $text_inner . PHP_EOL .
				'	</div>' . PHP_EOL .
				'</a>' . PHP_EOL;
		return $text;
		} // anchor()

	public static function hover_block($label,&$text_inner_ary,
		$outer_class = '', $inner_class = '',
		$outer_params = '', $inner_params = '',
		$table_class = '') {
		if(Ccms::is_tiny() || Ccms::is_tablet()) {	// use panel_block()
			return self::panel_block($label,$text_inner_ary,$outer_class,$inner_class,
					$outer_params, $inner_params,$table_class);
			} // if
		if(is_array($text_inner_ary)) {	// $text_inner_ary is a ref and can be a parameter array or the text_inner
			foreach($text_inner_ary as $k => &$v) {
				if(!is_numeric($k))
					$$k = $v;	// define arry contents
				} // foreach
			if(empty($text_inner)) {
				if(!empty($text)) $text_inner = $text;	// catch the common variation
				else {
					Ccms::addDebugMsg('CODE ERROR: Missing text_inner parameter for ' . $label . ' (2).');
					$text_inner = '';
					} // else
				} // if
			} // if
		else $text_inner = &$text_inner_ary;
		if(!Ccms::is_hover_boxes_ok()) return '';
		if(empty($label)) $label = '&nbsp;&nbsp;';
		$text = '<div' . //	((Ccms::is_tiny() || Ccms::is_tablet()) ? ' onClick="return true"':'') .
					' class="' . (!empty($outer_class) ? ' ' . $outer_class:'cms_hover_block_outer') . '"' .
					(!empty($outer_params) ? ' ' . $outer_params:'') . '>' . PHP_EOL .
					$label . PHP_EOL .
				'	<div class="' . (!empty($inner_class) ? ' ' . $inner_class:'cms_hover_block_inner') . '"' .
							(!empty($inner_params) ? ' ' . $inner_params:'') . '>' . PHP_EOL .
				'		' . (!empty($table_class) ? '<table class="' . $table_class . '"><tr class="' . $table_class . '"><td class="' . $table_class . '">':'') .
				'		' . $text_inner . PHP_EOL .
				'		' . (!empty($table_class) ? '</td></tr></table>':'') .
				'	</div>' . PHP_EOL .
				'</div>' . PHP_EOL;
		return $text;
		} // hover_block()

	public static function panel_block($label,&$text_inner_ary,
		$outer_class = '', $inner_class = '',
		$outer_params = '', $inner_params = '',
		$table_class = '') {
		if(is_array($text_inner_ary)) {	// $text_inner_ary is a ref and can be a parameter array or the text_inner
			foreach($text_inner_ary as $k => &$v) {
				if(!is_numeric($k))
					$$k = $v;	// define arry contents
				} // foreach
			if(empty($text_inner)) {
				Ccms::addDebugMsg('CODE ERROR: Missing text_inner parameter for ' . $label . ' (3).');
				$text_inner = '';
				} // if
			} // if
		else $text_inner = &$text_inner_ary;
		if(!Ccms::is_hover_boxes_ok()) return '';
		$id = 'id_panel_blk_' . self::$class_idx++;
		if(empty($label)) $label = '&nbsp;&nbsp;';
		// $ev_main = 'onclick="cms_toggle_childByIndex(event,this,\'SPAN\',0);"';
		// $ev_main = 'onclick="cms_toggle_elemsByClass(\'' . (!empty($inner_class) ? ' ' . $inner_class:'cms_panel_block_inner') . '\');"';
		$ev_main = 'onclick="cms_toggle_childByID(event,\'' . (!empty($inner_class) ? ' ' . $inner_class:'cms_panel_block_inner') . '\',\'' . $id . '\');"';
		$ev_bye_gd = ' onclick="event.stopPropagation(); this.parentElement.parentElement.style.display = \'none\';"';	// bye grandad' .
		$text = '';
		$text .= '<div ' . $ev_main . PHP_EOL .
					' class="' .(!empty($outer_class) ? ' ' . $outer_class:'cms_panel_block_outer') . '"' .
					(!empty($outer_params) ? ' ' . $outer_params:'') .
					'>' . PHP_EOL .
					$label . PHP_EOL .
				'	<div class="' . (!empty($inner_class) ? ' ' . $inner_class:'cms_panel_block_inner') . '"' .
							' id="' . $id . '"' .
							(!empty($inner_params) ? ' ' . $inner_params:'') .
							// ' onmouseout="this.style.display = \'block\';"' .
							'>' . PHP_EOL .
				'		' . '<div>' . $label . PHP_EOL .
				'				<div style="display: inline-block; float: right; font-size: 1.4em;" ' . $ev_bye_gd . '>' . PHP_EOL .	// bye grandad
				'					&nbsp;&times;&nbsp;</div></div>' . PHP_EOL .
				'		' . (!empty($table_class) ? '<table class="' . $table_class . '"><tr class="' . $table_class . '"><td class="' . $table_class . '">':'') .
				'		' . $text_inner . PHP_EOL .
				'		' . (!empty($table_class) ? '</td></tr></table>':'') .
				'	</div>' . PHP_EOL .
				'</div>' . PHP_EOL;
		return $text;
		} // panel_block()

} // Ccms_drop_box

?>
