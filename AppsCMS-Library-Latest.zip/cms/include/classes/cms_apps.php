<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_apps.php 3278 2023-03-23 14:46:57Z robert0609 $
 */

/**
 * Description of cms_apps
 * general base class for local applications functions
 *
 * @author robert0609
 */

class Ccms_apps extends Ccms_general {

	protected static $cms_app_flg = false;
	protected static $cms_app_ini_flg = false;
	protected static $cms_apps_config_done = false;
	protected static $cms_apps_ini = false;
	protected static $cms_apps_ini_flat = false;
	protected static $cms_apps_ini_ctls = false;

	function __construct() {
		parent::__construct();
		if(!self::is_apps()) return;
		self::$cms_app_flg = true;
		$this->init();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods
	public static function is_ini_congurable() {
		if(!Ccms_auth::is_cms_admin_user()) return false;
		if(!self::is_apps()) return false;
		// if(is_readable(ETC_FS_APPS_CONFIG)) return true;
		// to slow if(!self::read_apps_ini_comments()) return false;
		if(!file_exists(APPS_FS_CONFIG_MSGS)) return false;
		// too slow if(!self::read_apps_ini_defaults()) return false;
		if(!file_exists(APPS_FS_APPS_CONFIG_DEFAULT)) return false;

		return true;
		} // is_ini_congurable()

	public static function &read_apps_ini_settings($rebuild = false) {
		if(self::$cms_apps_ini) return self::$cms_apps_ini;
		if(!file_exists(ETC_FS_APPS_CONFIG)) return self::$cms_apps_ini;	// false
		$settings = self::parse_ini_file(ETC_FS_APPS_CONFIG,true);	// the data
		if($settings === false) {
			self::addMsg('Read of "' . basename(ETC_FS_APPS_CONFIG) . '" format error.');
			return self::$cms_apps_ini;	// false
			} // if
		if((self::is_debug()) || ($rebuild)) {// check for missing sections and keys (and values)
			$settings_comments = self::read_apps_ini_comments();
			$settings_default = self::read_apps_ini_defaults();
			$defaults = array();
			foreach ($settings_default as $sect_name => &$sect) {
				if(preg_match('/^_/',$sect_name)) continue;	// system section
				if(empty($settings[$sect_name])) {	// new/missing section
					$settings[$sect_name] = $sect;	// put the default values in
					self::log_msg('Missing APPS INI section: ' . $sect_name . ', using default.', 'warn');
					$defaults[] = 'Added section ' . $sect_name;
					continue;
					} // if
				foreach ($sect as $key => $val) {
					if(!isset($settings[$sect_name][$key])) {	// new/missing section
						$settings[$sect_name][$key] = $val;	// put the default values in
						self::log_msg('Missing APPS INI section: ' . $sect_name . ', key: ' . $key . ', using default.', 'warn');
						$defaults[] = '[' . $sect_name . '][' . $key . ']=' . $val;
						continue;
						} // if
					} // foreach
				} // foreach
			if(!empty($defaults)) {
				self::addAdminMsg("Using: " . PHP_EOL . implode(',' . PHP_EOL,$defaults) . PHP_EOL . " default values from Aggregated Applications INI Defaults.", 'warning');
				if(self::is_rebuild()) {
					self::write_ini_settings(ETC_FS_APPS_CONFIG,$settings,
						ETC_FS_APPS_CONFIG_JSON,
						"; rebuild to insert defaults.");
					}  // if
				} // if
			} // if
		self::$cms_apps_ini = $settings;
		return self::$cms_apps_ini;
		} // read_apps_ini_settings()

	private static function merge_apps_ini_comments($ini,$parent_ini,$cntl) {
		$body_defines = Ccms_sm::get_bodies_defines();
		foreach($body_defines as $cms_body_id => &$body) {
			if(empty($body['app_key'])) continue;
			if(empty($body['app_dir'])) continue;
			$fi = APPS_WS_DIR . $body['app_dir'] . '/ini/' . $ini;
			$cms_app_key = self::get_app_key($body,'_');
			$class = self::get_app_primary_class($body);
			if(file_exists(DOCROOT_FS_BASE_DIR . $fi)) {
				if(!$cms_app_comments = self::parse_ini_file(DOCROOT_FS_BASE_DIR . $fi,true)) {
					self::addDebugMsg('Read of "' . $fi . '" format error.');
					continue;
					} // if
				// join it together
				foreach($cms_app_comments as $sect_name => &$sect) {
					foreach($sect as $key => &$val) {
						if($key == 'comment')
							$parent_ini[$cms_app_key . $sect_name][$key] = $val;
						else {
							if(($cntl) && ($class) &&
								(method_exists($class,'is_app_setup_key_funcs_used')) &&
								($class::is_app_setup_key_funcs_used($key))) {	// check for app special funcs used for this app setup key
								$ctl = array(
									'text' => $val,
									'app_key' => $cms_app_key,
									'_show_func' => (method_exists($class,'show_app_setup_value') ? $class . '::show_app_setup_value':false),
									'_form_input_func' => (method_exists($class,'input_app_setup_form_text') ? $class . '::input_app_setup_form_text':false),
									'_form_get_func' => (method_exists($class,'get_app_setup_form_value') ? $class . '::get_app_setup_form_value':false),
									);
								$parent_ini[$cms_app_key . $sect_name][$cms_app_key . $key] = $ctl;
								} // if
							else $parent_ini[$cms_app_key . $sect_name][$cms_app_key . $key] = $val;
							} // else
						} // foreach
					} // foreach
				} // if
			} // foreach
		return $parent_ini;
		} // merge_apps_ini_comments()

	public static function read_apps_ini_comments() {
		if(file_exists(APPS_FS_CONFIG_MSGS)) {
			$comments = self::parse_ini_file(APPS_FS_CONFIG_MSGS,true,true);	// the control keynames
			if($comments === false) {
				self::addMsg('Read of "' . basename(APPS_FS_CONFIG_MSGS) . '" format error.');
				return false;
				} // if
			} // if
		else $comments = array();	// empty primary/global settings
		return self::merge_apps_ini_comments('app.comments.ini', $comments,true);	// include apps comments
		} // read_apps_ini_comments()

	public static function read_apps_ini_defaults() {
		if(file_exists(APPS_FS_APPS_CONFIG_DEFAULT)) {
			$defaults = self::parse_ini_file(APPS_FS_APPS_CONFIG_DEFAULT,true,true);	// the contral keynames
			} // if
		else $defaults = array();
		return self::merge_apps_ini_comments('app.defaults.ini', $defaults,false);	// include apps defaults
		} // read_apps_ini_defaults()

 	protected static function get_apps_configs() {
		if(self::$cms_apps_config_done) return true;
		self::$cms_apps_config_done = true;	// only need once
		$cms_apps_config = APPS_FS_INCLUDE_DIR . 'apps_config.php';
		if(file_exists($cms_apps_config)) {
			require_once $cms_apps_config;
			} // if
		return true;
		} // get_apps_configs()

	public static function get_apps_settings($redefine = false) {
		// if(self::is_rebuild()) return false;
		if((!$redefine) && (self::$cms_app_ini_flg)) return true;
		self::$cms_app_ini_flg = true;

		if(!$settings = self::read_apps_ini_settings()) return false;

		// define apps settingss
		foreach($settings as $sect_name => $sect) {
			if(preg_match('/^_/i',$sect_name)) continue;
			foreach($sect as $key => $val) {
				if(defined('APP_' . $key)) continue;
				$val = self::get_macro_lookup($sect_name,$sect, $key, $val);
				$val = self::conv_conf_val_to_type($val);
				define('APP_' . $key,$val);
				} // foreach
			} // foreach
		self::get_apps_configs();
		return true;
		} // get_apps_settings()

	public static function get_apps_ini_value($key,$sect_name = false) { // get from the ini file directly
		$cms_apps_settings = self::read_apps_ini_settings(); // cache
		if ((empty($sect_name)) || ($sect_name == '*')) { // flat lookup required (uniqueness required per manual)
			// slow way
			if (self::$cms_apps_ini_flat === false) {
				self::$cms_apps_ini_flat = array(); // cache
				foreach ($cms_apps_settings as $sect_nam => &$sect) {
					foreach ($sect as $k => &$v) {
						self::$cms_apps_ini_flat[$k] = $v;
				} // foreach
			} // foreach
		} // if
			if (!isset(self::$cms_apps_ini_flat[$key]))
				return null;
			$value = self::$cms_apps_ini_flat[$key];
		} // if
		else { // normal lookup
			if (!isset($cms_apps_settings[$sect_name][$key]))
				return null;
			$value = $cms_apps_settings[$sect_name][$key];
		} // else

		if (is_numeric($value))
			return $value;

		$value = self::get_macro_lookup($sect_name, $cms_apps_settings[$sect_name], $key, $value);
		$val = self::conv_conf_val_to_type($value);
		return $val;
		} // get_apps_ini_value()

	public static function set_apps_ini_value($key, $value, $sect_name = false) { // set the ini file directly
		$cms_apps_ini = self::read_apps_ini_settings(); // cache
		foreach ($cms_apps_ini as $sect_nm => &$sect) {
			foreach ($sect as $k => &$v) {
				if ((!empty($sect_name)) && ($sect_name != $sect_nm)) continue;
				if($k == $key) {
					$cms_apps_ini[$sect_nm][$key] = $value;
					return self::save_apps_ini_settings($cms_apps_ini,true);
					} // if
				} // foreach
			} // foreach
		return false;
		} // set_apps_ini_value()

	public static function output_apps_jhead_inc($prn = true) {
		static $sent = false;
		if(!$sent) {
			$sent = true;
			 if(empty(self::$cms_body_id)) return '';
			// $body_defines = Ccms_sm::get_bodies_defines();
			// add app js in correct order
			
			ob_start();
			$cms_apps_head_inc = APPS_FS_INCLUDE_DIR . 'apps_head_inc.php';
			if(file_exists($cms_apps_head_inc)) {
				include($cms_apps_head_inc);
				} // if
			
			$cms_app_head_inc = APPS_FS_DIR . self::$cms_app_dir  . '/include/' . 'app_head_inc.php';
			if(file_exists($cms_app_head_inc)) {
				include($cms_app_head_inc);
				} // if
			
			$text = ob_get_clean();
			$ct = preg_replace('/(\n\n|\s$)/m','',$text);
			if($prn) echo $ct;
			return $ct;
			} // if
		return '';
		} // output_apps_head_inc()

	public static function output_apps_js($prn = true) {
		static $sent = false;
		if(!$sent) {
			$sent = true;
			 if(empty(self::$cms_body_id)) return '';
			$text = '';
			// $body_defines = Ccms_sm::get_bodies_defines();
			// add app js in correct order
			$text .= Ccms_sm::get_head_JS_url(APPS_WS_DIR . 'js/apps.js') . PHP_EOL;
			$text .= Ccms_sm::get_head_JS_url(APPS_WS_DIR . self::$cms_app_dir . '/js/app.js') . PHP_EOL;
			$ct = preg_replace('/(\n\n|\s$)/m','',$text);
			if($prn) echo $ct;
			return $ct;
			} // if
		return '';
		} // output_apps_js()

	public static function output_apps_css($prn = true) {
		if(!CMS_S_INC_APPS_CSS_IN_HEAD_BOOL) return '';
		static $sent = false;
		if(!$sent) {
			$sent = true;
			if(!self::is_apps_action()) return '';

			if(empty(self::$cms_app_dir)) {
				if(empty(self::$cms_page_info['body']['cms_body_dir'])) return '';
				$app_dir = self::$cms_page_info['body']['cms_body_dir'];
				} // if
			else $app_dir = self::$cms_app_dir;

			if(empty(self::$cms_app_name)) {
				if(empty(self::$cms_page_info['body']['cms_body_name'])) return '';
				$app_name = self::$cms_page_info['body']['cms_body_name'];
				} // if
			else $app_name = self::$cms_app_name;

			$text = '';
			// $body_defines = Ccms_sm::get_bodies_defines();
			// add app css in correct order
			$text .= Ccms_sm::get_head_CSS_url(APPS_WS_DIR . 'css/apps.css') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(APPS_WS_DIR . $app_dir . '/css/app.css') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(APPS_WS_DIR . $app_dir . '/css/app.scss') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(ETC_WS_CSS_DIR . 'apps.css') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(ETC_WS_CSS_DIR . 'apps_sass.css') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(ETC_WS_CSS_DIR . $app_name . '_app.css') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(ETC_WS_CSS_DIR . $app_name . '_app_sass.css') . PHP_EOL;
			$text .= Ccms_sm::get_head_CSS_url(ETC_WS_CSS_DIR . $app_name . '_app.scss') . PHP_EOL;
			$ct = trim(preg_replace('/' . PHP_EOL . PHP_EOL . '/m',PHP_EOL,preg_replace('/\s$/m','',$text)));
			if($prn) echo $ct;
			return $ct;
			} // if
		return '';
		} // output_apps_css()

	public static function gen_app_css() {
		$body_defines = Ccms_sm::get_bodies_defines();
		$settings = self::read_apps_ini_settings();
		$ok = true;
		foreach($body_defines as $cms_body_id => &$body) {
			if(empty($body['app_key'])) continue;
			if(empty($body['app_dir'])) continue;
			$cms_app_key = $body['app_key'];
			$theme_key = $cms_app_key . '_ThemeSettings';

			// make theme combo
			if(empty($body['app_dir'])) continue;
			$fi = APPS_WS_DIR . $body['app_dir'] . '/include/app_scss.php';
			if(file_exists($fi)) {	// compile scss
				$fo = ETC_WS_CSS_DIR . $body['app_name'] . '_app_sass.css';
				$gen_note = '"' . $body['cms_body_name'] . '" App theme SCSS file generated and compiled on ' . self::get_gm_datetime() . PHP_EOL;
				ob_start();
				include(DOCROOT_FS_BASE_DIR . $fi);
				$scss = ob_get_clean();
				if((!empty($scss)) &&
					($text = Ccms_sassc::compile_scss_t2t($scss)) &&					
					(self::file_safe_write(DOCROOT_FS_BASE_DIR . $fo, $text))) {
					self::chmod_chown(DOCROOT_FS_BASE_DIR . $fo);
					self::addMsg('Generated and compiled updated "' . $body['cms_body_name'] . '" "_app_sass.css".','success');
					} // if
				else {
					$ok = false;
					self::addMsg('Failed to generate and compiled updated "' . $body['cms_body_name'] . '" "_app_sass.css".');
					} // else
				
				} // if
			$fi = APPS_WS_DIR . $body['app_dir'] . '/include/app_css.php';
			if(file_exists(DOCROOT_FS_BASE_DIR . $fi)) {
				// do all three for compatibiblity
				$theme = array();
				if(isset($settings[$theme_key])) {
					foreach($settings[$theme_key] as $k => $v) {
						// make it look like the original INI file
						$kk = preg_replace('/^' . $cms_app_key . '_/','',$k);
						$theme['ThemeSettings'][$kk] = $v;

						$theme[$kk] = $v;	// the easy ones
						$theme[$k] = $v;	// the easy ones
						$theme[$theme_key][$k] = $v;	// compatibility version
						} // foreach
					} // if
				$fo = ETC_WS_CSS_DIR . $body['app_name'] . '_app.css';
				$gen_note = '"' . $body['cms_body_name'] . '" App theme CSS file generated on ' . self::get_gm_datetime() . PHP_EOL;
				ob_start();
				include(DOCROOT_FS_BASE_DIR . $fi);
				$text = ob_get_clean();
				if((!empty($text)) &&
					(self::file_safe_write(DOCROOT_FS_BASE_DIR . $fo, $text))) {
					self::chmod_chown(DOCROOT_FS_BASE_DIR . $fo);
					self::addMsg('Generated updated "' . $body['cms_body_name'] . '" "app.css".','success');
					} // if
				else {
					$ok = false;
					self::addMsg('Failed to generate updated "' . $body['cms_body_name'] . '" "app.css".');
					} // else
				} // if
			} // foreach
		return $ok;
		} // gen_app_css()

	public static function save_apps_ini_settings(&$new_settings,$always_save = true) {
		Ccms_content_cache::reset_caches(false);
		Ccms_minify_plugin::expire_cache();
		if(!self::is_rebuild()) {	// hot fix bug fix for orphan removal
			if($old_settings = self::read_apps_ini_settings()) {
				foreach($old_settings as $sect_name => $section) {
					// put in missings sections
					if(!isset($new_settings[$sect_name])) {
						$new_settings[$sect_name] = $section;
						} // if
					} // foreach
				} // if
			} // if
		self::insert_macros($new_settings);

		$ini_cntl = self::read_apps_ini_comments();	// get control file
		$settings_default = self::read_apps_ini_defaults();
		if($settings_default === false) {
			self::addMsg('Read of "' . basename(APPS_FS_APPS_CONFIG_DEFAULT) . '" format error.');
			return false;
			} // if
		$save_settings = array();
		foreach($ini_cntl as $sect_name => $section) {
			if(preg_match('/^_/i',$sect_name)) continue;
			foreach($section as $key => $value_comment) {
				if($key == 'comment') continue;
				if(!isset($new_settings[$sect_name][$key])) $new_value = '';
				else {
					$new_value = $new_settings[$sect_name][$key];
					if(is_array($new_value)) {
						if(in_array('',$new_value)) $new_value = '';	// use default
						else $new_value = implode(' ',$new_value);
						} // if
					} // else

				if((empty($new_value)) && (!is_numeric($new_value)) &&
					(!empty($settings_default[$sect_name][$key]))) {
					$new_value = $settings_default[$sect_name][$key];
					$new_settings[$sect_name][$key] = $new_value;
					self::addMsg('Restore apps default; ' . Ccms::unmake_hungarion_fmt($sect_name) . ', ' . Ccms::make_nice_name($key) .' = "' . $new_value . '".','info');
					} // if

				if((!preg_match('/theme/i',$sect_name)) &&
					(!isset($ini_cntl[$sect_name][$key]['app_key']))) {
					if($new_value == '0') $new_value = 'false';
					if($new_value == '1') $new_value = 'true';
					} // if

				if((self::is_macro_lookup($sect_name, $new_value)) &&
					(self::get_macro_lookup($sect_name, $key, $new_value)) &&
					(!empty($settings_default[$sect_name][$key]))) {
					$macro = $new_value;
					$new_value = $settings_default[$sect_name][$key];
					$save_settings[$sect_name][$key] = $new_value;
					self::addMsg('Bad app macro expansion, using default; ' . Ccms::unmake_hungarion_fmt($sect_name) . ', ' . Ccms::make_nice_name($key) .' = "' . $new_value . '" (was "' . $macro . '").','info');
					} // if

				$save_settings[$sect_name][$key] = $new_value;
				} // foreach
			} // foreach
		if((empty($save_settings)) || (!is_array($save_settings))) {
			self::addMsg('No apps settings.','info');
			} // if

		if((!$always_save) && (!self::is_rebuild())) {
			$cmp = self::cmp_arrays($save_settings,$old_settings);
			if($cmp == 0) {
				self::addMsg('Unchanged APPS INI file.','info');
				return true;
				} // if
			} // if

		$hc =	'; Copyright: ' . 	CMS_C_CO_NAME . ' ' . date('Y') . PHP_EOL .
				'; Contains common applications settings.' . PHP_EOL . 
				'; Date: ' . self::get_gm_datetime() . PHP_EOL;
		if(!self::write_ini_settings(ETC_FS_APPS_CONFIG,$save_settings,ETC_FS_APPS_CONFIG_JSON,$hc)) return false;

		// import global theme settings for apps
		if((!isset($theme)) ||
			(empty($theme)) ||
			(!isset($theme['ThemeSettings'])) ||
			(!is_array($theme['ThemeSettings']))) {
			$theme = Ccms::read_cms_ini_settings(false,self::get_install_ini_sections());
			} // if

		if(file_exists(APPS_FS_CSS_DIR . 'apps_css.php')) {
			// build the apps.css changes

			$gen_note = 'Common apps CSS theme file generated on ' . self::get_gm_datetime() . PHP_EOL;
			$odd_even_ratio = Ccms_base::get_cms_ini_value('ODD_EVEN_ROW_CHG','ThemeSettings');	// typ '0.10'; // table row ratio for contrast
			$out = ETC_FS_CSS_DIR .'apps.css';
			ob_start();
			include(APPS_FS_CSS_DIR . 'apps_css.php');
			$text = ob_get_clean();
			if((!empty($text)) &&
				(self::file_safe_write($out, $text))) {
				self::chmod_chown($out);
				self::addMsg('Updated general "apps.css".','success');
				} // if
			else {
				$ok = false;
				self::addMsg('Failed to update general "apps.css".');
				} // else
			} // if

		if(file_exists(APPS_FS_CSS_DIR . 'apps_scss.php')) {
			// build the apps.css changes

			$gen_note = 'Common apps SCSS theme file generated and compiled on ' . self::get_gm_datetime() . PHP_EOL;
			$odd_even_ratio = Ccms_base::get_cms_ini_value('ODD_EVEN_ROW_CHG','ThemeSettings');	// typ '0.10'; // table row ratio for contrast
			$out = ETC_FS_CSS_DIR .'apps_sass.css';
			ob_start();
			include(APPS_FS_CSS_DIR . 'apps_scss.php');
			$sass = ob_get_clean();
			if((!empty($sass)) &&
				($text = Ccms_sassc::compile_scss_t2t($sass)) &&
				(self::file_safe_write($out, $text))) {
				self::chmod_chown($out);
				self::addMsg('Updated general "apps_sass.css".','success');
				} // if
			else {
				$ok = false;
				self::addMsg('Failed to update general "apps_sass.css".');
				} // else
			} // if

		Ccms_content_cache::reset_caches();
		Ccms_gotcha_plugin::reset_cache();
		Ccms_proxy::clear_signats();
		Ccms_minify_plugin::reset_cache();

		if(!self::gen_app_css()) return false;
		return true;
	} // save_apps_ini_settings()

	public static function is_apps() {
		if(!is_dir(APPS_FS_DIR)) return false;	// not present
		if(!is_readable(APPS_FS_DIR)) return false;	// not present
		return true;
		} // is_apps()

	protected static function get_app_primary_class(&$body) {
		if(empty($body['app_name'])) return false;
		if(empty($body['app_key'])) return false;
		if(empty($body['app_dir'])) return false;
		$cms_app_name = $body['app_name'];
		$cms_app_key = $body['app_key'];
		$cms_app_dir = $body['app_dir'];
		$class = 'C' . $cms_app_name . '_app';
		if(!class_exists($class)) {
			$class = 'C' . $cms_app_dir . '_app';
			if(!class_exists($class)) return false;
			} // if
		return $class;
		} // get_app_primary_class()

	public static function get_app_api_map_summary(&$body) {
		if(!Ccms_DB_checks::is_body_api_allowed($body['cms_body_type'])) return false;
		$class = self::get_app_primary_class($body);
		if(!$class) return false;
		if(method_exists($class,'get_api_map_summary')) {
			$summary = $class::get_api_map_summary();
			return $summary;
			} // if
		return false;
		} // get_app_api_map_summary()

	public static function get_head_text() {
		if(empty(self::$cms_body_id)) return false;
		if(empty(self::$cms_bodies[(self::$cms_body_id)])) return false;
		$body = &self::$cms_bodies[(self::$cms_body_id)];
		$class = self::get_app_primary_class($body);
		if(!$class) return false;
		if(method_exists($class,'get_head_text')) {
			$app_head = $class::get_head_text();
			return $app_head;
			} // if
		return false;
		} // get_head_text()

	public static function do_std_app_warnings($bld = false) {
		$body_defines = self::get_bodies_defines();
		foreach($body_defines as $cms_body_id => &$body) {
			$class = self::get_app_primary_class($body);
			if(!$class) continue;
			if(method_exists($class,'do_app_warnings')) {
				$class::do_app_warnings($bld);
				} // if
			} // foreach
		return true;
		} // do_std_app_warnings()

	public static function do_apps_rebuild() {
		//self::get_apps_settings();
		$cms_apps_bld_script = APPS_FS_INCLUDE_DIR . 'apps_rebuild.php';
		if((file_exists($cms_apps_bld_script)) && (is_readable($cms_apps_bld_script))) {
			include_once($cms_apps_bld_script);
			} // if
		if(!self::do_std_app_warnings(true)) return false;
		return true;
		} // do_apps_rebuild()

	public static function get_ini_apps_input_ctl($ini_key) {
		if(!self::$cms_apps_ini_ctls) {
			self::$cms_apps_ini_ctls = array();
			$body_defines = self::get_bodies_defines();
			foreach($body_defines as $cms_body_id => &$body) {
				$class = self::get_app_primary_class($body);
				if(!$class) continue;
				if(method_exists($class,'get_ini_app_input_ctl')) {
					$ini_ctl = $class::get_ini_app_input_ctl();
					if(!empty($ini_ctl)) {
						// $cms_app_key = &$body['app_key'];
						foreach($ini_ctl as $k => &$v) {
							$v['class'] = $class;
							//self::$cms_apps_ini_ctls[$cms_app_key . $k] = $v;
							self::$cms_apps_ini_ctls[$k] = $v;
							} // foreach
						} // if
					} // if
				} // foreach
			} // if
		if(empty($ini_key)) return self::$cms_apps_ini_ctls;
		if(isset(self::$cms_apps_ini_ctls[$ini_key]))
			return self::$cms_apps_ini_ctls[$ini_key];
		return false;	// not found
		} // get_ini_apps_input_ctl()

	public static function convert_ini_apps_form_input(&$ini_ary) {
		// get any images
//		$conf = Ccms_apps::read_apps_ini_settings();
//		$ini_cntl = self::read_apps_ini_comments();	// get control file
//		$settings_default = self::read_apps_ini_defaults();

		foreach($ini_ary as $sect_name => &$s2c) {
			foreach($s2c as $k => &$v) {
				$val = $v;
				if($c = self::get_ini_apps_input_ctl($k)) {
					switch($c['type']) {
					case 'multi_select':
						$v = Ccms_options::multi_row_get_form_elems($k,$v,'',$c['val_sep']);
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					case 'multi_input':
						$val = self::serialize_array2string($v, $c['val_sep'], $c['data_sep']);
						break;
					default:
						break;
						} // switch
					} // if
				else if(is_array($v)) {
					if(in_array('',$v)) $val = '';	// use default
					else $val = implode(' ',$v);
					} // if
				$s2c[$k] = $val;	// ?? stripslashes($val);
				} // foreach
			} // foreach

		$cCMS_C = new Ccms_config_funcs();
		$conf = Ccms_apps::read_apps_ini_settings();
		$ini_cntl = self::read_apps_ini_comments();	// get control file
		// $default = self::read_apps_ini_defaults();
		foreach($ini_cntl as $sect_name => &$section) {	// fill missing section
			if(preg_match('/^_/i',$sect_name)) continue;
			// if(!isset($ini_ary[$sect_name])) $ini_ary[$sect_name] = [];
			foreach($section as $k => &$v) {
				if(preg_match('/^_|^comment/i',$k)) continue;
				if(!isset($ini_ary[$sect_name][$k])) {	// check for missing images
					if(preg_match('/BKGD_IMAGE$/',$k)) {
						$ini_ary[$sect_name][$k] = $cCMS_C->get_image($k, '', ETC_FS_BACKGROUNDS_DIR);
						} // if
					else if(preg_match('/_IMAGE$/',$k)) {
						$ini_ary[$sect_name][$k] = $cCMS_C->get_image($k, '', ETC_FS_IMAGES_DIR);
						} // if
					// else leave rest to goto defaults on save
					} // if
				} // foreach
			} // foreach
		return $ini_ary;
		} // convert_ini_apps_form_input()

	public static function get_apps_admin_extensions(&$config_menu,$column = false,$style = false) {		// build a submenu for each app from
		$cnt = 0;
		if(!is_array($config_menu)) $config_menu = array();
		if(empty($config_menu['app_sub_names'])) $config_menu['app_sub_names'] = array();
		$cms_app_admin_uris = self::get_all_plugins_static_func_text('get_admin_uris');
		if((is_null($cms_app_admin_uris)) || (empty($cms_app_admin_uris)) || (!is_array($cms_app_admin_uris))) return false;

		foreach($cms_app_admin_uris as $cms_app_name => $cms_app_items) {
			$inline = (Ccms::show_nav_bar() ? true:false);
			if(!isset($cms_app_items[1])) $inline = true;
			// $cms_app_name = (!empty($cms_app_items['app_name']) ? $cms_app_items['app_name']:'apps');
			$cms_app_dir = (!empty($cms_app_items['app_dir']) ? $cms_app_items['app_dir']:self::lookup_body_dir($cms_app_name));
			$cms_app_uri = (!empty($cms_app_items['app_uri']) ? $cms_app_items['app_uri']:self::lookup_body_url($cms_app_name));
			$cms_body_name = (!empty($cms_app_items['name']) ? $cms_app_items['name']:$cms_app_name);
			$config_menu['app_sub_names'][] = self::format_app_name($cms_app_name);
			$cms_app_menu = array(
				'th' => array(
					'text' => $cms_body_name,
					'title' => 'App: ' . $cms_body_name . ' configs',
					),
				'td' => array(),
				);

			foreach($cms_app_items as $x => $item) {
				if(!is_numeric($x)) continue;
				if((empty($item['uri'])) && (empty($item['func']))) continue;	// ?? no where to go
				$td = array(
					'text' => $item['text'],
					'title' => ($inline ? $cms_body_name . ' - ':'') . $item['title'],
					);

				if(empty($item['uri'])) $td['uri'] = 'index.php?cms_action=admin_extend&app_name=' . urlencode($cms_app_name) . '&idx=' . ($item['idx'] + 1);
				else $td['uri'] = $item['uri'];

				if($inline) $config_menu['td'][] = $td; // put in direct
				else $cms_app_menu['td'][] = $td;	// else put up a sub menu

				$cnt++;
				} // foreach

			if(!$inline) {
				$inner_style = ' style="';
				$col_pos = preg_replace('/^.*(none|left|right|navbar|header).*$/','$1',$column);
				switch($col_pos) {
				case 'none':
					break;
				case 'left':
					$inner_style .= 'left: 30px;';
					break;
				case 'right':
					$inner_style .= 'right: 30px;';
					break;
				case 'navbar':
					break;
				case 'header':
					$inner_style .= 'left: 30px;';
					break;
				default:
					if(self::$cms_menus_in_header) $inner_style .= 'left: 30px;';
					else if(self::$cms_right_column) $inner_style .= 'right: 30px;';
					else if(self::$cms_left_column) $inner_style .= 'left: 30px;';
					break;
					} // switch
				if(!empty($style)) $inner_style .= ' ' . $style;
				$inner_style .= '"';
				$vm = new Ccms_generate_Vmenu('apmenu_' . $cms_app_name,'admin_pdb_container',$cms_app_menu,true,true,20, 'Application extension menu');
				$atext = $vm->get_text();
				$params = array(	// make $text_inner variable array
					'text_inner' => &$atext,
					'outer_class' => (!$inline ? 'cms_sub_hover_block_outer':'cms_hover_block_outer'),	// 'admin_pdb_container'),
					'inner_class' => (!$inline ? 'cms_sub_hover_block_inner':'cms_hover_block_inner'),
					//'outer_params' => '',
					'inner_params' => $inner_style,
					//'table_class' => '',
					);
				$text = Ccms_drop_box::hover_block($cms_body_name,$params);
				$config_menu['td'][] = array(
					'text' => $text,
					'title' => '',
					'uri' => '',
					);
				} // if
			} // foreach
		return $cnt;
		} // get_apps_admin_extensions()

	public static function get_apps_menus_submenus(&$body_menu,$column = false,$style = false) {		// build a submenu for each app from
		$cnt = 0;
		if(!is_array($body_menu)) $body_menu = array();
		if(empty($body_menu['app_sub_names'])) $body_menu['app_sub_names'] = array();
		$cms_app_menu_uris = Ccms::get_all_plugins_static_func_text('get_menu_uris');
		if((is_null($cms_app_menu_uris)) || (empty($cms_app_menu_uris)) || (!is_array($cms_app_menu_uris))) {	// no submenus
			return $cnt;
			} // if
		foreach($cms_app_menu_uris as $cms_app_name => $cms_app_items) {
			$inline = (Ccms::show_nav_bar() ? true:false);
			if(!isset($cms_app_items[1])) $inline = true;
			// $cms_app_name = (!empty($cms_app_items['app_name']) ? $cms_app_items['app_name']:'apps');
			$cms_app_dir = (!empty($cms_app_items['app_dir']) ? $cms_app_items['app_dir']:self::lookup_body_dir($cms_app_name));
			$cms_app_uri = (!empty($cms_app_items['app_uri']) ? $cms_app_items['app_uri']:self::lookup_body_url($cms_app_name));
			$cms_body_name = (!empty($cms_app_items['name']) ? $cms_app_items['name']:$cms_app_name);
			$used = false;
			if(empty($cms_body_name)) $cms_body_name = 'Apps';
			$body_menu['app_sub_names'][] = self::format_app_name($cms_app_name);
			if(!$inline ) {
				$cms_app_menu = array(
					'th' => array(
						'uri' => (!empty($cms_app_items['app_uri']) ? $cms_app_items['app_uri']:false),
						'title' => (!empty($cms_app_items['title']) ? $cms_app_items['title']:false),
						'text' => $cms_body_name,
						),
					'td' => array(),
					);
				} // if

			foreach($cms_app_items as $x => $item) {
				if(!is_numeric($x)) continue;
				if((empty($item['uri'])) && (empty($item['func']))) continue;	// ?? no where to go
				$td = array(
					'text' => $item['text'],
					'title' => ($inline ? $cms_body_name . ' - ':'') . $item['title'],
					);
				if(empty($item['uri'])) $td['uri'] = 'index.php?action=body_extend&app_name=' . $cms_app_name . '&idx=' . ($i + 1);
				else $td['uri'] = $item['uri'];

				if($inline) $body_menu['td'][] = $td; // put in direct
				else $cms_app_menu['td'][] = $td;	// else put up a sub menu
				} // for

			if(!$inline) {
				$inner_style = ' style="';
				$col_pos = preg_replace('/^.*(none|left|right|navbar|header).*$/','$1',$column);
				switch($col_pos) {
				case 'none':
					break;
				case 'left':
					$inner_style .= 'left: 30px;';
					break;
				case 'right':
					$inner_style .= 'right: 30px;';
					break;
				case 'navbar':
					break;
				case 'header':
					$inner_style .= 'left: 30px;';
					break;
				default:
					if(self::$cms_menus_in_header) $inner_style .= 'left: 30px;';
					else if(self::$cms_right_column) $inner_style .= 'right: 30px;';
					else if(self::$cms_left_column) $inner_style .= 'left: 30px;';
					break;
					} // switch
				if(!empty($style)) $inner_style .= ' ' . $style;
				$inner_style .= '"';
				$vm = new Ccms_generate_Vmenu('apmenu_' . $cms_app_name,'bodies_pdb_container',$cms_app_menu,true,true,20,'Apps submenu');
				$atext = $vm->get_text();;
				$params = array(	// make $text_inner variable array
					'text_inner' => &$atext,
					'outer_class' => (!$inline ? 'cms_sub_hover_block_outer':'cms_hover_block_outer'),
					'inner_class' => (!$inline ? 'cms_sub_hover_block_inner':'cms_hover_block_inner'),
					//'outer_params' => '',
					'inner_params' => $inner_style,
					//'table_class' => '',
					);
				$text = Ccms_drop_box::hover_block($cms_body_name,$params);
				$body_menu['td'][] = array(
					'text' => $text,
					'title' => '',
					'uri' => '',
					);
				} // if
			$cnt++;
			} // foreach
		return $cnt;
		} // get_apps_menus_submenus()

	public static function get_apps_menus($position,$body_items = false,$plain_menu = true,$menu_name = 'Applications menu') {

		if(empty($body_items)) $body_items = Ccms_options::get_bodies_menu_items();

		$body_menu = array(
			'th' => array(
				'text' => (Ccms::show_nav_bar() ? 'Apps:':'Main Menu:'),
				'title' => 'Apps. Click to select.',
				),
			'td' => array(),
			);
		// add apps menus
		foreach($body_items as &$item) {	// do sub menus first so can filter
			if((isset($item['allowed_now'])) && (!$item['allowed_now'])) continue;
			if(empty($item['func'])) continue;
			// submenus
			$func = $item['func'];
			if(self::is_static_callable($func)) {
				$func($body_menu,$position);
				} // if
			} // foreach

		// $debug = print_r($body_menu,true);	// debug var 1000000
		foreach($body_items as &$item) {
			if((isset($item['allowed_now'])) && (!$item['allowed_now'])) continue;
			if(!empty($item['func'])) continue;
			if((!empty($item['app_name'])) &&
				(!empty($body_menu['app_sub_names'])) &&
				(in_array($item['app_name'],$body_menu['app_sub_names'])))
				continue;
			$body_menu['td'][] = array(
				'uri' => (!empty($item['uri']['uri']) ? $item['uri']['uri']:$item['uri']),
				'title' => (!empty($item['title']) ? $item['title']:''),
				'text' => (!empty($item['uri']['text']) ? $item['uri']['text']:
					(!empty($item['text']) ? $item['text']:(!empty($item['name']) ? $item['name']:'(Unknown item)'))),
				);
			} // foreach

		if((!$plain_menu) && (Ccms_base::is_tiny())) {
			$text = Ccms::get_header_tools_pdb_text(false);
			if(!empty($text)) {
				$body_menu['td'][] = array(
					'uri' => '',
					'title' => "",
					'text' => $text,
					);
				} // if
			} //if
		if(empty($body_menu['td'][0])) return '';

		// $debug = print_r($body_menu,true);	// debug var 1000000
		$vm = new Ccms_generate_Vmenu('bmenu_' . $position,'bodies_pdb_container',$body_menu,true,true,20,$menu_name);
		return $vm->get_text();
		} // get_apps_menus()

	public static function get_app_extend_body($cms_app_name) {
		// each app extend plugin
		if(empty($cms_app_name)) return false;
		$body_defines = &self::get_bodies_defines();
		$cnt = 0;
		foreach($body_defines as $id => &$body) {
			if($cms_app_name == $body['app_name']) return $body;
			$cnt++;
			} // foreach
		return false;
		} // get_app_extend_body()

	private static function chk_extend_uri(&$pl_uris,$cms_app_name,$idx) {
		if(!empty($pl_uris[$cms_app_name][($idx - 1)])) {
			$uri = $pl_uris[$cms_app_name][($idx - 1)];
			if(!empty($uri['func'])) unset($uri['uri']);
			else if(empty($uri['uri'])) return false;
			return $uri;
			} // if
		return false;
		} // chk_extend_uri()

	public static function get_admin_extend_uri($cms_app_name,$idx,$args = array()) {
		// each app extend plugin
		if((empty($cms_app_name)) || (empty($idx))) return false;
		$pl_uris = self::get_all_plugins_static_func_text('get_admin_uris',$args,$cms_app_name);
		return self::chk_extend_uri($pl_uris,$cms_app_name,$idx);
		} // get_admin_extend_uri()

	public static function get_body_extend_uri($cms_app_name,$idx,$args = array()) {
		// each app extend plugin
		if((empty($cms_app_name)) || (empty($idx))) return false;
		$pl_uris = self::get_all_plugins_static_func_text('get_menu_uris',$args,$cms_app_name);
		return self::chk_extend_uri($pl_uris,$cms_app_name,$idx);
		} // get_body_extend_uri()

	public static function get_sub_apps_ids($cms_body_id,$cms_body_dir) {	// including the primary app id
		// note app may not a dir
		$ids = [];
		if((int)$cms_body_id <= 0) return $ids;
		$ids[] = $cms_body_id;
		if(!empty($cms_body_dir)) {
			// $ids[] = $cms_body_id;
			$sql_sub_query = "SELECT cms_body_id FROM cms_bodies WHERE cms_body_dir LIKE '" . $cms_body_dir . "%'";
			if($result = self::$cDBcms->query($sql_sub_query)) {
				while($body = self::$cDBcms->fetch_array($result)) {
					$id = $body['cms_body_id'];
					if(!in_array($id,$ids)) $ids[] = $id;
					} // while
				} //if
			} // if
		return $ids;
		} // get_sub_apps_ids()

	public static function upd_sub_apps_dirs($old_body_dir,$new_body_dir) {
		if((empty($old_body_dir)) || (empty($new_body_dir))) return false;
		if($old_body_dir == $new_body_dir) return true;
		$ok = true;
		$sql_sub_query = "SELECT cms_body_id,cms_body_dir FROM cms_bodies WHERE cms_body_dir LIKE '" . $old_body_dir . "%'";
		if($result = self::$cDBcms->query($sql_sub_query)) {
			while($body = self::$cDBcms->fetch_array($result)) {
				$id = $body['cms_body_id'];
				$old = $body['cms_body_dir'];
				$new = str_replace($old_body_dir,$new_body_dir,$old);
				if(!self::$cDBcms->set_data_in_table('cms_bodies','cms_body_dir',$new,'cms_body_id = ' . $id)) {
					self::addAdminMsg('Failed to update dir from: ' . $old . ', to: ' . $new);
					$ok = false;
					} // if
				} // while
			} //if
		return $ok;
		} // upd_sub_apps_dirs()

	public static function get_sub_apps_names_text($name,$cms_body_dir) {
		if(empty($cms_body_dir)) return '';
		$text = '';
		$sql_sub_query = "SELECT cms_body_dir,cms_body_name FROM cms_bodies WHERE cms_body_dir LIKE '" . $cms_body_dir . "%'";
		if($result = self::$cDBcms->query($sql_sub_query)) {
			while($body = self::$cDBcms->fetch_array($result)) {
				if($body['cms_body_dir'] == $cms_body_dir) continue;
				if(!empty($text)) $text .= ', ';
				$text .= '&quot;' . $body['cms_body_name'] . '&quot;';
				} // while
			} //if
		if(empty($text)) return '';
		return '<br>' . '<b>Note:</b> Application: &quot;' . $name . '&quot; also contains: ' . $text . ' sub-applications.' . '<br><br>' . PHP_EOL;;
		} // get_sub_apps_names_text()

	// dynamic methods
	protected function init() {
		// if(self::is_rebuild()) return;
		Ccms_sm::get_bodies_defines();
		self::get_apps_settings();
		} // init()

} // Ccms_apps
