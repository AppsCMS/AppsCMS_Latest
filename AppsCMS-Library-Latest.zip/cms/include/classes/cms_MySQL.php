<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_MySQL.php 2985 2022-11-14 03:22:23Z robert0609 $
 */

/**
 * Description
 * cms_mysql functions wrapper and easy access class
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_database_mysql.php');

class Ccms_MySQL extends Ccms_database_mysql {

	protected static $cmsDBinstallDone = false;
	public static $cmsDBreconstructDone = false;

	function __construct($create = false,$admin_user = '',$admin_passwd = '') {

		// use AppsCMS INI settimgs
		$db_inuse = ((Ccms_base::get_cms_ini_value('DB_MYSQL_USE_BOOL','DataBaseAccess') != 'true') ? false:true);
		if((!$db_inuse) && (!$create)) return;	// not used
		$db_user = Ccms_base::get_cms_ini_value('DB_MYSQL_USERNAME','DataBaseAccess');
		$db_passwd = Ccms_base::get_cms_ini_value('DB_MYSQL_PASSWORD','DataBaseAccess');
		$db_name = Ccms_base::get_cms_ini_value('DB_MYSQL_DATABASE','DataBaseAccess');	// . (self::is_debug() ? '_TEST':'');
		$db_host = Ccms_base::get_cms_ini_value('DB_MYSQL_HOST_URL','DataBaseAccess');
		$db_port = Ccms_base::get_cms_ini_value('DB_MYSQL_HOST_PORT','DataBaseAccess');
		if((empty($db_user)) && (empty($db_passwd)) && (empty($db_name))) return;	// doing a separate open

		if($create) {
			if((empty($admin_user)) || (empty($admin_passwd))) {
				self::addMsg('Missing ' . CMS_PROJECT_SHORTNAME . ' admin user or admin password for "' . $db_host . '".');
				return;
				} // if
			if(!Ccms_database_mysql::install_user_privileges_database($admin_user,$admin_passwd,
					$db_user,$db_passwd,$db_host,$db_name)) {
				self::addMsg('Failed to create ' . CMS_PROJECT_SHORTNAME . ' MySQL database and user on "' . $db_host . '".');
				return;
				} // if
			} // if
		if(!$db_inuse) return;

		$db_timeout = 10000;
		parent::__construct($db_user, $db_passwd, $db_name, $db_host, $db_port, $db_timeout);
		if($create) {
			$this->m_bNew = true;
			$this->init(true);
			} // if
		} // __construct()

	function __destruct() {
		$this->save_reconstruct_DB_data();
		parent::__destruct();
		} // __destruct()

	// methods
	public function init($install_tables) {
		if(!$this->is_ok()) return false;
		if(($this->m_bNew) || ($install_tables === true)) {
			if(!$this->installDatabase()) {
				die('ERROR: Failed to install MySQL DB tables.');
				return false;
				} // if
			} // if
		$this->m_bNew = false;
		return true;
		} // init()

	public function save_reconstruct_DB_data($always = false) {
		if((defined('CMS_S_DB_SQLITE_JSON_MIRROR_BOOL')) &&
			(CMS_S_DB_SQLITE_JSON_MIRROR_BOOL) &&
			(!self::$cmsDBreconstructDone) &&
			(($this->db_chgd) || ($always)) &&
			(Ccms_auth::is_cms_admin_user()) &&
			(!self::is_ajax())) {
			self::$cmsDBreconstructDone = true;	// dont repeat
			$install_scripts = Ccms_DB_install::get_installDBscriptsSQLite();
			$json_file = ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE . '.json';
			return $this->export_db2json($install_scripts,$json_file);
			} // if
		return false;
		} // save_reconstruct_DB_data()

	public function installDatabase($table = '', $verbose = false, $drop = false) {
		if(empty($table)) {	// full install (rebuild)
			if(self::$cmsDBinstallDone) return true;	// done
			self::$cmsDBinstallDone = true;	// only once
			} // if

		$install_scripts = Ccms_DB_install::get_installDBscriptsMySQL();

		$res = $this->install_db_tables($table,$install_scripts,true,$drop);
		if((!self::$cmsDBreconstructDone) && ($res) &&
			(Ccms_base::get_cms_ini_value('DB_SQLITE_JSON_MIRROR_BOOL','DataBaseAccess'))) {
			self::$cmsDBreconstructDone = true;	// dont repeat
			if(($this->m_bNew) ||
				((defined('USE_JSON_REBUILD')) && (USE_JSON_REBUILD))) {
				$json_file = ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE . '.json';
				$this->import_json2db($install_scripts,$json_file,$drop,$verbose);
				} // i
			} // if
		if(($res) &&
			(($table == 'cms_configs') || (empty($table)))) {
			$cms_plugins = Ccms::get_cms_config_value('CMS_C_ENABLED_PLUGINS');
			Ccms::do_plugin_installs($cms_plugins);
			} // if
		$this->db_chgd = true;
		return $res;
		} // installDatabase()


} // Ccms_MySQL
