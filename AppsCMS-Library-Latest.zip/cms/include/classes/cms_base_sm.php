<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_base_sm.php 3366 2023-07-20 07:23:55Z robert0609 $
 */

/**
 * Description of cms_base_sm state machine base class
 * Used to hold variable from Ccmc_sm (state machine) class
 *
 * @author robert0609
 */

require_once 'cms_base_sm_gs.php';	// speed up for proxy (no autoloader needed)

class Ccms_base_sm extends Ccms_base_sm_gs {
	
	protected static $cms_tidy_buffer = false;

	protected static $cms_client_ip = false;
	protected static $cms_session_id = false;
	protected static $cms_visitor_cnt = false;
	protected static $cms_site_data = false;
	protected static $cms_client_headers = false;
	protected static $cms_access_logged = false;	// only do once
	protected static $cms_browsercap_done = false;	// only do once
	protected static $cms_head_output_flg = false;
	protected static $cms_tools_on_navbar = false;
	protected static $cms_tools = false;
	protected static $cms_tools_cnt = false;

	protected static $cms_nav_bar = null;	// only do once

	protected static $cms_nav_bar_grid_sanitised = false;	// only do once
	protected static $cms_nav_bar_grid_sanitised_cnt = false;	// only do once
	
	protected static $cms_nav_bar_grid_sanitised_privileged = false;	// only do once
	protected static $cms_nav_bar_grid_sanitised_privileged_cnt = false;	// only do once
	
	protected static $cms_nav_bar_grid = false;	// only do once
	protected static $cms_nav_bar_grid_cnt = false;	// only do once

	protected static $cms_nav_bar_grid_menu_only = false;	// only do once
	protected static $cms_nav_bar_grid_menu_only_cnt = false;	// only do once

	protected static $cms_bodies = false;	// only do once
	protected static $cms_bodies_cnt = false;	// only do once
	protected static $cms_session_timeout = false;
	protected static $cms_session_no_write = false;	// used to stop foreign session decodes being re/saved
	protected static $cms_refd_false = false;	// DO NOT CHANGE, used as reference return &false
	protected static $cms_header_admin_sent = false;
	protected static $cms_header_tools_sent = false;
	protected static $cms_header_menu_sent = false;
	protected static $cms_left_column = null;	// time saver
	protected static $cms_right_column = null;	// time saver
	protected static $cms_menu_admin_in_header = null;	// time saver
	protected static $cms_menu_apps_in_header = null;	// time saver
	protected static $cms_menu_tools_in_header = null;	// time saver
	protected static $cms_menus_in_header = null;	// time saver
	protected static $cms_password_resource_done = false;	// stop multiple generates.

	public static $cms_browsercap_result = null;

	public static $cms_tool_id = false;
	public static $cms_tool_name = false;
	public static $cms_tool_version = false;

	public static $lm_link_id = false;
	public static $lm_link_name = false;

	public static $cms_body_id = false;
	public static $cms_body_dir = false;
	public static $cms_body_name = false;
	public static $cms_body_title = false;
	public static $cms_body_app_key = false;
	public static $cms_body_virtual_name = false;
	public static $cms_body_lang = false;
	public static $cms_body_version = false;
	public static $cms_body_iframe_view = false;
	public static $cms_body_full_view = false;

	public static $cms_body_default_msgs = true;
	public static $cms_plugin = false;
	public static $cms_app = false;

	
	// see tech manual
	public static $cms_docroot = false;
	public static $cms_app_dir = false;
	public static $cms_app_name = 'base';
	public static $cms_app_key = false;
	public static $cms_app_type = false;
	public static $cms_httpd_version = false;	// from apache_get_version(); e.g.Apache/1.3.29 (Unix) PHP/4.3.4

	protected static $cms_prevErrorHandler = false;
	protected static $cms_error_cnt = 0;		// global error cnt

	protected static $cms_page_start_time = 0;
	protected static $cms_page_end_time = 0;

	private static $sm_body_defines = false;	// use ::get_bodies_defines() to access
	private static $sm_all_plugins = null;
	private static $sm_apache_vhosts = null;

	const PRE_DEF_APPs_WS_DIR = "APPs_WS_";
	const PRE_DEF_APPs_FS_DIR = "APPs_FS_";

	function __construct() {
		parent::__construct();
		if((!self::$cms_client_headers) && (!self::is_cli()) &&
			(function_exists('apache_request_headers')) &&
			($cms_client_headers = @apache_request_headers())) {
			self::$cms_client_headers = array();
			foreach($cms_client_headers as $k => &$v) {
				$t = explode(';',$v);
				self::$cms_client_headers[$k] = array(
					'type' => trim($t[0]),
					'params' => (empty($t[1]) ? null:trim($t[1])),
					);
				} // foreach
			} // if
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function get_session_timeout() {
		return self::$cms_session_timeout;
		} // get_session_timeout()

	public static function get_body_lang_trans_code() {
		return self::$cms_body_lang;
		} // get_body_lang_trans_code()
		
	private static function chk_http_port($set_port,$def_port) {
		if((empty($set_port)) || ((int)$set_port < 10) || (strlen($set_port) < 2)) return '';	// use default
		if((int)$set_port == (int)$def_port) return '';	// same, use default
		$port = ':' . $set_port;
		return $port;
		} // chk_http_port()
		
	protected static function get_vhosts_urls() {
		if(self::$sm_apache_vhosts) return self::$sm_apache_vhosts;
		if(((defined('CLI_MODE')) && (CLI_MODE)) ||
			(!isset($_SERVER))) { // running in CLI
			global $_SERVER;
			$_SERVER = array(	// spoof global
				'HTTP_USER_AGENT' => 'cli',
				);
			define("CMS_WWW_HOST",			'http://' . CMS_DOMAIN . '/');
			define("CMS_SSL_HOST",			'https://' . CMS_DOMAIN . '/');
			define("CMS_WWW_URL",			CMS_WWW_HOST . CMS_URI_ALIAS);
			define("CMS_SSL_URL",			CMS_SSL_HOST . CMS_URI_ALIAS);
			self::$sm_apache_vhosts = true;
			} // if
		else {	// assume it is a web server
			// use port settings if not default
			$port = CMS_S_SVR_WWW_PORT;
			define("CMS_WWW_HOST",			'http://' . CMS_DOMAIN . self::chk_http_port(CMS_S_SVR_WWW_PORT,80) . '/');
			define("CMS_SSL_HOST",			'https://' . CMS_DOMAIN . self::chk_http_port(CMS_S_SVR_SSL_PORT,443) . '/');
			define("CMS_WWW_URL",			CMS_WWW_HOST . CMS_URI_ALIAS);
			define("CMS_SSL_URL",			CMS_SSL_HOST . CMS_URI_ALIAS);
			self::$sm_apache_vhosts = true;
			} // else
		return self::$sm_apache_vhosts;
		} // get_vhosts_urls()

	protected static function ipCIDRCheck($IP, $CIDR) { // from "http://php.net/manual/en/ref.network.php" after the maths was sorted
		$nips = explode('/',$CIDR);
		if(count(explode('.',$IP)) < 4) return false;
		$net = $nips[0];
		if(!isset($nips[1])) $ip_mask = -1;
		else $ip_mask = ~((1 << (32 - $nips[1])) - 1);
		$ip_net = ip2long ($net);
		$ip_ip = ip2long ($IP);
		if(($ip_ip == 0) && ($ip_net == 0)) return false;
		$ip_ip_net = $ip_ip & $ip_mask;
		return ($ip_ip_net == $ip_net);
		} // ipCIDRCheck()

	protected static function is_intranet($domain) {
		// see "https://en.wikipedia.org/wiki/Private_network"
		static $int_ip_ranges = false;
		if(!$int_ip_ranges) {
			$int_ip_ranges = array(
				array('hi' => ip2long('10.255.255.255'), 'lo' => ip2long('10.0.0.0')),
				array('hi' => ip2long('192.168.255.255'), 'lo' => ip2long('192.168.0.0')),
				array('hi' => ip2long('172.31.255.255'), 'lo' => ip2long('172.16.0.0')),
				);
			} // if
		$hosts = gethostbynamel($domain);
		if(empty($hosts)) return false;
		$found = false;
		foreach($hosts as $host) {
			$h_ipl = ip2long($host);
			foreach($int_ip_ranges as $ip_r) {
				if(($h_ipl > $ip_r['lo']) && ($h_ipl < $ip_r['hi'])) {
					$found = true;
					break;
					} // if
				} // foreach
			if($found) break;
			} // foreach
		return $found;
		} // is_intranet()

	protected static function is_internet($domain) {
		$hosts = gethostbynamel($domain);
		if(empty($hosts)) return false;
		return !self::is_intranet($domain);
		} // is_internet()

	public static function get_base_url($req_ssl_chk = false) {

		if(!$req_ssl_chk) return (self::is_ssl_inuse() ? CMS_SSL_URL:CMS_WWW_URL);
		return (self::is_ssl_inuse() || self::is_ssl_required()) ? CMS_SSL_URL:CMS_WWW_URL;
		} // get_base_url()
		
	public static function lookup_body($cms_app_key_name_dir, $dis_assoc = false) {
		$body = array_filter(self::get_bodies_defines(),
			function($a) use ($cms_app_key_name_dir) {
				// find this app
				if($a['app_name'] == $cms_app_key_name_dir) return true;
				if(self::format_app_name($a['app_name']) == $cms_app_key_name_dir) return true;
				if($a['cms_body_name'] == $cms_app_key_name_dir) return true;
				if($a['app_key'] == $cms_app_key_name_dir) return true;
				if(self::format_app_name($a['cms_body_name']) == $cms_app_key_name_dir) return true;
				if($a['cms_body_dir'] == $cms_app_key_name_dir) return true;
				if($a['cms_body_virtual_name'] == $cms_app_key_name_dir) return true;
				return false;
				}
			);
		if(empty($body)) return false;
		$k = @array_key_first($body);
		if(!empty($k)) return $body[$k];
		return $body;
		} // lookup_body()

	public static function lookup_body_url($cms_app_name_or_body) {
		if(!is_array($cms_app_name_or_body))
			$body = self::lookup_body($cms_app_name_or_body);
		else {
			if(isset($cms_app_name_or_body['cms_body_virtual_name'])) {
				$url = $cms_app_name_or_body['cms_body_virtual_name'];
				return $url;
				} // if
			else if(isset($cms_app_name_or_body['cms_body_id'])) {
				$url = 'index.php?app=' . (int)$cms_app_name_or_body['cms_body_id'];
				return $url;
				} // if
			$body = $cms_app_name_or_body;
			} // else

		$uri = Ccms_sm::get_body_uri($body);
		return $uri;
		} // lookup_body_url()

	public static function lookup_body_dir($cms_app_name_or_body) {
		if(!is_array($cms_app_name_or_body))
			$body = self::lookup_body($cms_app_name_or_body);
		else {
			if(isset($cms_app_name_or_body['app_dir'])) {
				$dir = $cms_app_name_or_body['app_dir'];
				return $dir;
				} // if
			else if(isset($cms_app_name_or_body['cms_body_dir'])) {
				$dir = $cms_app_name_or_body['cms_body_dir'];
				return $dir;
				} // else if
			$body = $cms_app_name_or_body;
			} // else
		$dir = Ccms_sm::get_body_dir($body);
		return $dir;
		} // lookup_body_dir()

	public static function format_app_key($cms_key_name_uf,$suffix = false) {
		// if(!empty($cms_key_name_uf)) return $cms_key_name_uf;	// test
		$cms_app_key = strtoupper(preg_replace('/[^\w]|-/', '_', $cms_key_name_uf)) . (!empty($suffix) ? $suffix:'');
		return $cms_app_key;
		} // format_app_key()

	public static function get_app_key(&$body,$suffix = false) {
		if(!empty($body['cms_body_app_key'])) {
			$cms_app_key = self::format_app_key($body['cms_body_app_key'],$suffix);
			return $cms_app_key;
			} // if
		// try dir
		if(empty($body['cms_body_dir'])) return false;
		$cms_app_key = self::format_app_key($body['cms_body_dir'],$suffix);
		return $cms_app_key;
		} // get_app_key()

	public static function format_app_name($cms_app_name_uf) {
		// if(!empty($cms_app_name_uf)) return $cms_app_name_uf;	// test
		$cms_app_name = preg_replace('/[^0-9a-zA-Z]+/','_',strtolower($cms_app_name_uf));
		return $cms_app_name;
		} // format_app_name()

	public static function get_app_name(&$body) {
		if(!empty($body['cms_body_name'])) {
			return self::format_app_name($body['cms_body_name']);
			} // if
		if(!empty($body['cms_body_dir'])) {;
			return self::format_app_name($body['cms_body_dir']);
			} // if
		return false;
		} // get_app_name()

	public static function format_app_dir($cms_app_dir_uf,$def_ext = false) {
		// if(!empty($cms_app_dir_uf)) return $cms_app_dir_uf;	// test
		$cms_dir = preg_replace('/[^0-9a-z\/\.]+/i','_',$cms_app_dir_uf);
		// $cms_dir = preg_replace('/^[^0-9a-z\/]+/i','',$cms_dir);
		if((!empty($cms_dir)) && (!empty($def_ext))) {	// must have an extension
			$ext = pathinfo($cms_dir,PATHINFO_EXTENSION);
			if(empty($ext))
				$cms_dir .= '.' . $def_ext;
			} // if
		return $cms_dir;
		} // format_app_dir()

	protected static function get_app_dir(&$body) {
		if(!empty($body['cms_body_dir'])) {
			return self::format_app_dir($body['cms_body_dir']);
			} // if
		return false;
		} // get_app_dir()

	public static function format_virtual_name($cms_app_name_uf) {
		// if(!empty($cms_body_app_key)) return $cms_body_app_key;	// test
		$cms_virt_name = strtolower(preg_replace('/[^\w]|-/', '_', $cms_app_name_uf));
		return $cms_virt_name;
		} // format_virtual_name()

	protected static function get_virtual_name(&$body) {
		if(!empty($body['cms_body_virtual_name'])) {
			return self::format_virtual_name($body['cms_body_virtual_name']);
			} // if
		return false;
		} // get_virtual_name()

	private static function define_body_const(&$app_constants_type,&$body,$fs_dir_const,$fs_dir,$ws_dir_const,$ws_dir) {
		if(!is_dir($fs_dir)) return false;	// dir not there
		if(!defined($fs_dir_const)) {
			define($fs_dir_const, $fs_dir);
			// $body[$fs_dir_const] = $fs_dir;
			$app_constants_type['fs'] = array('const' => $fs_dir_const, 'val' => $fs_dir);
			} // if
		if(!defined($ws_dir_const)) {
			define($ws_dir_const, $ws_dir);
			// $body[$ws_dir_const] = $ws_dir;
			$app_constants_type['ws'] = array('const' => $ws_dir_const,'val' => $ws_dir);
			} // if
		return true;
		} // define_body_const()
		
	private static function get_dir_def_constant($dir) {
		return preg_replace('/[^09-a-z]+/i','_',strtoupper($dir)) . '_DIR';
		} // get_dir_def_constant()

	private static function define_app_body_constants(&$body) {
		// define the standard FS and WS constants for the apps
		$cms_apps_types = Ccms_DB_checks::get_apps_types_configs();
		$body['app_name'] = self::get_app_name($body);

		if(!isset($body['cms_body_type'])) return false;	// not yet
		$cms_app_type = &$cms_apps_types[((int)$body['cms_body_type'] % count($cms_apps_types))];
		if(!isset($cms_app_type['app_dirs'])) return false;
		if(empty($body['cms_body_dir'])) return false;

		$app_constants = array(
			'apps' => array(
				'fs' => array('const' => 'APPS_FS_DIR', 'val' => APPS_FS_DIR),
				'ws' => array('const' => 'APPS_WS_DIR', 'val' => APPS_WS_DIR),
				),
			'dir' => array(),
			);
		$cms_app_fs_dir = APPS_FS_DIR . $body['cms_body_dir'] . '/';
		$cms_app_fs_dir_const = self::PRE_DEF_APPs_FS_DIR .  self::get_dir_def_constant($body['cms_body_dir']);

		$cms_app_ws_dir = APPS_WS_DIR . $body['cms_body_dir'] . '/';
		$cms_app_ws_dir_const = self::PRE_DEF_APPs_WS_DIR .  self::get_dir_def_constant($body['cms_body_dir']);

		self::define_body_const($app_constants['dir'],$body,$cms_app_fs_dir_const,$cms_app_fs_dir,$cms_app_ws_dir_const,$cms_app_ws_dir);

		if(!empty($cms_app_type['app_dirs'])) {
			foreach($cms_app_type['app_dirs'] as $d) {	// do defines

				$cms_app_fs_dir = APPS_FS_DIR . $body['cms_body_dir'] . '/' . $d . '/';
				$cms_app_fs_dir_const = self::PRE_DEF_APPs_FS_DIR .  self::get_dir_def_constant($body['cms_body_dir'] . '_' . $d);

				$cms_app_ws_dir = APPS_WS_DIR . $body['cms_body_dir'] . '/' . $d . '/';
				$cms_app_ws_dir_const = self::PRE_DEF_APPs_WS_DIR .  self::get_dir_def_constant($body['cms_body_dir'] . '_' . $d);

				$app_constants[$d] = array();
				self::define_body_const($app_constants[$d],$body,$cms_app_fs_dir_const,$cms_app_fs_dir,$cms_app_ws_dir_const,$cms_app_ws_dir);

				} // foreach

			if((!empty(self::$cms_body_id)) && (self::$cms_body_id == $body['cms_body_id'])) {
				$cms_app_config = APPS_FS_DIR . $body['cms_body_dir'] . '/include/' . 'app_config.php';
					if(file_exists($cms_app_config)) {
						try {	// don't kill the system because of coding error in one app
							include_once $cms_app_config;
							$body['app_config'] = $cms_app_config;
							} // try
						catch(Exception $e) {
							$err = $e->getMessage();
							self::addAdminMsg('Error in ' . $cms_app_config . ': ' . $err);
							// continue
							} // catch
						} // if

				$cms_app_css = APPS_FS_DIR . $body['cms_body_dir'] . '/css/' . 'app.css';
				if(file_exists($cms_app_css)) {
					// save web location
					$body['app_css'] = APPS_WS_DIR . $body['cms_body_dir'] . '/css/' . 'app.css';
					} // if

				$cms_app_head_inc = APPS_FS_DIR . $body['cms_body_dir'] . '/include/' . 'app_head_inc.php';
				if(file_exists($cms_app_head_inc)) {
					// save web location
					$body['app_head_inc'] = $cms_app_head_inc;
					} // if

				$cms_app_scss = APPS_FS_DIR . $body['cms_body_dir'] . '/css/' . 'app.scss';
				if(file_exists($cms_app_css)) {
					// save web location
					$body['app_scss'] = APPS_WS_DIR . $body['cms_body_dir'] . '/css/' . 'app.scss';
					} // if

				$cms_app_theme_css = ETC_WS_CSS_DIR . $body['app_name'] . '_app.css';
				if(file_exists($cms_app_theme_css)) {
					// save web location
					$body['app_theme_css'] = ETC_WS_CSS_DIR . $body['app_name'] . '_app.css';
					} // if

				$cms_app_js = APPS_FS_DIR . $body['cms_body_dir'] . '/js/' . 'app.js';
				if(file_exists($cms_app_js)) {
					// save web location
					$body['app_js'] = APPS_WS_DIR . $body['cms_body_dir'] . '/js/' . 'app.js';
					} // if
				} // if
			} // if
			
		$body['app_dir'] = (empty($body['cms_body_dir']) ? '':$body['cms_body_dir']);
		$body['app_key'] = self::get_app_key($body);

		return $app_constants;
		} // define_app_body_constants()

	protected static function get_body_plugins(&$body) {
		if(empty($body['cms_body_dir'])) return false;
		$pl_dir = APPS_FS_DIR . $body['cms_body_dir'] . '/plugins/';
		if(!is_dir($pl_dir)) return false;
		$files = scandir($pl_dir);
		$bdy_pls = array();
		foreach($files as $f) {
			if(!self::is_dir_usable($f)) continue;
			if((!self::is_debug()) && (preg_match('/^example/',$f))) continue;
			$pi = pathinfo($f);
			if(!isset($pi['extension'])) continue;
			if(strtolower($pi['extension']) != 'php') continue;
			$class = 'C' . $pi['filename'] . '_plugin';
			if($pl_path = Ccms_autoloader::find_plugin($class,$pl_dir)) {
				$bdy_pls[] = array(
					'name' => $body['cms_body_name'],
					'app_name' => $body['cms_body_app_key'],
					'class' => $class,
					'path' => $pl_path,);
				} // if
			} // foreach
		return $bdy_pls;
		} // get_body_plugins()

	public static function &get_bodies_defines() {	// to define APPs_
		if (self::$sm_body_defines === false) { // not set yet
			self::$sm_body_defines = array();
			$sql_query = "SELECT  " . (self::is_rebuild() ? '*':'cms_body_id,cms_body_enabled,cms_body_name,cms_body_app_key,cms_body_virtual_name,cms_body_lang,cms_body_type,cms_body_dir') .
				" FROM  cms_bodies" .
				//all bodies needed for defined	" WHERE cms_body_enabled > 0" .
				" ORDER BY  cms_body_order,cms_body_name,cms_body_id";
			if (($result = self::$cDBcms->query($sql_query)) &&
				(self::$cDBcms->num_rows($result) > 0)) {
				$row = 0;
				while ($body = self::$cDBcms->fetch_array($result)) {
					$body['constants'] = self::define_app_body_constants($body);
					if(!empty($body['cms_body_enabled'])) {
						$body['plugins'] = self::get_body_plugins($body);
						$body['app_virtual'] = self::get_virtual_name($body);
						$body['app_key'] = self::get_app_key($body);
						$body['app_name'] = self::get_app_name($body);
						$body['app_dir'] = $body['cms_body_dir'];
						self::$sm_body_defines[($body['cms_body_id'])] = $body;
						} // if
					} // while
				} //if
			self::$cDBcms->free_result($result);
			} // if
		return self::$sm_body_defines;
		} // get_bodies_defines()

	public static function &get_all_plugins() {
		if(is_null(self::$sm_all_plugins)) {
			self::$sm_all_plugins = array();	// once only
			$all_pls = &self::$sm_all_plugins;
			// get common area plugins
			$cmn_pls_dirs = array(CMS_FS_PLUGINS_DIR,APPS_FS_PLUGINS_DIR);
			foreach($cmn_pls_dirs as $pl_dir) {
				if(!is_dir($pl_dir)) continue;
				$files = scandir($pl_dir);
				foreach($files as $f) {
					if(!self::is_dir_usable($f)) continue;
					if((!self::is_debug()) && (preg_match('/^example/',$f))) continue;
					$pi = pathinfo($f);
					if(!isset($pi['extension'])) continue;
					if(strtolower($pi['extension']) != 'php') continue;
					$class = 'C' . $pi['filename'] . '_plugin';
					if($pl_path = Ccms_autoloader::find_plugin($class,$pl_dir)) {
						$all_pls[] = array('class' => $class,'path' => $pl_path,);
						} // if
					} // foreach
				} // foreach
			// add body/apps plugins
			$sm_body_defines = Ccms_sm::get_bodies_defines();
			foreach($sm_body_defines as $bid => &$body) {
				if(empty($body['plugins'])) continue;
				$all_pls = array_merge($all_pls,$body['plugins']);
				} // foreach
			} // if
		return self::$sm_all_plugins;
		} // get_all_plugins()

// @TODO change
	public static function get_plugins_function($meth_name, $cms_plugins = false) {
		if(preg_match('/[ !?@]+/',$meth_name)) return false;
		$sm_all_plugins = self::get_all_plugins();
		if(!is_array($cms_plugins)) $cms_plugins = array();
		foreach($sm_all_plugins as $cms_plugin) {
			$func = false;
			if(self::is_static_callable(array($cms_plugin['class'],$meth_name),false,$func)) {
				$cms_plugin['callable'] = $func;
				$cms_plugins[$meth_name][] = $cms_plugin;
				} // if
			} // foreach
		if(empty($cms_plugins)) return false;
		return $cms_plugins;
		} // get_plugins_function()

	public static function get_all_plugins_static_func_text($meth_name,$args = array(),$cms_app_name_only = false) {
		$cms_plugins = self::get_plugins_function($meth_name);
		if(empty($cms_plugins[$meth_name])) return false;
		$items = array();
		foreach($cms_plugins[$meth_name] as $cms_plugin) {
			if(empty($cms_plugin['callable'])) continue;
			$result = call_user_func_array($cms_plugin['callable'],$args);

			$cms_app_name = false;
			if(!empty($cms_plugin['name'])) $cms_app_name = $cms_plugin['name'];
			else if(!empty($result['name'])) $cms_app_name = $result['name'];
			else $cms_app_name = (!empty($result['app_name']) ? $result['app_name']:$cms_plugin['class']);
			if(!empty($cms_app_name_only)) {
				if($cms_app_name_only != $cms_app_name) continue;
				} // if

			$items[$cms_app_name] = array(
				'class' => $cms_plugin['class'],
				'name' => $cms_app_name,
				'app_name' => self::format_app_name($cms_app_name,false),
				'app_dir' => (!empty($result['app_dir']) ? $result['app_dir']:self::lookup_body_dir($cms_app_name)),
				'app_uri' => (!empty($result['app_uri']) ? $result['app_uri']:self::lookup_body_url($cms_app_name)),
				'always' => (!empty($result['always']) ? $result['always']:false),
				);

			$idx = 0;
			foreach($result as $k => &$item) {
				if(!is_numeric($k)) continue;
				$allowed_now = false;
				if(!isset($item['role'])) $allowed_now = true;	// default
				else {
					switch($item['role']) {
					case 'admin':
						$allowed_now = Ccms_auth::is_cms_admin_user();
						break;
					case 'manager':
						$allowed_now = Ccms_auth::is_cms_group_manager();
						break;
					case 'user':
						$allowed_now = Ccms_base::is_cms_user();
						break;
					default:	// error, what is this ??
						self::addAdminMsg('Unknown role: ' . print_r($item['role'],true) . ' for ' . $cms_app_name);
						$allowed_now = Ccms_auth::is_cms_admin_user();	// only admin
						break;
						} // switch
					} // else

				$items[$cms_app_name][] = array_merge($item,array(
					'allowed_now' => $allowed_now,
					'idx' => $idx,
					));
				$idx++;
				} // foreach
			} // foreach
		if(empty($items)) return false;
		return $items;
		} // get_all_plugins_static_func_text()

	private static function log_error_handler_context($errcontext = false) {
		return;

//		if(empty($errcontext)) return;
//		echo PHP_EOL . 'CODE CONTEXT:' . PHP_EOL;
//		print_r($errcontext);
//		echo PHP_EOL;
//		return;

//		if(is_array($errcontext)) {
//			foreach($errcontext as $k => $v) {
//				self::addDebugMsg("CODE CONTEXT: [$k] => " . ((is_array($v) || (is_object($v))) ? print_r($v,true):$v),'warn');
//				} // foreach
//			} // if
//		else self::addDebugMsg("CODE CONTEXT: $errcontext",'warn');
		} // log_error_handler_context()

	protected static function global_undefined_handler($errno, $errstr, $errfile, $errline, $errcontext) {
		if(preg_match('/^Use of undefined constant /',$errstr)) {
			$constant = preg_replace('/^Use of undefined constant ([^\s]+).*$/','$1',$errstr);
			define($constant, false);	// just a default
			self::addDebugMsg("USER UNDEFINED ERROR: for $constant (defaulted to false) in \"$errfile\" at line $errline.",'error');
			return true;
			}
		return false;
		} // global_undefined_handler()

	public static function global_error_handler($errno, $errstr, $errfile, $errline) {
		// see "https://www.php.net/manual/en/function.set-error-handler.php"
		// this is especially helpful in catching and hilighting intermittent code disrupting warnings and errors.
		if (!(error_reporting() & $errno)) {
			// This error code is not included in error_reporting, so let it fall
			// through to the standard PHP error handler
			// the @ error ignore comes thru here too
			self::log_error("ERROR @ [$errno] $errstr\n" .
				"  Error @ on line $errline in file $errfile" .
				", PHP " . PHP_VERSION . " (" . PHP_OS . ").");
			return false;
			} // if
		switch ($errno) {
		case E_USER_ERROR:	// user generated with trigger_error()
			self::addDebugMsg("USER ERROR: [$errno] $errstr\n" .
				"  Fatal error on line $errline in file $errfile" .
				", PHP " . PHP_VERSION . " (" . PHP_OS . ").");
			break;

		case E_USER_WARNING:	// user generated with trigger_error()
			if(self::global_undefined_handler($errno, $errstr, $errfile, $errline)) break;	// sorted
			self::addDebugMsg("USER WARNING: [$errno] $errstr in \"$errfile\" at line $errline.",'warn');
			return true; /* Don't execute PHP internal error handler */
			break;

		case E_USER_NOTICE:	// user generated with trigger_error()
			self::addDebugMsg("USER INFO: [$errno] $errstr in \"$errfile\" at line $errline.",'info');
			return true; /* Don't execute PHP internal error handler */
			break;

		case E_ERROR:	// std error number
			self::addMsg("CODE ERROR: [$errno] $errstr in \"$errfile\" at line $errline.",'info');
			break;

		case E_WARNING:	// std error number
			if((self::is_debug()) || (!self::is_production())) {
				if(preg_match('/undefined/i',$errstr)) {
					self::addDebugMsg("CODE UNDEFINED (debug): [$errno] $errstr in \"$errfile\" at line $errline.",'warn');
					} // if
				else {
					self::addDebugMsg("CODE WARNING (debug): [$errno] $errstr in \"$errfile\" at line $errline.",'warn');
					} // else
				} // if
			self::addDebugMsg("CODE WARNING: [$errno] $errstr in \"$errfile\" at line $errline.",'warn');
			return true;

		default:
			self::log_msg("CODE ERROR: Type: [$errno] $errstr in \"$errfile\" at line $errline.");
			break;
			} // switch

		self::$cms_error_cnt++;
		return false;	// use the internal error handler
		} // global_error_handler()

} // Ccms_base_sm
