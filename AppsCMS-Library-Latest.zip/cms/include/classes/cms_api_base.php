<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api_base.php 2986 2022-11-14 11:10:49Z robert0609 $
 */

/**
 * Description of Ccms_api_base
 * API execute class
 *
 * Contains the Ccms_api_jwt class
 * Use private / public SSL keys.
 *
 * @author robert0609
 */

require_once 'cms_general.php';	// speed up for proxy (no autoloader needed)

class Ccms_api_base extends Ccms_general {

	protected static $api_exc_keys = array('/resource.json','_role','_func','_function','_method','_class');
	protected static $api_resource_map = false;
	protected static $api_cntl_map = false;
	protected static $api_func_cntl = false;
	protected static $api_http_code = false;	// HTTP response code number

	protected $api_request = false;
	protected $api_request_vf = false;	// has virtual folders
	protected $api_request_vf_vals = false;	// inline virtual folder values
	protected $api_request_method = false;
	protected $api_role = false;
	protected $api_cmd = false;
	protected $api_response = false;
	protected $api_errors = array();

	protected static $api_response_headers = array();
	protected static $api_request_headers = false;

	// common JWT statics
	protected static $jwt_payload = false;
	protected static $jwt_user_id = false;

	const API_TOK_KEY = 'API_key';	// index to token in headers
	const API_JWT_KEY = 'JWT';	// index to JWT where used

	// enumerate roles (allows between roles)
	const API_PUBLIC = 100;
	const API_USER = 200;
	const API_MANAGER = 300;
	const API_ADMIN = 400;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// getters and setters
	public static function get_api_cntl_map() { return self::$api_cntl_map; }
	public static function get_api_func_cntl() { return self::$api_func_cntl; }
	public static function get_api_http_code($code = false) {
		if((int)$code > 0) self::$api_http_code = (int)$code;
		return self::$api_http_code;
		} // get_api_http_code()

// static methods

// dynamic methods

	protected function filter_api_keys(&$data,$exc = array()) {
		$api_exc_keys = self::$api_exc_keys;
		if(CMS_C_API_SHOW_ROLES) {	// remove _role from the exclude array
			$k = array_search('_role', $api_exc_keys);
			unset($api_exc_keys[$k]);
			} // if
		foreach ($data as $k => &$value) {
			if(is_string($k) !== false) {
				if((substr($k,1) == "_") || // ignore
					(in_array($k,$api_exc_keys))) {
					unset($data[$k]);
					continue;
					} // if
				} // if
			if (is_array($value)) {
				if((!$this->chk_api_role($value)) &&
					(!Ccms_api_jwt::is_use_jwt_ok())) {
					unset($data[$k]);
					continue;
					} // if
				$this->filter_api_keys($value,$exc);	// recurse
				} // if
			} // foreach
		return true;
		} // filter_api_keys()

	protected function chk_api_role(&$value) {
		if(!Ccms_auth::check_login_ip_allowed(false)) return false;
		if((is_array($value)) && (isset($value['_role']))) $role = $value['_role'];	// summary and open always have a _role
		// else if(!Ccms_auth::is_jwt_user()) return false;
		else $role = $value;
		switch($role) {
		case 'admin':
			if(!Ccms_auth::is_cms_admin_user()) return false;
			$this->api_role = self::API_ADMIN;
			break;
		case 'manager':
			if(!self::is_cms_group_manager()) return false;
			$this->api_role = self::API_MANAGER;
			break;
		case 'user':
			if(self::is_cms_guest()) return false;
			$this->api_role = self::API_USER;
			break;
		case 'public':
		default:
			$this->api_role = self::API_PUBLIC;
			break;
			} // switch
		return true;
		} // chk_api_role()

	protected function add_http_code($code = 0, $msg = false) {
		if(!empty(self::$api_response_headers[0])) return true;	// already done
		if(!$code) $code = self::get_api_http_code ();
		if(!$code) $code = 200;
		if(empty($msg)) $msg = self::get_url_response_str($code);
		if(empty($msg)) return false;	// ??
		self::$api_response_headers[0] = 'HTTP/1.1 ' . $code . ' ' . $msg;
		return true;
		} // add_http_code()

	protected function send_api_headers() {
		if(headers_sent()) {
			$this->api_response['error'] = "Error: headers sent.";
			return false;
			} // if
		$this->add_http_code(200);
		if(empty(self::$api_response_headers['Content-Type']))
			self::$api_response_headers['Content-Type'] = 'application/json';
		if(!preg_match('/charset/',self::$api_response_headers['Content-Type'])) {
			$charset = (!empty(self::$api_resource_map['charset']) ? self::$api_resource_map['charset']:CMS_S_CHAR_SET);
			self::$api_response_headers['Content-Type'] .= '; charset=' . $charset;
			} // if
		asort(self::$api_response_headers);
		foreach(self::$api_response_headers as $k => &$v) {
			if(is_numeric($k)) header($v);	// already coded
			else {
				$kc = preg_replace('/\s/m', '_',$k);	// no spaces
				header($kc . ': ' . $v);
				} // else
			} // foreach
		return true;
		} // send_api_headers()

} // Ccms_api_base
