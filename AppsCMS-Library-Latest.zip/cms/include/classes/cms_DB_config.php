<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_config.php 2877 2022-10-15 07:58:45Z robert0609 $
 */

/**
 * Description of Ccms_DB_config
 * Top level AppsCMS configuration database class
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_SQLite.php');
require_once(CMS_FS_CLASSES_DIR . 'cms_MySQL.php');
require_once(CMS_FS_CLASSES_DIR . 'cms_base.php');

class Ccms_DB_config extends Ccms_base {

	private $cDBary = false;
	private $cDBprim = false;
	private static $failed_obj = false;	// used as a ref return for failed object pointer

	protected $MySQLfirst = false;
	protected $m_bConfigDefined = false;

	public $m_bNew = false;
	public $m_sVersion = false;

	function __construct($install_tables = false) {
		$this->m_bConfigDefined = false;
		// parent::__construct();
		$this->MySQLfirst = Ccms_base::get_cms_ini_value('DB_MYSQL_PRIMARY_BOOL','DataBaseAccess');
		$this->cDBary = array();
		if($this->MySQLfirst) {
			$this->cDBary[] = new Ccms_MySQL();
			$this->cDBary[] = new Ccms_SQLite();
			} // if
		else {
			$this->cDBary[] = new Ccms_SQLite();
			$this->cDBary[] = new Ccms_MySQL();
			} // else
		$this->cDBprim = &$this->cDBary[0];
		$this->init($install_tables);

		$this->m_bNew = $this->cDBprim->m_bNew;
		$this->m_sVersion = $this->cDBprim->m_sVersion;
		parent::__construct();
		} // __construct()

	function __destruct() {
		// clean before I go home
		parent::__destruct();
		} // __destruct()

	function __call($name, $args) {	// a PHP magic method
		if(method_exists($this->cDBprim, $name)) {
			return call_user_func_array(array($this->cDBprim,$name),$args);
			} // if
		self::addDebugMsg('Unknown ' . __CLASS__ . ' method "' . $name . '()');
		return false;
		} // __call()

// static methods

// dynamic methods
	protected function &get_DB($db_idx = 0) {
		if((!isset($this->cDBary[$db_idx])) ||
			(!$this->cDBary[$db_idx]->is_ok())) {
			self::$failed_obj;
			} // if
		return $this->cDBary[$db_idx];
		} // get_1stDB()

	protected function init($install_tables) {
		if(self::is_rebuild()) $install_tables = true;
		$cf_debug = false;
		if((self::is_debug()) && (!self::is_ajax()) && (!self::is_api())) $cf_debug = true;
		$res = true;
		for($i = 0; $i < sizeof($this->cDBary); $i++) {
			$DBobj = &$this->cDBary[$i];
			if($DBobj) {
				if($DBobj->is_ok()) {
					if(!$DBobj->init($install_tables)) $res = false;
					} // if
				} // if
			} // for
		// Ccms_content_cache::reset_caches(false);
		if(($install_tables) && ($res)) {
			new Ccms_xml_sitemap();	// do sitemap
			} // if

		// setup configuration table defines
		$DBobj = $this->get_DB();
		if((!$this->m_bConfigDefined) &&
			($config_result = $DBobj->query("select cms_config_key, cms_config_value, cms_config_allowed_values from cms_configs"))) {
			$this->m_bConfigDefined = true;
			if($cf_debug) {	// check for corrupt config table
				$cfs_done = array();
				} // if
			while ($config = $DBobj->fetch_array($config_result,false)) {	// read in config
				$key = &$config['cms_config_key'];
				$val = &$config['cms_config_value'];
				$allowed = &$config['cms_config_allowed_values'];

				// and define
				if(empty($allowed)) define($key,$val);
				else {
					switch(strtolower($val)) {
					case '0':	// thats what false becomes
					case 'false':
					case 'disabled':
					case 'disable':
						define($key,false);
						break;
					case '1':	// thats what true becomes
					case 'true':
					case 'enabled':
					case 'enable':
						define($key,true);
						break;
					default:
						define($key,$val);
						break;
						} // switch
					} // else
				if($cf_debug) {	// check for corrupt config table
					$cfs_done[] = $key;	// save define
					} // if
				} // while
			$DBobj->free_result($config_result);
			if($cf_debug) {	// check for corrupt config table
				$cCMSi_configs = Ccms_DB_install::get_installDBscriptsSQLite();
				$data = &$cCMSi_configs['cms_configs']['data'];
				$columns = array_keys($cCMSi_configs['cms_configs']['columns']);
				$missing_confs = array();
				foreach($data as &$d) {
					$cf = array_combine($columns,$d);
					$key = preg_replace('/^\'|\'$/','',$cf['cms_config_key']);
					if(!in_array($key,$cfs_done)) $missing_confs[] = $key;
					} // foreach
				if(!empty($missing_confs)) {
					self::addDebugMsg('Missing config keys: ' . implode(',',$missing_confs));
					} // if
				} // if
			} // if
		} // init()
		
	protected function updateDBversion() {
		$fields = array();
		$fields['cms_config_value'] = CMS_PROJECT_VERSION;
		if(!$this->perform('cms_configs',$fields,'update',"cms_config_key = 'CMS_C_VERSION'")) {
			Ccms::addAdminMsg('DB update to ' . CMS_PROJECT_VERSION . " failed");
			return false;
			} // if
		Ccms::addAdminMsg('DB updated to ' . CMS_PROJECT_VERSION, 'warn');
		return true;
		} // updateDBversion()

	private function chk_section_table() {
		$sql_query = "SELECT  lm_section_id, lm_section_parent_id" .
			" FROM  lm_sections";
		if(($result = Ccms::$cDBcms->query($sql_query)) &&
			(Ccms::$cDBcms->num_rows($result) > 0)) {
			$cnt = 0;
			while($section = Ccms::$cDBcms->fetch_array($result)) {
				if(empty($section['lm_section_parent_id'])) {	// fix migration error
					$up_sql = 'UPDATE lm_sections SET lm_section_parent_id = 0 WHERE lm_section_id = ' . (int)$section['lm_section_id'] . ';';
					if($up_result = self::$cDBcms->query($up_sql)) {
						$cnt++;
						} // if
					} // if
				} // while
			return $cnt;
			} // if
		return false;
		} // chk_section_table()

	public function checkDBversion($rebuild = false,$use_json = false) {
		if($rebuild) Ccms_DB_install::upgrade_DB_lmc_V303();
		if((!$rebuild) &&
			(defined('CMS_C_VERSION')) &&
			(CMS_C_VERSION == CMS_PROJECT_VERSION) &&	// same version
			(defined('CMS_C_README_LINK')))	// last rebuild completed
			return true;
		if($rebuild) Ccms::addInfoMsg('Rebuild setup.');

		Ccms::addMsg('Checking ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ' database for updates.','info');

		Ccms_DB_install::clean_DB();

		Ccms_filesystems::apps_read_only_filesystems('remount');

		// if(!self::$cDBcms) self::$cDBcms = new Ccms_DB_config(); // also reads in configuration definitions
		if(Ccms::$cDBcms->installDatabase((!$rebuild ? 'cms_configs':''),true ,false)) { // update db configs
			// if($rebuild) Ccms_DB_install::rebuild_from_settings();
			$this->chk_section_table();
			return $this->updateDBversion();
			} // if

		Ccms::addAdminMsg('DB update at ' . CMS_PROJECT_VERSION . " failed (not checked).");
		return false;
		} // checkDBversion()

} // Ccms_DB_config
