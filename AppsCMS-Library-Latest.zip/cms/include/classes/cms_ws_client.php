<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_ws_client.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of Ccms_ws_base
 * websockets client code class
  *
 * @author robert0609
 */

class Ccms_ws_client extends Ccms_general {

	function __construct() {
		parent::__construct();

		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

	public static function get_ws_socks_client_js($id,$app_name,$op = false,$index = false) {
		if(!self::is_ws_enabled()) return false;
		$host = '127.0.0.1';	// CMS_DOMAIN;	// from browser using SNI
		$port = CMS_S_WS_REDIR_PORT;
		$uri = CMS_URI_ALIAS . ($index ?:'') . '?wsid=' . urlencode($id) . '&app=' . urlencode($app_name) . (!empty($op) ? '&op=' . rawurldecode($op):'');
		$ws_p = 'ws';	// (self::has_ssl_available() ? 'wss':'ws');

		$text =<<< EOTJS

		<div id="wsid_tcp_${id}"></div>

		<script type="text/javascript">

			var ws_tcp_url = '{$ws_p}://{$host}:{$port}/{$uri}';
			var ws_tcp_socket = new WebSocket(ws_tcp_url);
			ws_tcp_socket.onopen = function(e) {
				console.log("[open] Connection established");
				};
			ws_tcp_socket.onmessage = function(event) {
				document.getElementById('wsid_tcp_{$id}').append(event.data);
				};
			ws_tcp_socket.onclose = function(event) {
				console.log("WebSocket is closed now.");
				};
			ws_tcp_socket.onerror = function(event) {
				console.error("WebSocket error observed:", event);
				};

		</script>

EOTJS;

		return $text;
		} // get_ws_socks_client_js()

// dynamic methods


} // Ccms_ws_client
