<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api_map.php 3049 2022-12-16 02:47:04Z robert0609 $
 */

/**
 * Description of Ccms_api_map
 *
 * API request map to response execution map
 *
 * @author robert0609
 */

require_once 'cms_api_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_api_map extends Ccms_api_base {

	private static $skip_path_jwt = array('/resource.json','/summary','/session/open');
	private static $meths2mod = array('get','post','put','delete');

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

	protected static function add_jwt_auth_param(&$api_map) {
		if(CMS_C_API_AUTH == 'JWT') {	// add authorisation definitions
			$auth_param = array(
						'name' => self::API_JWT_KEY,
						'in' => 'header',
						'description' => 'JWT for authorisation.',
						'required' => true,
						'type' => 'string',
						);
			foreach($api_map['paths'] as $path => &$cntls) {	// add JWT in header
				if(in_array($path,self::$skip_path_jwt)) continue;
				foreach($cntls as $meth => &$cntl) {
					if(!in_array($meth,self::$meths2mod)) continue;
					if(!isset($cntl['parameters'])) $cntl['parameters'] = array();
					$cntl['parameters'][] = $auth_param;
					} // foreach
				} // foreach
			} // if
		return true;
		} // add_jwt_auth_param()

	private static function add_api_map_info(&$api_map) {	// get map parts
		if(self::is_cli()) return false;
		if(!empty($api_map['info'])) return false;
		$api_map_info = array(
			'info' => array(
				'description' => CMS_C_CO_NAME . ' API summary.' .
					'<br>Generator: ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ',' .
					'<br>Security tokens are part of the request and response headers.' .
					'<br>Refer to the <a href="'  . Ccms_base::get_base_url(true) . 'index.php?cms_action=cms_manual#APImapping" target="_blank">Technical Manual</a>.',
				'uri' => Ccms_base::get_base_url(true) . 'index.php?cms_action=cms_manual',
				'title' => CMS_C_TITLE,
				'contact' => array(CMS_C_SUPPORT_EMAIL,),
				),
			'license' => array(
				'name' => 'Clear BSD License',
				'uri' => Ccms_base::get_base_url(true) . 'cms/LICENCE.txt',
				),
			'host' => CMS_DOMAIN,	//Ccms_base::get_base_url(true),
			'schemes' => (Ccms::is_ssl_required() ? array('https'):array('https','http')),
			'basePath' => '/' . DOCROOT_WS_BASE_DIR . 'api',
			);
		$api_map = array_merge($api_map_info,$api_map);
		return true;
		} // add_api_map_info()

	public static function &get_api_resource_map($reload = false,$res_flg = false) {
		$api_map = &self::$api_resource_map;	// quickie for debug
		if((!defined('CMS_C_API_ENABLE')) || (!CMS_C_API_ENABLE)) {	// API disabled
			$api_map = false;
			return $api_map;
			// exit(11001);	// API disabled
			} // if
		if(($reload) || (!file_exists(ETC_FS_CMS_API))) {
			self::build_cmd2method_map();
			$db_map = Ccms_export::get_DB_api_summary_map();
			if(!empty($db_map['tags'])) self::add_api_tags($db_map['tags']);
			if(!empty($db_map['paths'])) self::add_api_paths($db_map['paths']);
			self::get_apps_api_map_summaries($api_map);
			self::add_api_map_info($api_map);

			$tags = $api_map['tags'];	// make a copy
			$api_map['tags'] = array();	// remove existing tags
			foreach($tags as &$tag) {	// add used tags
				$fnd = false;
				foreach($api_map['paths'] as $path => &$cntls) {
					if(!in_array($path,self::$skip_path_jwt)) continue;
					foreach($cntls as $meth => &$cntl) {
						if(empty($cntl['tags'])) continue;
						if(in_array($tag['name'],$cntl['tags'])) {
							$fnd = true;
							break 2;
							} // if
						} // foreach
					} // foreach
				if($fnd) $api_map['tags'][] = $tag;
				} // foreach
			self::add_jwt_auth_param($api_map);

			if(!self::save_json(ETC_FS_CMS_API, $api_map)) {
				self::addMsg('Failed to save "' . ETC_FS_CMS_API . '".');
				}
			} // if
		else if(empty($api_map)) {
			$api_map = self::load_json(ETC_FS_CMS_API);
			if(self::add_api_map_info($api_map)) {
				self::save_json(ETC_FS_CMS_API, $api_map);
				} // if
			} // if
		if((!self::is_cli()) && ($res_flg)) {	// for compatibility with swagger resource wobbles generating 406 errors
			//self::$api_resource_map['basePath'] = '/' . DOCROOT_WS_BASE_DIR . 'api.php';
			self::$api_resource_map['swagger'] = '2.0';
			} // if
		return $api_map;
		} // get_api_resource_map()

	public static function add_api_tags($tags) {
		if((empty($tags)) || (!is_array($tags))) {
			self::addAdminMsg('Cannot add empty API tags.');
			return false;
			} // if
		$api_map = &self::$api_resource_map;
		foreach($tags as $tag) {
			$tagged = array_filter($api_map['tags'], function($v) use ($tag) {
				if($v['name'] != $tag['name']) return false;
				return true; // me
				});
			if(!empty($tagged));
				$api_map['tags'][] = $tag;
			} // foreach
		return true;
		} // add_api_tags()

	public static function add_api_paths($paths) {
		if((empty($paths)) || (!is_array($paths))) {
			self::addAdminMsg('Cannot add empty API paths.');
			return false;
			} // if
		$api_map = &self::$api_resource_map;
		foreach($paths as $path => &$v) {
			if(isset($api_map['paths'][$path])) {
				self::addAdminMsg('API path : ' . $path . ' already present.');
				} // if
			else {
				if(empty($v['_func'])) {
					self::addAdminMsg('API path : ' . $path . ' does not have a callback [_func] entry.');
					} // if
				else $api_map['paths'][$path] = $v;
				} // else
			} // foreach
		return true;
		} // add_api_paths()

	protected static function get_apps_api_map_summaries(&$api_resource_map) {
		$body_defines = Ccms_sm::get_bodies_defines();
		foreach($body_defines as $bid => &$body) {
			if(!$cms_app_map = Ccms_apps::get_app_api_map_summary($body)) continue;	// has no API calls
			// insert into main api map
			if(!empty($cms_app_map['tags'])) self::add_api_tags($cms_app_map['tags']);
			if(!empty($cms_app_map['paths'])) self::add_api_paths($cms_app_map['paths']);

			} // foreach

		return true;
		} // get_apps_api_map_summaries()

	protected static function build_cmd2method_map() {
		$api_map = &self::$api_resource_map;	// debug easier
		$api_map = array(
			'charset' => 'utf-8',	//CMS_S_CHAR_SET,
			'tags' => array(
				array( 'name' => 'summary', 'description' => 'Provides API information and a map of available API functions.' ),
				array( 'name' => 'session', 'description' => 'Session control API functions.' ),
				array( 'name' => 'cms', 'description' => CMS_PROJECT_SHORTNAME . ' API calls.' ),
				// apps may provide tags to be included here.
				),
			'_role' => array(
				array('public' => 'Public access allowed.'),
				array('user' => 'Only users with an open sessions allowed.'),
				array('manager' => 'Only group managers and admins with an open sessions allowed.'),
				array('admin' => 'Only admins with an open sessions allowed.'),
				array('description' => 'Roles provide access levels to API functionality.'),
				),
			'paths' => array(
				'/resource.json' => array(	// special case, API request path
					'_role' => 'public', // 'admin','manager','user' or 'public'
					'_func' => 'cmd_api_resource',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('summary',),
						'produces' => array('application/json'),
						'description' => 'Provides a summary of all API calls (refer to <a href="index.php?cms_action=cms_manual#APImapping" target="_blank">Technical Manual</a> for more info).',
						'responses' => array(
							'200' => array('description' =>  "OK",),
							),
						),
					),
				'/summary' => array(	// special case, API request path
					'_role' => 'public', // 'admin','manager','user' or 'public'
					'_func' => 'cmd_api_summary',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('summary',),
						'produces' => array('application/json'),
						'description' => 'Provides a summary of allowed API calls (refer to <a href="index.php?cms_action=cms_manual#APImapping" target="_blank">Technical Manual</a> for more info).',
						'responses' => array(
							'200' => array('description' =>  "OK",),
							),
						),
					),
				'/session/open' => array(	// API request path
					'_role' => 'public', // 'admin','manager','user' or 'public'
					'_func' => 'cmd_api_open',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('session',),
						'produces' => array('application/json'),
						'description' => 'Open API session',
						'parameters' => array(	// API function parameters
							array( 'name' => 'username', 'in' => 'query', 'description' => 'The user name for login', 'required' => true, 'type' => 'string' ),
							array( 'name' => 'password', 'in' => 'query', 'description' => 'The user login password', 'required' => true, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Session opened (recommend reloading summary).",),
							'202' => array('description' =>  "Session already open.",),
							'401' => array('description' =>  "Invalid username/password."),
							'403' => array('description' =>  "Open not allowed."),
							),
						),
					'post' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('session',),
						'produces' => array('application/json'),
						'description' => 'Open API session',
						'consumes' => array('application/json',),
						'parameters' => array(	// API function parameters
							array( 'name' => 'username', 'in' => 'formData', 'description' => 'The user name for login', 'required' => true, 'type' => 'string' ),
							array( 'name' => 'password', 'in' => 'formData', 'description' => 'The user login password', 'required' => true, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Session opened (recommend reloading summary).",),
							'202' => array('description' =>  "Session already open.",),
							'401' => array('description' =>  "Invalid username/password."),
							'403' => array('description' =>  "Open not allowed."),
							),
						),
					),
				'/session/close' => array(	// API request path
					'_role' => 'user', // 'admin','manager','user' or 'public'
					'_func' => 'cmd_api_close',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('session',),
						'produces' => array('application/json'),
						'description' => 'Close API session',
						'responses' => array(
							'200' => array('description' =>  "Session closed (recommend reloading summary).",),
							'401' => array('description' =>  "Invalid session."),
							),
						),
					),
				'/cms/logCMS' => array(	// API request path
					'_role' => 'admin',	// admin required
					'_func' => 'cmd_api_cms_log',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('cms',),
						'description' => 'Get most recent internet log entries.',
						'produces' => array('text/plain'),
						'parameters' => array(	// API function parameters
							array( 'name' => 'tail', 'in' => 'query', 'description' => 'Number of most recent log lines.', 'required' => true, 'type' => 'integer' ),
							array( 'name' => 'grep', 'in' => 'query', 'description' => 'Grep options.', 'required' => false, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'400' => array('description' =>  "Invalid request."),
							'401' => array('description' =>  "Invalid session."),
							),
						),
					),
				'/cms/logCLI' => array(	// API request path
					'_role' => 'admin',	// admin required
					'_func' => 'cmd_api_cli_log',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('cms',),
						'description' => 'Get most recent CLI log entries.',
						'produces' => array('text/plain'),
						'parameters' => array(	// API function parameters
							array( 'name' => 'tail', 'in' => 'query', 'description' => 'Number of most recent log lines.', 'required' => true, 'type' => 'integer' ),
							array( 'name' => 'grep', 'in' => 'query', 'description' => 'Grep options.', 'required' => false, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'204' => array('description' =>  "No content (empty).",),
							'400' => array('description' =>  "Invalid request."),
							'401' => array('description' =>  "Invalid session."),
							),
						),
					),
				'/cms/errorCMS' => array(	// API request path
					'_role' => 'admin',	// admin required
					'_func' => 'cmd_api_error_cms_log',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('cms',),
						'description' => 'Get most recent internet log entries.',
						'produces' => array('text/plain'),
						'parameters' => array(	// API function parameters
							array( 'name' => 'tail', 'in' => 'query', 'description' => 'Number of most recent log lines.', 'required' => true, 'type' => 'integer' ),
							array( 'name' => 'grep', 'in' => 'query', 'description' => 'Grep options.', 'required' => false, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'204' => array('description' =>  "No content (empty).",),
							'400' => array('description' =>  "Invalid request."),
							'401' => array('description' =>  "Invalid session."),
							),
						),
					),
				'/cms/errorCLI' => array(	// API request path
					'_role' => 'admin',	// admin required
					'_func' => 'cmd_api_error_cli_log',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('cms',),
						'description' => 'Get most recent internet log entries.',
						'produces' => array('text/plain'),
						'parameters' => array(	// API function parameters
							array( 'name' => 'tail', 'in' => 'query', 'description' => 'Number of most recent log lines.', 'required' => true, 'type' => 'integer' ),
							array( 'name' => 'grep', 'in' => 'query', 'description' => 'Grep options.', 'required' => false, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'204' => array('description' =>  "No content (empty).",),
							'400' => array('description' =>  "Invalid request."),
							'401' => array('description' =>  "Invalid session."),
							),
						),
					),
				'/cms/SMSlog' => array(	// API request path
					'_role' => 'manager',	// admin required
					'_func' => 'cmd_api_sms_log',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array('cms',),
						'description' => 'Get SMS send and reply log entries.',
						'produces' => array('application/json'),
						'parameters' => array(	// API function parameters
							array( 'name' => 'date', 'in' => 'query', 'description' => 'Date of SMS log.', 'type' => 'date' ),
							array( 'name' => 'tail', 'in' => 'query', 'description' => 'Number of most recent entries.', 'type' => 'integer' ),
							array( 'name' => 'grep', 'in' => 'query', 'description' => 'Grep options.', 'required' => false, 'type' => 'string' ),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'204' => array('description' =>  "No content (empty).",),
							'400' => array('description' =>  "Invalid request."),
							'401' => array('description' =>  "Invalid session."),
							),
						),
					),
				// more cms and apps sections added
				),	// paths
			);
		return true;
		} // build_cmd2method_map()

// dynamic methods

} // Ccms_api_map
