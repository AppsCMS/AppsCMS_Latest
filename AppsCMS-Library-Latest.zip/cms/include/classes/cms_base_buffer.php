<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_base_buffer.php 2996 2022-11-23 02:43:02Z robert0609 $
 */

/**
 * Description of cms_base_buffer
 *
 * @author robert0609
 */

require_once 'cms_msgs.php';	// speed up for proxy (no autoloader needed)

class Ccms_base_buffer extends Ccms_msgs {

	public $cms_prn_flg = true; // true = print $this->cms_text_buffit direct (false = buffer it for a $this->get_buffered_text() call)
	protected $cms_text_buffit = array();	// an accumlative text buffer array, call $this->prn_or_buffer_text() to print intermediate buffing (and put in html debug markers)

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function get_gm_datetime($time = false, $short = false) { // returns date time string in DB compatible format, useful as it returns the SI DT string
		$fmt = ($short ? 'Ymd-His' : 'Y-m-d H:i:s');
		if ($time)
			return gmdate($fmt, $time) . 'Z';
		return gmdate($fmt) . 'Z';
		} // get_gm_datetime()

	public static function get_localtime_from_utc($utc_dt) {
		$tz_from = new DateTimeZone('UTC');
		$tz_local = date_default_timezone_get();
		$tz_to = new DateTimeZone($tz_local);
		if((is_int($utc_dt)) && ((int)$utc_dt > 0)) {
			$orig_time = new DateTime('now', $tz_from);
			$orig_time->setTimestamp($utc_dt);
			} // if
		else $orig_time = new DateTime($utc_dt, $tz_from);
		$new_time = $orig_time->setTimezone($tz_to);
		$localtime = $new_time->format('c');
		return $localtime;
		} // get_localtime_from_utc()

	public static function flush_out_msg($msg) {	// output an iterative on a single line using line refresh
		if(!Ccms_base::is_cli()) {
			if(!empty($msg))
				echo '<p>' . nl2br($msg) . '</p>' . PHP_EOL;
			@ob_flush();
			@flush();
			} // if
		else if(!empty($msg)) {
			if(Ccms_posix::is_windows()) {
				echo $msg . PHP_EOL;
				} // if
			else system('echo -en \'                     \r\'; echo -n "' . $msg . '"');
			} // else if
		} // flush_out_msg()

	protected static function ipCIDRCheck($IP, $CIDR) { // virtual
		return true;
		} // ipCIDRCheck()

	protected static function get_backtrace($levels = 1) {
		if($levels < 1) $level = 1;
		// not $levels++;	// one for me
		$l_idx = $levels - 1;
		$dbt = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,$levels);
		$caller = '';
		if(isset($dbt[$l_idx]['class'])) {
			$caller .= $dbt[$l_idx]['class'];
			if(isset($dbt[$l_idx]['type'])) {
				$caller .= $dbt[$l_idx]['type'];
				} // if
			else $caller .= '::';
			} // if
		if(isset($dbt[$l_idx]['function'])) {
			$caller .= $dbt[$l_idx]['function'];
			} // if
		if(isset($dbt[$l_idx]['line'])) {
			$caller .= ', line=' . $dbt[$l_idx]['line'];
			} // if
		return $caller;
		} // get_backtrace()

// dynamic methods
	protected function prn_or_buffer_text($text = false) {
		if(Ccms_base::is_debug()) {
			$caller = '<!-- Caller="' . self::get_backtrace(2) . '" -->';
			$this->cms_text_buffit[] = $caller;
			} // if
		if(is_string($text)) $this->cms_text_buffit[] = $text;	// using $text here is the slow way, add to the $this->cms_text_buffit array directly
		if($this->cms_prn_flg) {
			echo PHP_EOL . implode(PHP_EOL,$this->cms_text_buffit) . PHP_EOL;
			$this->cms_text_buffit = array();	// clear it
			} // if
		return '';	// do nothing
		} // prn_or_buffer_text()

	protected function get_buffered_text() {
		$text = PHP_EOL . implode(PHP_EOL,$this->cms_text_buffit) . PHP_EOL; // wasteful
		$this->cms_text_buffit = '';	// but !!
		return $text;
		} // get_buffered_text()

	public static function set_chk_php_value($name,$val,$chk = false) {
		if($chk) {
			$cur = ini_get($name);
			if($cur != $val) {
				self::log_msg('Require PHP "' . $name . '" = "' . $val . '", have "' . $cur .'".','Warning');
				return false;
				} // if
			return true;
			} // if
		else {
			switch($name) { // use alt funcs
			case 'max_execution_time':
				if(set_time_limit((int)$val)) return true;
				// could be running under xdebug ??
				break;
			default:
				$old = ini_set($name,$val);
				break;
				} // swiitch
			$chk = ini_get($name);
			if($chk != $val) {
				self::log_error('Cannot set PHP "' . $name . '" to "' . $val . '", have "' . $chk .'".','Error');
				return false;
				} // if
			} // else
		return true;
		} // set_chk_php_value()

	public static function urlEncode3986($string) {	// use with caution(only needed complete urls)
		$entities =		['%21',	'%2A',	'%27',	'%28',	'%29',	'%3B',	'%3A',	'%40',	'%26',	'%3D',	'%2B',	'%24',	'%2C',	'%2F',	'%3F',	'%25',	'%23',	'%5B',	'%5D'	];
		$replacements = ['!',	'*',	"'",	"(",	")",	";",	 ":",	"@",	"&",	"=",	"+",	"$",	",",	"/",	"?",	"%",	"#",	"[",	"]"		];
		return str_replace($entities, $replacements, urlencode($string));
	} // urlEncode3986()

} // Ccms_base_buffer
