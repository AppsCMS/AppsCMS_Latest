<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_valid.php 3421 2023-08-06 10:21:57Z robert0609 $
 */

/**
 * Description of Ccms_valid class
 * save valid user data like emails and phone that have been validated
 * from user inputs like contact us forms, etc. (i.e. not registered users).
 *
 * @author robert0609
 */

class Ccms_valid extends Ccms_base {

	protected static $validated = false;
	protected static $validated_chgd = false;

	protected static $cDBvalids = false;
	protected static $ok = false;

	function __construct() {
		self::open_validity_data();
		// parent::__construct();
		} // __construct()

	function __destruct() {
		self::close_validity_data();	// save validated data
		// parent::__destruct();
		} // __destruct()

// static methods
	protected static function get_SQLite_install_script() {	// the appointment data base
		return array(
			'emails' => array(	// table name
				'drop' => 'false', // dont drop on table reload
				'id' => 'id',	// row id column (optional)
				'asc' => 'user',	// ASC sort column (optional)
				'columns' => array(
					"id" => "INTEGER PRIMARY KEY AUTOINCREMENT",	// the row id
					"added" => "DATETIME",		// date and time the row was added
					"updated" => "DATETIME DEFAULT 0",		// date and time the row was updated
					"domain" => "VARCHAR(128) NOT NULL",			// the user email
					"user" => "VARCHAR(128) NOT NULL",			// the user email confirmation
					),
				'key_column' => 'id',	// used with update_row_data()
				'updateable_columns' => '',	// used with update_row_data(), comma separate list, nil
				'functions' => array(
					"InsertTrigger_emails" => "CREATE TRIGGER InsertTrigger_emails AFTER INSERT ON emails" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE emails SET added = DATETIME('NOW')  WHERE rowid = new.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					"UpdateTrigger_emails" => "CREATE TRIGGER UpdateTrigger_emails AFTER UPDATE ON emails" . PHP_EOL .
						"BEGIN" . PHP_EOL .
						" UPDATE emails SET updated = DATETIME('NOW')  WHERE rowid = old.rowid;" . PHP_EOL .
						"END;" . PHP_EOL,
					),
				),
			);
		} // get_SQLite_install_script()

	protected static function init_db($initialise) {
		if(self::$cDBvalids !== false) return true;	// already open
		$db_file = CMS_VALIDATED_DB;
		self::$cDBvalids = new Ccms_database_sqlite($db_file);
		if(self::is_rebuild()) $initialise = true;
		if(($initialise) ||
			(!self::$cDBvalids->is_table_present('emails'))
			// || (!$result = self::$cDBvalids->query("SELECT * FROM emails LIMIT 1"))
			// || (!$row = self::$cDBvalids->fetch_array($result,false))
			) {
			$install_scripts = self::get_SQLite_install_script();
			if(!self::$cDBvalids->install_db_tables('', $install_scripts)) {
				self::addAdminMsg('Failed to update/create ' . self::VALIDATED_DB . ' database.');
				return false;
				} // if
			} // if
		self::$ok = true;
		return true;
		} // init_db()

	protected static function open_validity_data($initialise = false) {
		// get validated data
		self::init_db($initialise);
		if(!self::$validated) {
			if(file_exists(CMS_VALIDATED_JSON)) {
				self::$validated = self::load_json(CMS_VALIDATED_JSON);
				} // if
			if(!self::$validated) self::$validated = [];
			} // if
		} // open_validity_data()

	public static function close_validity_data() {
		// save validated data
		if(self::$cDBvalids) self::$cDBvalids->close();
		self::$cDBvalids = false;
		if((self::$validated_chgd) && (self::$validated)) {
			if(!self::save_json(CMS_VALIDATED_JSON,self::$validated)) {
				self::addAdminMsg('Failed to save validated JSON data.');
				} // if
			else self::$validated_chgd = false;
			} // if
		} // close_validity_data()

	public static function remove_validity_data() {
		// save validated data
		self::$validated_chgd = false;
		self::$validated = false;
		if(self::$cDBvalids) self::$cDBvalids->close();
		self::$cDBvalids = false;
		self::trash_path(CMS_VALIDATED_JSON);
		self::trash_path(CMS_VALIDATED_DB);
		self::trash_path(CMS_VALIDATED_DB . '-shm');
		self::trash_path(CMS_VALIDATED_DB . '-wal');
		self::addMsg('Removed the validity data.','warn');
		} // remove_validity_data()

	public static function chk_domain_user_valid($domain,$user,$type = 'emails') {
		self::open_validity_data();	// get validated data
		switch($type) {
		case 'emails':	// saved in DB
			if(($result = self::$cDBvalids->query("SELECT * FROM emails WHERE domain = '" . self::$cDBvalids->input($domain) . "' AND user = '" . self::$cDBvalids->input($user) . "'")) &&
				(self::$cDBvalids->num_rows($result) > 0)) {
				return true;
				} // if
			break;
		default:
			break;
			} // switch
		if((!empty(self::$validated)) && (!empty(self::$validated[$type]))) {
			if(!empty(self::$validated[$type][$domain])) {
				if(in_array($user,self::$validated[$type][$domain])) return true;
				} // if
			} // if
		return false;
		} // chk_domain_user_valid()

	public static function add_domain_user_valid($domain,$user,$type = 'emails') {
		if(self::chk_domain_user_valid($domain,$user,$type)) return;	// don't double up
		// self::open_validity_data();	// get validated data
		switch($type) {
		case 'emails':	// saved in DB
			if(self::$cDBvalids->query("INSERT INTO emails (domain,user) VALUES ('" . self::$cDBvalids->input($domain) . "','" . self::$cDBvalids->input($user) . "')")) {
				return;
				} //if
		default:
			break;
			} // switch
		self::$validated[$type][$domain][] = $user;
		self::$validated_chgd = true;
		} // add_domain_user_valid()

} // Ccms_valid