<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_posix.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/**
 * Description of Ccms_posix
 * POSIX replacement functions used in AppsCMS for when php-process or
 * php-posix modules are not installed or not available
 *
 * refer to "https://www.php.net/manual/en/book.posix.php"
 *
 * @author robert0609
 */

//Understanding fields
//
// /etc/passwd (indexes for self::$passwd)
//    0. Username: It is used when user logs in. It should be between 1 and 32 characters in length.
//    1. Password: An x character indicates that encrypted password is stored in /etc/shadow file. Please note that you need to use the passwd command to computes the hash of a password typed at the CLI or to store/update the hash of the password in /etc/shadow file.
//    2. User ID (UID): Each user must be assigned a user ID (UID). UID 0 (zero) is reserved for root and UIDs 1-99 are reserved for other predefined accounts. Further UID 100-999 are reserved by system for administrative and system accounts/groups.
//    3. Group ID (GID): The primary group ID (stored in /etc/group file)
//    4. User ID Info: The comment field. It allow you to add extra information about the users such as user’s full name, phone number etc. This field use by finger command.
//    5. Home directory: The absolute path to the directory the user will be in when they log in. If this directory does not exists then users directory becomes /
//    6. Command/shell: The absolute path of a command or shell (/bin/bash). Typically, this is a shell. Please note that it does not have to be a shell.
//
// /etc/group file (indexes for self::$group)
//    0. group_name: It is the name of group. If you run ls -l command, you will see this name printed in the group field.
//    1. Password: Generally password is not used, hence it is empty/blank. It can store encrypted password. This is useful to implement privileged groups.
//    2. Group ID (GID): Each user must be assigned a group ID. You can see this number in your /etc/passwd file.
//    3. Group List: It is a list of user names of users who are members of the group. The user names, must be separated by commas.

// /etc/shadow (indexes for self::$passwd['shadow'])
// e.g.username:$1$TrOIigLp$PUHL00kS5UY3CMVaiC0/g0:15020:0:99999:7:::
//	Username : It is your login name.
//	Password : It is your encrypted password. The password should be minimum 8-12 characters long including special characters, digits, lower case alphabetic and more. Usually password format is set to $id$salt$hashed, The $id is the algorithm used On GNU/Linux as follows:
//		$1$ is MD5
//		$2a$ is Blowfish
//		$2y$ is Blowfish
//		$5$ is SHA-256
//		$6$ is SHA-512
//	Last password change (lastchanged) : Days since Jan 1, 1970 that password was last changed
//	Minimum : The minimum number of days required between password changes i.e. the number of days left before the user is allowed to change his/her password
//	Maximum : The maximum number of days the password is valid (after that user is forced to change his/her password)
//	Warn : The number of days before password is to expire that user is warned that his/her password must be changed
//	Inactive : The number of days after password expires that account is disabled
//	Expire : days since Jan 1, 1970 that account is disabled i.e. an absolute date specifying when the login may no longer be used.

class Ccms_posix {

	private static $uname = false;
	private static $os_type = false;
	private static $is_linux = null;
	private static $is_windows = null;
	private static $env = false;
	private static $passwd = false;	// organised /etc/passwd file
	private static $group = false;	// organised /etc/group file

	function __construct() {
		// parent::__construct();
		} // __construct()

	function __destruct() {
		// parent::__destruct();
		} // __destruct()

// static methods
	public static function get_os_type() {
		if(!self::$os_type) {
			self::$os_type = PHP_OS;
			} // if
		return self::$os_type;
		} // get_os_type()

	public static function get_uname() {
		if(!self::$uname) {
			self::$uname = php_uname();
			} // if
		return self::$uname;
		} // get_uname()

	public static function is_linux() {
		if(is_null(self::$is_linux)) {
			self::$is_linux = preg_match('/^linux.*/i',self::get_os_type());
			} // if
		return self::$is_linux;
		} // get_os_type()

	public static function is_windows() {
		if(is_null(self::$is_windows)) {
			self::$is_windows = preg_match('/^windows .*/i', self::get_uname());
			} // if
		return self::$is_windows;
		} // get_os_type()

	private static function get_env_var($name) {
		if(!self::$env) {
			$output = array();
			$return_var = -1;
			exec('env',$output,$return_var);
			if($return_var) return false;
			self::$env = array();
			foreach($output as &$l) {
				$exp = preg_replace('/^([A-Z_]+)=.*$/','$1',$l);
				$v = preg_replace('/^[A-Z_]+=(.*)$/','$1',$l);
				self::$env[$exp] = $v;
				} // foreach
			} // if
		if(isset(self::$env[$name])) return self::$env[$name];
		return false;
		} // get_env_var()

	private static function search_info(&$info,$s_col,&$match,$r_col) {
		$cols = count($info);
		if(($r_col >= $cols) || ($s_col >= $cols)) return false;
		for($i = 0 ; $i < $cols; $i++ ) {
			if($info[$i][$s_col] == $match) return $info[$i][$r_col];
			} // for
		return false;
		} // search_info()

	private static function get_user_info($s_col,&$match,$r_col) {
		global $_ENV;
		if(!self::$passwd) {
			if(self::is_linux()) {	// LINUX can do /etc lookups
				$output = array();
				$return_var = -1;
				exec('cat /etc/passwd',$output,$return_var);
				if($return_var) return false;
				// user:pw:uid:gid:gecos:home:shell
				self::$passwd = array();
				foreach($output as &$p) {
					self::$passwd[] = explode(':',$p);
					} // foreach
				} // if
			else if(self::is_windows()) {	// not LINUX cannot do /etc lookups
				// $output = getenv();
				self::$passwd = array(
					array(
						getenv("USERNAME"),	// user
						'x',	// pw
						0,	// uid
						0,	// gid
						'',	// gecos
						getenv("HOMEDRIVE") . getenv("HOMEPATH"),	// home
						'cmd',	// shell
						),
					);
				} // else if
			else return false;
			} // if
		return self::search_info(self::$passwd,$s_col,$match,$r_col);
		} // get_user_info()

	private static function get_group_info($s_col,&$match,$r_col) {
		if(!self::$group) {
			$output = array();
			$return_var = -1;
			exec('cat /etc/group',$output,$return_var);
			if($return_var) return false;
			self::$group = array();
			foreach($output as &$p) {
				self::$group[] = explode(':',$p);
				} // foreach
			} // if
		return self::search_info(self::$group,$s_col,$match,$r_col);
		} // get_group_info()

	public static function posix_getegid() {	// Return the effective group ID of the current process
		// refer "https://www.php.net/manual/en/function.posix-getegid.php"
		if(function_exists('posix_getegid')) return posix_getegid();

		if(!self::is_linux()) return false;	// not LINUX cannot do /etc lookups

		// return an int,not strictly the same
		return getmygid();
		} // posix_getegid()

	public static function posix_getgrgid($gid ) {	// Return info about a group by group id
		// refer "https://www.php.net/manual/en/function.posix-getgrgid.php"
		if(function_exists('posix_getgrgid')) return posix_getgrgid($gid);

		if(!self::is_linux()) return false;	// not LINUX cannot do /etc lookups

		// return an array(), not strictly the same
		$grgid = array(
			'name' => self::get_group_info(2,$gid,0),
			'passwd' => self::get_group_info(2,$gid,1),
			'gid' => self::get_group_info(2,$gid,2),
			'glist' => explode(',',self::get_group_info(2,$gid,3)),	// not std
			);
		return $grgid;
		} // posix_getgrgid()

	public static function posix_getpwuid($uid) {	// Return info about a user by user id
		// refer "https://www.php.net/manual/en/function.posix-getpwuid.php"
		if(function_exists('posix_getpwuid')) return posix_getpwuid($uid);

		if(!self::is_linux()) return false;	// not LINUX cannot do /etc lookups

		// return an array(), not strictly the same
		$pwuid = array(
			'name' => self::get_user_info(2,$uid,0),
			'passwd' => self::get_user_info(2,$uid,1),
			'uid' => self::get_user_info(2,$uid,2),
			'gid' => self::get_user_info(2,$uid,3),
			'gecos' => false,	// GECOS is an obsolete term that refers to the finger information field
			'info' => self::get_user_info(2,$uid,4),	// not std
			'dir' => self::get_user_info(2,$uid,5),
			'shell' => self::get_user_info(2,$uid,6),
			);
		return $pwuid;
		} // posix_getpwuid()

	public static function posix_geteuid() {	// Return current user id
		// refer "https://www.php.net/manual/en/function.posix-getpwuid.php"
		if(function_exists('posix_geteuid')) return posix_geteuid();

		$info = false;
		$uid = self::get_user_info(2,$info,2);
		return $uid;
		} // posix_geteuid()

	public static function get_current_username() {	// instead of get_current_user();
		if(function_exists('get_current_user')) 
			return get_current_user();
		// keep PHP 5 compatibility
		$user = self::posix_getpwuid(self::posix_geteuid());
		return $user['name'];
		} // get_current_username()

	public static function posix_getpwnam($username, $passwd = false) {
		// refer "https://www.php.net/manual/en/function.posix-getpwnam.php"

		$pwnam = false;
		if((empty($passwd)) && (function_exists('posix_getpwnam'))) {
			$pwnam = posix_getpwnam($username);
			} // if
		else if(self::is_linux()) {	// LINUX
			// return an array(), not strictly the same
			$pwnam = array(
				'name' => self::get_user_info(0,$username,0),
				'passwd' => self::get_user_info(0,$username,1),
				'uid' => self::get_user_info(0,$username,2),
				'gid' => self::get_user_info(0,$username,3),
				'gecos' => false,	// GECOS is an obsolete term that refers to the finger information field
				'info' => self::get_user_info(0,$username,4),	// not std
				'dir' => self::get_user_info(0,$username,5),
				'shell' => self::get_user_info(0,$username,6),
				);
//			if( $pwnam['passwd'] == 'x') {	// password encryted
//				// get encrypted pw
//				$output = array();
//				$return_var = -1;
//				$cmd = "cat /etc/shadow | grep -E \"^$username:\"";	// THIS WILL NOT WORK (no permission)
//				exec($cmd,$output,$return_var);
//				if((!$return_var) && (!empty($output))) {
//					$shads = explode(':',$output);
//					$pwnam['pwenc'] = $shad[1];
//					if (!empty($passwd)) {
//						$t_s_e = explode('$',$shads[1]);
//						$pwenc = false;
//						switch($t_s_e[1]) {
//						case '1':	// is MD5
//						case '5':	// is SHA-256
//						case '6':	// is SHA-512
//							$output = array();
//							$return_var = -1;
//							$cmd = 'openssl passwd -' . $t_s_e[1] . ' -salt ' . $t_s_e[1] . ' ' . $passwd;
//							exec($cmd,$output,$return_var);
//							if((!$return_var) && (!empty($output))) {
//								$pwenc = $output;
//								} // if
//							break;
//						case '2a':	// is Blowfish
//						case '2y':	// is Blowfish
//							// mostly not available on modern systems
//							break;
//						default:
//							$output = array();
//							$return_var = -1;
//							$s = substr($t_s_e[1],0,2);
//							$cmd = 'openssl passwd -crypt -salt ' . $s . ' ' . $passwd;
//							exec($cmd,$output,$return_var);
//							if((!$return_var) && (!empty($output))) {
//								$pwenc = $output;
//								} // if
//							break;
//							} // switch
//						if($t_s_e[3] == $pwenc) return $pwnam;	// ok
//						} // if
//					} // if
//				else {	// plain text !!!!
//					if($pwnam['passwd'] == $passwd) return $pwnam;	// ok
//					} // else
//				return false;	// no good
//				} // if
			} // else
		return $pwnam;
		} // posix_getpwnam()

	public static function posix_get_last_error() {
		// refer "https://www.php.net/manual/en/function.posix_get_last_error.php"
		if(function_exists('posix_get_last_error')) return posix_get_last_error();

		if(!self::is_linux()) return false;	// not LINUX cannot do /etc lookups

		return 0;	// @TODO maybe later
		} // posix_get_last_error()

} // Ccms_posix
