<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_msgs.php 2986 2022-11-14 11:10:49Z robert0609 $
 */

/**
 * Description of Ccms_msgs
 *
 * A basic storage class.
 *
 * All messages are logged to the log file.
 *
 * Accumulates all messages avoiding html header contamination,
 * then messages can be formatted and output to the page in an orderly fashion.
 *
 * Messages are reported according to the setting of CMS_S_ONLINE_MSGS_LEVEL
 *
 * Remaining/undisplayed messages are saved to session
 *
 * @author robert0609
 */

require_once 'cms_logger.php';	// speed up for proxy (no autoloader needed)

class Ccms_msgs extends Ccms_logger {

	private static $cms_msgs = false;
	public static $cms_logit = true;

	const CLI_SH_BOLD = "\033[1m";
	const CLI_SH_NORM = "\033[0m";

	const CLI_SH_RED = "\033[1;31m";
	const CLI_SH_GREEN = "\033[1;32m";
	const CLI_SH_YELLOW = "\033[1;33m";
	const CLI_SH_PURPLE = "\033[1;35m";
	const CLI_SH_BLUE = "\033[1;34m";	// now light blue
	const CLI_SH_WHITE = "\033[1;39m";
	const CLI_SH_DEFCOL = "\033[0m";

	private static $cms_online_types = false;


	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		self::saveMsgs();
		} // __destruct()

	protected static function remove_duplicate_msgs(&$msgs) {
		$unq = array();
		foreach($msgs as &$v) {
			$found = false;
			for($i = 0; $n = count($unq),$i < $n;$i++) {
				if($unq[$i] == $v) {
					$found = true;
					break;
					} // if
				} // for
			if(!$found) $unq[] = $v;
			} // foreach
		return $unq;
		} // remove_duplicate_msgs()

	protected static function initMsgs() {
		if(!is_array(self::$cms_msgs)) {
			self::$cms_msgs = array();	// start
			} // if
		if(($msgs = self::get_cms_sess_var('msgs')) && (is_array($msgs))) {
			$tmp = array_merge(self::$cms_msgs,$msgs);
			self::$cms_msgs = self::remove_duplicate_msgs($tmp);
			self::unset_cms_sess_var('msgs');
			} // if
		} // initMsgs()

	public static function Start_working_js() {
		$text = '<script type="text/javascript">if (typeof Ccms_cursor === \'function\') Ccms_cursor.setWait();</script>' . PHP_EOL;
		return $text;
		} // Start_working_js()

	public static function stop_working_js() {
		$text = '<script type="text/javascript">if (typeof Ccms_cursor === \'function\') Ccms_cursor.restore();</script>' . PHP_EOL;
		return $text;
		} // stop_working_js()

	protected static function chk_msg_type_used(&$type) {
		if(Ccms_base::is_cli()) return true;
		if(!defined('CMS_S_ONLINE_MSGS_LOGGED_BOOL')) return true;
		if((CMS_S_ONLINE_MSGS_LOGGED_BOOL) &&
			(self::is_cms_guest())) return false;
		if(!self::$cms_online_types) {
			if((Ccms_base::is_debug()) ||
				(!defined('CMS_S_ONLINE_MSGS_LEVEL')) ||
				(Ccms_auth::is_config_user())) self::$cms_online_types = -1;
			else self::$cms_online_types = explode(':', strtolower(CMS_S_ONLINE_MSGS_LEVEL));
			} // if
		$type = strtolower($type);
		if($type == 'all') return true;
		if(self::$cms_online_types == -1) return true;
		if(in_array($type,self::$cms_online_types)) return true;

		return false;
		} // chk_msg_type_used()

	protected static function get_msg_icon($default,$config) {
		if((!empty($config)) &&
			(defined($config))) {
			$icon = constant($config);
			if((strlen($icon) > 4) &&
				(file_exists(ETC_WS_ICONS_DIR . $icon)))
				return ETC_WS_ICONS_DIR . $icon;
			} // if
		// if(file_existd(CMS_WS_IMAGES_DIR . $default)) return CMS_WS_IMAGES_DIR . $default;
		return CMS_WS_ICONS_DIR . $default;
		} // get_msg_icon()

	public static function get_msg_small_icon_text($default,$config) {
		$img = self::get_msg_icon($default, $config);
		return '<img alt="small icon" class="msg_icon_small" src="' . $img . '">';
		} // get_msg_small_icon_text()

	public static function make_message_brief_text($msg,$type,$ext_class = '',$title = false) {
		self::initMsgs();

		$cli_pre = '';
		$cli_suf = '';

		switch($type) {

		case 'ok':
		case 'tick':
			$pre = '';
			$class = 'cms_msg_info';
			break;
		case 'wrong':
		case 'cross':
			$pre = '';
			$class = 'cms_msg_info';
			break;

		case 'required':
		case 'require':
			$pre = 'REQUIRED:';
			$class = 'cms_msg_required';
			break;

		case 'warning':
		case 'warn':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_PURPLE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'WARNING:';
			$class = 'cms_msg_warning';
			break;
		case 'success':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_GREEN;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'SUCCESS:';
			$class = 'cms_msg_success';
			break;
		case 'info':
		case 'information':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_BLUE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'INFO:';
			$class = 'cms_msg_info';
			break;
		case 'working':
			$pre = 'WORKING:';
			$class = 'cms_msg_info';
			break;
		case 'debug':
			$pre = 'DEBUG:';
			$class = 'cms_msg_debug';
			break;
		default:
		case 'error':
		case 'err':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_RED;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'ERROR:';
			$class = 'cms_msg_error';
			break;
			} // switch

		$text = '';
		if(!Ccms_base::is_cli()) {
			$text .= '<span class="' . (!empty($ext_class) ? ' ' . $ext_class:'') . $class . ' cms_msg_brief"';
			if(!empty($title)) $text .= ' title="' . $title . '"';
			$text .= '>';
			// $text .= '&nbsp;' . $pre . ' ' . $msg;
			$text .= '&nbsp;' . $msg;
			$text .= '</span>';
			} // if
		else {	// CLI mode
			$text .= $cli_pre . $pre . $cli_suf;
			$text .= ' ' . $msg . PHP_EOL;
			} // else
		return $text;
		} // make_message_brief_text()

	public static function make_message_text($msg,$type,$ext_class = '',$title = false, $ext_icon_class = false) {
		self::initMsgs();

		$cli_pre = '';
		$cli_suf = '';

		switch($type) {

		case 'ok':
		case 'tick':
			$pre = '';
			$class = 'cms_msg_info';
			$img = self::get_msg_icon('tick.gif','CMS_C_MSG_OK_ICON');
			break;
		case 'wrong':
		case 'cross':
			$pre = '';
			$class = 'cms_msg_info';
			$img = self::get_msg_icon('cross.gif','CMS_C_MSG_WRONG_ICON');
			break;

		case 'required':
		case 'require':
			$pre = 'REQUIRED:';
			$class = 'cms_msg_required';
			$img = self::get_msg_icon('required.gif','CMS_C_MSG_REQUIRED_ICON');
			break;

		case 'warning':
		case 'warn':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_PURPLE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'WARNING:';
			$class = 'cms_msg_warning';
			$img = self::get_msg_icon('warning.gif','CMS_C_MSG_WARNING_ICON');
			break;
		case 'success':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_GREEN;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'SUCCESS:';
			$class = 'cms_msg_success';
			$img = self::get_msg_icon('success.gif','CMS_C_MSG_SUCCESS_ICON');
			break;
		case 'info':
		case 'information':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_BLUE;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'INFO:';
			$class = 'cms_msg_info';
			$img = self::get_msg_icon('info.gif','CMS_C_MSG_INFO_ICON');
			break;
		case 'working':
			$pre = 'WORKING:';
			$class = 'cms_msg_info';
			$img = self::get_msg_icon('working.gif','CMS_C_MSG_WORKING_ICON');
			break;
		case 'debug':
			$pre = 'DEBUG:';
			$class = 'cms_msg_debug';
			$img = self::get_msg_icon('debug.gif','CMS_C_MSG_DEBUG_ICON');
			break;
		default:
		case 'error':
		case 'err':
			$cli_pre = self::CLI_SH_BOLD . self::CLI_SH_RED;
			$cli_suf = self::CLI_SH_DEFCOL . self::CLI_SH_NORM;
			$pre = 'ERROR:';
			$class = 'cms_msg_error';
			$img = self::get_msg_icon('error.gif','CMS_C_MSG_ERROR_ICON');
			break;
			} // switch

		$text = '';
  		if((!Ccms_base::is_cli()) && (!Ccms_base::is_api())) {
			$text .= '<span class="' . (!empty($ext_class) ? ' ' . $ext_class:'') . $class . '"';
			if(!empty($title)) $text .= ' title="' . $title . '"';
			$text .= '>';
			$text .= '<img alt="' . $type . '" class="msg_icon' . ($ext_icon_class ? ' ' . $ext_icon_class:'') . '" src="' . $img . '">';
			$text .= '&nbsp;' . $pre . ' ' . $msg;
			$text .= '</span>';
			} // if
		else if(Ccms_base::is_cli()) {	// CLI mode
			$text .= $cli_pre . $pre . $cli_suf . ' ' . html_entity_decode($msg);
			} // else
		else {	// API mode (the rest)
			$text .= $pre . ' ' . ' ' . $msg;	// put into an array()
			} // else
		return $text;
		} // make_message_text()

	protected static function chkAdminMsg(&$m_saMsg) {
		if(empty($m_saMsg['admin'])) return true;	// not admin msg, allow
		if(!method_exists('Ccms_auth','is_cms_admin_user')) return true;	// why, some sort of error
		if(Ccms_auth::is_cms_admin_user()) return true;
		return false;	// admin msg but not admin user
		} // chkAdminMsg()

	public static function getMsgs($clearFlg = true) {
		self::initMsgs();
		if(!self::$cms_msgs) return false;
		$text = (Ccms_base::is_cli() ? "":PHP_EOL);
		$o_cnt = 0;
		for($i = 0, $n = count(self::$cms_msgs); $i < $n; $i++) {
			$msg = &self::$cms_msgs[$i];
			if(!self::chkAdminMsg($msg)) continue;
			$msg_txt = (Ccms_base::is_cli() ? $msg['msg']:nl2br(htmlentities($msg['msg'])));
			if((Ccms_base::is_debug()) && ($msg['cnt'] > 1)) $msg_txt .= ' (x' . $msg['cnt'] . ')';
			if(self::chk_msg_type_used($msg['type'])) {
				if($o_cnt++ > 0) $text .= (Ccms_base::is_cli() ? "," . PHP_EOL:'<br>' . PHP_EOL);
				$text .= self::make_message_text($msg_txt,$msg['type']);
				} // if
			} // for
		if($clearFlg) self::$cms_msgs = false;
		if($o_cnt == 0) return '';
		return $text . PHP_EOL;
		} // getMsgs()

	public static function getMsgsAPIresult($clearFlg = true) {
		self::initMsgs();
		if(!self::$cms_msgs) return false;
		$msgs = array();
		$o_cnt = 0;
		for($i = 0, $n = count(self::$cms_msgs); $i < $n; $i++) {
			$msg = &self::$cms_msgs[$i];
			if(!self::chkAdminMsg($msg)) continue;
			$msg_txt = $msg['msg'];
			if((Ccms_base::is_debug()) && ($msg['cnt'] > 1)) $msg_txt .= ' (x' . $msg['cnt'] . ')';
			if(self::chk_msg_type_used($msg['type'])) {
				if($o_cnt++ > 0) $msg_txt .= (Ccms_base::is_cli() ? "," . PHP_EOL:'<br>' . PHP_EOL);
				$msgs[] = self::make_message_text($msg_txt,$msg['type']);
				} // if
			} // for
		if($clearFlg) self::$cms_msgs = false;
		return $msgs;
		} // getMsgsAPIresult()

	public static function getMsgsCount($type = 'all') {
		self::initMsgs();
		$type = strtolower($type);
		if(!self::$cms_msgs) return 0;
		if(!self::chk_msg_type_used($type)) return 0;
		$cnt = 0;
		for($i = 0, $n = count(self::$cms_msgs); $i < $n; $i++) {
			$msg = &self::$cms_msgs[$i];
			if(!self::chkAdminMsg($msg)) continue;
			if($type == 'all') $cnt++;
			else if($msg['type'] == $type) $cnt++;
			} // for
		return $cnt;
		} // getMsgsCount()

	protected static function type_msg_chk($msg,$type) {
		// $type maybe a callback
		if((!is_array($type)) ||
			(!isset($type['func'])) ||
			(!self::is_static_callable($type['func']))) {
			return true;	// normal msg
			} // if
		// its a callback
		$func = $type['func'];
		if(isset($type['param'])) {
			call_user_func($func,$type['param'],$msg);
			} // if
		else {
			call_user_func($func,$msg);
			} // else
		return false;	// done by callback
		} // type_msg_chk()

	public static function pushMsg($msg, $type = 'error',$debug_only = false, $admin = false) {	// allows msgs to be stored to be show in a meaning full way
		if((self::$cms_logit) || ($debug_only)) self::log_msg($msg,$type);
		if(($debug_only) && (!Ccms_base::is_debug())) return;
		if(!self::type_msg_chk($msg, $type)) return;		// done by callback
		self::initMsgs();
		// don't repeat the msg
		$found = false;
		for($i = 0; $n = count(self::$cms_msgs), $i < $n; $i++) {
			if(self::$cms_msgs[$i]['admin'] != $admin) continue;
			if(self::$cms_msgs[$i]['type'] != $type) continue;
			if(strcasecmp(self::$cms_msgs[$i]['msg'],$msg)) continue;
			self::$cms_msgs[$i]['cnt']++;
			$found = true;
			break;
			} // for
		if(!$found) {
			self::$cms_msgs[] = array(
				'msg' => $msg,
				'type' => $type,
				'cnt' => 1,
				'admin' => $admin,
				);
			} // if
		// if(self::$cms_logit) self::log_msg($msg,$type);
		} // pushMsg()

	public static function addMsg($msg, $type = 'error') {	// allows msgs to be stored to be show in a meaning full way and print directlt if cli mode
		self::pushMsg($msg,$type);
		if(Ccms_base::is_cli()) {	// CLI output immediately
			echo self::getMsgs();
			} // if
		return true;
		} // addMsg()

	public static function addInfoMsg($msg) {	// allows information msgs to be stored to be show in a meaning full way and print directlt if cli mode
		self::pushMsg($msg,'info');
		if(Ccms_base::is_cli()) {	// CLI output immediately
			echo self::getMsgs();
			} // if
		return true;
		} // addInfoMsg()

	public static function addDebugMsg($msg, $type = 'error') {	// allows msgs to be stored to be show in a meaning full way and print directlt if cli mode
		self::pushMsg($msg,$type,true);
		if(Ccms_base::is_cli()) {	// CLI output immediately
			echo self::getMsgs();
			} // if
		return true;
		} // addDebugMsg()

	public static function addAdminMsg($msg, $type = 'error',$keyword = false) {	// allows msgs to be stored to be show in a meaning full way and print directlt if cli mode
		if((!Ccms_base::is_cli()) && (!Ccms_auth::is_cms_admin_user())) {
			self::log_msg($msg,$type);
			return;
			} // if
		if((!empty($keyword)) && (!Ccms_base::is_cli()) &&	// append the help link
			($url = Ccms_search::get_keyword_help_url($keyword))) {
			$link = '<a href="' . $url . '">' . $msg . '</a>';
			self::pushMsg($link,$type,false,true);
			return;
			} // if
		self::pushMsg($msg,$type,false,true);
		if(Ccms_base::is_cli()) {	// CLI output immediately
			echo self::getMsgs();
			} // if
		} // addAdminMsg()

	public static function saveMsgs() {
		if((!empty(self::$cms_msgs)) && (is_array(self::$cms_msgs)) && (Ccms_base::have_session())) {
			self::set_cms_sess_var(self::$cms_msgs,'msgs');
			}
		else self::unset_cms_sess_var('msgs');
		} // saveMsgs()

	public static function getMsgsTable($clearFlg = true) {
		self::initMsgs();
		if(!self::$cms_msgs) return '';
		$text = '<table class="page_body_msgs">' . PHP_EOL;
		// $text .= '<tr class="admin_pdb_container"><th class="admin_pdb_container">Messages:</th></tr>' . PHP_EOL;
		for($i = 0, $n = count(self::$cms_msgs); $i < $n; $i++) {
			$msg = self::$cms_msgs[$i];
			$text .= '<tr class="page_body_msgs"><td class="page_body_msgs">';
			$msg_txt = (Ccms_base::is_cli() ? $msg['msg']:nl2br($msg['msg']));
			if((Ccms_base::is_debug()) && ($msg['cnt'] > 1)) $msg_txt .= ' (x' . $msg['cnt'] . ')';
			$text .= self::make_message_text($msg_txt,$msg['type']);
			$text .= '</td></tr>' . PHP_EOL;
			} // for
		$text .= '</table>' . PHP_EOL;
		if($clearFlg) self::$cms_msgs = false;
		return $text . PHP_EOL;
		} // getMsgsTable()

	public static function getMsgsStack($clearFlg = true) {	// this is not ajax safe, use getMsgs()
		self::initMsgs();
		if(!self::$cms_msgs) return '';
		$text = '';
		if(Ccms_general::is_admin_action()) {	// it's an admin page
			$style = 'right: ' . (Ccms::show_right_column() ? CMS_S_RIGHT_WIDTH:'25px') . ';';
			$top = 'calc(' . CMS_S_HEADER_HEIGHT . ' + ' . (Ccms::show_nav_bar() ? CMS_S_NAV_BAR_HEIGHT:'0px') . ' + 15px)';
			$style .= ' top: ' . $top . ';';
			$text .= '<div class="admin_msg_stack" style="' . $style . '">' . PHP_EOL;
			$text .= '<div class="admin_msg_table">' . PHP_EOL;
			} // if
		else {
			$text .= '<div class="cms_msg_stack">' . PHP_EOL;
			$text .= '<div class="cms_msg_table">' . PHP_EOL;
			} // else
		$text .= self::getMsgsTable($clearFlg);
		$text .= '</div>' . PHP_EOL;
		$text .= '<span class="cms_msg_closebtn" onclick="this.parentElement.style.display=\'none\';" title="Close Messages">&times;</span>' . PHP_EOL;
		$text .= '</div>' . PHP_EOL;
		return $text . PHP_EOL;
		} // getMsgsStack()

	public static function getMsgsDropBox($class = false, $clearFlg = true) {
		return self::getMsgsStack();	// hook to replacement
		} // getMsgsDropBox()

	protected static function get_online_msgs_options($values) {	// return options for CMS_S_ONLINE_MSGS_LEVEL selector
		$opts_allowed = array(
			'ERROR'	=> 'Error messages',
			'WRONG' => 'Wrong or bad result messages',
			'CROSS' => 'Fail or incorrect messages',
			'WARNING' => 'Warning messages',
			'REQUIRED' => 'Required input (or error in input)',
			'WORKING' => 'Working or busy message',
			'DEBUG' => 'Debug messages',
			'INFO' => 'Information messages',
			'OK' => 'Ok or acknowledgement message',
			'TICK' => 'Correct or pass messages',
			'SUCCESS' => 'Success messages',
			);
		$vals = explode(':',$values);
		$options = array();
		foreach($opts_allowed as $k => &$v) {
			$options[] = array(
				'value' => $k,
				'selected' => (in_array($k,$vals) ? true:false),
				'text' => $k . ' - ' . $v,
				);
			} // foreach
		return $options;
		} // get_online_msgs_options()

	public static function addDebugMsgDie($msg, $type = 'error') {
		self::log_msg($msg, $type);
		if(!Ccms_base::is_debug()) die();
		echo PHP_EOL . strtoupper($type) . ': ' . $msg . PHP_EOL;
		echo PHP_EOL . '<pre>' . PHP_EOL;
		var_dump(debug_backtrace());
		echo PHP_EOL . '</pre>' . PHP_EOL;
		die();
		} // addDebugMsgDie()



} // Ccms_msgs
