<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_base_file.php 3366 2023-07-20 07:23:55Z robert0609 $
 */

/**
 * Description of cms_base_file
 *
 * @author robert0609
 */
require_once 'cms_base_buffer.php'; // speed up for proxy (no autoloader needed)

class Ccms_base_file extends Ccms_base_buffer {

	public static $cDBcms = false;
	protected static $cms_ini = false; // speed up for reading config ini file
	protected static $cms_ini_flat = false; // speed up for error handler definitions
	private static $cms_json_buffer = array(); // used by inc_merge_jsons() to buffer json file arrays to speed merges
	private static $cms_url_response_codes = false;

	private static $cms_uploads_cache = false;

	const FILE_MOD_STR = "0664";
	const DIR_MOD_STR = "0775";
	const UMASK_STR = "0002";
	const MACRO_DELIM = '%%';
	const FILE_MOD = 0664;
	const DIR_MOD = 0775;
	const UMASK = 0002;

	const NO_CLOBBER_FREE_SECS = 5;
	const MAX_NO_CLOBBER_DEF = 100;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function conv_conf_val_to_type($val) {
		switch(strtolower($val)) {
		case '0':	// that is what false becomes
		case 'false':
		case 'disabled':
		case 'disable':
		//case 'inline':
			$val = false;
			break;
		case '1':	// that is what true becomes
		case 'true':
		case 'enabled':
		case 'enable':
		//case 'block':
			$val = true;
			break;
		default:
			break;
			} // switch
		return $val;
		} // conv_conf_val_to_type()

	private static function get_docroot_fs() { // this used if the session has not started yet or not available
		$cms_docroot = false;
		if (!empty($_SERVER['DOCUMENT_ROOT']))
			$cms_docroot = $_SERVER['DOCUMENT_ROOT']; // if web served
		else if (defined(DOCROOT_FS_BASE_DIR))
			$cms_docroot = DOCROOT_FS_BASE_DIR; // if cli, may not be defined yet
		return $cms_docroot;
		} // get_docroot_fs()

	private static function is_under_docroot($path) {
		if (!$cms_docroot = self::get_docroot_fs())
			return false;
		if ($cms_docroot == substr($path, 0, strlen($cms_docroot)))
			return true;
		return false;
		} // is_under_docroot()

	public static function get_ws_filename($filepath) {
		if ((Ccms_base::is_under_docroot($filepath)) &&
			($cms_docroot = self::get_docroot_fs())) {
			$ws_file = preg_replace('/^' . $cms_docroot . '/', '', $filepath);
			return $ws_file;
		} // if
		return false;
		} // get_ws_filename()

	private static function get_path_group($path_of_interest = false) {
		if ($path_of_interest) {
			if (Ccms_base::is_under_docroot($path_of_interest)) {
				$cms_docroot = self::get_docroot_fs();
			} // if
		else
			$cms_docroot = dirname($path_of_interest);
			} // if
		else if (!empty($_SERVER['SCRIPT_FILENAME'])) {
			$script_dir = dirname($_SERVER['SCRIPT_FILENAME']);
			$cms_docroot = (substr($path_of_interest, 0, strlen($script_dir)) ? $script_dir : fale);
			} // else
		else
			$cms_docroot = false;
		if ((!$cms_docroot) &&
			(defined('CMS_S_GROUP_PERMISSIONS')) &&
			(strlen(CMS_S_GROUP_PERMISSIONS) > 0)) {
			// depreciated
			$group = CMS_S_GROUP_PERMISSIONS; // depreciated
			return group;
		} // else if
		if (!$cms_docroot)
			return false;
		$group = filegroup($cms_docroot);
		return $group;
		} // get_path_group()

    public static function gzip($path, $level = 9) {
		if((!file_exists($path)) || (is_dir($path))) {
			self::log_msg($path . ' is not a file (gz).');
			return false;
			} // if
		if(!preg_match('/\.gz$/i',$path)) {
			rename($path,$path . '.gz');
			$path .= '.gz';
			}
        $data = file_get_contents($path);
        $gzdata = gzencode($data, $level, FORCE_GZIP);
		if($gzdata === false) {
			self::log_msg('Failed to gzip: ' . $path);
			return false;
			} // if
		return file_put_contents($path,$gzdata);
	    } // gzip()

    public static function zip($zipfile,$source) {
		if(!file_exists($source)) {
			self::log_msg($source . ' is not a file (zip).');
			return false;
			} // if
	    if(!extension_loaded('zip')) {
			self::log_msg('Zip extension not loaded.');
			return false;
			} // if
	    $zip = new ZipArchive();
    	if(!$zip->open($zipfile, ZIPARCHIVE::CREATE)) {
			self::log_msg('Failed to open: ' . $zipfile);
			return false;
			} // if
  		$source = str_replace('\\', '/', realpath($source));	// windows compatibility
		if (is_dir($source) === true) {
        	$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);
			foreach ($files as $file) {
            	$file = str_replace('\\', '/', $file);
				// Ignore "." and ".." folders
            	if( in_array(substr($file, strrpos($file, '/')+1), array('.', '..')) ) continue;
				$file = realpath($file);
				if (is_dir($file) === true) {
                	$zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
            		} // if
				else if (is_file($file) === true) {
                	$zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
					} // else if
				} // foreach
			} // if
    	else if (is_file($source) === true) {
        	$zip->addFromString(basename($source), file_get_contents($source));
			} // else if
        return $zip->close();
		} // zip()

	public static function zip_info($zipfile) {
        $zip = new ZipArchive;
		if(!$res = $zip->open($zipfile)) return false;
		$files = array();
		while ($zip_entry = $zip->statIndex()) {
			$files[] = array(
				'name' => $zip_entry['name'],
				'size' => $zip_entry['size'],
				);
			} // while
		$zip->close();
		return true;
		} // zip_info()

	public static function unzip($zipfile,$dest) {
        $zip = new ZipArchive;
		if(!$res = $zip->open($zipfile)) {
			self::log_msg('Failed to open zip: ' . $zipfile);
			return false;
			} // if
		if(!$zip->extractTo($dest)) {
			self::log_msg('Failed to save unzip: ' . $zipfile . ' to: ' . $dest);
			return false;
			} // if
		$zip->close();
		return true;
		} // unzip()

	private static function chmod_chown_part(&$path, $group) {
		$ok = true;
		try {
			if (@chgrp($path, $group) === false)
				$ok = false;
			if (is_dir($path))
				$mod = self::DIR_MOD;
			else
				$mod = self::FILE_MOD;
			@umask(self::UMASK);
			if (@chmod($path, $mod) === false)
				$ok = false;
			if (@chgrp($path, $group) === false)
				$ok = false;
			} // try
		catch(Exception $e) {
			$err = $e->getMessage();
			self::addAdminMsg('Permission error in ' . __METHOD__ . ': ' . $err);
			return false;
			} // catch
		return $ok;
		} // chmod_chown_part()

	private static function chmod_chown_base_path($path, $group = false) {
		$parts = explode('/', $path);
		$last_gid = false;
		$ws_gid = Ccms_posix::posix_getegid();
		if ($ws_gid === false)
			return true; // OK it's windows
		$i = 0;
		$abs_path = ((substr($path, 0, 1) == '/') ? true : false);
		$path_base = '';
		for (; $i < count($parts); $i++) {
			$part = &$parts[$i];
			if (empty($part))
				continue;
			if (empty($path_base)) { // start it for abs or rel
				if ($abs_path)
					$path_base .= '/' . $part;
				else
					$path_base .= $part;
		} // if
			else
				$path_base .= '/' . $part;
			$gid = filegroup($path_base);
			if ($gid == $ws_gid)
				break;
			$last_gid = $gid;
		} // for
		// continue and chmod and chgrp
		$ok = true;
		if (!$group)
			$group = $last_gid;
		for (; $i < count($parts); $i++) {
			$part = &$parts[$i];
			if (empty($part))
				continue;
			$ok &= self::chmod_chown_part($path_base, $group);
			$path_base .= '/' . $part;
		} // for
		return $ok;
		} // chmod_chown_base_path()

	public static function chmod_chown($filename, $recurs = true) {
		if (!file_exists($filename))
			return false;

		$group = self::get_path_group($filename);
		if ((!$recurs) || (!is_dir($filename))) {
			if (!$group)
				return false;
			$ok = self::chmod_chown_part($filename, $group);
		} // if
		else
			$ok = self::chmod_chown_base_path($filename, $group);
		clearstatcache(); // do not cache filegroup() results (see "http://php.net/manual/en/function.chgrp.php")
		return $ok;
		} // chmod_chown()

	public static function mkdir($dirname, $recurs = true) {
		$chk = preg_replace('/\/$/', '', $dirname);
		if($win = Ccms_posix::is_windows()) {
			if(is_dir($chk)) return true;
			return @mkdir($chk,0777,$recurs);
			} // if
//		if(strpos($chk,DOCROOT_FS_BASE_DIR) !== 0) {
//			self::addDebugMsg('Attempt to create directory "' . $chk . '" out of scope.');
//			return false;
//			} // if
		if (is_link($chk))
			return true; // @TODO is this enough ??
		// if(realpath($chk)) return true;	// @TODO is this right ??
		if (!is_dir($chk)) {
			@umask(self::UMASK);
			if($recurs) {
				$dir_stk = explode('/',$chk);
				$dir_chk = explode('/',DOCROOT_FS_BASE_DIR);
				$d_b = '';
				$gid = 0;
				$uid = 0;
				$mod = self::DIR_MOD;
				$ok = true;
				for($i = 0; $n = count($dir_stk), $i < $n; $i++) {
					$d = $dir_stk[$i];
					$d_b .= '/' . $d;
					if((isset($dir_chk[$i])) && ($d == $dir_chk[$i])) {
						continue;	// don't alter base directories
						} // if
					if(is_dir($d_b)) {
						$gid = filegroup($d_b);
						$uid = fileowner($d_b);
						} // if
					else {
						$ok &= @mkdir($d_b, $mod,false);
						$ok &= @chmod($d_b, $mod);
						$ok &= @chgrp($d_b, $gid);	// carry it thru
						@chown($d_b, $uid);	// carry it thru, not sure if this will work on apache
						} // else
					} // for
				return $ok;
				} // if
			@mkdir($chk, self::DIR_MOD, $recurs);
			if (!is_dir($chk)) {
				self::addAdminMsg('Failed to create "' . $dirname . '" directory and chmod to "' . self::DIR_MOD_STR . '".');
				return false;
				} // if
			} // if
		// and set permissions
		return self::chmod_chown($dirname, $recurs);
		} // mkdir()

	protected static function findmnt($dir, $grep = false) {	// custom cmd
		if(!is_dir($dir)) return false;	// ??
		if(Ccms_posix::is_windows()) {
			// @TODO
			return false;
			} // if
		$output = false; $ret = false;
		exec('findmnt ' . $dir . ($grep ? ' | grep ' . $grep:''), $output, $ret);
		if($ret) return false;
		return implode(PHP_EOL,$output) . PHP_EOL;
		} // is_fs_squash_mount()

	public static function chkdir($dirname, $create = true, $recurs = true) {
		$chk = preg_replace('/\/$/', '', $dirname);
		if (is_link($chk))
			return $dirname; // @TODO is this enough ??
		// if(realpath($chk)) return $dirname;	// @TODO is this right ??
		if (is_dir($chk)) {
			// self::chmod_chown($dirname, $recurs); // overcooked
			return $dirname;
		} // if
		if (!$create)
			return false;
		if (!self::mkdir($dirname, $recurs))
			return false;
		return $dirname;
		} // chkdir()

	public static function chk_dir_path(&$dir_path, $readable = true, $writeable = false) {
		$dir_path = self::clean_path($dir_path);
		if (!is_dir($dir_path))
			return false;
		if (!Ccms_base::is_dir_usable($dir_path))
			return false;
		if (($readable) && (!is_readable($dir_path)))
			return false;
		if (($writeable) && (!is_writable($dir_path)))
			return false;
		if ((!$readable) && (!$writeable))
			return false; // error
		return true;
		} // chk_dir_path()

	protected static function can_macro(&$sect_name) {
		$not_dynamic_sects = array('AppsControlSettings', 'DataBaseAccess', 'SessionSettings', 'CRONsettings'); // non macro sections that programmed
		if (in_array($sect_name, $not_dynamic_sects))
			return false; // also stops recursion
		return true;
		} // can _macro()

	protected static function is_macro_lookup(&$sect_name, $value) {
		// looks for the "" . self::MACRO_DELIM . "class::method" . self::MACRO_DELIM . "" format in value and does the value retrieval from class::method
//		if(empty($value)) return false;
		if (!self::can_macro($sect_name))
			return false; // also stops recursion
		if ((!is_array($value)) &&
			(preg_match('/' . self::MACRO_DELIM . '[a-zA-Z0-9_]+::[a-zA-Z0-9_]+' . self::MACRO_DELIM . '/', $value))) {
			// have a macro in correct format
			return true;
		} // if
		return false;
		} // is_macro_lookup()

	protected static function get_macro_lookup(&$section_name, &$section, &$key, $value, $err_lev = '') {
		// looks for the "" . self::MACRO_DELIM . "class::method . self::MACRO_DELIM . "" format in value and does the value retrieval from class::method
		if (Ccms_base::is_macro_lookup($section_name, $value)) {
			// have a macro in correct format
			$c_m = preg_replace('/[ \%\:]/', ' ', $value);
			$c_m = trim($c_m);
			$c_m = explode('  ', $c_m);
			$class = $c_m[0];
			$method = $c_m[1];
			if ((!Ccms_autoloader::find_class($class)) ||
				(!method_exists($class, $method))) {
				self::addAdminMsg('Cannot find  "' . $class . '::' . $method . '() in "' . $section . '->' . $key . '" = "' . $value . '".');
				return false;
		} // if
			$value = $class::$method($section, $key);
		} // if
		return $value;
		} // get_macro_lookup()

	protected static function insert_macro(&$val) { // insert macro back into setting
		if ((!is_array($val)) || (!isset($val['macro'])))
			return false; // no macro
		if ((isset($val['chkbox'])) && ($val['chkbox'] == 'on')) {
			$macro = $val['macro'];
			return $macro;
		} // if
		if (isset($val['val']))
			return $val['val'];
		return false;
		} // insert_macro()

	protected static function insert_macros(&$new_settings) { // reads settings from $_POST and adjusts it to include macros
		if((empty($new_settings)) || (!is_array($new_settings))) return;
		foreach ($new_settings as &$section) {
			if((empty($section)) || (!is_array($section))) continue;
			foreach ($section as $key => &$val) {
				$macro = self::insert_macro($val);
				if ($macro) {
					$section[$key] = $macro;
			} // if
		} // foreach
		} // foreach
		} // insert_macros()

	public static function build_css_css($theme = '') {
		global $cms_left_column, $cms_right_column, $cms_nav_bar, $cms_nav_bar_right;
		Ccms_minify_plugin::expire_cache();
		$cms_left_column = self::get_cms_ini_value('LEFT_COLUMN_BOOL','ThemeSettings');
		$cms_right_column = self::get_cms_ini_value('RIGHT_COLUMN_BOOL','ThemeSettings');
		$cms_nav_bar = self::get_cms_ini_value('NAV_BAR_BOOL','ThemeSettings');
		$cms_nav_bar_right = self::get_cms_ini_value('NAV_BAR_RIGHT_BOOL','ThemeSettings');

		if ((empty($theme)) ||
			(!isset($theme['ThemeSettings'])) ||
			(!is_array($theme['ThemeSettings']))) {
			$theme = self::read_cms_ini_settings(false, self::get_install_ini_sections());
		} // if
		$css_files = array(
			'cms_styles_main',
			'cms_styles_block',
			'cms_styles_inline',
		);
		$ok = true;
		foreach ($css_files as $css) {
			$gen_note = 'CSS file generated on ' . self::get_gm_datetime() . PHP_EOL;
			ob_start();
			include(CMS_FS_CSS_DIR . $css . '.css.php');
			$text = ob_get_clean();
			$out = ETC_FS_CSS_DIR . '' . $css . '.css';
			if ((!empty($text)) &&
				($fh = self::file_safe_wopen($out, 'w'))) {
				fwrite($fh, $text);
				self::file_safe_wclose($fh, $out);
				self::addMsg('Updated ' . $css . '.css', 'success');
				} // if
			else {
				$ok = false;
				self::addAdminMsg('Failed to update ' . $css . '.css');
			} // else
		} // foreach
		if(!@Ccms_apps::gen_app_css()) $ok = false;
		return $ok;
		} // build_css_css()

	public static function get_install_ini_sections() {
		if(Ccms_base::is_debug()) {
			return array('GlobalIniSettings','CommonSettings', 'ServerSettings', 'LanguageSettings','CRONsettings', 'WsServersSettings' ,'ExtLibSettings','SessionSettings', 'DataBaseAccess',
				'AppsControlSettings', 'AuthSettings','ActionTanslations','AppsCMSupdater','TestDebugSettings');
			} // if
		return array('GlobalIniSettings','CommonSettings', 'ServerSettings', 'LanguageSettings', 'CRONsettings', 'WsServersSettings' ,'ExtLibSettings','SessionSettings', 'DataBaseAccess',
			'AppsControlSettings', 'AuthSettings','ActionTanslations','AppsCMSupdater');
		} // get_install_ini_sections()

	public static function get_theme_ini_sections() {
		return array('ThemeSettings', 'CustomThemeSettings');
		} // get_theme_ini_sections()

	public static function read_cms_ini_settings($verbose = true, $exclude_sects = '') { // and sub defaults
		if (!is_readable(ETC_FS_CMS_CONFIG))
			$settings = false;
		else {
			$settings = self::parse_ini_file(ETC_FS_CMS_CONFIG, true);
			} // else
		if (!is_readable(CMS_FS_CMS_CONFIG_DEFAULT))
			$settings_default = false;
		else {
			$settings_default = self::parse_ini_file(CMS_FS_CMS_CONFIG_DEFAULT, true,true);
			} // else
		if (((empty($settings) || !is_array($settings)) &&
			((empty($settings_default)) || !is_array($settings_default)))) {
			echo "ERROR: Failed to read settings " . basename(ETC_FS_CMS_CONFIG) . ' and default ' . basename(CMS_FS_CMS_CONFIG_DEFAULT) . "." . CMS_NL;
			exit(100);
		} // if
		if (((empty($settings) || !is_array($settings)) &&
			(!empty($settings_default)) && is_array($settings_default))) {
			$settings = $settings_default;
			if ($verbose)
				self::addAdminMsg("Using default settings " . basename(CMS_FS_CMS_CONFIG_DEFAULT) . ".", 'warning');
			} // if
		else if (((empty($settings_default) || !is_array($settings_default)) &&
			(!empty($settings)) && is_array($settings))) {
			$settings_default = $settings;
			if ($verbose)
				self::addAdminMsg("No default settings " . basename(CMS_FS_CMS_CONFIG_DEFAULT) . ". (Copy " . basename(ETC_FS_CMS_CONFIG) . " to " . basename(CMS_FS_CMS_CONFIG_DEFAULT) . " as a safe guard.)", 'warning');
			} // if
		if(self::getDottedKeys2Var($settings,'TestDebugSettings.DEBUG_BOOL') == 'true') {	// don't call Ccms_base::is_debug(), it will cause an infinite loop
			// check for missing sections and keys (and values)
			$defaults = array();
			foreach ($settings_default as $sect_name => &$sect) {
				if(preg_match('/^_/',$sect_name)) continue;	// system section
				if ((is_array($exclude_sects)) && (in_array($sect_name, $exclude_sects))) {
					unset($settings[$sect_name]);
					continue;
					} // if
				if(empty($settings[$sect_name])) {	// new/missing section
					$settings[$sect_name] = $sect;	// put the default values in
					self::log_msg('Missing CMS INI section: ' . $sect_name . ', using default.', 'warn');
					$defaults[] = 'Added section: ' . $sect_name . ', ';
					continue;
					} // if
				foreach ($sect as $key => $val) {
					if(!isset($settings[$sect_name][$key])) {	// new/missing section
						$settings[$sect_name][$key] = $val;	// put the default values in
						self::log_msg('Missing CMS INI section: ' . $sect_name . ', key: ' . $key . ', using default.', 'warn');
						$defaults[] = '[' . $sect_name . '][' . $key . ']=' . $val;
						continue;
						} // if
					} // foreach
				} // foreach

			if(($verbose) && (!empty($defaults))) {
				self::addAdminMsg("Using: " . PHP_EOL . implode(',' . PHP_EOL,$defaults) . PHP_EOL . " default values from " . basename(CMS_FS_CMS_CONFIG_DEFAULT) . ".", 'warning');
				} // if
			if((empty($exclude_sects)) && (empty($defaults)) && (Ccms_base::is_rebuild())) {
				self::write_ini_settings(ETC_FS_CMS_CONFIG,$settings,
					ETC_FS_CONFIG_JSON,
					"; rebuild to insert defaults.");
				}  // if
			} // if
		return $settings;
		} // read_cms_ini_settings()

	public static function reload_ini_default_settings() {
		Ccms_xml_sitemap::reset_xml_sitemap();
		$settings_default = self::parse_ini_file(CMS_FS_CMS_CONFIG_DEFAULT, true);
		if ((file_exists(ETC_FS_CMS_CONFIG)) && // not installing
			($settings = self::parse_ini_file(ETC_FS_CMS_CONFIG, true))) {
			$sections = self::get_install_ini_sections();
			foreach ($sections as $sect) {
				if ((isset($settings[$sect])) && (is_array($settings[$sect])) &&
					(isset($settings_default[$sect])) && (is_array($settings[$sect]))) {
					$settings[$sect] = $settings_default[$sect];
			} // if
		} // foreach
		} // if
		else
			$settings = $settings_default;
		if (!self::save_cms_ini_settings($settings, true))
			return false;
		return true;
		} // reload_ini_default_settings()

	protected static function is_htaccess_regen_reqd($key,$new,$old) {
		static $rgen_keys = array(
			'CMS_C_API_ENABLE',
			'CMS_C_API_REWRITE_NAME',
			'WS_REDIR_ENABLE_BOOL',
			'WS_REDIR_PORT',
			'WS_REDIR_SVR_IP',
			);
		if(!defined('CMS_S_AUTO_GEN_HTACCESS_BOOL')) return false;
		if(!CMS_S_AUTO_GEN_HTACCESS_BOOL) return false;
		if($new == $old) return false;
		$keys = $rgen_keys;
		foreach(Ccms_sm::global_ini_settings() as $k => &$v) {
			$keys[] = $v['key'];
			} // foreach
		if(in_array($key,$keys)) return true;
		return false;
		} // is_htaccess_regen_reqd()

	public static function save_cms_ini_settings(&$new_settings, $always_save = false) {
		require_once(CMS_FS_CLASSES_DIR . 'cms_content_cache.php');	// require when rebuild
		Ccms_content_cache::reset_caches(false);
		$chgd = false;
		$regen_htaccess = array();
		if(!Ccms_base::is_rebuild()) {
			$old_settings = self::read_cms_ini_settings();
			foreach ($old_settings as $sect_name => $section) {
				// put in missings sections
				if (!isset($new_settings[$sect_name])) {
					$new_settings[$sect_name] = $section;
					$chgd = true;
				} // if
			} // foreach
		} // if
		self::insert_macros($new_settings);

		$ini_old = self::read_cms_ini_settings(); // get old file
		$ini_cntl = self::read_cms_ini_comments(); // get control file
		$settings_default = self::parse_ini_file(CMS_FS_CMS_CONFIG_DEFAULT, true);
		foreach ($ini_cntl as $sect_name => &$section) {
			if(preg_match('/^_/',$sect_name)) continue;	// system section
			foreach ($section as $key => $value_comment) {
				if (preg_match('/^_|^comment/i',$key)) continue;
				if ((!isset($new_settings[$sect_name][$key])) ||
					(empty($new_settings[$sect_name][$key]))) {
					$new_value = '';
					if(isset($settings_default[$sect_name][$key])) {
						$new_value = $settings_default[$sect_name][$key];
						$new_value = self::replace_constants_ini_data($new_value);
						$new_settings[$sect_name][$key] = $new_value;
						if(!empty($new_value)) {	// is an vale by default
							if(self::is_htaccess_regen_reqd($key, $new_value, "")) $regen_htaccess['CMS_S_' . $key] = $new_value;
							self::addAdminMsg('Restore cms default; ' . Ccms::unmake_hungarion_fmt($sect_name) . ', ' . Ccms::make_nice_name($key) . ' = "' . $new_value . '".', 'info');
							$chgd = true;
							} // if
						} // if
					} // if
				else {
					$new_value = $new_settings[$sect_name][$key];
					} // else

				if ($sect_name != 'ThemeSettings') {
					if ($new_value == '0')
						$new_value = 'false';
					if ($new_value == '1')
						$new_value = 'true';
			} // if

				if (Ccms_base::is_macro_lookup($sect_name, $new_value)) {
					if ((!self::get_macro_lookup($sect_name, $section, $key, $new_value)) &&
						(!empty($settings_default[$sect_name][$key]))) {
						$macro = $new_value;
						$new_value = $settings_default[$sect_name][$key];
						$new_settings[$sect_name][$key] = $new_value;
						self::addAdminMsg('Bad macro expansion, using default; ' . Ccms::unmake_hungarion_fmt($sect_name) . ', ' . Ccms::make_nice_name($key) . ' = "' . $new_value . '" (was "' . $macro . '").', 'info');
						$chgd = true;
						} // if
					} // if
				if(!empty($ini_old[$sect_name][$key])) {
					$old_value = $ini_old[$sect_name][$key];
					if(self::is_htaccess_regen_reqd($key, $new_value, $old_value)) $regen_htaccess['CMS_S_' . $key] = $new_value;
					} // if
				$new_settings[$sect_name][$key] = $new_value;
				} // foreach
			} // foreach
		if((empty($new_settings)) || (!is_array($new_settings))) {
			self::addAdminMsg('Failed to process new ' . CMS_PROJECT_SHORTNAME . ' settings.');
			return false;
			} // if

		if ((!$chgd) && (!$always_save) && (!Ccms_base::is_rebuild())) {
			$cmp = self::cmp_arrays($new_settings, $old_settings);
			if ($cmp == 0) {
				self::addAdminMsg('Unchanged ' . CMS_PROJECT_SHORTNAME . ' INI file.', 'info');
				return true;
				} // if
			} // if

		$hc = '; Copyright: ' . CMS_C_CO_NAME . ' ' . date('Y') . PHP_EOL .
			'; Contains non database ' . CMS_PROJECT_SHORTNAME . ' ' . CMS_PROJECT_VERSION . ' settings.' . PHP_EOL .
			'; Date: ' . self::get_gm_datetime() . PHP_EOL;

		if(!self::write_ini_settings(ETC_FS_CMS_CONFIG,$new_settings,ETC_FS_CONFIG_JSON,$hc)) return false;

		Ccms_content_cache::reset_caches();
		Ccms_gotcha_plugin::reset_cache();
		Ccms_proxy::clear_signats();
		Ccms_minify_plugin::reset_cache();
		if((!empty($regen_htaccess)) &&
			(Ccms::rebuild_docroot_htaccess($regen_htaccess))) {
			self::addAdminMsg('Automatically rebuilt (DOCROOT)/.htaccess for setting change/s.', 'warn');
			} // if
		return self::build_css_css($new_settings);
		} // save_cms_ini_settings()

	protected static function write_ini_settings($ini,$new_settings,$json = false,$hc = false) {
		$fh = self::file_safe_wopen($ini, 'w');
		if (!$fh) {
			self::log_msg('ERROR: Failed to open "' . $ini . '" for save.');
			self::addAdminMsg('Failed to open "' . basename($ini) . '" for save.');
			return false;
			} // if
		else {
			if ((!empty($hc)) && (!fwrite($fh, $hc . PHP_EOL))) {
				self::log_msg('ERROR: Failed to save comments in "' . basename($ini) . '".');
				self::addAdminMsg('Failed to save comments in "' . basename($ini) . '".');
				return false;
				} // if
			else {
				foreach ($new_settings as $sect_name => &$section) {
					fwrite($fh, '[' . $sect_name . ']' . PHP_EOL);
					foreach ($section as $key => $new_value) {
						$safe_text = html_entity_decode($new_value);
						$safe_text = preg_replace('/\\\\/', '\\', $safe_text);
						$safe_text = addcslashes($safe_text, '"\\');
						fwrite($fh, $key . ' = "' . $safe_text . '"' . PHP_EOL);
						} // foreach
					fwrite($fh, PHP_EOL);
					} // foreach
				fwrite($fh, '; eof' . PHP_EOL);
				self::file_safe_wclose($fh, $ini);
				self::log_msg('INFO: Saved in "' . basename($ini) . '".');
				self::addAdminMsg('Saved settings in "' . basename($ini) . '".', 'success');
				if($json) self::save_json($json, $new_settings);
				} // else
			} // else
		return true;
		} // write_ini_settings()

	public static function read_cms_ini_comments($verbose = true, $exclude_sects = '') { // and sub defaults
		$comments = self::parse_ini_file(CMS_FS_CMS_CONFIG_MSGS, true,true);
		if (((empty($comments) || !is_array($comments)) &&
			((empty($comments_default)) || !is_array($comments_default)))) {
			echo "ERROR: Failed to read comments INI controls " . basename(CMS_FS_CMS_CONFIG_MSGS) . "." . CMS_NL;
			exit(100);
			} // if
		if (is_array($exclude_sects)) {
			foreach ($comments as $sect_name => $sect) {
				if (in_array($sect_name, $exclude_sects)) {
					unset($comments[$sect_name]);
					continue;
				} // if
			} // foreach
		} // if
		return $comments;
		} // read_cms_ini_comments()

	public static function get_cms_ini_value($key, $sect_name = false) { // get from the ini file directly
		if (self::$cms_ini === false) {
			self::$cms_ini = self::read_cms_ini_settings(); // cache
		} // if
		if ((empty($sect_name)) || ($sect_name == '*')) { // flat lookup required (uniqueness required per manual)
			// slow way
			if (self::$cms_ini_flat === false) {
				self::$cms_ini_flat = array(); // cache
				foreach (self::$cms_ini as $sect_nm => &$sect) {
					foreach ($sect as $k => &$v) {
						self::$cms_ini_flat[$k] = $v;
						} // foreach
					} // foreach
				} // if
			if (!isset(self::$cms_ini_flat[$key]))
				return null;
			$value = self::$cms_ini_flat[$key];
		} // if
		else { // normal lookup
			if (!isset(self::$cms_ini[$sect_name][$key]))
				return null;
			$value = self::$cms_ini[$sect_name][$key];
		} // else

		if (is_numeric($value))
			return $value;

		$value = self::get_macro_lookup($sect_name, self::$cms_ini[$sect_name], $key, $value);
		$val = self::conv_conf_val_to_type($value);
		return $val;
		} // get_cms_ini_value()

	public static function set_cms_ini_value($key, $value, $sect_name = false) { // set the ini file directly
		$cms_ini = self::read_cms_ini_settings(); // cache
		foreach ($cms_ini as $sect_nm => &$sect) {
			foreach ($sect as $k => &$v) {
				if ((!empty($sect_name)) && ($sect_name != $sect_nm)) continue;
				if($k == $key) {
					$cms_ini[$sect_nm][$key] = $value;
					return self::save_cms_ini_settings($cms_ini,true);
					} // if
				} // foreach
			} // foreach
		return false;
		} // set_cms_ini_value()

	public static function get_cms_config_value($key) { // get from the DB directly
		if (defined($key))
			return constant($key);
		if (!self::$cDBcms)
			return false; // setup not read in yet (i.e. does know the setting for DB)
		$value = self::$cDBcms->get_data_in_table('cms_configs', 'cms_config_value', "cms_config_key = '" . $key . "'");
		if (!$value)
			return null; // error
		if (is_numeric($value))
			return $value;
		switch (strtolower($value)) {
			case 'false': return false;
			case 'true': return true;
			default: break;
		} // switch
		return $value;
		} // get_cms_config_value()

	public static function set_cms_config_value($key,$value) { // get from the DB directly
		if (!self::$cDBcms)
			return false; // setup not read in yet (i.e. does know the setting for DB)
		if(!self::$cDBcms->set_data_in_table('cms_configs', 'cms_config_value', $value, "cms_config_key = '" . $key . "'")) return false;
		if((self::is_htaccess_regen_reqd($key, $value, "")) &&
			(Ccms::rebuild_docroot_htaccess(array($key => $value)))) {
			self::addAdminMsg('Automatically rebuilt (DOCROOT)/.htaccess for config change to: ' . $key, 'warn');
			} // if
		return true;
		} // set_cms_config_value()

	public static function get_cms_config_name($key) { // get from the DB directly
		if (!self::$cDBcms)
			return false; // setup not read in yet (i.e. does know the setting for DB)
		$value = self::$cDBcms->get_data_in_table('cms_configs', 'cms_config_name', "cms_config_key = '" . $key . "'");
		return $value;
		} // get_cms_config_name()

	public static function clean_path($path) { // the file path
		// leave the dot dot slash $text = preg_replace('/[\/]+|[\/]+\.|\.[\/]+/','/',$path);
		$text = preg_replace('/([^:])[\/]{2,}/', '$1/', $path);
		return $text;
		} // clean_path()

	public static function get_max_upload_size() {
		$post_size = self::hstring2int(ini_get('post_max_size'));
		$upload_size = self::hstring2int(ini_get('upload_max_filesize'));
		return (($post_size < $upload_size) ? $post_size : $upload_size);
		} // get_max_upload_size()

	public static function is_file_usable($path) {
		$bf = basename($path);
		if (preg_match('/\.gitignore$|\.htaccess$/', $bf))
			return false; // generally ignored
		if (preg_match('/^[\._]/', $bf))
			return false; // system / hidden name
		return true;
		} // is_file_usable()

	public static function is_dir_usable($dir) {
		if (preg_match(CMS_DONT_ACCESS_PATH_PATTERN, $dir))
			return false;
		return Ccms_base::is_file_usable($dir);
		} // is_dir_usable()

	private static function do_no_clobber_shuffle_down($dir_name, $max_cnt, $extension) {
		// shuffle down no clobber file
		$m_cnt = 0;
		$cnt = 0;
		while($cnt <= $max_cnt) {
			$src = $dir_name . '(' . ++$cnt . ').' . $extension;
			if(!file_exists($src)) continue;
			if((time() - fileatime($src)) < self::NO_CLOBBER_FREE_SECS) continue;	// probably in use
			if($cnt > 1) $dest = $dir_name . '(' . ($cnt - 1) . ').' . $extension;
			else $dest = $dir_name . '.' . $extension;	// last file
			if((file_exists($dest)) && ((time() - fileatime($dest)) < self::NO_CLOBBER_FREE_SECS)) continue;	// probably in use
			else {
				@rename($src, $dest);
				$m_cnt++;
				} // else
			} // while
		return $m_cnt;
		} // do_no_clobber_shuffle_down()

	protected static function do_file_safe_no_clobber($filepath, $no_clobber, $max_no_clobber) {
		if ((!$no_clobber) || (!file_exists($filepath)))
			return false;
		// don't clobber existing files
		if(empty($max_no_clobber))	$max_no_clobber = self::MAX_NO_CLOBBER_DEF;
		$path_parts = pathinfo($filepath);
		$filename_copy = $filepath;
		$cnt = 0;
		while (file_exists($filename_copy)) {
			// make a copy number string.
			$cnt++;
			$filename_copy = $path_parts['dirname'] . '/' . $path_parts['filename'] . '(' . $cnt . ').' . $path_parts['extension'];
			if($cnt >= $max_no_clobber) {
				self::do_no_clobber_shuffle_down($path_parts['dirname'] . '/' . $path_parts['filename'], $cnt, $path_parts['extension']);	// do the clobber shuffle
				$cnt = 0;	// restart, not files may have been moved
				} // if
		} // while

		if ($fp = @fopen($filepath, 'a')) {
			// $t = microtime();	// test
			$start_uS = self::get_us_timestamp();
			flock($fp, LOCK_UN);
			do {
				$writeable = flock($fp, (LOCK_EX | LOCK_NB));
				if (!$writeable)
					usleep(round(rand(0, 100) * 1000)); // microseconds * (0 to 100) * 1000
				} while ((!$writeable) && ((self::get_us_timestamp() - $start_uS) < 500000)); // with timeout 0.5 seconds
			//file was locked so now we can store information
			flock($fp, LOCK_UN);
			fclose($fp);
		} //if
		if (@rename($filepath, $filename_copy) === false) {
			self::log_msg('WARNING: Failed to move no clobber backup of "' . $filepath . '" to "' . $filename_copy . '".');
			return false;
		} // if
		self::chmod_chown($filename_copy, false);

		return true;
		} // do_file_safe_no_clobber()

	public static function file_safe_wopen($filepath, $mode = 'w', $no_clobber = false, $max_no_clobber = false) {
		self::do_file_safe_no_clobber($filepath, $no_clobber, $max_no_clobber);

		if ($fp = @fopen($filepath, $mode)) {
			$start_uS = self::get_us_timestamp();
			do {
				$writeable = flock($fp, (LOCK_EX | LOCK_NB));
				if (!$writeable)
					usleep(round(rand(0, 100) * 1000)); // microseconds * (0 to 100) * 1000
				} while ((!$writeable) && ((self::get_us_timestamp() - $start_uS) < 500000)); // with timeout 0.5 seconds
			//file was locked so now we can store information
			if ($writeable)
				return $fp; // ready
			fclose($fp);
			} //if
		return false; // failed
		} // file_safe_wopen()

	public static function file_safe_wclose($fp, $filepath = false) {
		if ((flock($fp, LOCK_UN) === false) ||
			(fclose($fp) === false))
			return false; // what, file already closed ??
		if (($filepath) && (!self::chmod_chown($filepath, false)))
			return false;
		return true; // closed
		} // file_safe_wclose()

	public static function file_safe_write($filepath, $data, $no_clobber = false, $max_no_clobber = false) {
		self::do_file_safe_no_clobber($filepath, $no_clobber, $max_no_clobber);

		if ($fp = @fopen($filepath, 'w')) {
			$start_uS = self::get_us_timestamp();
			do {
				$writeable = flock($fp, (LOCK_EX | LOCK_NB));
				if (!$writeable)
					usleep(round(rand(0, 100) * 1000)); // microseconds * (0 to 100) * 1000
		} while ((!$writeable) && ((self::get_us_timestamp() - $start_uS) < 500000)); // with timeout 0.5 seconds
			//file was locked so now we can store information
			if (($writeable) &&
				(fwrite($fp, $data) !== false)) {
				flock($fp, LOCK_UN);
				fclose($fp);
				self::chmod_chown($filepath, false);
				return true; // saved
		} // if
			fclose($fp);
		} //if

		return false; // failed
		} // file_safe_write()

	public static function write_ini($array, $file, $comment = false) {
		$res = array();
		if (!empty($comment)) {
			// make multi lines into comment lines
			$com_tmp = '; ' . preg_replace('/\r\n|\n\r|\n|\r/', PHP_EOL . '; ', $comment);
			$res = explode(PHP_EOL, $com_tmp);
		} // if
		foreach ($array as $key => $val) {
			if (is_array($val)) {
				$res[] = "[$key]";
				foreach ($val as $skey => $sval) {
					$res[] = "$skey = " . (is_numeric($sval) ? $sval : '"' . $sval . '"');
			} // foreach
		} // if
			else
				$res[] = "$key = " . (is_numeric($val) ? $val : '"' . $val . '"');
		} // foreach
		self::file_safe_write($file, implode(PHP_EOL, $res));
		} // write_ini()

	public static function read_csv($sorc) {
		// reads a csv file into keyed (by column name) array
		$f_a = array();
		self::set_chk_php_value('auto_detect_line_endings', true);
		if ((is_readable($sorc)) && (($fh = @fopen($sorc, "r")) !== false)) {
			while (($data = fgetcsv($fh, 4096, ",")) !== false) {
				if ($data === null)
					continue; // blank line
				$f_a[] = $data;
		} // while
			fclose($fh);
			return $f_a;
		} // if
		return false;
		} // read_csv()

	public static function save_csv($dest, $list) {
		if ((is_writeable($dest)) && (($fh = self::file_safe_wopen($dest, 'w')) !== false)) {
			foreach ($list as $fields) {
				if (fputcsv($fh, $fields) === false)
					break;
		} // foreach
			self::file_safe_wclose($fh, $dest);
			return true;
		} // if
		return false;
		} // save_csv()

	public static function read_keyed_csv($sorc, $has_heading = true, $col_sep = ',', $col_enc = '"') {
		// a keyed for csv is same 2 dimensional json
		// reads a csv file into keyed (by column name) array
		$row = 0;
		$idx = 0;
		$k_a = array();
		$head_row = false;
		self::set_chk_php_value('auto_detect_line_endings', true);
		if ((is_readable($sorc)) && (($fh = @fopen($sorc, "r")) !== false)) {
			while (($data = fgetcsv($fh, 4096, $col_sep, $col_enc)) !== false) {
				if($data === null) continue; // blank line
				if((!empty($data[0])) && (preg_match('/^[#;]/',$data[0]))) continue;	//comment
				$row++;
				$ok = true;
				if ($has_heading) {
					if ($row == 1) { // first ir heading row
						// heading row
						$head_row = $data; // save atm
						continue;
						} // if
					$k_a[] = array_combine($head_row, $data);
//					$col = 0;
//					foreach ($head_row as $h) {
//						if (!isset($data[$col])) {
//							$ok = false;
//							break;
//							} // if
//						$k_a[$h][$idx] = $data[$col++];
//						} //  foreach
					} // if
				else { // just enumerate (bad csv)
					for ($i = 0; $i < count($data); $i++) {
						if (!isset($data[$i])) {
							$ok = false;
							break;
							}
						$k_a[$i][$idx] = $data[$col++];
						} // for
					} // else
				if (!$ok) { // remove bad row
					foreach ($head_row as $h) {
						unset($k_a[$h][$idx]);
						} //  foreach
					continue;
					} // if
				$idx++;
				} // while
				fclose($fh);
				return $k_a;
			} // if
		return false;
		} // read_keyed_csv()

	public static function save_keyed_csv($dest, $k_a, $has_heading = true) {
		// a keyed for csv is same 2 dimensional json
		// saves keyed (by column name) array to a csv files (there is a 2 dimensional limitations to csv)
		if ((is_writeable($dest)) && (($fh = self::file_safe_wopen($dest, 'w')) !== false)) {
			$row = 1;
			$idx = 0;
			$cols = 0;
			$heading = array();
			if ($has_heading) {
				// output heading
				foreach ($k_a as $h => &$v) {
					$heading[] = $h;
					$cols++;
			} // foreach
				if (fputcsv($fh, $heading) === false) {
					self::file_safe_wclose($fh, $dest);
					return false;
			} // if
				$row++;
		} // if
			else
				$cols = count($k_a);

			$done = false;
			do {
				$data = array();
				for ($col = 0; $col < $cols; $col++) {
					$hd = ($has_heading ? $heading[$col] : $col);
					if (!isset($k_a[$hd][$idx]))
						$done = true;
					else
						$data[$col] = $k_a[$hd][$idx];
			} // for
				if ((!$done) && (fputcsv($fh, $data) === false)) {
					fclose($fh);
					return false;
			} // if
				$idx++;
				$row++;
		} while ((!$done));
			file_safe_wclose($fh, $dest);
			return true;
		} // if
		return false;
		} // save_keyed_csv()

	protected static function json_text_pretty($json, $html = false) { // pretty print json for PHP 5.3 or less
		// from "https://gist.github.com/drazisil/eda9065698dd0beedede"
		$tabcount = 0;
		$result = '';
		$inquote = false;
		$ignorenext = false;

		if ($html) {
			$tab = "&nbsp;&nbsp;&nbsp;";
			$newline = "<br/>";
		} else {
			$tab = "\t";
			$newline = PHP_EOL;
		}

		for ($i = 0; $i < strlen($json); $i++) {
			$char = $json[$i];

			if ($ignorenext) {
				$result .= $char;
				$ignorenext = false;
		} else {
				switch ($char) {
					case '[':
					case '{':
						if (!$inquote) {
							$tabcount++;
							$result .= $char . $newline . str_repeat($tab, $tabcount);
					} // if
						else
							$result .= $char;
						break;
					case ']':
					case '}':
						if (!$inquote) {
							$tabcount--;
							$result = trim($result) . $newline . str_repeat($tab, $tabcount) . $char;
					} // if
						else
							$result .= $char;
						break;
					case ',':
						if (!$inquote) {
							$result .= $char . $newline . str_repeat($tab, $tabcount);
					} // if
						else
							$result .= $char;
						break;
					case '"':
						$inquote = !$inquote;
						$result .= $char;
						break;
					case '\\':
						if ($inquote)
							$ignorenext = true;
						$result .= $char;
						break;
					default:
						$result .= $char;
			}
		}
		}
		return $result;
		} // json_text_pretty()

	public static function flatten_array(&$array) {
		if (!is_array($array))
			return array(); // a flat array ??

		$result = array();
		foreach ($array as $key => $value) {
			if (is_array($value))
				$result = array_merge($result, self::flatten_array($value)); // recurse
			else
				$result = array_merge($result, array($key => $value));
		} // foreach
		return $result;
		} // flatten_array()

	public static function clean_array($grid, $remove_all_mt = true) { // clean out dead empty rows
		if (!is_array($grid))
			return array();
		$old_grid = $grid;
		$new_grid = array();
		for ($i = 0; $i < count($old_grid); $i++) {
			if (is_array($old_grid[$i])) { // has a sub-array
				$min = count($old_grid[$i]);
				$mt = false;
				foreach ($old_grid[$i] as $k => $j) {
					if (!$remove_all_mt) {
						if (empty($j)) {
							$mt = true; // set flg
							} // if
						else {
							$mt = false;
							break;
							} // else
						} // if
					else {
						if (empty($j)) {
							$mt = true; // set flg
							break;
							} // if
						} // else
					} // foreach
				if (!$mt)
					$new_grid[] = $old_grid[$i];
				continue;
				} // if
			if(is_array($old_grid[$i])) {
				$filtd = array_filter($old_grid[$i]);	// remove false entries
				if (empty($filtd))
					continue;
				} // if
			$new_grid[] = $old_grid[$i];
		} // for
		return $new_grid;
		} // clean_array()

	public static function is_key_in_array($key, &$array) { // better is_array() check with key checks
		if (!is_array($array))
			return false;
		if (!array_key_exists($key, $array))
			return false;
		return true;
		} // is_key_in_array()

	public static function is_key_array($key, &$array) { // better is_array() check with key checks
		if (!is_array($array))
			return false;
		if (!array_key_exists($key, $array))
			return false;
		if (!is_array($array[$key]))
			return false;
		return true;
		} // is_key_array()

	public static function is_in_array($value, &$array) { // better in_array() check with key checks
		if (!is_array($array))
			return false;
		if (!in_array($value, $array))
			return false;
		return true;
		} // is_in_array()

	private static function cmp_array_sect(&$v, &$y) {
		if ((is_array($v)) && (is_array($y))) {
			$cmp = self::cmp_arrays($v, $y);
			if ($cmp != 0)
				return $cmp;
		} // if
		else if ((is_array($v)) && (!is_array($y))) {
			return 1;
		} // else if
		else if ((!is_array($v)) && (is_array($y))) {
			return -1;
		} // else if
		else { // a string
			$cmp = strcmp($v, $y);
			if ($cmp != 0)
				return $cmp;
		} // else
		return 0;
		} // cmp_array_sect()

	public static function cmp_arrays(&$a, &$b) {
		// do $a first
		foreach ($a as $k => &$v) {
			if (!Ccms_base::is_key_in_array($k, $b))
				return 1;
			$y = &$b[$k];
			$cmp = self::cmp_array_sect($v, $y);
			if ($cmp != 0)
				return $cmp;
		} // foreach
		// now do $b in case some values are missing from $a
		foreach ($b as $k => &$v) {
			if (!Ccms_base::is_key_in_array($k, $a))
				return 1;
			$y = &$a[$k];
			$cmp = self::cmp_array_sect($v, $y);
			if ($cmp != 0)
				return $cmp;
		} // foreach

		return 0; // equall
		} // cmp_arrays()

	public static function ini_num_str2int($val_str) {
		$val_str = trim($val_str);
		if(is_numeric($val_str)) return (int)$val_str;	// no suffix
		if(preg_match('/[^0-9]+[^EPTGMK]$/',$val_str)) return false;	// !number
		$num = (int)substr($val_str,0,-1);
		$last = strtoupper($val_str[(strlen($val_str) - 1)]);
		switch($last) {
		case 'E':	// exa
		  $num = $num * 1024;
		case 'P':	// peta
		  $num = $num * 1024;
		case 'T':	// tera
		  $num = $num * 1024;
		case 'G':	// giga
		  $num = $num * 1024;
		case 'M':	// mega
		  $num = $num * 1024;
		case 'K':	// kilo
		  $num = $num * 1024;
		default:
			break;
			} // switch
		return $num;
		} // ini_num_str2int()

	protected static function log_json_error($errno = JSON_ERROR_NONE) {
		if($errno == JSON_ERROR_NONE) $errno = json_last_error();
		if($errno == JSON_ERROR_NONE) return;	// 'No error'
		// json_last_error_msg() ??
		$err_msgs = array(	// see "https://www.php.net/manual/en/function.json-last-error-msg.php"
			JSON_ERROR_NONE => 'JSON: No error',
			JSON_ERROR_DEPTH => 'JSON: Maximum stack depth exceeded',
			JSON_ERROR_STATE_MISMATCH => 'JSON: State mismatch (invalid or malformed JSON)',
			JSON_ERROR_CTRL_CHAR => 'JSON: Control character error, possibly incorrectly encoded',
			JSON_ERROR_SYNTAX => 'JSON: Syntax error',
			JSON_ERROR_UTF8 => 'JSON: Malformed UTF-8 characters, possibly incorrectly encoded'
			);
		if(isset($err_msgs[$errno])) $msg = $err_msgs[$errno];
		else $msg = 'Unknown JSON error: ' . $errno;
		self::addDebugMsg($msg);
		} // log_json_error()

	public static function json_decode($json,$associative = null,$depth = 512,$flags = 0) {
		// json_decode with error handles
		if(empty($json)) return array();
		$obj = json_decode($json,$associative,$depth,$flags);
		if ($errno = json_last_error()) self::log_json_error($errno);
		if(is_null($obj)) {
			self::addDebugMsg('Null result with non-null JSON');
			$obj = array();
			} // else if
		return $obj;
		} // json_decode()

	public static function json_encode($obj) {
		// self::json_encode with error handles
		$json = json_encode($obj, (JSON_PRETTY_PRINT));
		if ($errno = json_last_error()) self::log_json_error($errno);
		else if ($json === 'null' && $obj !== null) {
			self::addDebugMsg('Null result with non-null object');
			} // else if
		return $json;
		} // json_encode()

	public static function save_json($dest, &$data_ary_obj, $no_clobber = false, $pretty_print = true, $always_save = false) {
		if (empty($dest))
			return false;
		if(is_object($data_ary_obj)) $data_ary = get_object_vars($data_ary_obj);	// loose ref
		else $data_ary = $data_ary_obj;	// keep ref
		$dest = self::clean_path($dest);
		if ((!is_writable($dest)) && (!is_writable(dirname($dest)))) {
			self::log_msg('ERROR: JSON destination "' . $dest . '" not writeable.');
			return false;
		} // if
		unset($data_ary['JSON_ModTime']); // remove old version
		unset($data_ary['JSON_ModUser']); // remove old version

		if ((!$always_save) &&
			($cur_json = self::load_json($dest))) { // check if data has changed
			unset($data_ary['_JSON_ModTime']); // remove for cmp
			unset($data_ary['_JSON_ModUser']); // remove for cmp
			unset($cur_json['_JSON_ModTime']); // remove for cmp
			unset($cur_json['_JSON_ModUser']); // remove for cmp
			$cmp = self::cmp_arrays($cur_json, $data_ary);
			if($cmp == 0) {
				if (Ccms_base::is_debug())
					self::log_msg('INFO: Unchanged JSON "' . $dest . '" not saved.');
				return true;
				} // if
		} // if
		$data_ary['_JSON_ModTime'] = time();	// self::get_gm_datetime();
		$data_ary['_JSON_ModUser'] = Ccms_base::get_logged_in_username();

		if ($pretty_print) {
			if (version_compare(PHP_VERSION, '5.4.0') >= 0) {
			$json = self::json_encode($data_ary, (JSON_PRETTY_PRINT)) . PHP_EOL;
			} // if
		else {
			// no pretty print option < PHP 5.4
			$json = self::json_encode($data_ary);
			$json = self::json_text_pretty($json) . PHP_EOL;
			} // else
		} // if
		else
			$json = self::json_encode($data_ary) . PHP_EOL;
		if (self::file_safe_write($dest, $json, $no_clobber) === false) {
			self::log_msg('ERROR: Failed to save JSON "' . $dest . '".');
			return false;
		} // if
		// else ok
		self::chmod_chown($dest);
		return true;
		} // save_json()

	public static function merge_save_json($dest, &$data_ary) {
		if ($orig_ary = self::load_json($dest)) {
			$new_ary = array_merge($orig_ary, $data_ary);
			return self::save_json($dest, $new_ary);
		} // if
		return self::save_json($dest, $data_ary);
		} // merge_save_json()

	private static function inc_merge_jsons(&$data_ary, &$path) {  // merge include json files
		static $depth = 0;
		// recursively merge include json files
		$data_merged_arry = array();
		$depth++;
		if ($depth > 10) {
			self::addDebugMsg('Recursion depth in ' . __METHOD__ . ' greater than 10.');
			return null;
		} // if
		foreach ($data_ary as $s => &$v) {
			if (is_array($v)) {
				$w = self::inc_merge_jsons($v, $path);
				if (is_null($w)) {
					return null;
			} // if
				if (!Ccms_base::is_key_in_array($s, $data_merged_arry))
					$data_merged_arry[$s] = array();
				$data = array_merge($data_merged_arry[$s], $w);
				$data_merged_arry[$s] = $data;
		} // if
			else if ((is_string($s)) && ($s == '_inc_json_file')) {
				if (!isset(self::$cms_json_buffer[$v])) {
					$inc_file = $path . '/' . $v;
					if ((!file_exists($inc_file)) || (!is_readable($inc_file))) {
						self::addAdminMsg('Cannot find "' . $v . '" in ' . __METHOD__ . '.');
						return null;
				} // if
					self::$cms_json_buffer[$v] = self::load_json(($path . '/' . $v), true);
					if (!self::$cms_json_buffer[$v]) {
						self::addAdminMsg('Cannot read "' . $v . '" in ' . __METHOD__ . '.');
						return null;
				} // if
			} // if
				$data = array_merge($data_merged_arry, self::$cms_json_buffer[$v]);
				$data_merged_arry = $data;
		} // else if
			else if ((is_string($s)) && ($s == '_function')) {
				if ((is_string($v)) &&
					($callback = Ccms::get_inc_method_callback($v)) &&
					($data = call_user_func($callback))) {
					$data_merged_arry = array_merge($data_merged_arry, $data);
			} // if
				else {
					self::addAdminMsg('Cannot get data from method "' . $v . '" in ' . __METHOD__ . '.');
					continue;
			} // else
//				if(!isset(self::$cms_json_buffer[$v])) {
//					self::$cms_json_buffer[$v] = self::load_json(($path . '/' . $v),true);
//					if(!self::$cms_json_buffer[$v]) {
//						self::addAdminMsg('Cannot read "' . $v . '" in ' . __METHOD__ . '.');
//						return null;
//					} // if
//				} // if
//				$data = array_merge($data_merged_arry,self::$cms_json_buffer[$v]);
//				$data_merged_arry = $data;
		} // else if
			else
				$data_merged_arry[$s] = $v;
		} // foreach
		$depth--;
		return $data_merged_arry;
		} // inc_merge_jsons()

	public static function load_json($sorc, $do_incs = false) {
		// read a keyed csv
		if ((!empty($sorc)) &&
			(file_exists($sorc)) &&
			(($json = @file_get_contents($sorc)) !== false)) {
			$data_ary = self::json_decode($json, true);
			if (is_null($data_ary)) {
				$err = json_last_error();
				$err_msg = json_last_error_msg();
				self::addDebugMsg('Error in "' . $sorc . '" JSON: "' . $err_msg . '"');
				return false;
				} // if
			if (!$do_incs)
				return $data_ary;
			$path = dirname($sorc);
			$json = self::inc_merge_jsons($data_ary, $path);
			return $json;
		} // if
		// else
		return false;
		} // load_json()

	protected static function &save_multipart_form_upload_contents($elem_name,$type,$filename,&$blk,$data_size = false) {
		// why am I here (bug in php or server probably)

		if(empty($elem_name)) return false;
		if(!self::chkdir(VAR_FS_CACHE_UPLOADS_DIR)) return false;
		if(!self::$cms_uploads_cache) self::$cms_uploads_cache = [];
		$error = UPLOAD_ERR_OK;

		// try to figure out what happened
		$confs = ini_get_all();	// test
		$size = $data_size;
		$max_size = self::ini_num_str2int(ini_get('post_max_size'));
		$tmp_filename = false;
		if(($data_size) && ($data_size >= $max_size)) $error = UPLOAD_ERR_FORM_SIZE;
		else {
			$max_size = self::ini_num_str2int(ini_get('upload_max_filesize'));
			$size = filesize($tmp_filename);
			if($size >= $max_size) $error = UPLOAD_ERR_INI_SIZE;
			else {
				$lines = &explode(PHP_EOL,$blk,5);
				$contents = &$lines[4];
				$tmp_filename = tempnam(VAR_FS_CACHE_UPLOADS_DIR,'cb_');
				if(!file_put_contents($tmp_filename,$contents)) $error = UPLOAD_ERR_CANT_WRITE;
				} // else
			} // else


		self::$cms_uploads_cache[$elem_name] = [
			'type' => $type,
			'filename' => $filename,
			'tmp_filename' => $tmp_filename,
			'size' => $size,
			'max_allowed' => $max_size,
			'error' => $error,
			];

		if(!isset($_FILES[$elem_name])) {	// put in $_FILES
			$_FILES[$elem_name] = [
				'type' => $type,
				'name' => $filename,
				'tmp_name' => $tmp_filename,
				'size' => $size,
				'max_allowed' => $max_size,
				'error' => $error,
				];
			} // if
		return self::$cms_uploads_cache[$elem_name];
		} // save_multipart_form_upload_contents()

	protected static function &get_multipart_form_upload_contents($elem_name) {
		if(empty($elem_name)) return false;
		if(empty(self::$cms_uploads_cache[$elem_name])) {
			self::$cms_uploads_cache[$elem_name] = false;	// make ref
			} // if
		return self::$cms_uploads_cache[$elem_name];
		} // get_multipart_form_upload_contents()

	public static function save_uploaded_file($destpath, $elem_name = 'file', $no_clobber = false, $max_no_clobber = false) {
		if ((isset($_FILES[$elem_name]['name'])) &&
			(!empty($_FILES[$elem_name]['name']))) { // check image location
			$size = (isset($_FILES[$elem_name]['size']) ? $_FILES[$elem_name]['size']:-1);		// browser may not do it's job
			$error = (isset($_FILES[$elem_name]['error']) ? $_FILES[$elem_name]['error']:UPLOAD_ERR_OK);
			switch ($error) {
				case UPLOAD_ERR_OK:
					// There is no error, the file uploaded with success.
					// upload OK
					break;
				case UPLOAD_ERR_INI_SIZE:
					// The uploaded file exceeds the upload_max_filesize directive in php.ini.
					self::addMsg('The uploaded file size: ' . Ccms_base::int2hstring($size) . ' bytes, exceeds the "upload_max_filesize" directive in php configuration.');
					return false;
				case UPLOAD_ERR_FORM_SIZE:
					// The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.
					self::addMsg('The uploaded form size: ' . Ccms_base::int2hstring($size) . ' bytes, exceeds the "post_max_size" directive in php configuration.');
					return false;
				case UPLOAD_ERR_PARTIAL:
					// The uploaded file was only partially uploaded.
					self::addMsg('The uploaded file was only partially uploaded.');
					return false;
				case UPLOAD_ERR_NO_FILE:
					// No file was uploaded.
					self::addMsg('No file was uploaded.');
					return false;
				case UPLOAD_ERR_NO_TMP_DIR:
					// Missing a temporary folder.
					self::addMsg('Missing a temporary folder.');
					return false;
				case UPLOAD_ERR_CANT_WRITE:
					// Failed to write file to disk.
					self::addMsg('Failed to write file to disk.');
					return false;
				case UPLOAD_ERR_EXTENSION:
					// A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help.
					self::addMsg('A PHP extension stopped the file upload.');
					return false;
				default:
					// unknown error
					self::addMsg('Unknown upload error "' . $error . '".');
					return false;
				} // switch

			$tmp_name = $_FILES[$elem_name]['tmp_name'];
			if(pathinfo($destpath, PATHINFO_EXTENSION))	{ // if a file name
				$filename = $destpath;
				} // if
			else {
				$dir = $destpath;
				if (!self::chkdir($dir)) {
					self::addMsg('Failed to create "' . $dir . '" directory.');
					return false;
					} // if
				$filename = self::clean_path($dir . '/' . $_FILES[$elem_name]['name']);
				} // else

			self::do_file_safe_no_clobber($filename, $no_clobber, $max_no_clobber);
			if($multi_up = self::get_multipart_form_upload_contents($elem_name)) {	// try the multipart_form_upload
				self::addAdminMsg('May have failed to meet some upload security requirements, using back up decoding.','warn');	// @TODO what ??

				} //if
			if (move_uploaded_file($tmp_name, $filename)) {
				Ccms::chmod_chown($filename);
				self::addMsg('Uploaded "' . $_FILES[$elem_name]['name'] . '".', 'success');
				return $filename; //done
				} // if
			self::addMsg('Failed upload "' . $_FILES[$elem_name]['name'] . '".');
			} // if
		return false;
		} // save_uploaded_file()

	public static function set_download_dir($dn_path) {	// mostly used with ajax downloads
		self::set_cms_sess_var($dn_path,'download_dir');
		return true;
		} // set_download_dir()

	public static function do_download_file($dn_file = false, $dn_path = false, $delete = false) {
		if (!$dn_path) {
			if (!$dn_path = self::get_cms_sess_var('download_dir'))
				return false; // SESSION used to obviscate path
		} // if

		if (!$dn_file) {
			if ($dn_file = self::get_cms_sess_var('download_file')) {
				self::unset_cms_sess_var('download_file');
				} // if
			else
				$dn_file = Ccms_base::get_or_post('download_file');
		} // if
		if ((!$dn_path) || (!$dn_file))
			return false;
		if (headers_sent()) {
			// self::addMsg('Download error, header already sent.');
			self::set_cms_sess_var($dn_path,'download_dir');
			self::set_cms_sess_var($dn_file,'download_file');
			return true;
		} // if

		$dn_filepath = self::clean_path($dn_path . '/' . $dn_file);
		if (file_exists($dn_filepath)) {
//			self::addMsg('Downloaded &quot;' . $dn_file . '&quot;' . ($delete ? ' and cleaned up':'') . '.','info');
//			Ccms::saveMsgs();
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="' . basename($dn_filepath) . '"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Pragma: public');
			header('Content-Length: ' . filesize($dn_filepath));
			// ob_flush();
			// flush();
			readfile($dn_filepath);
			if ($delete)
				@unlink($dn_filepath);
			exit(0); // do it
		} // if
		else {
			self::addMsg('Cannot find &quot;' . $dn_file . '&quot; to download.');
		} // else
		return false; // no download requested
		} // do_download_file()

	public static function do_redirect_uri($uri = false) {

		if (!$uri) {
			if (!$uri = self::get_cms_sess_var('redirect_uri'))
				return false; // SESSION used to obviscate path
			self::unset_cms_sess_var('redirect_uri');
			if((!empty($_SERVER['SCRIPT_URL'])) && ($_SERVER['SCRIPT_URL'] == $uri)) return true;
			if((!empty($_SERVER['SCRIPT_URI'])) && ($_SERVER['SCRIPT_URI'] == $uri)) return true;
			} // if

		$file = ""; $line = 0;
		if(headers_sent($file,$line)) {
			echo <<< EOTRED

				<script type="text/javascript">
					window.location = "{$uri}";
				</script>

EOTRED;
			self::set_cms_sess_var($uri,'redirect_uri');
			} // if
		else {
			self::log_debug_msg('Redirect to: ' . $uri,'info');
			header('Location: ' . $uri);
			exit(0);
			}
		return false; // wait for page reload
		} // do_redirect_uri()

	public static function trash_path($path, $compress = false, $trash_dir = false) {
		if (!file_exists($path))
			return false;
		$retVal = false;
		if (empty($trash_dir))
			$trash_dir = VAR_FS_TRASH_DIR;
		else
			$trash_dir .= '/';

		if (($compress) && (is_file($path)) && (!preg_match('/\.zip$|\.gz$/i', $path))) {
			$file = basename($path);
			$date = date('Ymd-hms');
			$old_file = preg_replace('/(\.[^.]+)$/', '-' . $date . '\1', $file);
			$gz = $trash_dir . $old_file . '.gz';
			if ($fh = self::file_safe_wopen($gz, 'w')) {
				if (fwrite($fh, gzencode(file_get_contents($path), 9)) !== false) {
					@unlink($path);
					self::addMsg('Commpressed and moved &quot;' . $file . '&quot; to Trash.', 'info');
					$retVal = true;
					} // if
				self::file_safe_wclose($fh, $gz);
				} // if
			} // if
		else {
			// align base directories for trash, if possible
			$trash_parts = explode('/', $trash_dir);
			$path_parts = explode('/', dirname($path));
			$dest_dir = '';
			$j = 0;
			for ($i = 0; $i < count($trash_parts); $i++) {
				if (!isset($path_parts[$j]))
					break;
				if (empty($trash_parts[$i]))
					continue;
				if (empty($path_parts[$j]))
					$j++;
				if ($trash_parts[$i] == $path_parts[$j])
					$j++;
				$dest_dir .= '/' . $trash_parts[$i];
				} // for
			while ($j < count($path_parts)) {
				if (!empty($path_parts[$j]))
					$dest_dir .= '/' . $path_parts[$j];
				$j++;
				} // while
			if (!is_dir($dest_dir)) {
				if (@self::mkdir($dest_dir) === false) {
					self::addMsg('Could not make trash destination: &quot;' . $dest_dir . '&quot;.');
					return false;
					} // if
				} // if
			$dest_path = $dest_dir . '/' . basename($path);
			$cnt = 0;
			$chk_dest_path = $dest_path;
			while (file_exists($chk_dest_path)) {
				$cnt++;
				$chk_dest_path = $dest_path . '(' . $cnt . ')';
				} // while
			if (@rename($path, $chk_dest_path) !== false) {
				self::addMsg('Moved &quot;' . $path . '&quot; to Trash.', 'info');
				$retVal = true;
				} // if
			} // else
		return $retVal;
		} // trash_path()

	public static function chk_unserialize($str) {
		// using @unserialize() in an unserialized string return an @ error
		// to stop this happening use this method
		// check if a string is an array (return string) or
		// is a serialize string (unserialize and return it
		// else return false;
		if(is_null($str)) return false;
		if(empty($str)) return false;
		if(is_array($str)) return $str;
		if(preg_match('/^[bdsaO]:.*[;\}]$/',$str))
			return unserialize($str);
		return false;
		} // chk_unserialize()

	protected static function make_single_axis_array($grid) {
		if(!is_array($grid)) return array();
		$new_g = [];
		foreach($grid as $i => &$n) {	// filter and map
			if((isset($n[0])) && (empty($n[0]))) continue;
			if((isset($n[1])) && (!empty($n[1]))) return $grid;	// has more than one dimension
			$new_g[] = $n[0];
			} // foreach
		return $new_g;
		} // make_single_axis_array()

	public static function unserialize_string2arry($value, $val_sep = ':', $data_sep = '=') { // to convert setting and config strings into an array
		if (empty($value))
			return array();
		if ((($grid = self::chk_unserialize($value, array())) !== false) && // try serialized array first
			(is_array($grid)))
			return self::make_single_axis_array($grid);
		if (empty($val_sep)) {
			self::addDebugMsg('Code error in call to "' . self::get_backtrace(2) . '", see log.');
			return false; // error
			} // if
		// else its one of the old colon+ separated strings. Make into an array.
		$grid = array();
		$cc = explode($val_sep, $value);
		foreach ($cc as $cr) {
			if (!empty($data_sep)) {
				$c = @preg_split('/' . $data_sep . '/', $cr); // try for ini custom colours,etc
				if ((is_array($c)) && (count($c) == 2)) {
					$grid[] = $c;
					continue;
			} // if
		} // if
			$grid[] = array($cr, false); // single column, false as err marker if accessed
		} // foreach
		return self::make_single_axis_array($grid);
		} // unserialize_string2arry()

	public static function serialize_array2string($value, $val_sep = ':', $data_sep = '=') { // to convert setting and config strings into an array
		if (empty($value))
			return '';
		if (!is_array($value))
			return $value;
		$value = self::make_single_axis_array($value);
		if (empty($val_sep))
			return serialize($value);
		// else its one of the old colon+ separated strings. Make into a string
		$str = '';
		foreach ($value as $cr) {
			if (empty($cr))
				continue;
			if (strlen($str) > 0)
				$str .= $val_sep;
			if (is_array($cr)) {
				for ($i = 0; $i < count($cr); $i++) {
					if ($i > 0) $str .= $data_sep;
					if (empty($cr[$i])) break;
					if(is_array($cr[$i])) $str .= self::serialize_array2string($cr[$i], $val_sep, $data_sep);
					else $str .= $cr[$i];
				} // for
				continue;
		} // if
			$str .= $cr;
		} // foreach
		$str = preg_replace('/' . $val_sep . '*$/', '', $str); // clean off empties
		return $str;
		} // serialize_array2string()

	// recursive directory scan
	private static function recursiveScan_dir($dir, &$tree, $patt) { // the recursor
		if (is_file($dir)) {
			$tree[] = $dir;
			return 1;
		} // if
		$files = glob(rtrim($dir, '/') . '/*');
		$cnt = 0;
		if (is_array($files)) {
			foreach ($files as $file) {
				if (is_dir($file)) {
					if (!Ccms_base::is_dir_usable($file))
						continue;
					$cnt += self::recursiveScan_dir($file, $tree, $patt);
					} // if
				elseif (is_file($file)) {
					if (!Ccms_base::is_file_usable($file))
						continue;
					if(($patt) && (!preg_match($patt,$file)))
						continue;
					$tree[] = $file;
					$cnt++;
			} // else if
		} // foreach
		} // if
		return $cnt;
		} // recursiveScan_dir()

	public static function recursiveScan($dirs, &$tree, $patt = false) {
		$tree = array();
		if($patt)	// make a clean pattern
			$patt = '/' . preg_replace('/(^\/|\/[a-z]*$)/','',$patt) . '/i';
		if(is_array($dirs)) {
			$cnt = 0;
			foreach($dirs as $d) {
				$cnt += self::recursiveScan_dir($d, $tree, $patt);
				} // foreach
			} // if
		else $cnt = self::recursiveScan_dir($dirs, $tree, $patt);
		return $cnt;
		} // recursiveScan()

	// recursive scan directory for .php files and include them
	private static function recursiveIncPHP_dir($dir) { // the recursor
		if (is_file($dir)) {
			return 1;
		} // if
		$files = glob(rtrim($dir, '/') . '/*');
		$cnt = 0;
		if (is_array($files)) {
			foreach ($files as $file) {
				if (is_dir($file)) {
					if (!Ccms_base::is_dir_usable($file))
						continue;
					$cnt += self::recursiveIncPHP_dir($file);
					} // if
				elseif (is_file($file)) {
					if (!Ccms_base::is_file_usable($file))
						continue;
					if(!preg_match('/.*\.php$/i',$file))
						continue;
					@include_once($file);
					$cnt++;
			} // else if
		} // foreach
		} // if
		return $cnt;
		} // recursiveIncPHP_dir()

	public static function recursiveIncPHP($dir) {
		$cnt = self::recursiveIncPHP_dir($dir);
		return $cnt;
		} // recursiveIncPHPn()

	public static function get_url_response_str($code) {
		if (!self::$cms_url_response_codes) { // load it
			self::$cms_url_response_codes = self::parse_ini_file(CMS_FS_CMS_RESPONSE_CODES);
		} // if
		if (isset(self::$cms_url_response_codes[$code]))
			return self::$cms_url_response_codes[$code];
		return false; // not found
		} // get_url_response_str()

	private static function chk_excluded(&$src_dir,&$exclude_preffixes) {
		if(($exclude_preffixes) && (is_array($exclude_preffixes))) {
			foreach($exclude_preffixes as $e) {	// treat as prefix masks
				if(empty($e)) continue;
				$chk = substr($src_dir,0,strlen($e));
				if($e == $chk) return true;	// excluded
				} // foreach
			} // if
		return false;	// not excluded
		} // chk_excluded()

	public static function recurse_copy($src_dir,$dst_dir, $exclude_preffixes = false, $update = false, $dir_always = false, $along_src_path = false) { // recursively copy filesystem
		// $update used refresh $scr to $dst_dir to the source, $dir_always creates the directory structure anyway
		// $along_src_path is used to control/limit the number directories copied (usefule in snapshots)
		if((!file_exists($src_dir)) || (!is_dir($src_dir))) return 0;	// just in case
		if(!Ccms_base::is_dir_usable($src_dir)) return 0;
		if((!empty($exclude_preffixes)) &&
			(self::chk_excluded($src_dir, $exclude_preffixes))) return 0;
		if(!$dir = opendir($src_dir)) return 0;
		self::chkdir($dst_dir,true,false);
		$cnt = 1;
		if($along_src_path) $new_along_path = substr($along_src_path,0,strlen($src_dir));
		else $new_along_path = false;
		while(false !== ( $file = readdir($dir)) ) {
			if(self::chk_excluded($file, $exclude_preffixes)) continue;
			if (is_dir($src_dir . '/' . $file)) {
				if(!Ccms_base::is_dir_usable($file)) continue;
				if((!$dir_always) && ($new_along_path) && ($new_along_path != $src_dir)) continue;
				$cnt += self::recurse_copy(self::clean_path($src_dir . '/' . $file . '/'),self::clean_path($dst_dir . '/' . $file), $exclude_preffixes,$update,$dir_always,$along_src_path);
				} // if
			else {
				if (!Ccms_base::is_file_usable($file)) continue;
				if(($dir_always) && ($new_along_path) && ($new_along_path != $src_dir)) continue;
				if(($update) ||
					(!file_exists($dst_dir . '/' . $file))) {
					copy($src_dir . '/' . $file,$dst_dir . '/' . $file);
					self::chmod_chown($dst_dir . '/' . $file);
					$cnt++;
					} // if
				} // else
			} // while
		closedir($dir);
		return $cnt;
		} // recurse_copy()

	public static function recurse_move($src_dir,$dst_dir, $overwrite = true, $remove_src = true) { // recursively move filesystem
		// move a directory recursively using the copy deelet method,
		// cleaning up the source as it goes
		// if not over write and the file exists in the destination,
		// the destination file remains unchanged and the source file is deleted
		// $along_src_path is used to control/limit the number directories copied (usefule in snapshots)
		if((!file_exists($src_dir)) || (!is_dir($src_dir))) return 0;	// just in case
		if(!$dir = opendir($src_dir)) return 0;
		self::chkdir($dst_dir,true,false);
		$cnt = 1;
		while(false !== ( $file = readdir($dir)) ) {
			if (is_dir($src_dir . '/' . $file)) {
				if($src_dir . '/' . $file == $dst_dir) continue;	// run away recursing into self
				if(preg_match('/^\.$|^\.\.$/', $file)) continue;
				$cnt += self::recurse_move(
					self::clean_path($src_dir . '/' . $file . '/'),
					self::clean_path($dst_dir . '/' . $file),
					$overwrite,$remove_src);
				} // if
			else {
				if(file_exists($dst_dir . '/' . $file)) {
					if($overwrite) @unlink($dst_dir . '/' . $file);
					else {
						@unlink($src_dir . '/' . $file);	// clean up sorc
						continue;	// don't over write dest
						} // else
					} // if
				copy($src_dir . '/' . $file,$dst_dir . '/' . $file);
				self::chmod_chown($dst_dir . '/' . $file);
				@unlink($src_dir . '/' . $file);	// clean up sorc
				$cnt++;
				} // else
			} // while
		closedir($dir);
		if($remove_src)
			@rmdir(preg_replace('/\/$/','',$src_dir));	// clean up sorc
		return $cnt;
		} // recurse_move()

	protected static function is_fs_squash_mount($dir) {
		if(self::findmnt($dir,'squash')) return true;
		return false;
		} // is_fs_squash_mount()

	public static function is_cms_readonly() {
	// check for squash filesystems mounted at CMS_DIR
	if(!file_exists('cms_lib_sqsh.sqsh')) return false;
	if(!Ccms_base::is_fs_squash_mount(CMS_FS_DIR)) return false;
	return true;
	} // is_cms_readonly()

	public static function is_apps_readonly() {
		// check for squash filesystems mounted at APPS_DIR
		if(!file_exists('apps_fs_sqsh.sqsh')) return false;
		if(!Ccms_base::is_fs_squash_mount(APPS_FS_DIR)) return false;
		return true;
		} // is_apps_readonly()

	private static function replace_constants_ini_data_recurs($data,&$search,&$replace) {
		foreach($data as $k => &$v) {
			if(is_array($v)) $data[$k] = self::replace_constants_ini_data_recurs($data[$k], $search, $replace);	// recurs
			else $data[$k] = str_replace($search,$replace,$v);	// simples
			} // foreach
		return $data;
		} // replace_constants_ini_data_recurs()

	public static function replace_constants_ini_data($data) {
		static $search = false;
		static $replace = false;
		if(empty($data)) return $data;	// keep type
		if(empty($search)) {	// do once, setup for string replace
			$search = array();
			$replace = array();
			$constants = get_defined_constants(true);
			ksort($constants['user']);
			foreach($constants['user'] as $s => $r) {	// do user defined
				$search[] = $s;	// keep in order
				$replace[] = $r;	// ditto
				} // foreach
			} // if
		if((is_array($data)) && (!isset($data[0]))) { // associative array
			$data = self::replace_constants_ini_data_recurs($data, $search, $replace);
			return $data;
			} // if
		$evald = str_replace($search,$replace,$data);	// simples
		if(!empty($evald)) return $evald;
		return $data;
		} // replace_constants_ini_data()

	public static function parse_ini_file($filename, $process_sections = false, $do_consts = false) {
		$data = parse_ini_file($filename,$process_sections);
		if(!$do_consts) return $data;
		return self::replace_constants_ini_data($data);
		} // parse_ini_file()

	public static function get_user_json_name($user = '') {
		if(empty($user)) $user = Ccms_base::get_logged_in_username();
		if(empty($user)) {
			if((defined('CMS_C_DEFAULT_CLIENT_NAME')) &&
				(CMS_C_DEFAULT_CLIENT_NAME == 'SID') &&
				(!empty(self::$cms_session_id))) $user = self::$cms_session_id;
			// else $user = Ccms_auth::get_client_ip_address();	// use IP address as substitute
			else $user = 'Guest';
			if(empty($user)) return false;
			} // if
		return $user;
		} // get_user_json_name()

	public static function get_user_json_data_ary($user = '') {
		if(!$user = self::get_user_json_name($user)) return false;
		$json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		$json_def = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		if(!file_exists($json_file)) $json = $json_def;
		else {
			$json = self::load_json($json_file);
			$json = array_merge($json_def,$json);	// merge in new variables
			} // else
		if(!isset($json['cms_user'])) return array();
		return $json['cms_user'];
		} // get_user_json_data_ary()

	public static function save_user_json_data_ary($data,$user = '') {
		if(!$user = self::get_user_json_name($user)) return false;
		$json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		if(!file_exists($json_file)) $json = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		else $json = self::load_json($json_file);
		if(!is_array($json)) $json = array();
		$json['cms_user'] = $data;
		if(CMS_S_LOG_USER_UPDATES_BOOL) {
			self::log_msg('User: ' . $user . ', Variables: ' . self::json_encode($json),'info');
			} // if
		return self::save_json($json);
		} // save_user_json_data_ary()

	protected static function get_user_json_filename($user = '') {
		if((empty($user)) &&
			(!$user = self::get_user_json_name($user))) return false;
		$ip_addr = Ccms_auth::get_client_ip_address();
		if($user == $ip_addr) $json_file = VAR_FS_USERS_DIR . rawurlencode($user) . '.json';
		else $json_file = VAR_FS_USERS_DIR . rawurlencode($user . '@' . $ip_addr) . '.json';
		return $json_file;
		} // get_user_json_filename()

	public static function get_user_json_data_key($key,$user = '') {
		if(!$json_file = self::get_user_json_filename($user)) return false;
		if(!file_exists($json_file)) $json = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		else $json = self::load_json($json_file);
		if(!isset($json['cms_user'][$key])) return false;
		if(empty($json['cms_user']['cms_user_ip_addr'])) $json['cms_user']['cms_user_ip_addr'] = Ccms_auth::get_client_ip_address();
		return $json['cms_user'][$key];
		} // get_user_json_data_key()

	public static function update_user_json_data($key,$new_val,$user = '') {
		if(!$user = self::get_user_json_name($user)) return false;
		if(!$json_file = self::get_user_json_filename($user)) return false;
		if(!file_exists($json_file)) $json = self::load_json(CMS_FS_CMS_USER_DEFAULT);
		else $json = self::load_json($json_file);
		$json['username'] = $user;
		$json['cms_user'][$key] = $new_val;
		$json['cms_user']['cms_user_ip_addr'] = Ccms_auth::get_client_ip_address();
		if(CMS_S_LOG_USER_UPDATES_BOOL) {
			self::log_msg('User: ' . $user . ', Variables: ' . self::json_encode($json),'info');
			} // if
		return self::save_json($json_file, $json);
		} // update_user_json_data()

	public static function scan_dir_recurs($dir) {
		$result = [];
		if(!is_dir($dir)) {
			if(!is_dir(DOCROOT_FS_BASE_DIR . $dir)) return $result;
			$t = DOCROOT_FS_BASE_DIR . $dir;
			$dir = $t;
			} // if
		$files = scandir($dir);
		for($i = 0, $n = count($files); $i < $n; $i++) {
			$file = $files[$i];
			if ($file[0] === '.') continue;
			$filePath = $dir . '/' . $file;
			if (is_dir($filePath)) {
				$dir_res = self::scan_dir_recurs($filePath);
				$result = array_merge($result,$dir_res);
				} // if
			else {
				$result[] = $dir . '/' . $file;
				} // else
			} // foreach
		return $result;
		} // scan_dir_recurs()

	public static function mime_content_type($file) {
		if(function_exists('mime_content_type')) return mime_content_type($file);
		if(class_exists('finfo')) {
			$result = new finfo();
			if (is_resource($result) === true) {
				return $result->file($file, FILEINFO_MIME_TYPE);
				} // if
			} // if
		self::addAdminMsg('SYSTEM: Missing class: finfo, missing function: finfo.');
		return false;
		} // mime_content_type()

	} // Ccms_base_file
