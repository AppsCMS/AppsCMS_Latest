<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api_jwt.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of Ccms_api_jwt
 * API execute class
 *
 * Use private / public SSL keys (recommended) or hash_hmac (slow).
 *
 * @author robert0609
 */

require_once 'cms_api_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_api_jwt extends Ccms_api_base {	// JWT class

	protected static $private_key = false;
	protected static $key_csr = false;
	protected static $public_key = false;
	protected static $key_info = false;

	protected static $secret = false;

	protected $jwt = false;

	protected $payload = false;

	protected static $supported_algs = array(
		// only OpenSSL private key / public key pairs used
		'RS256' => array('openssl', 'SHA256'),
		'RS384' => array('openssl', 'SHA384'),
		'RS512' => array('openssl', 'SHA512'),
		'ES384' => array('openssl', 'SHA384'),
		'ES256' => array('openssl', 'SHA256'),
		'HS256' => array('hash_hmac', 'SHA256'),
		'HS384' => array('hash_hmac', 'SHA384'),
		'HS512' => array('hash_hmac', 'SHA512'),
		);
	protected static $jwt_decoded = false;
	private static $jwt_api_token = null;	// from client

	const JWT_LOG_PRE = 'JWT: ';

	function __construct() {
		self::is_use_jwt_ok();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_use_jwt_ok() {	// check if JWT ok
		if((!self::is_api()) || (!CMS_C_API_ENABLE) || (CMS_C_API_AUTH != 'JWT')) {
			return false;
			} // if
		return true;
		} // is_use_jwt_ok()

	public static function get_allowed_algorithms_descriptions($nl = '<br>') {
		$algs =array();
		$algs[] = 'JWT Encryption Algorithms.';
		foreach(self::$supported_algs as $alg => &$v) {
			$algs[] = $alg . ': type ' . $v[0] . ', hash ' . $v[1];
			} // foreach
		return implode($nl,$algs) . PHP_EOL;
		} // get_allowed_algorithms_descriptions()

	public static function get_allowed_algorithms($implode = ':') {
		$algs =array();
		foreach(self::$supported_algs as $alg => &$v) $algs[] = $alg;
		if($implode) return implode($implode,$algs);	// for config table
		return $algs;
		} // get_allowed_algorithms()

	public static function is_jwt_user() {
		if(!empty(self::$jwt_payload['data']['cms_user_id'])) return true;
		return false;
		} // is_jwt_user()

	public static function is_jwt_admin() {
		if(!empty(self::$jwt_payload['data']['cms_user_admin'])) return true;
		return false;
		} // is_jwt_admin()

	public static function get_jwt_username() {
		if(!empty(self::$jwt_payload['data']['cms_user_name']))
			return self::$jwt_payload['data']['cms_user_name'];
		return false;
		} // get_jwt_username()

	public static function get_jwt_group_manager_ids() {
		if(!empty(self::$jwt_payload['data']['group_manager_ids']))
			return self::$jwt_payload['data']['group_manager_ids'];
		return false;
		} // get_jwt_group_manager_ids()

	public static function get_jwt_token($set = null) {
		if(!is_null($set)) self::$jwt_api_token = $set;
		if(is_null(self::$jwt_api_token)) {
			if(!Ccms_api_jwt::is_use_jwt_ok ()) self::$jwt_api_token = false;
			else {
				if(!empty(self::$api_request_headers[Ccms_api_base::API_JWT_KEY]))
					self::$jwt_api_token = self::$api_request_headers[Ccms_api_base::API_JWT_KEY];
				else self::$jwt_api_token = false;
				} // else
			} // if
		return self::$jwt_api_token;
		} // get_jwt_token()

	public static function gen_jwt_filename($user_id,$user_name, $jwt) {
		self::chkdir(VAR_FS_API_KEYS_DIR);
		$md5_jwt = md5($jwt);
		$filename = VAR_FS_API_KEYS_DIR . 'JWT_' . $md5_jwt . '_' . $user_id . '_' . rawurlencode($user_name) . '.json';
		return $filename;
		} // gen_jwt_filename()

	public static function find_jwt_filename(&$jwt) {
		$md5_jwt = md5($jwt);
		$filemsk = VAR_FS_API_KEYS_DIR . 'JWT_' . $md5_jwt . '_*.json';
		$files = glob($filemsk);
		if((empty($files)) || (count($files) != 1)) return false;	// not found
		return $files[0];
		} // find_jwt_filename()

	public static function gen_user_signature($user_id) {
		$sql_query = "SELECT * FROM  cms_users WHERE cms_user_enabled = 1 AND cms_user_id = " . (int)$user_id . " LIMIT 1";
		if(($user = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user))) {
			$lng_str = implode('?&',$user);
			return md5($lng_str);
			} // if
		return false; // not mine
		} // gen_user_signature()

	public static function del_jwt_filename(&$jwt) {
		$filename = self::find_jwt_filename($jwt);
		if((empty($filename)) ||
			(!file_exists($filename)))
			return false;
		return unlink($filename);
		} // del_jwt_filename()

	public static function chk_user_signature($user_id,$sig) {
		$sql_query = "SELECT * FROM  cms_users WHERE cms_user_enabled = 1 AND cms_user_id = " . (int)$user_id . " LIMIT 1";
		if(($user = self::$cDBcms->query($sql_query)) &&
			($user = self::$cDBcms->fetch_array($user))) {
			$lng_str = implode('?&',$user);
			return ((md5($lng_str) == $sig) ? true:false);
			} // if
		return false; // not mine
		} // chk_user_signature()

	protected static function addKWTmsg($msg, $type = 'error') {
		$log = self::JWT_LOG_PRE . $msg . ', from ' . Ccms_auth::get_client_ip_address() . '.';
		self::addDebugMsg($msg, $type);
		} // addKWTmsg()

	protected static function safe_b64_decode($b64) {
		$remainder = strlen($b64) % 4;
		if ($remainder) {
			$padlen = 4 - $remainder;
			$b64 .= str_repeat('=', $padlen);
			} // if
		return base64_decode(strtr($b64, '-_', '+/'));
		} // safe_b64_decode()

	protected static function safe_b64_encode($input) {
		return str_replace('=', '', strtr(base64_encode($input), '+/', '-_'));
		} // safe_b64_encode()

	protected static function extract_sections(&$jwt) {
		if(!empty(self::$jwt_decoded)) return true;	// do once
		$tks = explode('.', $jwt);
		if (count($tks) != 3) {
			self::addKWTmsg('Wrong number of segments');
			return false;
			} // if
		$jwtd = &self::$jwt_decoded;	// a ref
		$jwtd = array();
		list($jwtd['headb64'], $jwtd['payload64'], $jwtd['cryptob64']) = $tks;
		if(null === ($jwtd['header'] = self::json_decode(self::safe_b64_decode($jwtd['headb64']),true))) {
			self::addKWTmsg('Invalid header encoding');
			return false;
			} //if
		if(null === ($jwtd['payload'] = self::json_decode(self::safe_b64_decode($jwtd['payload64']),true))) {
			self::addKWTmsg('Invalid payload encoding');
			return false;
			} //if
		if (false === ($jwtd['sig'] = self::safe_b64_decode($jwtd['cryptob64']))) {
			self::addKWTmsg('Invalid signature encoding');
			return false;
			} //if
		return true;
		} // extract_sections()

	protected static function gen_signat(&$signing_input, $alg = false) {
		if (empty(self::$supported_algs[$alg])) {
			self::addKWTmsg('Algorithm not supported');
			return false;
			} // if
		list($function, $algorithm) = self::$supported_algs[$alg];
		switch ($function) {
			case 'hash_hmac':
				self::gen_random_secret();	// if public_key to save
				return hash_hmac($algorithm, $signing_input, self::secret, true);
			case 'openssl':
				if((!self::gen_ssl_keys()) || (empty(self::$key_info['key']))) {
					self::addMsg('CODE SSL FAILURE: No API public key text.');
					return false;
					} // if
				$signature = '';
				$success = openssl_sign($signing_input, $signature, self::$private_key, $algorithm);
				if (!$success) {
					self::addKWTmsg("OpenSSL unable to sign data");
					return false;
					} // if
				return $signature;
			default:
				break;
				} // switch
		return false;
		} // gen_signat()

	protected static function verify_signat($alg,&$jwt) {
		if (empty(self::$supported_algs[$alg])) {
			self::addKWTmsg('Algorithm not supported');
			return false;
			} // if
		if((!$pub_json_file = self::find_jwt_filename($jwt)) ||
			(!$pub_json = self::load_json($pub_json_file)) ||
			(empty($pub_json))) {
			self::addKWTmsg('Keys not found. Verification failed.');
			return false;
			} // if
		if((CMS_C_JWT_FIX_IP) &&
			(!empty($pub_json['client_ip'])) &&
			($pub_json['client_ip'] != Ccms_auth::get_client_ip_address ())) {
			self::addKWTmsg('Failed client IP verification. Verification failed.');
			return false;
			} // if
		$public_key = $pub_json['public_key'];

		$jwtd = &self::$jwt_decoded;	// a ref
		$signing_input = $jwtd['headb64'] . '.' . $jwtd['payload64'];
		$signature = &$jwtd['sig'];
		list($function, $algorithm) = self::$supported_algs[$alg];
		switch ($function) {
		case 'openssl':
			if(empty($pub_json['public_key'])) {
				self::addKWTmsg('Public key not found for ' . $cms_user_name . ', id ' . $cms_user_id . '');
				return false;
				} // if
			$public_key = $pub_json['public_key'];
			$success = openssl_verify($signing_input, $signature, $public_key, $algorithm);
			if ($success === 1) return true;
			else if ($success === 0) return false;
			// returns 1 on success, 0 on failure, -1 on error.
			self::addKWTmsg('OpenSSL error: ' . openssl_error_string());
			return false;
		case 'hash_hmac':
		default:
			if(empty($pub_json['secret'])) {
				self::addKWTmsg('Secret key not found for ' . $cms_user_name . ', id ' . $cms_user_id . '');
				return false;
				} // if
			$secret = $pub_json['secret'];
			$hash = hash_hmac($algorithm, $signing_input, $secret, true);
			if (function_exists('hash_equals')) return hash_equals($signature, $hash);
			$len = min(mb_strlen($signature,'8bit'), mb_strlen($hash,'8bit'));
			$status = 0;
			for ($i = 0; $i < $len; $i++) {
				$status |= (ord($signature[$i]) ^ ord($hash[$i]));
				} // for
			$status |= (mb_strlen($signature,'8bit') ^ mb_strlen($hash,'8bit'));
			return ($status === 0);
			} // switch
		return false;
		} // verify_signat()

	protected static function gen_random_secret() {
		$the_string2hash = time() . random_bytes(32);
		self::$secret = md5($the_string2hash);
		return true;
		} // gen_random_secret()

	protected static function &gen_ssl_keys() {
		// Generate a new private and public key pair
		self::$private_key = openssl_pkey_new(
			array(
				"private_key_bits" => 2048,
				"private_key_type" => OPENSSL_KEYTYPE_RSA,
				));

		// Generate a certificate signing request
		$distinguished_names = array(
			"commonName" => CMS_DOMAIN,
			//"countryName" => "GB",
			//"stateOrProvinceName" => "Somerset",
			//"localityName" => "Glastonbury",
			"organizationName" => CMC_C_CO_NAME,
			"organizationalUnitName" => CMS_C_TITLE,
			"emailAddress" => CMS_C_EMAIL_ADDRESS
			);
		self::$key_csr = openssl_csr_new($distinguished_names,
			self::$private_key, array('digest_alg' => 'sha256'));

		self::$public_key = openssl_csr_get_public_key(self::$key_csr);
		self::$key_info = openssl_pkey_get_details(self::$public_key);
		return self::$key_info;
		} // gen_ssl_keys()

	// dynamic methods

	public function make_jwt($user_id,$extra = false) {	// for results
		if(!self::is_use_jwt_ok()) return false;
		if(CMS_C_JWT_INC_ID) {
			$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_admin,cms_user_group_ids" .
				",cms_user_enabled,cms_user_auth_ldap,cms_user_auth_pam,cms_user_api" .
				",cms_user_email,cms_user_mobile" .
				" FROM  cms_users" .
				" WHERE  cms_user_enabled = 1 AND cms_user_id = " . (int)$user_id;
			} // if
		else {
			$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_admin,cms_user_group_ids" .
				" FROM  cms_users" .
				" WHERE  cms_user_enabled = 1 AND cms_user_id = " . (int)$user_id;
			} // else
		if((!$user = self::$cDBcms->query($sql_query)) ||
			(!$user = self::$cDBcms->fetch_array($user))) {
			self::addKWTmsg('User not found');
			return false;
			} // if
		foreach($user as $k => $v) $$k = $v;	// define vars
		$user['group_manager_ids'] = self::get_group_manager_ids($cms_user_admin, $cms_user_group_ids);
		$user['group_ids'] = $cms_user_group_ids;	// group ids array
		$user['type'] = self::JWT_LOG_PRE;
		if(CMS_C_API_USER_SIG) $user['user_sig'] = self::gen_user_signature($user_id);
		$user_name = $user['cms_user_name'];

		$now = time();
		$expires = (time() + ((int)CMS_C_JWT_EXPIRE_HRS * 3600));	// make it seconds

		$payload = array(
			"data" => $user,
			"sub" => CMS_PROJECT_SHORTNAME,
			"iss" => CMS_DOMAIN,
			"aud" => (self::is_ssl_inuse() ? CMS_SSL_URL:CMS_WWW_URL),
			"iat" => $now,
			"exp" => $expires,
			"extra" => $extra,
			);
		$header = array('typ' => self::API_JWT_KEY, 'alg' => CMS_C_JWT_ALG);
		$segments = array();
		$segments[] = self::safe_b64_encode(self::json_encode($header));
		$segments[] = self::safe_b64_encode(self::json_encode($payload));
		$signing_input = implode('.', $segments);

		$signature = self::gen_signat($signing_input, CMS_C_JWT_ALG);
		$segments[] = self::safe_b64_encode($signature);

		$this->jwt = implode('.', $segments);
		// save JWT public key, etc
		$jwt_record = array(
			'user_id' => $user_id,
			'user_name' => $user_name,
			'from' => $now,
			'expires' => $expires,
			self::API_JWT_KEY => $this->jwt,
			);
		if(CMS_C_JWT_FIX_IP) $jwt_record['client_ip'] = Ccms_auth::get_client_ip_address ();
		if(!empty(self::$key_info['key'])) {
			$jwt_record['public_key'] = self::$key_info['key'];	// public key text
			} // if
		else if(!empty($this->secret)) {
			$jwt_record['secret'] = $this->secret;	// public key text
			} // else if
		else {
			self::addKWTmsg('CODE ERROR: No decoding key.');
			return false;
			} //
		$filename = self::gen_jwt_filename($user_id, $user_name, $this->jwt);
		self::save_json($filename, $jwt_record);
		return $this->jwt;
		} // make_jwt()

	public function check_jwt(&$jwt) {	//
		if(!self::is_use_jwt_ok()) return false;
		if(!self::extract_sections($jwt)) return false;

		$jwtd = &self::$jwt_decoded;	// a ref
		$payload = &$jwtd['payload'];
		if((empty($payload['data']['cms_user_id'])) || ((int)$payload['data']['cms_user_id'] <= 0)) {
			self::addKWTmsg('Unknown user ID');
			return false;
			} // if
		$user_id = $payload['data']['cms_user_id'];
		if(!empty($payload['data']['user_sig'])) {
			if(!self::chk_user_signature($user_id,$payload['data']['user_sig'])) return false;
			} // if
		$sql_query = "SELECT  cms_user_id,cms_user_name,cms_user_admin,cms_user_group_ids" .
			",cms_user_enabled,cms_user_auth_ldap,cms_user_auth_pam,cms_user_api" .
			",cms_user_email,cms_user_mobile" .
			" FROM  cms_users" .
			" WHERE  cms_user_enabled = 1 AND cms_user_id = " . (int)$user_id;
		if((!$user = self::$cDBcms->query($sql_query)) ||
			(!$user = self::$cDBcms->fetch_array($user))) {
			self::addKWTmsg('User not found');
			return false;
			} // if
		foreach($user as $k => $v) $$k = $v;

		if (empty($jwtd['header']['alg'])) {
			self::addKWTmsg('Empty algorithm');
			return false;
			} //if
		if (empty(self::$supported_algs[($jwtd['header']['alg'])])) {
			self::addKWTmsg('Algorithm not supported');
			return false;
			} //if

		if(!self::verify_signat($jwtd['header']['alg'],$jwt)) {
			self::addKWTmsg('Signature verification failed');
			return false;
			} // if
		// payload clean
		$timestamp = time();
		if (isset($payload['nbf']) && $payload['nbf'] > $timestamp) {
			self::addKWTmsg('Cannot handle token prior to ' . date(DateTime::ISO8601, $payload['nbf']));
			return false;
			} // if
		if (isset($payload['iat']) && $payload['iat'] > $timestamp) {
			self::addKWTmsg('Cannot handle token prior to ' . date(DateTime::ISO8601, $payload-['iat']));
			return false;
			} // if
		if (isset($payload['exp']) && $timestamp >= $payload['exp']) {
			self::addKWTmsg('Expired token');
			return false;
			} // if
		$this->payload = (array) $payload;	// force it to associative array
		return $this->payload;
		} // check_jwt()

} // Ccms_api_jwt

