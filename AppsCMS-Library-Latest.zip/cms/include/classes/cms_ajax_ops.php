<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_ajax_ops.php 3265 2023-03-10 10:02:49Z robert0609 $
 */

/**
 * Description of cms_ajax_ops
 *
 * Class to package, provides session isolation for ajax ops
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_html.php');	// speed up, save class lookup

class Ccms_ajax_ops extends Ccms_html {

	function __construct() {
		parent::__construct();
		$this->do_ajax_ops();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods

	// dynamic methods
	protected function do_ajax_ops() {
		self::log_ajax_request();
		$text = false;
		$content_type = 'text/html';
		if(!empty(self::$cms_plugin)) {	// do plugins
			$class = 'C' . self::$cms_plugin . '_plugin';
			if(Ccms_autoloader::find_plugin($class)) {
				if((method_exists($class,'is_enabled')) &&
					(method_exists($class,'is_this_ajax_plugin')) &&
					(method_exists($class,'get_ajax_text')) &&
					($class::is_enabled(self::$cms_plugin)) &&
					($class::is_this_ajax_plugin(self::get_ajax()))) {
					$text = $class::get_ajax_text(self::get_ajax());
					if (method_exists($class, 'ajax_content_type')) {
						$content_type = $class::ajax_content_type();
						}
		//				$text = self::get_pretty_html_doc($text,true);
					} // if
				else {
					$text = 'Ajax Plugin Error. Check ' . self::$cms_plugin . ' config.';
					} // else
				} // if
			else {
				$text = 'Ajax Error.';
				} // else
			if(!empty($text)) {
				self::log_ajax_response($text);
				// output a response header
				if(preg_match('/^UTF/i',CMS_S_CHAR_SET))
					header("Content-type: $content_type; charset=" . CMS_S_CHAR_SET . '');
				header('Cache-Control: no-cache');
				header('Cache-Control: no-store' , false);     // false => this header
				echo $text;
				} // if
			} // if
		else if(!empty(self::$cms_app)) {	// do apps
			if((Ccms_autoloader::find_class(($class = 'C' . self::$cms_app . '_app'))) &&	// uses autoloader to test
				(method_exists($class,'get_ajax_text'))) {
				$text = $class::get_ajax_text(self::get_ajax());
				if(is_bool($text)) {	// no point sending
					exit(1000);	// just an indicator
					} // if
				if (method_exists($class, 'ajax_content_type')) {
					$content_type = $class::ajax_content_type();
					}
				} // if
			else if(is_readable(($fphp = APPS_FS_DIR . self::$cms_app . '.php'))) {
				ob_start();
				include $fphp;
				$text = ob_get_clean();
				} // else if
			else $text = 'Apps ' . self::$cms_app . ' Error.';
			if(!empty($text)) {
				self::log_ajax_response($text);
				// output a response header
				if(preg_match('/^UTF/i',CMS_S_CHAR_SET))
					header("Content-type: $content_type; charset=" . CMS_S_CHAR_SET . '');
				header('Cache-Control: no-cache');
				header('Cache-Control: no-store' , false);     // false => this header
				echo $text;
				} // if
			} // if
		else {
			switch(self::get_ajax()) {
			case 'cms_edit_ws_image_upload':
				if($filename = self::save_uploaded_file(ETC_FS_IMAGES_DIR,'file')) {
					self::chmod_chown($filename);
					// output a response header
					if(preg_match('/^UTF/i',CMS_S_CHAR_SET))
						header("Content-type: $content_type; charset=" . CMS_S_CHAR_SET . '');
					header('Cache-Control: no-cache');
					header('Cache-Control: no-store' , false);     // false => this header
					$text = self::get_ws_image_uri_selection();
					self::log_ajax_response($text);
					echo $text;
					} // if
				break;
			case 'cms_edit_search':
				if(Ccms_auth::is_cms_admin_user()) {
					self::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_search.php");
					break;
					} // if
			case 'cms_debug_vars':
				if(Ccms_auth::is_cms_admin_user()) {
					self::output_include_body_text(CMS_FS_OPS_DIR . "cms_debug_vars.php");
					break;
					} // if
			case 'cms_log_view':
				if(Ccms_auth::is_cms_admin_user()) {
					self::output_include_body_text(CMS_FS_OPS_DIR . "cms_log_view.php");
					break;
					} // if
			case 'cms_browse_sessions':
				if(Ccms_auth::is_cms_admin_user()) {
					self::output_include_body_text(CMS_FS_OPS_DIR . "cms_session_browser.php");
					break;
					} // if
			case 'cms_users_stats':
				if(Ccms_auth::is_cms_admin_user()) {
					self::output_include_body_text(CMS_FS_OPS_DIR . "cms_users_stats.php");
					break;
					} // if
			case 'cms_get_filtered_links_page':
				if(self::is_get_or_post('keywords')) { // get filtered output
					// output a response header
					if(preg_match('/^UTF/i',CMS_S_CHAR_SET))
						header('Content-type: text/html; charset=' . CMS_S_CHAR_SET . '');
					header('Cache-Control: no-cache');
					header('Cache-Control: no-store' , false);     // false => this header
		//				if(CMS_S_DEBUG_BOOL) {
		//					$text = "AJAX DEBUG - " . self::get_or_post('filter');
		//					echo $text;
		//					} // if
					include_once(CMS_FS_INCLUDES_DIR . "cms_filtered_links.php");
					} // if
				break;
			case 'lm_save_filtered_sections_state':
				if(self::is_get_or_post('lm_section_states')) { // get lm section states
					$states = self::get_or_post('lm_section_states');
					foreach($states as $id => $val) {
						self::set_cms_sess_var($val,'lm_section_states',$id);
						} // foreach
					$v = array('message' => 'ok');
					} // if
				else $v = array('message' => 'ERROR: no data');
				header("Content-Type: application/json");
				echo self::json_encode($v);
				break;
			case 'cms_livesearch':	// default callback for get_live_search_input()
				$name = self::get_or_post('name');
				if(!name) {
					self::log_msg('Failed to get name for "cms_livesearch".','warn);');
					echo 'Failed "cms_livesearch" name.';
					break;
					} // if
				if($func = self::get_cms_sess_var('callbacks','cms_livesearch',$name,'func')) {
					$text = @call_user_func($func,$name);
					if(is_null($text) || empty($text)) {
						self::log_msg('Failed "cms_livesearch.' . $name . '" to get results..','warn);');
						echo 'Failed "cms_livesearch.' . $name . '" to get results.';
						echo '';
						} // if
					else echo $text;
					}
				else {
					self::log_msg('Failed "cms_livesearch.' . $name . '": callback not found.','warn);');
					echo 'Failed "cms_livesearch" name.';
					} // else
				break;
			case 'cms_cookie_banner_closed':	// default callback for cms_cookie_banner_closed()
				Ccms_auth::cms_cookie_banner_closed();
				self::log_msg('Cookie banner closed.','info');
				echo 'Ok';
				break;
			case 'cms_client_metadata':
				$meta = self::get_or_post('clientMeta');
				self::set_cms_sess_var($meta,'clientMetadata');
		//			if(self::is_debug()) {
		//				self::save_json(VAR_FS_TEMP_DIR . 'client_meta.json',$meta);
		//				} // if
				break;
			default:
				// else what, nothing
				break;
				} // switch
			} // else
		} // do_ajax_ops()

} // Ccms_ajax_ops
