<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_vfs.php 3159 2023-02-16 10:41:56Z robert0609 $
 */

/**
 * Description of Ccms_vfs
 *
 * Virtual folders engagement auxillary class
 *
 * @author robert0609
 */

// the always defined classes
require_once 'cms_base_sm.php';	// speed up for proxy (no autoloader needed)

class Ccms_vfs extends Ccms_base_sm {

	private static $cms_vfs_on = false;
	private static $cms_vfs_redirect_url = false;
	private static $cms_vfs_redirect_uri = false;
	private static $cms_vfs_done = false;
	private static $cms_vfs_name = false;
	private static $cms_vfs_dest = false;
	private static $cms_vfs_url = false;
	private static $cms_vfs_vars = false;
	
	private static $cms_vfs_cms_virtuals = array(	
		'login' => 'index.php?action=login',
		'logout' => 'index.php?action=logout',
		'signin' => 'index.php?action=login',
		'signout' => 'index.php?action=logout',
		'cms_login' => 'index.php?cms_action=cms_login',
		'cms_logout' => 'index.php?cms_action=cms_logout',
		'cms_signin' => 'index.php?cms_action=cms_login',
		'cms_signout' => 'index.php?cms_action=cms_logout',
		);

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function is_vfs() { return self::$cms_vfs_on; }
	public static function get_vfs_name() { return self::$cms_vfs_name; }
	public static function get_vfs_dest() { return self::$cms_vfs_dest; }
	public static function get_vfs_url() { return self::$cms_vfs_url; }

	private static function chk_engage_vfs_gvars($req, $inc_gvar = true) {
		if(preg_match('/[\?&]+.*$/',$req)) {	// has vars
			$uri = preg_replace('/[\?&].*$/','',$req);
			$vars = preg_replace('/^.*[\?&](.*$)/','$1',$req);
			$nvars = explode('&',$vars);
			self::$cms_vfs_vars = array();
			foreach($nvars as &$nv) {
				list($nam,$val) = explode('=',$nv);
				self::$cms_vfs_vars[$nam] = $val;
				if($inc_gvar) Ccms_base::get_or_post_pushback($nam,$val);
				} // foreach			
			return $uri;
			} // if
		return $req;	// no name=var in request
		} // chk_engage_vfs_gvars()
		
	protected static function chk_engage_vfs() {
		if(self::$cms_vfs_done) return self::$cms_vfs_on;
		self::$cms_vfs_done = true;
		self::$cms_vfs_redirect_url = false;
		self::$cms_vfs_redirect_uri = false;
		if(!self::has_apache_rewrite()) return self::$cms_vfs_on;
		
		if(!empty($_SERVER['REDIRECT_SCRIPT_URI'])) {	// the redirect URI
			$cms_vfs_redirect_uri = self::chk_engage_vfs_gvars($_SERVER['REDIRECT_SCRIPT_URI']);
			$path_info = parse_url($cms_vfs_redirect_uri);
			if(!empty(CMS_URI_ALIAS)) {
				// $dest = substr($path_info['path'],(strlen(CMS_URI_ALIAS)));
				$pat = '/^.*' . preg_quote(CMS_URI_ALIAS,'/') . '/';
				$dest = preg_replace($pat,'',$path_info['path']);
				} // if
			else {
				$dest = $path_info['path'];
				} // else
			self::$cms_vfs_redirect_uri = $cms_vfs_redirect_uri;
			} // if
		else if(!empty($_SERVER['REDIRECT_URL'])) {	// has the alias/vf_name
			$cms_vfs_redirect_url = self::chk_engage_vfs_gvars($_SERVER['REDIRECT_URL']);
			$dest = false;
			if(!empty(CMS_URI_ALIAS)) {
				// $dest = substr(self::$cms_vfs_redirect_url,(strlen(CMS_URI_ALIAS)));
				$pat = '/^.*' . preg_quote(CMS_URI_ALIAS,'/') . '/';
				$dest = preg_replace($pat,'',$cms_vfs_redirect_url);
				} // if
			else {
				$dest = $cms_vfs_redirect_url;
				} // else
			self::$cms_vfs_redirect_url = $cms_vfs_redirect_url;
			} // else if
		else return self::$cms_vfs_on;


		$name = preg_replace('/^[\/]+/','',$dest);
		$name = preg_replace('/[?&].*$/','',$name);
		$name = preg_replace('/[\/]+.*$/','',$name);
		if(($result = self::$cDBcms->query("select cms_body_id from cms_bodies where cms_body_name = '" . $name . "' OR cms_body_virtual_name = '" . strtolower($name) . "' limit 1")) &&
			($body = self::$cDBcms->fetch_array($result))) {
			Ccms_base::get_or_post_pushback('body',$body['cms_body_id']);
			self::$cms_vfs_name = $name;
			self::$cms_vfs_dest = $dest;
			self::$cms_vfs_url = preg_replace('/^[\/]*?' . $name . '[\/?&]?/','',$dest);
//			if(!empty($_SERVER['REQUEST_URI'])) {	// the full request URI
//				$request = $_SERVER['REQUEST_URI'];
//				$path_info = parse_url($request);
//				if(!empty($path_info['query'])) {} // if
//				} // if
			self::$cms_vfs_on = true;
			} // if
		else if(isset(self::$cms_vfs_cms_virtuals[$name])) {		// internal cms virtuals
			self::$cms_vfs_name = $name;
			self::$cms_vfs_dest = $dest;
			self::$cms_vfs_url = self::$cms_vfs_cms_virtuals[$name];
			if(preg_match('/^cms_/',$name)) self::get_cms_action($name);
			else self::get_app_action($name);
			self::is_in_auth_mode(true);
			self::$cms_vfs_on = true;
			} // else if
		return self::$cms_vfs_on;
		} // chk_engage_vfs()

// dynamic methods

} // Ccms_vfs
