<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_update.php 3439 2024-04-28 04:44:57Z robert0609 $
 */

/**
 * Description of cms_update
 *
 * Class to check updates for AppsCMS
 * Typical AppsCMS--version.info file;-

#	Applications Management System Library for PHP (AppsCMS)
#	see Licence in cms/LICENCE.txt
#	_SVN_build: svn2428

# AppsCMS Version Info File (Used to check for updates - 20230219-174236).
AppsCMS-Library-version=V3.07.7
AppsCMS-Library-Latest=AppsCMS-Library-V3.07.7zip
AppsCMS-Library-Installer=AppsCMS-Library-V3.07.7sh
AppsCMS-Library-rpm=AppsCMS-Library-V3.07.7-1.svn3191.noarch.rpm
AppsCMS-Docs-rpm=AppsCMS-Docs-V3.07.7-1.svn3191.noarch.rpm

# .EOF.


 * @author robert0609
 */

class Ccms_update extends Ccms_base {

	protected $current_version_info = false;
	protected $current_version_url = false;

	protected $upd_version = false;
	protected $upd_latest_zip = false;
	protected $upd_installer = false;
	protected $upd_rpm = false;

	const INFO_FILE = CMS_PROJECT_SHORTNAME . '-version.info';
	const DIST_PKGS = 'dist-pkgs/';

	function __construct($chk = false) {
		parent::__construct();
		if($chk) $this->get_update_status();
		} // __construct()

	function __destruct() {
		parent::__destruct();

		} // __destruct()

	// static methods

	// dynamic methods
	public function get_rpm_installed_package_status() {
		$sh = CMS_FS_CLI_DIR . 'cms_pkgs_stats.sh';	// returns "AppsCMS-Library-V3.07.7svn2431.noarch.rpm" if installed
		$result = '';
		$installed = '';
		exec($sh, $installed, $result);
		if($result) return false;
		return $installed;
		} // get_rpm_installed_package_status()

	public function get_update_status() {
		if(!CMS_S_CMS_UPDATER_ALLOW_BOOL) {
			self::log_msg('Update checks disabled.');
			return true;
			} // if

		if(!$this->get_current_version_info()) {
			self::addMsg('Failed to retrieve ' . CMS_PROJECT_SHORTNAME . ' update info.','info');
			return false;
			} // if
		if($installed = $this->get_rpm_installed_package_status()) {
			self::addAdminMsg('This ' . CMS_PROJECT_SHORTNAME . ' library installation is a system package ' . CMS_PROJECT_VERSION . ', available library is ' . $this->upd_version . '.','info');
			$cmp = strcasecmp($installed, $this->upd_rpm);
			} // if
		else $cmp = strcasecmp(CMS_PROJECT_VERSION, $this->upd_version);
		if(!$cmp) {
			self::addAdminMsg(CMS_PROJECT_SHORTNAME . ' is up to date (' . $this->upd_version . ').','info');
			self::unset_cms_sess_var(CMS_PROJECT_SHORTNAME,'latest');
			return true;
			} // if
		else if($cmp > 0) {
			self::addAdminMsg(CMS_PROJECT_SHORTNAME . ' (' . CMS_PROJECT_VERSION . ') is higher version than update (' . $this->upd_version . ').','info');
			self::unset_cms_sess_var(CMS_PROJECT_SHORTNAME,'latest');
			return true;
			} // if
		// else needs update ????
		self::addAdminMsg('This ' . CMS_PROJECT_SHORTNAME . ' library installation is ' . CMS_PROJECT_VERSION . ', available library is ' . $this->upd_version . '.','info');
		if(self::have_session()) {
			if(!is_array(self::get_cms_sess_var(CMS_PROJECT_SHORTNAME)))
				self::set_cms_sess_var(array(),CMS_PROJECT_SHORTNAME);
			self::set_cms_sess_var($this->upd_version,CMS_PROJECT_SHORTNAME,'latest');
			} // if
		// now what
		return false;
		} // get_update_status()

	protected function get_current_version_info() {
		if($this->upd_installer) return true;	//already done
		$primary = CMS_S_CMS_UPDATER_BASE_URI;
		$secondary = CMS_S_CMS_UPDATER_ALT_BASE_URI;
		$sorc_chks = array();
		if(!empty($primary)) {
			$sorc_chks[] = self::clean_path($primary . '/' . self::INFO_FILE);
			$sorc_chks[] = self::clean_path($primary . '/' . self::DIST_PKGS . self::INFO_FILE);
			} // if
		if(!empty($secondary)) {
			$sorc_chks[] = self::clean_path($secondary . '/' . self::INFO_FILE);
			$sorc_chks[] = self::clean_path($secondary . '/' . self::DIST_PKGS . self::INFO_FILE);
			} // if
		$con_opts = array(
			'http'=> array(
				'timeout' => (float)CMS_S_CMS_UPDATER_TIMEOUT,
				// 'max_redirects' => 1,
				),);
		foreach($sorc_chks as $url) {
			$streamContext = stream_context_create($con_opts);
			$info = @file_get_contents($url,false,$streamContext);
			if(!empty($info)) {
				$this->current_version_info = $info;
				$this->current_version_url = $url;
				break;
				} // if
			} // foreach
		if(empty($this->current_version_info))
			return false;
		// else gotcha
		$info_lines = explode(PHP_EOL, $this->current_version_info);
		foreach($info_lines as $line) {
			if(preg_match('/^[#;]|^\/\/|^$/',$line)) continue;	// comments
			list($name,$val) = explode('=',$line);
			switch($name) {
			case CMS_PROJECT_SHORTNAME . '-version':
				$this->upd_version = $val;
				break;
			case CMS_PROJECT_SHORTNAME . '-latest':
				$this->upd_latest_zip = $val;
				break;
			case CMS_PROJECT_SHORTNAME . '-installer':
				$this->upd_installer = $val;
				break;
			case CMS_PROJECT_SHORTNAME . '-rpm':
				$this->upd_rpm = $val;
				break;
			default:
				// ???
				break;
				} // switch
			} // foreach
		return true;
		} // get_current_version_info()

} // Ccms_update
