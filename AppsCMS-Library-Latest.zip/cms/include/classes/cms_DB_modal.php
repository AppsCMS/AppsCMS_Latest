<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_modal.php 2793 2022-09-10 06:40:19Z robert0609 $
 */

/**
 * Description of Ccms_DB_modal
 *
 * Single row DB editing modal dialog box
 * These classes Ccms_DB_modal (the modal controller) and
 * Ccms_DB_modal_editor (the DB data editor)
 * run using a Ccms_modal generated modals (not all displayed together but one by one)
 *
 * These objective is to all multiple dialogs to be available
 *
 * @author robert0609
 */

class Ccms_DB_modal_editor extends Ccms_DB_edit_sql {	// private class

	function __construct(&$cEditDB,$cms_app_name,$form_name,$install_scripts,$class = '') {
		// similar to Ccms_DB_edit::_construct();
		parent::__construct();
		$this->cEditDB = $cEditDB;
		if($this->cEditDB) {
			$this->db_name_id = $this->cEditDB->get_DB_signat();
			$this->edit_DB_info = self::get_cms_sess_var($this->db_name_id,'edit_DB_info');	// recover data
			} // if

		$this->edit_DB_info['install_scripts'] = $install_scripts;
		$this->edit_DB_info['form_name'] = $form_name;

		if(empty($class)) {
			$this->class = 'page_database page_database_dlg';
			} // if
		else {
			$this->class = $class;
			} // else
		$this->get_DB_form_data();

		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

// dynamic methods
	protected function get_DB_dlg_styles() {
		static $done = false;
		if($done) return '';
		$done = true;

		$text = <<< EOTSTY

		<style>

			div.form_container {
				display: flex;
				}

			div.form_element {
				display: inline-block;
				vertical-align: top;
				}

		</style>

EOTSTY;

		return $text;
		} // get_DB_dlg_styles()

	protected function get_DB_edit_new_row(&$table_details,$table) {
		$edit = &$table_details['edit'];
		$columns = &$edit['columns'];
		$row = array();
		foreach($columns as $col => &$v) {
			if(($edit['row_id_name'] != $col) &&
				($this->edit_DB_info['required_form']) &&
				(((!isset($columns[$col]['required'])) || (!$columns[$col]['required']))))
				continue;	// not required
			$row[$col] = "";
			} // foreach
		return $row;
		} // get_DB_edit_new_row()

	protected function get_DB_edit_row(&$table_details,$table,$row_id) {
		if($row_id == self::NO_INDEX_STR)
			return $this->get_DB_edit_new_row ($table_details, $table);

		$edit = &$table_details['edit'];
		$columns = &$edit['columns'];
		$sql = 'SELECT ';
		foreach($columns as $col => &$v) {
			if(($edit['row_id_name'] != $col) &&
				($this->edit_DB_info['required_form']) &&
				(((!isset($columns[$col]['required'])) || (!$columns[$col]['required']))))
				continue;	// not required
			$sql .= $col . ',';
			} // foreach
		$sql = substr($sql,0,-1); // remove last comma
		$sql .= ' FROM ' .$table;
		$sql .= ' WHERE ' . $edit['row_id_name'] . ' = ' . $row_id . ';';
		if(($result = $this->cEditDB->query($sql)) &&
			($row = $this->cEditDB->fetch_array_assoc($result))) {
			return $row;
			} // if
		return false;	// ????
		} // get_DB_edit_row()

	public function get_dlg_DB_row_text($action_uri,$ajax_uri,$table,$row_id) {
		if((!$this->cEditDB) && (!$this->cEditDB->is_ok())) {
			self::addDebugMsg('Dialog cannot find DB connection.');
			return '';
			} // if
		if(!isset($this->edit_DB_info['install_scripts'][$table]['edit'])) {
			self::addDebugMsg('Dialog missing DB table value.');
			return '';
			} // if
		$this->action_uri = $action_uri;
		$this->ajax_uri = $ajax_uri;
		$edit_info = &$this->edit_DB_info;
		$edit = &$edit_info['install_scripts'][$table]['edit'];
		$table_details = &$edit_info['install_scripts'][$table];
		$table_heading = (!empty($edit['text']) ? $edit['text']:$table);
		$table_title = '';
		if(!empty($edit['title'])) {
			$table_title .= ' onload="cms_addElem_title2tooltip(this);"';
			$table_title .= ' title="' . $edit['title'] . '"';
			} // if

		$text = $this->get_DB_dlg_styles();
		$text .= <<< EOTPAN
		<div>
			<h2{$table_title}>Table: {$table_heading}</h2>
		</div>
		<div class="form_container">

EOTPAN;

		$edit_info['free_form'] = 1;	// put it in edit mode @TODO later
		$edit_info['row_editor'] = true;

		$text .= '<form name="' . $edit_info['form_name'] . '" action="' . $action_uri . '" method="post" enctype="multipart/form-data">' . PHP_EOL;
		$text .= '<input type="hidden" name="form_name" value="' . $edit_info['form_name'] . '">' . PHP_EOL;
		$text .= '<input type="hidden" name="table" value="' . $table . '">' . PHP_EOL;
		if($table_op = self::get_or_post('table_op')) {
			if(($table_op == 'new') && ((int)$row_id <= 0))
				$row_id = self::NO_INDEX_STR;
			$text .= '<input type="hidden" name="table_op" value="' . $table_op . '">' . PHP_EOL;
			} // if
		$text .= '<input type="hidden" name="row_id" value="' . $row_id . '">' . PHP_EOL;
		$row = $this->get_DB_edit_row($table_details, $table, $row_id);
		if((!$row) || (!is_array($row))) return '';
		foreach($row as $col => $val) {
			$col_info = $table_details['edit']['columns'][$col];
			if((!empty($col_info['readonly'])) && ($col_info['readonly'])) continue;
			if(empty($col_info['name'])) $col_info['name'] = $col;	// add column name (column name used on form may different)
			$js_func = '';
			$has_inputs = false;
			$elem = $this->get_DB_form_elem($table_details,$col,$row_id,$col_info,$row,$js_func) . PHP_EOL;
			if($col_info['type'] == 'hidden')
				$text .= $elem . PHP_EOL;
			else {
				if($col_info['type'] != 'show') $has_inputs = true;
				$text .= '<div class="' . $this->class . ' form_element">' . PHP_EOL;
				$text .= '	<div class="' . $this->class . ' form_element">' . PHP_EOL;
				$text .= '	<h3 class="page_config">' . $col_info['head'] . '</h3>' . '<br>';
				$text .= $elem . PHP_EOL;
				$text .= '	</div>' . PHP_EOL;
				$text .= '</div>' . PHP_EOL;
				} // else
			} // foreach
		// put in controls

		$text .= PHP_EOL. '<hr>' . PHP_EOL;
		$text .= '<div style="white-space: nowrap; text-align: center;">';
		//$text .= '<button type="submit" name="submit" value="previous">Previous</button>&nbsp;';
		if($has_inputs) {
			$text .= '<button type="submit" name="submit" value="save">Save</button>&nbsp;';
			$text .= '<button type="button" name="submit" value="cancel"' .
				' onclick="window.location.href = \'' . $action_uri . '&table=' . $table . '&row_id=' . $row_id . '\';" ' .
				'formnovalidate>Cancel</button>&nbsp;';
			} // if
		else {
			$text .= '<button type="button" name="submit" value="cancel"' .
				' onclick="window.location.href = \'' . $action_uri . '&table=' . $table . '&row_id=' . $row_id . '\';" ' .
				'>Close</button>&nbsp;';
			} // else
		//$text .= '<button type="submit" name="submit" value="next">Next</button>&nbsp;';
		$text .= '</div>';
		$text .= '</form>' . PHP_EOL;
		$text .= '</div>' . PHP_EOL;
		return $text;
		} // get_dlg_DB_row_text()

} // Ccms_DB_modal_editor

class Ccms_DB_modal extends Ccms_modal {

	protected $cDBeditorDlg = false;

		function __construct($cms_app_name = false) {
		// $cms_app_name has a matching class $cms_app_name . '_app'
		if(!empty($cms_app_name)) self::$cms_app_name = $cms_app_name;
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

// dynamic methods

	public function get_DB_edit_modal_ajax($cEditDB,$action_uri,$ajax_uri,$form_name,$install_scripts,
		$class_name = '', $h1 = '', $header = '', $footer = '', $name = '') {
		// parameters come from the calling app

		$table = self::get_or_post('table');
		$row_id = self::get_or_post('row_id');
		$this->cDBeditorDlg = new Ccms_DB_modal_editor($cEditDB,self::$cms_app_name,$form_name,$install_scripts,$class_name);
		if(!$this->cDBeditorDlg) return false;

		if(empty($name)) $name = '_DB';
		$id = 'id_DB_dlg_';

		$body_text = $this->cDBeditorDlg->get_dlg_DB_row_text($action_uri,$ajax_uri,$table, $row_id);

		$cModal = new Ccms_modal();
		echo $cModal->get_modal($id, $body_text, $class_name, $h1, $header, $footer, $name);

		$cModal_name = $cModal->get_name();

		echo <<< EOT_DBE

	<style>
		div.{$cModal_name}_content {
			/*height: {$this->theme['MODAL_HEIGHT']};*/
			/*width: {$this->theme['MODAL_WIDTH']};*/
			padding: 5px;
			}

		div.{$cModal_name}_modal {
			scroll-behavior: auto;
			overflow: scroll;
			padding: 5px;
			}

		img.logo_{$id} {
			height: 35px;
			}

	</style>

	<script type="text/javascript">
		function show_DBeditDlg_modal() {
			{$cModal_name}_open_modal();
			} // show_DBeditDlg_modal()

		show_DBeditDlg_modal();	// keep dialog open is message/s
	</script>
EOT_DBE;

		} // get_DB_edit_modal_ajax()

	public function get_DB_edit_modal($h1 = '',$cms_plugin = '') {

	// some checks
	// some checks
	if(!empty($cms_plugin)) {
		$actor = '&plugin=' . $cms_plugin;
		} // if
	else {
		$cms_app = self::$cms_app_name;
		if(!$cms_app) return false;
		$actor = '&app=' . $cms_app;
		} // else

	echo <<< EOT_DBE

<span id="id_DBeditDlg_modal_text" name="DBeditDlg_modal_text"></span>

<script type="text/javascript">

	function ajax_load_cmsDBeditDlg(table,row_id,obj) {

		if(typeof 'show_DBeditDlg' === 'function') {	// already there
			show_DBeditDlg();
			return;
			} // if
		var body_name_id = 'id_DBeditDlg_modal_text';
		// if(body_name_id.length < 4) return;

		var body_url = 'show_DBeditDlg{$actor}&table=' + table + '&row_id=' + row_id;
		if(!cms_ajaxOps[body_name_id]) {
			var op_data = false;	// no operational data (i.e. posts)
			var run_scripts = true;	// runs the internal javascripts in ajax return
			var feedback = '<div style="float: right;">Retrieving DB edit Dlg ... <img alt="loading" src="cms/images/ajax-loader.gif"></div>';
			// proto of constructor Ccms_ajaxOps(ajax_url_op,ajax_feedback_id,ajax_result_id,op_data,run_scripts) {	// class to hold the everything
			cms_ajaxOps[body_name_id] = new Ccms_ajaxOps(body_name_id,body_name_id,op_data,run_scripts,feedback);
			} // if

		// do ajax request
		var post_data = '';	// no data to post
		var res = cms_ajaxOps[body_name_id].doAjaxRequest(body_url,post_data);
		return res;
		} // ajax_load_cmsDBeditDlg()

	// hide_DBeditDlg_dialog();

	// ajax_load_cmsDBeditDlg('transactions',10);	// test

</script>

EOT_DBE;

		} // get_DB_edit_modal()

} // Ccms_DB_modal
