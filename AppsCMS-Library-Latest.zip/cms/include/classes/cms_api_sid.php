<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api_sid.php 2868 2022-10-15 02:59:04Z robert0609 $
 */

/**
 * Description of Ccms_api_sid
 * API execute class
 *
 * Use session id
 *
 * @author robert0609
 */

require_once 'cms_api_base.php';	// speed up for proxy (no autoloader needed)

class Ccms_api_sid extends Ccms_api_base {	// SID class

	private static $sid_api_token = null;

	function __construct() {
		self::is_use_sid_ok();
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		// clean before I go home
		} // __destruct()

	// static methods
	public static function is_use_sid_ok() {	// check if SID ok
		if((!self::is_api()) || (!CMS_C_API_ENABLE) || (CMS_C_API_AUTH != 'SID')) {
			return false;
			} // if
		return true;
		} // is_use_sid_ok()

	public static function get_api_token($set = null) {
		if(!is_null($set)) self::$sid_api_token = $set;
		if(is_null(self::$sid_api_token)) {
			if(!self::is_use_sid_ok ()) self::$sid_api_token = false;
			else {
				if(!empty(self::$api_request_headers[Ccms_api_base::API_JWT_KEY]))
					self::$sid_api_token = self::$api_request_headers[Ccms_api_base::API_JWT_KEY];
				else if($sid = session_id()) self::$sid_api_token = $sid;
				else self::$sid_api_token = false;
				} // else
			} // if
		return self::$sid_api_token;
		} // get_api_token()

	// dynamic methods
	public function add_response_headers() {
		if(!self::is_use_sid_ok()) return false;
		// examples expires=Wed, 14 Jun 2017 07:00:00 GMT or (Mozilla example)
		// expires=Tue, 24-Aug-2021 14 or (seen by dbg, note no minutes, seconds or GMT)
		// expires=Thu, 26 Aug 2021 13:49:36 +1000 (RFC2822)
		if(!empty(self::$cms_session_timeout)) {	// on browser (?) or CLI or similar client
			self::$api_response_headers['Expires'] = date('r', ((int)self::$cms_session_timeout + time()));	 // RFC2822 format
			} // if
		else {
			self::$api_response_headers['Expires'] = date('r', ((int)CMS_S_SESSIONS_API_TIMEOUT_SECS + time()));	 // RFC2822 format
			} // else
		if(!empty(self::get_api_token()))
			self::$api_response_headers[self::API_TOK_KEY] = self::get_api_token();
		} // add_response_headers()

	public function make_sid($user_id,$extra = false) {	// for results
		if(!self::is_use_sid_ok()) return false;
		return self::get_api_token();
		} // make_sid()

} // Ccms_api_sid

