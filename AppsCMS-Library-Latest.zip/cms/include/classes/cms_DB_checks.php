<?php
/*
 * Applications Management System Library Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_checks.php 3248 2023-03-01 06:34:03Z robert0609 $
 */

/**
 * Description of Ccms_DB_checks
 *
 * Provides common methods for generation for editing database table row based arrays.
 *
 * @author robert0609
 */

class Ccms_DB_checks extends Ccms_html {

	const APP_TYPE_NONE = 0;
	const APP_TYPE_COUPLED = 1;
	const APP_TYPE_SIMPLE = 2;
	const APP_TYPE_STANDARD = 3;
	const APP_TYPE_LINKED = 4;
	const APP_TYPE_BASIC = 5;

	private static $last_posted_data = false;
	private static $db_conf =false;

	protected $sect_idx = 0;

	protected static $js_done = false;
	
	private static $cms_apps_types = false;			

	protected static $cCMS_C = false;

	const TOOL_URL_LEN_MIN = 6;

	function __construct($name = false, $h1 = false, $db_row = false, $comments_json = false, $opts_ary = false) {
		parent::__construct();
		if(($name) && ($db_row) && ($comments)) {	// the must have

			$this->show_edit_ini_json_page($name, $h1, $conf, $comments_json, $opts_ary);
			} // if
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function sanitize_DB_table($table,&$row, $use_defaults = true) {
		if(!is_array($row)) {
			if(!$use_defaults) return false;
			$row = array();
			} // if
		if(!self::$db_conf) 
			self::$db_conf = Ccms_DB_install::get_installDBscriptsSQLite();
		if(!isset(self::$db_conf [$table])) {
			self::addAdminMsg('Attempt to sanitize data for non existant table: ' . $table);
			return false;
			} // if
		$columns = &self::$db_conf[$table]['columns'];
		$id_col = self::$db_conf[$table]['id'];
		$ok = true;
		$err_cnt = 0;
		foreach($columns as $c => $t) {
			if($c == $id_col) continue;
			// usually caused by changes in DB schema
			if((!isset($row[$c])) || (is_null($row[$c]))) {
				$err_cnt++;
				if($use_defaults) {
					if(preg_match('/default/i', $t)) {
						$v = preg_replace('/^.*default[\s]*(.*)$/i','$1', $t);
						switch($v) {
						case "''": $v = ''; break;
						case '""': $v = ''; break;
						default: break;							
							} // switch
						$row[$c] = $v;
						} // if
					else {
						$v = preg_replace('/^([a-zA-Z]*).*$/i','$1', $t);
						switch(strtoupper($v)) {	// from SQLite
						case 'DATETIME': $row[$c] = self::get_gm_datetime(); break; 	
						case 'INTEGER': $row[$c] = 0; break; 
						case 'BOOLEAN': $row[$c] = 0; break; 
						case 'TEXT': $row[$c] = ''; break; 
						case 'VARCHAR': $row[$c] = ''; break; 
						default: $row[$c] = 'N.K.'; break;	
							} // switch
						} // else
					} // if
				$ok = false;
				} // if
			} // foreach 
		return $ok;		
		} // sanitize_DB_table()
	
	public static function is_user_password_ok($cms_user_auth_ldap,&$cms_user_password,&$cms_user_confirm, $op = false) {
		if($cms_user_auth_ldap) {
			if(!Ccms_auth::is_ldap_ok()) {
				self::addMsg('LDAP authentication not available.','warn');
				} // if
			} // if
		if(((!$cms_user_auth_ldap) && ($op == 'insert')) ||
			(strlen($cms_user_password) > 0) ||
			(strlen($cms_user_confirm) > 0)) {
			$pwd_chks = self::get_password_chk_regex();
			if(strlen($cms_user_password) < LM_C_MIN_PASSWD_LEN) {
				self::addMsg('Password too short.');
				return false;
				} // else if
			else if(!preg_match('/' . $pwd_chks	['pattern'] .'/', $cms_user_password)) {
				self::addMsg('Password does not meet requirements (' . $pwd_chks['title'] . ').');
				return false;
				} // else if
			else if($cms_user_password != $cms_user_confirm) {
				self::addMsg('Password/confirm error.');
				return false;
				} // if
			$idx = 0;
			while($idx < strlen($cms_user_password)) {
				$cChr = ord(substr($cms_user_password, $idx++,1));
				if(($cChr < 32) ||
					($cChr >= 128)) {
					self::addMsg('Password contains prohibited non-printable/control characters.');
					return false;
					} // ifF
				} // while
			if(preg_match('/[\\\'\’\"]/', $cms_user_password)) {
				self::addMsg('Password contains prohibited characters (i.e. &#92; &rsquo; &#96; or &quot;).');
				return false;
				} // if
			return true;	// ok
			} // if

		if($cms_user_auth_ldap) {
			$cms_user_confirm = $cms_user_password = date('Ymd');
			return true;
			} // if
		return false;
		} // is_user_password_ok()

	private static function is_DB_value_unique($table, $column, $value, $op, $where_suffix, $err_msg = false, $opt_prefix = false) {
		if(empty($value)) return false;
		$sql_query = "SELECT " . $column . " FROM " . $table . " WHERE " . $column . " = '" . self::$cDBcms->input($value) . "'";
		if(($op != 'insert') && (!empty($where_suffix))) $sql_query .= ' AND ' . $where_suffix;
		if((!$result = self::$cDBcms->query($sql_query)) ||
			(!$rows = self::$cDBcms->num_rows($result)) ||
			(($op == 'insert') && ($rows < 1)) ||
			(($op != 'insert') && ($rows == 1))) {
			self::$cDBcms->free_result($result);
			return $value;	// it's unique
			} // if
		if(!empty($opt_prefix)) {	// no good so try the prefix
			$new_value = self::is_DB_value_unique($table, $column,($opt_prefix . $value), $op, $where_suffix, $err_msg);
			if($new_value) return $new_value;
			} // if
		if((!empty($err_msg)) && ((int)$rows > 0)) self::addMsg($err_msg);
		return false;
		} // is_DB_value_unique()

	private static function is_DB_mobile_unique($table, $column, $value, $op, $where_suffix, $err_msg = false) {
		if(empty($value)) return false;
		
		$sql_query = "SELECT " . $column . " FROM " . $table;
		if(($op != 'insert') && (!empty($where_suffix))) $sql_query .= ' WHERE ' . $where_suffix;
		if((!$result = self::$cDBcms->query($sql_query)) ||
			(!$rows = self::$cDBcms->num_rows($result)) ||
			(($op == 'insert') && ($rows < 1)) ||
			(($op != 'insert') && ($rows == 1))) {
			self::$cDBcms->free_result($result);
			return $value;	// it's unique
			} // if
		while($row = self::$cDBcms->fetch_array($result)) {
			if(self::is_mobile_numbers_same($value, $row[$column])) {
				if((!empty($err_msg)) && ((int)$rows > 0)) self::addMsg($err_msg);
				return false;
				} // if
			} // while
		return $value;	// unique
		} // is_DB_mobile_unique()

	public static function is_group_name_ok($cms_group_name, $op, $where_suffix) {
		if((empty($cms_group_name)) || (strlen($cms_group_name) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('Group name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_groups','cms_group_name', $cms_group_name, $op, $where_suffix,
			'Group name "' . $cms_group_name . '" already in use');
		} // is_group_name_ok()

	public static function is_user_name_ok($cms_user_name, $op, $where_suffix) {
		if((empty($cms_user_name)) || (strlen($cms_user_name) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('User name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_users','cms_user_name', $cms_user_name, $op, $where_suffix,
			'User name "' . $cms_user_name . '" already in use.');
		} // is_user_name_ok()

	public static function is_user_email_ok(&$cms_user_email, $op, $where_suffix) {
		if(empty($cms_user_email)) {
			if(CMS_C_USER_EMAIL_REQUIRED) {
				self::addMsg('User email address required.');
				return false;
				} // if
			return true; // empty and not required
			} // if
		if(strlen($cms_user_email) < 8) {
			self::addMsg('User email address "' . $cms_user_email . '" too short.');
			return false;
			} // if

		if(!self::$cCMS_C) self::$cCMS_C = new Ccms_config_funcs();
		$cms_user_email = self::$cCMS_C->get_email('', $cms_user_email);
		if(empty($cms_user_email)) return false;	// scrapped
		return self::is_DB_value_unique('cms_users','cms_user_email', $cms_user_email, $op, $where_suffix,
			'Email address "' . $cms_user_email . '" in use.');
		} // is_user_email_ok()

	public static function is_user_mobile_ok(&$cms_user_mobile, $op, $where_suffix) {
		if(empty($cms_user_mobile)) {
			if(CMS_C_USER_MOBILE_REQUIRED) {
				self::addMsg('User mobile/phone number required.');
				return false;
				} // if
			return true; // empty and not required
			} // if
		if(strlen($cms_user_mobile) < 9) {
			self::addMsg('User mobile/phone number "' . $cms_user_mobile . '" too short.');
			return false;
			} // if
		if(!self::$cCMS_C) self::$cCMS_C = new Ccms_config_funcs();
		$cms_user_mobile = self::$cCMS_C->get_phone_number('', $cms_user_mobile);
		if(empty($cms_user_mobile)) return false;	// scrapped
		return self::is_DB_mobile_unique('cms_users','cms_user_mobile', $cms_user_mobile, $op, $where_suffix,
			'Mobile "' . $cms_user_mobile . '" already in use.');
		} // is_user_mobile_ok()

	public static function is_link_name_ok($lm_link_name, $op, $where_suffix) {
		if((empty($lm_link_name)) ||
			(strlen($lm_link_name) < LM_C_MIN_NAME_LEN) && (substr($lm_link_name,-1) !='/')) {	// not long enough and not an alias
			self::addMsg('Link name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('lm_links','lm_link_name', $lm_link_name, $op, $where_suffix,
			'Link name already in use.');
		} // is_link_name_ok()

	public static function is_section_name_ok($lm_section_name, $op, $where_suffix) {
		if((empty($lm_section_name)) || (strlen($lm_section_name) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('Section name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('lm_sections','lm_section_name', $lm_section_name, $op, $where_suffix,
			'Section name already in use.');
		} // is_section_name_ok()

	public static function is_body_name_ok($cms_body_name, $op, $where_suffix, $cms_body_prefix) {
		if((empty($cms_body_name)) || (strlen($cms_body_name) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('App / body name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		if(!Ccms_app_base::is_app_name_allowed($cms_body_name)) {
			self::addMsg('App / body name not allowed (used internally).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_bodies','cms_body_name', $cms_body_name, $op, $where_suffix,
			'App / body name already in use.', $cms_body_prefix);
		} // is_body_name_ok()

	public static function is_body_app_key_ok($cms_body_app_key, $op, $where_suffix, $cms_body_prefix) {
		if((empty($cms_body_app_key)) || (strlen($cms_body_app_key) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('App name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_bodies','cms_body_app_key', $cms_body_app_key, $op, $where_suffix,
			'App name already in use.', $cms_body_prefix);
		} // is_body_app_key_ok()

	public static function is_virtual_name_ok($cms_body_virtual_name, $op, $where_suffix, $cms_body_prefix) {
		if(empty($cms_body_virtual_name)) return true;	// optional
		if(strlen($cms_body_virtual_name) < LM_C_MIN_NAME_LEN) {
			self::addMsg('App / body virtual name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_bodies','cms_body_virtual_name', $cms_body_virtual_name, $op, $where_suffix,
			'App / body virtual name already in use.', $cms_body_prefix);
		} // is_virtual_name_ok()

	public static function is_app_dir_ok($cms_body_dir, $op, $where_suffix, $cms_body_prefix) {
	if((empty($cms_body_dir)) || (strlen($cms_body_dir) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('App / body directory name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		if((CMS_C_ALLOW_APPS_DIR_SHARE) && ($op != 'clone')) {
			// dirs have to the same or completely different for INI keys
//			$similar_name = self::$cDBcms->get_data_in_table('cms_bodies','cms_body_dir',"cms_body_dir != '" . self::$cDBcms->input($cms_body_dir) . "' AND cms_body_dir LIKE '%" . self::$cDBcms->input($cms_body_dir) . "%'");
//			if(!empty($similar_name)) $cms_body_dir = $similar_name;	// make dir name same
			if(!self::is_DB_value_unique('cms_bodies','cms_body_dir', $cms_body_dir, $op, $where_suffix)) {
				self::addMsg('App / body directory is shared.','warn');
				return $cms_body_dir;	// its ok
				} // if
			} // if
		return self::is_DB_value_unique('cms_bodies','cms_body_dir', $cms_body_dir, $op, $where_suffix,
			'App / body directory likeness already in use.', $cms_body_prefix);
		} // is_app_dir_ok()

	public static function is_body_file_required($cms_body_type) {
		switch($cms_body_type) {
		case self::APP_TYPE_NONE:
			break;
		case self::APP_TYPE_COUPLED:
			break;
		case self::APP_TYPE_SIMPLE:
			break;
		case self::APP_TYPE_STANDARD:
			break;
		case self::APP_TYPE_LINKED:
			break;
		case self::APP_TYPE_BASIC:
			break;
		default:
			self::addDebugMsg('Unknown app type; ' . $cms_body_type);
			return false;
			} // switch
		return true;
		} // is_body_file_required()

	public static function is_body_api_allowed($cms_body_type) {
		switch($cms_body_type) {
		default:
		case self::APP_TYPE_NONE:
		case self::APP_TYPE_SIMPLE:
		case self::APP_TYPE_LINKED:
		case self::APP_TYPE_BASIC:
			return false;	// app does not support API calls
		case self::APP_TYPE_COUPLED:
		case self::APP_TYPE_STANDARD:
			break;
			} // switch
		return true;
		} // is_body_api_allowed()

	public static function is_body_file_ok($cms_body_type, $cms_body_file, $op, $where_suffix, $cms_body_prefix) {
		if((empty($cms_body_file)) || (strlen($cms_body_file) < (LM_C_MIN_NAME_LEN + 4))) {
			self::addMsg('App / body filename (URL) too short (minimum of ' . (LM_C_MIN_NAME_LEN + 4) . ' characters).');
			return false;
			} // if
		switch($cms_body_type) {
		case self::APP_TYPE_NONE:
			break;
		case self::APP_TYPE_COUPLED:
			break;
		case self::APP_TYPE_SIMPLE:
			break;
		case self::APP_TYPE_STANDARD:
			break;
		case self::APP_TYPE_LINKED:
			break;
		case self::APP_TYPE_BASIC:
			break;
		default:
			self::addDebugMsg('Unknown app type; ' . $cms_body_type);
			return false;
			} // switch
		$file_ext = pathinfo($cms_body_file,PATHINFO_EXTENSION);
		if(empty($file_ext)) $cms_body_file = preg_replace('/\.$/','', $cms_body_file) . '.htm';	// remove trailing dot and use default extension
		return self::is_DB_value_unique('cms_bodies','cms_body_file', $cms_body_file, $op, $where_suffix,
			'App / body file name already in use.', $cms_body_prefix);
		} // is_body_file_ok()

	public static function is_tool_name_ok($cms_tool_name, $op, $where_suffix) {
		if((empty($cms_tool_name)) || (strlen($cms_tool_name) < LM_C_MIN_NAME_LEN)) {
			self::addMsg('Tool name too short (minimum of ' . LM_C_MIN_NAME_LEN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_tools','cms_tool_name', $cms_tool_name, $op, $where_suffix,
			'Tool name already in use.');
		} // is_tool_name_ok()

	public static function is_tool_url_ok($cms_tool_url, $op, $where_suffix) {
		if((empty($cms_tool_url)) || (strlen($cms_tool_url) < self::TOOL_URL_LEN_MIN)) {
			self::addMsg('Tool URL too short (minimum of ' . self::TOOL_URL_LEN_MIN . ' character).');
			return false;
			} // if
		return self::is_DB_value_unique('cms_tools','cms_tool_url', $cms_tool_url, $op, $where_suffix,
			'Tool URL already in use.');
		} // is_tool_url_ok()

	public static function &get_apps_types_configs() {
		if(!empty(self::$cms_apps_types)) return self::$cms_apps_types;
		self::$cms_apps_types = array(
			// index by type number
			self::APP_TYPE_NONE => array(
				'name' => '(not set)',
				'title' => 'Application type not set',
				'desc' => 'Application type not set.',
				'cron' => false,
				),
			self::APP_TYPE_COUPLED => array(
				'name' => 'Coupled',
				'title' => 'Close Coupled Application',
				'desc' => 'This application has its code intimately bound to other applications (and possibly to the ' . CMS_PROJECT_SHORTNAME . ' library).' .
					' This type loses modularity because of the close relationship with other applications.' .
					' The ' . CMS_PROJECT_SHORTNAME . ' supports application API server calls.' .
					' The application usually has most of its code in &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot;  directory' .
					' or in the &quot;' . APPS_BODIES_DIR . '&quot; directory.',
				'app_dirs' => array(
					'classes',
					'docs',
					'plugins',
					'include',
					'images',
					'icons',
					'backgrounds',
					'css',
					'js',
					'ini',
					'cli',
					'lib',
					),
				'cron' => true,
				'api' => true,
				),
			self::APP_TYPE_SIMPLE => array(
				'name' => 'Simple',
				'title' => 'Simple Application',
				'desc' => 'A simple application with code in one file in the &quot;' . APPS_BODIES_DIR . '&quot; directory.' .
						' The simple application has no API support for API server calls.' .
						' It uses the ' . CMS_PROJECT_SHORTNAME . ' library functionality to minimize code requirements.',
				'cron' => false,
				'api' => false,
				),
			self::APP_TYPE_BASIC => array(
				'name' => 'Basic',
				'title' => 'Basic Application',
				'desc' => 'A basic application has most of its code in the &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot; directory.' .
					' The application &quot;body file&quot; in &quot;' . APPS_BODIES_DIR . '&quot; usually provides a hook, include or link' .
					' to the application code in &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot; directory.' .
					' This makes a modular application that is independent of other applications and ' . CMS_PROJECT_SHORTNAME . ' library.' .
					' It may or may not use the ' . CMS_PROJECT_SHORTNAME . ' library functionality (leaving the ' . CMS_PROJECT_SHORTNAME . ' to provide basic access control).' .
					' Although in most cases the ' . CMS_PROJECT_SHORTNAME . ' base classes are usually engaged to provide base line functionality from the ' . CMS_PROJECT_SHORTNAME . ' library.' .
					' The ' . CMS_PROJECT_SHORTNAME . ' does not support application API server calls.' .
					' Basic modular is an independent application in its own application &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot;  directory.' .
					' Basic application does not have/need the ' . CMS_PROJECT_SHORTNAME . ' directory like a standard application. The ' . CMS_PROJECT_SHORTNAME . ' only provides the &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot; directory.' .
					' The ' . CMS_PROJECT_SHORTNAME . ' does not support for CRON job settings.' .
					' Basic applications are more suited js frameworks (e.g. vueJS, AngularJS, etc.) having an empty &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot; directory.',
				'app_dirs' => array(),
				'cron' => false,
				'api' => false,
				),
			self::APP_TYPE_STANDARD => array(
				'name' => 'Standard',
				'title' => 'Standard Application',
				'desc' => 'A standard application has all of its code in the &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot; directory.' .
					' The application &quot;body file&quot; in &quot;' . APPS_BODIES_DIR . '&quot; usually provides a hook, include or link' .
					' to the application code in &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot; directory.' .
					' This makes a modular application that is independent of other applications and ' . CMS_PROJECT_SHORTNAME . ' library.' .
					' It may or may not use the ' . CMS_PROJECT_SHORTNAME . ' library functionality (leaving the ' . CMS_PROJECT_SHORTNAME . ' to provide basic access control).' .
					' Although in most cases the ' . CMS_PROJECT_SHORTNAME . ' base classes are usually engaged to provide base line functionality from the ' . CMS_PROJECT_SHORTNAME . ' library.' .
					' The ' . CMS_PROJECT_SHORTNAME . ' supports application API server calls.' .
					' Standard modular is an independent application in its own application &quot;' . APPS_WS_DIR . '(APP_DIR)/&quot;  directory.' .
					' Standard application has the ' . CMS_PROJECT_SHORTNAME . ' standard directory allowing ajax, API and crom interfacing to the application by the ' . CMS_PROJECT_SHORTNAME . '.' .
					' Standard applications have independent CRON job settings.',
				'app_dirs' => array(
					'classes',
					'docs',
					'plugins',
					'include',
					'images',
					'icons',
					'backgrounds',
					'css',
					'js',
					'cli',
					'ini',
					'lib',
					),
				'cron' => true,
				'api' => true,
				),
			self::APP_TYPE_LINKED => array(
				'name' => 'Linked',
				'title' => 'Linked Application',
				'desc' => 'A linked (i.e. symlinked) application lives by itself (for the most part)' .
					' but can use most of the ' . CMS_PROJECT_SHORTNAME . ' library functionality (including global variables, plugins and classes).' .
					' The ' . CMS_PROJECT_SHORTNAME . ' library passes operation to the linked application after checking required credentials, etc.' .
					' The link is usually a symbolic link (e.g. MyAPP.php -> /some/dir/code.php) into the &quot;' . APPS_BODIES_DIR . '&quot; directory and does not have any code in the docroot structure.' .
					' The linked application has no API support for API server calls.' .
					' Some extra web server settings (e.g. FollowSymLinks option - often on by default)' .
					' will be required to run this type of application.Linked (or symlinked) independent application in its own location.',
				'cron' => false,
				'api' => false,
				),
			);
		return self::$cms_apps_types;
		} // get_apps_types_configs()

	public static function get_apps_types_descriptions($heading = '', $drop_box = false) {
		$cms_apps_types = self::get_apps_types_configs();
		$text = '';
		$text .= '			<ol class="page_config">' . PHP_EOL;
		for($i = 1; $i < count($cms_apps_types); $i++ ) {
			if(empty($cms_apps_types[$i])) continue;	// consec-qutive (who said ?)
			$at = &$cms_apps_types[$i];
			$text .= '				<li class="page_config ' . (($i & 1) ? 'page_config_odd':'page_config_even') . '"><b>' . $at['title'] . '</b> (Type ' . $i . ')<br>' . PHP_EOL;
			$text .= '					' . $at['desc'] . PHP_EOL;
			if(!empty($at['cron'])) $text .= '					Cron available.' . PHP_EOL;
			if(!empty($at['api'])) $text .= '					API available.' . PHP_EOL;
			$text .= '				</li>' . PHP_EOL;
			} // for
		$text .= '			</ol>' . PHP_EOL;
		if($drop_box) {
			$blk_ary = array(	// use multi level params
				'text' => $text,	// usually 'text_inner'
				'outer_class' => '',
				'inner_class' => '',
				'outer_params' => 'style="width: 95%; display: block;"',	// fill column / available width
				'inner_params' => '',
				'table_class' => '',
				);
			return Ccms_drop_box::hover_block($heading, $blk_ary);
			} // if
		return (!empty($heading) ? '<b>' . $heading . '</b><br>':'') . $text;
		} // get_apps_types_descriptions()

// dynamic methods

} // Ccms_DB_checks
