<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_filesystems.php 2791 2022-09-08 12:54:48Z robert0609 $
 */

/**
 * Description of cms_filesystems
 * AppsCMS filesytems operations class.
 *
 * @author robert0609
 */

require_once 'cms_base.php';	// speed up for proxy and CLI (no autoloader needed)

class Ccms_filesystems extends Ccms_base {
	//put your code here

	function __construct() {
		parent::__construct();
		// self::send_downloads();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function _mount_read_only_filesystem($lib,$mntpnt) {	// similar to function cms_lib_sqsh.php
		if((!file_exists($lib)) ||
			(!is_readable($lib))) {	// no squashfs ??
			self::addDebugMsg($lib . "' file not found. Cannot mount read only filesystem.","error");
			return false;
			} // if
		if(self::findmnt($lib,'squash')) return true;	// already mounted fs
		@mkdir($mntpnt,0777);	// make sure the mount point is there
		@chmod($mntpnt,0777);	// and useable perms for web and cli
		$g = filegroup('./');
		@chgrp($mntpnt, $g);
		$output=null;
		$retval=null;
		$opts = " -o allow_other";
		exec('squashfuse ' .  $opts . ' ' . $lib . ' ' . $mntpnt, $output, $retval);	// mount simple fs
		if($retval) {	// mount fs
			self::addDebugMsg("Read only " . $lib . " mount failed.","error");
			return false;
			} // if
		return true;
	} // _mount_read_only_filesystem()

	protected static function _umount_read_only_filesystem($lib,$mntpnt) {
		$output=null;
		$retval=null;
		if(!self::findmnt($lib,'squash')) return true;	// not mounted fs
		if(Ccms_posix::is_windows()) {
			// @TODO write_ini_file
			return true;
			} // if
		$output=null;
		$retval=null;
		exec('fusermount -u ' . $lib, $output, $retval);	// umount simple fs
		if($retval) {	// umount fs
			self::addDebugMsg("Failed to umount " . $lib,"error");
			return false;
			} // if
		if(is_dir($mntpnt)) unlink($mntpnt);
		return true;
	} // _umount_read_only_filesystem()

	public static function apps_read_only_filesystems($op) {
		$ok = true;
		switch ($op) {
		case 'mount':
			if((!is_dir(APPS_FS_INCLUDE_DIR)) ||
				(!is_readable(APPS_FS_INCLUDE_DIR))) {	// apps code not there
				if(!self::_mount_read_only_filesystem('apps_fs_sqsh.sqsh',APPS_FS_DIR)) $ok = false;
				} // IF
			break;
		case 'unmount':	// ?
			// fall thru
		case 'umount':
			if(!self::_umount_read_only_filesystem('apps_fs_sqsh.sqsh',APPS_FS_DIR)) $ok = false;
			break;
		case 'remount':
			if(!self::apps_read_only_filesystems('umount')) $ok = false;
			if(!self::apps_read_only_filesystems('mount')) $ok = false;
			if(!$ok) {
				self::addDebugMsg("Failed to remount apps read only filesystems.");
				} // if
			break;
		default:
			$ok = false;
			self::addMsg("Unknown operation (" . $op . ") in " . __FUNCTION__ . "().");
			break;
			} // switch
		return $ok;
		} // apps_read_only_filesystems()

} // Ccms_filesystems
