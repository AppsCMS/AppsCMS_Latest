<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_config_funcs.php 3250 2023-03-02 02:13:34Z robert0609 $
 */

/**
 * Description
 * Ccms_configs functions for settings and DB configurations
 * 
 * Usually functions/methods used as an indirect call
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_vfs.php');

class Ccms_config_funcs extends Ccms_vfs {
	
	private static $validity_failed_mobiles = [];

	protected const MAX_INPUT_SIZE = 120;	// > goes to textarea
	protected const TEXT_LEN_MAX = 1000;	// max textarea text length

	public const PHONE_NUMBER_MIN_MAX_PARAM = 'minlength="6" maxlength="18"';
	public const MOBILE_REV_MATCH_MIN_LEN = 9;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// methods
	public function is_config_value_ok($cms_config_id,$cms_config_value) {
		$conf = self::$cDBcms->get_data_in_table('cms_configs',['cms_config_allowed_values','cms_config_input_func'],"cms_config_id = '" . (int)$cms_config_id . "'");
		if(!empty($conf['cms_config_input_func'])) return true;
		if(empty($conf['cms_config_allowed_values'])) return true;
		$allowed = explode(':',$conf['cms_config_allowed_values']);
		if(!is_array($allowed)) return true;
		if(!in_array($cms_config_value,$allowed)) return false;
		return true;
		} // is_config_value_ok()

	public function show_input_elem($cms_config_value,$cms_config_allowed_values,$cms_config_input_func,$cms_config_description = false) {
		$text = '';
		if((!empty($cms_config_input_func)) &&
			(method_exists($this,$cms_config_input_func))) {
			$method = $cms_config_input_func;
			$text .= $this->$method('cms_config_value',$cms_config_value,$cms_config_allowed_values);
			}
		else if(self::is_static_callable($cms_config_input_func)) {
			$method = $cms_config_input_func;
			$text .= @call_user_func($method,'cms_config_value',$cms_config_value,$cms_config_allowed_values);
			}
		else if((!empty($cms_config_allowed_values)) && (is_array(($allowed = explode(':',$cms_config_allowed_values))))) {
			$s_txt = ''; $tit = '';
			if(!in_array($cms_config_value,$allowed)) {	// V3.00 false -> disabled, true -> enabled
				$ed_chg = array( 'false' => 'disabled', 'true' => 'enabled');
				if(isset($ed_chg[$cms_config_value])) {
					$tmp = $ed_chg[$cms_config_value];
					$s_txt = ' (Value updated from ' . $cms_config_value . ' to ' . $tmp . '.)';
					$tit = ' title="' . $s_txt . '"';
					$cms_config_value = $tmp;
					} // if
				} // if
			$text .= '<select name="cms_config_value" size="1" ' . $tit . '>'; // title="' . strip_tags($cms_config_description) . '">';
			foreach($allowed as $v) {
				$text .= '<option value="' . htmlentities($v) . '"' . ($cms_config_value == $v ? ' SELECTED':'') . '>' . Ccms::make_nice_name(strip_tags($v)) . '</option>' . PHP_EOL;
				} // foreach
			$text .= '</select>';
			// $text .= $s_txt;
			}
		else {
			if(strlen($cms_config_value) > self::MAX_INPUT_SIZE) {	// use a textarea
				$text .= Ccms_html::get_textarea_input('cms_config_value',$cms_config_value);
				} // if
			else {	// standard text input 
				$text .= '<input type="text" ' .
					' name="cms_config_value" ' .
					' style="width: 98%;" ' .
					' value="' . htmlentities($cms_config_value) . '" ' .
					' autocapitalize="off"/>' . PHP_EOL;	// title="' . strip_tags($cms_config_description) . "/>';
				} // else
			} // else
		return $text;
		} // show_input_elem()

	public function show_input_comments($cms_config_comments,$cms_config_description = false) {
		$text = '';
		if(strlen($cms_config_comments) > self::MAX_INPUT_SIZE) {	// use a textarea
			$text .= Ccms_html::get_textarea_input('cms_config_comments',$cms_config_comments);
			} // if
		else {	// standard text input 
			$text .= '<input type="text" ' .
				' name="cms_config_comments" ' .
				' style="width: 98%;" ' .
				' value="' . htmlentities($cms_config_comments) . '" ' .
				' autocapitalize="off"/>' . PHP_EOL;	// title="' . strip_tags($cms_config_description) . "/>';
			} // else
		return $text;
		} // show_input_comments()

// special config functions
	public static function find_img_path(&$image,&$paths,$icon_flg = false) {
		// path can be a string or an array()
		// return the the path name of the $image
		// $image maybe include it's path
		$img_path = '';
		if(empty($paths)) {
			if($icon_flg) $paths = array(ETC_WS_ICONS_DIR,CMS_WS_ICONS_DIR,LOCAL_WS_TOOLS_ICONS_DIR);
			else $paths = array(ETC_WS_IMAGES_DIR,CMS_WS_IMAGES_DIR,LOCAL_WS_TOOLS_IMAGES_DIR);
			} // if
		else if (!is_array($paths)) {
			$pathes = array($paths);
			$paths = $pathes;
			} // else if
		$path = '';
		if((!empty($image)) && (is_dir(DOCROOT_FS_BASE_DIR . $image))) {
			$paths[] = $path = $image;
			$image = '';	// no image
			} // else if
		else if((!empty($image)) && (file_exists(DOCROOT_FS_BASE_DIR . $image))) {
			$paths[] = $path = dirname($image);
			$image = basename($image);
			$img_path = self::clean_path($path . '/' . $image);
			} // if
		$paths = array_unique($paths);	// remove dupes
		if((empty($image)) && (!empty($paths[0])) && (DOCROOT_FS_BASE_DIR . is_dir($paths[0]))) {
			// for uploaded images
			$img_path = $paths[0];
			return $img_path;
			} // else if
		if((!empty($image)) && (!is_dir($image))) {
			$img_file = basename($image);
			foreach($paths as $p) {
				if((is_dir(DOCROOT_FS_BASE_DIR . $p)) &&
					(file_exists(DOCROOT_FS_BASE_DIR . $p . '/' . $img_file))) {
					// standard presentation
					$img_path = self::clean_path($p . '/' . $img_file);
					return $img_path;
					} // if
				} // foreach
			} // if
		return $img_path;
		} // find_img_path()

	public function show_image($image,$path = '', $height_or_class = false,$alt = false) {
		$img_path = $this->find_img_path($image, $path);

		// whats happening
		if(empty($height_or_class)) { $height = (int)CMS_C_SMALL_IMAGE_HEIGHT; $class = false; }
		else if(is_numeric($height_or_class)) { $height = (int)$height_or_class; $class = false; }
		else if(is_string($height_or_class)) { $height = false; $class = $height_or_class; }
		else { $height = (int)$height_or_class; $class = false; }

		$text = '';
		if((!empty($image)) && (is_readable(DOCROOT_FS_BASE_DIR . $img_path))) {
			$text .= '<img alt="'. (!empty($alt) ? $alt:'check config image') . '"' . (!empty($class) ? ' class="' . $class . '"':'') .
				(!empty($height) ? ' height="' . $height . 'px"':'') .
				' src="' . $img_path . '">';
			} // if
		else $text .= '(No image)';
		return $text;
		} // show_image()

	public function input_image($name,$image,$paths = '',$title= '',$show_img = true) {
		$img_path = $this->find_img_path($image, $paths);
		$text = '';
		$id_select = 'id_' . $name;
		if(!is_array($paths)) $pathes = array($paths);
		else $pathes = $paths;
		$options = Ccms_options::make_image_select_options($pathes,$image);
		$text .= '<table>' . PHP_EOL;
		$text .= '<tr>' . PHP_EOL;
		$text .= '<td>' . Ccms_options::get_select_option_filter($id_select,'',-1) . '</td>' . PHP_EOL;
		$text .= '<td><select name="' . $name . '" id="' . $id_select . '" onclick="cms_filter_select_click(this);" size="1">';
		$text .= $options;
		$text .= '</select><td>' . PHP_EOL;
		$text .= '</tr>' . PHP_EOL;
		if(($show_img) && (!empty($image)) && (is_readable(DOCROOT_FS_BASE_DIR . $img_path))) {
			$text .= '<tr>' . PHP_EOL;
			$text .= '<td style="text-align: right;">Current:&nbsp;</td>' . PHP_EOL;
			$text .= '<td>' . PHP_EOL;
			$text .= '<img alt="check config image" class="page_config" src="' . htmlentities($img_path) . '">' . PHP_EOL;
			$text .= '&nbsp;<input type="checkbox" name="' . $name . '_delete"/> delete image' . PHP_EOL;
			$text .= '</td>' . PHP_EOL;
			$text .= '</tr>' . PHP_EOL;
			} // if
		$text .= '<tr><td>or URL to Download&nbsp;</td>' . PHP_EOL;
		$text .= '<td><input type="text" accept="image/*" class="page_config" name="' . $name . '_download" size="32" value="" title="' . (!empty($title) ? $title:'URL to download image or icon (optional). Stored in the ' . implode(',',$paths) . ' directory.') .'"/></td>';
		$text .= '</tr><tr>' . PHP_EOL;
		$text .= '<td>or File to Upload&nbsp;</td>' . PHP_EOL;
		$text .= '<td><input type="file" accept="image/*" class="page_config" name="' . $name . '_new" size="32" ' . (!empty($image) ? 'value="' . htmlentities($image) . '" ':'') . ' title="' . (!empty($title) ? $title:'Image or icon (optional). Stored in the ' . implode(',',$paths) . ' directory.') .'"/></td>';
		$text .= '</tr></table>' . PHP_EOL;
		return $text;
		} // input_image()

	public function get_image($name,$image,$path = '') {	// get image from request
		$img_path = $this->find_img_path($image, $path);
		if($img_download_url = Ccms_base::get_or_post($name . '_download')) {
			$img_filename = basename($img_download_url);
			$img_filepath = DOCROOT_FS_BASE_DIR . $img_path . $img_filename;
			if(file_put_contents($img_filepath, fopen($img_download_url, 'r')) !== false)
				return $img_path . $img_filename;
			} // if
		if($filename = self::save_uploaded_file($img_path,$name . '_new',false)) {
			return $filename;
			} // if
		else if(Ccms_base::get_or_post_checkbox('_delete')) {
			$image = '';
			} // if
		else if(Ccms_base::is_get_or_post($name)) {
			$image = Ccms_base::get_or_post($name);
			} // else if
		return $image;
		} // get_image()

	public function show_icon($image,$paths = false,$class = false) {
		if(empty($paths)) $paths = array(ETC_WS_ICONS_DIR);
		return $this->show_image($image, $paths, $class);
		} // show_icon()

	public function input_icon($name,$image,$title= '',$paths = false) {
		if(empty($paths)) $paths = array(ETC_WS_ICONS_DIR);
		return $this->input_image($name, $image, $paths,$title);
		} // input_icon()

	public function get_icon($name,$image,$paths = false) {
		if(empty($paths)) $path = array(ETC_WS_ICONS_DIR);
		return $this->get_image($name, $image, $paths);;
		} // get_icon()

	public function input_doc_file($name,$value) {
		if($v = Ccms_base::get_or_post($name)) $value = $v;
		return Ccms_options::get_docs_selection($name,$value);
		} // input_doc_file()

	public function input_ext_file($name,$value) {
		if($v = Ccms_base::get_or_post($name)) $value = $v;
		return Ccms_options::get_ext_code_dir_selection($name,$value);
		} // input_ext_file()

	public function input_ssl_file($name,$value) {
		if($v = Ccms_base::get_or_post($name)) $value = $v;
		return Ccms_options::get_ssl_dir_selection($name,$value);
		} // input_ssl_file()

	public function get_url($name,$url) {
		if($u = html_entity_decode(Ccms_base::get_or_post($name))) $url = $u;
		if(empty($url)) return '';

		$p = parse_url($url);
		if((!isset($p['scheme'])) || (empty($p['scheme']))) {
			if(!isset($p['host'])) {
				// try the front part
				$h = strtolower(preg_replace('/\/.*/', '', $p['path']));
				if(!empty($h)) {
					if((substr($h, 1, 3) == 'www') ||	// guess ???
						(dns_get_record($h,'A'))) {	// lookup
						$p['scheme'] = (CMS_S_ALWAYS_USE_SSL_BOOL ? 'https':'http'); // default
						$p['host'] = $h;
						$p['path'] = substr($p['path'],strlen($h));
						} // if
					} // if
				// else leave it
				} // if
			} // if

		$url = '';
		if((isset($p['host'])) && (!empty($p['host']))) {
			$url .= $p['scheme'] . '://';
			$url .= $p['host'];
			} // if
		if((isset($p['port'])) && ((int)$p['port'] > 0)) $url .= ':' . $p['port'];
		if((isset($p['path'])) && (!empty($p['path']))) $url .= $p['path'];
		if((isset($p['query'])) && (!empty($p['query']))) $url .= '?' . $p['query'];

		return $url;
		} // get_url()

	private function send_get($sock,$msg) {
		fwrite($sock, $msg."\r\n");
		$reply = fread($sock, 2082);
		return $reply;
		} // send_get()

	protected function validate_email($user,$domain,$fail_msg_lev = '') {
		$mxhosts = array();
		if((!getmxrr($domain,$mxhosts)) ||
			(count($mxhosts) < 1)) {
			self::log_msg('Failed to lookup MX host for "' . $domain . '".',$fail_msg_lev);
			return false;
			} // if
		$conn_timeout = 15; // seconds  @TODO add a setting for this (??)
		foreach($mxhosts as $smtp) {
			if(!$sock = @fsockopen($smtp, 25, $errno, $errstr, $conn_timeout)) {
				self::log_msg('Failed to open "' . $smtp . ':25", "' . $errstr . '" ',$fail_msg_lev);
				continue;
				} // if
			stream_set_timeout($sock, 5);
			$reply = fread($sock, 2082);
			$matches = array();
			preg_match('/^([0-9]{3}) /ims', $reply, $matches);
			$code = isset($matches[1]) ? $matches[1] : '';
			if($code != '220') {	// MTA gave an error...
				$this->send_get($sock,"QUIT");	// bye
				fclose($sock);
				$sock = false;
				continue;	// try next
				} // if
			if((!CMS_S_VALIDATE_EMAIL_ADDRESS_BOOL) ||	// not checking user
				(CMS_C_CONFIRM_EMAIL) ||	// don't double check
				(stripos($smtp,$domain) === false) ||	// this only works if there is not an interceding mailserver (e.g. MailGuard, etc.)
				((self::is_intranet(CMS_DOMAIN)) && (!self::is_intranet($smtp))) ||	// maybe not testable
				((!self::is_intranet(CMS_DOMAIN)) && (self::is_intranet($smtp)))) {	// maybe not testable
				$this->send_get($sock,"QUIT");	// bye
				fclose($sock);	// done
				$sock = false;
				return true;	// have a running MX (but users not checked)
				} // if
				
			$this->send_get($sock,"HELO ".CMS_DOMAIN);	// say helo
			$this->send_get($sock,"MAIL FROM: <".'no-reply' . '@' . CMS_DOMAIN . ">");	// tell of sender

			$reply = $this->send_get($sock,"RCPT TO: <".$user.'@'.$domain.">");	// ask of recepient
			$this->send_get($sock,"QUIT");	// bye
			fclose($sock);	// done
			$sock = false;
			preg_match('/^([0-9]{3}) /ims', $reply, $matches);	 // get code and msg from response
			$code = isset($matches[1]) ? $matches[1] : '';
			switch($code) {
			case '250':	// you received 250 so the email address was accepted
				return true;
			case '451':
			case '452':	 // you received 451 so the email address was greylisted (or some temporary error occured on the MTA) - so assume is ok
				return true;
			case '503':	// 503 5.5.2 Need mail command (or This mail server requires authentication)
			case '550':	// 550 Recipient address rejected: User unknown in local recipient table
			// fall thru to next
			default:
				break;
				} // switch
			} // foreach
		self::log_msg('Failed to validate "' . $user . '@' . $domain . '".',$fail_msg_lev);
		return false;
		} // validate_email()

	public function get_email($name,$email,$fail_msg_lev = '') {
		if(isset($_POST[$name])) $email = html_entity_decode($_POST[$name]);
		if(empty($email)) return '';

		$email_cln = preg_replace('/[^0-9a-z_\-@\.]/i', '', $email); // sanitize it
		if(!preg_match('/^.+@.+$/',$email_cln)) return false;	// not an email address
		$h = preg_replace('/.*@/', '', $email_cln);
		$u = preg_replace('/@.*/', '', $email_cln);
		if(empty($h)) {
			self::addMsg('Email address missing host.',$fail_msg_lev);
			return '';
			} // if
		if(empty($u)) {
			self::addMsg('Email address missing username.',$fail_msg_lev);
			return '';
			} // if
//		if(!dns_get_record($h,'MX')) {	// lookup
//			self::addMsg('Email host "' . $h . '" has no MX record.',$fail_msg_lev);	//,$fail_msg_lev);
//			return '';
//			} // if
		if(!$this->validate_email($u,$h,$fail_msg_lev)) {	// is it real one
			self::addMsg('Email host "' . $h . '" has no "' . $u . '" user.',$fail_msg_lev);	//,$fail_msg_lev);
			return '';
			} // if
		$email = $u . '@' . $h;
		return $email;
		} // get_email()

	public function get_phone_number($name,$phone = '',$fail_msg_lev = '',$sep = false) {
		if(isset($_POST[$name])) $phone = html_entity_decode($_POST[$name]);
		if(empty($phone)) return '';
		if(!Ccms::validate_phone_number($phone,$sep)) {
			self::addMsg('Phone number is invalid.',$fail_msg_lev);
			return '';
			} // if
		return $phone;
		} // get_phone_number()

	public function get_mobile_number($name,$mobile = '',$fail_msg_lev = '',$sep = false) {
		if(isset($_POST[$name])) $mobile = html_entity_decode($_POST[$name]);
		if(empty($mobile)) return '';
		if((!Ccms::validate_phone_number($mobile,$sep)) ||
			(!$this->chk_get_mobile_number($mobile))) {
			self::addMsg('Mobile number is invalid.',$fail_msg_lev);
			return '';
			} // if
		return $mobile;
		} // get_mobile_number()

	public function chk_get_mobile_number($mobile,$locale = false) {
		// assume number is already validated with Ccms::validate_phone_number()
		$cleaned = preg_replace('/[^0-9]+/','',$mobile);
		if(strlen($cleaned) < 9) return false;
		if(!$locale) $locale = str_replace('-','_',strtolower(self::get_user_locale()));
		$ok = false;
		switch($locale) {	// try localised numbers first assuming find mobile is registered in same locale as web browser.
		case 'en_au':
			if(preg_match('/^[0]?4[0-9]{8,8}$/',$cleaned)) $ok = true;
			break;
		case 'en_us':	// this is dodgy without the correct local setting;
			if(preg_match('/^[0]?[0-9]{10,10}$/',$cleaned)) $ok = true;
			break;
		case 'en_nz':
			if(preg_match('/^8[0-9]{6,8}$/',$cleaned)) $ok = true;
			break;
		case 'en_gb':
			if(preg_match('/^[0]?[0-9]{10,10}$/',$cleaned)) $ok = true;
			break;
		// @TODO add more locales
		default:
			self::addAdminMsg('Mobile number: ' . $mobile . ' unknown locale format "' . $locale . '", check browser locale.','warn');
			break;
			} // switch
			// check common international codes
		if(preg_match('/^(13[0-9]{4,4}|1300[0-9]{6}|1800[0-9][6]|190[0-9][7])$/',$cleaned)) $ok = false;	// 13 xx xx, 1300 xxx xxx ... , 1800 xxx xxx ..., 190x xxx xxx ...
		else if((preg_match('/^614[0-9]{8,8}$/',$cleaned)) ||	// 'en_au'
			(preg_match('/^1[0-9]{10,10}$/',$cleaned)) ||  // 'en_us'
			(preg_match('/^648[0-9]{6,8}$/',$cleaned)) ||	// 'en_nz'
			(preg_match('/^44[0-9]{10,10}$/',$cleaned)) ||	// 'en_gb'
			// @TODO add more
			(0)) $ok = true;
		if(!$ok) {
			self::addMsg('Mobile number: ' . $mobile . ' is not compatible.','warn');
			self::$validity_failed_mobiles[] = [ 'mobile' => $mobile, 'locale' => $locale, ];
			return false;				
			} // if
		return $cleaned;
		} // chk_get_mobile_number()
		
	public static function is_mobile_numbers_same($a ,$b, $min_digits_len = false) {	// probability
		// assume number is already validated with Ccms::validate_phone_number()
		if((empty($a)) || (empty($b))) return false;	// fail (not equal)
		$a_c = preg_replace('/[^0-9]+/','',$a);	// clean
		$a_r = strrev($a_c);	// reverse 
		$b_c = preg_replace('/[^0-9]+/','',$b);	// clean
		$b_r = strrev($b_c);	// reverse
		$l = min(strlen($a_c),strlen($b_c));
		if(!$min_digits_len) $min_digits_len = self::MOBILE_REV_MATCH_MIN_LEN;
		if($l < $min_digits_len) return false;
		if(substr($a_r,0,$min_digits_len) == (substr($b_r,0,$min_digits_len))) return true;	// considered equal
		return false;
		} // is_mobile_numbers_same()
		
	public static function &get_failed_mobile_validates() {
		return self::$validity_failed_mobiles;
		} // get_failed_mobile_validates()

	public function get_plugins($value,$filter = false) {
		$aldirs = Ccms_autoloader::get_ops_dirs_list();
		$paths = $aldirs['plugins'];
		$cms_plugins_enabled = explode(':',$value);
		$cms_plugins = array();
		foreach($paths as $path) {
			if(!is_dir(DOCROOT_FS_BASE_DIR . $path)) continue;
			if($dh = opendir(DOCROOT_FS_BASE_DIR . $path)) { // check plugin location
				while (($file = readdir($dh)) !== false) {
					if(preg_match('/\.php$/',$file)) {
						if(($filter) && (strpos($file,$filter) === false)) continue;
						$p = preg_replace('/.php$/', '', $file);
						$class = 'C' . $p . '_plugin';
						if(Ccms_autoloader::find_plugin($class)) {
							$cms_plugins[$p] = array(
								'class' => $class,
								'name' => $p,
								'title' => $class::get_title(),
								'enabled' => (in_array($p,$cms_plugins_enabled) ? true:false),
								'description' => $class::get_description(),
								);
							} // if
						} // if
					} // while
				closedir($dh);
				} // if
			} // foreach
		ksort($cms_plugins);
		return $cms_plugins;
		} // get_plugins()

//	public function input_apps_ext_plugin($name,$value) {
//		$cms_plugins = $this->get_plugins($value,'_apps_extend');
//		$text = '';
//		$text .= '<select name="' . $name . '">';
//		$text .= '	<option value="-1"> -- Select Plugin -- </option>';
//		// $text .= '	<option value="None"' . (('None' == $value) ? ' SELECTED':'') . '>None</option>';
//		foreach($cms_plugins as $n => &$v) {
//			$text .= '	<option value="' . $n . '"' . (($n == $value) ? ' SELECTED':'') . '>' . strip_tags(($v['title'] . ' - ' . substr($v['description'],0,48) . ' ...')) . '</option>';
//			} // foreach
//		$text .= '</select>' . PHP_EOL;
//		return $text;
//		} // input_apps_ext_plugin()

//	public function save_apps_ext_plugin($name,$value) {
//		$text = '';
//		if((isset($_POST[$name])) && (!empty($_POST[$name]))) {
//			// $cms_plugins = $this->get_plugins($value);
//			$text = $_POST[$name];
//			} // if
//		else if(!empty($value)) $text = $value;
//		// already a ':' separated string
//		Ccms::do_plugin_installs($text);
//		return $text;
//		} // save_apps_ext_plugin()

	public function show_plugins($value) {
		$cms_plugins = $this->get_plugins($value);
		$text = '';
		foreach($cms_plugins as $p) {
			if(!$p['enabled']) continue;
			if(!empty($text)) $text .= ', ';
			$text .= $p['title'];
			} // foreach
		$text = str_replace('.,', ',', $text);
		return $text;
		} // show_plugins()

	public function input_plugins($name,$value) {
		$cms_plugins = $this->get_plugins($value);
		$class = 'page_config';
		$text = '';
		$col_heads = 'Plugin:Enabled:Description';
		$col_heads = explode(':', $col_heads);
		$text .= '<table class="' . $class . '">' . PHP_EOL .
				'<tr class="' . $class . '">' .
					'<th class="' . $class . '">' . $col_heads[0] . '</th>' .
					'<th class="' . $class . '" style="text-align: center;">' . $col_heads[1] . '</th>' .
					'<th class="' . $class . '">' . $col_heads[2] . '</th>' .
				'</tr>' . PHP_EOL;
		$row = 0;
		foreach($cms_plugins as &$p) {
			$text .= '<tr class="' . (($row++ & 1) ? 'page_config_even':'page_config_odd') . '">';
			$text .= '<td class="' . $class . '" valign="top" title="Type: ' . $p['name'] . '">' . $p['title'] . '</td>';
			$text .= '<td class="' . $class . '" valign="top" style="text-align: center;" title="Check to enable."><input type="checkbox" name="' . $name . '[' . $p['name'] . ']"' . (($p['enabled']) ? ' CHECKED':'') . '/></td>';
			$text .= '<td class="' . $class . '" valign="top">' . $p['description'] . '</td>';
			$text .= '</tr>' . PHP_EOL;
			} // foreach
		$text .= '</table>' . PHP_EOL;
		return $text;
		} // input_plugins()

	public function save_plugins($name,$value) {
		$cms_plugins = $this->get_plugins($value);
		$text = '';
		$val_sep = ':';
		if((isset($_POST[$name])) && (!empty($_POST[$name])) && (is_array($_POST[$name]))) {
			$text_a = $_POST[$name];
			$text_p = array();
			foreach($text_a as $p => &$e) {
				if($e == 'on') {
					if(empty($avail)) $text_p[] = $p;
					else if(isset($avail[$p])) $text_p[] = $p;	// stop rubbish getting thru
					} // if
				} // foreach
			$text = implode($val_sep,$text_p);
			} // if
		else if(!empty($value)) {	// analyse the data
			if(is_array($value)) {
				$text = '';
				foreach($value as $k => $v) {
					if(strlen($text) > 0) $text .= $val_sep;
					if($v == 'on') $text .= $k;	// checkbox return
					else $text .= $v;	// a list return
					} // foreach
				} // if
			else $text = $value;
			} // else if
		Ccms::do_plugin_installs($text);
		return $text;
		} // save_plugins()

//	public function get_page_layout($value,$filter = false) {
//		$col_master = array(
//			'config' => Ccms_options::get_admin_config_items(),
//			'tools' => Ccms_options::get_tools_menu_items(),
//			'menu' => Ccms_options::get_bodies_menu_items(),
//			);
//		$col_layouts = self::unserialize_string2arry($value,':',',');
//		return $col_layouts;
//		} // get_page_layout()

	public function show_page_layout($value,$col_heads) {
//		$col_layouts = $this->get_page_layout($value);
		return $this->show_grid($value, $col_heads);
		} // show_page_layout()

	public function input_page_layout($name,$value,$col_heads) {
//		$col_layouts = $this->get_page_layout($value);
		return $this->input_grid($name,$value, $col_heads);
		} // input_page_layout()

	public function save_page_layout($name,$value,$col_heads) {
//		$col_layouts = $this->get_page_layout($value);
		return $this->save_grid($name,$value, $col_heads);
		} // save_page_layout()

	public function show_grid($value,$col_heads) {
		return Ccms_options::grid_show($value, $col_heads,':',false);
		} // show_grid()

	public function input_grid($name,$value,$col_heads) {
		return Ccms_options::grid_input_form_elems($name,$value,$col_heads,':',false);
		} // input_grid()

	public function save_grid($name,$value,$col_heads) {
		if(empty($value)) $value = Ccms_base::get_or_post ($name);
		return Ccms_options::grid_get_form_elems($name,$value,$col_heads,':',false);
		} // save_grid()

	public function show_map_address($value,$col_heads) {
		return Ccms_map_location_plugin::show_map_location_address($value, $col_heads);
		} // show_map_address()

	public function input_map_address($name,$value,$col_heads) {
		return Ccms_map_location_plugin::input_map_location_address($name,$value,$col_heads);
		} // input_map_address()

	public function save_map_address($name,$value,$col_heads) {
		if(empty($value)) $value = Ccms_base::get_or_post ($name);
		return Ccms_map_location_plugin::save_map_location_address($name,$value,$col_heads);
		} // save_map_address()

	public function select_time_of_day($name,$value,$cms_config_allowed_values) {
		if(!preg_match('/^[0-9]+:[0-9]+:[0-9]+$/',$cms_config_allowed_values)) {	// use a default
			$start = 0;
			$inc = 1800;
			$finish = (24 * 3600);			
			} // if
		else {
			list($start,$inc,$finish) = @explode(':',$cms_config_allowed_values);
			} // else
		$time = $start;
		$text = array();
		$text[] = '	<select name="' . $name . '">' . PHP_EOL;
		$text[] = '		<option value="-1" selected hidden>' . '- Time of Day -' . '</option>' . PHP_EOL;
		$text[] = '		<option value="-2"' . (($value == -2) ? ' SELECTED':'') . '>' . 'Not Avalable' . '</option>' . PHP_EOL;
		while($time <= $finish) {
			$h_m = sprintf('%02d:%02d',(int)($time / 3600),((int)($time / 60) % 60));
			if($time == $value) {
				$selected = ' SELECTED';
				$h_m_txt = '&nbsp; ' . $h_m . ' ** &nbsp;';
				} // if
			else {
				$selected = '';
				$h_m_txt = '&nbsp; ' . $h_m. ' &nbsp;';
				} // else
			$text[] = '		<option value="' . $time . '" ' . $selected . '>' . $h_m_txt . '</option>' . PHP_EOL;
			$time += $inc;
			} // while
		$text[] = '	</select>' . PHP_EOL;
		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // select_time_of_day()

	public function show_number($value) {
		return $value;
		} // show_number()

	public function input_number($name,$value,$allowed) {
		$text = '';
		$allow = explode(':',$allowed);
		if(preg_match('/(min|step|max)="?[0-9]+"?/i',$allowed)) {
			$allow = preg_replace('/[:"]/',' ',$allowed);
			$allow = preg_replace('/=([0-9]+)/','="${1}"',$allow);
			$text .= '<input type="number" name="' . $name . '" value="' . $value . '" ' . $allow . '/>' . PHP_EOL;
			} // if
		else if(is_array($allow)) {
			$text .= '<select name="' . $name . '">';
			foreach($allow as $v) {
				$text .= '<option value="' . $v . '"' . (($value == $v) ? ' SELECTED':'') . '>' . $v . '</option>';
				} // foreach
			$text .= '</select>' . PHP_EOL;
			} // else if
		else {	// assume no allowed
			$text .= '<input type="number" name="' . $name . '" value="' . $value . '"/>' . PHP_EOL;
			} // else
		return $text;
		} // input_number()

	public function save_number($name,$value) {
		if(empty($value)) $value = Ccms_base::get_or_post ($name);
		return $value;
		} // save_number()

	public function get_sanitized_text($name,$value = '',$htmlenties = false) {	// cleans the text, mainly for use in meta values
		$text = '';
		if(isset($_POST[$name])) {
			$text = html_entity_decode($_POST[$name]);
			} // if
		else if(!empty($value)) $text = $value;
		if(empty($text)) return '';
		$text = Ccms::sanitiseText4Html($text);
//		$search_strs = array(
//			'/<|>/',
//			'/\n|\d/',
//			);
//		$text = preg_replace($search_strs, ' ', $text);
		if($htmlenties) $text = htmlentities($text, ENT_QUOTES, CMS_S_CHAR_SET, false);
		return $text;
		} // get_sanitized_text()

	public function input_wysiwyg($name,$value = '') {	// make a select drop boxes for available WYSIWYGs
		return Ccms_wysiwyg::input_wysiwyg_selector($name,$value);
		} // input_wysiwyg()

	public function show_sm_order($value) {
		$text = array();
		$text[] = '<table class="page_config">';
		if(!empty($value)) {
			$spls = Ccms_socialmedia_plugin::get_list_SM_subplugins();
			$sort_order = explode(':',$value);
			$text[] = '	<tr class="page_config">';
			$text[] = '		<th class="page_config">' . 'Order' . '</th>';
			$text[] = '		<th class="page_config">' . 'Name' . '</th>';
			$text[] = '	</tr>';
			for($r = 0; $r < count($sort_order); $r++) {
				$text[] = '	<tr class="' . (($r & 1) ? 'page_config_odd':'page_config_even') . '">';
				$text[] = '		<td class="page_config" valign="top">' . ($r + 1) . '</td>';
				$text[] = '		<td class="page_config" valign="top">' . $spls[($sort_order[$r])]['title'] . '</td>';
				$text[] = '	</tr>';
				} // for
			} // if
		else $text[] = '<tr class="page_config"><td class="page_config">(No order set)</td></tr>';
		$text[] = '</table>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // show_sm_order()

	public function input_sm_order($name,$value) {
		$spls = Ccms_socialmedia_plugin::get_list_SM_subplugins();
		if(!empty($value)) $sort_order = explode(':',$value);
		else $sort_order = array();
		foreach($spls as $p => $sp) {	// add missing sub plugins
			if(in_array($p,$sort_order)) continue;
			$sort_order[] = $p;
			} // foreach

		$text = array();
		$text[] = '';
		$text[] = '<script type="text/javascript">';
		$text[] = '	function swap_' . $name . '(name,s_r,d_r) {';
		$text[] = '		var s_id, s_obj, s_val;';
		$text[] = '		var d_id, d_obj, d_val;';
		$text[] = '';
		$text[] = '		// swap the text';
		$text[] = '		s_id = name + "_" + s_r;';
		$text[] = '		d_id = name + "_" + d_r;';
		$text[] = '		s_obj = document.getElementById(s_id);	// span';
		$text[] = '		d_obj = document.getElementById(d_id);	// span';
		$text[] = '		s_val = s_obj.innerHTML;';
		$text[] = '		d_val = d_obj.innerHTML;';
		$text[] = '		d_obj.innerHTML = s_val;';
		$text[] = '		s_obj.innerHTML = d_val;';
		$text[] = '';
		$text[] = '		// swap the hidden input';
		$text[] = '		s_id = name + "[" + s_r + "]";';
		$text[] = '		d_id = name + "[" + d_r + "]";';
		$text[] = '		s_obj = document.getElementsByName(s_id)[0];	// hidden input';
		$text[] = '		d_obj = document.getElementsByName(d_id)[0];	// hidden input';
		$text[] = '		s_val = s_obj.value;';
		$text[] = '		d_val = d_obj.value;';
		$text[] = '		d_obj.value = s_val;';
		$text[] = '		s_obj.value = d_val;';
		$text[] = '';
		$text[] = '		} // swap_' . $name . '()';
		$text[] = '';
		$text[] = '	function move_up_' . $name . '(name,s_r,rows) {';
		$text[] = '		if(s_r > (0 + 0)) {';
		$text[] = '			swap_' . $name . '(name,s_r,(s_r - 1));';
		$text[] = '			} // if';
		$text[] = '		} // move_up_' . $name . '()';
		$text[] = '';
		$text[] = '	function move_down_' . $name . '(name,s_r,rows) {';
		$text[] = '		if(s_r < (rows - 1)) {';
		$text[] = '			swap_' . $name . '(name,s_r,(s_r + 1));';
		$text[] = '			} // if';
		$text[] = '		} // move_down_' . $name . '()';
		$text[] = '</script>';
		$text[] = '';

		$text[] = '<table class="page_config">';
		$text[] = '	<tr class="page_config">';
		$text[] = '		<th class="page_config">' . 'Order' . '</th>';
		$text[] = '		<th class="page_config">' . 'Name' . '</th>';
		$text[] = '		<td class="page_config">' . '&nbsp;' . '</td>';
		$text[] = '		<td class="page_config">' . '&nbsp;' . '</td>';
		$text[] = '	</tr>';

		$r_c = count($sort_order); $idx = 0;
		for($r = 0; $r < count($sort_order); $r++) {
			if(!isset($spls[($sort_order[$r])])) { $r_c--; continue; }	// old sub plugin
			$text[] = '	<tr class="page_config">';
			$text[] = '		<td class="page_config">' . ($idx + 1) . '</td>';
			$text[] = '		<td class="page_config">';
			$text[] = '			<input type="hidden" name="' . $name . '[' . $idx . ']" value="' . $sort_order[$r] . '"/>';
			$text[] = '			<span id="' . $name . '_' . $idx . '">';
			$text[] = '				' . $spls[($sort_order[$r])]['title'];
			$text[] = '			</span>';
			$text[] = '		</td>';
			$text[] = '		<td class="page_config">';
			if($r >= 1) {
				$text[] = '			<a onclick="move_up_' . $name . '(\'' . $name . '\',' . $idx . ',' . $r_c . ');" title="Move row up to ' . ($idx - 1 + 1) . '">';
				$text[] = '				<img alt="up arrow" src="' . CMS_WS_IMAGES_DIR . 'arrow-up.gif" width="25" height="25"/>';
				$text[] = '			</a>';
				} // if
			$text[] = '		</td>';
			$text[] = '		<td class="page_config">';
			if(($idx >= 0) && ($idx < ($r_c - 1))) {
				$text[] = '			<a onclick="move_down_' . $name . '(\'' . $name . '\',' . $idx . ',' . $r_c . ');" title="Move row down to ' . ($idx + 1 + 1) . '">';
				$text[] = '				<img alt="down arrow" src="' . CMS_WS_IMAGES_DIR . 'arrow-down.gif" width="25" height="25"/>';
				$text[] = '			</a>';
				} // if
			$text[] = '		</td>';
			$text[] = '	</tr>';
			$idx++;
			} // for
		$text[] = '</table>';
		return implode(PHP_EOL,$text) . PHP_EOL;
		} // input_sm_order()

	public function save_sm_order($name,$value) {
		$text = '';
		if((isset($_POST[$name])) && (!empty($_POST[$name])) && (is_array($_POST[$name]))) {
			$text = implode(':',$_POST[$name]);
			} // if
		else if(!empty($value)) $text = $value;
		return $text;
		} // save_sm_order()

	private function get_cron_select_multi($sub_pre,$sub_inc,$sub_value,$max_numb,$strt_num = 0,$max_rows = 0,$sorc_ary = false) {
		if((!empty($sub_value)) && ($sub_value != '*') && (!is_array($sub_value)))
			$sub_value = explode(',',$sub_value);
		if(!$max_rows) $max_rows = $max_numb - $strt_num;
		$sub_name = $sub_pre . '[' . $sub_inc . '][]';
		$all_id = $sub_pre . '[' . $sub_inc . '_all]';
		if(($sorc_ary) && (is_array($sorc_ary))) {	// single drop
			$text = '';
			$text .= '<table class="' . $sub_pre . '_cron_box"><tr><td>';
			$text .= '<select  onclick="cron_elem_turn_off_all(this,\'' . $all_id . '\');"id="' . $sub_name . '" name="' . $sub_name . '" size="' . (count($sorc_ary) + 0) . '" method="GET" multiple>';
			foreach($sorc_ary as $k => $v) {
				$selected = '';
				if((!empty($sub_value)) && ($sub_value != '*') && (in_array($k,$sub_value))) $selected = ' SELECTED';
				$text .= '<option value="' . $k . '"' . $selected . '>' . $v . '</option>';
				} // foreach
			$text .= '</select>';
			$text .= '</td></tr></table>';
			$text .= PHP_EOL;
			} // if
		else {	// multi drop
			$text = '<table class="' . $sub_pre . '_cron_box"><tr><td>';
			$text .= '<select class="no_scroll" onclick="cron_elem_turn_off_all(this,\'' . $all_id . '\');" id="' . $sub_name . '" name="' . $sub_name . '" size="' . ($max_rows + 1) . '" method="GET" multiple>';
			$cntr = $strt_num;
			$row_cntr = -1; // for *
			while($cntr < $max_numb) {
				$selected = '';
				if((!empty($sub_value)) && ($sub_value != '*') && (in_array($cntr,$sub_value))) $selected = ' SELECTED';
				$text .= '<option value="' . $cntr . '"' . $selected . '>' . $cntr . '</option>';
				$cntr++;
				$row_cntr++;
				if(($row_cntr >= $max_rows) && ($cntr < $max_numb)) {
					$row_cntr = -1;
					$text .= '</select>';
					$text .= '</td><td>';
					$text .= '<select onclick="cron_elem_turn_off_all(this,\'' . $all_id . '\');" id="' . $sub_name . '[' . $cntr . ']" name="' . $sub_name . '" size="' . ($max_rows + 1) . '" method="GET" multiple>';
					}
				} // while
			$text .= '</select>';
			$text .= '</td></tr></table>' . PHP_EOL;
			} // else
		return $text;
		} // get_cron_select()

	public function inp_cron_times($name,$value) {
		if(empty($value)) {
			$value = '15 * * * *';	// set a default
			} // if
		list($minutes,$hours,$days,$months,$weekdays) = explode(' ',$value);	// get crontab parts

		if((empty($minutes)) || ($minutes == '*')) {
			$minutes_chk = ' CHECKED';
			$minutes_sel = $this->get_cron_select_multi($name,'minutes', '*', 60, 0, 11, false);
			} // if
		else {
			$minutes_chk = '';
			$minutes_sel = $this->get_cron_select_multi($name,'minutes', $minutes, 60, 0, 11, false);
			}

		if((empty($hours)) || ($hours == '*')) {
			$hours_chk = ' CHECKED';
			$hours_sel = $this->get_cron_select_multi($name,'hours', '*', 24, 0, 11, false);
			} // if
		else {
			$hours_chk = '';
			$hours_sel = $this->get_cron_select_multi($name,'hours', $hours, 24, 0, 11, false);
			}

		if((empty($days)) || ($days == '*')) {
			$days_chk = ' CHECKED';
			$days_sel = $this->get_cron_select_multi($name,'days', '*', 32, 1, 11, false);
			} // if
		else {
			$days_chk = '';
			$days_sel = $this->get_cron_select_multi($name,'days', $days, 32, 1, 11, false);
			}

		if((empty($months)) || ($months == '*')) {
			$months_chk = ' CHECKED';
			$months_sel = $this->get_cron_select_multi($name,'months', '*', 0,0,0,
				array(	1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
						7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'));
			} // if
		else {
			$months_chk = '';
			$months_sel = $this->get_cron_select_multi($name,'months', $months, 0,0,0,
				array(	1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
						7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'));
			}

		if((empty($weekdays)) || ($weekdays == '*')) {
			$weekdays_chk = ' CHECKED';
			$weekdays_sel = $this->get_cron_select_multi($name,'weekdays', '', 0,0,0,
				array(0 => 'Sunday', 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday'));
			} // if
		else {
			$weekdays_chk = '';
			$weekdays_sel = $this->get_cron_select_multi($name,'weekdays', $weekdays, 0,0,0,
				array(0 => 'Sunday', 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday'));
			}

		$text = '';
		$text .= <<< EOTCR

		<style>
			.no_scroll {
				overflow: -moz-scrollbars-none;
				}
			#{$name}_cron_elem {
				width: unset;
				}
			#{$name}_cron_elem table {
				border-radius: 5px;
				border: 2px solid grey;
				padding: 3px;
				margin : auto;
				}
			#{$name}_cron_elem td {
				margin : auto;
				vertical-align: top;
				}
			#{$name}_cron_elem select {
				border: 0;
				padding: 0px;
				margin: 0px;
				vertical-align: top;
				}
			table.{$name}_cron_box {
				width: unset;
				float: left;
				}
		</style>

		<script type="text/javascript">
			function cron_elem_turn_off_all(obj,id) {
				var e_all = document.getElementById(id);
				if(e_all) {
					e_all.checked = false;
					//e_all.value = 'off';
					} // if
				} // cron_elem_turn_off_all()

			function cron_elem_turn_off_sel(obj,name,type) {
				if(!obj.checked) return;
				var id_c = name + '[' + type + '][]';
				var chk = document.getElementById(id_c);
				if(chk) {
					if(chk[0].tagName == 'OPTION') {	// single bank / normal select
						for(var i = 0; i < chk.length; i++) {
							chk.options[i].selected = false;
							} // for
						} // if
					var form = obj.form;
					var sels = form.elements[id_c];	// multi bank selects
					if(sels[0].tagName == 'SELECT') {
						for(var i = 0; i < sels.length; i++) {
							if(!sels[i].options) continue;
							var sel = sels[i];
							for(var j = 0; j < sel.length; j++) {
								sel.options[j].selected = false;
								} // for
							} // for
						} // if
					} // if
				} // cron_elem_turn_off_sel()
		</script>

		<table id="{$name}_cron_elem">
			<tr>
				<td colspan="5">
					<b>NOTES on CRONTAB TIMES:</b> Checking &quot;All:&quot; over rides selection/s in each group.
					<br>
					To make individual selections, uncheck &quot;All:&quot;, hold down the control key and click on the required selection/s.
				</td>
			</tr>
			<tr>
				<th>
					Minutes
				</th>
				<th>
					Hours
				</th>
				<th>
					Days
				</th>
				<th>
					Months
				</th>
				<th>
					Weekdays
				</th>
			</tr>
			<tr>
				<td style="vertical-align: top;">
					<label>All:<input type="checkbox" id="{$name}[minutes_all]" onclick="cron_elem_turn_off_sel(this,'{$name}','minutes');" name="{$name}[minutes_all]"{$minutes_chk}></label>
				</td>
				<td style="vertical-align: top;">
					<label>All:<input type="checkbox" id="{$name}[hours_all]" onclick="cron_elem_turn_off_sel(this,'{$name}','hours');" name="{$name}[hours_all]"{$hours_chk}></label>
				</td>
				<td style="vertical-align: top;">
					<label>All:<input type="checkbox" id="{$name}[days_all]" onclick="cron_elem_turn_off_sel(this,'{$name}','days');" name="{$name}[days_all]"{$days_chk}></label>
				</td>
				<td style="vertical-align: top;">
					<label>All:<input type="checkbox" id="{$name}[months_all]" onclick="cron_elem_turn_off_sel(this,'{$name}','months');" name="{$name}[months_all]"{$months_chk}></label>
				</td>
				<td style="vertical-align: top;">
					<label>All:<input type="checkbox" id="{$name}[weekdays_all]" onclick="cron_elem_turn_off_sel(this,'{$name}','weekdays');" name="{$name}[weekdays_all]"{$weekdays_chk}></label>
				</td>
			</tr>
			<tr>
				<td class="cron_elem" style="width: auto; padding: 0px 10px 0px 0px;">
					{$minutes_sel}
				</td>
				<td class="cron_elem" style="width: auto; padding: 0px 10px 0px 0px;">
					{$hours_sel}
				</td>
				<td class="cron_elem" style="width: auto; padding: 0px 10px 0px 0px;">
					{$days_sel}
				</td>
				<td class="cron_elem" style="width: auto; padding: 0px 10px 0px 0px;">
					{$months_sel}
				</td>
				<td class="cron_elem" style="width: auto; padding: 0px 10px 0px 0px;">
					{$weekdays_sel}
				</td>
			</tr>
		</table>

EOTCR;

		return $text;
		} // inp_cron_times()

	private function make_cron_sect($value,$name) {
		$all = $name . '_all';
		if((isset($value[$all])) && ($value[$all] == 'on')) return '* ';
		if(!isset($value[$name])) return '* ';
		return  implode(',',$value[$name]) . ' ';
		} // make_cron_sect()

	public function get_cron_times($name,$value) {
		if($v = Ccms_base::get_or_post($name)) $value = $v;
		// make the crontab time string in correct order (minutes hours days months weekdays)
		$crontab = '';
		$crontab .= $this->make_cron_sect($value, 'minutes');
		$crontab .= $this->make_cron_sect($value, 'hours');
		$crontab .= $this->make_cron_sect($value, 'days');
		$crontab .= $this->make_cron_sect($value, 'months');
		$crontab .= $this->make_cron_sect($value, 'weekdays');

		return trim($crontab);
		} // get_cron_times()

	public function input_string($name,$value,$allowed) {
		$text = '';
		$text .= '<input type="text" name="' . $name . '" value="' . $value . '" ' . $allowed . '/>' . PHP_EOL;
		return $text;
		} // input_string()

} // Ccms_config_funcs
