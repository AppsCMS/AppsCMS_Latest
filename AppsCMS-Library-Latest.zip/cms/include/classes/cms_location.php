<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_location.php 3127 2023-02-12 10:37:55Z robert0609 $
 */

/**
 * Description of Ccms_location
 *
 * Description of Geo browser navigation and location class
 * Geo location class for client navigation
 *
 * @author robert0609
 */

class Ccms_location extends Ccms_base {

	public static $geo_location_latitude = false;	// decimal degrees
	public static $geo_location_longitude = false;	// decimal degrees
	public static $geo_location_accuracy = false;	// metres
	public static $geo_location_loc_time = false;	// seconds since epoch

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	public static function chk_geo_location() {
		$latitude = self::get_or_post('geo_latitude');
		$longitude = self::get_or_post('geo_longitude');
		$accuracy = self::get_or_post('geo_accuracy');
		$loc_time = time();
		if((!empty($latitude)) && (!empty($longitude))) {	// save from form
			self::set_cms_sess_var($latitude,'geo_location','latitude');
			self::set_cms_sess_var($longitude,'geo_location','longitude');
			self::set_cms_sess_var($accuracy,'geo_location','accuracy');
			self::set_cms_sess_var($loc_time,'geo_location','loc_time');
			} // if
		else if((self::get_cms_sess_var('geo_location','latitude')) &&
			(self::get_cms_sess_var('geo_location','longitude')) &&
			(self::get_cms_sess_var('geo_location','loc_time')) &&
			(self::get_cms_sess_var('geo_location','accuracy'))) {
			$latitude = self::get_cms_sess_var('geo_location','latitude');
			$longitude = self::get_cms_sess_var('geo_location','longitude');
			$accuracy = self::get_cms_sess_var('geo_location','accuracy');
			$loc_time = self::get_cms_sess_var('geo_location','loc_time');
			} // else if
		else return false;
		self::$geo_location_latitude = $latitude;
		self::$geo_location_longitude = $longitude;
		self::$geo_location_accuracy = $accuracy;
		self::$geo_location_loc_time = $loc_time;
		return true;	// got it
		} // chk_geo_location()

	public static function get_client_browser_geolocation_text() {
		$text = '';
		if((self::is_cms_user()) &&
			(CMS_C_GEOLOCATE_ALLOW) &&
			(self::$geo_location_latitude) &&
			(self::$geo_location_longitude)) {
			$timeout = (int)CMS_C_GEOLOCATE_TTL + (int)self::$geo_location_loc_time;
			if($timeout > time()) {
				$text .= '<br>' . PHP_EOL;
				$text .= '<p id="id_geolation_message_stat" style="text-align: center; font-size:xx-small; font-weight: lighter; font-style: italic;">';
				$text .= 'Latitude: ' . self::$geo_location_latitude . '&deg;, Longitude: ' . self::$geo_location_longitude . '&deg;' . (self::$geo_location_accuracy ? ', &plusmn;' . self::$geo_location_accuracy . 'm':'') . ' on ' . date('d/m/Y H:i:s',self::$geo_location_loc_time) . '</p>';
				$text .= '</p>' . PHP_EOL;
				} // if
			} // if
		return $text;
		} // get_client_browser_geolocation_text()

	public static function add_JS_browser_geolocation_form_text($prn_flg = true,$refresh = false) {
		if(!CMS_C_GEOLOCATE_ALLOW) return '';	// empty string
		if(!self::is_ssl_inuse()) return '';	// empty string
		if((!$refresh) &&
			(((int)self::$geo_location_loc_time + (int)CMS_C_GEOLOCATE_TTL) < time())) return '';
		$text = array();
		if(self::is_debug())
			$text[] = '		<p id="id_geolation_message" style="text-align: center; font-size:x-small; font-weight: lighter; font-style: italic;"></p>';
		$text[] = '		<input type="hidden" id="id_geo_latitude" name="geo_latitude" value=""/>';
		$text[] = '		<input type="hidden" id="id_geo_longitude" name="geo_longitude" value=""/>';
		$text[] = '		<input type="hidden" id="id_geo_accuracy" name="geo_accuracy" value=""/>';
		$text[] = '		<script type="text/javascript">';
		if(self::is_debug())
			$text[] = '			var el_geo_msg = document.getElementById("id_geolation_message");';
		$text[] = '			var el_geo_latitude = document.getElementById("id_geo_latitude");';
		$text[] = '			var el_geo_longitude = document.getElementById("id_geo_longitude");';
		$text[] = '			var el_geo_accuracy = document.getElementById("id_geo_accuracy");';
		$text[] = '';
		$text[] = '			function get_geo_location() {';
		$text[] = '				if (navigator.geolocation) {';
		$text[] = '					navigator.geolocation.getCurrentPosition(save_geo_location,error_geo_location);';
		$text[] = '					} //if';
		if(self::is_debug()) {
			$text[] = '				else { ';
			$text[] = '					el_geo_msg.innerHTML = "Geolocation is not supported by this browser.";';
			$text[] = '					} // else';
		} // if
		$text[] = '				} // get_geo_location()';
		$text[] = '';
		$text[] = '			function save_geo_location(position) {';
		$text[] = '				el_geo_latitude.value = position.coords.latitude;';
		$text[] = '				el_geo_longitude.value = position.coords.longitude;';
		$text[] = '				el_geo_accuracy.value = position.coords.accuracy;';
		if(self::is_debug())
			$text[] = '				el_geo_msg.innerHTML = "Latitude: " + position.coords.latitude + "&deg;&nbsp;Longitude: " + position.coords.longitude + "&deg;&nbsp;Accuracy: 	&plusmn;" + position.coords.accuracy + "m"';
		$text[] = '				} // save_geo_location()';
		$text[] = '';
		$text[] = '			function error_geo_location(position) {';
		if(self::is_debug())
			$text[] = '				el_geo_msg.innerHTML = position.message;';
		$text[] = '				} // save_geo_location()';
		$text[] = '';
 		$text[] = '			window.addEventListener("DOMContentLoaded",get_geo_location);';
		$text[] = '		</script>';

		$tmp = implode(PHP_EOL,$text) . PHP_EOL;
		if($prn_flg) echo $tmp;
		return $tmp;
		} // add_JS_browser_geolocation_form_text()

} // Ccms_location

