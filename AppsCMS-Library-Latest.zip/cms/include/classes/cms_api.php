<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_api.php 2985 2022-11-14 03:22:23Z robert0609 $
 */

/**
 * Description of Ccms_api
 *
 * API controller class
 *
 * @author robert0609
 */

require_once 'cms_api_funcs.php';	// speed up  (no autoloader needed)

class Ccms_api extends Ccms_api_funcs {

	function __construct() {
		if(!self::is_api()) return;
		if((!defined('API_CALL')) || (!API_CALL)) exit(11000);	// request mixed up
		self::$cms_page_start_time = self::get_us_timestamp();
		set_error_handler('Ccms_base::global_error_handler');
		self::$cDBcms = new Ccms_DB_config(); // also reads in configuration definitions

		// check for and engage virtual folders
		self::chk_engage_vfs();

		// complete the defines from the ini file
		self::get_cms_settings();
		if ((CMS_S_ALLOW_HTTP_COMPRESSION_BOOL) &&
			// (!in_array('eAccelerator', $this->php_mods)) &&
			(!Ccms::is_get_or_post('ajax'))) {
			self::set_chk_php_value("zlib.output_compression", 'On');
			} //if
		else {
			self::set_chk_php_value("zlib.output_compression", 'Off');
			} // else

		if (!defined('CMS_S_TIMEZONE_TZ'))
			date_default_timezone_set(CMS_DEFAULT_TIMEZONE); // set a default
		else
			date_default_timezone_set(CMS_S_TIMEZONE_TZ);

		// until this point the any DB logging is disabled (so don't log init() ops.)
		if(defined('CMS_C_LOGS_DB_OPS')) {
			switch(CMS_C_LOGS_DB_OPS) {
			case 'all':
				Ccms_database_common::$m_bSaveDBtransactions = true;
				break;
			case 'debug':
				if(self::is_debug()) Ccms_database_common::$m_bSaveDBtransactions = true;
				break;
			case 'none':
			default:
				break;
				} // switch
			} // if

		Ccms_apps::get_apps_settings();

		parent::__construct();

		self::$api_request_headers = getallheaders();
		$api_map = Ccms_api_map::get_api_resource_map();	// by reference
		self::log_api_request();

		if(Ccms_api_jwt::is_use_jwt_ok()) {
			$jwt = Ccms_api_jwt::get_jwt_token();
			if(!empty($jwt)) {
				$cJWT = new Ccms_api_jwt();
				self::$jwt_payload = $cJWT->check_jwt($jwt);
				} // if
			} // if
		else if(Ccms_api_sid::is_use_sid_ok ()) {
			$sid = session_id();
			Ccms_sessions::init();

			// set user local
			$locale = self::get_user_locale();
			setlocale(LC_ALL,$locale);
			} // else if
		else {
			$this->send_api_response(array(
				'status' => 'error',
				'message' => 'No API type enabled.',
				));
			} // else

		// do response headers
		self::$api_response_headers = array(
			'Cache-Control' => 'no-cache',
			'Pragma' => 'no-cache',
			);
		if(!$this->get_api_request()) {
			$this->send_api_response();
			return;
			} // if

		$this->log_http_access(CMS_C_API_AUTH);

		// $api_map = Ccms_api_map::get_api_resource_map();	// by reference
		if(empty($api_map)) {
			self::addMsg('API command map empty.');
			$this->add_http_code(500,'API map not found.');
			$this->send_api_response(array(
				'status' => 'error',
				'message' => 'API map not found.',
				));
			return false;
			} // if
		else if((self::is_ssl_inuse()) || (!CMS_C_API_SSL)) {
			$this->decode_api_cmd($this->api_request,$api_map,$this->api_response);	// recursive
			$this->send_api_response();
			} // if
		else {
			$this->add_http_code(403,'API SSL required.');
			$this->send_api_response(array(
				'status' => 'error',
				'message' => 'Insecure protocol not allowed.',
				));
			} // else
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

// dynamic methods
	protected function chk_API_vf_path($vf) {
		$api_map = &self::$api_resource_map;	// Ccms_api_map::get_api_resource_map();
		if(isset($api_map['paths'][$vf])) {
			$this->api_request_vf = $vf;
			return true;
			} // if
		// search for it
		$vf_parts = explode('/',$vf);
		foreach($api_map['paths'] as $path => &$cnt) {
			$path_parts = explode('/',$path);
			if(count($vf_parts) != count($path_parts)) continue;
			$idx = 1;	// start from 1 as the first val is empty because of the first /
			$fnd = true;	// assume true
			$in_line_vals = array();
			$in_line_vf = '';
			while((!empty($vf_parts[$idx])) && (!empty($path_parts[$idx]))) {	// step thru it
				if($vf_parts[$idx] != $path_parts[$idx]) {
					if(preg_match('/\{[a-x0-9_]+\}/i',$path_parts[$idx])) {	// it's an inline variable
						$nam = preg_replace('/^.*\{([a-x0-9_]+)\}.*$/i','$1',$path_parts[$idx]);
						$in_line_vals[$nam] = $vf_parts[$idx];
						} // if
					else {
						$fnd = false;
						break;
						} // else
					} // if
				$in_line_vf .= '/' . $path_parts[$idx];	// to match paths[]
				$idx++;
				} // while
			if(($fnd) && ($idx == count($vf_parts))) {
				$this->api_request_vf = $in_line_vf;
				$this->api_request_vf_vals = $in_line_vals;
				return true;
				} // if
			} // foreach
		return false;
		} // chk_API_vf_path()

	protected function get_api_vf_path() {	// get virtual folders as path
		if(!empty($_SERVER['PATH_INFO'])) {
			$vf = $_SERVER['PATH_INFO'];	// e.g. /summary
			if($this->chk_API_vf_path($vf)) return true;
			} // if
		if(!empty($_SERVER['REQUEST_URI'])) {	// from rewrite ??
			// e.g. "/APPS_CMS/branches/AppsCMS/api/session/open?username=tester&password=tester"
			$res_uri = preg_replace('/\?.*$/','',$_SERVER['REQUEST_URI']);	// query variables will be in $_GET
			$ws_dir = DOCROOT_WS_BASE_DIR;
			$path = substr($res_uri,(strlen($ws_dir)));	// e.g. /api/summary
			$api_bases = array('/api.php','/api');
			foreach($api_bases as $base) {
				$b_siz = strlen($base);
				if(!strcasecmp($base,substr($path,0,$b_siz))) {
					$vf = substr($path,$b_siz);
					if($this->chk_API_vf_path($vf)) return true;
					} // if
				} // foreach
			} // if
		// quirk
		$query = self::get_or_post(CMS_C_API_REWRITE_NAME);
		if(!empty($query)) {
			if($this->chk_API_vf_path('/' . $query)) return true;
			if($this->chk_API_vf_path($query)) return true;
			} // if
		self::addMsg('No API path found.');
		return false;
		} // get_api_vf_path()

	public function get_api_request() {
		if(!$this->get_api_vf_path()) return false;
		$this->api_request_method = 'get';	// set a default
		if(!is_array($this->api_request)) {
			$this->api_request = array();
			} // if

		switch($_SERVER['REQUEST_METHOD']) {
		case 'GET':
			$this->api_request_method = 'get';
			$request = &$_GET;
			if(empty($request)) $request = $_REQUEST;
			break;
		case 'PUT':
			$this->api_request_method = 'put';
			$request = &$_REQUEST;	// includes GET (and usually POST)
			break;
		case 'POST':
			$this->api_request_method = 'post';
			$request = &$_POST;
			break;
		default:
			$this->api_request_method = $_SERVER['REQUEST_METHOD'];
			break;
			} // switch
		if(empty($request)) {
			$request = $_REQUEST;
			//$this->api_request_method = 'get';
			} // if
		if(empty($request)) {
			$request = file_get_contents("php://input");
			if((!empty($request)) && (!is_array($request)) &&
				($chk = @sself::json_decode($request))) {
				$request = $chk;
				} // if
			// $this->api_request_method = 'post';
			} // if
		if((empty($request)) && (empty($this->api_request_vf))) {
			self::addMsg('API empty request.');
			$this->add_http_code(400,'API empty request.');
			$this->send_api_response(array(
				'status' => 'error',
				'message' => 'API request empty.',
				));
			return false;
			} // if
		$this->api_request['payload'] = $request;
		return true;
		} // get_api_request()

	public function send_api_response($response = false) {
		$api_response = &$this->api_response;
		$func_cntl = &self::$api_func_cntl;
		if(is_array($api_response)) {
			$out = array();
			if((!empty($api_response)) && (!empty($response))) {	// merge the responses
				if(is_array($response))
					$out = array_merge($api_response,$response);
				else {
					$out = $api_response;
					$out['response'] = $response;	// as text
					} // else
				} // if
			else if(!empty($response)) {
				$out = $response;
				} // if
			else if(!empty($api_response)) {
				$out = $api_response;
				} // if
			} // if
		else {	// text
			$out = $api_response;
			if(!empty($response)) {
				if(is_array($response)) $out .= PHP_EOL . 'Response JSON: ' . self::json_encode($response) . PHP_EOL;
				else $out .= PHP_EOL . 'Response: ' . $response . PHP_EOL;
				} // if
			} // else

		if(empty($out)) {	// no response data available
			$this->add_http_code(400, 'API cmd not found.');
			$result = array(
				'cmd' => $this->api_cmd,
				'session' => (self::is_cms_user() ? 'active':'inactive'),
				'timestamp' => self::get_us_datetime(),
				'status' => 'error',
				'message' => 'No data available' . (empty($this->api_cmd) ? ' (cmd not found)':'') . '.',
				);
			if(!empty($this->api_errors)) $result['status'] = $this->api_errors;
			if(self::getMsgsCount()) {
				$result['APImsgs'] = self::getMsgsAPIresult();
				} // if
			self::$api_response_headers['Content-Type'] = 'application/json';	// default
			$this->send_api_headers();
			echo self::json_encode($result);	// output
			return false;
			} // if

		$mime_type = $func_cntl['produces'][0];
		switch($mime_type) {
		default:
		case 'application/json':
			// $out contains an array ?? check
			$result = array(
				'cmd' => $this->api_cmd,
				'session' => (self::is_cms_user() ? 'active':'inactive'),
				'timestamp' => self::get_us_datetime(),
				'status' => 'success',
				);
			if(!empty($this->api_errors)) $result['status'] = $this->api_errors;
			if(is_array($out)) $result = array_merge($result,$out);	// $out will update $result['result']
			else { // assume it's plain text
				$result['text'] = PHP_EOL . $out . PHP_EOL;
				self::addMsg('Output is not a JSON, treated as text.');
				} // if
			if(self::getMsgsCount()) {
				$result['APImsgs'] = self::getMsgsAPIresult();
				} // if
			self::$api_response_headers['Content-Type'] = $func_cntl['produces'][0];	// default
			$text = self::json_encode($result);	// output
			break;
		case 'text/csv':
			// $out contains csv
			$result = false;
			if(is_array($out)) { // assume it's array
				if((empty($func_cntl['produces'][1])) ||
					($func_cntl['produces'][1] != 'application/json')) {
					self::addMsg('CSV output is an array, sent as JSON.','warn');
					} // if
				self::$api_response_headers['Content-Type'] = 'application/json';	// change
				$result = array(
					'cmd' => $this->api_cmd,
					'session' => (self::is_cms_user() ? 'active':'inactive'),
					'timestamp' => self::get_us_datetime(),
					'status' => 'success',
					);
				if(!empty($this->api_errors)) $result['status'] = $this->api_errors;
				$result['payload'] = $out;
				$text = self::json_encode($result);	// output
				} // if
			else {
				self::$api_response_headers['Content-Type'] = $func_cntl['produces'][0];	// default
				$result = '';
				// $result .= 'cmd: ' . $this->api_cmd . PHP_EOL;
				// $result .= 'session: ' . (self::is_cms_user() ? 'active':'inactive') . PHP_EOL;
				// $result .= 'timestamp: ' . self::get_us_datetime() . PHP_EOL;
				// $result .= 'status' . 'success' . PHP_EOL;
				if(!empty($this->api_errors)) $result .= 'status: ' . implode(PHP_EOL,$this->api_errors) . PHP_EOL;
				if(self::getMsgsCount()) {
					$result .= PHP_EOL . 'APImsgs: ' . implode(PHP_EOL,self::getMsgsAPIresult()) .PHP_EOL;
					} // if
				$text = $out . $result;	// output
				} // else
			break;
		case 'text/html':
		case 'text/plain':
			// $out contains text
			$result = '';
			// $result .= 'cmd: ' . $this->api_cmd . PHP_EOL;
			// $result .= 'session: ' . (self::is_cms_user() ? 'active':'inactive') . PHP_EOL;
			// $result .= 'timestamp: ' . self::get_us_datetime() . PHP_EOL;
			// $result .= 'status' . 'success' . PHP_EOL;
			if(!empty($this->api_errors)) $result .= 'status: ' . implode(PHP_EOL,$this->api_errors) . PHP_EOL;
			if(is_array($out)) { // check if it's array
				$out = implode(PHP_EOL,$out) .PHP_EOL;
				// self::addMsg('Text output is an array, converted to text.','warn');
				} // if
			if(self::getMsgsCount()) {
				$result .= PHP_EOL . 'APImsgs: ' . implode(PHP_EOL,self::getMsgsAPIresult()) .PHP_EOL;
				} // if
			self::$api_response_headers['Content-Type'] = $func_cntl['produces'][0];	// default
			$text = $out . $result;	// output
			break;
			} // switch
		if(empty(self::$api_response_headers['Content-Type']))	// bad map (??)
			self::$api_response_headers['Content-Type'] = 'application/json';
		$this->add_http_code();	// check and put in missing HTTP Code
		$this->send_api_headers();
		echo $text;	// out it goes
		return true;
		} // send_api_response()

	protected function get_param_by_type(&$req_pm,&$param) {
		$val = $param;	// because its a ref
		if(!isset($req_pm['type'])) return $val;
		switch(strtolower($req_pm['type'])) {
		case 'integer':	// workaround for swagger bug
		case 'int':
		case 'int32':	// ??
		case 'int64':	// swagger compatibility
			$val = (int)$param;	// a string representation (with rounding)
			break;
		case 'float':
			$val = (float)$param;	// a string representation (e.g. 1.25e-2)
			break;
		case 'number':	// usually returns as text (int or float)
			if(!is_numeric($param)) $val = 0;
			else { // pickles
				$int = intval($param);
				$flt = floatval($param);
				if((float)$int == (float)$flt) $val = $int;
				else $val = $flt;
				} // else
			break;
		case 'string':
			$val = sprintf('%s',$param);	// string
			break;
		default:
			$val = $param;
			break;
			} // switch
		return $val;
		} // get_param_by_type()

	protected function chk_api_params(&$required_params,&$request_params) {
		$ok = true;
		foreach($required_params as &$req_pm) {
			$name = $req_pm['name'];
			$in = $req_pm['in'];
			switch($in) {
			case 'header':
				if(isset(self::$api_request_headers[$name])) {
					$val = self::$api_request_headers[$name];
					$request_params[$name] = $this->get_param_by_type($req_pm, $val);
					} // if
				else {
					$request_params[$name] = null;
					if(empty($req_pm['required'])) break;
					$this->api_errors[] = array('error' => $name . ' parameter not found.');
					$ok = false;
					} // else
				break;
			case 'app':	// probably from php://input
			case 'body':	// probably from php://input
				if(isset($this->api_request_vf_vals[$name])) {
					$val = $this->api_request_vf_vals[$name];
					$request_params[$name] = $this->get_param_by_type($req_pm, $val);
					break;
					} // if
				if(!empty($this->api_request['payload'])) {
					$request_params[$name] = &$this->api_request['payload'];
					} // if
				else $ok = false;
				break;
			case 'path':
				if(isset($this->api_request_vf_vals[$name])) {
					$val = $this->api_request_vf_vals[$name];
					$request_params[$name] = $this->get_param_by_type($req_pm, $val);
					break;
					} // if
				// fall thru
			case 'query':
			default:
				if(!self::is_get_or_post($name)) {
					$request_params[$name] = null;
					if(empty($req_pm['required'])) break;
					$this->api_errors[] = array('error' => $name . ' parameter not found.');
					$ok = false;
					} // if
				else {
					$val = self::get_or_post($name);
					$request_params[$name] = $this->get_param_by_type($req_pm, $val);
					} // else
				break;
				} // switch
			} // foreach
		if(!$ok) $this->api_errors[] = array('error' => 'API missing parameter.');
		return $ok;
		} // chk_api_params()

	protected function call_api_func(&$cntl_map,&$api_request,&$api_response) {
		if(!self::is_api()) exit(11001);	// API disabled, etc.
		if(empty($cntl_map[$this->api_request_method])) return false;
		if(!$this->chk_api_role($cntl_map['_role'])) {
			$this->add_http_code(403, 'Operation not authorised.');
			$this->api_errors[] = 'Operation not allowed.';
			return false;
			} // if
		self::$api_cntl_map = $cntl_map;
		self::$api_func_cntl = $cntl_map[$this->api_request_method];	// for methods and function in other code.
		$meth = &$cntl_map[$this->api_request_method];
		$required_params = array();
		$request_params = array();
		if(!empty($meth['parameters'])) {
			$required_params = $meth['parameters'];
			if(!$this->chk_api_params($required_params,$request_params)) return false;
			} // if
		$func = false;
		if((is_callable($cntl_map['_func'],false,$func)) &&
			(function_exists($func))) {	// global function or class static method
			$response = @call_user_func($func,$this->api_request_method,self::$api_func_cntl,$request_params);
			if(is_array($api_response)) {
				$api_response = array_merge($api_response,$response);	// add
				} // if
			else $api_response = $response;	// first
			return true;
			} // if
		$func = $cntl_map['_func'];
		if(method_exists($this,$func)) {	// in dynamic scope of $this
			$response = @$this->$func($this->api_request_method,self::$api_func_cntl,$request_params);
			if(is_array($api_response)) {
				$api_response = array_merge($api_response,$response);	// add
				} // if
			else $api_response = $response;	// first
			return true;
			} // if
		self::addAdminMsg('User function: ' . $cntl_map['_func'] . ' not available.');
		$this->add_http_code(404,'Method or function call not found');
		return false;
		} // call_api_func()

	protected function vf_path_to_map(&$api_resource_map) {
		if(empty($this->api_request_vf)) return false;	// no virtual folder path
		$paths = &$api_resource_map['paths'];
		$vf = &$this->api_request_vf;
		foreach($paths as $p => &$v) {
			if($p == $vf) {
				$this->api_cmd = $p;
				return $v;
				} // if
			} // foreach
		$this->add_http_code(404);
		return false; // not found
		} // vf_path_to_map()

	protected function decode_api_cmd(&$api_request,&$api_resource_map,&$api_response) {
		if(empty($api_resource_map)) return false;
		if($cntl_map = $this->vf_path_to_map($api_resource_map)) {
			if(!$this->call_api_func($cntl_map, $api_request, $api_response)) {
				$this->add_http_code(400);
				return false;
				} // if
			} // if
		if(!empty($api_response)) return true;
		$this->add_http_code(204);
		return false;
		} // decode_api_cmd()

} // Ccms_api
