<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_ops.php 3159 2023-02-16 10:41:56Z robert0609 $
 */

/**
 * Description of cms_ops
 *
 * Class to package, provides session isolation and basic ops for cms core
 *
 * @author robert0609
 */

require_once(CMS_FS_CLASSES_DIR . 'cms_html.php');	// speed up, save class lookup

class Ccms_ops extends Ccms_html {

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// static methods

	public static function do_gen_pre_body() {
		if(self::is_full_body_view()) {
			$body_cnt = self::get_body_cnt();
			$body = '';
			if($body_cnt > 0) {
				if(!$body = self::get_body()) {	// should not happen
					self::log_msg('ERROR: Could not find a page body.');
					return false;
					} // if
				} // if
			self::output_body_core($body);
			return false;	// done
			} // if
			
		$cms_action = self::get_cms_action();
		$app_action = self::get_app_action();
		if((empty($cms_action)) && (empty($app_action)) && (!self::is_vfs())) {	// go home
			self::get_app_action('home');
			} // if

		switch($cms_action) {
		case 'cms_login':
			if($submit = self::get_or_post('submit')) {
				if($submit == 'cancel') {
					self::get_app_action(false);
					self::unset_cms_sess_var('cms_action');
					self::do_redirect_uri(self::get_base_url(true));
					} // if
				} // if
			Ccms_auth::login_user();
			if ((CMS_S_LOGIN_VIA_HOMEPAGE_BOOL) && (Ccms_base::is_cms_guest())) {
				// special case see login CAUTION in install settings
				self::do_redirect_uri(self::get_base_url(true));
				} // if
			if((Ccms_auth::is_login_allowed()) && (Ccms_base::is_cms_guest())) {
				$cms_body_id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_login_page > 0 AND cms_body_enabled > 0");
				if((int)$cms_body_id > 0) {	// have a login page
					$url = self::get_base_url(true) . self::get_body_uri($cms_body_id);
					self::do_redirect_uri($url);
					} // if
				} // if
			self::unset_cms_sess_var('cms_action');
			break;
		case 'cms_eula':
			self::unset_cms_sess_var('cms_action');
			Ccms_auth::check_eula_form();	// will logout if dont agree
			break;
		case 'set_password':
			self::unset_cms_sess_var('cms_action');
			Ccms_auth::set_password();
			break;
		case 'cms_about':
			self::unset_cms_sess_var('cms_action');
			break;
		case 'cms_manual':
			if(CMS_S_ALLOW_ABOUT_MANUAL_LINKS_BOOL) break;
			if(Ccms_base::is_cms_guest()) {
				self::unset_cms_sess_var('cms_action');
				$url = self::get_base_url(true) . self::get_body_uri();
				self::do_redirect_uri($url);
				} // if
			break;
		case 'cms_rebuild_setup':
			if(Ccms_auth::is_cms_admin_user()) {
				define('REBUILD_MODE',true);
				self::is_rebuild(REBUILD_MODE);	// set to rebuild
				self::backup_settings_configs();
				Ccms_autoloader::get_ops_dirs_list(true);	// reload autoloader
				if((Ccms_DB_install::rebuild_from_settings()) &&
					(self::do_cms_warnings(true)) &&
					(self::do_cms_cli_warnings(true)) &&
					(self::$cDBcms->checkDBversion(true))) { // rebuild setup
					self::backupOnSave();
					self::addMsg('Setup rebuild complete.','success');
					} // if
				else self::addMsg('Failed to rebuild setup.','error');
				} // if
			else self::addMsg('Must be an administrator to rebuild setup.','error');
			self::unset_cms_sess_var('cms_action');
			$url = self::get_base_url(true) . self::get_body_uri();
			if(!headers_sent()) {
				self::saveMsgs();
				self::do_redirect_uri($url);
				} // if
			else {
				echo self::getMsgs();
				echo PHP_EOL . '<br><a href="' . $url . '"><b>Click to return.</b>  </a>';
				} // else
			exit (0);
			break;
		case 'cms_log_view':
			if(!Ccms_auth::is_cms_admin_user()) {
				self::addMsg('Must be an administrator to view logs.','error');
				self::saveMsgs();
				self::unset_cms_sess_var('cms_action');
				$url = self::get_base_url(true) . self::get_body_uri();
				self::do_redirect_uri($url);
				} // if
			break;
		case 'cms_browse_sessions':
			if(!Ccms_auth::is_cms_admin_user()) {
				self::addMsg('Must be an administrator to browse sessions.','error');
				self::saveMsgs();
				self::unset_cms_sess_var('cms_action');
				$url = self::get_base_url(true) . self::get_body_uri();
				self::do_redirect_uri($url);
				} // if
			break;
		case 'cms_users_stats':
			if(!Ccms_auth::is_cms_admin_user()) {
				self::addMsg('Must be an administrator to browse user statics.','error');
				self::saveMsgs();
				self::unset_cms_sess_var('cms_action');
				$url = self::get_base_url(true) . self::get_body_uri();
				self::do_redirect_uri($url);
				} // if
			break;
		case 'cms_version':
			self::output_include_body_text(CMS_FS_DIR . "AppsCMS-version.info",'',false);
			exit(0);

		case 'admin_extend':
		case 'apps_manual':
		case 'app_manual':
			// allowed
			break;
		default:
			break;
			} // switch

		switch($app_action) {
		case 'login':
			if((!CMS_S_LOGIN_TRANSLATE2CMS_BOOL) &&
				(!empty(self::$cms_body_id))) {
				break;	// an app takes care of it
				} // if
			self::reset_session_actions();
			if($submit = self::get_or_post('submit')) {
				if($submit == 'cancel') {
					self::do_redirect_uri(self::get_base_url(true));
					} // if
				} // if
			Ccms_auth::login_user();
			if ((CMS_S_LOGIN_VIA_HOMEPAGE_BOOL) && (Ccms_base::is_cms_guest())) {
				// special case see login CAUTION in install settings
				self::do_redirect_uri(self::get_base_url(true));
				} // if
			if((Ccms_auth::is_login_allowed()) && (Ccms_base::is_cms_guest())) {
				$cms_body_id = self::$cDBcms->get_data_in_table('cms_bodies', 'cms_body_id', "cms_body_login_page > 0 AND cms_body_enabled > 0");
				if((int)$cms_body_id > 0) {	// have a login page
					$url = self::get_base_url(true) . self::get_body_uri($cms_body_id);
					self::do_redirect_uri($url);
					} // if
				} // if
			break;
		case 'eula':
			if((!CMS_S_EULA_TRANSLATE2CMS_BOOL) &&
				(!empty(self::$cms_body_id))) {
				break;	// an app takes care of it
				} // if
			self::reset_session_actions();
			Ccms_auth::check_eula_form();	// will logout if dont agree
			break;
		//case 'set_password':
		//	self::reset_session_actions();
		//	Ccms_auth::set_password();
		//	break;
		case 'apps_manual':
		case 'app_manual':
			if(!CMS_S_ALLOW_ABOUT_MANUAL_LINKS_BOOL) break;
			if(Ccms_base::is_cms_guest()) {
				self::reset_session_actions();
				$url = self::get_base_url(true) . self::get_body_uri();
				self::do_redirect_uri($url);
				} // if
			break;
		case 'body_extend':
			break;
		default:
			break;
			} // switch
			
		return true;
		} // do_gen_pre_body()

	public static function do_site_redirect($code = 301) {
		$url = self::is_web_site_redirected();
		if(!empty($url)) {
			self::addAdminMsg('Redirected to: ' . $url . ', code: ' . $code,'info');
			header('Location: ' . $url, true, $code);
			die();
			} // if
		return false;
		} // do_site_redirect()

	public static function do_site_closed() {
	if((self::is_web_site_closed()) &&
		(!Ccms_auth::is_cms_admin_user())) {	// don't squash admin already logged in
		if(self::get_cms_action() == 'cms_login')
			self::set_cms_sess_var('cms_login','cms_action');	// remember its a login sequence
		if((self::get_cms_sess_var('cms_action') != 'cms_login') &&
			(self::get_cms_action() != 'cms_login')) {
			include(CMS_FS_OPS_DIR . "cms_closed.php");
			require_once CMS_FS_INCLUDES_DIR . 'cms_bottom.php';
			exit(0);
			} // if
		} // if
		return false;
		} // do_site_closed()

	public static function do_site_sess_close() {
		// save last url for variable recovery
		$current_url = (!empty($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI']:'');
		if(!preg_match('/ajax=|ajax\.php/',$current_url)) {	// no ajax url
			self::set_cms_sess_var($current_url,'last_url');
			self::set_cms_sess_var(time(),'last_time');
			} // if
		else {
			self::set_cms_sess_var($current_url,'last_ajax');
			} // else
		self::set_cms_sess_var(Ccms_auth::get_client_ip_address(),'client_ip');
		// session closed by server
		} // do_site_sess_close()()

	// dynamic methods

} // Ccms_ops
