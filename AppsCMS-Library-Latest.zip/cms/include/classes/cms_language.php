<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_language.php 2991 2022-11-15 09:45:12Z robert0609 $
 */

/**
 * Description
 * Ccms_language translate text to another language
 *
 * @TODO May add more as required/available
 *
 * @author robert0609
 */

class Ccms_language extends Ccms_base {

	private static $langs_avail = false;
	protected static $lang_from = CMS_LANG_DEFAULT;
	protected static $lang_to = false;
	private const METHOD_DEF = 'translate_shell';
	private const METHODS_PLUGINS_AVAIL = 'translate_shell';

	private const TRANS_BIND_MKR_ELEM = 'translateboundary';
	private const TRANS_START_MKR = '<' . self::TRANS_BIND_MKR_ELEM . ' id="id_translated" class="translated">';
	private const TRANS_END_MKR = '</' . self::TRANS_BIND_MKR_ELEM . '>';

	protected const BRWR_LANG_CODES = 'browser-language-codes.json';
	protected const TRANS_LANG_CACHE_JSON = 'trans_langs_cache.json';

	protected const TAGS2TRANSLATE = array('h1','h2','h3','h4','td','th','p','li','button' ,'a','div','span');	// tags with text to translate

	protected static $elem_pre_sent =false;

	function __construct() {
		} // __construct()

	function __destruct() {
		} // __destruct()

// static methods
	public static function get_trans_mothods_available() {
		$methods = explode(':',self::METHODS_PLUGINS_AVAIL);
		return $methods;
		} // get_trans_mothods_available()

	public static function &get_available_languages($add_cmmn_langs = true) {
		if(!empty(self::$langs_avail)) return self::$langs_avail;	// do once

		if(($langs_cache = self::load_json(VAR_FS_CACHE_DIR . self::TRANS_LANG_CACHE_JSON)) &&
			(!empty($langs_cache['expiry'])) &&
			($langs_cache['expiry'] > time()) &&
			($langs_cache['engine'] == Ccms_translate_plugin::get_def_engine())) {
			self::$langs_avail = $langs_cache['langs'];
			return self::$langs_avail;
			}

		$langs_avail = Ccms_translate_plugin::get_translate_languages();

		// add the extra variants
		$langs_avail = array_merge($langs_avail,array(
			'zh' => 'Chinese',
			'zh-CN' => 'Chinese (Simplified)',
			'zh-TW' => 'Chinese (Traditional)',
			'zh-SG' => 'Chinese (Singapore)',
			'en-029' => 'English (Caribbean)',
			'en-AU' => 'English (Australia)',
			'en-BZ' => 'English (Belize)',
			'en-CA' => 'English (Canada)',
			'en-GB' => 'English (United Kingdom)',
			'en-IE' => 'English (Ireland)',
			'en-JM' => 'English (Jamaica)',
			'en-NZ' => 'English (New Zealand)',
			'en-PH' => 'English (Republic of the Philippines)',
			'en-TT' => 'English (Trinidad and Tobago)',
			'en-US' => 'English (United States)',
			'en-ZA' => 'English (South Africa)',
			'en-ZW' => 'English (Zimbabwe)',
			));

		$browser_langs = self::load_json (CMS_FS_LIB_DIR . self::BRWR_LANG_CODES);	// control (all lowercase)
		if(empty($browser_langs)) {
			self::addAdminMsg('Missing library master language codes json');
			return false;
			} // if
		self::$langs_avail = array();
		$br_langCodes = &$browser_langs['langCodes'];
		foreach($langs_avail as $c => $n) {
			if(isset($br_langCodes[strtolower($c)])) {
				self::$langs_avail[$c] = $n;		// ok key = value
				continue;
				} // if
			else if(isset($br_langCodes[strtolower($n)])) {
				self::$langs_avail[$n] =  $br_langCodes[$n];		// ok but no key
				continue;
				} // if
			else self::log_msg('Cannot find ' . $c . ' => ' . $n . ' in master browser language code library.','warn');
			} // foreach

		if(self::is_debug()) asort(self::$langs_avail);	// debug only
		$expiry = (time() + (int)(7 * 24 * 3600));
		$data = array('expiry' => $expiry,'engine' => Ccms_translate_plugin::get_def_engine(),'langs' => self::$langs_avail);
		self::save_json(VAR_FS_CACHE_DIR . self::TRANS_LANG_CACHE_JSON,$data);
		return self::$langs_avail;
		} // get_available_languages()

	public static function reset_language_caches() {
		@unlink(VAR_FS_CACHE_DIR . self::TRANS_LANG_CACHE_JSON);
		return true;
		} // reset_language_caches()

	public static function get_language_name($lang_code) {
		if(empty($lang_code)) return '(default language)';
		$langs = self::get_available_languages();
		if(empty($langs[$lang_code])) return '(default language)';
		$name = $langs[$lang_code];
		if(!empty($name)) return $name;
		return '(default language)';
		} //  get_language_name()

	public static function get_language_selector($elem_name,$elem_value,$class = false, $params = false) {
		$options = self::get_available_languages();
		$id = 'id_' . $elem_name;
		$text = array();
		// check if a search filter used
		$text[] = Ccms_edit::get_select_option_filter($id, '',-1,Ccms_edit::count_sel_opts($options));
		$text[] = '<select id="' . $id . '" onclick="javascript:cms_filter_select_click(this);" name="' . $elem_name . '"' .
			($class ? ' class="' . $class . '"':'') . ($params ? ' ' . $params . ' ':'') . '>' . PHP_EOL;
			$select_done = false;
			$text[] ='	<option ' . 'value=""' . (empty($elem_value) ? ' SELECTED':'') . '>' . '-- (default) --' . '</option>' . PHP_EOL;
			foreach($options as $n => $val) {	// language and code is in the reversed column
				if(($n == $elem_value) || ($val == $elem_value)) { $select_done = true; $selected = ' SELECTED'; } // if
				else $selected = '';
				$text[] ='	<option ' . 'value="' . $n . '"' . $selected . '>' . htmlentities($val) . '</option>' . PHP_EOL;
				} // foreach
		$text[] = '</select>' . PHP_EOL;
		$text[] = '<script type="text/javascript">';
		$text[] = '	cms_preventDefSelectEvent("{$id}");';
		$text[] = '</script>';

		return PHP_EOL . "\t\t" . implode(PHP_EOL . "\t\t",$text) . PHP_EOL;
		} // get_language_selector()

	public static function check_language($lang) {
		$langs_avail = self::get_available_languages();
		$lang_pat = preg_replace('/([^\w\d]+)/s','.*',$lang);	// slightly heuristic, skip non alphanumerics, ???
		if($lang == $lang_pat) $lang_pat = false;
		$lused = array_filter($langs_avail, function($lname,$lcode) use ($lang,$lang_pat) {	// find unused keys
			if(!strcasecmp($lang,$lname)) return true;	// used
			if(!strcasecmp($lang,$lcode)) return true;	// used
			if(($lang_pat) && (preg_match('/' . $lang_pat . '/i',$lname))) return true;
			return false;
			},ARRAY_FILTER_USE_BOTH);
		if(empty($lused)) return false;
		return array_key_first($lused);
		} // check_language()

	private static function chk_lang($lang) {
		if(preg_match('/^en/i',$lang)) return 'en';	// translators only know english
		return str_replace('_','-',$lang);
		} // chk_lang()

	public static function init($lang_to,$lang_from = CMS_LANG_DEFAULT) {
		// check from language
		if(is_array($lang_to)) {	// from an array
			$langs = $lang_to;
			if(empty($langs['from_lang'])) $lang_from = CMS_LANG_DEFAULT;
			else $lang_from = $langs['from_lang'];
			if(empty($langs['to_lang'])) {
				self::addAdminMsg('CODE ERROR: Failed to provide to language parameter. Check code.');
				return false;
				} // if
			else $lang_to = $langs['to_lang'];
			} // if
		$lang_from_chk = self::check_language($lang_from);
		if(empty($lang_from_chk)) {
			self::addAdminMsg('Failed from language check: ' . $lang_from . '. Check language settings.');
			return false;
			} // if

		// check to language
		if(empty($lang_to)) $lang_to_chk = $lang_from_chk;
		else $lang_to_chk = self::check_language($lang_to);
		if(empty($lang_to_chk)) {
			self::addAdminMsg('Failed to language check: ' . $lang_to . '. Check language settings.');
			return false;
			} // if
			
		self::$lang_from = $lang_from_chk;
		self::$lang_to = $lang_to_chk;

		return Ccms_translate_plugin::trans_init($lang_to_chk,$lang_from_chk);
		} // init()

	public static function is_ok() {
		if((empty(self::$lang_from)) ||
			(empty(self::$lang_to))) {
			return false;
			} // if
		switch(CMS_S_LANG_TRANS_METHOD) {
		case 'translate_shell':
			return Ccms_translate_plugin::trans_chk();	// for the moment
			// break;
		// decode other translator status calls here
		default:
			break;
			} // switch
		return false;
		} // is_ok()

	public static function translate_text(&$text) {
		if(empty($text)) return '';
		$transd = false;
		switch(CMS_S_LANG_TRANS_METHOD) {
		case 'translate_shell':
			$transd = Ccms_translate_plugin::trans_lang($text);
			break;
		// decode other translate methods here
		default:
			return $text;
			break;
			} // switch
		if(empty($transd)) return false;
		return $transd;
		} // translate_text()

	public static function get_body_lang_trans_codes($inc_file_hint = false,$body = false) {
		if(!CMS_S_LANG_TRANSLATE_BOOL) return false;	// no translate
		$langs = false;	// default
		if((!empty($body['cms_body_lang'])) &&
			($body['cms_body_lang'] > 0) &&
			(!self::is_iframe_body_view())) {
			$langs = array(
				'from_lang' => (!empty(CMS_S_BASE_APP_LANG) ? CMS_S_BASE_APP_LANG:CMS_CORE_LANG),
				'to_lang' => $body['cms_body_lang'],
				);
			} // if
		else if((!self::is_iframe_body_view()) &&
			(!empty(self::$cms_page_info['filepath'])) &&
			(	($inc_file_hint == self::$cms_page_info['filepath']) ||
				($inc_file_hint == CMS_FS_OPS_DIR . "cms_body.php")
			)	) {
			$langs = array(
				'from_lang' => (!empty(CMS_S_BASE_APP_LANG) ? CMS_S_BASE_APP_LANG:CMS_CORE_LANG),
				'to_lang' => (!empty(self::$cms_body_lang) ? self::$cms_body_lang:CMS_S_LANGUAGE_CODE),
				);
			} // if
		else if($user_lang = self::get_user_language()) {
			$langs = array(
				'from_lang' => (!empty(CMS_S_BASE_APP_LANG) ? CMS_S_BASE_APP_LANG:CMS_CORE_LANG),
				'to_lang' => $user_lang,
				);
			} // if
		if((!empty($langs)) &&
			(!empty($langs['from_lang'])) && (!empty($langs['to_lang'])) &&
			(Ccms_translate_plugin::sanitize_langs($langs)) &&	// returns !false if translation required
			($langs['from_lang'] != $langs['to_lang']))
			return $langs;
		return false;
		} // get_body_lang_trans_codes()

	private static function is_elem_translated(&$elem) {
		if(empty(self::$lang_to)) return false;
		$lang = $elem->getAttribute('data-tolang');
		if((!empty($lang)) && ($lang == self::$lang_to)) return true;
		$elem->setAttribute('data-tolang',self::$lang_to);
		return false;
		} // is_elem_translated()

	private static function add_elem_title(&$elem,&$text) {
		if((self::is_debug()) && (CMS_S_LANG_TRANS_DEBUG_TITLE_BOOL)) {
			$title = $elem->getAttribute('title');
			if(!preg_match('/\(' . self::$lang_from . ': /',$title)) return; // don't double up
			$title .= '(' . self::$lang_from . ': ' . strip_tags($text) . ')';
			$elem->setAttribute('title',$title);
			} // if
		} // add_elem_title()

	private static function domTransTextNode(DOMNode &$domNode) {
		if(self::is_elem_translated($domNode->parentNode)) return true;	// dont double up
		$text = $domNode->textContent;
		if(empty($text)) return false;
		$transd = self::translate_text($text);
		if(empty($transd)) return false;
		$newTextNode = $domNode->ownerDocument->createTextNode($transd);
		if(!$domNode->replaceChild( $newTextNode, $domNode )) {
			$domNode->textContent = $transd;
			} // if
		self::add_elem_title($domNode->parentNode,$text);
		return true;
		} // domTransTextNode()

	private static function domTraverseNode(DOMNode &$domNode) {
		if ( $domNode->hasChildNodes() ) {
		  $children = array();
			// since looping through a DOM being modified is a bad idea we prepare an array:
			foreach ( $domNode->childNodes as $child ) {
				$children[] = $child;
				} // foreach
			foreach ( $children as $child ) {
				if ( $child->nodeType === XML_TEXT_NODE ) {
					self::domTransTextNode($child);
					} // if
				else {
					self::domTraverseNode($child);
					} // else
				} // foreach
			return true;
			} // if
		return false;
		} // domTraverseNode()

	private static function elem_crawler_recurs(&$elem) {
		if(empty($elem)) return;
		if($elem->nodeType != XML_ELEMENT_NODE) return false;
		$tag = strtolower($elem->tagName);
		if(!in_array($tag,self::TAGS2TRANSLATE)) return false;
		// if(self::is_debug()) self::log_info_msg(print_r($elem,true));	// test
		if(!self::domTraverseNode($elem)) {	// no child
			self::domTransTextNode($elem);
			} // if
		// if(self::is_debug()) self::log_info_msg(print_r($elem,true));	// test
		return true;
		} // elem_crawler_recurs()

	protected static function dom_crawler(&$html) {
		if(!class_exists('DOMDocument')) return false;	// try DOMDocument
		libxml_use_internal_errors(true);
		$dom = new DOMDocument('1.0',CMS_S_CHAR_SET);
		$dom->validateOnParse = true;
		if(!@$dom->loadHTML($html)) {
			foreach (libxml_get_errors() as $error) {
				self::log_msg($error);	// handle errors here
				} // foreach
			libxml_clear_errors();
			self::addDebugMsg('HTML ERROR: Cannot load document, cannot translate.');
			return false;
			} // if

		$elems = $dom->getElementsByTagName('*');
		if(empty($elems)) return $html;
		foreach($elems as $elem) {
			self::elem_crawler_recurs($elem);	// start crawler
			} // foreach

		// self::dom_html_recurs($dom->documentElement);
		$text = $dom->saveHTML();
		return $text;
		} // dom_crawler()

	public static function translate_body_html($html,$langs) {
		// $html = 'Some try out free text.<p>Some paragraph text.</p>';	// test
		if(!CMS_S_LANG_TRANSLATE_BOOL) return $html;	// translate turned off
		if(!Ccms_translate_plugin::is_enabled()) return $html;
		if(!Ccms_translate_plugin::sanitize_langs($langs)) return $html;
		if(!self::init($langs)) {
			self::addAdminMsg('Failed to initialise language translator.');
			return $html;
			} // if
		// if(self::is_debug()) file_put_contents(VAR_FS_TEMP_DIR . 'test_text.html',$html);	// @TODO test only
		if(empty($html)) return '';

		$bound_html = self::TRANS_START_MKR . $html . self::TRANS_END_MKR;
		$text = self::dom_crawler($bound_html);	// try DOMDocument
		if(empty($text)) {
			self::addAdminMsg('Translation failed.','warn');
			return $html;
			} // if

		$txt1 = preg_replace('/^.*?<' . self::TRANS_BIND_MKR_ELEM . '.*?>/s','',$text);
		$text = preg_replace('/<\/' . self::TRANS_BIND_MKR_ELEM . '>.*$/s','',$txt1);

		return <<<EOTTR

	<!-- Start  of translation -->
		{$text}
	<!-- End  of translation -->

EOTTR;
		} // translate_body_html()

} // Ccms_language
