<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_logger.php 3321 2023-04-11 23:58:24Z robert0609 $
 */

/**
 * Description of logger
 *
 * @author robert0609
 */

require_once 'cms_base_utils.php';	// speed up for proxy (no autoloader needed)

class Ccms_logger extends Ccms_base_utils {

	private static $cms_log_filename = '';
	private static $cms_error_log_filename = '';
	private static $cms_logs_inuse = false;
	private static $cms_logs_buffr = array();

	public static $cms_record_time_times = false;
	private static $cms_last_record_time = false;

	private static $cms_logs_done = false;
	private static $cms_logs_initialised = false;

	protected const CMS_LOG_TYPE = '_cms-';
	protected const CMS_ERR_LOG_TYPE = '_error-';

	function __construct() {
		// initial log filenames here after TZ set
		self::log_init();
		} // __construct()

	function  __destruct() {
		} // __destruct()

	public function __call($name, $arguments) {
		// Note: value of $name is case sensitive.
		if((is_array($arguments)) || (is_object($arguments))) {
			self::log_msg("Calling unavailable object method: " . $name . " (" . print_r($arguments,true) . ")");
			} // if
		else self::log_msg("Calling unavailable object method: " . $name . " (" . implode(', ', $arguments) . ")");
		} // __call()

	public static function __callStatic($name, $arguments) {
		// Note: value of $name is case sensitive.
		if((is_array($arguments)) || (is_object($arguments))) {
			self::log_msg("Calling unavailable static method: " . $name . " (" . print_r($arguments,true) . ")");
			} // if
		else self::log_msg("Calling unavailable static method: " . $name . " (" . implode(', ', $arguments) . ")");
		} // __callStatic()

// virtuals
	public static function is_cli($set = null) { return false; } // virtual

// static methods
	public static function get_current_cms_logfile() {
		if(empty(self::$cms_log_filename)) {
			self::log_init();
			} // if
		return self::$cms_log_filename;
		} // get_current_cms_logfile()

	public static function get_current_error_logfile() {
		if(empty(self::$cms_error_log_filename)) {
			self::log_init();
			} // if
		return self::$cms_error_log_filename;
		} // get_current_error_logfile()

	private static function get_last_log_filename($mask) {
		$logs = glob(VAR_FS_LOGS_DIR . $mask);
		if(empty($logs)) return false;
		rsort($logs);	// last at [0]
		foreach($logs as $l) {	// weed out empty logs and return the latest
			$ret = '';
			$output = '';
			if(!preg_match('/\.zip$/i',$l)) $cmd = 'filesize "' . $l . '"';
			else $cmd = 'zipinfo "' . $l . '" | grep uncompress | awk \'{ print $3 }\'';
			$err = exec($cmd, $output, $ret);
			if($ret) continue;
			if((!empty($output)) && ((int)$output[0] > 100)) return $l;
			} // foreach
		return false;
		} // get_last_log_filename()

	protected static function get_cms_log_filename() {
		return self::get_last_log_filename(CMS_DOMAIN . self::CMS_LOG_TYPE . '*');
		} // get_cms_log_filename()

	protected static function get_cms_error_filename() {
		return self::get_last_log_filename(CMS_DOMAIN . self::CMS_ERR_LOG_TYPE . '*');
		} // get_cms_error_filename()

	protected static function get_cli_log_filename() {
		return self::get_last_log_filename('CLI' . self::CMS_LOG_TYPE . '*');
		} // get_cli_log_filename()

	protected static function get_cli_error_filename() {
		return self::get_last_log_filename('CLI' . self::CMS_ERR_LOG_TYPE . '*');
		} // get_cli_error_filename()

	public static function get_ms_timestamp() {	// get millisecond time stamp
		list($us,$sec) = explode(' ', microtime());
		return ((int)$sec) * 1000 + ((int)round($us * 1000));
		} // get_ms_timestamp()

	public static function get_us_timestamp() {	// get microsecond time stamp
		list($us,$sec) = explode(' ', microtime());
		return ((int)$sec) * 1000000 + ((int)round($us * 1000000));
		} // get_us_timestamp()

	public static function get_us_datetime() {	// get YYYY/MM/DD HH:MM:SS.UUUUUU, string to microsend resolution
		$d = new DateTime();
		return $d->format('Y-m-d H:i:s.u P'); // e.g. 2011-01-01 15:03:01.012345 +10:00
		} // get_us_datetime()

	public static function record_event_time($msg) {
		if(!self::$cms_record_time_times) return false;
		$diff = 0.0;
		$usecs = self::get_us_timestamp();
		if(self::$cms_last_record_time) $diff = $usecs - self::$cms_last_record_time;
		self::$cms_last_record_time = $usecs;
		return self::log_msg('EV (' .$diff . 'uS): ' . $msg);
		} // record_event_time()

	public static function addMsg($msg, $type = 'error') { // virtual method
		return false;
		} // addMsg()

	public static function addInfoMsg($msg) { // virtual method
		return false;
		} // addInfoMsg()

	protected static function zip_a_file($filepath, $delete_orig = true) {
		if(!class_exists('ZipArchive',false)) return false;
		if(!is_readable($filepath)) return false;
		$file = str_replace(DOCROOT_FS_BASE_DIR,'',$filepath);
		$zip = new ZipArchive();
		if(!$zip) return false;
		$fileZip = $file . '.zip';
		if(file_exists($fileZip)) {
			$zip->open($fileZip);
			$zip->addFromString($file, file_get_contents($file));
			// $zip->addFile($file);
			} // if
		else {
			$zip->open($fileZip, ZipArchive::CREATE);
			$zip->addFile($file);
			} // else
		$zip->close();
		Ccms_base::chmod_chown($fileZip);
		if($delete_orig) @unlink($file);
		return true;
		} // zip_a_file()

	protected static function _log_file_maintainer($path,$file_pattern,$inc_hidden = false) {	// do  usually only called after sysadmin login
		$npatt = '/' . date('Ymd') . '/';	// todays log files
		$fpatt = $file_pattern;	// its a regex '/' . preg_quote($file_pattern, '.\+*?[^]$(){}=!<>|:-#') . '/';
		if((defined('CMS_C_MAX_LOG_FILES')) &&
			((int)CMS_C_MAX_LOG_FILES > 0)) {
			$files = array();
			$logs = glob($path . '*.*');
			foreach($logs as $lf) {
				$f = basename($lf);
				if(preg_match($npatt, $f)) continue;	// not todays
				if(preg_match(CMS_DONT_ACCESS_PATH_SYSTEM_PATTERN,$f)) continue;
				if((!$inc_hidden) && (preg_match(CMS_DONT_ACCESS_PATH_HIDDEN_PATTERN,$f))) continue;
				if(!preg_match($fpatt, $f)) continue;	// not mine
				$ftime = filemtime($lf);
				while(isset($files[$ftime])) $ftime++;	// some logs created at the same time
				$files[$ftime] = $lf;
				} // foreach
			if(count($files) > CMS_C_MAX_LOG_FILES) {	// only when needed
				krsort($files);
				$skip = 0; $cnt = 0;
				foreach($files as $ft => $lf) {
					if($skip++ < (int)CMS_C_MAX_LOG_FILES) continue;
					@unlink($lf);
					$cnt++;
					} // foreach
				if($cnt > 0) self::log_msg ('Removed ' . $cnt . ' files.', 'info');
				} // if
			} // if
		if((defined('CMS_C_COMPRESS_LOGS_ENABLE')) &&
			(CMS_C_COMPRESS_LOGS_ENABLE)) {
			$cnt = 0;
			$logs = glob($path . '*.*');

			foreach($logs as $lf) {
				$f = basename($lf);
				if(preg_match('/\.zip$/', $f)) continue;	// already zipped
				if(preg_match($npatt, $f)) continue;	// not todays
				if(preg_match(CMS_DONT_ACCESS_PATH_SYSTEM_PATTERN,$f)) continue;
				if((!$inc_hidden) && (preg_match(CMS_DONT_ACCESS_PATH_HIDDEN_PATTERN,$f))) continue;
				if(!preg_match($fpatt, $f)) continue;	// not mine

				// just zip the file (don't include the path)
				$sav_dir = getcwd();
				chdir($path);
				if(self::zip_a_file($f)) $cnt++;	// ok zip it
				chdir($sav_dir);
				} // foreach
			if($cnt > 0) self::log_msg ('Zipped ' . $cnt . ' log files.', 'info');
			} // if
		return true;
		} // _log_file_maintainer()

	protected static function log_file_maintanence() {	// usually only called after sysadmin login
		if(self::$cms_logs_done) return true;
		self::$cms_logs_done = true;	// stop repeats
		// if(!Ccms_auth::is_cms_admin_user()) return false;	//
		$path = VAR_FS_LOGS_DIR;
		return self::_log_file_maintainer($path,'/(' . self::CMS_LOG_TYPE . '|' . self::CMS_ERR_LOG_TYPE. ')/');
		} // log_file_maintanence()

	private static function init_log_file($log) {
		if(!is_readable($log)) {	// create it
			$fh = Ccms_base::file_safe_wopen($log, 'w');
			if($fh) {
				Ccms_base::file_safe_wclose($fh,$log);
				if($user = Ccms_auth::get_logged_in_username())
					self::addMsg('Started new "' . basename($log) . '" by user: ' . $user . '.','info');
				} // if
			else self::addMsg('Failed to create "' . basename($log) . '".','warn');
			} // if
		} // init_log_file()

	protected static function log_init() {
		if(self::$cms_logs_initialised) return;
		self::$cms_logs_initialised = true;

		// do time zone first, otherwise we get log zip repeats
		if (!defined('CMS_S_TIMEZONE_TZ')) {
			$tz = Ccms_base::get_cms_ini_value('TIMEZONE_TZ','LanguageSettings');
			if(!empty($tz)) date_default_timezone_set($tz);
			else date_default_timezone_set(CMS_DEFAULT_TIMEZONE); // set a default
			} // if
		else date_default_timezone_set(CMS_S_TIMEZONE_TZ);

		self::$cms_log_filename = VAR_FS_LOGS_DIR . CMS_DOMAIN . self::CMS_LOG_TYPE . date('Ymd') . '.log';
		self::$cms_error_log_filename = VAR_FS_LOGS_DIR . CMS_DOMAIN . self::CMS_ERR_LOG_TYPE . date('Ymd') . '.log';
		Ccms_base::chkdir(VAR_FS_LOGS_DIR);
		self::init_log_file(self::$cms_log_filename);
		self::init_log_file(self::$cms_error_log_filename);
		$elog = ini_get('error_log');	// should be the startup
		ini_set('error_log',self::$cms_error_log_filename);
		} // log_init()

	public static function log_dump($data) {
		self::log_msg(print_r($data,true),'debug');
		} // log_dump()

	public static function log_exception($e) {
		self::log_msg($e->getMessage(), 'error');
		self::log_msg($e->getTraceAsString(), 'error');
		} // log_exception()

	protected static function get_msg_type_label($type) {
		if($type) {
			if(is_array($type)) {
				if(isset($type['type'])) {
					$label = $type['type'];
					$label = strtolower($label) . ': ';
				} // if}
				else $label = '';
				} //if
			// assume a string
			else $label = strtolower($type) . ': ';
			} // if
		else $label = '';
		return $label;
		} // get_msg_type_label()

	public static function log_error($msg, $type = 'ERROR') {
		// if(empty(self::$cms_log_filename)) return false;
		if(empty($msg)) return false;
		if (Ccms_base::is_cli()) $prefix = 'CLI: ';
		else $prefix = '';
		$prefix .= date('c: ');
		$user = Ccms_auth::get_logged_in_username();
		if(empty($user)) $user = '(default)';
		$label = self::get_msg_type_label($type);
		$log_msg = $prefix . $user . ' - ' . $label . $msg . PHP_EOL;
		return error_log($log_msg,3,self::$cms_error_log_filename);
		} // log_error()

	public static function log_debug_msg($msg, $type = false) {
		if(!Ccms_base::is_debug()) return false;
		return self::log_msg($msg, $type);
		} // log_debug_msg()

	public static function log_msg($msg, $type = false) {
		if(empty(self::$cms_log_filename)) return false;
		if(empty($msg)) return false;
		if (Ccms_base::is_cli()) $prefix = 'CLI: ';
		else $prefix = '';
		$prefix .= date('c: ');
		$user = Ccms_auth::get_logged_in_username();
		if(empty($user)) $user = '(default)';
		$label = self::get_msg_type_label($type);
		$log_msg = $prefix . $user . ' - ' . $label . $msg . PHP_EOL;
		if(self::$cms_logs_inuse) {
			try {
				self::$cms_logs_buffr[] = $log_msg;
				} // try
			catch(Error $e) {	// probably run out of memory
				// no, circular	self::addMsg($error,'debug');
				} // catch
			} // if
		else {
			self::$cms_logs_inuse = true;
			error_log($log_msg,3,self::$cms_log_filename);
			$i = 0;
			while($i < count(self::$cms_logs_buffr)) {
				if(strlen(self::$cms_logs_buffr[$i])) {
					error_log(self::$cms_logs_buffr[$i],3,self::$cms_log_filename);
					self::$cms_logs_buffr[$i] = '';
					} // if
				$i++;
				} // while
			self::$cms_logs_buffr = array();	//?? multithreading
			self::$cms_logs_inuse = false;
			} // else
		return true;
		} // log_msg()

	public static function log_info_msg($msg) {	// allows information msgs to be stored to be show in a meaning full way and print directlt if cli mode
		self::log_msg($msg,'info');
		return true;
		} // addInfoMsg()

	public static function log_ajax_request($debug = true) {	// this method is to help debug ajax ops
		if(($debug) && (!CMS_S_LOG_AJAX_DEBUG_BOOL)) return true;
		$text = PHP_EOL;
		if(!empty($_REQUEST)) {
			$text .= 'AJAX _REQUEST START = ' . PHP_EOL;
			foreach($_REQUEST as $k => &$v) {
				$text .= $k . ' => ' . (is_array($v) ? implode(', ', $v):$v) . PHP_EOL;
				} // foreach
			$text .= 'AJAX _REQUEST END.' . PHP_EOL;
			} // if
		if(!empty($_SERVER['REQUEST_URI'])) {
			$text .= '_SERVER[REQUEST_URI] = ' . $_SERVER['REQUEST_URI'] . PHP_EOL;
			} // if
		return self::log_msg(PHP_EOL . 'AJAX RESQUEST START::: ' . PHP_EOL . $text . PHP_EOL . ':::AJAX REQUEST END' . PHP_EOL, 'debug');
		} // log_ajax_request()

	public static function log_api_request($debug = true) {	// this method is to help debug ajax ops
		if(($debug) && (!CMS_S_LOG_API_DEBUG_BOOL)) return true;
		$text = PHP_EOL;
		if(!empty($_REQUEST)) {
			$text .= 'API _REQUEST START = ' . PHP_EOL;
			foreach($_REQUEST as $k => &$v) {
				$text .= $k . ' => ' . (is_array($v) ? implode(', ', $v):$v) . PHP_EOL;
				} // foreach
			$text .= 'API _REQUEST END.' . PHP_EOL;
			} // if
		if(!empty($_SERVER['REQUEST_URI'])) {
			$text .= '_SERVER[REQUEST_URI] = ' . $_SERVER['REQUEST_URI'] . PHP_EOL;
			} // if
		return self::log_msg(PHP_EOL . 'API RESQUEST START::: ' . PHP_EOL . $text . PHP_EOL . ':::AJAX REQUEST END' . PHP_EOL, 'debug');
		} // log_api_request()

	public static function log_ajax_response(&$text, $debug = true) {	// this method is to help debug ajax ops
		if(($debug) && (!CMS_S_LOG_AJAX_DEBUG_BOOL)) return true;
		return self::log_msg(PHP_EOL . 'AJAX RESPONSE START::: ' . PHP_EOL . $text . PHP_EOL . ':::AJAX RESPONSE END' . PHP_EOL, 'debug');
		} // log_ajax_response()

	public static function logSessEvent($msg) {
		self::log_msg('Session: ' . $msg,'error');
		return true;
		} // logSessEvent()

// dynamic methods

} // Ccms_logger

