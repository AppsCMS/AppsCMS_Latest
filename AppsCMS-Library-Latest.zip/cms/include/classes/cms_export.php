<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_export.php 3269 2023-03-13 09:23:14Z robert0609 $
 */

/*
 *  * Description of cms_export
 *	* static class to provide text export in user data
 *
 * @author robert0609
 */
class Ccms_export extends Ccms_general {

	const delim = "\t";

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	protected static function &exported_tables($table = false) {
		static $not_export = '';	// return ref
		static $exported_tables = array(
			'cms_users' => array (
				'index' => 'cms_user_id',
				'name' => 'Users',
				'unique_idxs' => array('cms_user_name'),	// the unique index columns
				'insert' => true,
				'imported_columns' => array(
					'cms_user_id',
					'cms_user_name',
					'cms_user_admin',
					// 'cms_user_password_md5',
					'cms_user_group_ids',
					'cms_user_enabled',
					'cms_user_auth_ldap',
					'cms_user_auth_pam',
					'cms_user_api',
					'cms_user_email',
					'cms_user_email_confirmed',
					'cms_user_mobile',
					'cms_user_mobile_confirmed',
					),
				'exported_columns' => array(
					'cms_user_id',
					'cms_user_name',
					// 'cms_user_password_md5',
					'cms_user_admin',
					'cms_user_group_ids',
					'cms_user_enabled',
					'cms_user_auth_ldap',
					'cms_user_auth_pam',
					'cms_user_api',
					'cms_user_email',
					'cms_user_email_confirmed',
					'cms_user_mobile',
					'cms_user_mobile_confirmed',
					'cms_user_added',
					'cms_user_updated',
					),
				),
			'cms_groups' => array (
				'index' => 'cms_group_id',
				'name' => 'Groups',
				'unique_idxs' => array('cms_group_name'),	// the unique index columns
				'insert' => true,
				'imported_columns' => array(
					'cms_group_name',
					'cms_group_description',
					'cms_group_admin',
					'cms_group_user_ids',
					'cms_group_admin_ids',
					'cms_group_order',
					'cms_group_enabled',
					),
				'exported_columns' => array(
					'cms_group_id',
					'cms_group_name',
					'cms_group_description',
					'cms_group_admin',
					'cms_group_user_ids',
					'cms_group_admin_ids',
					'cms_group_order',
					'cms_group_enabled',
					'cms_group_added',
					'cms_group_updated',
					),
				),
			'lm_sections' => array (
				'index' => 'lm_section_id',
				'name' => 'Sections',
				'unique_idxs' => array('lm_section_name'),	// the unique index columns
				'insert' => true,
				'imported_columns' => array(
					'lm_section_name',
					'lm_section_description',
					'lm_section_order',
					'lm_section_parent_id',
					'lm_section_enabled',
					'lm_section_columns',
					'lm_section_title',
					'lm_section_group_ids',
					),
				'exported_columns' => array(
					'lm_section_id',
					'lm_section_parent_id',
					'lm_section_name',
					'lm_section_description',
					'lm_section_order',
					'lm_section_enabled',
					'lm_section_group_ids',
					'lm_section_title',
					'lm_section_image_url',
					'lm_section_icon_url',
					'lm_section_columns',
					'lm_section_added',
					'lm_section_updated',
					),
				),
			'lm_links' => array (
				'index' => 'lm_link_id',	// if not in the exported_columns, it will appear first
				'name' => 'Links',
				'unique_idxs' => array('lm_link_name'),	// the unique index columns
				'insert' => true,
				'imported_columns' => array(
					'lm_link_name',
					'lm_link_description',
					'lm_link_order',
					'lm_link_enabled',
					'lm_link_title',
					'lm_link_section_id',
					'lm_link_image_url',
					'lm_link_icon_url',
					'lm_link_url',
					'lm_link_new_page',
					'lm_link_ssl',
					'lm_link_add_name2url',
					),
				'exported_columns' => array(
					'lm_section_id',	// helper / sanity
					'lm_section_name',	// helper / sanity
					'lm_link_section_id',
					'lm_link_id',
					'lm_link_name',
					'lm_link_description',
					'lm_link_order',
					'lm_link_enabled',
					'lm_link_title',
					'lm_link_image_url',
					'lm_link_icon_url',
					'lm_link_url',
					'lm_link_new_page',
					'lm_link_ssl',
					'lm_link_add_name2url',
					'lm_link_added',
					'lm_link_updated',
					),
				'extras' => array(	// from other tables
					'notes' => array(
						'The lm_section_id and lm_section_name columns are included for information to show the section information.',
						'The import only follows the lm_link_section_id column to link links to a section.',
						),
					'table' => 'lm_sections as ls, lm_links as lk',
					'where' => 'ls.lm_section_id = lk.lm_link_section_id OR lk.lm_link_section_id = 0',	// to get linked section names
					// put unused section into the export
					'sql' => 'SELECT lm_section_added, lm_section_updated, lm_section_id, lm_section_name FROM lm_sections' .	// helper / sanity
						' WHERE NOT EXISTS (select * FROM lm_links WHERE lm_sections.lm_section_id = lm_links.lm_link_section_id);', 	// to get unlink section names
						// note: the column orders type match
					'comment' => 'Unused sections (not linked by lm_section_id = lm_link_section_id)',
					),
				),
			'cms_bodies' => array (
				'index' => 'cms_body_id',
				'name' => 'Bodies',
				'unique_idxs' => array('cms_body_name','cms_body_app_key'),	// the unique index columns
				'insert' => true,
				'imported_columns' => array(
					'cms_body_group_ids',
					'cms_body_manager_group_ids',
					'cms_body_order',
					'cms_body_default',
					'cms_body_nomenu',
					'cms_body_enabled',
					'cms_body_file',
					'cms_body_version',
					'cms_body_name',
					'cms_body_app_key',
					'cms_body_title',
					'cms_body_H1',
					'cms_body_H1_title',
					'cms_body_purpose',
					'cms_body_info1',
					'cms_body_info2',
					'cms_body_comments',
					'cms_body_package_excludes',
					'cms_body_meta_description',
					'cms_body_meta_keywords',
					'cms_body_copyright',
					'cms_body_cached',
					'cms_body_debug_only',
					'cms_body_ssl',
					'cms_body_full_view',
					'cms_body_iframe_view',
					'cms_body_manual_url',
					'cms_body_icon_url',
					'cms_body_image_url',
					'cms_body_terms_url',
					'cms_body_terms_upfirst',
					'cms_body_acknowledgment_url',
					'cms_body_licence_url',
					'cms_body_release_notes_url',
					'cms_body_readme_url',
					'cms_body_debug_only',
					'cms_body_default_msgs',
					'cms_body_login_page',
					'cms_body_login_required',
					'cms_body_description',
					),
				'exported_columns' => array(
					'cms_body_id',
					'cms_body_acknowledgment_url',
					'cms_body_app_key',
					'cms_body_cached',
					'cms_body_comments',
					'cms_body_crontab_enable',
					'cms_body_crontab_job',
					'cms_body_crontab_time',
					'cms_body_debug_only',
					'cms_body_default',
					'cms_body_default_msgs',
					'cms_body_description',
					'cms_body_dir',
					'cms_body_enabled',
					'cms_body_file',
					'cms_body_full_view',
					'cms_body_group_ids',
					'cms_body_H1',
					'cms_body_H1_title',
					'cms_body_icon_url',
					'cms_body_iframe_view',
					'cms_body_image_url',
					'cms_body_info1',
					'cms_body_info2',
					'cms_body_installed',
					'cms_body_lang',
					'cms_body_licence_url',
					'cms_body_login_page',
					'cms_body_login_required',
					'cms_body_manager_group_ids',
					'cms_body_manual_url',
					'cms_body_meta_description',
					'cms_body_meta_keywords',
					'cms_body_copyright',
					'cms_body_name',
					'cms_body_nomenu',
					'cms_body_order',
					'cms_body_package_excludes',
					'cms_body_purpose',
					'cms_body_readme_url',
					'cms_body_release_notes_url',
					'cms_body_ssl',
					'cms_body_terms_upfirst',
					'cms_body_terms_url',
					'cms_body_title',
					'cms_body_type',
					'cms_body_version',
					'cms_body_virtual_name',
					'cms_body_added',
					'cms_body_updated',
					),
				),
			'cms_tools' => array(	// table name
				'index' => 'cms_tool_id',
				'name' => 'Tools',
				'unique_idxs' => array('cms_tools_id'),	// the unique index columns
				'insert' => false,	// fixed by code and version
				'imported_columns' => array(
					'cms_tool_name',
					'cms_tool_group_ids',	// display group ids
					'cms_tool_order',	// sort order
					'cms_tool_enabled',
					'cms_tool_url',
					'cms_tool_description',
					'cms_tool_title',
					'cms_tool_copyright',
					'cms_tool_new_page',
					'cms_tool_ssl',
					'cms_tool_login_required',
					'cms_tool_add_name2url',
					'cms_tool_include',
					'cms_tool_comments',
					'cms_tool_package_excludes',
					'cms_tool_icon_url',
					'cms_tool_image_url',
					'cms_tool_terms_url',
					'cms_tool_terms_upfirst',
					'cms_tool_acknowledgment_url',
					'cms_tool_release_notes_url',
					'cms_tool_readme_url',
					'cms_tool_debug_only',
					),
				'exported_columns' => array(
					'cms_tool_id',
					'cms_tool_name',
					'cms_tool_group_ids',	// display group ids
					'cms_tool_order',	// sort order
					'cms_tool_enabled',
					'cms_tool_url',
					'cms_tool_description',
					'cms_tool_title',
					'cms_tool_copyright',
					'cms_tool_new_page',
					'cms_tool_ssl',
					'cms_tool_login_required',
					'cms_tool_add_name2url',
					'cms_tool_include',
					'cms_tool_comments',
					'cms_tool_package_excludes',
					'cms_tool_icon_url',
					'cms_tool_image_url',
					'cms_tool_terms_url',
					'cms_tool_terms_upfirst',
					'cms_tool_acknowledgment_url',
					'cms_tool_licence_url',
					'cms_tool_release_notes_url',
					'cms_tool_readme_url',
					'cms_tool_added',	// date and time the row was added
					'cms_tool_updated',	// date and time the row was updated
					),
				),
			'cms_configs' => array (
				'index' => 'cms_config_id',
				'name' => 'Configs',
				'unique_idxs' => array('cms_config_id','cms_config_key'),	// the unique index columns
				'insert' => false,	// fixed by code and version
				'imported_columns' => array(
					'cms_config_value',
					),
				'exported_columns' => array(
					'cms_config_id',
					'cms_config_key',
					'cms_config_value',
					'cms_config_allowed_values',
					'cms_config_name',
					'cms_config_description',
					'cms_config_show_func',
					'cms_config_input_func',
					'cms_config_save_func',
					'cms_config_added',
					'cms_config_updated',
					),
				),
			);
		if(empty($table)) return $exported_tables;
		if(isset($exported_tables[$table])) {
			if(!isset($exported_tables[$table]['exported_columns'])) // use all columns
				$exported_tables[$table]['exported_columns'] = self::$cDBcms->get_columns_list($table,false);
			$exported_tables[$table]['columns_types'] = self::$cDBcms->get_columns_list($table,true,true);
			return $exported_tables[$table];
			} // if
		return $not_export;
		} // exported_tables()

	protected static function make_table_export_commentary(&$table,&$exp,$format = 'csv') {
		$dt = date('Y/m/d H:i:s');
		$comments = array();
		$comments[] = '# NOTES: for ' . $table . ' export.';
		$comments[] = '# First line/row is the column headings / column names.';
		$comments[] = '# Lines beginning with hash as the first character are ignored and are treated as comments.';
		$comments[] = '# Export of ' . $table . ' table on ' . $dt . ' from ' . CMS_WWW_URL;
		$comments[] = '# Allowed: Can ' . ($exp['insert'] ? ' insert and update':'update') . ' imported columns.';
		$comments[] = '# Unique/index columns;- ' . implode(', ',$exp['unique_idxs']) . ' (each column value must be unique).';
		if($format == 'csv') $comments[] = '# Imported columns;- ' . implode(', ',$exp['imported_columns']) . '.';
		foreach($exp['columns_types'] as $c => $v) {
			if(!in_array($c,$exp['exported_columns'])) continue;	// should never happen ??
			$comments[] = '# Column: ' . $c . ' is of type: ' . $v;
			} // foreach
		if(!empty($exp['extras']['notes'])) {
			$cnt = 1;
			$notes = &$exp['extras']['notes'];
			foreach ($notes as $n) $comments[] = '# Note ' . $cnt++ . ': ' . $n;
			} // if
		$comments[] = '# refer to manual for more information.';
		if($format == 'csv') return '"' . implode('"' . "\r\n" . '"',$comments) . '"' . "\r\n"; // implode and wrap in enclosures
		return $comments;
		} // make_table_export_commentary()

	public static function export_table($table,$show = false) {
		if(!CMS_C_ALLOW_CSV_EXPORT_IMPORT) return false;
		if(!$exped = self::exported_tables($table)) return false;

		$csv_file = VAR_FS_EXPORT_DIR . $table . '.csv';
		$commentary = self::make_table_export_commentary($table, $exped);

		if((!$fh = self::file_safe_wopen($csv_file,'w')) ||
			(!fputcsv($fh,$exped['exported_columns'])) ||
			(!fwrite($fh,$commentary))) {
			if($fh) self::file_safe_wclose($fh,$csv_file);
			self:addMsg('Failed to export "' . $table . '" headers to "' . $csv_file . '".');
			return false;
			} // if
		$sql_row_query = "SELECT " . PHP_EOL .
			(!in_array($exped['index'],$exped['exported_columns']) ? "\t" . $exped['index'] . ", " . PHP_EOL:'') .
			implode(',' . PHP_EOL . "\t",$exped['exported_columns']) . PHP_EOL .
			" FROM  " . (!empty($exped['extras']['table']) ? $exped['extras']['table']:$table) .
			(!empty($exped['extras']['where']) ? ' WHERE ' . $exped['extras']['where']:'') . PHP_EOL .
			" ORDER BY " . $exped['index'] . ";";
		if($result_row = self::$cDBcms->query_unbuffered($sql_row_query)) {
			while($row = self::$cDBcms->fetch_array_unbuffered($result_row)) {
				// make the null columns good, don't mangled the CSV
				$out_row = [];
				foreach($exped['exported_columns'] as $k) {	// keep the same as head
					if(is_null($row[$k])) 
						$out_row[$k] = 'null';
					else $out_row[] = str_replace(array(PHP_EOL,"\r","\t"),'',$row[$k]);	// remover CSV upsets
					} // foreach
				fputcsv($fh,$out_row);
				} // while
			} // if
		if(!empty($exped['extras']['sql'])) {
			if(!empty($exped['extras']['comment'])) fwrite($fh,'# ' . $exped['extras']['comment'] . "\r\n");
			$sql_row_query = $exped['extras']['sql'];
			if($result_row = self::$cDBcms->query_unbuffered($sql_row_query)) {
				while($row = self::$cDBcms->fetch_array_unbuffered($result_row)) {
					$row = str_replace(array(PHP_EOL,"\r","\t"),'',$row);	// remover CSV upsets
					fputcsv($fh,$row);
					} // while
				} // if
			} // if
		self::file_safe_wclose($fh,$csv_file);
		if($show) self::addMsg('Exported table "' . $table . '" to "' . $csv_file . '",','success');
		return true;
		} // export_table()

	protected static function search_row_keywords(&$row,$keywords_str) {
		if(empty($keywords_str)) return true;	// no filter
		$keywords = explode(' ', strtolower($keywords_str));

		// make a searchable string subject
		$subject = '';
		foreach($row as $n => &$v) {
			if(!empty($subject)) $subject .= ' - ';	// joiner/delim
			$sub = $v;
			if($vg = self::chk_unserialize($sub,array())) { // check if serialized
				$sub = self::serialize_array2string($vg);
				} // if
			$subject .= $sub;
			} // foreach
		$d = strtolower($subject);
		foreach($keywords as $w) {
			if(strpos($d,$w) == false) {
				return false;
				} // if
			} // foreach
		return true;	// use it
		} // search_row_keywords()

	public static function export_api_table($table,$format,$keywords) {
		if(!CMS_C_ALLOW_CSV_EXPORT_IMPORT) return false;
		if(!$exped = self::exported_tables($table)) return false;

		if($format == 'csv') {
			$commentary = self::make_table_export_commentary($table, $exped, $format);
			if(!empty($keywords)) $commentary .= PHP_EOL . '"# Using keywords: ' . $keywords . '"' . PHP_EOL;
			$text = array();
			$text[] = implode("\t",$exped['exported_columns']);	// column headings
			$text[] = $commentary;
			} // if
		else {	// json
			$json = array(
				'cms' => CMS_PROJECT_SHORTNAME,
				'version' => CMS_PROJECT_VERSION,
				'uri' => self::get_base_url(),
				'operation' => 'Configuration table export.',
				'table' => $table,
				'export_columns' => $exped['exported_columns'],	// column headings output
				'import_columns' => $exped['imported_columns'],	// column headings input
				'comments' => self::make_table_export_commentary($table, $exped, $format),
				'keywords' => $keywords,
				'data' => array(),
				'extras' => array(),
				);
			} // else

		$sql_row_query = "SELECT " .
			(!in_array($exped['index'],$exped['exported_columns']) ? $exped['index'] . ", ":'') .
			implode(',',$exped['exported_columns']) .
			" FROM  " . (!empty($exped['extras']['table']) ? $exped['extras']['table']:$table) .
			(!empty($exped['extras']['where']) ? ' WHERE ' . $exped['extras']['where']:'') .
			" ORDER BY " . $exped['index'] . ";";
		if($result_row = self::$cDBcms->query_unbuffered($sql_row_query)) {
			while($row = self::$cDBcms->fetch_array_unbuffered($result_row)) {
				if(!self::search_row_keywords($row, $keywords)) continue;
				if($format == 'csv') {
					$row = str_replace(array(PHP_EOL,"\r","\t"),'',$row);	// remove CSV upsets
					$text[] = implode("\t",$row);
					} // if
				else {	// json
					$id = $row[($exped['index'])];
					$json['data'][$id] = $row;
					} // else
				} // while
			} // if
		if(!empty($exped['extras']['sql'])) {
			if(!empty($exped['extras']['comment'])) fwrite($fh,'# ' . $exped['extras']['comment'] . "\r\n");
			$sql_row_query = $exped['extras']['sql'];
			if($result_row = self::$cDBcms->query_unbuffered($sql_row_query)) {
				while($row = self::$cDBcms->fetch_array_unbuffered($result_row)) {
					if(!self::search_row_keywords($row, $keywords)) continue;
					if($format == 'csv') {
						$row = str_replace(array(PHP_EOL,"\r","\t"),'',$row);	// remover CSV upsets
						$text[] = implode("\t",$row);
						} // if
					else {	// json
						$json['extras'][] = $row;
						} // else
					} // while
				} // if
			} // if
		if($format == 'csv') return implode(PHP_EOL,$text) . PHP_EOL;
		return $json;
		} // export_api_table()

	protected static function get_txt_file($table) {
		$csv_file = VAR_FS_EXPORT_DIR . $table . '.csv';
		$name = $table . '_upload_csv_new';
		if(self::save_uploaded_file($csv_file,$name)) return $csv_file;
		return false;
		} // get_txt_file()

	public static function import_table($table) {
		if(!CMS_C_ALLOW_CSV_EXPORT_IMPORT) return true;
		if(!$exped = self::exported_tables($table)) return false;
		Ccms_content_cache::reset_caches(false);
		self::$cDBcms->backupDatabase();

		$csv_file = self::get_txt_file($table);
		if(empty($csv_file)) {
			Ccms_msgs::addMsg('Failed to upload csv file for table: "' . $table . '".');
			return false;
			} // if
		if((!is_readable($csv_file)) ||
			(!$fh = @fopen($csv_file,'r')) ||
			(!$head = fgetcsv($fh))) {
			if($fh) fclose($fh);
			Ccms_msgs::addMsg('Failed to read "' . $csv_file .'"');
			return false;
			} // if
//		if($head != $exped['exported_columns']) {
//			Ccms_msgs::addMsg('Header row in "' . $csv_file .'" does not match columns in table ' . $table . '.','warn');
//			// return false;
//			} // if

		$row_cnt = 0;
		while(($data = fgetcsv($fh)) !== false) {
			if(substr($data[0],0,1) == '#') continue;	// its a comment

			reset($exped['imported_columns']);

			// make values array
			$fields = array_combine($head,$data);
			if(empty($fields)) {
				self::addAdminMsg('Import data row: ' . $row_cnt . ' for ' . $table . ': is corrupted.');
				continue;
				} // if

			// make where string
			$where = '';
			if(isset($fields[($exped['index'])])) { // use the ID
				$where .= $exped['index'] . " = " . (int)$fields[($exped['index'])] . "";
				unset($fields[($exped['index'])]);
				} // if
			else {
				foreach($exped['unique_idxs'] as $idx) {
					if(!empty($where)) $where .= ' AND ';
					$where .= $idx . " = '" . $fields[($exped['index'])] . "'";
					unset($fields[($exped['index'])]);
					} // foreach
			} // else

			foreach($fields as $k => $v) {	// check if import allowed
				if(($k == $exped['index']) ||
					(!in_array($k, $exped['imported_columns'])))
					unset($fields[$k]);
				} // for

			// check if new or update
			$sql_query = "SELECT * FROM " . $table . " WHERE ";
			$sql_query .= $where;

			$id = self::$cDBcms->get_data_in_table($table,$exped['index'],$where);
			if((int)$id > 0) {	// update
				if(!self::$cDBcms->perform($table, $fields, 'update', $where)) {
					Ccms_msgs::addMsg('Failed to update row in table ' . $table . ' at ' . $where . '.');
					return false;
					} // if
				} // if
			else { // insert it
				if(!in_array($exped['index'],$exped['unique_idxs'])) {
					unset($fields[$exped['index']]);	// to creat the new index
					if(!self::$cDBcms->perform($table, $fields, 'insert')) {
						Ccms_msgs::addMsg('Failed to insert row in table ' . $table . ' at ' . $where . '.');
						return false;
						} // if
					} // if
				else {
					Ccms_msgs::addMsg('Failed to insert row in table ' . $table . ' due controlls.');
					return false;
					} // else
				} // else
			$row_cnt++;
			} // while
		Ccms_msgs::addMsg('Imported to: "' . $table . '", ' . $row_cnt . ' rows.','success');
		return true;
		} // import_table()

	public static function import_api_table($table,$format,&$payload) {
		if(!CMS_C_ALLOW_CSV_EXPORT_IMPORT) return true;
		if(!$exped = self::exported_tables($table)) return false;
		Ccms_content_cache::reset_caches(false);
		self::$cDBcms->backupDatabase();

		$row_cnt = 0;
		if($format == 'csv') {
			$rows = explode(PHP_EOL,$payload);
			$head = explode("\t",$rows[0]);
			for($i = 1; $i < count($rows); $i++) {
				$data = &$rows[$i];
				if(empty($data)) continue;
				if(preg_match('/^["]*#/',$data)) continue;	// its a comment
				$values = explode("\t",$data);
				if(count($head) != count($values)) continue;
				reset($exped['imported_columns']);
				// make values array
				$fields = array_combine($head,$values);
				// make where string
				$where = '';
				if(isset($fields[($exped['index'])])) { // use the ID
					$where .= $exped['index'] . " = " . (int)$fields[($exped['index'])] . "";
					unset($fields[($exped['index'])]);
					} // if
				else {
					foreach($exped['unique_idxs'] as $idx) {
						if(!empty($where)) $where .= ' AND ';
						$where .= $idx . " = '" . $fields[($exped['index'])] . "'";
						unset($fields[($exped['index'])]);
						} // foreach
				} // else

				foreach($fields as $k => $v) {	// check if import allowed
					if(($k == $exped['index']) ||
						(!in_array($k, $exped['imported_columns'])))
						unset($fields[$k]);
					} // for

				// check if new or update
				$sql_query = "SELECT * FROM " . $table . " WHERE ";
				$sql_query .= $where;

				$id = self::$cDBcms->get_data_in_table($table,$exped['index'],$where);
				if((int)$id > 0) {	// update
					if(!self::$cDBcms->perform($table, $fields, 'update', $where)) {
						Ccms_msgs::addMsg('Failed to update row in table ' . $table . ' at ' . $where . '.');
						return false;
						} // if
					} // if
				else { // insert it
					if(!in_array($exped['index'],$exped['unique_idxs'])) {
						unset($fields[$exped['index']]);	// to creat the new index
						if(!self::$cDBcms->perform($table, $fields, 'insert')) {
							Ccms_msgs::addMsg('Failed to insert row in table ' . $table . ' at ' . $where . '.');
							return false;
							} // if
						} // if
					else {
						Ccms_msgs::addMsg('Failed to insert row in table ' . $table . ' due controlls.');
						return false;
						} // else
					} // else
				$row_cnt++;
				} // for
			} // if csv
		else { // json
			if(!is_array($payload)) $payload = self::json_decode($payload,true);
			if(!isset($payload['data'])) {
				Ccms_msgs::addMsg('Cannot imported to: "' . $table . '", No Data.','err');
				return false;
				} // if
			$data = &$payload['data'];
			foreach($data as $id => $fields) {
				reset($exped['imported_columns']);
				// make where string
				$where = '';
				if(isset($fields[($exped['index'])])) { // use the ID
					$where .= $exped['index'] . " = " . (int)$fields[($exped['index'])] . "";
					unset($fields[($exped['index'])]);
					} // if
				else {
					foreach($exped['unique_idxs'] as $idx) {
						if(!empty($where)) $where .= ' AND ';
						$where .= $idx . " = '" . $fields[($exped['index'])] . "'";
						unset($fields[($exped['index'])]);
						} // foreach
				} // else

				foreach($fields as $k => $v) {	// check if import allowed
					if(($k == $exped['index']) ||
						(!in_array($k, $exped['imported_columns'])))
						unset($fields[$k]);
					} // for

				// check if new or update
				$sql_query = "SELECT * FROM " . $table . " WHERE ";
				$sql_query .= $where;

				$id = self::$cDBcms->get_data_in_table($table,$exped['index'],$where);
				if((int)$id > 0) {	// update
					if(!self::$cDBcms->perform($table, $fields, 'update', $where)) {
						Ccms_msgs::addMsg('Failed to update row in table ' . $table . ' at ' . $where . '.');
						return false;
						} // if
					} // if
				else { // insert it
					if(!in_array($exped['index'],$exped['unique_idxs'])) {
						unset($fields[$exped['index']]);	// to creat the new index
						if(!self::$cDBcms->perform($table, $fields, 'insert')) {
							Ccms_msgs::addMsg('Failed to insert row in table ' . $table . ' at ' . $where . '.');
							return false;
							} // if
						} // if
					else {
						Ccms_msgs::addMsg('Failed to insert row in table ' . $table . ' due controlls.');
						return false;
						} // else
					} // else
				$row_cnt++;
				} // foreach
			} // else
		Ccms_msgs::addMsg('Imported to: "' . $table . '", ' . $row_cnt . ' rows.','success');
		return true;
		} // import_api_table()

	protected static function get_download_url($table) {
		if(!CMS_C_ALLOW_CSV_EXPORT_IMPORT) return false;
		if(!Ccms_auth::is_cms_admin_user()) return false;
		if(!self::chkdir(VAR_FS_EXPORT_DIR)) {
			self::addMsg('Export directory "' . VAR_FS_EXPORT_DIR . '" not found.');
			return false;
			} // if
		if(!is_readable(VAR_FS_EXPORT_DIR . $table . '.csv')) {
			if(!self::export_table($table)) return false;
			} // if
		self::set_cms_sess_var(VAR_FS_EXPORT_DIR,'download_dir');
		$url = self::get_base_url(true) . 'index.php?download_file=' . $table . '.csv';
		return $url;
		} // get_download_url()

	public static function get_table_form_text($table, $left_padding_cnt = 4) {
		if(!$url = Ccms_export::get_download_url($table)) return '';
		if(!$exped = self::exported_tables($table)) return '';

		$text = array();
		$text[] = '	<div>';
		if($left_padding_cnt) {
			$padding = '	<br>';
			for($i = 0; $i < $left_padding_cnt; $i++) $padding .= '&nbsp;';
			$padding .= 'On table &quot;' . $table . '&quot;: ';
			$text[] = $padding;
			} // if
		else $text[] = '	&nbsp;&nbsp;';
		$text[] = '	<button name="export" value="export" type="button" title="Export ' . $exped['name'] . ' to CSV (exports/' . $table . '.csv)." onclick="window.open(\'' . $url . '\');">Export</button>';
		$text[] = '	&nbsp;&nbsp;';
		$text[] = '	<input type="file" accept=".csv" class="page_config" name="' . $table . '_upload_csv_new" size="40" value="' . $table .'.csv" title="Select ' . $table . '.csv file to import.">';
		$text[] = '	<button name="import" id="import_button" value="import" type="submit" title="Import ' . $exped['name'] . ' from CSV (exports/' . $table . '.csv)." onclick="return cms_enable_import();">Import</button>';
		$text[] = '	<script type="text/javascript">';
		$text[] = '	function cms_enable_import() {';
		$text[] = '		var b = document.getElementsByName("' . $table . '_upload_csv_new")[0].value;';
		$text[] = '		if(b.length < 6) {';
		$text[] = '			alert(\'Select ' . $table . '.csv import file first.\');';
		$text[] = '			return false;';
		$text[] = '			} // if;';
		$text[] = '		 return confirm(\'Import ' . $exped['name'] . ' table from csv file?\');';
		$text[] = '		} // cms_enable_import()';
		$text[] = '	</script>';
		$text[] = '	</div>';

		return implode(PHP_EOL,$text) . PHP_EOL;
		} // get_table_form_text()

	public static function get_DB_api_summary_map() {
		if(!CMS_C_ALLOW_CSV_EXPORT_IMPORT) return false;
		$exp_tabs = self::exported_tables();
		$enum = array();
		foreach($exp_tabs as $table => &$cf) {
			$enum[] = $table;
			} // foreach

		$tag_name1 = 'cmsDB';
		$api_DB_sum_map = array(
			'paths' => array(
				'/cmsDB/export/{table}/{format}' => array(
					'_role' => 'admin', // 'admin','manager','user' or 'public'
					'_func' => __CLASS__ . '::cms_export_DB_tables',	// internal function to callback
					'get' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array($tag_name1),
						'produces' => array('text/csv','application/json'),
						'description' => 'Export ' . CMS_PROJECT_SHORTNAME . ' configuration table.',
						'parameters' => array(	// API function parameters
							array(
								'name' => 'table',
								'in' => 'path',
								'description' => 'Table selection.',
								'required' => true,
								'type' => 'string',
								'enum' => $enum,
								),
							array(
								'name' => 'format',
								'in' => 'path',
								'description' => 'Format: CSV file text or JSON array.',
								'required' => true,
								'type' => 'string',
								'enum' => array(
									'csv',
									'json',
									),
								'default' => 'json',
								),
							array(
								'name' => 'keywords',
								'in' => 'query',	// not required, cannot be the path
								'description' => 'Data search keywords.',
								'required' => false,
								'type' => 'string',
								'default' => '',
								),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'403' => array('description' =>  "Export not allowed."),
							),
						),
					),
				'/cmsDB/import/{table}/{format}' => array(
					'_role' => 'admin', // 'admin','manager','user' or 'public'
					'_func' => __CLASS__ . '::cms_import_DB_tables',	// internal function to callback
					'post' => array(	// client call method (GET, PUT, POST, etc.)
						'tags' => array($tag_name1),
						'consumes' => array( 'application/json', 'text/csv',),
						'produces' => array('application/json'),
						'description' => 'Import ' . CMS_PROJECT_SHORTNAME . ' configuration table.',
						'parameters' => array(	// API function parameters
							array(
								'name' => 'table',
								'in' => 'path',
								'description' => 'Table selection.',
								'required' => true,
								'type' => 'string',
								'enum' => $enum,
								),
							array(
								'name' => 'format',
								'in' => 'path',
								'description' => 'Format: CSV or JSON.',
								'required' => true,
								'type' => 'string',
								'enum' => array(
									'csv',
									'json',
									),
								'default' => 'json',
								),
							array(
								'name' => 'data',
								'in' => 'body',
								'description' => 'Data to import, CSV file text or JSON encoded array.',
								'required' => true,
								'type' => 'string',
								),
							),
						'responses' => array(
							'200' => array('description' =>  "Success.",),
							'403' => array('description' =>  "Import not allowed."),
							),
						),
					),
				),
			'tags' => array(
				array(
					'name' => $tag_name1,
					'description' => CMS_PROJECT_SHORTNAME . ' database tables admin configuration.',
					),
				),
			);
		return $api_DB_sum_map;
		} // get_DB_api_summary_map()

	public static function cms_export_DB_tables($method,&$func_cntl,&$params) {
		if((!isset($params['table'])) || (!isset($params['format']))) return false;
		$table = $params['table'];	// must have
		$format = $params['format'];	// must have
		$keywords = (isset($params['keywords']) ? $params['keywords']:false);	// optional
		return self::export_api_table($table,$format,$keywords);
		} // cms_export_DB_tables()

	public static function cms_import_DB_tables($method,&$func_cntl,&$params) {
		if((!isset($params['table'])) ||
			(!isset($params['format'])) ||
			(!isset($params['data']))) return false;
		$table = $params['table'];	// must have
		$format = $params['format'];	// must have
		$payload = &$params['data'];
		return self::import_api_table($table,$format,$payload);
		} // cms_import_DB_tables()

} // Ccms_export
