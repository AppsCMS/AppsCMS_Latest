<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_lm_bookmarks.php 2786 2022-08-31 05:40:44Z robert0609 $
 */

/*
 *  * Description of cms_export
 *	* static class to provide bookmark import
 *
 * @author robert0609
 */
class Ccms_lm_bookmarks extends Ccms_general {

	const ORDER_INC = 10;	// default section and link order increment

	protected static $bm_cntr = false;
	protected static $bm_new_sect_cntr = false;
	protected static $bm_new_links_cntr = false;

	protected static $bm_check_urls = false;
	protected static $bm_check_timeout_ms = false;

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods
	public static function get_bookmark_form_text() {
		$sect_select = Ccms::gen_section_selection_list(
			'bm_section_id',
			0,
			'size="1" title="Select existing section to import bookmarks to."',
			false,
			true,
			false);
		$bm_check_timeout_ms = self::get_or_post('bm_check_timeout_ms');
		if(empty($bm_check_timeout_ms)) $bm_check_timeout_ms = 500;
		$text = <<< EOTBMLK
			<script type="text/javascript">
				function cms_enable_bm_import(obj) {
					var b = document.getElementsByName("lm_upload_bm_new")[0].value;
					if(b.length < 6) {
						alert('Select bookmarks json file first.');
						return false;
						} // if;
					var s = document.getElementsByName("bm_section_id")[0].selectedIndex;
					var n = document.getElementsByName("bm_section_new")[0].value;
					if((s <= 0) && (n.length < 4)) {
						alert('Select or enter parent section for bookmarks.');
						return false;
						} // if;
					if(!confirm('Import bookmarks (by selection)?')) return false;
					var bm_sp = document.getElementById('bm_ajax-loader');
					if(bm_sp) bm_sp.style.display = 'inline-block';
					return true;
					} // cms_enable_bm_import()
			</script>
			<div style="
				display: inline-block;
				border: 2px solid grey;
				border-radius: 5px;
				padding: 4px 4px;
				margin: 3px 1px;
				width: calc(100% - 15px);
				">
				<h3 class="page_config">Import Bookmarks</h3>
				<br>
				<label>&nbsp;Check URLs:
					<input type="checkbox"
						class="std"
						style="width: 20px;"
						name="bm_check_urls"
						title="Check URLs exist. This can be time consuming on large import."
						CHECKED>
				</label>
				<label>&nbsp;Bookmark URL Timeout (mS):
					<input type="number" class="std"
						name="bm_check_timeout_ms"
						title="Enter milliseconds to wait for URL, typically 250 to 3000 milliseconds."
						min="100" max="10000" step="50" style="width: 50px"
						value="{$bm_check_timeout_ms}">
				</label>
				Longer times increase the wait time for checking URLs.
				<span id="bm_ajax-loader" style="display: none;">
					&nbsp;<img alt="loading" src="cms/images/ajax-loader.gif"/>
					&nbsp;Checking Bookmarks.
				</span>
				<br>
				<label>
					<input type="file" accept=".json,.html" class="std"
						name="lm_upload_bm_new"
						style="border: 0px;  display: inline-block;"
						size="40" value=""
						title="Select bookmarks file (.json) to import.">
				</label>
				<br>
				<label>
					{$sect_select}
				&nbsp;OR&nbsp;
					<input type="text" class="std"
						name="bm_section_new"
						id="bm_section_new"
						size="40" value=""
						placeholder="New Section Name"
						title="Enter a new destination section name.">
					<button name="import_bookmarks_selected"
						id="import_bookmarks_selected"
						value="import_bookmarks_selected"
						type="submit"
						class="std"
						title="Import Links from bookmarks file)."
						onclick="return cms_enable_bm_import(this);">
						Import Bookmarks
					</button>
				</label>
			</div>
EOTBMLK;

		return $text . PHP_EOL;
		} // get_bookmark_form_text()

	private static function sanitize_bm_label($label,&$labels) {
		$label = preg_replace('/[\[\],\"\']?/','',$label);
		while(in_array($label,$labels)) {
			$label .= '_' . count($labels);
			} // while
		$labels[] = $label;
		return $label;
		} // sanitize_bm_label()

	private static function filter_firefox_bookmarks(&$children) {
		static $section_exc = array(
			'Mozilla Firefox',
			'Recent Tags',
			'Quick Searches',
			'Recently Bookmarked',
			'Get Bookmark Add-ons',
			);
		$cnt = 0;
		foreach($children as $k => $child) {
			if((empty($child['title'])) ||	// rubbish
				(((empty($child['children'])) && (empty($child['uri'])))) ||	// rubbish
				(in_array($child['title'],$section_exc)) ||
				(empty($child['type'])) ||
				($child["type"] == "text/x-moz-place-separator")) {
				$children[$k] = false;	// don't unset()
				continue;
				} // if
			$cnt++;
			} // foreach
		return $cnt;
		} // filter_firefox_bookmarks()

	private static function process_firefox_bookmarks_selections(&$children,$level,&$sect_names,&$lm_link_names) {	// recursive
		// extract firefox elements to a clean heirachical array;
		self::filter_firefox_bookmarks($children);
		$bookmarks = array('level' => $level);
		foreach($children as $child) {
			if(!$child) continue;	// filtered
			$bookmark = array( 'title' => rawurldecode(self::$cDBcms->input(rawurldecode($child['title']))), );	// firefox is stupid (double encodes things)
			if(isset($child['iconuri'])) $bookmark['iconuri'] = self::$cDBcms->input($child['iconuri']);
			if(isset($child['children'])) $bookmark['children'] = self::process_firefox_bookmarks_selections($child['children'],($level + 1),$sect_names,$lm_link_names);
			else if(isset($child['uri'])) $bookmark['uri'] = self::$cDBcms->input($child['uri']);
			else continue;
			$bookmark['title'] = self::sanitize_bm_label($bookmark['title'], $sect_names);
			$bookmarks[] = $bookmark;
			self::$bm_cntr++;
			} // foreach
		return $bookmarks;
		} // process_firefox_bookmarks_selections()

	private static function process_chrome_bookmarks_selections(&$child,$level,&$sect_names,&$lm_link_names) {	// recursive
		// extract firefox elements to a clean heirachical array;
		static $section_exc = array();
		if(!isset($child['name'])) return $bookmarks;	// rubbish
		if(in_array($child['name'],$section_exc)) return $bookmarks;
		if(isset($child['uri'])) {
			$bookmark = array(
				'uri' => self::$cDBcms->input($child['uri']),
				'title' => rawurldecode(self::$cDBcms->input($child['name'])),
				);
			return $bookmark;
			} // if
		if(isset($child['children'])) {
			$children = array();
			foreach($child['children'] as $ch) {
				$children[] = self::process_chrome_bookmarks_selections($ch,($level + 1),$sect_names,$lm_link_names);
				} // foreach
			if(!empty($children)) {
				$children['level'] = $level;
				$bookmarks = array(
					'title' => rawurldecode(self::$cDBcms->input($child['name'])),
					'children' => $children,
					);
				self::$bm_cntr++;
				return $bookmarks;
				} // if
			} // if
		return array();	// what ??
		} // process_chrome_bookmarks_selections()

	private static function process_chrome_bookmarks_roots(&$children,$level,&$sect_names,&$lm_link_names) {	// recursive
		// extract firefox elements to a clean heirachical array;
		$bookmarks = array('level' => $level);
		foreach($children as $r_n => $child) {
			$child_marks = self::process_chrome_bookmarks_selections($child,($level + 1),$sect_names,$lm_link_names);
			if(empty($child_marks)) continue;
			$bookmarks[] = $child_marks;
			//self::$bm_cntr++;
			} // foreach
		return $bookmarks;
		} // process_chrome_bookmarks_roots()

	private static function extract_netscape_bm_recurse($fh,$level = 0) {	// returns bm json
		$bm_json = array(
			'children' => array(
				'level' => $level,
				),
			);
		while(!feof($fh)) {
			$line = trim(fgets($fh));
			if($line === false) break;
			if(empty($line)) continue;
			file_put_contents (VAR_FS_TEMP_DIR . 'bm_check.html', str_repeat("\t",$level) . $line . PHP_EOL, FILE_APPEND);	// test
			if(preg_match('/<DL><p>/i',$line)) {	// section boundary
				// <DL><p>
				$bm_json['children'][] = self::extract_netscape_bm_recurse($fh, $level + 1);
				} // if
			else if(preg_match('/<\/DL><p>/i',$line)) {	// section end
				// </DL><p>
				return $bm_json;
				} // else if
			else if(preg_match('/<DT><H[1234]\s/i',$line)) {	// section name
				// <DT><H3 ADD_DATE="1599702213" LAST_MODIFIED="1599702213">BW Quick Links</H3>
				$bm_json['title'] = html_entity_decode(preg_replace('/^.*>([^"]+?)<.*$/i','\1',$line));
				} // if
			else {
				// $bm_json[] = $line;	// test
				$bm_json['children'][] = array(
					'uri' => preg_replace('/^.*><A[\s]+HREF="(.+?)"[\s]+.*$/i','\1',$line),
					'title' => html_entity_decode(preg_replace('/^.*>([^"]+?)<\/A>.*$/i','\1',$line)),
					'img_data' => (preg_match('/ICON="/i',$line) ? preg_replace('/^.*ICON="(data:image\/[\w]+;base64,[-A-Za-z0-9+\/=]+?)".*$/i','\1',$line):''),
					);
				} // else
			} // while
		return $bm_json;	// should not get here
		} // extract_netscape_bm_recurse()

	protected static function import_netscape_bm($bm_file) {	// returns bm json
		if(!preg_match('/\.html$/i',$bm_file)) return false;	// not a netscape bm file
		$bm_json = false;
		if(!$fh = @fopen($bm_file,'r')) return false;
		$line = fgets($fh);
		if(preg_match('/DOCTYPE[\s]+NETSCAPE-Bookmark-file-1/i',$line)) {	// check DOCTYPE
			$bm_json = array();
			$bm_json['level'] = 0;
			while(!feof($fh)) {
				$line = trim(fgets($fh));
				if($line === false) break;
				if(empty($line)) continue;
				file_put_contents (VAR_FS_TEMP_DIR . 'bm_check.html', $line . PHP_EOL);	// test
				if(preg_match('/<DL><p>/i',$line)) {	// section boundary
					// <DL><p>
					$bm_json[] = self::extract_netscape_bm_recurse($fh,1);
					} // if
				} // while
			} // if
		fclose($fh);
		return $bm_json;
		} // import_netscape_bm()

	public static function import_bookmarks_selections() {

		$bm_section_id = Ccms::get_or_post('bm_section_id');
		$bm_section_new = Ccms::get_or_post('bm_section_new');
		if((!$bm_file = Ccms::save_uploaded_file(VAR_FS_TEMP_DIR, 'lm_upload_bm_new')) ||
			((empty($bm_section_id)) && (empty($bm_section_new))) ||
			(!preg_match('/\.(json|html)$/i',$bm_file))) return false;
		if(!$bm_json = self::import_netscape_bm($bm_file)) {
			if(!$bm_json = Ccms::load_json($bm_file)) return false;
			} // else

		self::$bm_check_urls = self::get_or_post_checkbox('bm_check_urls');
		self::$bm_check_timeout_ms = self::get_or_post('bm_check_timeout_ms');

		// got it
		$sect_names = array();
		$lm_link_names = array();
		$bookmarks = array();
		self::$bm_cntr = 0;
		// what is the json from ??
		if((isset($bm_json['guid'])) && ($bm_json['guid'] == 'root________') &&
			(isset($bm_json['type'])) && ($bm_json['type'] == 'text/x-moz-place-container') &&
			(isset($bm_json['children'])) && (is_array($bm_json['children']))) {	// its firefox
			if(!$bookmarks = self::process_firefox_bookmarks_selections($bm_json['children'],0,$sect_names,$lm_link_names)) {
				return false;
				} // if
			$bookmarks['type'] = 'Firefox';
			if(self::is_debug())
				self::save_json (VAR_FS_TEMP_DIR . 'firefox_bms.json', $bookmarks,false,true,true);
			} // if
		else if((isset($bm_json['checksum'])) && (isset($bm_json['roots'])) &&
			(is_array($bm_json['roots']))) {
			if(!$bookmarks = self::process_chrome_bookmarks_roots($bm_json['roots'],0,$sect_names,$lm_link_names)) {
				return false;
				} // if
			$bookmarks['type'] = 'Chrome';
			if(self::is_debug())
				self::save_json (VAR_FS_TEMP_DIR . 'chrome_bms.json', $bookmarks,false,true,true);
			} // else if
		else if(is_array($bm_json)) {	// from netscape html file
			$bookmarks = $bm_json;
			$bookmarks['type'] = 'Netscape';
			if(self::is_debug())
				self::save_json (VAR_FS_TEMP_DIR . 'netscape_bms.json', $bookmarks,false,true,true);
			$bm_file .= '.json';
			} // else if
		else {
			self::addMsg('Cannot identify bookmarks structure.');
			return false;
			} // else
		$bookmarks['file'] = basename($bm_file);
		$bookmarks['total'] = self::$bm_cntr;
		$bookmarks['check_urls'] = self::$bm_check_urls;
		$bookmarks['check_timeout_ms'] = self::$bm_check_timeout_ms;
		$bookmarks['sect_dest'] = (!empty($bm_section_new) ? $bm_section_new:'ID: ' . $bm_section_id);
		self::save_json($bm_file, $bookmarks,false, true, true);
		return $bookmarks;
		} // import_bookmarks_selections()

	private static function add_bm_section($bm_section_new,&$sect_ord_next,$bm_section_parent_id) {
		$bm_section_name = urldecode($bm_section_new);
		$bm_section_id = self::$cDBcms->get_data_in_table('lm_sections','lm_section_id','lm_section_name = \'' . $bm_section_new . '\'');
		$fields = array(
			'lm_section_name' => $bm_section_new,
			'lm_section_order' => $sect_ord_next,
			'lm_section_parent_id' => $bm_section_parent_id,
			);
		if((int)$bm_section_id <= 0) {	// new section
			if(!self::$cDBcms->perform('lm_sections', $fields, 'insert')) {
				Ccms_msgs::addMsg('Failed to insert new section "' . $bm_section_new . '".');
				return false;
				} // if
			$bm_section_id = self::$cDBcms->insert_id();
			$sect_ord_next += self::ORDER_INC;
			} // if
		else {
			if(!self::$cDBcms->perform('lm_sections', $fields, 'update','lm_section_id = ' . (int)$bm_section_id)) {
				Ccms_msgs::addMsg('Failed to update section "' . $bm_section_new . '".');
				return false;
				} // if
			} // else
		self::$bm_new_sect_cntr++;
		return $bm_section_id;
		} // add_bm_section()

	private static function add_bm_link($bm_link_new,$bm_section_id,&$link_ord_next,$bm_uri) {
		if(self::$bm_check_urls) {
			$new_url = self::chk_web_host_up($bm_uri,self::$bm_check_timeout_ms);
			if(!$new_url) return false;	// mS timeout, not available
			$bm_uri = $new_url;
			} // if
		$bm_link_new = urldecode($bm_link_new);
		$bm_link_id = self::$cDBcms->get_data_in_table('lm_links','lm_link_id',
			'lm_link_name = \'' . self::$cDBcms->input($bm_link_new) . '\' AND lm_link_section_id = ' . $bm_section_id);
		$fields = array(
			'lm_link_name' => $bm_link_new,
			'lm_link_section_id' => $bm_section_id,
			'lm_link_order' => $link_ord_next,
			'lm_link_url' => urldecode(rawurldecode($bm_uri)),
			'lm_link_new_page' => 1,
			'lm_link_add_name2url' => 0,
			);
		if((int)$bm_link_id <= 0) {	// new link
			if(!self::$cDBcms->perform('lm_links', $fields, 'insert')) {
				Ccms_msgs::addMsg('Failed to insert new link "' . $bm_link_new . '".');
				return false;
				} // if
			$bm_link_id = self::$cDBcms->insert_id();
			$link_ord_next += self::ORDER_INC;
			} // if
		else {	// update link
			if(!self::$cDBcms->perform('lm_links', $fields, 'update','lm_link_id = ' . (int)$bm_link_id)) {
				Ccms_msgs::addMsg('Failed to update link "' . $bm_link_new . '".');
				return false;
				} // if
			} // else
		self::$bm_new_links_cntr++;
		return $bm_link_id;
		} // add_bm_link()

	private static function process_bookmarks(&$children,&$sect_ord_next,&$link_ord_next, $bm_section_parent_id) {	// recursive
		if((!isset($children['cb'])) || ($children['cb'] != 'on')) return true;;	//not required
		if(!isset($children['title'])) return false;	// rubbish
		$new_sect_id = self::add_bm_section($children['title'], $sect_ord_next, $bm_section_parent_id);
		if(!$new_sect_id) return false;
		foreach($children as $k => $child) {
			//if(($k == 'cb') && ($child != 'on')) return false;	// section not required
			if(!isset($child['title'])) continue;	// rubbish
			if((!isset($child['cb'])) || ($child['cb'] != 'on')) continue;	//not required
			if(isset($child['uri'])) {
				self::add_bm_link($child['title'],$new_sect_id,$link_ord_next,$child['uri']);
				} // if
			else if(is_numeric($k)) {
				self::process_bookmarks($children[$k], $sect_ord_next, $link_ord_next, $new_sect_id);	// recurse
				} // else if
			} // foreach
		return true;
		} // process_bookmarks()

	public static function import_bookmarks() {

		if(!$bm_cb = Ccms::get_or_post('bm_cb')) return false;
		if((!$bm_section_new = Ccms::get_or_post('bm_section_new')) &&
			(!$bm_section_id = Ccms::get_or_post('bm_section_id'))) return false;
		if((empty($bm_section_id)) && (empty($bm_section_new))) return false;

		self::$bm_check_urls = self::get_or_post_checkbox('bm_check_urls');
		self::$bm_check_timeout_ms = self::get_or_post('bm_check_timeout_ms');

		// return true;	// test
		//
		// got it
		set_time_limit(7200);

		$sect_ord_max = self::$cDBcms->get_data_in_table('lm_sections','lm_section_order',false, 'ORDER BY lm_section_order DESC LIMIT 1');	// ge max val of order
		$sect_ord_next = $sect_ord_max + self::ORDER_INC;
		if(empty($bm_section_id)) {	// new section maybe
			if(!$bm_section_id = self::add_bm_section($bm_section_new,$sect_ord_next,0)) return false;
			} // if
		// have a parent section
		$link_ord_max = self::$cDBcms->get_data_in_table('lm_links','lm_link_order',false, 'ORDER BY lm_link_order DESC LIMIT 1');	// ge max val of order
		$link_ord_next = $link_ord_max + self::ORDER_INC;

		// process $bm_cb
		self::$bm_new_links_cntr = 0;
		self::$bm_new_sect_cntr = 0;

		foreach($bm_cb as $k => &$marks) {
			if((!isset($marks['cb'])) || ($marks['cb'] != 'on')) continue;	//not required
			self::process_bookmarks($marks, $sect_ord_next, $link_ord_next, $bm_section_id);
			} // foreach
		self::addMsg('Imported ' . self::$bm_new_sect_cntr . ' sections and ' . self::$bm_new_links_cntr . ' links.','success');
		return true;
		} // import_bookmarks()

} // Ccms_lm_bookmarks
