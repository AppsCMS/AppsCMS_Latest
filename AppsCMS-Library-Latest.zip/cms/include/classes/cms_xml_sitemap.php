<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_xml_sitemap.php 3092 2023-02-04 05:13:14Z robert0609 $
 */

/**
 * Description of cms_xml_sitemap
 * Class to generate xml sitemap for cms
 *
 * @author robert0609
 */

class Ccms_xml_sitemap extends Ccms_base {

	protected $db_file = '';

	protected $last_mod_date = '';	// last date the database was modified
	protected $chg_freq = 'weekly';
	protected $chg_priority = '0.6';

	protected $xml_header = '';		// xml header
	protected $xml_main_body = '';	// always included urls
	protected $xml_footer = '';		// xml footer

	protected $html_header = '';		// xml header
	protected $html_urls = array();	// sortable array
	protected $html_main_body = '';	// always included urls
	protected $html_footer = '';		// xml footer

	protected $href_base = '';

	public $xml_output = '';
	public $html_output = '';

	private $xml_sitemap_file = false;
	private $html_sitemap_file = false;

	function __construct($db_file = '') {
		if(empty($db_file)) $db_file = ETC_FS_SQLITE_DIR . CMS_S_DB_SQLITE_DATABASE;
		if(!$this->init($db_file)) return;
		self::temper_msgs('Rebuilding sitemap.','info');
		self::reset_xml_sitemap();
		$this->build_sitemaps();
		} // __construct()

	function __destruct() {
		} // __destruct()

	protected function init($db_file) {

		$this->xml_output = '';
		$this->html_output = '';

		if(!Ccms_base::get_cms_ini_value ('SITEMAPS_BOOL','CommonSettings')) {
			$this->unlink_sitemaps();
			return;
			} // if

		$this->xml_sitemap_file = CMS_SITEMAP_XML_FILE;
		$this->html_sitemap_file = CMS_SITEMAP_HTML_FILE;

		if((strlen($this->xml_sitemap_file) < 2) &&	// not required
			(strlen($this->html_sitemap_file) < 2)) {	// not required
			$this->unlink_sitemaps();
			// self::reset_xml_sitemap();
			return false;
			} // if

		if((defined('CMS_S_WEBSITE_CLOSED_BOOL')) &&
			(CMS_S_WEBSITE_CLOSED_BOOL)) {	// remove sitemap
			$this->unlink_sitemaps();
			return false;
			} // if

		if(!is_readable($db_file)) return false; // no db
		$this->db_file = $db_file;

		if((defined('CMS_C_WEB_SITE_ADDRESS')) && (strlen(CMS_C_WEB_SITE_ADDRESS) > 8)) $this->href_base = CMS_C_WEB_SITE_ADDRESS;
		else {
			if(self::is_cli()) return false;
			$this->href_base = CMS_WWW_URL;
			} // else
		if(substr($this->href_base, -1, 1) != '/') $this->href_base .= '/';
		if(!Ccms::has_dns_record($this->href_base)) {
			self::temper_msgs($this->href_base . ' has no DNS record.');
			return false;
			} // if

		$stat = stat($this->db_file);
		$this->last_mod_date = $this->getText(date('Y-m-d' , $stat['mtime']));

		$this->xml_header =
			'<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL .
			'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . PHP_EOL .
			'	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' . PHP_EOL .
			'	xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9' . PHP_EOL .
			'		http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">' . PHP_EOL;
		$this->html_header = '<div>' . PHP_EOL;

		$this->xml_main_body = $this->encode_xml_url($this->href_base . 'index.php');
		$this->html_main_body = $this->encode_html_url($this->href_base . 'index.php','<h2>Sitemap: ' . CMS_C_WEB_SITE_ADDRESS . '</h2>',CMS_C_TITLE,false,true);
		$this->html_main_body .= '	<ul>' . PHP_EOL;

		$this->xml_footer =
			'</urlset>' . PHP_EOL;
		$this->html_footer = '	</ul>' . PHP_EOL . '</div>' . PHP_EOL;

		return true;
		} // init()

	protected static function temper_msgs($msg,$type = false) {	// reduce the vebosity of msgs
		if(self::get_cms_action() == 'update_sitemap') {	// on screen map
			self::log_msg($msg, $type);
			} // if
		else {
			self::addMsg($msg,$type);
			} // else
		} // temper_msgs()

	private function unlink_sitemaps() {
		$xml_file = DOCROOT_FS_BASE_DIR . CMS_SITEMAP_XML_FILE;
		if(is_readable($xml_file)) @unlink($xml_file);
		$html_file = DOCROOT_FS_BASE_DIR . CMS_SITEMAP_HTML_FILE;
		if(is_readable($xml_file)) @unlink($xml_file);
		} // unlink_sitemaps()

	protected function build_sitemaps() {
		$this->xml_output = $this->xml_header;
		$this->xml_output .= $this->xml_main_body;

		$this->html_output = $this->html_header;
		$this->html_output .= $this->html_main_body;

		try {
			$this->add_body_urls();
			$this->add_tools_urls();
			$this->add_links_urls();

			usort($this->html_urls, function($a,$b) {
				$an = preg_replace('/[^0-9a-zA-Z ]+/','',$a['name']);
				$bn = preg_replace('/[^0-9a-zA-Z ]+/','',$b['name']);
				return strcasecmp($an,$bn);
				});
			foreach($this->html_urls as &$u)
				$this->html_output .= $this->encode_html_url($u['uri'],$u['name'],$u['title'],$u['new_page']);
			} // try
		catch (Execption $e) {
			self::temper_msgs("Tried and failed to generate sitemap.", 'error');
			$this->xml_output = "";
			$this->html_output = "";
			} // catch

		$this->xml_output .= $this->xml_footer;
		$this->html_output .= $this->html_footer;
		if($msg = $this->save_xmlreset_xml_sitemap()) {
			self::temper_msgs($msg, 'info');
			} // if
		if($msg = $this->save_htmlreset_html_sitemap()) {
			self::temper_msgs($msg, 'info');
			} // if
		return true;
		} // build_sitemaps()
		
	protected function is_not_external_link($url) {
		// $local_server = CMS_DOMAIN;
		$ssl_url = CMS_SSL_URL;
		$www_url = CMS_WWW_URL;
		if((stripos($url,$ssl_url) !== 0) &&
			(stripos($url,$www_url) !== 0)) {
			// $url_parts = parse_url($url);
			// don't want aliased locations in sitmap			
			return false;
			} // if
		
		return true;	// ok to use in sitemap
		} // is_not_external_link()

	protected function add_link_url($link) {
		if(empty($link)) return false;
		if(!$this->is_not_external_link($link['lm_link_url'])) return false;
		if($link['lm_link_new_page']) {
			$this->add_local_url($link['lm_link_url'] . ((int)$link['lm_link_add_name2url'] ? '?name=' . urlencode($link['lm_link_name']):''),
				$link['lm_link_updated'],
				Ccms_html::get_link_icon_text($link['lm_link_name']),
				$link['lm_link_title'],
				$link['lm_link_new_page']);
			} // if
		else {
			$this->add_local_url('index.php?cms_action=link&link_id=' . (int)$link['lm_link_id'] . '&name=' . urlencode($link['lm_link_name']),
				$link['lm_link_updated'],
				Ccms_html::get_link_icon_text($link['lm_link_name']),
				$link['lm_link_title'],
				$link['lm_link_new_page']);
			} // else
		return true;
		} // add_link_url()

	protected function add_links_urls() {
		if((!isset(self::$cDBcms)) || (!is_object(self::$cDBcms))) return '';
		// get data base links
		$sql_section_query = "SELECT  lm_section_id, lm_section_name, lm_section_columns" .
			", lm_section_title,lm_section_description,lm_section_group_ids" .
			", lm_section_image_url" .
			" FROM  lm_sections" .
			" WHERE  lm_section_enabled > 0" .
			" ORDER BY  lm_section_order,lm_section_id";
		$lm_section_cnt = 0; $links_cnt = 0;
		if($result_section = self::$cDBcms->query_unbuffered($sql_section_query)) {
			while($section = self::$cDBcms->fetch_array_unbuffered($result_section)) {
				if(!$this->is_default_group_id($section['lm_section_group_ids'])) continue;
					$lm_section_cnt++;
					$sql_link_query = "SELECT" .
						" lm_link_id,lm_link_name,lm_link_title,lm_link_description" .
						", lm_link_url, lm_link_image_url, lm_link_new_page, lm_link_add_name2url" .
						", lm_link_added, lm_link_updated" .
						" FROM  lm_links" .
						" WHERE  lm_link_enabled > 0 AND  lm_link_section_id = " . (int)$section['lm_section_id'] .
						" ORDER BY  lm_link_order";

					if($result_link = self::$cDBcms->query_unbuffered($sql_link_query)) {
						while($link = self::$cDBcms->fetch_array_unbuffered($result_link)) {
							$links_cnt++;
							$this->add_link_url($link);
							} // while
						} // if
					} // while
				} // if
		return true;
		} // add_links_urls()

	protected function add_body_urls() {
		// get data base links
		if((!isset(self::$cDBcms)) || (!is_object(self::$cDBcms))) return '';
		$sql_body_query = "SELECT  cms_body_id, cms_body_name, cms_body_virtual_name, cms_body_app_key".
			", cms_body_icon_url, cms_body_image_url, cms_body_meta_keywords" .
			", cms_body_title,cms_body_meta_description,cms_body_group_ids,cms_body_manager_group_ids" .
			", cms_body_file,cms_body_manual_url, cms_body_added, cms_body_updated" .
			" FROM  cms_bodies" .
			" WHERE  cms_body_enabled > 0" .
			(self::is_debug() ? "":" AND cms_body_debug_only = 0") .
			" ORDER BY  cms_body_order ASC,cms_body_id ASC";
		$body_cnt = 0; $links_cnt = 0;
		if($result_body = self::$cDBcms->query_unbuffered($sql_body_query)) {
			while($body = self::$cDBcms->fetch_array_unbuffered($result_body)) {
				// if(!$this->is_default_group_id($body['cms_body_group_ids'])) continue;
				$body_cnt++;
				$this->add_local_url(Ccms::get_body_uri($body),
					$body['cms_body_updated'],
					Ccms_html::get_menu_icon_text($body['cms_body_id'], $body['cms_body_name']),
					$body['cms_body_title']);	// . '&cms_id=' . (int)$body['cms_body_id']);
				} // while
			} // if
		return true;
		} // add_body_urls()

	protected function add_tools_urls() {
		if((!isset(self::$cDBcms)) || (!is_object(self::$cDBcms))) return '';
		$sql_query = "SELECT  cms_tool_id, cms_tool_name, cms_tool_url" .
			", cms_tool_icon_url, cms_tool_image_url, cms_tool_title" .
			", cms_tool_new_page, cms_tool_enabled, cms_tool_group_ids" .
			", cms_tool_add_name2url, cms_tool_added, cms_tool_updated" .
			" FROM  cms_tools" .
			" WHERE  cms_tool_enabled > 0" .
			" ORDER BY  cms_tool_order ASC,cms_tool_name,cms_tool_id ASC";
		if(($result = self::$cDBcms->query($sql_query)) &&
			(self::$cDBcms->num_rows($result) > 0)) {
			$row = 0;
			// Ccms::page_start_comment(__FILE__);
			while($tool = self::$cDBcms->fetch_array($result)) {
				// if(!$this->is_default_group_id($tool['cms_tool_group_ids'])) continue;
				$this->add_local_url(Ccms_sm::get_tool_uri($tool),
						$tool['cms_tool_updated'],
						Ccms_html::get_tool_icon_text($tool['cms_tool_name']),
						$tool['cms_tool_title'],
						$tool['cms_tool_new_page']);
				} // while
			self::$cDBcms->free_result($result);
			} // if
		return true;
		} // add_tools_urls()

	protected function is_default_group_id($group_ids, $default_id = 0) {
		// if(!self::check_user_group_ids($group_ids)) return false;	// test

		if(strlen($group_ids) == 0) return false;
		$op_group_ids = explode(':',$group_ids);
		if(in_array($default_id,$op_group_ids)) return true;
		return false;
		} // is_default_group_id()

	protected function encode_xml_url($url,$datetime = '') {
		if(empty($datetime)) $date = $this->last_mod_date;
		else $date = preg_replace ('/ \d\d:\d\d:\d\d/', '', $datetime);
		if(!preg_match('/http:|https:|ftp:/', $url)) $url = ($this->href_base . $url);
		$xml =	'	<url>' . PHP_EOL .
				'		<loc>' . $this->getText($url) . '</loc>' . PHP_EOL .
				'		<lastmod>' . $date . '</lastmod>' . PHP_EOL .
				'		<changefreq>' . $this->chg_freq . '</changefreq>' . PHP_EOL .
				'		<priority>' . $this->chg_priority . '</priority>' . PHP_EOL .
				'	</url>' . PHP_EOL;
		return $xml;
		} // encode_xml_url()

	protected function encode_html_url($url,$name,$title,$new_page = false, $pln = false) {
		$pattern = addcslashes($this->href_base,':/');
		$replace = '';	//Ccms::$cms_page_info['base_ref'];
		$url = preg_replace('/^' . $pattern . '/',$replace,$url);
		$html =	'		' . (!$pln ? '<li>':'') .
					'<a href="' . $url . '"' .
					(!empty($title) ? ' title="' . $title . '"':'') .
					(!empty($new_page) ? ' target="_blank"':'') .
					'>' .
					(!empty($name) ? $name : $url) .
					'</a>' .
					(!$pln ? '</li>':'') . PHP_EOL;
		return $html;
		} // encode_html_url()

	protected function add_local_url($url,$datetime,$name,$title,$new_page = false) {
		$this->xml_output .= $this->encode_xml_url($url,$datetime);
		$this->html_urls[] = array('uri' => $url, 'name' => $name, 'title' => $title, 'new_page' => $new_page);
		} // add_local_url()

	protected function getText($text) {	// clean xml content to meet xml text standard
		$sub = '';
		$remove = array("\r\n","\n\r","\r",PHP_EOL);
		$text = str_replace($remove,$sub, $text);

		$text = htmlentities($text);	// @TODO check??? not sure about this
		// http://www.sitemaps.org/protocol.html#sitemapXMLExample says this should be done

		return $text;
		} // getText()

	protected function save_xmlreset_xml_sitemap() {
		if(empty($this->xml_sitemap_file)) return false;
		$msg ='';
		$xml_file = $this->xml_sitemap_file;
		if(empty($this->xml_output)) {
			if(is_readable($xml_file)) @unlink($xml_file);
			$msg = 'Deleted sitemap "' . $xml_file . '" due to errors.';
			return $msg;
			} // if
		$xml_http = ' (Link=<a href="' . $xml_file . '" target="_blank"' . '>' . $xml_file . '</a>)';
		if(is_readable($xml_file)) $msg = 'Updated sitemap "' . $xml_file . '"' . $xml_http;
		else $msg = 'Created sitemap "' . $xml_file . '"' . $xml_http;
		$h = self::file_safe_wopen($xml_file,'w');
		if(!$h) {
			self::log_msg('WARNING: Failed to saved sitemap in "' . basename($xml_file) . '".','warn');
			return 'Failed to save sitemap "' . $xml_file . '"';
			} // if
		fwrite($h,  $this->xml_output);
		self::file_safe_wclose($h,$xml_file);
		self::log_info_msg('Saved sitemap in "' . basename($xml_file) . '".');
		Ccms::chmod_chown($xml_file);
		return $msg;
		} // save_xmlreset_xml_sitemap()

	protected function save_htmlreset_html_sitemap() {
		if(empty($this->html_sitemap_file)) return false;
		$msg ='';
		$html_file = $this->html_sitemap_file;
		if(empty($this->html_output)) {
			if(is_readable($html_file)) @unlink($html_file);
			$msg = 'Deleted sitemap "' . $html_file . '" due to errors.';
			return $msg;
			} // if
		$html_http = '';	// ' (Link=<a href="' . $html_file . '" target="_blank"' . '>' . $html_file . '</a>)';
		if(is_readable($html_file)) $msg = 'Updated sitemap "' . $html_file . '"' . $html_http;
		else $msg = 'Created sitemap "' . $html_file . '"' . $html_http;
		$h = self::file_safe_wopen($html_file,'w');
		if(!$h) {
			self::log_msg('WARNING: Failed to saved sitemap in "' . basename($html_file) . '".','warn');
			return 'Failed to save sitemap "' . $html_file . '"';
			} // if
		fwrite($h,  $this->html_output);
		self::file_safe_wclose($h,$html_file);
		self::log_info_msg('Saved sitemap in "' . basename($html_file) . '".');
		return $msg;
		} // save_htmlreset_html_sitemap()

	public static function reset_xml_sitemap() {
		$sitemaps = array(
			CMS_SITEMAP_HTML_FILE,
			CMS_SITEMAP_XML_FILE,
			);
		foreach($sitemaps as $s) {
			$path = DOCROOT_FS_BASE_DIR . $s;
			if(is_readable($path)) {
				@unlink($path);
				self::temper_msgs('Sitemap "' . $s . '" deleted.','info');
				self::log_msg('Deleted sitemap "' . $s . '".');
				} // if
			} // foreach
		return true;
		} // reset_xml_sitemap()

	public static function get_html_sitemap_file() {
		if(!CMS_S_SITEMAPS_BOOL) return false;
		$html_sitemap_file = DOCROOT_FS_BASE_DIR . CMS_SITEMAP_HTML_FILE;
		if(file_exists($html_sitemap_file)) return $html_sitemap_file;
		return false;
		} // get_html_sitemap_file()

	public static function show_html_sitemap() {
		$html_sitemap_file = self::get_html_sitemap_file();
		if(!$html_sitemap_file) return '';
		readfile($html_sitemap_file);
		} // show_html_sitemap()

} // Ccms_xml_sitemap
