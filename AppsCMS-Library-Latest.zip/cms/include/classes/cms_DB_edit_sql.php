<?php
/*
 * Applications Management System Library Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_DB_edit_sql.php 2987 2022-11-15 01:51:39Z robert0609 $
 */

/**
 * Description of Ccms_DB_edit_sql
 *
 * Provides the sql code for Ccms_DB_edit.
 *
 * @author robert0609
 */

class Ccms_DB_edit_sql extends Ccms_DB_edit_base {

	protected $inc_free = false;
	protected $filter_in_use = false;

	const SQL_EOL = PHP_EOL;	// used instead of PHP_EOL (for testing SQL code)

	function __construct() {
		parent::__construct();
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

// static methods

// virtual methods
	protected function save_DB_form_data(&$table_details) {	// virtual
		// just a place holder for inheritance
		return false;
		} // save_DB_form_data()

	protected function preprocess_DB_form_data() {	// virtual
		// just a place holder for inheritance
		return true;
		} // preprocess_DB_form_data()

// dynamic methods
	protected function chk_export_table($table) {	// export
		$export = self::get_or_post('export');
		if((empty($export)) || ($export != $table)) return false;
		// export table to csv
		$table_details = &$this->edit_DB_info['install_scripts'][$table];
		$download_dir = VAR_FS_EXPORT_DIR;
		$download_file = $table . '_table_export-' . self::get_gm_datetime(false,true) . '.csv';
		$csv_file = $download_dir . $download_file;
		$cnt = 0;
		if($fh = self::file_safe_wopen($csv_file)) {
			$head = array();
			$sel_cols = array();
			foreach($table_details['edit']['columns'] as $h => &$v) {
				$sel_cols[] = $h;
				if(isset($v['relation'])) {
					$rel = &$v['relation'];
					if(is_array($rel['name']))
						$rel_name = $rel['name'][0];
					else
						$rel_name = $rel['name'];
					$head[] = $rel_name;
					} // if
				else
					$head[] = $h;
				} // foreach
			fputcsv($fh,$head);
			$cnt++;
			// export in table row order
			$sql = 'SELECT DISTINCT ' . implode(',',$sel_cols) . ' FROM ' . $table . ' ORDER BY ' . $table_details['edit']['row_id_name'];
			if($sql_res = $this->cEditDB->query($sql)) {
				while($row = $this->cEditDB->fetch_array_assoc($sql_res)) {
					$csv = array();
					foreach($table_details['edit']['columns'] as $col => &$v) {
						if(isset($v['relation'])) {
							$rel = &$v['relation'];
							if(is_array($rel['name']))
								$rel_name = $rel['name'][0];
							else
								$rel_name = $rel['name'];
							$csv[] = $this->cEditDB->get_data_in_table(
								$rel['table'],$rel_name, $rel['id'] . ' = ' . (int)$row[$col]);
							} // if
						else $csv[] = $row[$col];
						} // foreach
					fputcsv($fh,$csv);
					$cnt++;
					} // while
				} // if
			self::file_safe_wclose($fh,$csv_file);
			} // if
		Ccms::unset_get_or_post('export');
		if($cnt > 0) {
			self::set_cms_sess_var($download_dir,'download_dir');
			self::set_cms_sess_var($download_file,'download_file');
			// self::do_download_file();
			$url = $_SERVER['HTTP_REFERER'];
			Ccms_base::do_redirect_uri($url);
			} // if
		return false;
		} // chk_export_table()

	private function restore_import_table_error($fh,$table,$table_bak,$msg) {
		fclose($fh);
		self::addMsg($msg);
		if((!$this->cEditDB->query("DROP TABLE IF EXISTS " . $table)) ||	// drop any bad
			(!$this->cEditDB->query("RENAME TABLE " . $table_bak . " TO " . $table))) {	// put it back
			self::addMsg('Failed to restore table: ' . $table . ' after import error.');
			} // if
		} // restore_import_table_error()

	protected function chk_import_table($table) {	// import
		$import = self::get_or_post('import');
		if((empty($import)) || ($import != $table)) return false;
		// import table to csv
		Ccms::unset_get_or_post('import');
		$install_scripts = &$this->edit_DB_info['install_scripts'];
		$table_details = &$install_scripts[$table];
		if(($csv_file = self::get_csv_file($table)) &&
			($fh = fopen($csv_file,'rb')) &&
			($headings = fgetcsv($fh))) {
			$bak_suffix = date('_Ymd_His');
			if(!$this->cEditDB->query("RENAME TABLE " . $table . " TO " . $table . $bak_suffix)) {
				self::addMsg('Failed to backup table: ' . $table);
				fclose($fh);
				return false;
				} // if
			if(!$this->cEditDB->install_db_tables($table, $install_scripts,true,true)) {
				$this->cEditDB->query("RENAME TABLE " . $table . $bak_suffix . " TO " . $table);	// put it back
				self::addMsg('Failed to install clean table: ' . $table);
				fclose($fh);
				return false;
				} // if

			while(!feof($fh)) {
				$line = fgetcsv($fh);
				if((empty($line)) || (!is_array($line))) continue;
				$row = array_combine($headings, $line);
				$fields = array();	// build fields
				foreach($table_details['edit']['columns'] as $col => &$v) {
					if(isset($v['relation'])) {
						$rel = &$v['relation'];
						if(is_array($rel['name']))
							$rel_name = $rel['name'][0];
						else
							$rel_name = $rel['name'];
						$id = $this->cEditDB->get_data_in_table(
							$rel['table'],$rel['id'],
							$rel_name . ' = \'' . $row[$col] . '\'' .
							(((int)$row[$col] > 0) ? ' OR ' . $rel['id'] . ' = ' . (int)$row[$col]:'') .
							(!empty($rel['title']) ? ' OR ' . $rel['title'] . ' = \'' . $row[$col] . '\'':''));
						if((int)$id <= 0) {
							if(is_int($row[$col])) {
								$this->restore_import_table_error($fh, $table, $table . $bak_suffix,
									'Failed to match ' . $table . '.' . $col . ' to ' . $rel['table'] . '.' . $rel_name . ', Enter table ' . $rel['table'] . ' first.');
								return false;	// hmm, what to do
								} // if
							$rel_fields = array(
								$rel_name => $row[$col],
								);
							if(!$this->cEditDB->perform($rel['table'],$rel_fields)) {
								$this->restore_import_table_error($fh, $table, $table . $bak_suffix,
									'Failed to insert into ' . $rel['table'] . '.' . $rel_name);
								return false;	// hmm, what to do
								} // if
							} //if
						$fields[$col] = $id;
						} // if
					else $fields[$col] = $row[$col];
					} // foreach
				if(!$this->cEditDB->perform($table,$fields)) {
					self::addMsg('Failed to insert into ' . $table);
					return false;	// hmm, what to do
					} // if
				} // while
			self::addMsg('Imported. Backed up table "' . $table . '" to "' . $table . $bak_suffix . '".','success');
			fclose($fh);
			return true;
			} // if
		return false;
		} // chk_import_table()

	protected function get_DB_form_controls($max_rows_per_page = 0, $max_DB_select_rows = 0) {
		if(self::is_ajax()) return;
		parent::get_DB_form_controls($max_rows_per_page, $max_DB_select_rows);

		if(!$this->preprocess_DB_form_data()) return false;

		// delete first
		$table = self::get_or_post('table');
		$delete_row = self::get_or_post('delete_row');
		if((!empty($table)) && (is_numeric($delete_row)) && ((int)$delete_row >= 0)) {
			$table_details = &$this->edit_DB_info['install_scripts'][$table];
			$id_col = $table_details['edit']['row_id_name'];
			$sql = 'DELETE FROM ' . $table . ' WHERE ' . $id_col . ' = ' . (int)$delete_row;
			if(!$result = $this->cEditDB->query($sql)) {
				self::addMsg('Failed to delete row:' . $delete_row . ' from table:' . $table . '.');
				} // if
			else self::addMsg('Deleted row:' . $delete_row . ' from table:' . $table . '.','success');
			Ccms::unset_get_or_post('delete_row');
			} // if

		$this->chk_export_table($table);	// export
		$this->chk_import_table($table);	// import
		} // get_DB_form_controls()

	public function get_DB_form_data() {	// check for ajax form data
		if(!$this->preprocess_DB_form_data()) return false;
		if(($form_name = self::get_or_post('form_name')) == $this->edit_DB_info['form_name']) {
			// standard form return
			$table = self::get_or_post('table');
			$row_id = self::get_or_post('row_id');
			$form_name = self::get_or_post('form_name');
			$table_op = self::get_or_post('table_op');
			$columns = self::get_or_post('columns');
			} // if
		else {	// JS form return
			$data = self::get_or_post($this->edit_DB_info['form_name']);
			if(!$data) return false;
			if(!$this->cEditDB) {
				$msg = 'DB not initialised.';
				self::addDebugMsg($msg,'warn');
				return false;
				} // if
			$form = self::json_decode($data,true);
			$table = $form['table'];
			$row_id = $form['row_id'];
			$form_name = $form['form_name'];
			if(!isset($form['columns'])) {
				$msg = 'Missing columns in AJAX for "' . $form_name . ', ' . $table . '"';
				self::addDebugMsg($msg,'warn');
				return false;
				} // if
			$columns = $form['columns'];
			} // else
		if(self::get_or_post('submit') != 'save') return true;	// cancel button (!save)
		if(empty($table)) {
			$msg = 'Missing DB table name.';
			self::addDebugMsg($msg,'warn');
			return false;
			} // if
		$t_edit = &$this->edit_DB_info['install_scripts'][$table]['edit'];
		if((empty($columns)) || (!is_array($columns))) {
			// look for JS packed columns
			$columns = array();
			foreach($t_edit['columns'] as $n => &$t) {
				if(!isset($t['type'])) continue;
				switch($t['type']) {
				case 'checkbox':
					$columns[$n] = self::get_or_post_checkbox('columns_' . $n);
					break;
				default:
					$val = self::get_or_post('columns_' . $n);
					if($val !== false)
						$columns[$n] = $val;
					break;
					} // switch
				} // foreach
			if(count($columns) <= 0)
				return false;	// oops
			} // if
		if($row_id == self::NO_INDEX_STR) $row_id = -1;
		$fields = array();
		foreach($columns as $n => &$v) {
			if(is_numeric($n)) continue; //??
			if((isset($t_edit['columns'][$n]['save_func'])) &&
				($t_edit['columns'][$n]['save_func'])) {
				// overrides 'type' and 'relation', a 'class::method' or a 'global_function',
				// paramters are ($form,$column_name,$data,$parent_obj) returns the value from posted form
  				$func = $t_edit['columns'][$n]['save_func'];
				if(self::is_static_callable($func)) {
					$self = $this;
					$d = @call_user_func($func,$form_name,$n,$v,$self);	// returns the value from posted form
					if($d === false) return false;	// something wrong
					} // if
				else {
					self::addDebugMsg('Cannot call function "' . $func . '".');
					$d = '';
					} // else
				} // if
			else if(isset($t_edit['columns'][$n]['type'])) {
				switch($t_edit['columns'][$n]['type']) {
				case 'password':
					if(empty($v)) continue 2; // no change
					$d = md5($v);
					break;
				case 'radio':
				case 'checkbox':
					if(($v === 'on') || ($v === 1)) $d = 1;
					else $d = 0;
					break;
				case 'enum':
					if(isset($t_edit['columns'][$n]['enum'][$v]))
						$d = $t_edit['columns'][$n]['enum'][$v];
					else $d = $v;
					break;
				default:
					$d = $v;
					break;
					} // switch
				} // else if
			else {
				$d = $v;
				} // else
			$fields[$n] = $d;
			} // foreach
		if((int)$row_id > 0) {	// update
			if(!$this->cEditDB->perform($table,$fields,'update',$t_edit['row_id_name'] . ' = ' . $row_id)) {
				$msg = 'Failed to update for "' . $form_name . ', ' . $table . ',' . $row_id . '"';
				self::addDebugMsg($msg,'warn');
				return false;
				} // if
			} // if
		else {	// insert
			if(!$this->cEditDB->perform($table,$fields)) {
				$msg = 'Failed to insert for "' . $form_name . ', ' . $table . '"';
				self::addDebugMsg($msg,'warn');
				return false;
				} // if
			$row_id = $this->cEditDB->get_last_insert_id();
			} // else
		self::addMsg('Saved.','success');
		self::unset_get_or_post('table_op');
		self::unset_get_or_post('submit');
		return $row_id;
		} // get_DB_form_data()

	public function check_DB_relationships($zero_unjoined_ids = true) {	// a maintanance function
		// find all table relationships and checks they have are connected to values in the related table.
		// if $zero_unjoined_ids and the relationship is not joined it sets the ID reference to zero
		// otherwise it just prints a warning
		$install_scripts = &$this->edit_DB_info['install_scripts'];
		if((!$this->cEditDB) || (!$this->cEditDB->is_ok()) || (!$install_scripts)) {
			self::addDebugMsg('Attempt to access/edit DB before initialization.');
			return false;
			} // if
		foreach($install_scripts as $table => &$v) {
			if(!isset($v['edit'])) continue;
			$chgs = 0;
			$unjoined = 0;
			$t_edit = &$v['edit'];
			$sql_top = 'SELECT * FROM ' . $table;
			if($result_top = $this->cEditDB->query($sql_top)) {
				while($row_top = $this->cEditDB->fetch_array_assoc($result_top)) {
					foreach($t_edit['columns'] as $col_name => &$col_info) {
						if(!isset($col_info['relation'])) continue;	// no relations
						$relation = &$col_info['relation'];
						// get the this tables ID column
						$join_id = $this->cEditDB->get_data_in_table($relation['table'], $relation['id'], $relation['id'] . ' = ' . $row_top[$col_name]);
						if(!$join_id) $unjoined++;
						if($join_id === false) {	// not joined, ignore columns that are already zero.
							if($zero_unjoined_ids) { // change ID to zero so it is easy to select
								$sql_zero_it = 'UPDATE ' . $table . ' SET ' . $col_name . ' = ' . 0 . ' WHERE ' . $t_edit['row_id_name'] . ' = ' . $row_top[($t_edit['row_id_name'])];
								if($result_zero_it = $this->cEditDB->query($sql_zero_it)) {
									$chgs++;
									} // if
								else {
									self::addDebugMsg('Failed to zero unjoined relation ' . $col_name . ' in ' . $table);
									} // else
								} // if
							} // if
						} // foreach
					} // while
				} // if
			self::addDebugMsg('Table: ' . $table . ' has ' . $unjoined . ' unjoined entries.',($unjoined ? 'warn':'info'));
			if($chgs > 0) self::addDebugMsg('Table: ' . $table . ' has had ' . $chgs . ' relation IDs set to zero.','warn');
			} // foreach
		return true;
		} // check_DB_relationships()

	public function get_DB_ajax_select_options() {	// usually called from app_class::get_ajax_text()
		$table = self::get_or_post('table');
		$col_name = self::get_or_post('column_name');
		$keywords = self::get_or_post('filters');
		$selected = self::get_or_post('selected');
		if((empty($table)) || (empty($col_name))) return '';
		if(!$relation = $this->get_DB_relation_joined($this->edit_DB_info['install_scripts'][$table],$col_name)) {
			return '';	// hmm
			} // if
		$where = '';
		if(!empty($keywords)) {	// make a where
			$keys = explode(' ',$keywords);
			$where .= ' ( ';
			for($i = 0; $i < count($keys); $i++) {
				$k = $keys[$i];
				if($i > 0) $where .= ' AND ';
				if(!is_array($relation['name'])) {
					$where .= ' ' . $relation['name'] . " LIKE '%" . $k . "%'";
					} // if
				else {
					$where .= ' ( ';
					for($j = 0; $j < count($relation['name']); $j++) {
						$n = $relation['name'][$j];
						if($j > 0) $where .= ' OR ';
						$where .= ' ' . $n . " LIKE '%" . $k . "%'";
						} // foreach
					$where .= ' ) ';
					} // else
				} // foreach
			$where .= ' ) ';
			} // if
		$ops = $this->get_DB_relation_select_options_ops_ary($relation, $where,$this->edit_DB_info['max_DB_select_rows'],$selected);
		if(!$ops) return '';
		return self::json_encode($ops['rows']);
		} // get_DB_ajax_select_options()

	protected function get_DB_relation_selected_option(&$relation, $selected) {
		if(empty($selected)) return false;
		// get selected row
		$names = (is_array($relation['name']) ? $relation['name']:explode(',',$relation['name']));
		$sql = 'SELECT ' . $relation['id'] . ', ' . implode(',',$names) .
			((isset($relation['title']) && (!in_array($relation['title'],$names))) ? ', ' . $relation['title']:'') .
			' FROM ' . $relation['table'] .
			' WHERE ' . $relation['id'] . " = '" . $selected . "'";
		if(($result = $this->cEditDB->query($sql)) &&
			($r_row = $this->cEditDB->fetch_array_assoc($result))) {
			return array(	// put selected row at the top
				'id' => $r_row[($relation['id'])],
				'title' => ((isset($relation['title']) && (!empty($relation['title']))) ? ' title="' . $r_row[($relation['title'])] . '"':''),
				'name' => '** ' . $r_row[($names[0])] . '  **',
				'params' => 'selected',
				);
			} // if
		return false;
		} // get_DB_relation_selected_option()

	protected function get_DB_relation_select_options_ops_ary(&$relation, $where = '', $limit = 0, $selected = '') {

		// do the main section
		if(!$limit) $limit = $this->edit_DB_info['max_DB_select_rows'];
		if((int)$limit < 10) $limit = 10;
		$names = (is_array($relation['name']) ? $relation['name']:explode(',',$relation['name']));
		$sql = 'SELECT ' . $relation['id'] . ', ' . implode(',',$names) .
			((isset($relation['title']) && (!in_array($relation['title'],$names))) ? ', ' . $relation['title']:'') .
			' FROM ' . $relation['table'];
		if(($selected != 'show_all') && (!empty($where))) $sql .= ' WHERE ' . $where;
		$sql .= ';';
		if(!$result = $this->cEditDB->query($sql)) {
			self::addMsg('Failed to retrieve DB data for table:' . $relation['table'] . ', column:' . $col_name . '.');
			return false;
			} // if

		$cntr = 0; $at_limit = false;
		$rows_total = $this->cEditDB->get_row_cnt($result);

		$rows = array();
		$rows[] = array(
			'id' => '',	// empty is a signal to insert the selected value
			'params' => (!$selected ? '':'selected') . ' disabled hidden',
			'name' => (($rows_total > self::AJAX_SELECT_MAX_DEF) ? '-- Filter Selections --':' -- Select -- '),
			'title' => '');

		if((!empty($selected)) && ($selected != 'show_all'))	// done ajax calls otherwise $selected is empty
			$rows[] = $this->get_DB_relation_selected_option($relation, $selected);	// get selected first

		$names = (is_array($relation['name']) ? $relation['name']:explode(',',$relation['name']));

		$sql = 'SELECT ' . $relation['id'] . ', ' . implode(',',$names) .
			((isset($relation['title']) && (!in_array($relation['title'],$names))) ? ', ' . $relation['title']:'') .
			' FROM ' . $relation['table'];
		if(($selected != 'show_all') && (!empty($where))) $sql .= ' WHERE ' . $where;
		$sql .= ' ORDER BY ' . $names[0] . ' ASC';
		if($selected != 'show_all') $sql .= ' LIMIT ' . ($limit + 10);
		$sql .= ';';

		if($selected == 'show_all') $limit = $rows_total + 10;
		if($result = $this->cEditDB->query($sql)) {
			while(($r_row = $this->cEditDB->fetch_array_assoc($result)) &&
				($limit-- > 0)) {
				if((!isset($r_row[($relation['id'])])) || (empty($r_row[($relation['id'])]))) continue;
				if((!isset($r_row[($names[0])])) || (empty($r_row[($names[0])]))) continue;
				$cntr++;
				if($selected == $r_row[($relation['id'])]) continue;	// already done
				$rows[] = array(
					'id' => $r_row[($relation['id'])],
					'title' => (!empty($relation['title']) ? ' title="' . $r_row[($relation['title'])] . '"':''),
					'name' => $r_row[($names[0])],
					'params' => '',
					);
				} // while
			} // if
		if($cntr == 0) {
			$rows[] = array(
				'id' => -1,
				'title' => ' title="Decrease the filters." ',
				'params' => (!$selected ? '':'selected') . ' disabled',
				'name' => '-- (empty) --',
				);
			} // if
		else if(($r_row) && ($limit < 0)) {	// more there
			$at_limit = true;
			$rows[] = array(
				'id' => 'show_all',
				'title' => ' title="Show all options." ',
				'name' => '-- (' . ($rows_total - $cntr) . ' more) --',
				);
			} // if
		return array( 'rows' => $rows, 'rows_total' => $rows_total, 'count' => $cntr, 'at_limit' => $at_limit);
		} // get_DB_relation_select_options_ops_ary()

	protected function get_DB_relation_select($js_func,&$table_details,$col_name,$row_id,$data,&$relation,&$extras, $where = '', $limit = 0) {
		$t_edit = &$table_details['edit'];
		if((!$this->edit_DB_info['free_form']) ||
			($t_edit['columns'][$col_name]['type'] == 'show') ||
			((!empty($t_edit['columns'][$col_name]['readonly'])) && ($t_edit['columns'][$col_name]['readonly']))) {
			if(empty($data)) return '(empty)';
			if(empty($where)) $where = $relation['id'] . " = '" . $data . "'";
			$text = $this->cEditDB->get_data_in_table($relation['table'],$relation['name'],$where);
			return $text;
			} // if
		if($limit <= 0) $limit = self::AJAX_SELECT_MAX_DEF;
		if(empty($js_func)) $col_form_name = 'columns[' . $col_name . ']';
		else $col_form_name = 'columns.' . $col_name;
		if((!isset($this->rel_ops[$col_name])) || (empty($this->rel_ops[$col_name]))) {	// buffer for next row
			if((isset($this->edit_DB_info['row_editor'])) &&
				(!$this->edit_DB_info['row_editor']) &&
				(!empty($data))) {
				// has a selection use that and let the ajax calls give the variations
				if(empty($where)) $where = $relation['id'] . " = '" . $data . "'";
				else $where .= ' AND ' . $relation['id'] . " = '" . $data . "'";
				} // if
			$this->rel_ops[$col_name] = $this->get_DB_relation_select_options_ops_ary($relation, $where, $limit);
			} // if
		$ops = &$this->rel_ops[$col_name];
		$sel_id = 'select_[' . $col_name . '][' . $row_id . ']';
		$seld_row = false;
		$js_sel_ajax = 'cmsDBops.get_DB_select_options(\'' . $sel_id . '\',\'' . $this->edit_DB_info['table'] . '\',\'' . $col_name . '\',this);';
		$text = PHP_EOL;
		$text .= '<label class="row_inline">';
		if($ops['at_limit']) {
			if(empty($js_func)) $js_func = $js_sel_ajax;
//			$text .= '<span style="display: inline;">';
			$text .= '<input name="filter.' . $col_name . '" style="width: 65px;" type="text" placeholder="Filter" oninput="' . $js_sel_ajax . '">';
//			$text .= '</span>';
			$seld_row = $this->get_DB_relation_selected_option($relation, $data);	// get selected first
			} // if
//		$text .= '<span style="display: inline;">';
		if(count($ops['rows']) <= 2) { // nothing there
			if(empty($ops['rows'][1]['name'])) return '(not setup)';
			return $ops['rows'][1]['name'];
			} // if
		$text .= '<select id="' . $sel_id . '"' . (!empty($js_func) ? ' onchange="' . $js_func . '"':'') . ' name="' . $col_form_name . '"' . $extras . '>';
		foreach($ops['rows'] as $v) {
			if($v['id'] == $data) {
				if(($seld_row) && ($seld_row['id'] == $v['id'])) continue;	// it's up already'
				$text .= '<option value="' . $v['id'] . '"' . $v['title'] . ' SELECTED' . '>' . $v['name'] . '</option>';
				} // if
			else {
				$text .= '<option value="' . $v['id'] . '"' . $v['title'] . '>' . $v['name'] . '</option>';
				} // else
			if((empty($v['id'])) && ($ops['at_limit']) && ($seld_row)) { // put after the select
				$text .= '<option value="' . $seld_row['id'] . '"' . $seld_row['title'] . ' SELECTED' . '>' . $seld_row['name'] . '</option>';
				} // if
			} // while
		$text .= '</select>';
//		$text .= '</span>' . PHP_EOL;
		$text .= '</label>' . PHP_EOL;
		return $text;
		} // get_DB_relation_select()

	protected function add_DB_sql_select_set(&$set, $table, $col) {
		if((empty($table)) && (empty($col))) return false;
		$cols = (is_array($col) ? $col:explode(',',$col));
		$sel = '';
		foreach($cols as $c) {
			if(!empty($sel)) $sel .= ', ';
			$sel .= $table . '.' . $c . ' as ' . $c;
			} // foreach
		if(empty($set['select'])) $set['select'] = $sel;
		else if(stripos($set['select'],$sel) === false) {
			$set['select'] .= ', ' . $sel;
			} // if
		return true;
		} // add_DB_sql_select_set()

	protected function add_DB_sql_from_set(&$set,$table) {
		if(empty($table)) return false;
		if(empty($set['from'])) $set['from'] = $table;
		else if(stripos($set['from'],$table) === false) {
			$set['from'] .= ', ' . $table;
			} // if
		return true;
		} // add_DB_sql_from_set()

	protected function add_DB_sql_where_set(&$set,$where, $logic = 'AND') {
		if(empty($where)) return false;
		if(empty($set['where'])) $set['where'] = $where;
		else if(stripos($set['where'],$where) === false) {
			$set['where'] .= ' ' . $logic . ' ' . $where;
			} // if
		return true;
		} // add_DB_sql_where_set()

	protected function add_DB_sql_col_search_set(&$set,$table,$col_name, $relation_parent_id_col = '') {
		if(!$this->edit_DB_info['col_filters_on']) return false;
		if(!isset($this->edit_DB_info['col_filters'])) return false;
		$col_filters = &$this->edit_DB_info['col_filters'];
		if(empty($col_filters)) return false;
		if(!empty($relation_parent_id_col)) { // > 0 (not >= 0) to catch errors in DB table
			if(!isset($col_filters[$relation_parent_id_col])) return false;
			if(empty($col_filters[$relation_parent_id_col])) return false;
			$col_filter = &$col_filters[$relation_parent_id_col];
			} // if
		else {
			if(!isset($col_filters[$col_name])) return false;
			if(empty($col_filters[$col_name])) return false;
			$col_filter = &$col_filters[$col_name];
			} // else
		$col_filter_ary = explode(' ',$col_filter);
		$active = false;
		$search = '';
		$tc = $table . '.' . $col_name;
		for($i = 0; $i < count($col_filter_ary); $i++) {
			$kw = &$col_filter_ary[$i];
			if(empty($kw)) continue;
			if($i == 0) $search .= self::SQL_EOL . '    (';
			else $search .= ' AND ';
			$search .= $tc . " LIKE '%" . $kw . "%'";
			$active = true;
			} // foreach
		if($active) {
			$search .= ')';
			if(empty($set['col_filters'])) $set['col_filters'] = $search;
			else if(stripos($set['col_filters'],$search) === false) {
				$set['col_filters'] .= ' AND ' . $search;
				} // if
			} // if
		$this->filter_in_use = true;
		return true;
		} // add_DB_sql_col_search_set()

	protected function add_DB_sql_search_set(&$set,$table,$col_name,$relation_parent_id_col = -1) {
		if(empty($this->edit_DB_info['db_keywords_ary'])) return false;
		$db_keywords_ary = &$this->edit_DB_info['db_keywords_ary'];
		$active = false;
		$search = '';
		$cols = (is_array($col_name) ? $col_name:explode(',',$col_name));
		foreach($cols as $c) {
//			if(!$relation = $this->get_DB_relation_joined($this->edit_DB_info['install_scripts'][$table],$col_name)) continue;
			$tc = $table . '.' . $c;
			for($i = 0; $i < count($db_keywords_ary); $i++) {
				$kw = &$db_keywords_ary[$i];
				if(empty($kw)) continue;
				if($i == 0) {
					if(!empty($search)) $search .= ') OR (';
					else $search .= self::SQL_EOL . ' (';
					} // if
				else $search .= ' AND ';
				$search .= $tc . " LIKE '%" . $kw . "%'";
				$active = true;
				} // foreach
			} // foreach
		if($active) {
			$search .= ')';
			if(empty($set['search'])) $set['search'] = $search;
			else if(stripos($set['search'],$search) === false) {
				$set['search'] .= ' OR ' . $search;
				} // if
			} // if
		$this->filter_in_use = true;
		return true;
		} // add_DB_sql_search_set()

	protected function make_DB_select_from_where(&$table_details) {
		// generate simple cross joined sql as needed
		// this is very simple and may not fit some applications with free/unjoined releationships,
		// it is recomended to override this function and use a UNION or subquery or possibly an outer join to pick up these rows.
		$this->edit_DB_info['sql'] = array( 'select' => '', 'from' => '', 'where' => '', 'search' => '', 'col_filters' => '',);
		$this->filter_in_use = false;
		$current_table = &$this->edit_DB_info['table'];
		$this->inc_free = ((!isset($table_details['edit']['inc_free']) || ($table_details['edit']['inc_free'])) ? true:false);
		$sql = &$this->edit_DB_info['sql'];
		$sql_search = '';

		// add the row id
		$row_id_name = $table_details['edit']['row_id_name'];
		$this->add_DB_sql_select_set($sql, $current_table, $row_id_name);
		$this->add_DB_sql_from_set($sql, $current_table);

		foreach($table_details['edit']['columns'] as $ci =>&$v) {
			if(is_numeric($ci)) continue;	// extra settings
			if(($this->edit_DB_info['required_form']) &&
				((!isset($v['required'])) || (!$v['required']))) continue;
			$use_col = false;
			if($ci == $table_details['edit']['row_id_name']) {
				// the row_id_name for update
				$col = $ci; // row_id_name column
				$ft = $current_table;
				// always include
				$this->add_DB_sql_select_set($sql, $ft, $col);
				$this->add_DB_sql_from_set($sql, $ft);
				continue;
				} // if
			else {
				// if(!isset($table_details['edit']['columns'][$ci])) continue;	// not used
				$use_col = true;

				$col = $ci; // add column
				$ft = $current_table;

				if(!$relation = $this->get_DB_relation_joined($table_details,$ci)) {
					// simple column
					$this->add_DB_sql_from_set($sql, $ft);
					$this->add_DB_sql_select_set($sql, $ft, $col);
					$this->add_DB_sql_search_set($sql, $ft,$col);
					$this->add_DB_sql_col_search_set($sql, $ft, $col);
					continue;
					} // if
				else {	// relational column
					$this->add_DB_sql_from_set($sql, $ft);
					$this->add_DB_sql_select_set($sql, $ft, $col);
					$this->add_DB_sql_search_set($sql, $relation['table'], $relation['name'], $col);
					$this->add_DB_sql_col_search_set($sql, $relation['table'], $relation['name'], $col);

					$where_join = '';
					if(!$this->inc_free) {
						$this->add_DB_sql_select_set($sql, $relation['table'], $relation['name']);
						$this->add_DB_sql_from_set($sql, $relation['table']);
						$where_join = $current_table . '.' . $ci . ' = ' . $relation['table'] . '.' . $relation['id'];
						} // if
					else if($this->filter_in_use) {
						$this->add_DB_sql_select_set($sql, $relation['table'], $relation['name']);
						$this->add_DB_sql_from_set($sql, $relation['table']);
						$inc_free = self::get_or_post_checkbox('include_free');
						if($inc_free) {
							$where_join = ' ( ' .
								$current_table . '.' . $ci . ' = ' . $relation['table'] . '.' . $relation['id'] .
								' OR ' .
								$current_table . '.' . $ci . ' = ' . 0 .
//								' OR ' .
//								' ( NOT EXISTS ( SELECT NULL FROM ' . $relation['table'] . ' WHERE ' . $current_table . '.' . $ci . ' = ' . $relation['table'] . '.' . $relation['id'] . ' ) ) ' .
//								' OR ' .
//								$current_table . '.' . $ci . ' IS NULL ' .
//								' OR ' .
//								$relation['table'] . '.' . $relation['id'] . ' IS NULL ' .
								' ) ';
							} // if
						else {
							$where_join = $current_table . '.' . $ci . ' = ' . $relation['table'] . '.' . $relation['id'];
							} // else
						} // else

					$this->add_DB_sql_where_set($sql, $where_join);

					} // else
				} // else
			} // foreach
		$this->add_DB_sql_where_set($sql, $sql_search);

		$virt_where = $this->add_DB_sql_virt_where($current_table,$table_details,$sql);
		if(!empty($virt_where)) $this->add_DB_sql_where_set($sql, $virt_where);

		$sql_str = 'SELECT DISTINCT ' . (!empty($sql['select']) ? $sql['select']:'*') .
			self::SQL_EOL . ' FROM ' . (!empty($sql['from']) ? $sql['from']:$current_table);
		if(!empty($sql['where'])) {
			$sql_str .= self::SQL_EOL . ' WHERE ' . $sql['where'];
			if(!empty($sql['search'])) $sql_str .= self::SQL_EOL . ' AND (' . $sql['search'] . self::SQL_EOL . ')';
			} // if
		else if(!empty($sql['search'])) $sql_str .= self::SQL_EOL . ' WHERE (' . $sql['search'] . self::SQL_EOL . ')';
		if(!empty($sql['col_filters'])) {
			if(empty($sql_str)) $sql_str .= self::SQL_EOL . ' WHERE ' . $sql['col_filters'];
			else $sql_str .= self::SQL_EOL . ' AND ' . $sql['col_filters'];
			} // if

		if(($this->inc_free) ) {	// && (!$this->filter_in_use)) {
			$sql_str .= self::SQL_EOL . ' GROUP BY ' . $current_table . '.' .$row_id_name;
			} // if

		return $sql_str;
		} // make_DB_select_from_where()

	protected function get_DB_order_by(&$table_details) {
		$edit = &$this->edit_DB_info;
		$text = '';
		if(($edit['sort_col']) && ($edit['sort_dir'])) {	// @TODO a bit checking
			if(((!$this->inc_free) || ($this->filter_in_use)) &&
				($relation = $this->get_DB_relation_joined($table_details,$edit['sort_col']))) {
				// a joined relational column
				$rel_table = $relation['table'];
				$rel_name = $relation['name'];
				$text .= ' ORDER BY ' . $rel_table . '.' . (!is_array($rel_name) ? $rel_name:$rel_name[0]) . ' ' . $edit['sort_dir'];
				} // if
			else {	// a non relational column
				$text .= ' ORDER BY ' . $edit['sort_col'] . ' ' . $edit['sort_dir'];
				} // else
			} // if
		else {
			if((isset($table_details['edit']['order_by'])) &&
				(!empty($table_details['edit']['order_by']))) {
				$text .= ' ORDER BY ' . $table_details['edit']['order_by'];
				} // if
			} // else
		if(empty($text)) return '';
		return PHP_EOL . $text;
		} // get_DB_order_by()

	protected function get_DB_page_limits() {
		$edit = &$this->edit_DB_info;
		// NOTE: value are base ref 0 (not 1)
		if(empty($edit['page_size']))
			$edit['page_size'] = self::ABS_MAX_ROWS;
		if(empty($edit['page_idx'])) $edit['page_idx'] = 0;
		if(empty($edit['row_cnt'])) $edit['row_cnt'] = self::PAGE_SIZE_MIN;	// from a mariadb fill cache bug 
		$edit['page_max'] = (int)($edit['row_cnt'] / $edit['page_size']);
		if((int)($edit['page_max'] * $edit['page_size']) < (int)$edit['row_cnt'])
			$edit['page_max']++;	// dont forget the last part of a page
		if($edit['page_max'] < 1) return '';
		if($edit['page_idx'] >= $edit['page_max'])
			$edit['page_idx'] = (int)$edit['page_max'] - 1;
		switch($edit['table_op']) {
		case 'prev':
			if(((int)$edit['page_idx'] - 0) > 0)
				$edit['page_idx']--;
			$edit['table_op'] = 'prev_done';
			break;
		case 'next':
			if(((int)$edit['page_idx'] - 0) < (int)$edit['page_max'])
				$edit['page_idx']++;
			$edit['table_op'] = 'next_done';
			break;
		default:
			break;
			} // switch
		$limit = ' LIMIT ' . (int)(($edit['page_idx'] - 0) * $edit['page_size']) . ', ' . $edit['page_size'];
		return self::SQL_EOL . $limit;
		} // get_DB_page_limits()

	protected function get_DB_table_editor_forms($action_uri,&$table_details) {
		if((!isset($table_details['edit']['columns'])) ||
			(!is_array($table_details['edit']['columns'])) ||
			(count($table_details['edit']['columns']) < 1)) {
			self::addMsg('Table "' . $this->edit_DB_info['table'] . '" edit.columns control missing.');
			return false;
			}
		if((!$this->cEditDB) || (!$this->cEditDB->is_ok())) {
			$this->log_msg('Fail DB in "' . __CLASS__. '::' . __METHOD__ . '".');
			return 'DB fail.';
			} // if
		// do SQL simple for the moment (easier to db_keywords)
		$edit = &$this->edit_DB_info;
		$edit['row_cnt'] = 0;

		$sql = $this->make_DB_select_from_where($table_details);
		// does not do work with cross joins	$edit['row_cnt'] = @$this->cEditDB->get_row_count_in_table($edit['table'],$where);
		if($result = $this->cEditDB->query($sql)) {
			$edit['row_cnt'] = @$this->cEditDB->get_row_cnt($result);
			} // if

		if($edit['free_form']) {
			$this->new_entry_row = $this->get_DB_form_table_row($action_uri,$table_details,array());	// add blank row/new row (simple)
			$new_tr = rawurlencode($this->new_entry_row);
			echo <<< EOTNRD

		<script type="text/javascript">
			var cms_DB_new_table_tr = '{$new_tr}';
		</script>

EOTNRD;

			} // if

		$limit = $this->get_DB_page_limits();	// do page cnts, etc.
		if((!is_null($edit['row_cnt'])) && ($edit['row_cnt'] > 0)) {
			$sql .= $this->get_DB_order_by($table_details);
			$sql .= $limit;
			if($result = $this->cEditDB->query($sql)) {
				echo $this->get_DB_filter_prev_next_page_form_sticky($action_uri);
				echo $this->get_DB_row_heading($action_uri, $table_details);
				if($this->edit_DB_info['free_form'])
					echo $this->new_entry_row;	// add blank row/new row (simple)
				while($row = $this->cEditDB->fetch_array_assoc($result)) {
					if($edit['free_form']) {
						echo $this->get_DB_form_table_row($action_uri,$table_details,$row);
						} // if
					else {
						echo $this->get_DB_table_row($action_uri,$table_details,$row);
						} // else
					} // while
//				if($this->edit_DB_info['free_form'])
//					echo $this->new_entry_row;	// add blank row/new row (simple)
				} // if
			} // if
		else {
			echo $this->get_DB_filter_prev_next_page_form($action_uri);
			echo $this->get_DB_row_heading($action_uri, $table_details);
			echo '<tr' . $this->class . '><td' . $this->class . ' colspan="' . $this->edit_DB_info['columns_num'] . '">' . 'No results found.' . '</td></tr>';
			} // else

		echo $this->get_DB_row_footing($action_uri, $table_details);
		// echo $this->get_DB_filter_prev_next_page_form_sticky($action_uri);
		return $this->prn_or_buffer_text();
		} // get_DB_table_editor_forms()

	protected function get_DB_dlg_editor_form($action_uri,&$table_details) {
		if((!isset($table_details['edit']['columns'])) ||
			(!is_array($table_details['edit']['columns'])) ||
			(count($table_details['edit']['columns']) < 1)) {
			self::addMsg('Table "' . $this->edit_DB_info['table'] . '" edit.columns control missing.');
			return false;
			}
		if((!$this->cEditDB) || (!$this->cEditDB->is_ok())) {
			$this->log_msg('Fail DB in "' . __CLASS__. '::' . __METHOD__ . '".');
			return 'DB fail.';
			} // if
		// do SQL simple for the moment (easier to db_keywords)
		$edit = &$this->edit_DB_info;
		$edit['row_cnt'] = 0;

		$sql = $this->make_DB_select_from_where($table_details);
		// does not do work with cross joins	$edit['row_cnt'] = @$this->cEditDB->get_row_count_in_table($edit['table'],$where);
		if($result = $this->cEditDB->query($sql)) {
			$edit['row_cnt'] = @$this->cEditDB->get_row_cnt($result);
			} // if

		$this->new_entry_row = $this->get_DB_form_table_row($action_uri,$table_details,array());	// add blank row/new row (simple)
		$new_tr = rawurlencode($this->new_entry_row);
		echo <<< EOTNRD

		<script type="text/javascript">
			var cms_DB_new_table_tr = '{$new_tr}';
		</script>

EOTNRD;

		$limit = $this->get_DB_page_limits();	// do page cnts, etc.
		if((!is_null($edit['row_cnt'])) && ($edit['row_cnt'] > 0)) {
			$sql .= $this->get_DB_order_by($table_details);
			$sql .= $limit;
			if($result = $this->cEditDB->query($sql)) {
				echo $this->get_DB_filter_prev_next_page_form_sticky($action_uri);
				echo $this->get_DB_row_heading($action_uri, $table_details);
				if($this->edit_DB_info['free_form'])
					echo $this->new_entry_row;	// add blank row/new row (simple)
				while($row = $this->cEditDB->fetch_array_assoc($result)) {
					echo $this->get_DB_form_table_row($action_uri,$table_details,$row);
					} // while
//				if($this->edit_DB_info['free_form'])
//					echo $this->new_entry_row;	// add blank row/new row (simple)
				} // if
			} // if
		else {
			echo $this->get_DB_filter_prev_next_page_form($action_uri);
			echo $this->get_DB_row_heading($action_uri, $table_details);
			echo '<tr' . $this->class . '><td' . $this->class . ' colspan="' . $this->edit_DB_info['columns_num'] . '">' . 'No results found.' . '</td></tr>';
			} // else

		echo $this->get_DB_row_footing($action_uri, $table_details);
		// echo $this->get_DB_filter_prev_next_page_form_sticky($action_uri);
		return $this->prn_or_buffer_text();
		} // get_DB_dlg_editor_form()

} // Ccms_DB_edit_sql
