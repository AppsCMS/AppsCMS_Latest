<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_database_common.php 3045 2022-12-15 02:08:14Z robert0609 $
 */

/**
 * Description of database
 *
 * @author robert0609
 */

class Ccms_database_common extends Ccms_base {

	protected $m_sDatabase = '';		// the database name used
	protected $m_bOpen = false;		// true when db link open
	private $username = '';
	private $password = '';

	public static $m_bSaveDBtransactions = false;
	public $m_bDB_checked = false;	// true indactes DB checked, dont check again
	public $m_sVersion = '';

	protected $db_chgd = false;

	public $m_bNew = false;	// true if db created

	public static $readonly_db = true;

	protected const OUT_MSG_ITERATION = 25;

	protected const CMS_TABLE_AUDIT_COLS = 3;

	function __construct($log = '') {
		parent::__construct($log);
		} // __construct()

	function __destruct() {
		parent::__destruct();
		} // __destruct()

	// methods
	public static function get_db_datetime($time = false) {	// returns date time string in DB compatible format, useful as it returns the SI DT string
		// @TODO why is this duplicated, and where has the base class gone !!!!
		if($time) return date('Y-m-d H:i:s',$time);
		return date('Y-m-d H:i:s');
		} // get_db_datetime()

	public static function convertSyntaxSQLite2MySQL($def) {	// $def is the column definition
		$ignored_prefixes = array(
			'PRAGMA',
			'BEGIN TRANSACTION;',
			'COMMIT;',
			'SELECT * FROM sqlite_master;',
			'DELETE FROM sqlite_sequence;',
			'INSERT INTO "sqlite_sequence"',
			);

		foreach($ignored_prefixes as $chk) {
			if(preg_match('/' . $chk . '/i',$def)) return false;
			} // foreach

		$replacements = array(
			"INTEGER PRIMARY KEY AUTOINCREMENT" =>  "INTEGER AUTO_INCREMENT",
			"INTEGER PRIMARY KEY" =>  "INTEGER AUTO_INCREMENT",
			"AUTOINCREMENT" =>  "AUTO_INCREMENT",
			"DATETIME('NOW','UTC')" => "CURRENT_TIMESTAMP",	// "UTC_TIMESTAMP()",
			"DATETIME('NOW')" => "CURRENT_TIMESTAMP",	// "NOW()",
			"DATETIME DEFAULT 0" => "TIMESTAMP NOT NULL DEFAULT 0",	// MariaDB 10 ???
			"DATETIME" => "TIMESTAMP",
			"DEFAULT 't'" =>  "DEFAULT '1'",
			"DEFAULT 'f'" =>  "DEFAULT '0'",
			"ON CONFLICT FAIL" => "",
			",'t'" =>  ",'1'",
			",'f'" =>  ",'0'",
			);

		foreach($replacements as $chk => $rep) {
//			$def = preg_replace('/' . $chk . '/i',$rep,$def);
			$def = str_replace($chk,$rep,$def);
			$def = str_replace(strtolower($chk),$rep,$def);
			} // foreach
		return $def;
		} // convertSyntaxSQLite2MySQL()

	public static function convert_scriptSQLite2MySQL($install_scripts_sqlite) {
		// now convert SQLite syntax to MySQL syntax
		$install_scripts_mysql = array();
		foreach($install_scripts_sqlite as $table => &$tab_data) {
			foreach($tab_data as $k => &$v) {
				switch($k) {
				case 'columns':
					foreach($v as $name => $def) {
						$val = self::convertSyntaxSQLite2MySQL($def);
						if(!empty($val))
							$install_scripts_mysql[$table][$k][$name] = $val;
						} // foreach
					break;
				case 'data':
					foreach($v as $ridx => &$cols) {
						foreach($cols as $cidx => $data) {
							$val = self::convertSyntaxSQLite2MySQL($data);
							if($val === false) {
								self::addMsg('Failed to convert SQLite: "' . $data . '".');
								exit(2);
								} // if
							$install_scripts_mysql[$table][$k][$ridx][$cidx] = $val;
							} // foreach
						} // foreach
					break;
				case 'functions':
					// not converted at the moment
					break;
				default:
					$install_scripts_mysql[$table][$k] = $v;
					break;
					} // switch
				} // foreach
			} // foreach
		return $install_scripts_mysql;
		} // convert_scriptSQLite2MySQL()

	public static function convertSyntaxMySQL2SQLite($def) {	// $def is the column definition
		$def = preg_replace('/\'/',"'",$def);	// Use '' instead of \'
		$def = preg_replace('/\"/','"',$def);	// Use " instead of \"
		$def = preg_replace('/\\r\\n/','\r\n',$def);	// Convert escaped \r\n to literal
		$def = preg_replace('/\\\\/','\\',$def);	// Convert escaped \ to literal
		$def = preg_replace('/ auto_increment/i','',$def);	// Remove auto_increment
		$def = preg_replace('/^[UN]*?LOCK TABLES.*/i','',$def);	// Remove locking statements
		return $def;
		} // convertSyntaxMySQL2SQLite()

	protected function out_import_stat_msg($msg) {	// output an iterative on a single line using line refresh
		self::flush_out_msg($msg);
		} // out_import_stat_msg()

	public function dt2sql_dt($dt) {
		$time = strtotime($dt);
		if($time === false) return false;
		$sql_dt = self::get_db_datetime($time);
		return $sql_dt;
		} // dt2sql_dt()

	public function get_db_sql_localtime($col_name = false,$as = false,$offset = false) {
		if(!empty($col_name)) $sql = $col_name;
		else $sql = date('Y-m-d H:i:s');	// now
		// cannot use offset here (DB function unknown)
		if(!empty($as)) $sql .= ' as ' . $as;
		return $sql;
		} // get_db_sql_localtime()

//	public function checkdate($date) {	// check the date is mysql std fmt 'yyyy-mm-dd'
//		// for sake of convienience this function is repeatly statically in Ccms_app_base.php
//		if(preg_match('/[0-9]{4,4}-[0-9]{2,2}-[0-9]{2,2}/', $date)) return true;
//		return false;
//		} // checkdate()

	protected function onError($error) {
		self::addMsg('DB_ERROR ' . $this->m_sDatabase . ' - ' . $error);
		if((!defined('CMS_S_DB_DIE_ON_ERRORS_BOOL')) || (CMS_S_DB_DIE_ON_ERRORS_BOOL != true)) return false;	// for short cut back
		echo self::getMsgs();
		die();
		} // onError()

	protected function log_result($result) {
		switch(gettype($result)) {
		case "boolean":
			self::log_msg('DB_RESULT: ' . ($result ? 'true':'false'));
			break;
		case "integer":
		case "double":
		case "float":
		case "string":
			self::log_info_msg('DB_RESULT: "' . $result . '"');
			break;
		case "object":
			self::log_info_msg('DB_RESULT: ' . serialize($result));
			break;
		case "array":
			self::log_info_msg('DB_RESULT: ' . self::json_encode($result));
			break;
		case "NULL":
			self::log_info_msg('DB_RESULT: ' . 'null');
			break;
		case "resource":
		case "resource (closed)":
		case "unknown type":
		default:
			break;
			} // switch
		} // log_result()

//	public static function array_trimCallback(&$str,$key) { $str = trim($str); } // array_trimCallback()
//	public static function array_trim(&$array) { return array_walk_recursive($array,'self::array_trimCallback'); } // array_trim()

	// dynamic methods
	public function get_name() { return $this->m_sDatabase; } // get_name()
	public function get_host() { return ''; } // get_host() virtual
	public function save_reconstruct_DB_data() { return false; } // save_reconstruct_DB_data() virtual

	public function output($string) {
		if(is_array($string)) {
			foreach($string as $k => &$v) {
				$string[$k] = $this->output($v);	// recurse
				} // foreach
			return $string;
			} // if
		$string = html_entity_decode($string,ENT_COMPAT,CMS_S_CHAR_SET);
		return htmlspecialchars($string,ENT_COMPAT,CMS_S_CHAR_SET);
		} // output()

	public function input($string) {
		return $string;
		} // input()

	public function implode_ary2str($sep,$row) {
		$string = '';
		foreach($row as &$v) {
			if(!empty($string)) $string .= $sep;
			$string .= "'" . $this->input($v) . "'";
			} // foreach
		return $string;
		} // implode_ary2str()

	protected function sanitize_string($string) {
		$string = ereg_replace(' +', ' ', trim($string));
		return preg_replace("/[<>]/", '_', $string);
		} // sanitize_string()

	public function prepare_input($string) {
		if (is_string($string)) {
			return trim($this->sanitize_string(stripslashes($string)));
		} // if
		elseif (is_array($string)) {
			reset($string);
			foreach($string as $key => &$value) {
				$string[$key] = prepare_input($value);
			} // foreach
			return $string;
		} // elseif
		else {
			return $string;
		} // else
	} // prepare_input()

	public function prepare_search_keyword($keyword) { // added by BF
		$keyword = prepare_input($keyword);
		if (empty($keyword))
			return $keyword;

		// ambiguous prefixes and suffixes that may hinder search
		$prefixes = array('[', ']', '{', '}', '\\', '/', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '|', '~', '?', '<', '>', '"', "'", '-', ';', ':', '.', ','); // single letter at this stage
		$suffixes = array('[', ']', '{', '}', '\\', '/', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '=', '|', '~', '?', '<', '>', '"', "'", '-', ';', ':', '.', ',', 's', 'S'); // single letter at this stage

		if (is_array($keyword)) {
			reset($keyword);
			foreach ($keyword as $key => &$value) {
				$keyword[$key] = prepare_search_keyword($value);
			} // foreach
		} // if
		else {
			foreach ($prefixes as $p) {
				if (strlen($keyword) < 1)
					break;
				if (substr($keyword, 0, 1) == $p)
					$keyword = substr($keyword, 1);
			} // foreach
			foreach ($suffixes as $s) {
				if (strlen($keyword) < 1)
					break;
				if (substr($keyword, -1, 1) == $s)
					$keyword = substr($keyword, 0, -1);
			} // foreach
		} // else
		return $keyword;
	} // prepare_search_keyword()

	public function is_data_in_table($table,$colname,$data) {
		if(!$this->is_ok()) return false;
		if(!$this->is_table_present($table)) return false;	// no table
		$test_sql = "SELECT ". $colname . " FROM " . $table .
			" where " . $colname . " = " . (is_numeric($data) ? $data:"'" . $this->input($data) . "'");
		if($test_result = $this->query($test_sql)) {
			if($test = $this->fetch_array($test_result)) {
				return true;	//$test[$colname];	// its there
				} // if
			} // if
		return false; // no data match
		} // is_data_in_table()

	public function get_row_count_in_table($table,$where = '') {	// virtual
		return false; // no data, error
		} // get_row_count_in_table()

	public function get_row_cnt($results = false) {	// virtual
		return -1;
		} // get_row_cnt()

	public function get_data_in_table($table,$colname,$where, $params = false) {
		if(!$this->is_ok()) return false;
		if((!$this->m_bDB_checked) &&
			(!$this->is_table_column_present($table,$colname))) return false;	// no table or no column
		$cols = (is_array($colname) ? $colname:explode(',',$colname));
		$test_sql = "SELECT ". implode(', ',$cols) . " FROM " . $table .
			(!empty($where) ? " WHERE " . $where:'') .
			(!empty($params) ? " " . $params:'');
		if($test_result = $this->query($test_sql)) {
			if($test = $this->fetch_array($test_result)) {
				if(count($test) == 1) return $this->output($test[(array_key_first($test))]);
				$result = array();
				foreach($test as $k => &$v) $result[$k] = $this->output($v);
				return $result;
				} // if
			} // if
		return false; // no data match
		} // get_data_in_table()

	public function set_data_in_table($table,$colname,$value,$where, $params = false) {
		if(!$this->is_ok()) return false;
		if((!$this->m_bDB_checked) &&
			(!$this->is_table_column_present($table,$colname))) return false;	// no table or no column
		$cols = (is_array($colname) ? $colname:explode(',',$colname));
		$vals = (is_array($value) ? $value:explode(',',$value));
		if(count($cols) != count($vals)) return false;

		$test_sql = "UPDATE " . $table . " SET ";
		for($i = 0; $i < count($cols); $i++) {
			if($i > 0) $test_sql .= ', ';
			$test_sql .= $cols[$i] . " = '" . $this->input($vals[$i]) . "'";
			} // for
		$test_sql .= (!empty($where) ? " WHERE " . $where:'');
		$test_sql .= (!empty($params) ? " " . $params:'');
		if($test_result = $this->query($test_sql)) return true;
		return false; // error
		} // set_data_in_table()

	protected function checkAddDBcolumn($table, $column, $type) {	// virtual
		return false;
		} // checkAddDBcolumn()

	public function checkDropDBcolumn($table, $column) {	// virtual
		return false;
		} // checkDropDBcolumn()

	protected function checkAddDBtable($table) {
		if(!$this->is_ok()) return false;
		if($this->is_table_present($table)) return true;
		if ($this->query('CREATE TABLE ' . $table . ';')) return true;
		return false;
		} // checkAddDBtable()

	protected function set_time_limit($limit) {
		// dummy function
		} // set_time_limit()

	protected function chk_table_row_sanity(&$table,&$row) {	// very likely this will have overrides
		$upd = false;
		switch($table) {
		case 'cms_configs':
			if(isset($row['cms_config_key'])) {
				switch($row['cms_config_key']) {
				case "'CMS_C_VERSION'":
					if(self::is_rebuild()) {
						$row['cms_config_value'] = CMS_PROJECT_VERSION;	// don't overwrite new version
						$upd = true;
						} // if
					break;
				default:
					break;
					} // switch
				} // if
			break;
		case 'cms_users':
			if(isset($row['cms_user_inline_html'])) {
				unset($row['cms_user_inline_html']);	// remove old column
				$upd = true;
				} // if
			break;
		default:
			break;
			} // switch
		return $upd;
		} // chk_table_row_sanity()

	protected function export_db2json(&$install_scripts,$json_file) {	// exports data and remove orphans as it goes
		if(!$this->is_ok()) return false;
		$json = array();
		foreach($install_scripts as $table => &$v) {
			$sql = 'SELECT * FROM ' . $table . (!empty($v['asc']) ? ' ORDER BY ' . $v['asc']:'');
			if($res = $this->query($sql)) {
				while($data = $this->fetch_array($res,false)) {
					$jd = array();
					foreach($v['columns'] as $c => &$t) {
						if(isset($data[$c])) $jd[$c] = $data[$c];	// filter it (remove empty and orphaned)
						} // if
					$json[$table][] = $jd;
					} // while
				} // if
			} // foreach
		if(self::save_json($json_file, $json, false)) {
			self::addMsg('Saved reconstruct data for ' . CMS_PROJECT_SHORTNAME . ' DB.','success');
			return true;
			}
		self::addMsg('Failed to save data for ' . CMS_PROJECT_SHORTNAME . ' DB.');
		return false;
		} // export_db2json()

	protected function get_msg_iteration_cnt(&$data) {
		$n = count($data);
		$msg_itr = self::OUT_MSG_ITERATION;
		if(($n / 100) > $msg_itr)
			$msg_itr = (int)($n / 100);	// 1% is enough
		return $msg_itr;
		} // get_msg_iteration_cnt()
		
	private function make_row_fields(&$data) {
		$fields = [];
		foreach($data as $col => $row) {
			if(empty($row)) continue;	// use default
			$fields[$col] = $row;
			} // foreach
		return $fields;
		} // make_row_fields()

	protected function import_json2db(&$install_scripts,$json_file,$drop_data = false,$verbose = false) {	// imports data into cms.sqlite (probably some corruption by encryption between sqlite versions)
		if(!$this->is_ok()) return false;
		if((!file_exists($json_file)) ||
			(!is_readable($json_file)) ||
			(!$json = self::load_json($json_file))) {
			self::addMsg('No reconstruct data for ' . CMS_PROJECT_SHORTNAME . ' DB.','warn');
			return false;
			} // if
		$ok = true;
		if(self::is_cli()) self::addMsg ('Reconstructing ' . CMS_PROJECT_SHORTNAME . ' DB.','info');
		else if($verbose) $this->out_import_stat_msg('Reconstructing ' . CMS_PROJECT_SHORTNAME . ' DB.' . PHP_EOL);
		foreach($json as $table => &$data) {
			if(preg_match('/^[^a-z]+/',$table)) continue;	// sys value, not table
			if(empty($install_scripts[$table])) continue;	// no table
			$inst = &$install_scripts[$table];
			$in_table_cnt = (int)$this->get_row_count_in_table($table);
			if($in_table_cnt < count($data)) $drop_data = true;
			if($drop_data) {	// clean data
				if((self::is_cli()) || ($verbose)) self::addMsg ('Reconstructing all data in table: ' . $table,'info');
				$this->query("DELETE FROM " . $table . ";");	// clean it
				$msg_itr = $this->get_msg_iteration_cnt($data);
				for($i = 0; $n = count($data), $i < $n; $i++) {
					$row = &$data[$i];
					$this->chk_table_row_sanity($table,$row);
					$fields = $this->make_row_fields($row);
					if(empty($fields)) continue;	// MT ??
					if((!empty($inst['id'])) && (empty($fields[($inst['id'])]))) continue;	// @TODO ?? error or schema change ??
					$sql_query = "INSERT INTO " . $table . " (" .
						implode(',',array_keys($fields)) .
						") VALUES (" .
						implode(',',array_map(function($v) {
							if(is_numeric($v)) return $v;
							return "'" . $v . "'";
							}, array_values($fields))) .
						");";
					if(!$this->query($sql_query)) {
						self::addMsg('Failed to reconstruct DB table: ' . $table . ', row: ' . var_export($fields,true));	//$sql_query);
						$ok = false;
						continue;	// keep going
						} // if
					if(($verbose) && (($i % $msg_itr) == 0))	// speed up
						$this->out_import_stat_msg('JSON to Table: ' . $table . ', row: ' . $i . '.');
					} // for
				$this->db_chgd = true;
				if($verbose) $this->out_import_stat_msg('JSON to Table: ' . $table . ', rows: ' . $i . '.' . PHP_EOL);
				} // if
			else {	// update or add missing data
				if(empty($install_scripts[$table]['data'])) continue;	// no table data
				if(empty($install_scripts[$table]['key_column'])) continue;	// no table key colum
				if((self::is_cli()) || ($verbose)) self::addMsg ('Reconstruct missing data: ' . $table,'info');
				$colnames = array_keys($install_scripts[$table]['columns']);
				$key_column = $install_scripts[$table]['key_column'];
				$id = (!empty($install_scripts[$table]['id']) ? $install_scripts[$table]['id']:false);
				$msg_itr = $this->get_msg_iteration_cnt($data);
				for($i = 0; $n = count($data), $i < $n; $i++) {
					$row = &$data[$i];
					$this->chk_table_row_sanity($table,$row);
					$fields = $this->make_row_fields($row);
					if(empty($fields[$key_column])) continue;
					$this->chk_table_row_sanity($table,$fields);
					$idx = 0;

					if((int)$this->get_row_count_in_table($table,$key_column . ' = \'' . $fields[$key_column] . '\'') > 0) {
						$where = $key_column . ' = \'' . $fields[$key_column] . '\'';
						unset($fields[$key_column]);
						$action = 'update';
						} // if
					else if((!empty($id)) &&
						((int)$this->get_row_count_in_table($table,$key_column . ' = ' . $fields[($id)] . '') > 0)) {
						$where = $key_column . ' = ' . $fields[($id)] . '';
						$action = 'update';
						} // else if
					else {
						$where = '';
						$action = 'insert';
						} // else
					if(!empty($id)) unset($fields[$id]);

					if($action == 'update') {
						if(!$this->perform($table,$fields,$action,$where)) {
							if($verbose) $this->out_import_stat_msg('JSON update failed table: ' . $table . ', row: ' . $i . '.' . PHP_EOL);
							continue;
							} // if
						} // if
					else if($action == 'insert') {
						if(!$this->perform($table,$fields,$action)) {
							if($verbose) $this->out_import_stat_msg('JSON insert failed table: ' . $table . ', row: ' . $i . '.' . PHP_EOL);
							continue;
							} // if
						} // else
					if(($verbose) && (($i % $msg_itr) == 0))	// speed up
						$this->out_import_stat_msg('JSON update Table: ' . $table . ', row: ' . $i . '.');
					$this->db_chgd = true;
					} // for
				if($verbose) $this->out_import_stat_msg('JSON update Table: ' . $table . ', row: ' . $i . '.' . PHP_EOL);
				} // else
			} // foreach
		self::addMsg('Reconstructed ' . CMS_PROJECT_SHORTNAME . ' DB.','success');
		if($verbose)$this->out_import_stat_msg('Reconstructed ' . CMS_PROJECT_SHORTNAME . ' DB.' . PHP_EOL);
		return $ok;
		} // import_json2db()

	function backupDatabase($backupFolder = false, $cms_msg_info = false) {
		if(!$this->is_ok()) return false;
		// dummy virtual function
		return true;
		} // backupDatabase()

	function restoreDatabase($backupfile) {
		if(!$this->is_ok()) return false;
		// dummy virtual function
		return true;
		} // restoreDatabase()

	protected function installTable($table,&$params,$drop = false, $verbose = false) {
		if(!$this->is_ok()) return false;
		// dummy function
		return true;
		} // installTable()

	public function install_db_tables($only_table, $install_scripts, $verbose = false, $drop = false) {
		if(!$this->is_ok()) return false;
		// dummy function
		return true;
		} // install_db_tables()

} // Ccms_database_common

