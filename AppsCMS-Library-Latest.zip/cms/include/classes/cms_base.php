<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_base.php 3457 2024-05-12 03:59:09Z robert0609 $
 */

/**
 * Description of cms_base
 *
 * @author robert0609
 */

// the always defined classes
require_once(CMS_FS_CLASSES_DIR . 'cms_config_funcs.php');

class Ccms_base extends Ccms_config_funcs {

	private static $cms_php_input_json = false;
	private static $cms_php_input_multi_data = false;

	protected const DEF_VAR_KEY = 'def_var_key';

	function __construct() {
		parent::__construct();
		$parent = get_class($this);	// wait for DB to open
		} // __construct()

	function __destruct() {
		if(self::$cms_refd_false !== false) {	// DO NOT CHANGE, used as reference &false
			self::addDebugMsg('CODE ERROR: $cms_refd_false has been aletered from false value.');
			} // if
		parent::__destruct();
		} // __destruct()

	public function __call($name, $args) {	// a PHP magic method
		if(preg_match('/[ !?@]+/',$name)) return null;	// not legal
		if(method_exists($this, $name)) {	// use local
			return call_user_func($name,$args);
			} // if
		$trace = self::get_backtrace(3);
		self::addDebugMsg ('Unknown function "' . $name . '" from "' . (empty($trace) ? '(base)':$trace) . '"');
		return null;
		} // __call()

	public static function __callStatic($name, $args) {	// a PHP magic method
		if(preg_match('/[ !?@]+/',$name)) return null;	// not legal
		$func = false;
		if(function_exists($name)) {	// use local
			return @call_user_func($name,$args);
			} // if
		$trace = self::get_backtrace(3);
		self::addDebugMsg ('Unknown static function "' . $name . '" from "' . (empty($trace) ? '(base)':$trace) .'"');
		return null;
		} // __callStatic()

// static methods
	public static function get_body($inkvd = false) {
		global $cCMS;
		if(empty($inkvd)) {	// current body
			if(isset(self::$cms_page_info['body'])) return self::$cms_page_info['body'];
			if(!Ccms_sm::get_body_cnt()) return false;
			$cCMS->lookup_default_body();
			if(isset(self::$cms_page_info['body'])) {
				return self::$cms_page_info['body'];
				} // if
			} // if
		// else try to find it
		$body = self::$cDBcms->get_data_in_table('cms_bodies','*',
			'cms_body_id = ' . (int)$inkvd . ' OR cms_body_name = \'' . $inkvd . '\' OR cms_body_app_key = \'' . $inkvd . '\' OR cms_body_virtual_name = \'' . $inkvd . '\' OR cms_body_dir = \'' . $inkvd . '\'');
			if(!empty($body)) return $body;
		return false;
		} // get_body()

	public static function is_on_navbar(&$nav_bar_grid,$url) {
		if(empty($nav_bar_grid)) return false;
		foreach($nav_bar_grid as $g) {
			$chk = false;
			if(!empty($g[0]['uri'])) $chk = $g[0]['uri'];
			else if(!empty($g[0])) $chk = $g[0];
			else return false;
			if(stripos($chk,$url) !== false) return true;
			} // foreach
		return false;
		} // is_on_navbar()

	public static function array_trimCallback(&$str,$key) { $str = trim($str); } // array_trimCallback()
	public static function array_trim(&$array) { return array_walk_recursive($array,self::class . '::array_trimCallback'); } // array_trim()

	public static function fmt_number2type($val, $allow_bool = true) {
		if((is_null($val)) || (is_array($val))) return $val;
		$val = trim($val);
		if(preg_match('/^true$/i',$val)) return ($allow_bool ? true:'true');
		if(preg_match('/^false$/i',$val)) return ($allow_bool ? false:'false');
		if(preg_match('/^[-+]{0,1}[0-9]+$/',$val)) return (int)$val;
		if(preg_match('/^[-+]{0,1}[0-9]+\.[0-9]+$/',$val)) return (float)$val;
		return $val;
		} // fmt_number2type()

	protected static function &decode_multipart_form_data(&$form_data,$boundary,$data_size) {
		// usually here because something has gone, upload error, etc.
		// example
		//------WebKitFormBoundary9ruhYEa1ojUTGL65
		//Content-Disposition: form-data; name="cms_action"
		//
		//cms_edit_bodies
		//------WebKitFormBoundary9ruhYEa1ojUTGL65
		//Content-Disposition: form-data; name="cms_body_id"
		//
		//0
		//------WebKitFormBoundary9ruhYEa1ojUTGL65
		//Content-Disposition: form-data; name="install"
		//
		//install
		//------WebKitFormBoundary9ruhYEa1ojUTGL65
		//Content-Disposition: form-data; name="packageToUpload"; filename="Private_Debug_Site_Application_LittleShop_V0.01-Beta-20230306-035730Z.zip"
		//Content-Type: application/zip
		//
		//PK ... the file contents

		if(empty($form_data)) return [];
		self::log_msg($form_data,'info');	// test
		$data = &self::$cms_php_input_multi_data;
		$data = [];
		$var_blks = &explode('--' . $boundary,$form_data);
		for($b = 1; $b < count($var_blks); $b++) {
			$blk = &$var_blks[$b];
			if(empty($blk)) continue;
			$lines = &explode(PHP_EOL,$blk,4);
			for($l = 1; $l < 4; $l++) {
				$line = &$lines[$l];
				if(empty($line)) continue;
				if(preg_match('/^Content-Disposition: form-data; name=/',$line)) {	// a varariable start
					$name = preg_replace('/^Content-Disposition: form-data; name="(\S+).?".*$/i','$1',$line);
					$type = false; $filename = 0;
					if(preg_match('/filename=".*"\s+$/',$line)) {	// has a filename
						$filename = preg_replace('/^.*filename="(.*)"\s+$/','$1',$line);
						} // if
					$line = &$lines[++$l];
					if(preg_match('/^Content-Type:/',$line)) {	// a multi type data
						$type = preg_replace('/^Content-Type: (.*)$/','$1',$line);
						$l += 2;	// skip blank line
						$data[$name]['file'] = self::save_multipart_form_upload_contents($name,$type,$filename,$blk,$data_size);
						} // if
					else {
						$l += 1;	// skip blank line
						$value = $lines[$l];
						$data[$name] = $value;
						}// else
					break;
					} // if
				} // for
			} // for
		return self::$cms_php_input_multi_data;
		} // decode_multipart_form_data()

	protected static function get_php_input_json($name = false, $chk =false) {
		// some posted data only appears on the "php://input" stream.
		if(!self::$cms_php_input_json) {
			if(empty(self::$cms_client_headers['Content-Type'])) return false;
			$type = &self::$cms_client_headers['Content-Type'];
			$data_size = self::$cms_client_headers['Content-Length']['type']; // ?? type ?? not size
			$val_str = file_get_contents("php://input");
			$val_ary = array();
			switch($type['type']) {
			default:	// @TODO assumed
			case 'application/json':
				$val_ary = @json_decode($val_str,true);
				if((!empty($val_ary))) {
					self::$cms_php_input_json = $val_ary;
					} // if
				else {
					parse_str($val_str,$val_ary);
					if((!empty($val_ary)) && (is_array($val_ary))) {
						self::$cms_php_input_json = $val_ary;
						} // if
					} //  else
				break;
			case 'multipart/form-data':		// @TODO why ??? server should do automatically
				if(!empty($val_str)) {
					$params = $type['params'];
					list(,$boundary) = explode('=',$params);	// e.g. boundary=----WebKitFormBoundarymz7d0mxk1AFG5YRV
					$val_ary = self::decode_multipart_form_data($val_str,$boundary,$data_size);
					} // if
				self::$cms_php_input_json = $val_ary;
				break;
			case 'application/x-www-form-urlencoded':
				$val_dec = @urldecode($val_str);
				if((($var_ary = self::chk_unserialize($val_dec)) !== false) &&
					(!empty($val_ary))) {
					self::$cms_php_input_json = $val_ary;
					} // if
				else if((($val_ary = @json_decode($val_dec,true)) !== false) &&
					(!empty($val_ary))) {
					self::$cms_php_input_json  = $val_ary;
					} // if
				else {
					parse_str($val_str,$val_ary);
					if((!empty($val_ary)) && (is_array($val_ary))) {
						self::$cms_php_input_json = $val_ary;
						} // if
					} //  else
				break;
				} // switch
			} // if
		if(!empty($name)) {
			if(isset(self::$cms_php_input_json[$name])) {
				if($chk) return true;
				return self::$cms_php_input_json[$name];
				} // if
			return false;
			} // if
		return self::$cms_php_input_json;
		} // get_php_input_json()

	public static function get_or_post_str($name, $allow_bool = true, $def = false) {
		// refer: https://www.php.net/manual/en/wrappers.php.php
		// NOTE: In php.ini; set always_populate_raw_post_data = true to use $_POST.
		// php://input is not available with enctype="multipart/form-data".
		// Using php://input is read only and does not allow push-back into the POSTed values.
		// To have push-back use "self::set_chk_php_value('always_populate_raw_post_data',1)" in config PHP code or
		// "php_flag always_populate_raw_post_data on" in the (DOCROOT)/.htaccess
		// to enable full $_POST access per application.;

		$val = $def;
		if(isset($_POST[$name]))
			$val = $_POST[$name];
		else if(isset($_GET[$name]))
			$val = $_GET[$name];
		else if((!isset($_COOKIE[$name])) && (isset($_REQUEST[$name])))
			// try for $_GET, $_POST (but !$_COOKIE)
			// $_REQUEST decoded already
			$val = $_REQUEST[$name];
		// if all configs/setups are correct, should never get here
		else if(($val_chk = self::get_php_input_json($name)) &&
			(!empty($val_chk))) {
			$val = $val_chk;
			} // if
		return $val;
		} // get_or_post_str()

	public static function get_or_post($name, $allow_bool = true, $def = false) {
		$val = self::get_or_post_str($name, $allow_bool, $def);
		return self::fmt_number2type($val,$allow_bool);
		} // get_or_post()

	public static function get_or_post_pushback($name, $val) {
		$_GET[$name] = $val;	// @TODO maybe a better way
		return true;
		} // get_or_post_pushback()

	public static function get_or_post_app_session($name, $cms_app_key = false, $allow_bool = true) {
		// use session if not available
		$val = self::get_or_post_str($name, $allow_bool, null);
		$val = self::fmt_number2type($val,$allow_bool);
		if(self::have_session()) {	// have a session
			if((empty($cms_app_key)) && (!empty(self::$cms_app_key))) $cms_app_key = self::$cms_app_key;
			if(!empty($cms_app_key)) {
				if(!is_null($val)) self::set_cms_sess_var($val,'apps',$cms_app_key,$name);
				else $val = self::get_cms_sess_var('apps',$cms_app_key,$name);
				} // if
			} // if
		return $val;
		} // get_or_post_app_session()

	public static function get_or_post_keyed_session_var($name, $var_key = false, $allow_bool = true) {
		// use session if not available
		$val = self::get_or_post_str($name, $allow_bool, null);
		$val = self::fmt_number2type($val,$allow_bool);
		if(self::have_session()) {	// have a session
			if(empty($var_key)) $var_key = self::DEF_VAR_KEY;
			if(!is_null($val)) self::set_cms_sess_var($val,$var_key,$name);
			else $val = self::get_cms_sess_var($var_key,$name);
			} // if
		return $val;
		} // get_or_post_keyed_session_var()

	public static function get_or_post_checkbox_keyed_session_var($name, $var_key = false, $allow_bool = true) {
		// use session if not available
		$val = self::get_or_post_checkbox($name);
		if(self::have_session()) {	// have a session
			if(empty($var_key)) $var_key = self::DEF_VAR_KEY;
			if(!is_null($val)) self::set_cms_sess_var($val,$var_key,$name);
			else $val = self::get_cms_sess_var($var_key,$name);
			} // if
		return $val;
		} // get_or_post_checkbox_keyed_session_var()

	public static function is_get_or_post($name) {
		if(isset($_POST[$name])) return true;
		if(isset($_GET[$name])) return true;
		// if((empty($_POST)) && (empty($_GET)))
		if(self::get_php_input_json($name,true)) return true;
		return false;
		} // is_get_or_post()

	public static function unset_get_or_post($name) {
		unset($_POST[$name]);
		unset($_GET[$name]);
		return true;
		} // unset_get_or_post()

	public static function get_or_post_checkbox($name) {
		if(self::get_or_post($name) == 'on') return 1;
		return 0;
		} // get_or_post_checkbox()

	public static function chk_get_or_post($name,&$val) {
		if(self::is_get_or_post($name)) {
			$i = self::get_or_post($name);
			$val = $i; // save it back to reference
			} // if
		return $val;
		} // chk_get_or_post()

	public static function chk_get_or_post_chgd($name,&$val) {
		$i = self::get_or_post($name);
		if($i) {
			if($i == $val) return false;	// no change
			$val = $i; // save it back to reference
			return true;	// it changed
			} // if
		return false;	// assume no change
		} // chk_get_or_post_chgd()

	public static function chk_get_or_post_str_chgd($name,&$val) {
		$i = self::get_or_post_str($name);
		if($i) {
			if($i == $val) return false;	// no change
			$val = $i; // save it back to reference
			return true;	// it changed
			} // if
		return false;	// assume no change
		} // chk_get_or_post_str_chgd()

	public static function checkdate($date) {	// check the date is mysql std fmt 'yyyy-mm-dd'
		// for sake of convienience this function is repeatly dynamically in Ccms_MySQL.php
		if(preg_match('/[0-9]{4,4}-[0-9]{2,2}-[0-9]{2,2}/', $date)) return true;
		return false;
		} // checkdate()

	public static function get_chk_date($name,$time_part = '') {
		$d = self::get_or_post($name);
		if($d === false) return false;
		if(!empty($time_part)) {	// change the time part, is actually a substitute string
			$d = substr($d,0,10); // just the date part
			$d .= ' ' . trim($time_part);	// add time_part, trim first in case
			} // if
		if(!self::checkdate($d)) return false;
		return $d;
		} // get_chk_date()

	public static function int2hstring($val) {	// reverse of hstring2int()
		$val = (int)trim($val);
		$num_brks = array(
			'E' => (1024 * 1024 * 1024 * 1024 * 1024 * 1024),
			'P' => (1024 * 1024 * 1024 * 1024 * 1024),
			'T' => (1024 * 1024 * 1024 * 1024),
			'G' => (1024 * 1024 * 1024),
			'M' => (1024 * 1024),
			'K' => (1024),
			);
		$text = '';
		foreach ($num_brks as $t => $v) {
			if($val > (int)((float)$v * 0.75)) {
				$text = number_format(($val / $v)) . $t;
				break;
				} // if
			} // foreach
		if(empty($text)) $text = $val;
		return $text;
		} // int2hstring()

	private static function chk_locale_currency(&$currency,&$locale) {
		$locale_info = localeconv();
		$currency = $locale_info['int_curr_symbol'];	// 'AUD';
		$locale = Locale::getDefault();	// CMS_CORE_LANG 'en_AU';
		} // chk_locale_currency()

	public static function number_to_currency($number,$currency = false, $locale = false) {
		self::chk_locale_currency($currency,$locale);
		$format = new NumberFormatter($locale, NumberFormatter::CURRENCY);
		$string = $format->formatCurrency($number, $currency);
		return $string;
		} // number_to_currency()

	public static function currency_to_float($value,$currency = false, $locale = false) {
		self::chk_locale_currency($currency,$locale);
		$format = new NumberFormatter($locale, NumberFormatter::CURRENCY);
		$flt = $format->parseCurrency($value, $currency);
		if($flt === false) $flt = $format->parse($value);	// try parse to float
		if($flt === false) $flt = (float)$value;	// try cast to float
		return $flt;
		} // currency_to_float()

	public static function hstring2int($val) {	// convert a linux type human string (e.g. 12K, 25M or 2G from a typical -h cmd option) to an integer, case insensitive
		return self::ini_num_str2int($val);
		} // hstring2int()

	protected static function get_random_str($length = 29) {
		$rnd_str = '';
		if($fh = @fopen('/dev/urandom', 'r')) {
			while(strlen($rnd_str) < $length) {
				if(($ch = fgetc($fh)) !== false) {
					if(!preg_match('/[[:alnum:]]/',$ch)) continue;	// eventually, aaf generation (???)
					$rnd_str .= $ch;
					} // if
				} // while
			fclose($fh);
			return $rnd_str;
			} // if
		return false;
		} // get_secret_str()

	protected static function bld_form2post($url,$data_n_v_ary,$form_id = false,$inc_JS_submitor = true) {
		// builds a form to from a users browser
		$u_p = explode('?',$url);
		$f_url = $u_p[0];	// form action url
		$u_vs = explode('&',$u_p[1]);	// split name=value parts
		if(empty($form_id)) $form_id = 'id_' . self::get_random_str();
		$text = array();
		$text[] = '';
		$text[] = '<form id="' . $form_id . '" action="' . $f_url . '" method="post" enctype="multipart/form-data">';
		// add the url name=values from url
		foreach($u_vs as $vs) {
			$n_v = explode('=',$vs);
			$text[] = '<input type="hidden" name="'.htmlentities($n_v[0]).'" value="'.htmlentities($n_v[1]).'">';
			} // foreach
		// add the data
		foreach ($data_n_v_ary as $a => $b) {
			$text[] = '<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
			} // foreach
		$text[] = '</form>';
		$text[] = '';
		if($inc_JS_submitor) {
			$text[] = '<script type="text/javascript">';
			$text[] = '	document.getElementById("' . $form_id . '").submit();';
			$text[] = '</script>';
			$text[] = '';
			} // if

		return PHP_EOL . implode(PHP_EOL,$text) . PHP_EOL;
		} // bld_form2post()

	public static function chk_web_host_up($enc_url, $timeout_mS = false, $port = false, $ret_code = false) {
		$url = rawurldecode($enc_url);
		if(preg_match('/^file:\/\/\/.+/i',$url)) {	// file URL
			$filename = preg_replace('/^file:\/\//i','',$url);
			if(file_exists($filename)) {
				self::log_msg('URL: "' . $url . '" OK.','success');
				return $url;
				} // if
			self::log_msg('URL: "' . $url . '" does not exist.','info');
			return false;
			} // if
		// web URL
		if($ret_code) {
			$u_vals = @parse_url($url);
			$host = (!empty($u_vals['host']) ? $u_vals['host']:$u_vals['path']);	// a quirk in parse_url()
			//if(!empty($u_vals['port'])) $port = $u_vals['port'];
			if(empty($host)) return false;
			if(!dns_get_record($host,DNS_A)) {
				self::log_msg('URL: "' . $url . '" does not have a DNS A record.','info');
				return 404;
				} // if
			} // if

		$ch = curl_init($url);
		if(preg_match('/^http:\/\/.+/i',$url)) {
			curl_setopt($ch, CURLPROTO_HTTP, true);
			} // if
		else if(preg_match('/^https:\/\/.+/i',$url)) {
			curl_setopt($ch, CURLPROTO_HTTPS, true);
			} // else if
		else {
			curl_close($ch);	// don't run out of memory with orphans
			return false;	// what ???
			} // else
		curl_setopt($ch, CURLOPT_HEADER, true);	// we want headers
		curl_setopt($ch, CURLOPT_NOBODY, true);	// dont need body
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
		curl_setopt($ch, CURLOPT_POSTREDIR, 7);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);	// catch output (do NOT print!)
		if(empty($timeout_mS)) $timeout_mS = 1000;
		if($timeout_mS) {
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout_mS);
			curl_setopt($ch, CURLOPT_TIMEOUT_MS, ($timeout_mS * 2));
			} // if
		if((int)$port > 10) curl_setopt ($ch, CURLOPT_PORT, (int)$port);
		$result = curl_exec($ch);
		$info = curl_getinfo($ch);
		curl_close($ch);	// don't run out of memory with orphans
		if($result === false) {
			self::log_msg('URL: "' . $url . '" failed to respond.','warn');
			return false;
			} // if
		$new_url = $info['uri'];
		$stat = self::get_url_response_str($info['http_code']);
		if(200 == $info['http_code']) {
			self::log_msg('URL: "' . $url . '" ok response "' . $stat . '".','success');
			return $new_url;	// ok
			} // if
		else if(301 == $info['http_code']) {
			self::log_msg('URL: "' . $url . '" redirect response "' . $stat . '".','warning');
			return $new_url;	// ok
			} // else if
		else if(302 == $info['http_code']) {
			self::log_msg('URL: "' . $url . '" redirect response "' . $stat . '".','warning');
			return $new_url;	// ok
			} // else if
		self::log_msg('URL: "' . $url . '" response "' . $stat . '".','info');
		if(($ret_code) && (!empty($info['http_code'])) && (is_numeric($info['http_code']))) return $info['http_code'];
		return false; // ???
		} // chk_web_host_up()

	public static function host_check($addr, $port = -1, $timeout = 2) {
		$u_vals = @parse_url($addr);
		$host = (!empty($u_vals['host']) ? $u_vals['host']:$u_vals['path']);	// a quirk in parse_url()
		if(empty($host)) return false;
		if(!empty($u_vals['port'])) $port = $u_vals['port'];
		else if(($port == -1) && (!empty($u_vals['scheme']))) {
			switch(strtolower($u_vals['scheme'])) {
			case 'ssh': $port = 22; break;
			case 'rsync': $port = 873; break;
			case 'ldap': $port = 389; break;
			case 'sftp': $port = 22; break;
			case 'ftp': $port = 21; break;
			case 'http': $port = 80; break;
			case 'https': $port = 443; break;
			case 'pop3': $port = 110; break;
			case 'pop3s': $port = 995; break;
			case 'imap': $port = 143; break;
			case 'imaps': $port = 993; break;
			case 'smb': $port = 445; break;
			case 'nfs': $port = 2049; break;
			case 'rdp': $port = 3389; break;
			case 'svn': $port = 3690; break;
			case 'mysql': $port = 3306; break;
			case 'postgresql': $port = 5432; break;
			case 'postgre': $port = 5432; break;
			default: break;
				} // switch
			} // else if
		// else a unix::// socket
		$fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
		if (!$fp) return false;
		fclose($fp);
		return true;
		} // host_check()

	public static function sanitiseText4Html($sStr,$cleanTail = true,$lf2br = true) {	// sanitise sStr to html compatibility
		$unknown = '';
		$sStr = str_replace(chr(0x0d),'',$sStr);	// windows !!
		$sStr = stripslashes($sStr);
		//$sStr = html_entity_decode($sStr,ENT_COMPAT,CMS_S_CHAR_SET);
		//$sStr = html_entity_decode($sStr,ENT_COMPAT,CMS_S_CHAR_SET);
		//$sStr = html_entity_decode($sStr,ENT_COMPAT,CMS_S_CHAR_SET);	// make sure all pre-encoding is gone
		$sStr = str_replace('&nbsp;',' ',$sStr);	// this seems to bring a bug in php/server language settings !!
		// return $sStr;

		$sSane = "";
		$idx = 0;
		while($idx < strlen($sStr)) {
			$cChr = ord(substr($sStr,$idx++,1));
			switch($cChr) {
			case 0xef:	// ef df db -> unknown glyph or UTF leader; could be 'tm',apostrophe, grave accent, or ...
				// remove it
				$idx++;
				$idx++;
				break;

			case 0x9:	// tab
				$sSane .= chr($cChr);
				break;
			// case 0xd:	// carriage retuen
			case 0xa:	// line feed
				if($lf2br) $sSane .= '<br>' . chr($cChr); // need to clean up later
				else $sSane .= chr($cChr); // need to clean up later
				break;

			// the html entities used
			case '&': $sSane .= '&amp;'; break;
			case '<': $sSane .= '&lt;'; break;
			case '>': $sSane .= '&gt;'; break;
			case '"': $sSane .= '&quot;'; break;
			case 0x96: $sSane .= '&#96;'; break;
			case 0x27: $sSane .= '&rsquo;'; break;

			// language specials
			case 0xa2: $sSane .= "&cent;"; break;
			case 0xa3: $sSane .= "&pound;"; break;
			case 0xa4: $sSane .= "&curren;"; break;
			case 0xa5: $sSane .= "&yen;"; break;
			case 0xa6: $sSane .= "&brvbar;"; break;
			case 0xa7: $sSane .= "&sect;"; break;
			case 0xa9: $sSane .= "&copy;"; break;
			case 0xab: $sSane .= "&laquo;"; break;
			case 0xae: $sSane .= "&reg;"; break;
			case 0xb0: $sSane .= "&deg;"; break;
			case 0xb1: $sSane .= "&plusmn;"; break;
			case 0xb2: $sSane .= "&sup2;"; break;
			case 0xb3: $sSane .= "&sup3;"; break;
			case 0xb5: $sSane .= "&micro;"; break;
			case 0xb9: $sSane .= "&sup1;"; break;
			case 0xbb: $sSane .= "&raquo;"; break;
			case 0xbc: $sSane .= "&frac14;"; break;
			case 0xbd: $sSane .= "&frac12;"; break;
			case 0xbe: $sSane .= "&frac34;"; break;
			case 0xd7: $sSane .= "&times;"; break;
			case 0xe2: $sSane .= "&trade;"; break;	// an anomaly in some charset conversions
			case 0xf7: $sSane .= "&divide;"; break;

			// MS Word cockups
			case 0x92: $sSane .= "&rsquo;"; break;	// '&#39;'

			default:
				if(($cChr >= ' ') && ($cChr < 0x7f)) {
					$sSane .= chr($cChr);
					} // if
	//			else {	// language char
	//				$sSane .= self:convert_language_char2html($cChr);
	//				} // else
				break;
				} // switch
			} // while

	// not good enough for the rubbish we get		$sSane = htmlentities($sStr,ENT_QUOTES);

		// remove some of silly things people do
		$sSane = str_replace("''", '&quot;', $sSane);
		$sSane = str_replace("&#039;&#039;", '&quot;', $sSane);
		$sSane = str_replace('&rsquo;&rsquo;', '&quot;', $sSane);
		$sSane = str_replace('&quot;&quot;', '&quot;', $sSane);
		$sSane = str_replace('&rsquo;', '&#039;', $sSane);
		// $sSane = str_replace('&amp;nbsp;', '&nbsp;', $sSane);

		if($cleanTail) {
			$chkOK = false;
			while(!$chkOK) {
				$chkOK = true;
				while(substr($sSane, -1, 1) == PHP_EOL) { $chkOK = false; $sSane = substr($sSane, 0, -1); }	// remove trailing \n
				while(substr($sSane, -4, 4) == "<br>") { $chkOK = false; $sSane = substr($sSane, 0, -4); }	// remove trailing <br>
				while(substr($sSane, -1, 1) == ' ') { $chkOK = false; $sSane = substr($sSane, 0, -1); }	// remove trailing spaces
				} // while
			} // if

		// $sSane = htmlentities($sSane,ENT_COMPAT,CMS_S_CHAR_SET);
		// $sSane = self::output_string_protected($sSane);
		// $sSane = nl2br($sSane);
		// $sSane = str_replace('&lt;br /&gt;','<br />',$sSane);
		$sSane = str_replace('<br />','<br>',$sSane);
		$sSane = str_replace('<br><br>','<br>',$sSane);
		$sSane = str_replace('><br>' . PHP_EOL,'>' . PHP_EOL,$sSane);
		$sSane = str_replace('><br>' . PHP_EOL,'>' . PHP_EOL,$sSane);

		return $sSane;
	} // sanitiseText4Html()

	public static function nl2br($str) {
		// a replacement for the PHP nl2br() function
		// which doesn't do as expected on '\n', only on PHP_EOL etc.
		$tmp = nl2br($str);	// do the "normal" replaces
		$pat = '/\\\\r\\\\n|\\\\n\\\\r|\\\\n|\\\\r/';
		$html = preg_replace($pat,'<br>',$tmp);
		return str_replace('\\','',$html);
		} // nl2br()

	public static function get_current_body_id($init = false) {
		if(self::is_cli()) return false; // @TODO why are we here in CLI
		$cms_body_id = false;
		if((!$init) && (self::$cms_body_id)) $cms_body_id = self::$cms_body_id;
		if(empty($cms_body_id)) {
			if(self::get_cms_sess_var('last_url')) {
				$u_vals = parse_url(self::get_cms_sess_var('last_url'));
				if(isset($u_vals['query'])) {
					if(preg_match('/(app|body)=([0-9a-zA-Z]+)/',html_entity_decode($u_vals['query']))) {
						$cms_body_id = preg_replace('/^.*(app|body)=([0-9a-zA-Z]+)&.+$/','$2',html_entity_decode($u_vals['query']));
						} // if
					} // if
				} // if
			else if(!$cms_body_id = self::get_or_post('app')) {
				$cms_body_id = self::get_or_post('body');
				} // else if
			} // if
		if((!empty($cms_body_id)) && ((int)$cms_body_id <= 0)) {	// a string app/body name
			$sql = 'SELECT cms_body_id FROM cms_bodies WHERE cms_body_name = \'' . $cms_body_id . '\' OR cms_body_dir = \'' . $cms_body_id . '\';';
			if(($result = self::$cDBcms->query($sql)) &&
				($cms_body = self::$cDBcms->fetch_array($result))) {
				$cms_body_id = $cms_body['cms_body_id'];
				} // if
			} // if
		return $cms_body_id;
		} // get_current_body_id()

	public static function get_current_body_uri($params = array()) {
		if(self::is_cli()) return ''; // @TODO why are we here in CLI
		$cms_body_id = self::get_current_body_id();
		// else $cms_body_id = self::get_or_post('body');
		if(empty($cms_body_id)) $uri = $_SERVER['PHP_SELF'];	// @TODO BAD a guess
		else $uri = Ccms::get_body_uri($cms_body_id);
		if(!empty($params)) {
			if(strpos($uri,'?')) $uri .= '&';
			else $uri .= '?';
			$uri .= (is_array($params) ? implode('&', $params):$params);
			} // if
		return $uri; // don't overcook	urlencode($uri);
		} // get_current_body_uri()

	public static function get_current_body_constant($type,$ws = false,$val = true,$inkvd = false) {
		$body_defines = Ccms_sm::get_bodies_defines();
		$id = false;
		if((empty($inkvd)) && (!empty(self::$cms_body_id))) {	// current body
			$id = self::$cms_body_id;
			} // if
		else if((!empty($inkvd)) &&	// else try to find it
			($body = self::get_body($inkvd))) {
			$id = $body['cms_body_id'];
			} // else if
		if(!empty($body_defines[$id]['constants'])) {
			$consts = &$body_defines[$id]['constants'];
			if(isset($consts[$type])) {
				if($ws) return $consts[$type]['ws'][($val ? 'val':'const')];
				else return $consts[$type]['fs'][($val ? 'val':'const')];
				} // if
			} // if
		return false;
		} // get_current_body_constant()

	public static function can_connect2host($host, $port, $tval = 15, $logit = true) {
		// set the error val to null so there is no confusion
		$error = null;
		$errstr = null;
		if((int)$tval < 1) $tval = 1;

		$h_p = parse_url($host);
		if(empty($port)) {
			if(!isset($h_p['port'])) {
				switch($h_p['scheme']) {
				case 'http':
					$port = 80;
					break;
				case 'https':
					$port = 443;
					break;
				case 'ssh':
					$port = 22;
					break;
				// and other possibilities
				default:
					return false;
					} // switch
				} // if
			else $port = $h_p['port'];
			} // if
		else if((isset($h_p['port'])) && ((int)$port != (int)$h_p['port'])) {
			// conflicted
			if($logit) {
				self::log_msg('Host "' . $host . '" has conflicting ports: ' . $port . ' and ' . $h_p['port']);
				} // if
			return false;
			} // else if
		if(isset($h_p['host'])) $host = $h_p['host'];
		else if(isset($h_p['path'])) $host = $h_p['path'];	// this appears to be a bug in PHP 7.2.14 if the host is numeric.
		else if(count($h_p) > 1) $host = false;
		if(empty($host)) return false;

		// connect to the server
		$conn = @fsockopen(
			$host,    // the host of the server
			$port,    // the port to use
			$errno,   // error number if any
			$errstr,  // error message if any
			$tval);   // give up after ? secs

		// verify we connected properly
		if(empty($conn)) {
			if($logit) {
				self::log_msg('Host: ' . $host . ':' . $port . ', failed to connect. ' . 'Err#' . $errno . ': ' . $errstr,'warn');
				} //if
			return false;
			} // if
		fclose($conn);
		return true;
		} // can_connect2host()

	private static function is_url_headers_ok(&$headers) {
		if(!$headers) {	// ssl self signed ???
			return false;
			} // if
		if(is_array($headers)) {
			foreach($headers as $l) {
				if(preg_match('/HTTP.+\s+200\s+OK/i',$l)) return true;
				} // foreach
			} // if
		else if(preg_match('/HTTP.+\s+200\s+OK/i',$headers)) return true;
		return false;
		} // is_url_headers_ok()

	protected static function get_chk_url($uri) {	// find the uri source
		if(empty($uri)) return false;
		if(preg_match('/http:|https/i',$uri)) {	// a remote host
			$headers = @get_headers($uri);
			if(self::is_url_headers_ok($headers)) return $uri;
			return false;
			} // if

		// check local
		// local on this web site
		$headers = @get_headers($uri);
		if(self::is_url_headers_ok($headers)) return $uri;

		// local on this host
		$url = self::get_base_url(true) . $uri;
		$headers = @get_headers($url);
		if(self::is_url_headers_ok($headers)) return $url;

		return false;
		} // get_chk_url()

// dynamic methods
	protected function log_http_access($type = 'access') {
		if(self::is_cli()) return false;	// not logged in CLI mode
		if((!CMS_C_LOG_ACCESS_ENABLE) && (!CMS_C_LOG_AJAX_ENABLE)) return false;
		if(self::$cms_access_logged) return false;
		self::$cms_access_logged = true;	// once only
			$access = 'ClientIP=' . Ccms_auth::get_client_ip_address();
		if(self::is_api()) {
			$access .= ',APIkey=' . Ccms_auth::get_client_ip_address();
			} // else
		if(!empty($_SERVER['HTTPS']))
			$access .= ',https=' . $_SERVER['HTTPS'];
		if(self::is_ajax()) {
			if(CMS_C_LOG_AJAX_ENABLE) {
				$access .= ',AJAX=' . self::get_ajax();
				} // if
			else return false;
			} // if
		else {
			$access .= ',Device=' . (self::is_tiny() ? 'tiny':(self::is_tablet() ? 'tablet':'desktop'));
			if(!empty($_SERVER['REQUEST_URI']))
				$access .= ',Request_URI="' . preg_replace('/(password|passwd)=.*$/i','XXXXXXXXXXXXXXX',$_SERVER['REQUEST_URI']) . '"';
			if(!empty(self::$cms_visitor_cnt))
				$access .= ',Visitor=' . self::$cms_visitor_cnt;
			} // else
//		if(self::is_debug()) {
//			if(!empty($_POST)) {
//				$access .= ',POST="' . rawurldecode(http_build_query($_POST)) . '"';
//				} // if
//			if(!empty($_FILES)) {
//				$access .= ',FILES="' . rawurldecode(http_build_query($_FILES)) . '"';
//				} // if
//			} // if
		return self::log_msg ($access, $type);
		} // log_http_access()

	public static function start_page_tidy_buffer() {
		if(!self::is_tidy()) return false;
		if(self::$cms_tidy_buffer) return true;	// already running
		if(ob_start()) {
			self::$cms_tidy_buffer = true;
			return true;
			} // if
		return false;
		} // start_page_tidy_buffer()

	private static function get_tidy_config() {
		// Specify configuration
		$config = array(
			'indent'        => true,
			'output-html'  => true,
			// 'output-xhtml'  => true,
			'wrap'          => 2000,
			'tab-size'		=> 2,
			'uppercase-tags' => true,
			//'newline' =>	true,
			);
		return $config;
		} // get_tidy_config()

	public static function output_page_tidy_buffer() {
		if(self::$cms_tidy_buffer) {
			self::$cms_tidy_buffer = false;
			// see "https://www.php.net/manual/en/tidy.examples.basic.php"
			$html = ob_get_clean();
			if(empty($html)) return false;

			// Tidy
			$tidy = new tidy;
			$tidy->parseString($html, self::get_tidy_config(), 'utf8');
			$tidy->cleanRepair();

			// $opts = $tidy->getConfig();	// for debug

			if($err = tidy_get_error_buffer($tidy)) {
				self::log_error(PHP_EOL . $err);
				if(self::is_debug()) {
					self::file_safe_write(VAR_FS_TEMP_DIR . 'tidy_errors.html', $html . PHP_EOL . $err . PHP_EOL,true,10);
					} // if
				} // if
			else @unlink(VAR_FS_TEMP_DIR . 'tidy_errors.html');

			// Output
			echo $tidy;
			return true;
			} // if
		return false;
		} // output_page_tidy_buffer()

	public static function get_pretty_html_doc(&$text,$bodyOnly = true) {
		// see "https://www.php.net/manual/en/tidy.examples.basic.php"
		if(!self::is_tidy()) return $text;	// tidy not installed

		if(($bodyOnly) && (!preg_match('/<html|<head|<body/im',$text))) {
			// just basic html text
			$tmp = '<!DOCTYPE><html><head></head><body>' . PHP_EOL . $text . PHP_EOL . '</body></html>';
			$text = $tmp;
			} // if
		// Tidy
		$tidy = new tidy;
		$tidy->parseString($text, self::get_tidy_config(), 'utf8');
		$tidy->cleanRepair();

		// Output
		if($bodyOnly) {
			$body = $tidy->body();
			$html = preg_replace('/<body>|<\/body>/im','',$body->value);
			return $html;
			} // if
		else $html = $tidy->html();
		return $html->value;
		} // get_pretty_html_doc()

	protected static function get_group_manager_ids(&$user_admin,&$user_group_ids) {
		if($user_admin)  return '';
		// check if in an admin group
		$group_ids = explode(':',$user_group_ids);
		$group_manager_ids = array();
		foreach($group_ids as $gid) {
			// check if an admin
			$admin = self::$cDBcms->get_data_in_table('cms_groups','cms_group_admin','cms_group_id = ' . $gid);
			if($admin) {
				$user_admin = true;
				break;
				} // if
			// check if a group manager
			$manager_ids = self::$cDBcms->get_data_in_table('cms_groups','cms_group_admin_ids','cms_group_id = ' . $gid);
			if($manager_ids === false) continue;
			$mids = explode(':',$manager_ids);
			if(in_array($gid, $mids)) $group_manager_ids[] = $gid;
			} // foreach
		if((!$user_admin) && (count($group_manager_ids) > 0)) {
			$user_group_manager_ids = implode(':', $group_manager_ids);
			return $user_group_manager_ids;
			} // if
		return $group_manager_ids;	// @TODO check this
		} // get_group_manager_ids()

} // Ccms_base
