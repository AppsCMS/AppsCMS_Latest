<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_filtered_links.php 2996 2022-11-23 02:43:02Z robert0609 $
 */

global $lm_sections_links_urls;
$lm_sections_links_urls = array();

?>
<?php Ccms::page_start_comment(__FILE__) ?>
<table class="page_body">
	<caption>The page contents</caption>
	<?php if(Ccms::getMsgsCount()) { ?>
	<tr class="page_body_msgs">
		<td class="page_body_msgs">
			<?= Ccms::getMsgsTable() ?>
		</td>
	</tr>
	<?php } //if ?>
<?php

$layout_data = Ccms_lm_filter::find_sections_links_layout(
	array(
		'section' => array(
			'enabled' => 1,
			'keywords' => false,
			),
		'link' => array(
			'enabled' => 1,
			'keywords' => false,
			),
		),true,false);	// generates a heirachical array of required links

global $lm_section_ids,$lm_section_cnt,$links_cnt,$link_row_cnt;
if(!$lm_section_ids = Ccms_base::get_cms_sess_var('lm_section_states'))
	$lm_section_ids = array();

$lm_section_cnt = 0; $links_cnt = 0; $link_row_cnt = 0;

function draw_links($section,$links) {
	global $links_cnt,$link_row_cnt,$lm_sections_links_urls;
?>

						<table class="link_body">
							<caption>Links for <?= $section['lm_section_name'] ?></caption>
							<tr class="link_body <?= (($link_row_cnt++ & 1) ? 'link_body_odd':'link_body_even')?>" valign="top" style="text-align: center;">
								<td class="link_body">
<?php
						// $lm_sections_links_urls[($section['lm_section_id'])]['section'] = $section;
						// $lm_sections_links_urls[($section['lm_section_id'])]['links'] = $links;
						$lm_sections_links_urls[($section['lm_section_id'])]['links'] = array();
						$lm_sections_links_urls[($section['lm_section_id'])]['name'] = $section['lm_section_name'];
						$open_links = &$lm_sections_links_urls[($section['lm_section_id'])]['links'];
						$cell_width = (int)(100/(empty($section['lm_section_columns']) ? 2:$section['lm_section_columns'])) - 2;
						$cnt = 0;
						$columns = 0;
						foreach($links as $l_id => $lk) {
							if(!is_numeric($l_id)) continue;	// skip over section data
							$open_links[$l_id]['uri'] = $lk['data']['lm_link_url'];
							$open_links[$l_id]['name'] = $lk['data']['lm_link_name'];
							$open_links[$l_id]['add_name'] = $lk['data']['lm_link_add_name2url'];
							$links_cnt++;
							$columns++;
							$cnt++;
							$link = $lk['data'];
							echo '									' .
								'<span class="link_body ' . (($link_row_cnt & 1) ? 'link_body_odd':'link_body_even') . '" style="min-width: ' . $cell_width . '%">' . Ccms::get_link_html($link) . '</span>' . PHP_EOL;
							if($columns >= $section['lm_section_columns']) {
								$columns = 0;
								} // if
							} // foreach
//						while($columns < $section['lm_section_columns']) {	// finish last row
//							echo '<div class="link_body_mt" style="min-width: ' . $cell_width . '%">&nbsp;</div>' . PHP_EOL;
//							$columns++;
//							} // while

?>
								</td>
							</tr>
<?php
						if(!$cnt) echo '<tr class="link_body"><td colspan="' . $section['lm_section_columns'] . '" class="link_body" style="text-align: left">(No links available in this section)</td></tr>' . PHP_EOL;
?>
						</table>
<?php
	} // draw_links()

function draw_section($sect, &$lm_section_ids,$sect_ids_tree = array()) {
	global $lm_section_cnt,$links_cnt,$link_row_cnt;
	if(empty($sect)) return;
	if((empty($sect['links'])) && (empty($sect['sections']))) return;	// MT
	if(empty($sect['data'])) {
		if(!empty($sect['sections'])) {
			foreach($sect['sections'] as $s_cid => $sect_child) {
				if(!is_numeric($s_cid)) continue;
				if(empty($sect_child)) continue;
				draw_section($sect_child,$lm_section_ids);	// recurse
				} // foreach
			} // if
		return;
		} // if

	$section = $sect['data'];
	$lm_section_cnt++;
	$sect_ids_tree[] = $section['lm_section_id'];
	if(!isset($lm_section_ids[($section['lm_section_id'])]))
		$lm_section_ids[($section['lm_section_id'])] = array('state' => 'down');

	if((empty($section)) || (empty($section['lm_section_name']))) return;

	if(LM_C_SHOW_SECT_COLL_EXP_BUTTON) {
		if($lm_section_ids[($section['lm_section_id'])]['state'] != 'down') {
	//		$state = ' data-sect-state="up" style="max-height: 0px;"';
	//		$state = ' data-sect-state="up" style="display: none; overflow: auto;"';
			$state = ' data-sect-state="up" style="display: none;"';
			$sbimg = 'cms/images/DbChevDn.gif';
			$sbalt = 'down';
			$open_btn_sty = 'background-color: inherit; display: none;';
			} // if
		else {
	//		$state = ' data-sect-state="down" style="max-height: 100vh;"';
	//		$state = ' data-sect-state="down" style="display: block; overflow: auto;"';
			$state = ' data-sect-state="down" style="display: block;"';
			$sbimg = 'cms/images/DbChevUp.gif';
			$sbalt = 'up';
			$open_btn_sty = 'background-color: inherit;';
			} // else
		} // if
	else {
	//	$state = ' style="display: block; overflow: auto;"';
		$state = ' style="display: block;"';
		$open_btn_sty = 'background-color: inherit;';
		} // else


?>
	<table>
		<caption>Section <?= $section['lm_section_name'] ?></caption>
		<tr class="section_body">
			<td class="section_body">
				<table class="section_body">
					<tr class="section_body">
						<td class="section_body">
							<table>
								<caption>Link Section</caption>
								<?php
								if(LM_C_SHOW_SECT_COLL_EXP_BUTTON) {
									$js_sect_col_event = '"toggle_lm_roll_sect_links(event,this,\'' .
										$section['lm_section_id'] . '\',\'' . implode(':',$sect_ids_tree) . '\');"';
									$js_click_sect_col_event = ' onclick=' . $js_sect_col_event;
									$js_mouseup_sect_col_event = ' onmouseup=' . $js_sect_col_event;
									} // if
								else {
									$js_click_sect_col_event = '';
									$js_mouseup_sect_col_event = '';
									} // else
								?>
								<tr class="section_body" <?= $js_click_sect_col_event ?>>
									<td class="section_body" style="text-align: left; width: <?= ((int)CMS_C_SMALL_IMAGE_HEIGHT * 3) ?>px;">
										<?php
											if((Ccms_auth::is_cms_admin_user()) && (LM_C_SHOW_CONF_LINKS)) {
												echo '<a href="index.php?cms_action=cms_edit_sections&section_edit_id=' . $section['lm_section_id'] . '&cms_return_action=lm_show_links"';
												echo ' title="Configure section,">';
												echo '<img class="lm_cog" src="' . CMS_WS_ICONS_DIR . 'cog.gif" alt="cog"/>';
												echo '</a>' . PHP_EOL;
												} // if
											echo Ccms::get_section_image_uri($section);
										?>
									</td>
									<th class="section_body" style="text-align: left">
										<h2<?= (!empty($section['lm_section_title']) ? ' title="' . strip_tags($section['lm_section_title']) . '"':'') ?>>
											<?= $section['lm_section_name'] ?>
										</h2>
									</th>
									<td class="section_body" style="text-align: left">
<?php							if(!empty($section['lm_section_description'])) { ?>
									<small><?= $section['lm_section_description'] ?></small>
<?php								} else echo '&nbsp;' ?>
<?php							if((!empty($section['lm_section_comments'])) && (Ccms_auth::is_cms_admin_user())) {
									echo '&nbsp;' . Ccms::getSimpleNotesDD($section['lm_section_comments'],'Comments:');
									} // if
?>
									</td>
									<td class="section_body" style="text-align: right">
<?php							if((LM_C_SHOW_SECT_OPEN_ALL_BUTTON) && (!empty($sect['links']))) { ?>
										<label style="display: inline-block;">
											<button id="id_btn_lm_open_tabs_sect_links_<?= $section['lm_section_id'] ?>"
													onmouseup="open_lm_tabs_sect_links(event,this,'<?= $section['lm_section_id'] ?>','<?= implode(':',$sect_ids_tree) ?>');"
													style="<?= $open_btn_sty;?>"
													title="Open section links in tabs."
													>
												Open All
											</button>
											&nbsp;
										</label>
<?php								} // if ?>
<?php							if(LM_C_SHOW_SECT_COLL_EXP_BUTTON) { ?>
										<label style="display: inline-block;">
											<button id="id_btn_lm_roll_sect_links_<?= $section['lm_section_id'] ?>"
													<?= $js_mouseup_sect_col_event ?>
													style="background-color: inherit;"
													title="Roll up / down section."
													>
												<img src="<?= $sbimg ?>" alt="<?= $sbalt ?>" style="height: 12px;">
											</button>
										</label>
<?php								} // if ?>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr class="section_body">
						<td class="section_body" style="overflow: hidden;">
<?php

	echo '			<span id="id_div_sect_links_' . $section['lm_section_id'] . '"' . $state . '>' . PHP_EOL;
	if(!LM_C_SHOW_SECT_CHILD_2ND) {
		if(!empty($sect['sections'])) {
			foreach($sect['sections'] as $s_cid => $sect_child) {
				if(!is_numeric($s_cid)) continue;
				if(empty($sect_child)) continue;
				draw_section($sect_child,$lm_section_ids,$sect_ids_tree);	// recurse
				} // foreach
			} // if

		if(isset($sect['links'])) {
			draw_links($section,$sect['links']);
			} // if
		} // if
	else {
		if(isset($sect['links'])) {
			draw_links($section,$sect['links']);
			} // if

		if(!empty($sect['sections'])) {
			foreach($sect['sections'] as $s_cid => $sect_child) {
				if(!is_numeric($s_cid)) continue;
				if(empty($sect_child)) continue;
				draw_section($sect_child,$lm_section_ids,$sect_ids_tree);	// recurse
				} // foreach
			} // if
		} // else

	echo '			</span>' . PHP_EOL;

		?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
<?php
	} // draw_section()

if(!empty($layout_data['sections'])) {
	foreach($layout_data['sections'] as $s_id => $sect) {
		if(!is_numeric($s_id)) continue;
		if((empty($sect['links'])) && (empty($sect['sections']))) continue;	// MT
		echo '<tr><td>';
		draw_section($sect,$lm_section_ids);
		echo '</td></tr>';
		} // foreach
	} // if

if(!$lm_section_cnt) {
?>
	<tr class="page_body">
		<td class="page_body" style="text-align: center;">
			(No results found.)
		</td>
	</tr>
<?php	} // if
else if(LM_C_FILTER_STAT) {
?>
	<tr class="page_body">
		<td class="page_body" style="text-align: right;">
<?php
		echo 'Total of ' . $lm_section_cnt . (($lm_section_cnt > 1) ? ' sections':' section') , ' with ' . $links_cnt . (($links_cnt > 1) ? ' links.':' link.');
?>
		</td>
	</tr>
<?php	} // if ?>

</table>

<script type="text/javascript">

	var lm_section_ids = <?= Ccms_base::json_encode($lm_section_ids) ?>;
	var lm_section_cnt = <?= $lm_section_cnt ?>;
	var lm_section_links_urls = <?= Ccms_base::json_encode($lm_sections_links_urls) ?>;

</script>


<?= Ccms::page_end_comment(__FILE__) ?>
