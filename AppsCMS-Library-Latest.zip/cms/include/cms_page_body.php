<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_body.php 3270 2023-03-14 10:47:54Z robert0609 $
 */
function do_common_actions($action) {
	switch($action) {
	case 'readme':
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['readme'])) {
			$readme = $tla['readme'];
			Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $readme,$tla['h1'] . ' - README.');
			} // if
		break;
	case 'release_notes':
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['release_notes'])) {
			$release_notes = $tla['release_notes'];
			Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $release_notes,$tla['h1'] . ' - Release Notes.');
			} // if
		break;
	case 'cookies':
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['cookies'])) {
			$cookies = $tla['cookies'];
			Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $cookies,$tla['h1'] . ' - Cookies');
			} // if
		break;
	case 'terms':
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['terms'])) {
			$terms = $tla['terms'];
			Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $terms,$tla['h1'] . ' - Terms and Conditions.');
			} // if
		break;
	case 'licence':
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['licence'])) {
			$licence = $tla['licence'];
			Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $licence,$tla['h1'] . ' - Licence.');
			} // if
		break;
	case 'acknowledgement':
		$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
		if(!empty($tla['acknowledgement'])) {
			$acknowledgement = $tla['acknowledgement'];
			Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $acknowledgement,$tla['h1'] . ' - Acknowledgement.');
			} // if
		break;
	default:
		return false;	// not me
		break;
		}
	return true;	// was mine
	} // do_common_actions()
	
Ccms::page_start_comment(__FILE__);

switch(Ccms::get_app_action()) {
case 'login':
case 'cms_login':
	if(Ccms_base::is_cms_user()) {
		// already logged in
		Ccms::get_app_action(false);
		} // if
	Ccms::get_cms_action('cms_login');	// change over
	break;
case 'lm_show_links':
	Ccms::get_cms_action('lm_show_links');	// change over
	break;

case 'home':
default:
	if(do_common_actions(Ccms::get_app_action())) break;
	if((Ccms_base::is_cms_action()) || (Ccms_base::is_page_done())) break;
	else if((LM_C_USE_LM_AS_HOME) &&
		(empty(Ccms::$cms_body_id)) &&
		(Ccms_sm::is_links_manager_inuse())) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_lm.php");
		Ccms_base::is_page_done(true);
		break;
		} // if
	else if($path = Ccms::get_home_filepath()) {
		if(!empty(Ccms::$cms_body_id)) {
			Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
			} // if
		else Ccms::output_include_body_text($path);
		Ccms_base::is_page_done(true);
		break;
		} // if
//	else if((empty(Ccms::get_app_action())) &&
//		(empty(Ccms::$cms_body_id))) {
//		$path = Ccms::get_home_filepath();
//		Ccms::output_include_body_text($path);
//		Ccms_base::is_page_done(true);
//		break;
//		} // if
	// fall thru to 'body'
case 'app':
case 'body':
	// gotcha
	if((!Ccms::get_cms_action()) && (!empty(Ccms::$cms_body_id))) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
		} // if
	break;
case 'app_extend':
case 'body_extend':
	$idx = Ccms::get_or_post('idx');
	$cms_app_name = Ccms::get_or_post('app_name');
	if($uri = Ccms_apps::get_body_extend_uri($cms_app_name,$idx)) {
		if((!empty($uri['func'])) && ($callback = Ccms::get_inc_method_callback($uri['func']))) {
			Ccms::output_include_body_text($uri['func']);
			} // if
		else Ccms::addAdminMsg ('Failed to engage body_extension function: app_name=' . $cms_app_name . ', idx=' . $idx);
		} // if
	break;
	} // switch

switch(Ccms::get_cms_action()) {
case 'cms_login':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_login.php",array('user_name'),true,false);
	break;
case 'no_cookie':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_no_cookie.php",'',false,false);
	break;
case 'get_password':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_get_password.php",array('user_name'));
	break;
case 'get_verification':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_verification_form.php",[],false,false);
	break;
case 'get_eula':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_eula_form.php",array('user_name'),false,false);
	break;
case 'cms_edit_tools':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_tools.php");
		} // if
	break;
case 'cms_edit_bodies':
	if(Ccms_auth::is_config_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_bodies.php");
		} // if
	break;
case 'cms_edit_header_footer':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_header_footer.php");
		} // if
	break;
case 'cms_edit_sections':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_sections.php");
		} // if
	break;
case 'cms_edit_links':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_links.php");
		} // if
	break;
case 'cms_edit_groups':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_group.php");
		} // if
	break;
case 'cms_edit_users':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_users.php");
		} // if
	break;
case 'cms_edit_search':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_search.php");
		} // if
	break;
case 'cms_edit_config':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_config.php");
		} // if
	break;
case 'cms_edit_install':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_install.php");
		} // if
	break;
case 'cms_edit_apps':
	if(Ccms_apps::is_ini_congurable()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_apps.php");
		} // if
	break;
case 'cms_edit_theme':
	if(Ccms_auth::is_cms_admin_user()) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_edit_theme.php");
		} // if
	break;
case 'lm_show_links':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_lm.php");
	break;
case 'link':
	if(((int)Ccms::$lm_link_id > 0) &&
		($link = Ccms::$cDBcms->get_data_in_table('lm_links','lm_link_url,lm_link_ssl,lm_link_title','lm_link_id = ' . (int)Ccms::$lm_link_id))) {
		$url = $link['lm_link_url'];
		$https = $link['lm_link_ssl'];
		$title = Ccms::get_link_title($link);
		Ccms::output_link_or_tool_text($url, $title, $https);
		} // if
	else Ccms::output_include_body_text("pages/default.php");
	break;
case 'tool':
	if(((int)Ccms::$cms_tool_id > 0) &&
		($tool = Ccms::$cDBcms->get_data_in_table('cms_tools','cms_tool_url,cms_tool_ssl,cms_tool_title,cms_tool_copyright,cms_tool_include',
			'cms_tool_id = ' . (int)Ccms::$cms_tool_id . (Ccms::is_debug() ? "":" AND cms_tool_debug_only = 0")))) {
		$url = $tool['cms_tool_url'];
		$https = $tool['cms_tool_ssl'];
		$title = $tool['cms_tool_title'];
		if(!$tool['cms_tool_include']) {
			Ccms::output_link_or_tool_text(LOCAL_WS_TOOLS_DIR . $url, $title, $https);
			} // if
		else {
			Ccms::output_include_body_text(LOCAL_FS_TOOLS_DIR . $url, $title);
			} // else
		} // if
	else Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
	break;

case 'update_sitemap':
	// if(Ccms_auth::is_cms_admin_user()) {
		new Ccms_xml_sitemap();
	//	} // if
case 'show_sitemap':	// make sure there is a site map
	if(Ccms_xml_sitemap::get_html_sitemap_file()) Ccms::get_cms_action('show_sitemap');
	else {
		// @TODO empty, do something
		} //else
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_show_sitemap.php");
	break;

case 'disclaimer':
	if(strlen(CMS_C_CUSTOM_FOOTER_LINK) <= 4) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . 'cms_disclaimer.tmpl.php');
		}
	else Ccms::output_link_or_tool_text(CMS_C_CUSTOM_FOOTER_LINK,CMS_C_TITLE);
	break;
case 'privacy':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['privacy'])) {
		$privacy = $tla['privacy'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $privacy,$tla['h1'] . ' - Privacy.');
		} // if
	break;
case 'aboutus':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['aboutus'])) {
		$aboutus = $tla['aboutus'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $aboutus,$tla['h1'] . ' - About Us.');
		} // if
	break;

case 'cookies':
	$tla = Ccms::get_releasenotes_terms_licence_ack_uris();
	if(!empty($tla['cookies'])) {
		$cookies = $tla['cookies'];
		Ccms::output_include_legal_text(DOCROOT_FS_BASE_DIR . $cookies,$tla['h1'] . ' - Cookies');
		} // if
	break;

case 'cms_version':
	Ccms::output_include_body_text(CMS_FS_DIR . "AppsCMS-version.info",'',false);
	break;

case 'home':
default:
	if(do_common_actions(Ccms::get_cms_action())) break;
	if((Ccms_base::is_apps_action()) || (Ccms_base::is_page_done())) break;
	else if((LM_C_USE_LM_AS_HOME) &&
		(empty(Ccms::$cms_body_id)) &&
		(Ccms_sm::is_links_manager_inuse())) {
		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_lm.php");
		Ccms_base::is_page_done(true);
		break;
		} // if
	else if($path = Ccms::get_home_filepath()) {
		if(!empty(Ccms::$cms_body_id)) {
			Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
			} // if
		else Ccms::output_include_body_text($path);
		Ccms_base::is_page_done(true);
		break;
		} // if
//	else if((empty(Ccms::get_app_action())) &&
//		(!empty(Ccms::$cms_body_id))) {
//		Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_body.php");
// 		Ccms_base::is_page_done(true);
//		break;
//		} // if
	break;
case 'cms_about':
	$params = array(
		'inc_file_or_func_or_text' => CMS_FS_OPS_DIR . "cms_about.php",
		'more_globals_ary' => '',
		'inc_top_msgs' => false,
		'inc_bot_msgs' => true,
		'is_common_content' => true,
		'cacheit' => true,
		);
	Ccms::output_include_body_text($params);
	break;
case 'cms_manual':
	$params = array(
		'inc_file_or_func_or_text' => CMS_FS_OPS_DIR . "cms_manual.php",
		'more_globals_ary' => '',
		'inc_top_msgs' => false,
		'inc_bot_msgs' => true,
		'is_common_content' => true,
		'cacheit' => true,
		);
	Ccms::output_include_body_text($params);
	break;
case 'app_manual':
	if(($cms_body_id = (Ccms::$cms_body_id ? Ccms::$cms_body_id:Ccms::get_or_post('body'))) &&	// single application manual
		($body = Ccms::$cDBcms->get_data_in_table('cms_bodies',array('cms_body_dir','cms_body_manual_url'),'cms_body_id = ' . (int)$cms_body_id))) {
		$uri = APPS_FS_DIR . $body['cms_body_dir'] . '/docs/' . $body['cms_body_manual_url'];
		if(file_exists($uri)) {
			Ccms::output_include_body_text($uri,'',false);	// application manual
			} // if
		} // IF
	break;
case 'apps_manual':
	Ccms::output_include_body_text(APPS_FS_APPS_MANUAL,'',false);	// all applications manual
	break;
case 'admin_extend':
	$idx = Ccms::get_or_post('idx');
	$cms_app_name = Ccms::get_or_post('app_name');
	if($uri = Ccms_apps::get_admin_extend_uri($cms_app_name,$idx)) {
		if((!empty($uri['func'])) && ($callback = Ccms::get_inc_method_callback($uri['func']))) {
			Ccms::output_include_body_text($uri['func']);
			} // if
		else Ccms::addAdminMsg ('Failed to engage admin_extension function: app_name=' . $cms_app_name . ', idx=' . $idx);
		} // if
	break;
case 'cms_debug_vars':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_debug_vars.php");
	break;
case 'cms_debug_code':
	if((defined('CMS_S_CODE_DEBUG_TEST_URI')) && (CMS_S_CODE_DEBUG_TEST_URI) &&
		(file_exists(DOCROOT_FS_BASE_DIR . CMS_S_CODE_DEBUG_TEST_URI))) {
		if(!CMS_S_CODE_DEBUG_TEST_NTAB_BOOL) {
			if(CMS_S_CODE_DEBUG_TEST_IFRM_BOOL) {
				$url = Ccms_base::get_base_url(true) . CMS_S_CODE_DEBUG_TEST_URI;
				Ccms::output_link_or_tool_text($url,CMS_C_TITLE);
				} // if
			else {
				Ccms::output_include_body_text(DOCROOT_FS_BASE_DIR . CMS_S_CODE_DEBUG_TEST_URI);
				} // else
			} // if
		} // if
	break;
case 'cms_api_test':
	if(CMS_C_API_ENABLE) {	// API enabled
		Ccms::output_link_or_tool_text(CMS_WS_LIB_DIR . 'swagger/swagger.php', CMS_C_TITLE, (Ccms::is_ssl_required() ? true:false));
		} // if
	break;
case 'cms_log_view':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_log_view.php");
	break;
case 'cms_browse_sessions':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_session_browser.php");
	break;
case 'cms_users_stats':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_users_stats.php");
	break;
case 'cms_text_view':
	Ccms::output_include_body_text(CMS_FS_OPS_DIR . "cms_text_view.php");
	break;
case 'show_sitemap':
	$params = array(
		'inc_file_or_func_or_text' => CMS_FS_OPS_DIR . "cms_show_sitemap.php",
//		'more_globals_ary' => '',
//		'inc_top_msgs' => true,
//		'inc_bot_msgs' => true,
		'cacheit' => true,
		);
	Ccms::output_include_body_text($params);
	break;
	} // switch

Ccms::reset_session_actions(array('body','tool'));

Ccms::page_end_comment(__FILE__);
