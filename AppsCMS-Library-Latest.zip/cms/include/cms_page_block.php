<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_block.php 3157 2023-02-16 03:30:11Z robert0609 $
 */

Ccms::page_start_comment(__FILE__);

?>

	<!--Block Mode-->
	<!--Recommended for desktop devices, has a fixed header and footer.-->

<?php if (!empty($frm_id)) { ?>
	<script type="text/javascript">
		function cms_onloadIframe(ent,obj) { // here when loads initially and on every iframe reload in block style
			var link_frame = document.getElementById('lm_link_frame');
			if(link_frame)
				obj.style.height = link_frame.offsetHeight;
			} // cms_onloadIframe()
	</script>
<?php	} // if ?>

	<div class="cms_lo_page_block" id="cms_lo_page_block">
<?php if(CMS_S_HEADER_BOOL) { ?>
		<div class="cms_lo_header" id="cms_lo_header">
			<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_header.php',false,CMS_C_PAGE_HEADER_CACHED) ?>
		</div>
<?php	} // if ?>

<?php if(Ccms::show_nav_bar()) { ?>
		<div class="cms_lo_nav_bar cms_nav_bar" id="cms_lo_nav_bar">
			<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_nav_bar.php',false,CMS_C_NAVBAR_CACHED) ?>
		</div>
<?php	} // if ?>

		<div class="cms_lo_middle cms_lo_page_width" id="cms_lo_middle">
<?php	if(Ccms::show_left_column()) { ?>
			<div class="cms_lo_left_column" id="cms_lo_left_column">
				<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_left_column.php',true,CMS_C_LEFT_COLUMN_CACHED) ?>
			</div>
<?php		} // if ?>

			<div class="cms_lo_body_column " id="cms_lo_body_column"
				<?php echo (Ccms::is_drag_drop_used() ? ' ondragover="javascript:cms_drag_over(event);" ondrop="javascript:cms_drop(event);"':'') ?>>
				<?php include CMS_FS_INCLUDES_DIR . 'cms_page_body.php' ?>
			</div>

<?php	if(Ccms::show_right_column()) { ?>
			<div class="cms_lo_right_column" id="cms_lo_right_column">
				<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_right_column.php',true,CMS_C_RIGHT_COLUMN_CACHED) ?>
			</div>
<?php		} // if ?>
		</div>

<?php	if(CMS_S_FOOTER_BOOL) { ?>
		<div class="cms_lo_footer" id="cms_lo_footer">
			<?php Ccms_content_cache::cache_content(CMS_FS_INCLUDES_DIR . 'cms_page_footer.php',false,CMS_C_PAGE_FOOTER_CACHED) ?>
		</div>
<?php		} // if ?>
	</div>

<?php
Ccms::page_end_comment(__FILE__);

