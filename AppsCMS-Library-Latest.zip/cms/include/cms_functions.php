<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_functions.php 3370 2023-07-20 10:36:13Z robert0609 $
 */

// used to define functions that are not present in older version of PHP (particularly pre 8.1)

if(!function_exists('array_key_first')) {
	function  array_key_first($array) {	// int|string|null
		if(!is_array($array)) return null;
		$keys = array_keys($array);
		return $keys[0];
		} // array_key_first()
	} // if

if(!function_exists('openssl_pkey_free')) {
    return cms_openssl_pkey_free($privKey);
     } // if

function cms_openssl_pkey_free($privKey) {
    return false; // does not do anything anyway
    } // if

if(!function_exists('strftime')) {
    function strftime($fmt,$time) {
        return cms_strftime($fmt, $time);
		} // strftime()
    } // if

function cms_strftime($fmt,$time) {
        return date($fmt,$time);
    } // if

if(!function_exists('mysql_escape_string')) {
    function mysql_escape_string($str) {
        return mysqli_prepare($str);
		} // strftime()
    } // if

// EOF

