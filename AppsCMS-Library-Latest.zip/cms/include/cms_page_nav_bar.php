<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_nav_bar.php 3254 2023-03-03 07:17:12Z robert0609 $
 */


if(!Ccms::show_nav_bar()) return;

global $navbar_prefix, $menu_only;
if(!isset($navbar_prefix)) $navbar_prefix = '';
if(!isset($menu_only)) $menu_only = false;

$nav_bar_grid = Ccms::get_navbar_grid($menu_only);

if((Ccms::is_hover_boxes_ok()) && 
	(!preg_match('/login/i',self::get_cms_action() . ' ' . self::get_app_action()))) {

	$show_all = false;	// Ccms_base::is_debug();

	if(Ccms::get_body_cnt() > 0) {	// put tools drop down in here
		if(((!Ccms::is_drop_down_menu_apps_in_header()) || ($show_all)) &&
			(!Ccms_base::is_on_navbar($nav_bar_grid, 'menu=apps')) &&
			(!Ccms_base::is_on_navbar($nav_bar_grid, 'id_body_'))) {
			$apps_grid = array('menu=apps','','');
			if(preg_match('/left/i', CMS_S_NAV_BAR_LINKS_POSITION)) $nav_bar_grid = array_merge (array($apps_grid),$nav_bar_grid);
			else  $nav_bar_grid = array_merge ($nav_bar_grid,array($apps_grid));
			} // if
		} // if

	if(Ccms::get_tool_cnt(true) > 0) {	// put tools drop down in here
		if(((!Ccms::is_drop_down_menu_tools_in_header()) || ($show_all)) &&
			(!Ccms_base::is_on_navbar($nav_bar_grid, 'menu=tools')) &&
			(!Ccms_base::is_on_navbar($nav_bar_grid, 'id_tool_'))) {
			$tool_grid = array('menu=tools','','');
			if(preg_match('/left/i', CMS_S_NAV_BAR_LINKS_POSITION)) $nav_bar_grid = array_merge (array($tool_grid),$nav_bar_grid);
			else  $nav_bar_grid = array_merge ($nav_bar_grid,array($tool_grid));
			} // if
		} // if

	if(Ccms_base::is_cms_group_manager()) {	// put admin drop down in here
		if(((!Ccms::is_drop_down_menu_admin_in_header()) || ($show_all)) &&
			(!Ccms_base::is_on_navbar($nav_bar_grid, 'menu=admin'))) {
			if(!Ccms::is_drop_down_menu_admin_in_header()) {	// if not in header
				$admin_grid = array('menu=admin','','');
				if(preg_match('/left/i', CMS_S_NAV_BAR_LINKS_POSITION)) $nav_bar_grid = array_merge (array($admin_grid),$nav_bar_grid);
				else  $nav_bar_grid = array_merge ($nav_bar_grid,array($admin_grid));
				} // if
			} // if
		} // if
	
	} // if

$liw_text = '';
$ul_text = '';
$i_cnt = count($nav_bar_grid) + 1;
//if(count($nav_bar_grid) > 0) {
	if(strlen(CMS_S_NAV_BAR_LINKS_POSITION) > 2) {
		$lw = CMS_S_NAV_BAR_LINKS_POSITION;
		if(Ccms::is_full_body_view()) {
			if(preg_match('/[0-9]px|[0-9]%/i', $lw)) $liw_text = ' style="text-align: center;"';
			} // if
		else {
			if(preg_match('/right/i', $lw)) {
				$ul_text = ' style="float: right; justify-content: flex-end;"';
				$liw_text = ' style="text-align: center;"';
				} // if
//			else if(preg_match('/center|centre/i', $lw)) {
//				$ul_text = ' style="text-align: center;'; ?????
//				$liw_text = ' style="text-align: center;"';
//				} // if
			else if(preg_match('/left/i', $lw)) {
				$ul_text = ' style="float: left;"';
				$liw_text = ' style="text-align: center;"';
				} // if
			else if(preg_match('/even|spread/i', $lw)) {
				$w = (int)((100 - 2 - $i_cnt)/($i_cnt + 1));	// - 2 - $i_cnt to stop wrapping
				$ul_text = ' style="justify-content: center;"';
				$liw_text = ' style="text-align: center; margin-left: auto;	margin-right: auto;"';
				} // if
			else if(preg_match('/[0-9]px|[0-9]%/i', $lw)) $liw_text = ' style="text-align: center;"';
			} // else
		} // if
//	} // if
	$cur_uri = basename($_SERVER['REQUEST_URI']);

	Ccms::page_start_comment(__FILE__);
	if((CMS_S_NAV_BAR_RIGHT_BOOL) && 
		(!Ccms::is_tiny()) && 
		(!Ccms::is_tablet())) {
		echo '<div style="float: right;">' . PHP_EOL;
		$rln = true;
		} // if
	else $rln = false;	// stop wasted on tiny devs

?>
<!--<div class="cms_nav_bar">-->
	<ul class="<?= $navbar_prefix ?>cms_nav_bar"<?= $ul_text ?>>
<?php

	$uris = Ccms::get_ws_links_options();
	// $uris_txt = print_r($uris,true);	// debug

	$db_done = array();
	for($i = 0;$i < $i_cnt; $i++) {
		if(!isset($nav_bar_grid[$i])) continue;
		$gr = $nav_bar_grid[$i];
		$lk = (isset($gr[0]['uri']) ? $gr[0]['uri']:$gr[0]);

		$menu = preg_replace('/^menu=([\S]+)$/','$1',$lk);
		switch($menu) {
		case 'admin':	// admin drop box
			$admin = Ccms::get_admin_menu('left','Admin');
			if(empty($admin)) continue 2;
			$icon = Ccms_html::get_navbar_icon_text('Admin');
			$text = Ccms_drop_box::hover_block((!empty($gr[1]) ? $gr[1]:$icon), $admin);
			$admin_grid = array('',$icon,'','text' => $text);
			$gr = &$admin_grid;
			$lk = 'db';
			break;
		case 'tools':	// tools drop box
			if(Ccms::get_tool_cnt(true) <= 0) continue 2;
			$cms_tools = Ccms::get_tools_menu('left','Tools',false);
			if(empty($cms_tools)) continue 2;
			$icon = Ccms_html::get_navbar_icon_text('Tools');
			if(is_array($cms_tools)) {	// not a drop box
				$lk = $cms_tools['uri'];
				$gr = array(
					0 => $cms_tools['uri'],
					1 => $cms_tools['text'],
					2 => $cms_tools['title'],
					'text' => $cms_tools['text'],
					);
				} // if
			else {
				$text = Ccms_drop_box::hover_block((!empty($gr[1]) ? $gr[1]:$icon), $cms_tools);
				$tool_grid = array('',$icon,'','text' => $text);
				$gr = &$tool_grid;
				$lk = 'db';
				} // else
			break;
		case 'apps':	// apps drop box
			if(Ccms::get_body_cnt() <= 0) continue 2;
			$cms_bodies = Ccms_apps::get_apps_menus('left',false,false,'Apps');
			if(empty($cms_bodies)) continue 2;
			$icon = Ccms_html::get_navbar_icon_text('Apps');
			$body_menu = Ccms_drop_box::hover_block((!empty($gr[1]) ? $gr[1]:$icon),$cms_bodies);
			$gr = array('',$icon,'','text' => $body_menu);
			$lk = 'db';
			break;
		default:
			if(!empty($gr['type'])) {
				switch($gr['type']) {
				case 'inline_tool':
					break;
				default:
					break;
					} // switch
				} // if
			break;
			} // switch

		if((!empty($lk)) && (preg_match('/^id_(app|body|tool)_[0-9]+$/',$lk))) {	// has a link and is an id string
			$ty = preg_replace('/^id_(app|body|tool)_[0-9]+$/','$1',$lk);
			$id = preg_replace('/^id_(app|body|tool)_([0-9]+)$/','$2',$lk);
			$use = array_filter($uris, function($uri) use ($lk,$ty,$id) {	// find allowed entries
				if(preg_match('/-\s+select\s+-/i',$uri['text'])) return false;
				if($lk == $uri['value']) {
					if((isset($uri['allowed_now'])) && (!$uri['allowed_now'])) {
						return false;
						} // foreach
					} // if
				return true;
				});
			if(empty($use)) continue;
			switch($ty) {
			case 'app':
			case 'body':
				$lk = Ccms::get_body_uri($id);
				break;
			case 'tool':
				$lk = Ccms::get_tool_uri($id);
				break;
			default:
				break;
				} // switch
			if(empty($lk)) continue;
			} // if

		$txt = (isset($gr['nb_icon']) ? $gr['nb_icon']:$gr[1]);
		$tit = (isset($gr['title']) ? $gr['title']:$gr[2]);
		if(empty($txt)) {
			$txt = '(empty)';
			$tit .= '(missing link text for link URL; ' . addslashes(htmlentities($lk)) . ' on row ' . $i . ', check config)';
			} // if
		if((!isset($gr['uri'])) && (isset($gr['text'])) && ($lk == 'db')) {	// a drop down or similar
			echo '			<li class="' . $navbar_prefix . 'cms_nav_bar"' . $liw_text . '>' . $gr['text'] . '</li>' . PHP_EOL;
			} // if
		else if($cur_uri == $lk) {
			$tit .= ' On page.';
			echo '			<li class="' . $navbar_prefix . 'cms_nav_bar_on"' . $liw_text . (!empty($tit) ? ' title="' . $tit . '"':'') . '>' . $txt . '</li>' . PHP_EOL;
			// echo '			<li class="' . $navbar_prefix . 'cms_nav_bar_on"' . $liw_text . '>' . '<a class="' . $navbar_prefix . 'cms_nav_bar_on ' . $navbar_prefix . 'cms_nav_bar" href="' . $lk . '"' . ' onclick="Ccms_cursor.setWait();"' . (!empty($tit) ? ' title="' . $tit . '"':'') . '>' . $txt . '</a>' . '</li>' . PHP_EOL;
			} // if
		else echo '			<li class="' . $navbar_prefix . 'cms_nav_bar"' . $liw_text . '>' . '<a class="' . $navbar_prefix . 'cms_nav_bar" href="' . $lk . '"' . ' onclick="Ccms_cursor.setWait();"' . (!empty($tit) ? ' title="' . $tit . '"':'') . '>' . $txt . '</a>' . '</li>' . PHP_EOL;
		} // for

	if(!CMS_C_SHOW_LOGIN_LINK) {
		$chg_pw = true;
		$dbox = true;
		if(!Ccms::is_full_body_view()) {
			// echo '		<li class="' . $navbar_prefix . 'cms_nav_bar_on" style="width: 25px; border: 0 none #ffffff">' . ' ' . '</li>' . PHP_EOL;
			$text = Ccms_auth::get_login_logout($navbar_prefix . 'cms_nav_bar',$dbox,$chg_pw);
			} // if
		else if(Ccms::is_full_body_view()) {
			$text = Ccms_auth::get_signin_signout($navbar_prefix . 'cms_nav_bar',$dbox,$chg_pw);
			} // if
		if(!empty($text)) {
			echo '			<li class="' . $navbar_prefix . 'cms_nav_bar"' . $liw_text . '>' . $text . '</li>' . PHP_EOL;
			} // if
		} // if
?>
		</ul>
<!--</div>-->

<?php

	if($rln) echo '</div>';
	
	Ccms::page_end_comment(__FILE__);
