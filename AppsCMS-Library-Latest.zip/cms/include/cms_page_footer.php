<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_footer.php 3351 2023-07-18 01:29:19Z robert0609 $
 */

if(!CMS_S_FOOTER_BOOL) return;

if((CMS_C_CUSTOM_FOOTER) && (is_readable(PAGE_FOOTER_FS_INC))) {
	Ccms::page_start_comment(PAGE_FOOTER_INC);
	include PAGE_FOOTER_FS_INC;
	Ccms::page_end_comment(PAGE_FOOTER_INC);
	return;
	} // if

function footer_cell_linebyline(...$lines) {
	// only put <br> if both have text
	$cnt = 0;
	foreach($lines as $l) {
		if(empty($l)) continue;
		if($cnt++ > 0) echo '<br>';
		echo $l;
		} // foreach
	} // footer_cell_linebyline()

Ccms::page_start_comment(__FILE__);
?>

		<ul class="page_bottom">
<!--			<li>&nbsp;</li>-->
			<li class="page_bottom" style="text-align: left; max-width: 33%">
				<?php echo Ccms::get_page_legals(); ?>
			</li>
<?php
		$smtxt = Ccms::get_social_media('footer_left');
		if(!empty($smtxt)) echo '<li class="page_bottom">' . $smtxt . '</li>' . PHP_EOL;
?>
			<li class="page_bottom" style="text-align: center; max-width: 33%">
				<?php echo footer_cell_linebyline(
						Ccms::get_copyright_text(),
						Ccms::get_page_stats()); ?>
			</li>
<?php
		$smtxt = Ccms::get_social_media('footer_center');
		if(!empty($smtxt)) echo '<li class="page_bottom">' . $smtxt . '</li>' . PHP_EOL;
?>
<?php
		$smtxt = Ccms::get_social_media('footer_right');
		if(!empty($smtxt)) echo '<li class="page_bottom">' . $smtxt . '</li>' . PHP_EOL;
?>
			<li class="page_bottom" style="text-align: right; max-width: 33%;">
				<?php echo footer_cell_linebyline(
						Ccms::get_about_text_link(),
						Ccms::get_show_counter_text()); ?>
			</li>
<!--			<li>&nbsp;</li>-->
		</ul>
<?php

echo Ccms::get_cookie_banner();

Ccms::page_end_comment(__FILE__);

