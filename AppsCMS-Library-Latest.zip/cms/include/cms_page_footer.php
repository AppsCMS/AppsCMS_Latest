<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_footer.php 3085 2023-01-03 08:23:53Z robert0609 $
 */

if(!CMS_S_FOOTER_BOOL) return;

if((CMS_C_CUSTOM_FOOTER) && (is_readable(PAGE_FOOTER_FS_INC))) {
	Ccms::page_start_comment(PAGE_FOOTER_INC);
	include PAGE_FOOTER_FS_INC;
	Ccms::page_end_comment(PAGE_FOOTER_INC);
	return;
	} // if

function footer_cell_linebyline($l1,$l2) {
	// only put <br> if both have text
	if($l1) echo $l1;
	if(($l1) && ($l2)) echo '<br>';
	if($l2) echo $l2;
	} // footer_cell_linebyline()

Ccms::page_start_comment(__FILE__);
?>

		<ul class="page_bottom">
<!--			<li>&nbsp;</li>-->
			<li class="page_bottom">
				<?php echo footer_cell_linebyline(
						Ccms::get_disclaimer_text(),
						Ccms::get_page_legals()); ?>
			</li>
<?php
		$smtxt = Ccms::get_social_media('footer_left');
		if(!empty($smtxt)) echo '<li class="page_bottom">' . $smtxt . '</li>' . PHP_EOL;
?>
			<li class="page_bottom" style="text-align: center;">
				<?php echo footer_cell_linebyline(
						Ccms::get_copyright_text(),
						Ccms::get_page_stats()); ?>
			</li>
<?php
		$smtxt = Ccms::get_social_media('footer_center');
		if(!empty($smtxt)) echo '<li class="page_bottom">' . $smtxt . '</li>' . PHP_EOL;
?>
<?php
		$smtxt = Ccms::get_social_media('footer_right');
		if(!empty($smtxt)) echo '<li class="page_bottom">' . $smtxt . '</li>' . PHP_EOL;
?>
			<li class="page_bottom" style="min-width: 25%; text-align: right; white-space: nowrap;">
				<?php echo footer_cell_linebyline(
						Ccms::get_about_text_link(),
						Ccms::get_show_counter_text()); ?>
			</li>
<!--			<li>&nbsp;</li>-->
		</ul>
<?php

echo Ccms::get_cookie_banner();

Ccms::page_end_comment(__FILE__);

