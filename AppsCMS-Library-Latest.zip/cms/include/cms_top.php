<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_top.php 3351 2023-07-18 01:29:19Z robert0609 $
 */

// Set the level of error reporting
error_reporting(E_ALL | E_STRICT);

if(file_exists('cms/include/cms_configure.php')) require_once 'cms/include/cms_configure.php';
elseif(file_exists('include/cms_configure.php')) require_once 'include/cms_configure.php';
elseif (file_exists('../../cms/include/cms_configure.php')) require_once '../../cms/include/cms_configure.php'; // for apps to run in (APP_DIR)
else die('ERROR: Failed to find AppsCMS configuration.');

require_once CMS_FS_INCLUDES_DIR . 'cms_auto_class_loader.php';

if(Ccms_base::is_ajax()) return;
if(Ccms_base::is_api()) return;

if((Ccms_minify_plugin::is_enabled()) &&
	(defined('PL_CMS_MINIFY_MINIFY_ADMIN')) &&
	(PL_CMS_MINIFY_MINIFY_ADMIN)) {
	ob_start('Ccms_minify_plugin::minify_html');
	} // if

Ccms_ops::do_site_redirect();

Ccms_ops::do_site_closed();

