<?php
/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_page_header.php 3216 2023-02-20 13:13:37Z robert0609 $
 */

if((CMS_C_CUSTOM_HEADER) && (is_readable(PAGE_HEADER_FS_INC))) {
	Ccms::page_start_comment(PAGE_HEADER_INC);
	include PAGE_HEADER_FS_INC;
	$atxt = Ccms::get_header_admin_tools_pdb_text();
	if(!empty($atxt)) echo '<br>' . $atxt . PHP_EOL;
	Ccms::page_end_comment(PAGE_HEADER_INC);
	return;
	} // if

Ccms::page_start_comment(__FILE__);
?>
		<ul class="page_top">
<!--			<li class="page_top" style="text-align: left;">&nbsp;</li>-->
			<li style="text-align: left;"><?= Ccms::get_home_link() ?></li>		
		
<?php	$atxt = Ccms::get_header_admin_tools_pdb_text(); 
		if(!empty($atxt)) {		?>
			<li class="page_top" style="text-align: left;">
				<?= $atxt ?>
			</li>
<?php		} // if ?>

<?php	$smtxt = Ccms::get_social_media('header_left');
		if(!empty($smtxt)) {	?>
			<li class="page_top no_print" style="text-align: left;">
				<?= $smtxt ?>
			</li>
<?php		} // if ?>
			
			<li class="page_top" style="text-align: center;">
				<div class="top_title">
					<?= Ccms::get_header_bar_title() ?>
				</div>
			</li>
					
<?php	// sort where the login and social media sit
		$smtxt = Ccms::get_social_media('header_right');
		if((Ccms_auth::is_header_login_logout_allowed()) &&
			($txt = Ccms_auth::get_login_logout('',false, true))) {	// do a simple login
			if(!empty($smtxt)) { ?>
					
			<li class="page_top no_print" style="text-align: right;">
				<?= $smtxt ?> 
			</li>
<?php				} // if ?>
			<li class="page_top no_print" style="text-align: right; font-size: smaller;">
				<div class="top_auth">
					<?= $txt ?>
				</div>
			</li>
<?php			} // if
		else if(!empty($smtxt)) { ?>
			<li class="page_top no_print" style="text-align: right; width: 25%;">
				<?= $smtxt ?>
			</li>
<?php		} // else if 
		else { // spacer ?>
			<li class="page_top no_print" style="text-align: right; width: 25%;">
				&nbsp;
			</li>
<?php		} // else ?>
			
<!--			<li class="page_top no_print" style="float: right;">&nbsp;</li>-->
		</ul>
<?php

Ccms::page_end_comment(__FILE__);
