<?php

/*
 * Applications Management System Library for PHP (AppsCMS)
 * see Licence in cms/LICENCE.txt
 * _SVN_build: $Id: cms_lib_sqsh.php 3366 2023-07-20 07:23:55Z robert0609 $
 */

class Ccms_mount_sqsh {

	public const APPSCMS_PKG_DIR = '/usr/local/lib/AppsCMS/';

	protected static $_readonly_mnts = array(	// NB associative index is used as a variable name
		array(	// AppsCMS library
			'name' => 'AppsCMS',	// Name
			'mountpnt' => 'cms',	// mount point dir
			'chk_dir' => false,	// if exists don't mount
			'chk_file' => 'cms/cms_index.php',	// if exists don't mount
			'sqfs' => 'cms_lib_sqsh.sqsh',	// squash file system to mount
			'required' => true,	// true = must have local files or a sqsh mount
			),
 		array(	// Applications
			'name' => 'Applications',	// Name
			'mountpnt' => 'apps',	// mount point dir
			'chk_dir' => 'apps/include',	// if exists don't mount
			'chk_file' => false,	// if exists don't mount
			'sqfs' => 'apps_fs_sqsh.sqsh',	// squash file system to mount
			'required' => true,	// true = must have local files or a sqsh mount
			),
 		array(	// Doxy
			'name' => 'Documentation',	// Name
			'mountpnt' => 'doxy/cms_html',	// mount point dir
			'chk_dir' => false,	// if exists don't mount
			'chk_file' => 'doxy/cms_html/index.html',	// if exists don't mount
			'sqfs' => 'cms_docs_sqsh.sqsh',	// squash file system to mount
			'required' => false,	// true = must have local files or a sqsh mount
			),
 		array(	// Examples
			'name' => 'Examples',	// Name
			'mountpnt' => 'examples',	// mount point dir
			'chk_dir' => 'examples/apps',	// if exists don't mount
			'chk_file' => false,	// if exists don't mount
			'sqfs' => 'cms_examples_sqsh.sqsh',	// squash file system to mount
			'required' => false,	// true = must have local files or a sqsh mount
			),
 		array(	// API Client Example
			'name' => 'API Client Example',	// Name
			'mountpnt' => 'API_Client',	// mount point dir
			'chk_dir' => false,	// if exists don't mount
			'chk_file' => 'API_Client/api_test.php',	// if exists don't mount
			'sqfs' => 'cms_example_api_client_sqsh.sqsh',	// squash file system to mount
			'required' => false,	// true = must have local files or a sqsh mount
			),
		);
	protected static $msg_log = false;

	function __construct() {
		} // __construct()

	function __destruct() {
		// clean before I go home
		} // __destruct()

// dynamic methods

// static methods

	protected static function log_msg($msg, $prn = true) {
		if(!self::$msg_log) {
			self::$msg_log = 'var/logs/' . $_SERVER['SERVER_NAME'] . '_startup_error.log';
			ini_set('log_errors','On');
			ini_set('error_log', self::$msg_log);
			} // if
		error_log(date('c: ') . $msg . PHP_EOL,3,self::$msg_log);
		if($prn) echo $msg . PHP_EOL;
		} // log_msg()

	protected static function _mount_read_only_filesystem(&$_mnt) {	// this is global
        extract($_mnt);	// foreach($_mnt as $k => &$v) $$k = $v;	// translate vars
		$sqsh_dirs = array("", self::APPSCMS_PKG_DIR);	// try local first then system

		if((($chk_file) && (file_exists($chk_file))) ||
			(($chk_dir) && (is_readable($chk_dir))))
			return true;	// already exists or is mounted

		$sqsh_fnd = false;
		$sqsh_path = false;
		foreach($sqsh_dirs as $sqsh_dir) {
			$sqsh_path = $sqsh_dir . $sqfs;
			if((file_exists($sqsh_path)) &&
				(is_readable($sqsh_path))) {	// have squashfs ??
				$sqsh_fnd = true;
				break;
				} // if
			} // foreach
		if(!$sqsh_fnd) {
			if(!$required) return true;
			self::log_msg("ERROR: '" . $sqfs . "' file system not found. Cannot mount read only filesystem.");
			false;
			} // if

		@mkdir($mountpnt,0777,true);	// make sure the mount point is there
		@chmod($mountpnt,0777);	// and useable perms for web and cli
		$g = filegroup(__FILE__);
		@chgrp($mountpnt, $g);
		$output=null;
		$retval=null;
		$opts = " -o allow_other";	// -o allow_root
		self::log_msg('INFO: mount "' . $sqsh_path . '" to "' . $mountpnt . '", group: "' . $g . '", options: ' . $opts,false);
		exec('squashfuse ' .  $opts . ' ' . $sqsh_path . ' ' . $mountpnt, $output, $retval);	// mount simple fs
		if($retval) {	// mount fs
			self::log_msg("ERROR: Read only \"" . $sqsh_path . "\" mount failed, status $retval.");
			self::log_msg("ERROR: Output:" . PHP_EOL . var_export($output,true));
			return false;
			} // if
		self::log_msg('INFO: mounted "' . $sqsh_path . '" to "' . $mountpnt . '" options: ' . $opts,false);
		return true;
		} // _mount_read_only_filesystem()

	public static function mount_readonly_filesystems() {
		$ok = true;
		foreach(self::$_readonly_mnts as &$_mnt) {
			if(!self::_mount_read_only_filesystem($_mnt)) $ok = false;
			} // foreach
		if(!$ok) {
			echo "ERROR: Cannot mount: required file system." . '<br>' . PHP_EOL;
			exit(1001);
			} // if
		return $ok;
		} // mount_readonly_filesystems()

} // Ccms_mount_sqsh

Ccms_mount_sqsh::mount_readonly_filesystems();

// eof
